package com.shazammod;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import net.minecraft.util.Mth;

/**
 * unlocked      = sudah layak jadi Shazam (nanti dibuka setelah boss kalah, sementara lewat /shazam unlock)
 * transformed   = sedang dalam wujud juara (Shazam atau Black Adam)
 * energy        = Energi Petir, 0 sampai MAX_ENERGY
 * hoodUp        = hood jubah sedang dipakai di kepala
 * knockoutUntil = game time sampai kapan belum bisa SHAZAM lagi, sesudah terlempar balik jadi manusia
 *                 karena serangan mematikan (0 = nggak sedang pulih)
 * form          = juara yang dipilih (lihat ShazamForm): 0 = Shazam, 1 = Black Adam
 */
public record ShazamData(boolean unlocked, boolean transformed, float energy, boolean hoodUp, long knockoutUntil, int form) {
    public static final ShazamData DEFAULT = new ShazamData(false, false, ShazamPowers.MAX_ENERGY, true, 0L, 0);

    public static final Codec<ShazamData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.BOOL.optionalFieldOf("unlocked", false).forGetter(ShazamData::unlocked),
            Codec.BOOL.optionalFieldOf("transformed", false).forGetter(ShazamData::transformed),
            Codec.FLOAT.optionalFieldOf("energy", ShazamPowers.MAX_ENERGY).forGetter(ShazamData::energy),
            Codec.BOOL.optionalFieldOf("hood_up", true).forGetter(ShazamData::hoodUp),
            Codec.LONG.optionalFieldOf("knockout_until", 0L).forGetter(ShazamData::knockoutUntil),
            Codec.INT.optionalFieldOf("form", 0).forGetter(ShazamData::form)
    ).apply(instance, ShazamData::new));

    public ShazamData withUnlocked(boolean value) {
        return new ShazamData(value, transformed, energy, hoodUp, knockoutUntil, form);
    }

    public ShazamData withTransformed(boolean value) {
        return new ShazamData(unlocked, value, energy, hoodUp, knockoutUntil, form);
    }

    public ShazamData withEnergy(float value) {
        return new ShazamData(unlocked, transformed, Mth.clamp(value, 0f, ShazamPowers.MAX_ENERGY), hoodUp, knockoutUntil, form);
    }

    public ShazamData withHoodUp(boolean value) {
        return new ShazamData(unlocked, transformed, energy, value, knockoutUntil, form);
    }

    public ShazamData withKnockoutUntil(long value) {
        return new ShazamData(unlocked, transformed, energy, hoodUp, value, form);
    }

    public ShazamData withForm(ShazamForm value) {
        return new ShazamData(unlocked, transformed, energy, hoodUp, knockoutUntil, value.ordinal());
    }

    /** Juara yang dipilih (nilai tak dikenal dari save lama/rusak dianggap Shazam). */
    public ShazamForm champion() {
        return ShazamForm.byId(form);
    }

    public boolean isBlackAdam() {
        return champion() == ShazamForm.BLACK_ADAM;
    }
}
