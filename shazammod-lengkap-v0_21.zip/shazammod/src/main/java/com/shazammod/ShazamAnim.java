package com.shazammod;

/**
 * Animasi yang dikirim server ke semua pemain di sekitar.
 * Urutannya dipakai sebagai id di jaringan, jadi tambah yang baru di paling bawah.
 */
public enum ShazamAnim {
    TRANSFORM,
    REVERT,
    SOLOMON_SIGHT,
    HERCULES_CLAP,
    ATLAS_GROUND,
    ATLAS_DIVE,
    ATLAS_IMPACT,
    ZEUS_CALL,
    ACHILLES_ROAR,
    MERCURY_BLITZ,
    LAUNCH,
    LAND_SOFT,
    LAND_HERO,
    CRASH,
    SONIC_BOOM,
    ROLL_LEFT,
    ROLL_RIGHT,
    SUMMON,      // memanggil enam dewa sebelum petir transformasi
    ZEUS_RAGE,   // amarah Zeus: mata menyala putih
    HOOD_UP,     // tangan meraih ke belakang kepala lalu menarik hood ke depan
    HOOD_DOWN,   // tangan memegang tepi hood di dahi lalu mendorongnya ke belakang
    MERCURY_ON,  // Mode Kilat Mercury menyala: kuda-kuda, listrik meledak dari badan
    MERCURY_OFF, // Mode Kilat Mercury mati
    MERCURY_JAB, // pukulan-pukulan secepat kilat (x, y, z = titik kena)
    MERCURY_CROSS,
    MERCURY_HOOK,
    MERCURY_KICK,
    KNOCKOUT,    // serangan mematikan saat jadi Shazam: badan terhentak, kekuatan tercabut dari dada, balik jadi manusia
    // ======= Black Adam (dewa-dewa Mesir) =======
    ADAM_SHU,         // S - Pusaran Shu: lengan terentang lalu terangkat, badai pasir berputar mengangkat musuh
    ADAM_HERU,        // H - Sambaran Heru: merunduk, lalu menerjang secepat elang (x, y, z = titik akhir terjangan)
    ADAM_AMON,        // A - Tinju Amon: melompat kecil, menghantam tanah, tanah terbelah lurus ke depan (x, y, z = ujungnya)
    ADAM_ZEHUTI,      // Z - Segel Zehuti: dua jari ke pelipis lalu menunjuk, hieroglif mengikat musuh
    ADAM_ZEHUTI_MARK, // segel hieroglif di satu musuh (x, y, z = posisinya); tanpa gerakan badan
    ADAM_ATON,        // A - Sinar Aton: tangan ke langit, cakram matahari terbentuk di atas telapak
    ADAM_ATON_RAY,    // satu sinar Aton ke satu musuh (x, y, z = sasaran); tanpa gerakan badan
    ADAM_MEHEN,       // M - Lilitan Mehen: kedua lengan menyilang, ular raksasa membelit badan
    ADAM_MEHEN_BITE,  // ular Mehen mematuk satu musuh (x, y, z = sasaran); tanpa gerakan badan
    ADAM_RAGE;        // Murka Kahndaq: badan terangkat, kepalan mengepal di samping, lalu meraung - mata emas menyala

    // Waktu (tick) yang dipakai bersama oleh server dan client supaya efek pas dengan gerakan
    public static final int SUMMON_TICKS = 88;      // enam dewa datang satu per satu (lihat client.fx.GodShow), lalu kepalan diangkat
    public static final int TRANSFORM_WINDUP = 8;   // angkat kepalan ke langit
    public static final int BOLT_DESCENT = 10;      // petir turun pelan dari langit ke kepalan (slow motion)
    public static final int TRANSFORM_STRIKE = TRANSFORM_WINDUP + BOLT_DESCENT;   // tick klip TRANSFORM saat petir mengenai
    public static final int TRANSFORM_SLOWMO = 28;  // slow motion berlanjut selama kostum terbentuk (sampai hood terpasang)
    public static final int HOOD_GRAB = 6;          // tangan memegang tepi hood
    public static final int HOOD_MOVE = 10;         // hood ditarik/didorong selama ini
    public static final int HOOD_TICKS = 24;        // panjang animasi hood
    public static final int REVERT_WINDUP = 6;
    public static final int CAST_WINDUP = 5;        // Solomon, Hercules, Atlas (di tanah), Zeus
    public static final int ROAR_WINDUP = 4;        // Achilles
    public static final int ACHILLES_TICKS = 120;   // lama kulit tak tertembus
    public static final int SOLOMON_TICKS = 200;    // lama musuh "terbaca"
    public static final int BLITZ_TICKS = 6;        // lama terjangan Mercury
    public static final int RAGE_WINDUP = 9;        // Zeus Rage: membungkuk, lalu meraung ke langit
    public static final int RAGE_TICKS = 240;       // lama amarah Zeus (12 detik)
    public static final int KNOCKOUT_BURST = 3;     // terlempar balik: kekuatan tercabut keluar dari dada (lengan terentang)
    // Black Adam
    public static final int SHU_TICKS = 50;         // lama pusaran pasir Shu (lalu meledak ke luar)
    public static final int HERU_WINDUP = 3;        // merunduk sebelum menerjang
    public static final int HERU_TICKS = 5;         // lama terjangan Heru (titik awal -> titik akhir)
    public static final int AMON_WINDUP = 7;        // melompat kecil lalu kedua kepalan menghantam tanah
    public static final int AMON_SPREAD = 8;        // tanah terbelah merambat sampai ujung dalam waktu ini
    public static final int ATON_WINDUP = 8;        // cakram matahari terbentuk, lalu sinar pertama
    public static final int ATON_GAP = 2;           // jeda antar-sinar ke tiap musuh
    public static final int MEHEN_WINDUP = 6;       // ular muncul dari bayangan dan melilit
    public static final int MEHEN_TICKS = 160;      // lama lilitan Mehen (8 detik)
    public static final int ADAM_RAGE_WINDUP = 10;  // Murka Kahndaq: menahan amarah, lalu meraung

    /** Penanda efek di satu titik (bukan gerakan badan): klip pemain yang sedang jalan nggak diganti. */
    public boolean isMarker() {
        return this == ADAM_ZEHUTI_MARK || this == ADAM_ATON_RAY || this == ADAM_MEHEN_BITE;
    }

    public static ShazamAnim byId(int id) {
        ShazamAnim[] values = values();
        return id >= 0 && id < values.length ? values[id] : null;
    }
}
