package com.shazammod.client;

import com.shazammod.ShazamClientState;
import com.shazammod.ShazamPowers;
import com.shazammod.client.flight.MercuryMode;
import com.shazammod.client.fx.AdamFx;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

/**
 * HUD Shazam / Black Adam: Energi Petir, juara yang dipilih, dan skill di kiri atas; bar darah di atas hotbar saat
 * berubah wujud. Warna mengikuti juara (emas Shazam / emas membara Black Adam).
 */
public final class ShazamHud {
    private ShazamHud() {}

    private static final int X = 6;
    private static final int Y = 6;
    private static final int BAR_WIDTH = 130;
    private static final String LETTERS = "SHAZAM\u26A1";   // kotak terakhir: Zeus Rage
    private static final String ADAM_LETTERS = "SHAZAM\u2625"; // Black Adam: Shu Heru Amon Zehuti Aton Mehen + ankh (Murka Kahndaq)
    private static final int ADAM_GOLD = 0xFFFFB13D;           // emas membara
    private static final int ADAM_BAR = 0xFFE89A2C;
    private static final int ADAM_SHADE = 0xB0140A06;          // kotak gelap kecokelatan, seperti batu Kahndaq
    private static final int MEHEN_ON = 0xFF5FE6CF;            // lilitan Mehen aktif: pirus
    private static final int MEHEN_BG = 0xB0102A26;
    private static final int GOLD = 0xFFFFD34D;
    private static final int GRAY = 0xFF9E9E9E;
    private static final int STORM_BLUE = 0xFF55FFFF;
    private static final int SHADE = 0xA0000000;
    private static final int MERCURY_ON = 0xFF86F0FF;
    private static final int MERCURY_BG = 0xA0103848;
    private static final int MERCURY_RUN = 0xFFFFE28A;   // auto-hit dimatikan: cuma lari
    private static final int RECOVERING = 0xFFFF7A6B;    // habis terlempar balik jadi manusia: belum bisa SHAZAM

    public static void render(GuiGraphics graphics, DeltaTracker deltaTracker) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.player == null || !ShazamClientState.unlocked) {
            return;
        }
        if (ShazamClientState.transformed) {
            renderHealth(graphics, mc, mc.player);
        }
        renderEnergy(graphics, mc);
    }

    /** Pengganti baris hati: 100 darah nggak muat dalam hati biasa. */
    private static void renderHealth(GuiGraphics graphics, Minecraft mc, LocalPlayer player) {
        if (mc.gameMode == null || !mc.gameMode.canHurtPlayer()) {
            return;
        }
        int x = graphics.guiWidth() / 2 - 91;
        int y = graphics.guiHeight() - 39;
        int width = 81;
        int height = 9;
        float health = player.getHealth();
        float max = Math.max(1f, player.getMaxHealth());
        float absorption = player.getAbsorptionAmount();
        graphics.fill(x - 1, y - 1, x + width + 1, y + height + 1, 0xFF6B4E12);
        graphics.fill(x, y, x + width, y + height, 0xFF1A0E0E);
        int filled = Math.round(Mth.clamp(health / max, 0f, 1f) * width);
        graphics.fill(x, y, x + filled, y + height, 0xFFC62828);
        graphics.fill(x, y, x + filled, y + 3, 0xFFE57373);
        if (absorption > 0f) {
            int extra = Math.round(Mth.clamp(absorption / max, 0f, 1f) * width);
            graphics.fill(x, y + height - 2, x + extra, y + height, GOLD);
        }
        String text = "\u2764 " + Math.round(health) + " / " + Math.round(max);
        graphics.pose().pushPose();
        graphics.pose().translate(x + width / 2f, y + 2f, 0f);
        graphics.pose().scale(0.7f, 0.7f, 1f);
        graphics.drawCenteredString(mc.font, text, 0, 0, 0xFFFFFFFF);
        graphics.pose().popPose();
    }

    private static void renderEnergy(GuiGraphics graphics, Minecraft mc) {
        boolean transformed = ShazamClientState.transformed;
        float energy = ShazamClientState.energy;
        int recovery = transformed ? 0 : ShazamClientState.recovery();
        if (!transformed && energy >= ShazamPowers.MAX_ENERGY && recovery <= 0) {
            return; // wujud manusia, energi penuh, dan nggak sedang pulih: disembunyikan
        }
        Font font = mc.font;
        boolean adam = ShazamClientState.isAdam();
        int color = transformed ? (adam ? ADAM_GOLD : GOLD) : GRAY;

        Component title = Component.literal("\u26A1 ")
                .append(Component.translatable("hud.shazammod.energy"))
                .append(" " + Math.round(energy) + "/" + Math.round(ShazamPowers.MAX_ENERGY));
        graphics.drawString(font, title, X, Y, color, true);
        // juara yang dipilih, kecil di samping judul
        Component champion = Component.translatable(adam ? "champion.shazammod.black_adam" : "champion.shazammod.shazam");
        int titleWidth = font.width(title);
        graphics.pose().pushPose();
        graphics.pose().translate(X + titleWidth + 6, Y + 1.5f, 0);
        graphics.pose().scale(0.75f, 0.75f, 1f);
        graphics.drawString(font, champion, 0, 0, adam ? 0xFFE0A050 : 0xFFE8D8A0, true);
        graphics.pose().popPose();

        int barY = Y + 12;
        graphics.fill(X - 1, barY - 1, X + BAR_WIDTH + 1, barY + 5, adam ? ADAM_SHADE : SHADE);
        int filled = Math.round(energy / ShazamPowers.MAX_ENERGY * BAR_WIDTH);
        graphics.fill(X, barY, X + filled, barY + 4, transformed && adam ? ADAM_BAR : color);
        if (ShazamClientState.storm) {
            graphics.drawString(font, Component.translatable("hud.shazammod.storm"), X + BAR_WIDTH + 6, barY - 2, STORM_BLUE, true);
        }
        if (!transformed) {
            if (recovery > 0) {   // habis kena serangan mematikan: sisa waktu sampai bisa SHAZAM lagi
                graphics.drawString(font, Component.translatable("hud.shazammod.recovering", (recovery + 19) / 20),
                        X, barY + 9, RECOVERING, true);
            }
            return;
        }

        // Kotak skill S-H-A-Z-A-M dan amarah: huruf dewa di atas, tombol (atau sisa detik cooldown) di bawah.
        // Black Adam: huruf yang sama, dewa yang beda (Shu, Heru, Amon, Zehuti, Aton, Mehen) + ankh untuk Murka Kahndaq.
        int boxY = barY + 9;
        boolean mercury = !adam && mc.player != null && ShazamClientState.isMercury(mc.player.getId());
        boolean mehen = adam && mc.player != null && AdamFx.mehenStrength(mc.player, 0f) > 0.05f;
        String letters = adam ? ADAM_LETTERS : LETTERS;
        int letterGold = adam ? ADAM_GOLD : GOLD;
        for (int i = 0; i < ShazamClient.SKILL_KEYS.length; i++) {
            int boxX = X + i * 22;
            int cooldown = ShazamClientState.cooldown(i);
            boolean ready = cooldown <= 0;
            boolean on = i == 5 && mercury;   // M: Mode Kilat menyala
            boolean coiled = i == 5 && mehen; // M: ular Mehen sedang melilit
            graphics.fill(boxX - 1, boxY - 1, boxX + 20, boxY + 21, on ? MERCURY_BG : coiled ? MEHEN_BG : adam ? ADAM_SHADE : SHADE);
            graphics.drawCenteredString(font, String.valueOf(letters.charAt(i)), boxX + 10, boxY + 2,
                    on ? MERCURY_ON : coiled ? MEHEN_ON : (ready ? letterGold : GRAY));
            String sub;
            int subColor = ready ? 0xFFFFFFFF : GRAY;
            if (on) {
                boolean auto = MercuryMode.isAuto();
                sub = Component.translatable(auto ? "hud.shazammod.mercury_auto" : "hud.shazammod.mercury_run").getString();
                subColor = auto ? 0xFFFFFFFF : MERCURY_RUN;
            } else if (ready) {
                sub = ShazamClient.SKILL_KEYS[i].getTranslatedKeyMessage().getString();
                if (sub.length() > 4) {
                    sub = sub.substring(0, 4);
                }
            } else {
                sub = (cooldown + 19) / 20 + "s";
            }
            graphics.pose().pushPose();
            graphics.pose().translate(boxX + 10, boxY + 13, 0);
            graphics.pose().scale(0.7f, 0.7f, 1f);
            graphics.drawCenteredString(font, sub, 0, 0, subColor);
            graphics.pose().popPose();
        }
    }
}
