package com.shazammod.client.fx;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamPowers;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Runes;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Efek Black Adam di client: berubah wujud dengan petir emas-jingga membara & asap hitam, dan keenam skill dewa
 * Mesir. Semuanya buatan sendiri di atas mesin efek (client.vfx), dipicu animasi dari server (ShazamAnim.ADAM_* dan
 * SUMMON/TRANSFORM/REVERT/KNOCKOUT kalau pemainnya memilih Black Adam).
 *
 * S Pusaran Shu   : badai pasir berpilin (pita pasir lembut + garis angin bercahaya) lalu meledak ke luar.
 * H Sambaran Heru : merunduk, lalu melesat dengan sayap elang dari cahaya; bayangan emas membara di lintasan.
 * A Tinju Amon    : kepalan membara menghantam tanah; celah membara merambat lurus, batu & debu menyembur di sepanjangnya.
 * Z Segel Zehuti  : mata pirus, gelombang hieroglif dari jari; tiap musuh terikat dua cincin hieroglif berputar.
 * A Sinar Aton    : cakram matahari terbentuk di atas telapak, sinar-sinarnya (berujung tangan) menyambar musuh.
 * M Lilitan Mehen : ular cahaya emas-merah membelit badan, kepalanya mematuk musuh.
 * R Murka Kahndaq : petir membara terhisap ke badan, lalu meledak; mata emas & listrik di badan (ShazamRage).
 */
public final class AdamFx {
    private AdamFx() {}

    // ======= Warna (RGB) =======
    public static final int AMBER = 0xFF8A24;        // petir & aura Black Adam: emas-jingga membara
    public static final int AMBER_LIGHT = 0xFFC46A;
    public static final int GOLD_HOT = 0xFFE2A8;
    public static final int WHITE_HOT = 0xFFF4E0;
    public static final int TURQUOISE = 0x48E2CE;    // Zehuti
    public static final int SUN = 0xFFD54A;          // Aton
    public static final int SERPENT = 0xFFC860;      // Mehen
    public static final int SERPENT_RED = 0xE8502E;
    public static final int SAND = 0xD9C08A;
    public static final int SMOKE = 0x17120E;        // asap hitam Black Adam
    private static final Vec3 UP = new Vec3(0, 1, 0);

    private static final Map<Integer, Long> SIGHT = new HashMap<>();       // mata pirus Zehuti: kapan mulai
    private static final Map<Integer, Serpent> SERPENTS = new HashMap<>(); // ular Mehen yang sedang melilit
    private static final Map<Integer, SunDisk> SUNS = new HashMap<>();     // cakram Aton yang sedang menyala

    public static void clear() {
        SIGHT.clear();
        SERPENTS.clear();
        SUNS.clear();
    }

    public static void tick(ClientLevel level) {
        long now = level.getGameTime();
        SIGHT.values().removeIf(start -> now - start > 80);
        SERPENTS.values().removeIf(s -> s.done);
        SUNS.values().removeIf(s -> s.done);
    }

    /** Animasi ini diurus AdamFx (ShazamFx melewatinya). */
    public static boolean handles(AbstractClientPlayer caster, ShazamAnim anim) {
        return switch (anim) {
            case SUMMON, TRANSFORM, REVERT, KNOCKOUT -> ShazamClientState.isAdam(caster.getId());
            default -> anim.name().startsWith("ADAM_");
        };
    }

    /** 0-1: mata pirus menyala sesudah Segel Zehuti. */
    public static float sightGlow(AbstractClientPlayer player, float partialTick) {
        Long start = SIGHT.get(player.getId());
        if (start == null) {
            return 0f;
        }
        float t = player.level().getGameTime() - start + partialTick - 2f;
        if (t < 0f) {
            return 0f;
        }
        return Math.min(1f, t / 3f) * Mth.clamp((70f - t) / 25f, 0f, 1f);
    }

    /** 0-1: ular Mehen sedang melilit pemain ini (HUD). */
    public static float mehenStrength(AbstractClientPlayer player, float partialTick) {
        Serpent s = SERPENTS.get(player.getId());
        return s == null || s.done ? 0f : s.strength(partialTick);
    }

    public static void onAnim(AbstractClientPlayer caster, ShazamAnim anim, Vec3 pos) {
        if (!handles(caster, anim)) {
            return;
        }
        boolean self = caster == Minecraft.getInstance().player;
        switch (anim) {
            case SUMMON -> summon(caster, self);
            case TRANSFORM -> transform(caster, self);
            case REVERT -> revert(caster, self);
            case KNOCKOUT -> knockout(caster, self);
            case ADAM_SHU -> shu(caster, self);
            case ADAM_HERU -> heru(caster, pos, self);
            case ADAM_AMON -> amon(caster, pos, self);
            case ADAM_ZEHUTI -> zehuti(caster, self);
            case ADAM_ZEHUTI_MARK -> seal(caster, pos);
            case ADAM_ATON -> aton(caster, self);
            case ADAM_ATON_RAY -> ray(caster, pos);
            case ADAM_MEHEN -> mehen(caster, self);
            case ADAM_MEHEN_BITE -> bite(caster, pos);
            case ADAM_RAGE -> rage(caster, self);
            default -> { }
        }
    }

    private static void schedule(int delay, int duration, ShazamFx.Step step) {
        ShazamFx.schedule(delay, duration, step);
    }

    private static void sound(ClientLevel level, Vec3 at, net.minecraft.sounds.SoundEvent sound, float volume, float pitch) {
        level.playLocalSound(at.x, at.y, at.z, sound, SoundSource.PLAYERS, volume, ShazamFx.slowPitch(level, pitch), false);
    }

    // ------------------------------------------------------------------ berubah wujud

    /**
     * Memanggil dewa-dewa Mesir: lingkaran hieroglif emas membara di tanah, pasir berputar pelan di tepinya,
     * asap hitam tipis merayap di kaki, dan cahaya mengalir dari lingkaran ke dada. Dewa-dewanya: ShazamSpirits.
     */
    private static void summon(AbstractClientPlayer caster, boolean self) {
        ShazamSpirits.start(caster);
        if (self) {
            ShazamCinematic.start();
        }
        int total = ShazamAnim.SUMMON_TICKS + ShazamAnim.TRANSFORM_STRIKE;
        schedule(0, 1, (level, t) -> {
            Vec3 c = caster.position();
            Ground.Map map = ShazamFx.ground(level, c, 3.2);
            double groundY = (map == null ? c.y : map.centerY) + 0.03;
            Vfx.add(new Runes.Circle(pt -> new Vec3(caster.getPosition(pt).x, groundY, caster.getPosition(pt).z), UP,
                    2.6 * caster.getScale(), AMBER, total + 8, -0.03f, 0.95f, null));
            Vfx.add(new Runes.Circle(pt -> new Vec3(caster.getPosition(pt).x, groundY + 0.01, caster.getPosition(pt).z), UP,
                    1.5 * caster.getScale(), GOLD_HOT, total + 8, 0.045f, 0.6f, null));
            sound(level, c, SoundEvents.AMETHYST_BLOCK_RESONATE, 1.2f, 0.45f);
            sound(level, c, SoundEvents.SAND_BREAK, 1.0f, 0.6f);
        });
        schedule(0, total, (level, t) -> {
            RandomSource r = level.random;
            double radius = 2.6 * caster.getScale();
            for (int i = 0, n = Vfx.count(2); i < n; i++) {   // cahaya mengalir dari lingkaran ke dada, berpilin
                double a = r.nextDouble() * Math.PI * 2.0;
                double x = caster.getX() + Math.cos(a) * radius, z = caster.getZ() + Math.sin(a) * radius;
                double tx = caster.getX() - x, tz = caster.getZ() - z;
                Vfx.mote(x, caster.getY() + 0.05, z, tx * 0.045 + tz * 0.03, 0.05 + r.nextDouble() * 0.03, tz * 0.045 - tx * 0.03,
                        AMBER_LIGHT, 0.09f, 22 + r.nextInt(8));
            }
            if (t % 2 == 0) {   // pasir berputar di tepi lingkaran
                double a = t * 0.21 + r.nextDouble();
                double x = caster.getX() + Math.cos(a) * (radius + 0.4), z = caster.getZ() + Math.sin(a) * (radius + 0.4);
                Vfx.dust(x, caster.getY() + 0.1, z, -Math.sin(a) * 0.12, 0.015, Math.cos(a) * 0.12, SAND, 0.45f, 18);
            }
            if (t % 5 == 0) {   // asap hitam tipis merayap di kaki
                double a = r.nextDouble() * Math.PI * 2.0, d = 0.6 + r.nextDouble() * 0.9;
                Vfx.smoke(caster.getX() + Math.cos(a) * d, caster.getY() + 0.1, caster.getZ() + Math.sin(a) * d,
                        Math.cos(a) * 0.01, 0.012, Math.sin(a) * 0.01, SMOKE, 0.35f + r.nextFloat() * 0.2f, 34);
            }
            if (t % 3 == 0) {
                double a = -t * 0.4;
                Vfx.glint(caster.getX() + Math.cos(a) * radius, caster.getY() + 0.1, caster.getZ() + Math.sin(a) * radius,
                        WHITE_HOT, 0.3f, 10);
            }
        });
    }

    private static void transform(AbstractClientPlayer caster, boolean self) {
        schedule(0, 1, (level, t) -> {
            sound(level, caster.position(), SoundEvents.LIGHTNING_BOLT_THUNDER, 0.8f, 0.42f);
            level.playLocalSound(caster.getX(), caster.getY(), caster.getZ(), SoundEvents.LIGHTNING_BOLT_THUNDER,
                    SoundSource.WEATHER, 0.5f, ShazamFx.slowPitch(level, 0.35f), false);
        });
        // 0-18: tenaga terkumpul: listrik membara dari tanah merambat ke kepalan, asap hitam terhisap
        schedule(0, ShazamAnim.TRANSFORM_STRIKE, (level, t) -> {
            RandomSource r = level.random;
            if (t % 2 == 0) {
                double a = r.nextDouble() * Math.PI * 2.0, d = 1.4 + r.nextDouble() * 1.2;
                Vec3 from = caster.position().add(Math.cos(a) * d, 0.05, Math.sin(a) * d);
                Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(from), pt -> ShazamPoses.handPos(caster, true, pt),
                        AMBER, 0.075f, 3, 1, 1, 0.24));
            }
            if (t % 3 == 1) {
                double a = r.nextDouble() * Math.PI * 2.0, d = 2.0 + r.nextDouble();
                Vfx.smoke(caster.getX() + Math.cos(a) * d, caster.getY() + 0.2, caster.getZ() + Math.sin(a) * d,
                        -Math.cos(a) * 0.06, 0.03, -Math.sin(a) * 0.06, SMOKE, 0.4f, 20);
            }
            if (t == ShazamAnim.TRANSFORM_WINDUP - 2) {
                Vfx.add(new Fx.Glow(caster, pt -> ShazamPoses.handPos(caster, true, pt), 0.95f, AMBER_LIGHT,
                        ShazamAnim.BOLT_DESCENT + 4, ShazamAnim.BOLT_DESCENT + 2));
            }
            if (self && t % 2 == 0) {
                CameraShake.add(0.045f);
            }
            ShazamFx.swirlDust(level, caster, t);
        });
        // 8-18: petir turun pelan; kepalan memanggilnya dengan busur listrik membara ke atas
        schedule(ShazamAnim.TRANSFORM_WINDUP, ShazamAnim.BOLT_DESCENT, (level, t) -> {
            Vec3 fist = caster.position().add(0, ShazamPowers.FIST_HEIGHT * caster.getScale(), 0);
            double remaining = 88.0 * (1.0 - Math.pow((t + 1) / (double) ShazamAnim.BOLT_DESCENT, 1.35));
            if (remaining < 26.0) {
                Vec3 tip = fist.add((level.random.nextDouble() - 0.5) * 0.8, Math.min(remaining, 9.0),
                        (level.random.nextDouble() - 0.5) * 0.8);
                Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(fist), Lightning.Anchor.fixed(tip), AMBER_LIGHT, 0.065f, 2, 1, 1,
                        0.28));
            }
            if (self) {
                ScreenFx.vignette(0.3f + t * 0.03f, 0x1E0800, 2);
            }
        });
        // 18: petir membara mengenai kepalan: ledakan cahaya, cincin asap hitam menyapu tanah
        schedule(ShazamAnim.TRANSFORM_STRIKE, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vec3 fist = c.add(0, ShazamPowers.FIST_HEIGHT * caster.getScale(), 0);
            Vfx.add(new Fx.Flash(fist, 3.4f, WHITE_HOT, 12, 1f));
            Vfx.add(new Fx.Flash(c.add(0, 1.0, 0), 2.6f, AMBER, 14, 0.95f));
            Vfx.add(new Fx.Pillar(c, 60.0, 1.6f, AMBER, 16));
            Vfx.add(new Fx.Bubble(fist, 2.6, AMBER_LIGHT, 9, 0.9f, 1.0, 2.0, true));
            ShazamFx.impact(level, caster, c, 2.7f, AMBER, GOLD_HOT, true, 0.3f);
            Ground.Map map = ShazamFx.ground(level, c, 4.0);
            if (map != null) {
                Vfx.add(new Fx.Wave(map.center(c), UP, 4.2, 1.2, SMOKE, 26, 0.55f, 0f, map, true));
            }
            ShazamFx.ringOfSparks(level, fist, 64, AMBER_LIGHT, 0.55);
            ShazamFx.groundArcs(level, c, 8, 4.8, AMBER, 7);
            Vfx.add(new Lightning.Crackle(caster, AMBER_LIGHT, 1.7f, 0.05f, 32));
            ShazamFx.shakeAround(c, 1.05f, 32);
            if (self) {
                ScreenFlash.flash(1.0f, 0xFFE8C8);
            }
        });
        schedule(ShazamAnim.TRANSFORM_STRIKE + 25, 1, (level, t) -> {
            Vec3 c = caster.position();
            Ground.Map map = ShazamFx.ground(level, c, 2.0);
            if (map != null) {
                Vfx.add(new Fx.Wave(map.center(c), UP, 2.2, 0.8, map.dustColor(level, c), 18, 0.45f, 0f, map, true));
            }
            ShazamFx.dustPuffs(level, c, SAND, 8, 1.0, 0.08);
        });
    }

    private static void revert(AbstractClientPlayer caster, boolean self) {
        schedule(0, ShazamAnim.REVERT_WINDUP, (level, t) -> {
            Vec3 chest = caster.position().add(0, 1.2 * caster.getScale(), 0);
            for (int i = 0, n = Vfx.count(4); i < n; i++) {
                Vec3 off = ShazamFx.randomDir(level.random).scale(1.4 + level.random.nextDouble() * 0.6);
                Vfx.mote(chest.x + off.x, chest.y + off.y, chest.z + off.z, -off.x * 0.16, -off.y * 0.16, -off.z * 0.16,
                        AMBER_LIGHT, 0.08f, 7);
            }
        });
        schedule(ShazamAnim.REVERT_WINDUP, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vec3 chest = c.add(0, 1.2, 0);
            Vfx.add(new Fx.Flash(chest, 1.8f, AMBER_LIGHT, 9, 1f));
            Vfx.add(new Fx.Bubble(chest, 1.6, AMBER, 8, 0.7f, 1.0, 2.0, true));
            Ground.Map map = ShazamFx.ground(level, c, 3.0);
            if (map != null) {
                Vfx.add(new Fx.Wave(map.center(c), UP, 3.0, 0.3, AMBER, 12, 0.7f, 0.1f, map));
                ShazamFx.dustPuffs(level, map.center(c), map.dustColor(level, c), 10, 0.7, 0.1);
            }
            ShazamFx.smokeCloud(level, c, SMOKE, 4, 0.8);
            ShazamFx.ringOfSparks(level, chest, 24, AMBER_LIGHT, 0.35);
            ShazamFx.shakeAround(c, 0.35f, 16);
            if (self) {
                ScreenFlash.flash(0.55f, 0xFFEAD0);
            }
        });
    }

    private static void knockout(AbstractClientPlayer caster, boolean self) {
        schedule(0, 1, (level, t) -> {
            Vec3 chest = caster.position().add(0, 1.2 * caster.getScale(), 0);
            Vfx.add(new Fx.Flash(chest, 1.5f, 0xFFC8B0, 6, 1f));
            ShazamFx.shakeAround(caster.position(), 0.6f, 20);
            if (self) {
                ScreenFx.vignette(0.7f, 0x3A0000, 14);
                CameraShake.add(0.45f);
            }
        });
        schedule(ShazamAnim.KNOCKOUT_BURST, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vec3 chest = c.add(0, 1.2 * caster.getScale(), 0);
            Vfx.add(new Fx.Flash(chest, 2.4f, AMBER_LIGHT, 10, 1f));
            Vfx.add(new Fx.Bubble(chest, 2.2, AMBER, 10, 0.75f, 1.0, 2.0, true));
            for (int k = 0; k < 4; k++) {   // petir membara lepas dari badan, kembali ke langit
                double a = Math.PI * 2.0 * (k + level.random.nextDouble() * 0.6) / 4.0;
                double r = 1.5 + level.random.nextDouble() * 2.0;
                Vec3 sky = c.add(Math.cos(a) * r, 7.0 + level.random.nextDouble() * 3.0, Math.sin(a) * r);
                Vfx.add(new Lightning.Arc(Lightning.Anchor.on(caster, 0, 1.2, 0), Lightning.Anchor.fixed(sky), AMBER,
                        0.07f, 5 + k, 1, 1, 0.3));
            }
            Ground.Map map = ShazamFx.ground(level, c, 3.5);
            if (map != null) {
                Vfx.add(new Fx.Wave(map.center(c), UP, 3.6, 0.35, AMBER, 14, 0.8f, 0.1f, map));
                Vfx.add(new Fx.Wave(map.center(c), UP, 2.8, 0.9, map.dustColor(level, c), 20, 0.5f, 0f, map, true));
                ShazamFx.dustPuffs(level, map.center(c), map.dustColor(level, c), 12, 0.8, 0.12);
            }
            ShazamFx.smokeCloud(level, c, SMOKE, 5, 1.0);
            ShazamFx.ringOfSparks(level, chest, 36, AMBER_LIGHT, 0.5);
            sound(level, c, SoundEvents.BEACON_DEACTIVATE, 1.2f, 0.5f);
            ShazamFx.shakeAround(c, 0.45f, 18);
            if (self) {
                ScreenFlash.flash(0.6f, 0xFFE0C0);
            }
        });
        schedule(ShazamAnim.KNOCKOUT_BURST + 1, 16, (level, t) -> {
            if (t % 2 != 0) {
                return;
            }
            Vec3 c = caster.position();
            for (int i = 0, n = Vfx.count(3); i < n; i++) {
                double a = level.random.nextDouble() * Math.PI * 2.0, r = 0.25 + level.random.nextDouble() * 0.3;
                Vfx.mote(c.x + Math.cos(a) * r, c.y + 0.3 + level.random.nextDouble() * 1.5, c.z + Math.sin(a) * r,
                        Math.cos(a) * 0.02, 0.05 + level.random.nextDouble() * 0.04, Math.sin(a) * 0.02, AMBER_LIGHT, 0.07f, 12);
            }
        });
    }

    // ------------------------------------------------------------------ S - Pusaran Shu

    private static void shu(AbstractClientPlayer caster, boolean self) {
        // napas dewa udara terkumpul: debu & angin terhisap ke badan
        schedule(0, ShazamAnim.CAST_WINDUP, (level, t) -> {
            Vec3 chest = caster.position().add(0, 1.1, 0);
            for (int i = 0, n = Vfx.count(5); i < n; i++) {
                Vec3 off = ShazamFx.randomDir(level.random).scale(2.2 + level.random.nextDouble());
                Vfx.dust(chest.x + off.x, chest.y + off.y * 0.5, chest.z + off.z, -off.x * 0.16, -off.y * 0.06, -off.z * 0.16,
                        SAND, 0.3f, 7);
            }
        });
        schedule(ShazamAnim.CAST_WINDUP, 1, (level, t) -> {
            Vfx.add(new Vortex(caster, ShazamAnim.SHU_TICKS));
            Vec3 c = caster.position();
            Ground.Map map = ShazamFx.ground(level, c, 3.5);
            Vfx.add(new Fx.Wave(c.add(0, 0.05, 0), UP, 3.4, 0.5, 0xE8F4FF, 12, 0.7f, 0.05f, map));
            Vfx.add(new Fx.Flash(c.add(0, 1.2, 0), 1.6f, 0xDDEEFF, 8, 0.7f));
            if (self) {
                ScreenFx.speedLines(0.4f);
            }
        });
        // tiap tick: pasir & angin berputar mengelilingi, makin tinggi
        schedule(ShazamAnim.CAST_WINDUP, ShazamAnim.SHU_TICKS, (level, t) -> {
            if (!ShazamClientState.isTransformed(caster.getId())) {
                return;
            }
            RandomSource r = level.random;
            Vec3 c = caster.position();
            for (int i = 0, n = Vfx.count(5); i < n; i++) {
                double a = r.nextDouble() * Math.PI * 2.0, rr = 2.4 + r.nextDouble() * 1.6;
                double tx = -Math.sin(a), tz = Math.cos(a);
                Vfx.dust(c.x + Math.cos(a) * rr, c.y + 0.1 + r.nextDouble() * 3.6, c.z + Math.sin(a) * rr,
                        tx * 0.4 - Math.cos(a) * 0.05, 0.03 + r.nextDouble() * 0.04, tz * 0.4 - Math.sin(a) * 0.05,
                        r.nextBoolean() ? SAND : 0xC4A672, 0.4f + r.nextFloat() * 0.4f, 12 + r.nextInt(8));
            }
            if (t % 2 == 0) {
                double a = r.nextDouble() * Math.PI * 2.0, rr = 1.6 + r.nextDouble() * 1.2;
                Vfx.spark(c.x + Math.cos(a) * rr, c.y + 0.4 + r.nextDouble() * 2.5, c.z + Math.sin(a) * rr,
                        -Math.sin(a) * 0.45, 0.05, Math.cos(a) * 0.45, 0xF0F8FF, 0.05f, 9, Double.NaN);
            }
        });
        // akhir: pusaran meledak ke luar
        schedule(ShazamAnim.CAST_WINDUP + ShazamAnim.SHU_TICKS, 1, (level, t) -> {
            if (!ShazamClientState.isTransformed(caster.getId())) {
                return;
            }
            Vec3 c = caster.position();
            Ground.Map map = ShazamFx.ground(level, c, 5.0);
            Vfx.add(new Fx.Flash(c.add(0, 1.2, 0), 2.6f, 0xEAF4FF, 9, 0.9f));
            Vfx.add(new Fx.Wave(c.add(0, 0.05, 0), UP, 9.5, 0.6, 0xEAF4FF, 16, 0.85f, 0.04f, map));
            Vfx.add(new Fx.Wave(c.add(0, 0.1, 0), UP, 8.0, 1.6, SAND, 30, 0.6f, 0f, map, true));
            Vfx.add(new Fx.Ripple(c.add(0, 1.0, 0), UP, 0.1, 1.5, 9.0, 0.5, 0xF4FAFF, 12, 0.6f, false));
            ShazamFx.dustPuffs(level, c, SAND, 26, 3.0, 0.35);
            ShazamFx.smokeCloud(level, c, 0xB89C6A, 8, 3.2);
            ShazamFx.shakeAround(c, 0.7f, 26);
            if (self) {
                ScreenFx.speedLines(0.8f);
                FovKick.punch(-0.06f);
            }
        });
    }

    /** Pusaran pasir Shu yang mengikuti pemain: pita pasir lembut berpilin + garis angin bercahaya. */
    static final class Vortex extends Effect {
        private final AbstractClientPlayer owner;
        private final int active;
        private float fade, fadeO;
        private boolean ending;

        Vortex(AbstractClientPlayer owner, int active) {
            super(active + 14);
            this.owner = owner;
            this.active = active;
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (!owner.isAlive() || !ShazamClientState.isTransformed(owner.getId())) {
                ending = true;
            }
            fadeO = fade;
            boolean on = !ending && age < active;
            fade = Mth.approach(fade, on ? 1f : 0f, on ? 0.2f : 0.1f);
            return super.tick(level) && !(ending && fade <= 0f);
        }

        private float strength(float pt) {
            return Mth.lerp(pt, fadeO, fade);
        }

        private void bands(Draw d, boolean soft) {
            float f = strength(d.partialTick);
            if (f <= 0.01f) {
                return;
            }
            Vec3 c = owner.getPosition(d.partialTick);
            float time = time(d.partialTick);
            int n = 26;
            float[] pts = new float[n * 3], w = new float[n], a = new float[n];
            int bands = soft ? 5 : 7;
            for (int b = 0; b < bands; b++) {
                double phase = b * Math.PI * 2.0 / bands + (soft ? 0.0 : 0.35);
                double spin = time * (soft ? 0.32 : 0.44);
                for (int i = 0; i < n; i++) {
                    double u = i / (double) (n - 1);
                    double ang = spin + phase + u * Math.PI * (soft ? 2.2 : 2.8);
                    double rad = (1.1 + 2.4 * Math.pow(u, 0.8)) * (0.6 + 0.4 * f);
                    double y = 0.05 + u * (soft ? 4.4 : 4.0);
                    pts[i * 3] = (float) (c.x + Math.cos(ang) * rad);
                    pts[i * 3 + 1] = (float) (c.y + y);
                    pts[i * 3 + 2] = (float) (c.z + Math.sin(ang) * rad);
                    float env = (float) Math.sin(Math.PI * u);
                    float near = d.nearFade(pts[i * 3], pts[i * 3 + 1], pts[i * 3 + 2], 0.8, 2.6);
                    w[i] = soft ? (float) (0.9 + 1.1 * u) : (float) (0.05 + 0.04 * u);
                    a[i] = env * f * near * (soft ? 0.34f : 0.42f);
                }
                if (soft) {
                    d.strip(pts, n, w, 1f, a, 1f, b % 2 == 0 ? SAND : 0xC9AE7A);
                } else {
                    d.strip(pts, n, w, 1f, a, 1f, 0xF6E9CC);   // angin hangat berdebu pasir
                }
            }
        }

        @Override
        public void renderSoft(Draw d) {
            bands(d, true);
        }

        @Override
        public void renderGlow(Draw d) {
            bands(d, false);
        }
    }

    // ------------------------------------------------------------------ H - Sambaran Heru

    private static void heru(AbstractClientPlayer caster, Vec3 end, boolean self) {
        Vec3 start = caster.position();
        // merunduk: cahaya emas terkumpul di bahu (pangkal sayap)
        schedule(0, ShazamAnim.HERU_WINDUP, (level, t) -> {
            Vec3 chest = caster.position().add(0, 1.2, 0);
            for (int i = 0, n = Vfx.count(4); i < n; i++) {
                Vec3 off = ShazamFx.randomDir(level.random).scale(1.4 + level.random.nextDouble() * 0.5);
                Vfx.mote(chest.x + off.x, chest.y + off.y * 0.6, chest.z + off.z, -off.x * 0.25, -off.y * 0.15, -off.z * 0.25,
                        AMBER_LIGHT, 0.08f, 5);
            }
        });
        schedule(ShazamAnim.HERU_WINDUP, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vec3 dir = end.subtract(start);
            dir = dir.lengthSqr() < 1.0E-4 ? caster.getViewVector(1f) : dir.normalize();
            Vfx.add(new FalconWings(caster, dir, ShazamAnim.HERU_TICKS + 6));
            Vfx.add(new Fx.Trail(caster, pt -> caster.getPosition(pt).add(0, 1.0, 0), AMBER, 1.1f, 9, ShazamAnim.HERU_TICKS + 2, true));
            Vfx.add(new Fx.Flash(c.add(0, 1.0, 0), 2.0f, GOLD_HOT, 7, 0.9f));
            Vfx.add(new Fx.Ripple(c.add(0, 1.0, 0), dir.scale(-1), 1.5, 0.4, 2.8, 0.4, AMBER_LIGHT, 10, 0.75f, false));
            Ground.Map map = ShazamFx.ground(level, c, 2.5);
            if (map != null && map.found && c.y - map.centerY < 1.5) {
                Vfx.add(new Fx.Wave(map.center(c), UP, 2.4, 0.8, map.dustColor(level, c), 18, 0.5f, 0f, map, true));
                ShazamFx.dustPuffs(level, map.center(c), map.dustColor(level, c), 12, 0.7, 0.18);
            }
            ShazamFx.shakeAround(c, 0.3f, 16);
            if (self) {
                ScreenFx.speedLines(1f);
                FovKick.punch(0.12f);
            }
        });
        // di lintasan: bulu cahaya & percikan berhamburan
        schedule(ShazamAnim.HERU_WINDUP, ShazamAnim.HERU_TICKS, (level, t) -> {
            Vec3 c = caster.position().add(0, 1.0, 0);
            for (int i = 0, n = Vfx.count(4); i < n; i++) {
                Vfx.mote(c.x + (level.random.nextDouble() - 0.5) * 1.2, c.y + (level.random.nextDouble() - 0.5) * 1.2,
                        c.z + (level.random.nextDouble() - 0.5) * 1.2, 0, -0.01, 0, i % 2 == 0 ? GOLD_HOT : AMBER, 0.11f,
                        18 + level.random.nextInt(8));
            }
        });
        // sampai: hempasan di titik akhir
        schedule(ShazamAnim.HERU_WINDUP + ShazamAnim.HERU_TICKS, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vfx.add(new Fx.Flash(c.add(0, 1.0, 0), 1.8f, AMBER_LIGHT, 8, 0.85f));
            Ground.Map map = ShazamFx.ground(level, c, 3.5);
            Vfx.add(new Fx.Wave(c.add(0, 0.05, 0), UP, 3.5, 0.4, AMBER, 12, 0.8f, 0.08f, map));
            if (map != null && map.found && c.y - map.centerY < 1.5) {
                ShazamFx.dustPuffs(level, map.center(c), map.dustColor(level, c), 12, 1.0, 0.16);
            }
            ShazamFx.ringOfSparks(level, c.add(0, 1.0, 0), 22, AMBER_LIGHT, 0.4);
            ShazamFx.shakeAround(c, 0.45f, 20);
        });
    }

    /** Sayap elang dari cahaya di punggung selama Sambaran Heru: bulu-bulu panjang menyapu ke belakang. */
    static final class FalconWings extends Effect {
        private final AbstractClientPlayer owner;
        private final Vec3 dir;

        FalconWings(AbstractClientPlayer owner, Vec3 dir, int life) {
            super(life);
            this.owner = owner;
            this.dir = dir;
        }

        @Override
        public void renderGlow(Draw d) {
            float p = progress(d.partialTick);
            float open = Math.min(1f, time(d.partialTick) / 2f);
            float a = (1f - p * p) * open;
            if (a <= 0.01f) {
                return;
            }
            Vec3 c = owner.getPosition(d.partialTick).add(0, 1.35 * owner.getScale(), 0);
            Vec3 f = dir;
            Vec3 right = new Vec3(-f.z, 0, f.x);
            right = right.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : right.normalize();
            Vec3 up = right.cross(f).normalize();
            if (up.y < 0) {
                up = up.scale(-1);
            }
            for (int side = -1; side <= 1; side += 2) {
                Vec3 root = c.add(right.scale(side * 0.25));
                for (int k = 0; k < 9; k++) {
                    double u = k / 8.0;
                    double spread = Math.toRadians(8 + 72 * u);
                    double len = (1.0 + 1.5 * Math.sin(Math.PI * (0.25 + 0.6 * u))) * owner.getScale();
                    Vec3 dd = f.scale(-Math.cos(spread)).add(right.scale(side * Math.sin(spread))).add(up.scale(0.25 - 0.3 * u))
                            .normalize();
                    Vec3 tip = root.add(dd.scale(len));
                    float near = d.nearFade(tip.x, tip.y, tip.z, 0.8, 2.4);
                    d.line(root.x, root.y, root.z, tip.x, tip.y, tip.z, 0.16f, 0.02f, k % 3 == 0 ? GOLD_HOT : AMBER_LIGHT,
                            0.75f * a * near, 0.1f * a * near);
                }
            }
        }
    }

    // ------------------------------------------------------------------ A - Tinju Amon

    private static void amon(AbstractClientPlayer caster, Vec3 end, boolean self) {
        Vec3 origin0 = caster.position();
        schedule(0, 1, (level, t) -> {
            for (boolean right : new boolean[] {true, false}) {
                Vfx.add(new Fx.Glow(caster, pt -> ShazamPoses.handPos(caster, right, pt), 0.7f, AMBER,
                        ShazamAnim.AMON_WINDUP + 3, ShazamAnim.AMON_WINDUP));
            }
        });
        schedule(0, ShazamAnim.AMON_WINDUP, (level, t) -> ShazamFx.swirlDust(level, caster, t));
        schedule(ShazamAnim.AMON_WINDUP, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vec3 origin = new Vec3(c.x, Math.min(c.y, origin0.y + 0.5), c.z);
            ShazamFx.impact(level, caster, origin, 1.9f, AMBER, GOLD_HOT, true);
            Vec3 flat = new Vec3(end.x - origin.x, 0, end.z - origin.z);
            double range = flat.length();
            if (range > 0.5) {
                Vfx.add(new Fissure(level, caster, origin, flat.scale(1.0 / range), range, ShazamAnim.AMON_SPREAD, 80));
            }
            ShazamFx.shakeAround(c, 1.0f, 30);
            if (self) {
                ScreenFlash.flash(0.35f, 0xFFD8A0);
                ScreenFx.vignette(0.45f, 0x2A1000, 6);
            }
        });
        // tanah terbelah merambat: tiap tick batu & debu menyembur di ujungnya
        schedule(ShazamAnim.AMON_WINDUP + 1, ShazamAnim.AMON_SPREAD, (level, t) -> {
            Vec3 o = origin0;
            Vec3 flat = new Vec3(end.x - o.x, 0, end.z - o.z);
            double range = flat.length();
            if (range < 0.5) {
                return;
            }
            Vec3 dir = flat.scale(1.0 / range);
            Vec3 front = o.add(dir.scale(range * (t + 1) / ShazamAnim.AMON_SPREAD));
            Ground.Map map = ShazamFx.ground(level, front.add(0, 1.0, 0), 2.0);
            if (map == null || !map.found) {
                return;
            }
            Vec3 g = map.center(front);
            Vfx.add(new Ground.Cracks(g, map, 5, 1.1f, 120, 40, AMBER_LIGHT, level.random.nextLong()));
            Vfx.add(new Ground.Debris(g, map, Vfx.count(5), 0.1, 0.55, 0.6, 45));
            Vfx.add(new Fx.Flash(g.add(0, 0.4, 0), 1.3f, AMBER, 6, 0.8f));
            Vfx.add(new Fx.Scorch(g, 0.7, 120, 30, map));
            ShazamFx.dustPuffs(level, g, map.dustColor(level, g), 8, 0.6, 0.12);
            for (int i = 0, n = Vfx.count(4); i < n; i++) {
                Vfx.ember(g.x + (level.random.nextDouble() - 0.5), g.y + 0.1, g.z + (level.random.nextDouble() - 0.5), 0,
                        0.06 + level.random.nextDouble() * 0.06, 0, 0.09f, 18 + level.random.nextInt(10));
            }
            ShazamFx.shakeAround(g, 0.35f, 18);
        });
    }

    /** Celah membara Amon: garis berkelok di tanah dari titik hantaman, merambat sampai ujung lalu mendingin. */
    static final class Fissure extends Effect {
        private final float[] pts;
        private final int n;
        private final int spread;
        private final double nx, nz;

        Fissure(ClientLevel level, Entity viewer, Vec3 origin, Vec3 dir, double range, int spread, int life) {
            super(life);
            this.spread = spread;
            this.n = Math.max(4, (int) (range * 2.0));
            this.pts = new float[n * 3];
            this.nx = -dir.z;
            this.nz = dir.x;
            Random r = new Random(Double.doubleToLongBits(origin.x * 31 + origin.z));
            double side = 0;
            double lastY = origin.y;
            for (int i = 0; i < n; i++) {
                double u = i / (double) (n - 1);
                side = Mth.clamp(side + (r.nextDouble() - 0.5) * 0.35, -0.45, 0.45);
                double x = origin.x + dir.x * range * u + nx * side * Math.min(1.0, u * 6);
                double z = origin.z + dir.z * range * u + nz * side * Math.min(1.0, u * 6);
                BlockHitResult hit = level.clip(new ClipContext(new Vec3(x, lastY + 2.0, z), new Vec3(x, lastY - 3.0, z),
                        ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, viewer));
                double y = hit.getType() == HitResult.Type.MISS ? lastY : hit.getLocation().y;
                lastY = y;
                pts[i * 3] = (float) x;
                pts[i * 3 + 1] = (float) (y + 0.035);
                pts[i * 3 + 2] = (float) z;
            }
        }

        private int shown(float pt) {
            float k = Math.min(1f, time(pt) / spread);
            return Math.max(2, Math.min(n, (int) Math.ceil(k * (n - 1)) + 1));
        }

        @Override
        public void renderSoft(Draw d) {
            float f = 1f - progress(d.partialTick);
            int m = shown(d.partialTick);
            for (int i = 0; i + 1 < m; i++) {   // bekas hangus gelap di kiri-kanan celah
                int o = i * 3;
                d.flatLine(pts[o], pts[o + 1], pts[o + 2], pts[o + 3], pts[o + 4], pts[o + 5], 0, 1, 0, 0.9f, 0x1A120C,
                        0.55f * Math.min(1f, f * 2f), 0.55f * Math.min(1f, f * 2f));
            }
        }

        @Override
        public void renderGlow(Draw d) {
            float p = progress(d.partialTick);
            float heat = (float) Math.pow(1f - p, 1.3);
            int m = shown(d.partialTick);
            float pulse = 0.85f + 0.15f * (float) Math.sin(time(d.partialTick) * 0.7f);
            for (int i = 0; i + 1 < m; i++) {
                int o = i * 3;
                float edge = i == m - 2 ? 1.6f : 1f;   // ujung yang sedang merambat paling terang
                d.flatLine(pts[o], pts[o + 1], pts[o + 2], pts[o + 3], pts[o + 4], pts[o + 5], 0, 1, 0, 0.42f, AMBER,
                        0.8f * heat * pulse * edge, 0.8f * heat * pulse * edge);
                d.flatLine(pts[o], pts[o + 1] + 0.005f, pts[o + 2], pts[o + 3], pts[o + 4] + 0.005f, pts[o + 5], 0, 1, 0, 0.12f,
                        GOLD_HOT, heat * edge, heat * edge);
            }
            int tip = (m - 1) * 3;
            d.glow(pts[tip], pts[tip + 1] + 0.3, pts[tip + 2], 1.2f, AMBER, 0.5f * heat);
        }
    }

    // ------------------------------------------------------------------ Z - Segel Zehuti

    private static void zehuti(AbstractClientPlayer caster, boolean self) {
        SIGHT.put(caster.getId(), caster.level().getGameTime());
        // huruf-huruf cahaya pirus terhisap ke kepala
        schedule(0, ShazamAnim.CAST_WINDUP, (level, t) -> {
            Vec3 head = caster.getEyePosition();
            for (int i = 0, n = Vfx.count(3); i < n; i++) {
                Vec3 off = ShazamFx.randomDir(level.random).scale(1.4 + level.random.nextDouble() * 0.6);
                Vfx.mote(head.x + off.x, head.y + off.y, head.z + off.z, -off.x * 0.18, -off.y * 0.18, -off.z * 0.18,
                        TURQUOISE, 0.07f, 6);
            }
        });
        // jari menunjuk: gelombang hieroglif menyebar ke depan
        schedule(ShazamAnim.CAST_WINDUP, 1, (level, t) -> {
            Vec3 look = caster.getViewVector(1f);
            Vec3 hand = ShazamPoses.handPos(caster, true, 1f);
            Vfx.add(new Runes.Circle(Lightning.Anchor.fixed(hand.add(look.scale(0.4))), look, 0.7, TURQUOISE, 14, 0.08f, 1f, null));
            Vfx.add(new Fx.Ripple(hand, look, 9.0, 0.4, 5.0, 0.3, TURQUOISE, 14, 0.7f, false));
            Vfx.add(new Fx.Flash(hand, 1.2f, 0xC8FFF0, 7, 0.9f));
            if (self) {
                ScreenFx.vignette(0.35f, 0x002A24, 10);
            }
        });
    }

    /** Segel hieroglif di satu musuh: dua cincin huruf berputar berlawanan + rantai cahaya, plus tali cahaya dari jari. */
    private static void seal(AbstractClientPlayer caster, Vec3 pos) {
        ClientLevel level = (ClientLevel) caster.level();
        LivingEntity target = nearest(level, pos, 1.6);
        Lightning.Anchor hand = pt -> ShazamPoses.handPos(caster, true, pt);
        if (target != null) {
            Vfx.add(new Seal(target, 160));
            Vfx.add(new Tether(hand, pt -> target.getPosition(pt).add(0, target.getBbHeight() * 0.55, 0), TURQUOISE, 0.12f, 8));
        } else {
            Vfx.add(new Tether(hand, Lightning.Anchor.fixed(pos.add(0, 0.8, 0)), TURQUOISE, 0.12f, 8));
        }
        Vec3 c = pos.add(0, 0.9, 0);
        Vfx.add(new Fx.Flash(c, 1.3f, 0xC8FFF0, 8, 0.8f));
        for (int i = 0, n = Vfx.count(8); i < n; i++) {
            Vec3 v = ShazamFx.randomDir(level.random).scale(0.15);
            Vfx.glint(c.x + v.x * 4, c.y + v.y * 4, c.z + v.z * 4, i % 2 == 0 ? TURQUOISE : GOLD_HOT, 0.22f, 10);
        }
    }

    private static LivingEntity nearest(ClientLevel level, Vec3 pos, double radius) {
        List<LivingEntity> list = level.getEntitiesOfClass(LivingEntity.class, new AABB(pos, pos).inflate(radius),
                e -> e.isAlive() && !(e instanceof AbstractClientPlayer));
        LivingEntity best = null;
        double bestD = Double.MAX_VALUE;
        for (LivingEntity e : list) {
            double dd = e.position().distanceToSqr(pos);
            if (dd < bestD) {
                bestD = dd;
                best = e;
            }
        }
        return best;
    }

    /** Dua cincin hieroglif berputar mengikat badan musuh, dengan rantai cahaya di antaranya. */
    static final class Seal extends Effect {
        private final LivingEntity target;

        Seal(LivingEntity target, int life) {
            super(life);
            this.target = target;
        }

        @Override
        public boolean tick(ClientLevel level) {
            return target.isAlive() && super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            float in = Math.min(1f, time / 4f);
            float out = Math.min(1f, (life - time) / 12f);
            float a = Math.max(0f, Math.min(in, out));
            if (a <= 0.01f) {
                return;
            }
            Vec3 p = target.getPosition(d.partialTick);
            double h = target.getBbHeight(), w = Math.max(0.6, target.getBbWidth() * 0.9 + 0.35);
            double[] heights = {h * 0.22, h * 0.72};
            for (int k = 0; k < 2; k++) {
                double y = p.y + heights[k];
                double spin = (k == 0 ? 1 : -1) * time * 0.06;
                double rr = w * (1.0 + 0.25 * (1f - in));
                d.ring(p.x, y, p.z, 0, 1, 0, rr, 0.05, TURQUOISE, 0.7f * a, 0f, null);
                d.ring(p.x, y, p.z, 0, 1, 0, rr * 1.18, 0.02, GOLD_HOT, 0.45f * a, 0f, null);
                int count = 10;
                for (int i = 0; i < count; i++) {
                    double ang = spin + Math.PI * 2.0 * i / count;
                    double gx = p.x + Math.cos(ang) * rr * 1.09, gz = p.z + Math.sin(ang) * rr * 1.09;
                    double ux = -Math.sin(ang), uz = Math.cos(ang);
                    double[] gl = EgyptLook.GLYPHS[(i + k * 3) % EgyptLook.GLYPHS.length];
                    double size = 0.09;
                    for (int s = 0; s + 3 < gl.length; s += 4) {
                        d.line(gx + ux * gl[s] * size, y + gl[s + 1] * size, gz + uz * gl[s] * size,
                                gx + ux * gl[s + 2] * size, y + gl[s + 3] * size, gz + uz * gl[s + 2] * size,
                                0.035f, 0.035f, 0xD8FFF4, 0.85f * a, 0.85f * a);
                    }
                }
            }
            // rantai cahaya di antara kedua cincin
            for (int i = 0; i < 4; i++) {
                double ang = time * 0.02 + Math.PI * 0.5 * i;
                double x = p.x + Math.cos(ang) * w, z = p.z + Math.sin(ang) * w;
                d.line(x, p.y + heights[0], z, x, p.y + heights[1], z, 0.05f, 0.05f, TURQUOISE, 0.35f * a, 0.35f * a);
            }
            d.glow(p.x, p.y + h * 0.5, p.z, (float) (w * 1.4), TURQUOISE, 0.12f * a);
        }
    }

    /** Tali/berkas cahaya singkat dari a ke b yang menipis. */
    static final class Tether extends Effect {
        private final Lightning.Anchor from, to;
        private final int rgb;
        private final float width;

        Tether(Lightning.Anchor from, Lightning.Anchor to, int rgb, float width, int life) {
            super(life);
            this.from = from;
            this.to = to;
            this.rgb = rgb;
            this.width = width;
        }

        @Override
        public void renderGlow(Draw d) {
            float p = progress(d.partialTick);
            float a = (1f - p) * (1f - p);
            Vec3 x = from.at(d.partialTick), y = to.at(d.partialTick);
            d.beam(x.x, x.y, x.z, y.x, y.y, y.z, width * (1f - 0.5f * p), rgb, 0xFFFFFF, a * 0.8f, a);
        }
    }

    // ------------------------------------------------------------------ A - Sinar Aton

    private static void aton(AbstractClientPlayer caster, boolean self) {
        SunDisk disk = new SunDisk(caster, ShazamAnim.ATON_WINDUP + ShazamAnim.ATON_GAP * 6 + 12);
        SUNS.put(caster.getId(), disk);
        Vfx.add(disk);
        // cahaya matahari terhisap ke telapak
        schedule(0, ShazamAnim.ATON_WINDUP, (level, t) -> {
            Vec3 c = disk.center(1f);
            for (int i = 0, n = Vfx.count(4); i < n; i++) {
                Vec3 off = ShazamFx.randomDir(level.random).scale(1.8 + level.random.nextDouble());
                Vfx.mote(c.x + off.x, c.y + off.y, c.z + off.z, -off.x * 0.2, -off.y * 0.2, -off.z * 0.2, SUN, 0.09f, 5);
            }
            if (self && t == ShazamAnim.ATON_WINDUP - 1) {
                ScreenFlash.flash(0.2f, 0xFFF0C8);
            }
        });
    }

    /** Satu sinar Aton dari cakram ke sasaran: berkas emas-putih berujung tangan terbuka, lalu ledakan kecil. */
    private static void ray(AbstractClientPlayer caster, Vec3 target) {
        SunDisk disk = SUNS.get(caster.getId());
        Lightning.Anchor from = disk != null && !disk.done ? disk::center
                : pt -> ShazamPoses.handPos(caster, true, pt).add(0, 0.9, 0);
        Vfx.add(new SunRay(from, target, 8));
        ClientLevel level = (ClientLevel) caster.level();
        Vfx.add(new Fx.Flash(target, 1.8f, 0xFFF2C8, 8, 1f));
        Vfx.add(new Fx.Bubble(target, 1.0, SUN, 7, 0.7f, 1.0, 2.0, true));
        ShazamFx.ringOfSparks(level, target, 18, SUN, 0.35);
        for (int i = 0, n = Vfx.count(5); i < n; i++) {
            Vfx.ember(target.x + (level.random.nextDouble() - 0.5) * 0.6, target.y + (level.random.nextDouble() - 0.5) * 0.6,
                    target.z + (level.random.nextDouble() - 0.5) * 0.6, 0, 0.04, 0, 0.08f, 16 + level.random.nextInt(8));
        }
        ShazamFx.shakeAround(target, 0.25f, 14);
    }

    /** Cakram matahari di atas telapak kanan: terbit memantul, korona berputar, lalu meredup. */
    static final class SunDisk extends Effect {
        private final AbstractClientPlayer owner;
        boolean done;

        SunDisk(AbstractClientPlayer owner, int life) {
            super(life);
            this.owner = owner;
        }

        @Override
        public boolean tick(ClientLevel level) {
            boolean alive = owner.isAlive() && ShazamClientState.isTransformed(owner.getId()) && super.tick(level);
            done = !alive;
            return alive;
        }

        Vec3 center(float pt) {
            return ShazamPoses.handPos(owner, true, pt).add(0, 0.85 * owner.getScale(), 0);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            float grow = time < ShazamAnim.ATON_WINDUP ? (float) GodFigures.outBack(time / ShazamAnim.ATON_WINDUP) : 1f;
            float fade = Math.min(1f, (life - time) / 6f);
            float k = Math.max(0f, grow) * Math.max(0f, fade);
            if (k <= 0.01f) {
                return;
            }
            Vec3 c = center(d.partialTick);
            double tx = d.camX - c.x, ty = d.camY - c.y, tz = d.camZ - c.z;
            double tl = Math.sqrt(tx * tx + ty * ty + tz * tz) + 1.0E-9;
            tx /= tl; ty /= tl; tz /= tl;
            float near = d.nearFade(c.x, c.y, c.z, 0.7, 2.0);
            float r = 0.55f * k;
            d.disc(c.x, c.y, c.z, tx, ty, tz, r, SUN, 0.95f * near, 0.55f * near, null);
            d.ring(c.x, c.y, c.z, tx, ty, tz, r * 1.04, r * 0.12, 0xFFB838, 0.9f * near, 0f, null);
            d.flare(c.x, c.y, c.z, r * 1.6f, GOLD_HOT, 0.7f * near);
            d.glow(c.x, c.y, c.z, r * 4f, SUN, 0.25f * near);
            // korona: sinar-sinar pendek berputar
            double[] e = new double[6];
            Draw.plane(tx, ty, tz, e);
            int rays = 20;
            for (int i = 0; i < rays; i++) {
                double a = time * 0.05 + Math.PI * 2.0 * i / rays;
                double cs = Math.cos(a), sn = Math.sin(a);
                double dx = e[0] * cs + e[3] * sn, dy = e[1] * cs + e[4] * sn, dz = e[2] * cs + e[5] * sn;
                double r0 = r * 1.1, r1 = r * (i % 2 == 0 ? 1.9 : 1.5);
                d.line(c.x + dx * r0, c.y + dy * r0, c.z + dz * r0, c.x + dx * r1, c.y + dy * r1, c.z + dz * r1,
                        0.07f * k, 0.01f, 0xFFE7A0, 0.7f * near, 0f);
            }
        }
    }

    /** Berkas sinar Aton (lurus, tebal, inti putih) dengan tangan terbuka di ujungnya. */
    static final class SunRay extends Effect {
        private final Lightning.Anchor from;
        private final Vec3 to;

        SunRay(Lightning.Anchor from, Vec3 to, int life) {
            super(life);
            this.from = from;
            this.to = to;
        }

        @Override
        public void renderGlow(Draw d) {
            float p = progress(d.partialTick);
            float a = p < 0.15f ? p / 0.15f : (float) Math.pow(1f - (p - 0.15f) / 0.85f, 1.5);
            if (a <= 0.01f) {
                return;
            }
            Vec3 s = from.at(d.partialTick);
            d.beam(s.x, s.y, s.z, to.x, to.y, to.z, 0.42f * (0.6f + 0.4f * a), SUN, 0xFFFFFF, a * 0.9f, a);
            // tangan terbuka di ujung sinar (lambang Aton): empat jari + ibu jari
            Vec3 dir = to.subtract(s);
            double len = dir.length();
            if (len < 0.3) {
                return;
            }
            dir = dir.scale(1.0 / len);
            Vec3 side = dir.cross(UP);
            side = side.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : side.normalize();
            Vec3 palm = to.subtract(dir.scale(0.25));
            for (int f = -2; f <= 2; f++) {
                Vec3 base = palm.add(side.scale(f * 0.06));
                Vec3 tip = base.add(dir.scale(f == -2 ? 0.14 : 0.24)).add(side.scale(f == -2 ? -0.1 : f * 0.02));
                d.line(base.x, base.y, base.z, tip.x, tip.y, tip.z, 0.06f, 0.035f, 0xFFF4D0, a, a * 0.7f);
            }
            d.glow(palm.x, palm.y, palm.z, 0.3f, SUN, 0.6f * a);
        }
    }

    // ------------------------------------------------------------------ M - Lilitan Mehen

    private static void mehen(AbstractClientPlayer caster, boolean self) {
        // ular muncul dari bayangan: asap hitam & pasir dari tanah, lalu membelit
        schedule(0, ShazamAnim.MEHEN_WINDUP, (level, t) -> {
            RandomSource r = level.random;
            Vec3 c = caster.position();
            for (int i = 0, n = Vfx.count(3); i < n; i++) {
                double a = r.nextDouble() * Math.PI * 2.0, d = 0.8 + r.nextDouble() * 0.8;
                Vfx.smoke(c.x + Math.cos(a) * d, c.y + 0.1, c.z + Math.sin(a) * d, -Math.sin(a) * 0.05, 0.04,
                        Math.cos(a) * 0.05, SMOKE, 0.4f, 20);
                Vfx.dust(c.x + Math.cos(a) * d, c.y + 0.1, c.z + Math.sin(a) * d, -Math.sin(a) * 0.1, 0.03,
                        Math.cos(a) * 0.1, SAND, 0.35f, 14);
            }
        });
        schedule(ShazamAnim.MEHEN_WINDUP, 1, (level, t) -> {
            Serpent old = SERPENTS.get(caster.getId());
            if (old != null) {
                old.done = true;
            }
            Serpent serpent = new Serpent(caster, ShazamAnim.MEHEN_TICKS);
            SERPENTS.put(caster.getId(), serpent);
            Vfx.add(serpent);
            Vec3 c = caster.position();
            Vfx.add(new Fx.Flash(c.add(0, 1.2, 0), 2.2f, SERPENT, 9, 0.8f));
            Ground.Map map = ShazamFx.ground(level, c, 3.0);
            Vfx.add(new Fx.Wave(c.add(0, 0.05, 0), UP, 2.8, 0.4, SERPENT_RED, 14, 0.8f, 0.1f, map));
            ShazamFx.ringOfSparks(level, c.add(0, 1.0, 0), 20, SERPENT, 0.35);
            if (self) {
                ScreenFx.vignette(0.3f, 0x2A0A00, 8);
            }
        });
    }

    private static void bite(AbstractClientPlayer caster, Vec3 target) {
        Serpent serpent = SERPENTS.get(caster.getId());
        if (serpent != null && !serpent.done) {
            serpent.strike(target);
        }
        schedule(2, 1, (level, t) -> {
            Vfx.add(new Fx.Flash(target, 1.4f, SERPENT, 6, 0.9f));
            ShazamFx.ringOfSparks(level, target, 12, SERPENT_RED, 0.3);
            for (int i = 0, n = Vfx.count(4); i < n; i++) {   // tetes bisa
                Vfx.mote(target.x + (level.random.nextDouble() - 0.5) * 0.5, target.y, target.z + (level.random.nextDouble() - 0.5) * 0.5,
                        0, -0.03, 0, 0x9CFF7A, 0.07f, 16);
            }
            ShazamFx.shakeAround(target, 0.2f, 12);
        });
    }

    /**
     * Ular Mehen dari cahaya yang membelit badan pemain: gulungan berpilin dari kaki ke bahu (bergelang emas-merah),
     * leher naik di belakang bahu kanan, kepala kobra bertudung dengan mata merah, dan bisa mematuk sasaran.
     */
    static final class Serpent extends Effect {
        private static final int COIL = 40, NECK = 12;
        private final AbstractClientPlayer owner;
        private final int active;
        private float fade, fadeO;
        private boolean ending;
        boolean done;
        private Vec3 strikeAt;
        private float strikeTime = -100f;

        Serpent(AbstractClientPlayer owner, int active) {
            super(active + 14);
            this.owner = owner;
            this.active = active;
        }

        void strike(Vec3 target) {
            strikeAt = target;
            strikeTime = age;
        }

        float strength(float pt) {
            return Mth.lerp(pt, fadeO, fade);
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (!owner.isAlive() || !ShazamClientState.isTransformed(owner.getId())) {
                ending = true;
            }
            fadeO = fade;
            boolean on = !ending && !done && age < active;
            fade = Mth.approach(fade, on ? 1f : 0f, on ? 0.12f : 0.1f);
            boolean alive = super.tick(level) && !((ending || done) && fade <= 0f);
            if (!alive) {
                done = true;
            }
            if (alive && fade > 0.5f && age % 7 == 0) {   // sisik berkilat
                Vec3 c = owner.position();
                double a = level.random.nextDouble() * Math.PI * 2, y = 0.2 + level.random.nextDouble() * 1.7;
                Vfx.glint(c.x + Math.cos(a) * 0.85, c.y + y, c.z + Math.sin(a) * 0.85, GOLD_HOT, 0.18f, 8);
            }
            return alive;
        }

        @Override
        public void renderGlow(Draw d) {
            float f = strength(d.partialTick);
            if (f <= 0.01f) {
                return;
            }
            float pt = d.partialTick;
            float time = time(pt);
            float sc = owner.getScale();
            Vec3 base = owner.getPosition(pt);
            float yaw = Mth.rotLerp(pt, owner.yBodyRotO, owner.yBodyRot) * Mth.DEG_TO_RAD;
            double fx = -Math.sin(yaw), fz = Math.cos(yaw);      // depan badan
            double rx = -fz, rz = fx;                           // kanan badan
            int n = COIL + NECK;
            float[] pts = new float[n * 3], w = new float[n], a = new float[n];
            // gulungan berpilin naik dari kaki ke bahu, berputar pelan; muncul dari bawah saat mulai
            double rise = Math.min(1.0, f * 1.2);
            for (int i = 0; i < COIL; i++) {
                double u = i / (double) (COIL - 1);
                double ang = -time * 0.045 + u * Math.PI * 2.0 * 2.6;
                double rad = (0.95 - 0.28 * u) * sc;
                double y = (0.12 + 1.62 * u * rise) * sc;
                pts[i * 3] = (float) (base.x + Math.cos(ang) * rad);
                pts[i * 3 + 1] = (float) (base.y + y);
                pts[i * 3 + 2] = (float) (base.z + Math.sin(ang) * rad);
                w[i] = (float) ((0.1 + 0.34 * Math.pow(u, 0.6)) * sc);
            }
            // kepala: melayang di atas bahu kanan, bergoyang; mematuk sasaran lalu kembali
            double sway = Math.sin(time * 0.09) * 0.12, bob = Math.sin(time * 0.13) * 0.06;
            Vec3 idle = base.add(rx * (0.55 + sway) * sc + fx * 0.45 * sc, (2.45 + bob) * sc * rise, rz * (0.55 + sway) * sc
                    + fz * 0.45 * sc);
            Vec3 head = idle;
            double lunge = 0.0;
            float since = time - strikeTime;
            if (strikeAt != null && since >= 0f && since < 8f) {
                lunge = since < 2.5f ? GodFigures.outCubic(since / 2.5f) : 1.0 - GodFigures.smooth((since - 2.5f) / 5.5f);
                Vec3 aim = strikeAt.subtract(idle);
                double reach = Math.min(aim.length(), 6.0);
                head = idle.add(aim.normalize().scale(reach * lunge));
            }
            // leher: dari ujung gulungan naik melengkung (Bezier) ke kepala
            int last = (COIL - 1) * 3;
            double ex = pts[last], ey = pts[last + 1], ez = pts[last + 2];
            double cx = ex + rx * 0.25 * sc - fx * 0.35 * sc, cy = ey + 0.9 * sc, cz = ez + rz * 0.25 * sc - fz * 0.35 * sc;
            for (int k = 0; k < NECK; k++) {
                double u = (k + 1) / (double) NECK, v = 1 - u;
                int i = COIL + k;
                pts[i * 3] = (float) (v * v * ex + 2 * v * u * cx + u * u * head.x);
                pts[i * 3 + 1] = (float) (v * v * ey + 2 * v * u * cy + u * u * head.y);
                pts[i * 3 + 2] = (float) (v * v * ez + 2 * v * u * cz + u * u * head.z);
                w[i] = (float) ((0.42 - 0.12 * u) * sc);
            }
            for (int i = 0; i < n; i++) {
                a[i] = f * d.nearFade(pts[i * 3], pts[i * 3 + 1], pts[i * 3 + 2], 0.7, 1.9);
            }
            d.polyline(pts, n, w, a, SERPENT, GOLD_HOT);
            // gelang merah berselang di sepanjang badan
            float[] seg = new float[3 * 3], sw = new float[3], sa = new float[3];
            for (int s = 2; s + 2 < n; s += 4) {
                for (int j = 0; j < 3; j++) {
                    int src = s + j - 1;
                    seg[j * 3] = pts[src * 3];
                    seg[j * 3 + 1] = pts[src * 3 + 1];
                    seg[j * 3 + 2] = pts[src * 3 + 2];
                    sw[j] = w[src] * 1.05f;
                    sa[j] = a[src] * 0.85f;
                }
                d.strip(seg, 3, sw, 0.85f, sa, 1f, SERPENT_RED);
            }
            // sisik: titik-titik terang di sepanjang punggung ular
            for (int i = 1; i < n; i += 3) {
                d.glow(pts[i * 3], pts[i * 3 + 1] + w[i] * 0.2f, pts[i * 3 + 2], w[i] * 0.22f, GOLD_HOT, 0.55f * a[i]);
            }
            // kepala kobra: tudung (kipas cahaya), kepala, mata merah, taring saat mematuk
            int hk = (n - 1) * 3, nk = (n - 3) * 3;
            Vec3 tip = new Vec3(pts[hk], pts[hk + 1], pts[hk + 2]);
            Vec3 neck = new Vec3(pts[nk], pts[nk + 1], pts[nk + 2]);
            Vec3 along = tip.subtract(neck);
            along = along.lengthSqr() < 1.0E-6 ? UP : along.normalize();
            Vec3 face = lunge > 0.05 && strikeAt != null ? strikeAt.subtract(tip).normalize()
                    : new Vec3(fx, -0.35, fz).normalize();
            Vec3 side = along.cross(face);
            side = side.lengthSqr() < 1.0E-6 ? new Vec3(rx, 0, rz) : side.normalize();
            float near = d.nearFade(tip.x, tip.y, tip.z, 0.7, 1.9);
            float hood = (float) (0.5 + 0.5 * Math.min(1.0, f * 1.4));
            for (int k = -4; k <= 4; k++) {
                double spread = k * 0.17;
                Vec3 dir = along.scale(Math.cos(spread)).add(side.scale(Math.sin(spread) * 1.6)).normalize();
                Vec3 end = neck.add(dir.scale((0.52 - Math.abs(k) * 0.03) * sc * hood));
                d.line(neck.x, neck.y, neck.z, end.x, end.y, end.z, 0.24f * sc, 0.1f * sc, Math.abs(k) % 2 == 0 ? SERPENT_RED : SERPENT,
                        0.85f * f * near, 0.35f * f * near);
            }
            Vec3 snout = tip.add(face.scale(0.26 * sc));
            d.line(tip.x, tip.y, tip.z, snout.x, snout.y, snout.z, 0.32f * sc, 0.14f * sc, SERPENT, f * near, f * near);
            d.line(tip.x, tip.y, tip.z, snout.x, snout.y, snout.z, 0.12f * sc, 0.05f * sc, GOLD_HOT, f * near, f * near);
            d.glow(tip.x, tip.y, tip.z, 0.45f * sc, SERPENT, 0.35f * f * near);
            for (int s = -1; s <= 1; s += 2) {
                Vec3 eye = tip.add(face.scale(0.1 * sc)).add(side.scale(s * 0.08 * sc)).add(along.scale(0.04 * sc));
                d.glow(eye.x, eye.y, eye.z, 0.07f * sc, 0xFF3A20, 0.95f * f * near);
                d.glow(eye.x, eye.y, eye.z, 0.025f * sc, 0xFFFFFF, f * near);
            }
            if (lunge > 0.2) {
                for (int s = -1; s <= 1; s += 2) {
                    Vec3 fang = snout.add(side.scale(s * 0.05 * sc));
                    Vec3 fangTip = fang.add(face.scale(0.06 * sc)).add(along.scale(-0.08 * sc));
                    d.line(fang.x, fang.y, fang.z, fangTip.x, fangTip.y, fangTip.z, 0.03f, 0.005f, 0xFFFFFF,
                            (float) lunge * f, (float) lunge * f);
                }
            }
        }
    }

    // ------------------------------------------------------------------ Murka Kahndaq

    private static void rage(AbstractClientPlayer caster, boolean self) {
        // petir membara dari segala arah terhisap ke badan, asap hitam naik dari tanah
        schedule(0, ShazamAnim.ADAM_RAGE_WINDUP, (level, t) -> {
            for (int i = 0; i < 2; i++) {
                Vec3 off = ShazamFx.randomDir(level.random).scale(2.6 + level.random.nextDouble() * 1.2);
                Vec3 from = caster.position().add(off.x, 1.1 + Math.abs(off.y) * 0.5, off.z);
                Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(from), Lightning.Anchor.on(caster, 0, 1.1, 0), AMBER,
                        0.065f, 2, 1, 1, 0.27));
            }
            if (t % 2 == 0) {
                double a = level.random.nextDouble() * Math.PI * 2.0, d = 1.0 + level.random.nextDouble();
                Vfx.smoke(caster.getX() + Math.cos(a) * d, caster.getY() + 0.1, caster.getZ() + Math.sin(a) * d,
                        0, 0.05, 0, SMOKE, 0.5f, 26);
            }
            ShazamFx.swirlDust(level, caster, t);
            if (self) {
                ScreenFx.vignette(0.32f + t * 0.03f, 0x2A0800, 3);
                CameraShake.add(0.035f);
            }
        });
        schedule(ShazamAnim.ADAM_RAGE_WINDUP, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vfx.add(new Fx.Flash(c.add(0, 1.3, 0), 3.2f, 0xFFE8C8, 10, 1f));
            ShazamFx.impact(level, caster, c, 2.2f, AMBER, GOLD_HOT, true);
            Ground.Map map = ShazamFx.ground(level, c, 4.0);
            if (map != null) {
                Vfx.add(new Fx.Wave(map.center(c), UP, 5.0, 1.4, SMOKE, 28, 0.6f, 0f, map, true));
            }
            ShazamFx.ringOfSparks(level, c.add(0, 1.2, 0), 44, AMBER_LIGHT, 0.5);
            ShazamFx.groundArcs(level, c, 7, 4.5, AMBER, 7);
            if (self) {
                ScreenFlash.flash(0.55f, 0xFFE2C0);
                ScreenFx.speedLines(0.5f);
                CameraShake.add(0.4f);
            }
        });
    }
}
