package com.shazammod;

import java.util.List;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/**
 * Server -> client: data buat HUD (energi, status, sisa cooldown tiap skill juara yang dipilih dalam tick, lalu di
 * urutan paling belakang sisa waktu pulih sesudah terlempar balik jadi manusia karena serangan mematikan) dan juara
 * yang dipilih (ShazamForm).
 */
public record ShazamSyncPayload(boolean unlocked, boolean transformed, boolean storm, float energy,
                                List<Integer> cooldowns, int form) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<ShazamSyncPayload> TYPE =
            new CustomPacketPayload.Type<>(ShazamMod.id("sync"));

    public static final StreamCodec<ByteBuf, ShazamSyncPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.BOOL, ShazamSyncPayload::unlocked,
            ByteBufCodecs.BOOL, ShazamSyncPayload::transformed,
            ByteBufCodecs.BOOL, ShazamSyncPayload::storm,
            ByteBufCodecs.FLOAT, ShazamSyncPayload::energy,
            ByteBufCodecs.VAR_INT.apply(ByteBufCodecs.list()), ShazamSyncPayload::cooldowns,
            ByteBufCodecs.VAR_INT, ShazamSyncPayload::form,
            ShazamSyncPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
