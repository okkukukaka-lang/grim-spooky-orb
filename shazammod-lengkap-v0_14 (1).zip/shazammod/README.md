# Mod Shazam untuk Minecraft 1.21.1 (NeoForge)

Versi 0.14.0. Isinya:
- Transformasi SHAZAM beranimasi, enam kekuatan S-H-A-Z-A-M, dan Energi Petir.
- Enam skill (plus Zeus Rage) yang masing-masing punya gerakan sendiri (ancang-ancang, gemetar mengumpulkan tenaga, gerakan utama yang menghentak) dan efek visual buatan sendiri, bukan partikel Minecraft.
- Terbang berbasis momentum dengan fisika dunia nyata (hambatan udara, belokan menikung, gravitasi saat menukik) ala Create: Lanterns: sonic boom, barrel roll, hero landing, dan kamera menikung.
- Kekuatan seperti di komik: darah 100, tahan banting, pukulan 20, dan Energi Petir 1000.
- Jubah 3D dengan fisika kain dunia nyata yang utuh jadi satu pakaian: hood yang pas dengan kepala kotak Minecraft, mantel bahu dengan pelat emas, bros pengait dan rantai, dan jubah panjang. Plus lambang 3D yang berkilau saat berubah (skin tetap skin aslimu), dan kostum armor 4 bagian yang bisa di-craft.

## Yang baru di 0.14: fisika kain ditulis ulang

Jubah, mantel, dan hood sekarang memakai mesin kain baru yang cara kerjanya sama dengan cloth di engine game sungguhan. Ini memperbaiki bug hood yang terbuka di belakang (belakang kepala kelihatan, "sayap" di samping, ujung runcing ke atas), mantel yang melorot dari bahu, dan kain yang nyangkut atau molor.

- **Penyebab bug lama:** tabrakan "dorong ke sisi terdekat" mendorong kain yang sudah masuk agak dalam ke kepala atau lengan keluar lewat sisi yang salah, lalu gaya "kembali ke bentuk" menariknya lurus menembus kepala, jadi kainnya nyangkut di posisi salah. Fisikanya juga dihitung di ruang dunia dengan pose kepala dan lengan yang cuma di-update sekali per frame, jadi tiap menoleh cepat kain tertinggal jauh.
- **Fisika di ruang badan + gaya semu yang benar:** tiap kain dihitung di ruang tempat ia dipasang (jubah dan mantel di badan atas, hood di kepala). Gerak badan di dunia (jalan, lompat, terbang 100 blok/detik, berbalik, menoleh) masuk sebagai percepatan bingkai, gaya sentrifugal, Coriolis, dan Euler, persis seperti hukum Newton di kerangka yang bergerak. Kain tetap punya kelembaman, tapi nggak pernah tertinggal, meledak, atau lepas dari badan, dan selalu menempel persis saat digambar.
- **Satuan dunia nyata:** 1 blok = 1 meter, gravitasi 9,81 m/s², udara 1,225 kg/m³, air 1000 kg/m³, kain wol 0,45-0,7 kg/m². Hambatan udara dihitung dari sudut kain terhadap angin.
- **XPBD:** kain nggak bisa molor (tali panjang ke titik paku), tapi gampang melipat saat tertekan, seperti kain sungguhan.
- **Wake di belakang badan:** udara tepat di belakang badan ikut terseret badan, jadi jubah di situ menerima angin yang lebih pelan. Dihitung dengan menelusuri arah datangnya angin dari tiap titik kain.
- **Turbulensi:** pusaran udara yang terbawa aliran (lebih kuat di dalam wake) bikin jubah berkibar alami, bukan gelombang buatan.
- **Tabrakan menerus:** kotak badan, kepala, lengan, dan kaki punya sudut membulat, dan kain selalu didorong ke sisi tempat ia datang. Jubah juga menabrak blok dunia (lantai, dinding, langit-langit).
- **Bentuk pakai:** hood yang dipakai ditahan dekat bentuknya (paling jauh 1,2-4,8 cm), jadi menoleh secepat apa pun tetap membungkus kepala. Mantel ditarik pelan ke bentuknya, dan bagian bahunya ikut terangkat bersama lengan.
- **Hood diturunkan** sekarang benar-benar kain lemas yang tergeletak di atas mantel, dan saat dipakai/dilepas dituntun lewat atas kepala.
- **Jubah menempel di badan atas**, jadi tetap di bahu saat jongkok atau membungkuk (dulu melayang di atas bahu). Pose bawaan Minecraft seperti berenang, merangkak, dan terbang elytra juga diikuti.
- Lebih ringan dari versi lama (±1,8% satu inti CPU per pemain Shazam yang kelihatan).

## Yang baru di 0.13

- **Hood, mantel, dan jubah menyatu.** Hood baru berbentuk kotak dengan sudut membulat (mengikuti kepala Minecraft), bingkai wajah yang menaungi dahi, panel belakang dengan jahitan, dan ujung runcing kecil di ubun-ubun. Mantel bahu baru (kain berfisika) menyambungkan hood dan jubah: tepi bawah hood masuk ke kerah mantel, list emas bingkai wajah bersambung ke tepi depan mantel, dan bagian atas jubah tersembunyi di bawah mantel.
- **Aksesoris bahu:** pelat emas tiga lapis bertumpuk di tiap bahu (dengan paku keling), bros berpermata di kedua tepi depan, dan rantai emas di dada atas. Semuanya menempel di kain dan ikut bergerak.
- **Kain dua lapis:** sisi luar putih, lapisan dalam biru tua keunguan, jadi bagian dalam hood terlihat dalam.
- **Efek skill buatan sendiri:** cahaya lembut, gelombang kejut yang menempel di tanah, cangkang energi, petir bercabang, retakan tanah yang membara, pecahan blok sungguhan, lingkaran rune, tanda sasaran, jejak cahaya, aura api, dan efek layar (garis kecepatan, vinyet). Lihat bagian *Efek visual*.
- **Animasi skill baru** dengan putaran pinggang, condong badan, dan gemetar. Lihat bagian *Animasi skill*.
- Enam penjaga kuil beserta totemnya.

## Yang dibutuhkan

- **JDK 21**, misalnya Eclipse Temurin 21 atau Microsoft Build of OpenJDK 21.
- **Internet** untuk build pertama. Gradle, NeoForge, dan Minecraft diunduh otomatis, totalnya beberapa ratus MB.

## Bikin file .jar

**Windows:** buka folder ini, ketik `cmd` di address bar File Explorer, tekan Enter, lalu jalankan:

    gradlew build

**Mac/Linux:**

    chmod +x gradlew
    ./gradlew build

Hasilnya ada di `build/libs/shazammod-0.14.0.jar`. Taruh di folder `.minecraft/mods`, dengan NeoForge 21.1.228 atau yang lebih baru untuk Minecraft 1.21.1.

Mau ngetes tanpa install? Jalankan `gradlew runClient`.

## Kontrol

Semua tombol bisa diganti di pengaturan Controls, kategori Shazam.

| Tombol | Skill | Gerakan & efek |
|---|---|---|
| G (atau ketik `shazam`) | Transformasi | Lingkaran rune emas menyala di tanah dan roh enam dewa bangkit mengelilingimu, lalu kepalan diangkat ke langit sementara listrik dari tanah merambat ke kepalan. Dunia melambat (slow motion) dan petir sihir turun pelan dari langit selama 2 detik, sementara roh-roh melesat menyatu ke kepalan. Petir mengenai kepalan, layar berkilat, dan kostum terbentuk masih dalam slow motion; begitu selesai, dunia kembali normal. Badan jadi 10% lebih besar. |
| Z | S - Mata Solomon | Tangan menyapu di depan mata, dua jari ke pelipis, cahaya terhisap ke kepala dan lingkaran rune kecil berputar di depan wajah. Lalu mata menyala ungu dan bola pemindai melebar sampai 48 blok: tiap musuh yang dilewatinya mendapat tanda sasaran berputar. Semua musuh itu bersinar dan menerima +25% damage selama 10 detik. |
| X | H - Tepukan Hercules | Tangan dibentang lebar ke belakang sambil menjinjit (kedua tangan bercahaya), lalu ditepuk sambil melangkah maju: kilatan, gelombang udara berbentuk kerucut dan cincin-cincin yang melesat ke depan, debu tersapu searah gelombang. Menghempas musuh di depan. |
| C | A - Hantaman Atlas | Di udara: menukik seperti meteor dengan jejak cahaya jingga. Di tanah: jongkok, melompat kecil dengan kepalan menyatu di atas kepala, lalu dihantamkan. Tanah retak membara, pecahan blok terlempar, kubah energi dan gelombang kejut menyebar, dan musuh terlempar ke atas. |
| V | Z - Petir Zeus | Tangan menyapu ke atas sambil pinggang berputar, listrik berkumpul di tangan dan langit di atas sasaran berkilat, lalu tangan mencambuk menunjuk sasaran dan petir menyambar. Tanahnya hangus dan retak. |
| B | A - Kulit Achilles | Membungkuk gemetar sementara cahaya emas terhisap ke badan, lalu meraung: kubah emas, gelombang raungan dari mulut, dan cincin di tanah. Selama 6 detik badan diselubungi perisai sisik heksagonal emas dan lidah api emas, hampir kebal, sementara musuh di sekitar terdorong dan melemah. |
| N | M - Kilat Mercury | Menerjang secepat kilat dengan jejak listrik biru, bayangan berjejak, dan garis kecepatan di layar, lalu tergelincir berhenti. Musuh di jalur terlempar ke samping. |
| R | Zeus Rage | Membungkuk mengepalkan tinju sementara listrik dari segala arah tertarik ke badan, lalu meraung ke langit: mata menyala putih, petir menyambar di sekeliling dan menghantam musuh dalam 5 blok, tanah retak. Selama amarah, listrik merayap di badan dan batu-batu kecil terangkat mengorbit. Selama 12 detik pukulan +50% dan petirnya merambat ke 2 musuh terdekat, tiap detik petir memburu 2 musuh dalam 12 blok, dan lari lebih cepat. Biaya 150 energi, cooldown 60 detik. |
| H | Hood naik/turun | Kedua tangan meraih ke belakang kepala lalu menarik hood ke depan sampai dahi, atau memegang tepi hood di dahi lalu mendorongnya ke belakang. Statusnya tersimpan dan terlihat oleh pemain lain. |

## Terbang

| Kontrol | Gerakan |
|---|---|
| Spasi 2x | Lepas landas: jongkok sebentar, lalu melesat ke atas. Di udara, tekan lagi 2x untuk berhenti terbang. |
| W | Terbang ke arah pandangan (±28 blok/detik). |
| W + sprint (ditahan) | Makin lama makin ngebut sampai ±100 blok/detik. Saat menembus kecepatan tertentu muncul sonic boom: cincin uap, dentuman, dan musuh di sekitar terhempas. |
| S | Mengerem dengan hambatan udara besar (dari 100 blok/detik ±0,8 detik). Badan menegak, tangan dan kaki terayun ke depan. |
| Spasi / Shift | Naik / turun. |
| A / D | Geser ke samping (hanya di kecepatan rendah). |
| A 2x / D 2x | Barrel roll menghindar ke kiri/kanan. |

### Fisika terbang

Geraknya mengikuti fisika dunia nyata:

- **Dorongan melawan hambatan udara:** makin kencang, makin berat menambah kecepatan. Dari melayang ke 28 blok/detik butuh ±0,5 detik; dengan sprint, sonic boom di ±1,5 detik dan kecepatan puncak di ±3 detik.
- **Belokan dibatasi gaya menyamping:** makin kencang, makin lebar belokannya, dan kecepatan nggak hilang saat berbelok. Putar balik di 28 blok/detik selebar ±10 blok (±0,5 detik); di 100 blok/detik selebar ±125 blok (±2 detik), seperti pesawat jet.
- **Gravitasi:** menukik menambah kecepatan (W sambil menukik lurus sampai ±49 blok/detik), menanjak menguranginya (±23 blok/detik).
- **Meluncur:** lepas W saat kencang, Shazam meluncur dan melambat karena hambatan udara (kecepatan tinggi cepat berkurang, kecepatan rendah meluncur jauh), lalu berhenti dan melayang.

### Pose terbang

Pose badan juga dihitung dari gaya yang bekerja, lalu dihaluskan dengan pegas teredam (ada sedikit ayunan alami):

- **Melayang:** badan condong searah gaya yang dibutuhkan, seperti helikopter. Mulai maju berarti condong ke depan, bergeser berarti miring ke samping, mundur berarti condong ke belakang. Naik-turun pelan tetap tegak.
- **Meluncur:** badan sejajar lintasan dengan "hidung" sedikit naik (sudut serang), yang makin kecil saat makin kencang. Satu kepalan di depan; saat super cepat kedua kepalan di depan seperti peluru. Badan tegak saat menanjak dan kepala di bawah saat menukik.
- **Menikung:** badan miring ke dalam belokan seperti pesawat, dengan sudut sebesar arctan(percepatan menyamping ÷ gravitasi), sampai ±70° di belokan tajam. Kamera ikut miring setengahnya.
- **Arah badan:** badan menghadap arah lintasan, bukan arah kamera, jadi saat berbelok kencang badan menyusul pelan-pelan. Kepala tetap memandang ke arah kamera.
- **Tangan dan kaki:** lembam. Saat dipercepat kaki tertinggal ke belakang, saat mengerem terayun ke depan, dan makin kencang makin bergetar diterpa angin.
- **Menjelang tanah:** sekitar 0,8 detik sebelum menyentuh tanah sambil turun, badan menegak dan kaki maju untuk mendarat.

Pandangan juga melebar sesuai kecepatan. Angka-angka fisika gerak ada di bagian atas `FlightModel.java`, dan angka pose di `FlightPose.java`.

Mendarat atau jatuh dengan kencang memicu hero landing: satu lutut turun, kepalan menghantam tanah, dan gelombang kejut melukai musuh di sekitar. Menabrak dinding dengan kencang juga menimbulkan gelombang kejut.

## Kekuatan saat jadi Shazam

| Bagian | Nilai |
|---|---|
| Darah | 100 (bar darah sendiri menggantikan baris hati), pulih 2 per detik |
| Ketahanan | damage yang diterima tinggal 40%, ditambah armor +10 dan toughness +6 |
| Kebal | jatuh, petir, api, lava, tenggelam (nggak perlu napas), beku, lapar, kaktus, racun, wither |
| Kelemahan | sihir (+50% damage) |
| Pukulan tangan kosong | 20 (critical 30), musuh terpental jauh |
| Lain-lain | badan 10% lebih besar, naik blok tanpa melompat, jangkauan +1, menghancurkan blok 4x lebih cepat |
| Energi Petir | 1000, berkurang 1 per detik saat jadi Shazam (±16 menit) dan terisi 5 per detik sebagai manusia; badai petir mempercepat |

## Tampilan saat jadi Shazam

Skin kamu tetap skin aslinya. Yang muncul saat berubah adalah hood, jubah, dan lambang 3D.

- **Roh enam dewa:** begitu SHAZAM diucapkan, roh Solomon, Hercules, Atlas, Zeus, Achilles, dan Mercury bangkit dari tanah satu per satu dengan denting yang makin tinggi. Tiap roh bercahaya dengan warna totem dewanya, dan totem itu berputar di atas kepalanya. Mereka melayang mengelilingimu selama ±1,5 detik sementara huruf-huruf sihir mengalir dari lingkaran di tanah, lalu melesat ke kepalan yang terangkat dan lenyap jadi semburan cahaya enam warna tepat saat petir menyambar. Roh-roh ini digambar di dunia, jadi tetap kelihatan dari sudut pandang orang pertama.
- **Saat berubah:** kepalan menembus langit, lalu petir sihir menyambar dan Shazam terangkat melayang. Kilau emas menyapu badan dari dada, lengan, kepala, sampai kaki. Di tengah kilau itu lambang muncul memantul di dada dengan kilatan terang. Jubah terbentang ke belakang lalu jatuh ke punggung, dan hood muncul di belakang leher lalu tertarik menutupi kepala.
- **Saat kembali jadi manusia:** lambang mengecil hilang, dan jubah, mantel, serta hood memudar jadi butiran cahaya emas.

### Slow motion saat berubah

Begitu kepalan terangkat ke langit, dunia melambat 4× dan petir sihir turun dari langit dengan ujung yang bercahaya dan memercik, tepat 2 detik sampai mengenai kepalan. Roh enam dewa melesat menyatu ke kepalan selama petir turun. Setelah petir mengenai, dunia tetap 2× lebih lambat selama kostum terbentuk (kilau emas, lambang, jubah, sampai hood tertarik ke kepala), lalu kembali normal pelan-pelan. Semuanya ikut melambat: gerakan, partikel, jubah, dan nada suara.

- Slow motion memperlambat seluruh dunia (sama seperti `/tick rate`), jadi hanya jalan kalau kamu sendirian di server. Di server dengan pemain lain, transformasinya tetap jalan dengan kecepatan normal.
- Kalau sebelumnya kamu memakai `/tick rate` sendiri, nilai itu yang dikembalikan. Kalau transformasi batal atau kamu keluar di tengah jalan, kecepatan langsung kembali normal.
- Kalau sedang di sudut pandang orang pertama, kamera pindah ke depan (orang ketiga, menghadap wajah) selama transformasi supaya semuanya terlihat jelas, lalu kembali seperti semula.
- Kecepatan dan lamanya bisa diatur di bagian atas `ShazamSlowMo.java`. Slow motion bisa dimatikan lewat `ENABLED` di file itu, dan kamera sinematik lewat `ENABLED` di `ShazamCinematic.java`.

### Jubah, mantel, dan hood (satu pakaian, 3D, berfisika)

Ketiganya kain 3D dengan fisika dunia nyata (XPBD, satuan meter, detik, dan kilogram) yang dihitung dengan langkah kecil tetap (160 kali per detik), jadi gerakannya halus dan sama di FPS berapa pun. Tiap kain dihitung di ruang tempat ia dipasang (jubah dan mantel di badan atas, hood di kepala), dan gerak badan di dunia masuk sebagai gaya semu yang benar secara fisika. Saat digambar, permukaan kain dihaluskan dengan kurva sehingga lipatannya melengkung, bukan bersudut. Urutan hitungnya tiap langkah: jubah, lalu mantel (yang selalu di luar bagian atas jubah), lalu hood (yang saat diturunkan tergeletak di atas mantel).

- **Hood:** bentuknya mengikuti kepala Minecraft yang kotak: penampang kotak dengan sudut atas membulat, sekitar 0,03 blok lebih besar dari kepala plus lapisan topi skin. Bingkai wajahnya lurus di samping pipi dan atas dahi, bagian atasnya sedikit maju menaungi dahi. Panel samping lurus sampai belakang kepala, lalu panel belakang yang rata dengan jahitan di tengah dan ujung runcing kecil di ubun-ubun. Pinggirannya menempel di wajah, sisanya kain yang ditahan dekat bentuknya (paling jauh 1,2-4,8 cm) dan sedikit berayun saat menoleh, menunduk, atau terbang. Hood tetap menjaga bentuknya, nggak pernah menutupi wajah, dan nggak pernah nyangkut di sisi kepala yang salah, secepat apa pun menolehnya.
- **Mantel bahu:** kain pendek yang melingkari pangkal kepala, jatuh menutupi kedua bahu, dada atas, dan punggung atas, dengan ujung lancip di tengah punggung. Mantel inilah yang menyatukan semuanya: tepi bawah hood masuk ke kerah mantel (seperti dijahit), list emas bingkai wajah bersambung ke list tepi depan mantel, dan bagian atas jubah tersembunyi di bawahnya. Mantel ditarik pelan ke bentuk pakainya, bagian di atas bahu ikut terangkat bersama lengan, dan kainnya menabrak badan serta kedua lengan (kotak bersudut bulat yang ikut berputar bersama lengan), jadi saat lengan diangkat atau diayun kainnya meluncur di atas lengan, nggak melorot dan nggak menembus.
- **Jubah:** bagian atasnya dipaku di bahu (di bawah mantel, ikut badan atas saat jongkok atau membungkuk) dan sisanya kain sungguhan: nggak pernah molor, nggak menembus badan, kaki, atau lengan, dan nggak menembus blok (lantai, dinding, langit-langit). Yang menggerakkannya:
  - Gravitasi 9,81 m/s² dan berat kain wol tebal (0,7 kg/m²).
  - Kelembaman: saat badan berbelok, berhenti, atau mendarat, jubah ikut terayun (gaya semu kerangka yang bergerak).
  - Hambatan udara sesuai sudut kain terhadap angin. Tepat di belakang badan udaranya ikut terseret badan (wake), jadi bagian itu menerima angin yang lebih pelan.
  - Turbulensi: pusaran udara yang terbawa aliran, lebih kuat di dalam wake, yang bikin jubah berkibar seperti bendera.

  Hasilnya, saat diam jubah menggantung sampai dekat tanah. Saat jalan terangkat sekitar 33°, saat sprint sekitar 43°, dan saat terbang memanjang di sepanjang badan sambil berkibar. Kalau terlempar ke atas, jubah jatuh lagi dalam ±0,5 detik lalu tenang. Di dalam air (air 800 kali lebih padat dari udara, dan kain hampir melayang) jubah mengambang pelan mengikuti arus gerak.
- **Angin sekitar:** di luar ruangan, jubah, mantel, dan hood bergoyang pelan tertiup angin yang arahnya berubah-ubah dan berembus. Angin lebih kencang saat hujan dan badai, dan tidak ada di dalam ruangan, gua, atau air.
- Tekan **H** untuk memakai atau melepas hood dengan tangan. Saat memakai, kedua tangan meraih ke belakang kepala, memegang tepi hood, lalu menariknya ke depan lewat atas kepala sampai dahi. Saat melepas, tangan memegang tepi hood di dahi lalu mendorongnya ke belakang sampai hood tergeletak di atas mantel di belakang leher. Hood baru bergerak saat tangan sudah memegangnya, dan terdengar gesekan kain. Statusnya tersimpan dan terlihat oleh pemain lain.
- **Saat terbentuk** (berubah jadi Shazam), tiap potong kain muncul bergantian (mantel, jubah, lalu hood) dan disapu pita cahaya emas dari atas ke bawah. **Saat lenyap**, kain memudar tembus pandang sambil melepas butiran cahaya emas.

**Kain dua lapis:** sisi luar putih, lapisan dalam berwarna gelap (biru tua keunguan), jadi bagian dalam hood terlihat dalam dan jubah yang berkibar memperlihatkan lapisan dalamnya. Warnanya diatur di `LINING` di bagian atas `ShazamCape.java` (angka RGB, misalnya `0x2E3458`).

**Hiasan emas:** list emas timbul di semua tepi: bingkai wajah dan tepi bawah hood, kerah, tepi depan, dan ujung bawah mantel, serta tepi kiri, kanan, dan bawah jubah. List itu timbul dari kain di kedua sisi, dengan tepi luar yang berkilau dan tepi dalam yang berbayang, dan sedikit menyala di tempat gelap. Karena menempel di titik-titik kain, list emas ikut berkibar.

**Aksesoris bahu:** di tiap bahu ada pelat emas tiga lapis yang bertumpuk seperti genteng, melengkung mengikuti mantel, dengan paku keling bercahaya di kedua ujungnya. Di kedua tepi depan mantel, tepat di bawah rahang hood, ada bros pengait berpermata, disambung rantai emas yang menjuntai di dada atas (di atas lambang dada). Semuanya menempel di kain mantel, jadi ikut bergerak saat mantel terdorong lengan atau tertiup angin. Letak dan ukurannya ada di `PLATE_COLS`, `PLATE_ROWS`, `CLASP_COL`, dan `CLASP_ROW` di `MantleShape.java`, serta bagian atas `CloakDecor.java`.

**Lambang punggung:** di tengah punggung jubah ada lambang 3D yang timbul dari kain dan ikut melengkung saat jubah berkibar. Lambang ini terang sendiri, dengan cahaya berdenyut, kilatan putih yang menyapu, dan pendar emas di kain sekitarnya. Gambarnya sama dengan lambang dada, kecuali kamu menaruh gambar khusus di `.../textures/entity/shazam_cape_emblem.png` (aturannya sama dengan lambang dada).

Lebar dan ketebalan list emas, serta ukuran, posisi, dan ketebalan lambang punggung, bisa diatur di bagian atas `CapeDecor.java`.

Jubah, mantel, dan hood juga muncul saat memakai Kostum Shazam (armor dada), walaupun tidak sedang jadi Shazam.

Warna dan motif kain ada di `.../textures/entity/shazam_cape_cloth.png`. Gambar itu dibentangkan ke seluruh jubah (kiri-kanan gambar = tepi kiri-kanan jubah, atas = bahu, bawah = ujung), dan bagian atasnya juga dipakai untuk hood dan mantel. Angka-angkanya bisa diatur di bagian atas file masing-masing: fisika umum (langkah per detik, gravitasi, hambatan udara, batas gaya semu, tabrakan) di `Cloak.java`; ukuran, berat, dan kelenturan jubah di `CapeShape.java`; bentuk dan kelenturan mantel di `MantleShape.java`; bentuk hood dan seberapa kuat bentuknya dijaga di `HoodShape.java`; angin sekitar, wake, dan turbulensi di `CapeAir.java`; kehalusan gambar dan warna di `ShazamCape.java`.

### Lambang 3D di dada

Bentuk dan warna lambang diambil dari `.../textures/entity/shazam_emblem.png`. Setiap piksel yang tidak transparan jadi balok kecil yang timbul dari dada, dengan warna piksel itu. Lambang menyala sendiri walaupun di tempat gelap, dan berkilau:

- cahaya emas berdenyut di sekelilingnya,
- kilatan putih yang menyapu permukaannya setiap ±2,5 detik,
- kilat terang saat lambang pertama muncul,
- percikan cahaya kecil yang sesekali keluar.

Lambang bawaannya bintang kilau empat sudut. Untuk memakai desain sendiri, timpa file itu dengan PNG berlatar transparan, maksimal 64×64 piksel (16×16 sampai 32×32 sudah cukup). Lebarnya otomatis disesuaikan ke dada, jadi gambar yang lebih tinggi daripada lebarnya akan memanjang ke bawah. Ukuran, posisi, dan ketebalannya bisa diatur di bagian atas `ShazamEmblemLayer.java`. Setelah mengganti gambar, build ulang (atau tekan F3+T saat `runClient`).

### Mata menyala: Zeus Rage dan Mata Solomon

Saat Zeus Rage menyala, matamu jadi putih terang dengan pendar biru-putih, kilau mendatar, dan kilatan listrik kecil di sekitarnya, lalu padam pelan saat amarahnya habis. Selama Zeus Rage aktif, listrik merayap di seluruh badan, busur listrik kecil keluar dari mata, dan batu-batu kecil (dari jenis tanah di bawahmu) terangkat dan mengorbit pelan di sekeliling badan. Pemain lain yang baru melihatmu di tengah amarah juga melihat semua efek ini.

Sesudah Mata Solomon, matamu menyala ungu selama ±3 detik.

Letak mata diatur untuk skin standar: baris ke-4 wajah, kolom 1-2 dan 5-6 (wajah 8×8 dihitung dari kiri-atas seperti terlihat dari depan). Kalau mata di skin-mu ada di baris atau kolom lain, ubah `EYE_ROW`, `EYE_HEIGHT`, dan `EYES` di bagian atas `ShazamEyesLayer.java`.

## Efek visual (buatan sendiri, bukan partikel Minecraft)

Semua efek skill, terbang, transformasi, dan petir digambar sendiri oleh mesin efek di `client/vfx`. Bentuknya dibuat dari geometri dengan gradasi warna per titik, jadi cahayanya halus di jarak berapa pun (nggak kotak-kotak seperti partikel bawaan). Cahaya digambar di lapisan aditif yang nggak menulis kedalaman, jadi pendar yang besar nggak pernah "memotong" benda di belakangnya.

| Efek | Isinya |
|---|---|
| Cahaya & kilatan | Pendar bulat lembut dengan inti putih, bintang kilau empat sudut |
| Gelombang kejut | Cincin yang melebar dan menempel di tanah yang tidak rata (tinggi tanah di sekitarnya diukur dulu), cincin debu, cincin yang melesat ke depan |
| Cangkang energi | Bola atau kubah yang tepinya paling terang (seperti gelembung energi), kerucut udara/uap |
| Petir | Jalur zig-zag bercabang yang berganti bentuk tiap 1-2 tick, busur listrik yang mengikuti tangan, listrik yang merayap di badan |
| Tanah | Retakan yang menjalar dari titik hantaman, membara emas-jingga lalu mendingin jadi celah gelap; bekas hangus; pecahan blok sungguhan (tekstur tanahnya) yang terlempar, berputar, jatuh, dan memantul |
| Butiran | Butiran cahaya, percikan berbentuk garis yang jatuh dan memantul, bara yang naik sambil mendingin, kepulan debu berwarna tanah |
| Sihir | Lingkaran rune berputar (cincin, sisir, busur putus-putus, huruf rune, bintang segi enam), tanda sasaran berputar di musuh |
| Lain-lain | Jejak cahaya (terjangan, menukik, tangan saat terbang), lidah api emas di sekeliling badan, tiang cahaya dari langit |
| Layar (pemain sendiri) | Garis kecepatan ala anime, vinyet berwarna di tepi layar, kilatan layar berwarna, sentakan pandangan |

Setiap skill memakai warna dewanya: ungu untuk Solomon, putih kehijauan untuk Hercules, jingga tanah untuk Atlas, emas untuk petir Zeus, emas untuk Achilles, biru muda untuk Mercury, dan putih kebiruan untuk Zeus Rage. Warna-warna ini ada di bagian atas `client/fx/ShazamFx.java`, dan urutan efek tiap skill ada di file yang sama. Jumlah efek dibatasi (`MAX_EFFECTS` di `Vfx.java`, butiran di `Particles.java`) supaya tetap ringan.

Tekstur khusus efek ada di `.../textures/entity/fx/`: `aegis.png` (perisai sisik Achilles), `weave.png` (kilau saat kostum terbentuk), dan `spirit.png` (roh dewa). Ketiganya bisa diganti dengan gambar sendiri ukuran 64×64 yang bisa diulang (latar hitam = tembus pandang, karena digambar sebagai cahaya).

## Animasi skill

Gerakan ada di `client/anim/Clips.java` sebagai keyframe. Selain putaran tiap bagian tubuh, condong badan (`tilt`), dan turunnya badan (`drop`), sekarang ada:

- `twist`: pinggang berputar (badan atas dan bahu ikut, kaki tetap), buat ancang-ancang memukul atau mencambuk;
- `lean`: seluruh badan condong ke samping;
- `spin`: seluruh badan berputar;
- `shake`: gemetar (derajat), buat mengumpulkan tenaga atau menahan amarah.

Tiap skill punya ancang-ancang, gerakan utama yang cepat dengan sedikit kebablasan, lalu kembali pelan. Waktu tiap gerakan pas dengan saat damage di server (`ShazamAnim.java`).

## Kostum armor (bisa di-craft)

Empat bagian, pertahanannya setara netherite, dan diperbaiki pakai emas. Teksturnya ada di `.../textures/models/armor/shazam_suit_layer_1.png` dan `_layer_2.png`.

| Bagian | Resep (G = emas batangan, R = wol merah) |
|---|---|
| Kepala Kostum Shazam | `KKK / BHB / _L_`: K = wol hitam, B = pewarna cokelat, H = helm berlian, L = penangkal petir |
| Kostum Shazam | `RLR / GCG / R_R`: L = penangkal petir, C = baju zirah berlian |
| Celana Kostum Shazam | `GYG / RLR / R_R`: Y = balok emas, L = celana berlian |
| Sepatu Kostum Shazam | `G_G / RDR / G_G`: D = sepatu berlian |

(`_` = kotak kosong.) Kostum ini nggak memberi kekuatan; kekuatan Shazam tetap datang dari mengucapkan SHAZAM.

## Perintah tes

Perintah ini butuh cheat aktif.

- `/shazam unlock` dan `/shazam lock`: membuka atau mencabut kekuatan Shazam.
- `/shazam energy <0-1000>`: mengatur Energi Petir.
- `/shazam summon <solomon|hercules|atlas|zeus|achilles|mercury>`: memunculkan penjaga.

## Kalau build gagal

- **`Plugin [id: 'net.neoforged.moddev', version: '2.0.+'] was not found`:** ganti `2.0.+` di `build.gradle` dengan versi ModDevGradle yang tertulis di MDK NeoForge 1.21.1 resmi.
- **Error soal versi Java:** pastikan `JAVA_HOME` mengarah ke JDK 21.
- **Crash saat game dibuka dengan pesan `Mixin`:** salin pesan error-nya dari `logs/latest.log` untuk diperbaiki.
- **Error kompilasi di `client/vfx`, `ShazamCape.java`, atau `ShazamFx.java`:** salin pesan error-nya (nama file, nomor baris, dan pesannya) untuk diperbaiki.

## Soal gradle-wrapper.jar

`gradle/wrapper/gradle-wrapper.jar` adalah pengganti ringkas untuk wrapper resmi Gradle. Sumbernya ada di `gradle/wrapper/GradleWrapperMain.java`. Cara kerjanya: mengunduh Gradle 8.14.3 sekali ke `~/.gradle/wrapper/dists`, lalu menjalankannya.

Kalau mau memakai wrapper resmi, ada dua cara:
- Kalau Gradle sudah terpasang, jalankan `gradle wrapper --gradle-version 8.14.3` di folder ini.
- Salin folder `gradle/` dan file `gradlew*` dari MDK resmi.
