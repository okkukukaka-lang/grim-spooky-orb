package com.shazammod.client.vfx;

import java.util.ArrayList;
import java.util.List;

import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Mesin efek visual Shazam: semua efek skill digambar sendiri di dunia (cahaya lembut, gelombang kejut,
 * petir bercabang, retakan tanah, pecahan blok, lingkaran rune, dan lain-lain), bukan partikel Minecraft.
 * Efek berumur pendek, dihitung tiap tick, digambar tiap frame dengan interpolasi supaya halus.
 */
public final class Vfx {
    private Vfx() {}

    private static final int MAX_EFFECTS = 320;
    private static final List<Effect> EFFECTS = new ArrayList<>();
    private static final List<Effect> PENDING = new ArrayList<>();
    private static final Particles PARTICLES = new Particles();
    private static final RandomSource RANDOM = RandomSource.create();

    public static RandomSource random() {
        return RANDOM;
    }

    public static void add(Effect effect) {
        if (EFFECTS.size() + PENDING.size() < MAX_EFFECTS) {
            PENDING.add(effect);
        }
    }

    public static void clear() {
        EFFECTS.clear();
        PENDING.clear();
        PARTICLES.clear();
    }

    public static void tick(ClientLevel level) {
        EFFECTS.addAll(PENDING);
        PENDING.clear();
        PARTICLES.tick();
        EFFECTS.removeIf(effect -> !effect.tick(level));
    }

    // ------------------------------------------------------------------ butiran

    /** Butiran cahaya lembut yang melayang. */
    public static void mote(double x, double y, double z, double vx, double vy, double vz, int rgb, float size, int life) {
        PARTICLES.spawn(Particles.MOTE, x, y, z, vx, vy, vz, rgb, size, life, 0f, 0.04f, Double.NaN, RANDOM.nextFloat());
    }

    /** Percikan memanjang searah gerak; jatuh dan memantul di tanah (floorY, atau NaN = tanpa tanah). */
    public static void spark(double x, double y, double z, double vx, double vy, double vz, int rgb, float size, int life,
                             double floorY) {
        PARTICLES.spawn(Particles.SPARK, x, y, z, vx, vy, vz, rgb, size, life, 0.035f, 0.05f, floorY, RANDOM.nextFloat());
    }

    /** Bara yang naik sambil mendingin. */
    public static void ember(double x, double y, double z, double vx, double vy, double vz, float size, int life) {
        PARTICLES.spawn(Particles.EMBER, x, y, z, vx, vy, vz, 0xFFE0A0, size, life, -0.002f, 0.06f, Double.NaN, RANDOM.nextFloat());
    }

    /** Bintang kilau empat sudut. */
    public static void glint(double x, double y, double z, int rgb, float size, int life) {
        PARTICLES.spawn(Particles.GLINT, x, y, z, 0, 0, 0, rgb, size, life, 0f, 0f, Double.NaN, RANDOM.nextFloat());
    }

    /** Kepulan debu lembut (warna tanah). */
    public static void dust(double x, double y, double z, double vx, double vy, double vz, int rgb, float size, int life) {
        PARTICLES.spawn(Particles.DUST, x, y, z, vx, vy, vz, rgb, size, life, -0.001f, 0.12f, Double.NaN, RANDOM.nextFloat());
    }

    // ------------------------------------------------------------------ gambar

    /** Dipanggil dari RenderLevelStageEvent. */
    public static void render(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES || (EFFECTS.isEmpty() && PARTICLES.isEmpty())) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            return;
        }
        float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        Vec3 cam = event.getCamera().getPosition();
        PoseStack poseStack = event.getPoseStack();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        poseStack.pushPose();
        // 1) benda padat (pecahan blok)
        for (Effect effect : EFFECTS) {
            effect.renderSolid(poseStack, buffers, cam.x, cam.y, cam.z, partialTick);
        }
        buffers.endBatch();
        Draw draw = new Draw(poseStack.last(), cam, partialTick);
        // 2) lapisan lembut (debu, hangus, retakan gelap)
        draw.begin(buffers.getBuffer(Draw.softType()), false);
        PARTICLES.renderSoft(draw);
        for (Effect effect : EFFECTS) {
            effect.renderSoft(draw);
        }
        // 3) cahaya
        draw.begin(buffers.getBuffer(Draw.additiveType()), true);
        PARTICLES.renderGlow(draw);
        for (Effect effect : EFFECTS) {
            effect.renderGlow(draw);
        }
        buffers.endBatch();
        poseStack.popPose();
    }
}
