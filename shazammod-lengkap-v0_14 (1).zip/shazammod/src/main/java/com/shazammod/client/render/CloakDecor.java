package com.shazammod.client.render;

/**
 * Aksesoris emas jubah (murni Java, gampang diuji): pelat bahu bertumpuk tiga, bros pengait di kedua tepi depan
 * mantel, dan rantai yang menjuntai di dada atas di antara kedua bros (di atas lambang dada).
 * Semuanya menempel di permukaan kain yang sedang berkibar (ikut melengkung dan bergerak bersama mantel).
 *
 * Keluaran: quad dengan format sama seperti ClothDecor (4 titik, normal, jenis warna).
 * Grid kain: hasil ClothDecor.refine (sudah dihaluskan) beserta normalnya (menghadap badan).
 */
public final class CloakDecor {
    private CloakDecor() {}

    public static final int STRIDE = ClothDecor.STRIDE;
    public static final int FACE = 0;     // permukaan emas
    public static final int OUTER = 1;    // tepi yang terkena cahaya (paling terang)
    public static final int INNER = 2;    // tepi berbayang
    public static final int GEM = 3;      // permata / paku keling (bercahaya)
    public static final int DARK = 4;     // emas tua (celah antar-lempeng, mata rantai)

    // ======= Ukuran (blok) =======
    private static final float[] PLATE_RAISE = {0.024f, 0.019f, 0.014f};   // tinggi tiap lempeng dari kain
    private static final float PLATE_FLARE = 0.011f;      // tepi bawah lempeng sedikit mencuat
    private static final float PLATE_BASE = 0.004f;       // kaki lempeng (di atas kain)
    private static final float RIVET = 0.011f;            // paku keling di ujung lempeng
    private static final float CLASP_RADIUS = 0.052f;
    private static final float CLASP_RAISE = 0.02f;
    private static final float GEM_RADIUS = 0.022f;
    private static final float LINK_WIDTH = 0.02f;
    private static final float LINK_THICK = 0.008f;
    private static final int LINKS = 13;
    private static final float CHAIN_SAG = 0.065f;

    /** Kumpulan quad yang tumbuh sendiri. */
    public static final class Quads {
        public float[] data = new float[STRIDE * 256];
        public int count;

        void add(float[] a, float[] b, float[] c, float[] d, float nx, float ny, float nz, int kind) {
            if ((count + 1) * STRIDE > data.length) {
                float[] bigger = new float[data.length * 2];
                System.arraycopy(data, 0, bigger, 0, data.length);
                data = bigger;
            }
            int o = count * STRIDE;
            data[o] = a[0]; data[o + 1] = a[1]; data[o + 2] = a[2];
            data[o + 3] = b[0]; data[o + 4] = b[1]; data[o + 5] = b[2];
            data[o + 6] = c[0]; data[o + 7] = c[1]; data[o + 8] = c[2];
            data[o + 9] = d[0]; data[o + 10] = d[1]; data[o + 11] = d[2];
            data[o + 12] = nx; data[o + 13] = ny; data[o + 14] = nz;
            data[o + 15] = kind;
            count++;
        }

        /** Quad dengan normal dihitung dari titik-titiknya, diarahkan searah (rx, ry, rz). */
        void face(float[] a, float[] b, float[] c, float[] d, float rx, float ry, float rz, int kind) {
            float ux = c[0] - a[0], uy = c[1] - a[1], uz = c[2] - a[2];
            float vx = d[0] - b[0], vy = d[1] - b[1], vz = d[2] - b[2];
            float nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
            float len = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
            if (len < 1.0E-9f) {
                nx = rx; ny = ry; nz = rz;
                len = Math.max((float) Math.sqrt(nx * nx + ny * ny + nz * nz), 1.0E-9f);
            }
            if (nx * rx + ny * ry + nz * rz < 0f) {
                nx = -nx; ny = -ny; nz = -nz;
            }
            add(a, b, c, d, nx / len, ny / len, nz / len, kind);
        }

        public void clear() {
            count = 0;
        }
    }

    /** Titik di permukaan kain (kolom/baris pecahan di grid halus) dinaikkan setinggi h ke luar kain. */
    private static float[] lifted(float[][] g, int cols, int rows, float c, float r, float h) {
        float[] s = new float[6];
        ClothDecor.sample(g[0], g[1], g[2], g[3], g[4], g[5], cols, rows, c, r, s);
        // normal grid menghadap badan; luar = kebalikannya
        return new float[] {s[0] - s[3] * h, s[1] - s[4] * h, s[2] - s[5] * h, -s[3], -s[4], -s[5]};
    }

    // ------------------------------------------------------------------ pelat bahu

    /**
     * Pelat bahu: tiga lempeng melengkung bertumpuk seperti genteng di atas kedua bahu mantel.
     * @param g      grid mantel halus {x, y, z, nx, ny, nz}
     * @param factor faktor penghalusan grid (kolom/baris grid kasar dikali ini)
     */
    public static void shoulderPlates(Quads out, float[][] g, int cols, int rows, int factor) {
        for (int side = 0; side < 2; side++) {
            float c0 = MantleShape.PLATE_COLS[0] * factor, c1 = MantleShape.PLATE_COLS[1] * factor;
            if (side == 1) {   // bahu kanan: dicerminkan
                float m0 = (cols - 1) - c1, m1 = (cols - 1) - c0;
                c0 = m0;
                c1 = m1;
            }
            for (int k = 0; k < MantleShape.PLATE_ROWS.length; k++) {
                float r0 = MantleShape.PLATE_ROWS[k][0] * factor, r1 = MantleShape.PLATE_ROWS[k][1] * factor;
                // lempeng bawah sedikit lebih sempit: siluet meruncing ke bawah
                float inset = (c1 - c0) * 0.04f * k;
                lame(out, g, cols, rows, c0 + inset, c1 - inset, r0, r1, PLATE_RAISE[k]);
            }
        }
    }

    private static void lame(Quads out, float[][] g, int cols, int rows, float c0, float c1, float r0, float r1, float raise) {
        int nu = 7, nv = 3;
        float[][][] top = new float[nu + 1][nv + 1][];
        float[][][] base = new float[nu + 1][nv + 1][];
        for (int i = 0; i <= nu; i++) {
            float c = c0 + (c1 - c0) * i / nu;
            float across = Math.abs(i / (float) nu - 0.5f) * 2f;   // 0 di tengah, 1 di ujung
            for (int j = 0; j <= nv; j++) {
                float v = j / (float) nv;
                float r = r0 + (r1 - r0) * v;
                // melengkung: tengah lebih tinggi, tepi bawah mencuat
                float h = raise * (1f - 0.35f * across * across) + PLATE_FLARE * v * v;
                top[i][j] = lifted(g, cols, rows, c, r, h);
                base[i][j] = lifted(g, cols, rows, c, r, PLATE_BASE);
            }
        }
        // permukaan atas
        for (int i = 0; i < nu; i++) {
            for (int j = 0; j < nv; j++) {
                float[] n = top[i][j];
                out.face(top[i][j], top[i + 1][j], top[i + 1][j + 1], top[i][j + 1], n[3], n[4], n[5], FACE);
            }
        }
        // dinding: bawah (terkena cahaya), atas (berbayang), kedua ujung
        for (int i = 0; i < nu; i++) {
            float[] a = top[i][nv], b = top[i + 1][nv], c = base[i + 1][nv], d = base[i][nv];
            float[] down = towards(top[i][nv], top[i][nv - 1], -1f);
            out.face(a, b, c, d, down[0], down[1], down[2], OUTER);
            float[] a2 = top[i][0], b2 = top[i + 1][0], c2 = base[i + 1][0], d2 = base[i][0];
            float[] up = towards(top[i][0], top[i][1], -1f);
            out.face(a2, b2, c2, d2, up[0], up[1], up[2], DARK);
        }
        for (int j = 0; j < nv; j++) {
            float[] l = towards(top[0][j], top[1][j], -1f);
            out.face(top[0][j], top[0][j + 1], base[0][j + 1], base[0][j], l[0], l[1], l[2], INNER);
            float[] r = towards(top[nu][j], top[nu - 1][j], -1f);
            out.face(top[nu][j], top[nu][j + 1], base[nu][j + 1], base[nu][j], r[0], r[1], r[2], INNER);
        }
        // paku keling di kedua ujung
        for (float u : new float[] {0.13f, 0.87f}) {
            float c = c0 + (c1 - c0) * u;
            float r = r0 + (r1 - r0) * 0.55f;
            float[] p = lifted(g, cols, rows, c, r, raise * (1f - 0.35f * 0.55f) + PLATE_FLARE * 0.3f + 0.002f);
            float[] t = towards(lifted(g, cols, rows, c + 0.5f, r, 0f), lifted(g, cols, rows, c - 0.5f, r, 0f), 1f);
            stud(out, p, t, RIVET, GEM);
        }
    }

    /** Arah satuan dari b ke a dikali sign (buat menentukan sisi dinding). */
    private static float[] towards(float[] a, float[] b, float sign) {
        float x = (a[0] - b[0]) * -sign, y = (a[1] - b[1]) * -sign, z = (a[2] - b[2]) * -sign;
        float len = (float) Math.sqrt(x * x + y * y + z * z);
        return len < 1.0E-9f ? new float[] {0f, 1f, 0f} : new float[] {x / len, y / len, z / len};
    }

    /** Kubus kecil menghadap normal p[3..5] dengan sisi sejajar arah t. */
    private static void stud(Quads out, float[] p, float[] t, float size, int kind) {
        float[] n = {p[3], p[4], p[5]};
        float[] b = cross(n, t);
        float[] t2 = cross(b, n);
        box(out, p, t2, b, n, size * 0.5f, size * 0.5f, size * 0.5f, kind, kind);
    }

    // ------------------------------------------------------------------ bros, rantai, liontin

    /**
     * Bros pengait di kedua tepi depan mantel dan rantai yang menjuntai di antaranya.
     * @param chestZ  bidang dada di ruang leher (rantai nggak masuk ke dada)
     * @param neck    ruang leher (posisi render)
     */
    public static void clasps(Quads out, float[][] g, int cols, int rows, int factor, HoodShape.Frame neck, double chestZ) {
        float[][] centers = new float[2][];
        for (int side = 0; side < 2; side++) {
            float c = MantleShape.CLASP_COL * factor;
            if (side == 1) {
                c = (cols - 1) - c;
            }
            float r = MantleShape.CLASP_ROW * factor;
            float[] p = lifted(g, cols, rows, c, r, CLASP_RAISE);
            float[] t = towards(lifted(g, cols, rows, c + 0.5f, r, 0f), lifted(g, cols, rows, c - 0.5f, r, 0f), 1f);
            float[] n = {p[3], p[4], p[5]};
            float[] b = cross(n, t);
            float[] u = cross(b, n);
            float[] base = lifted(g, cols, rows, c, r, 0.004f);
            disc(out, p, base, u, b, n, CLASP_RADIUS, FACE, OUTER);
            float[] ring = add(p, n, 0.006f);
            ring(out, ring, p, u, b, n, CLASP_RADIUS * 0.72f, CLASP_RADIUS * 0.98f, OUTER);
            float[] gem = add(p, n, 0.012f);
            disc(out, gem, p, u, b, n, GEM_RADIUS, GEM, GEM);
            centers[side] = add(p, n, 0.004f);
        }
        chain(out, centers[0], centers[1], neck, chestZ);
    }

    private static void chain(Quads out, float[] a, float[] b, HoodShape.Frame neck, double chestZ) {
        float[][] pts = new float[LINKS + 1][];
        double[] q = new double[3];
        for (int k = 0; k <= LINKS; k++) {
            float s = k / (float) LINKS;
            float sag = 4f * s * (1f - s);
            q[0] = a[0] + (b[0] - a[0]) * s;
            q[1] = a[1] + (b[1] - a[1]) * s;
            q[2] = a[2] + (b[2] - a[2]) * s;
            neck.toLocal(q);
            q[1] -= CHAIN_SAG * sag;
            q[2] = Math.min(q[2] + 0.05 * sag, chestZ);   // menjuntai ke dada, nggak menembus
            neck.toWorld(q);
            pts[k] = new float[] {(float) q[0], (float) q[1], (float) q[2]};
        }
        double[] fwd = {0, 0, -1};
        double[] o = {0, 0, 0};
        neck.toWorld(o);
        neck.toWorld(fwd);
        float[] front = {(float) (fwd[0] - o[0]), (float) (fwd[1] - o[1]), (float) (fwd[2] - o[2])};
        front = unit(front);
        for (int k = 0; k < LINKS; k++) {
            float[] p0 = pts[k], p1 = pts[k + 1];
            float[] d = unit(new float[] {p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]});
            float len = dist(p0, p1) * 0.62f;
            float[] mid = {(p0[0] + p1[0]) / 2f, (p0[1] + p1[1]) / 2f, (p0[2] + p1[2]) / 2f};
            float[] side = unit(cross(d, front));
            float[] up = cross(side, d);
            // mata rantai berselang: datar lalu tegak
            boolean flat = k % 2 == 0;
            float[] w = flat ? side : up;
            float[] t = flat ? up : side;
            box(out, mid, d, w, t, len, LINK_WIDTH * 0.5f, LINK_THICK * 0.5f, flat ? OUTER : FACE, DARK);
        }
    }

    /** Cakram (segi-12) setinggi dari base ke p, menghadap n. */
    private static void disc(Quads out, float[] p, float[] base, float[] u, float[] b, float[] n, float radius,
                             int faceKind, int wallKind) {
        int seg = 12;
        float hx = p[0] - base[0], hy = p[1] - base[1], hz = p[2] - base[2];
        for (int k = 0; k < seg; k++) {
            double a0 = 2.0 * Math.PI * k / seg, a1 = 2.0 * Math.PI * (k + 1) / seg;
            float[] e0 = add(add(p, u, (float) Math.cos(a0) * radius), b, (float) Math.sin(a0) * radius);
            float[] e1 = add(add(p, u, (float) Math.cos(a1) * radius), b, (float) Math.sin(a1) * radius);
            out.face(p, p, e0, e1, n[0], n[1], n[2], faceKind);
            float[] f0 = {e0[0] - hx, e0[1] - hy, e0[2] - hz}, f1 = {e1[0] - hx, e1[1] - hy, e1[2] - hz};
            float[] r = {(e0[0] + e1[0]) / 2f - p[0], (e0[1] + e1[1]) / 2f - p[1], (e0[2] + e1[2]) / 2f - p[2]};
            out.face(e0, e1, f1, f0, r[0], r[1], r[2], wallKind);
        }
    }

    /** Cincin timbul di permukaan bros. */
    private static void ring(Quads out, float[] p, float[] floor, float[] u, float[] b, float[] n, float r0, float r1, int kind) {
        int seg = 12;
        for (int k = 0; k < seg; k++) {
            double a0 = 2.0 * Math.PI * k / seg, a1 = 2.0 * Math.PI * (k + 1) / seg;
            float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0), c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
            float[] i0 = add(add(p, u, c0 * r0), b, s0 * r0), i1 = add(add(p, u, c1 * r0), b, s1 * r0);
            float[] o0 = add(add(p, u, c0 * r1), b, s0 * r1), o1 = add(add(p, u, c1 * r1), b, s1 * r1);
            out.face(i0, o0, o1, i1, n[0], n[1], n[2], kind);
        }
    }

    /** Balok berpusat di c dengan sumbu a (setengah panjang ha), b (hb), n (hn). */
    private static void box(Quads out, float[] c, float[] a, float[] b, float[] n, float ha, float hb, float hn,
                            int topKind, int sideKind) {
        float[][] v = new float[8][];
        for (int k = 0; k < 8; k++) {
            float sa = (k & 1) == 0 ? -ha : ha, sb = (k & 2) == 0 ? -hb : hb, sn = (k & 4) == 0 ? -hn : hn;
            v[k] = add(add(add(c, a, sa), b, sb), n, sn);
        }
        out.face(v[4], v[5], v[7], v[6], n[0], n[1], n[2], topKind);
        out.face(v[0], v[2], v[3], v[1], -n[0], -n[1], -n[2], sideKind);
        out.face(v[0], v[1], v[5], v[4], -b[0], -b[1], -b[2], sideKind);
        out.face(v[2], v[6], v[7], v[3], b[0], b[1], b[2], sideKind);
        out.face(v[0], v[4], v[6], v[2], -a[0], -a[1], -a[2], sideKind);
        out.face(v[1], v[3], v[7], v[5], a[0], a[1], a[2], sideKind);
    }

    // ------------------------------------------------------------------ vektor kecil

    private static float[] add(float[] p, float[] d, float s) {
        return new float[] {p[0] + d[0] * s, p[1] + d[1] * s, p[2] + d[2] * s};
    }

    private static float[] scale(float[] d, float s) {
        return new float[] {d[0] * s, d[1] * s, d[2] * s};
    }

    private static float[] cross(float[] a, float[] b) {
        return new float[] {a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]};
    }

    private static float[] unit(float[] a) {
        float len = (float) Math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]);
        return len < 1.0E-9f ? new float[] {0f, 1f, 0f} : new float[] {a[0] / len, a[1] / len, a[2] / len};
    }

    private static float dist(float[] a, float[] b) {
        float x = a[0] - b[0], y = a[1] - b[1], z = a[2] - b[2];
        return (float) Math.sqrt(x * x + y * y + z * z);
    }
}
