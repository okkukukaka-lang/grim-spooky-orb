package com.shazammod.client.vfx;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * Petir buatan sendiri: jalur zig-zag dengan simpangan bertingkat (midpoint displacement) dan cabang-cabang.
 * Bentuknya dibuat ulang tiap beberapa tick dengan benih acak baru, jadi petirnya berkedip dan merambat;
 * di antara itu titik ujungnya tetap mengikuti sasaran yang bergerak dengan halus.
 */
public final class Lightning {
    private Lightning() {}

    /**
     * Jalur zig-zag dari a ke b: 2^depth segmen; simpangan tiap tingkat = roughness × panjang segmen,
     * tegak lurus arah petir. Hasil: xyz berurutan, (2^depth + 1) titik.
     */
    public static float[] path(double ax, double ay, double az, double bx, double by, double bz, int depth,
                               double roughness, Random random) {
        int n = 1 << depth;
        double[] px = new double[n + 1], py = new double[n + 1], pz = new double[n + 1];
        px[0] = ax; py[0] = ay; pz[0] = az;
        px[n] = bx; py[n] = by; pz[n] = bz;
        double dx = bx - ax, dy = by - ay, dz = bz - az;
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1.0E-6) {
            dx = 0; dy = 1; dz = 0;
        } else {
            dx /= len; dy /= len; dz /= len;
        }
        double[] e = new double[6];
        Draw.plane(dx, dy, dz, e);
        for (int step = n; step > 1; step /= 2) {
            double amp = roughness * len * step / n;
            for (int i = 0; i < n; i += step) {
                int m = i + step / 2;
                double a = random.nextDouble() * Math.PI * 2.0;
                double r = (random.nextDouble() - 0.5) * 2.0 * amp;
                px[m] = (px[i] + px[i + step]) * 0.5 + (e[0] * Math.cos(a) + e[3] * Math.sin(a)) * r;
                py[m] = (py[i] + py[i + step]) * 0.5 + (e[1] * Math.cos(a) + e[4] * Math.sin(a)) * r;
                pz[m] = (pz[i] + pz[i + step]) * 0.5 + (e[2] * Math.cos(a) + e[5] * Math.sin(a)) * r;
            }
        }
        float[] out = new float[(n + 1) * 3];
        for (int i = 0; i <= n; i++) {
            out[i * 3] = (float) px[i];
            out[i * 3 + 1] = (float) py[i];
            out[i * 3 + 2] = (float) pz[i];
        }
        return out;
    }

    /** Titik yang boleh bergerak (misalnya tangan pemain). */
    @FunctionalInterface
    public interface Anchor {
        Vec3 at(float partialTick);

        static Anchor fixed(Vec3 p) {
            return pt -> p;
        }

        /** Titik relatif posisi entity (ikut bergerak bersamanya). */
        static Anchor on(Entity entity, double dx, double dy, double dz) {
            return pt -> entity.getPosition(pt).add(dx, dy, dz);
        }
    }

    /** Satu busur petir di antara dua titik, dengan cabang, berkedip dan dibuat ulang tiap rate tick. */
    public static final class Arc extends Effect {
        private final Anchor from;
        private final Anchor to;
        private final int rgb;
        private final float width;
        private final int rate;
        private final int branches;
        private final double roughness;
        private final long seed;
        private final int depth;

        public Arc(Anchor from, Anchor to, int rgb, float width, int life, int rate, int branches, double roughness) {
            super(life);
            this.from = from;
            this.to = to;
            this.rgb = rgb;
            this.width = width;
            this.rate = Math.max(1, rate);
            this.branches = branches;
            this.roughness = roughness;
            this.seed = Vfx.random().nextLong();
            Vec3 a = from.at(0f), b = to.at(0f);
            double len = a.distanceTo(b);
            this.depth = len > 12 ? 6 : len > 4 ? 5 : len > 1.2 ? 4 : 3;
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float t = progress(pt);
            int gen = age / rate;
            float flicker = (age % rate == 0 ? 1f : 0.72f) * (0.85f + 0.15f * (float) Math.sin((age + pt) * 3.1f));
            float a = flicker * (1f - t * t);
            if (a <= 0.01f) {
                return;
            }
            Vec3 p0 = from.at(pt), p1 = to.at(pt);
            Random random = new Random(seed + gen * 7919L);
            float[] main = path(p0.x, p0.y, p0.z, p1.x, p1.y, p1.z, depth, roughness, random);
            int n = main.length / 3;
            d.polyline(main, n, width, width * 0.7f, rgb, 0xFFFFFF, a, a);
            for (int b = 0; b < branches; b++) {
                int i = 1 + random.nextInt(Math.max(1, n - 2));
                double sx = main[i * 3], sy = main[i * 3 + 1], sz = main[i * 3 + 2];
                double rest = p0.distanceTo(p1) * (1.0 - i / (double) (n - 1));
                double blen = Math.max(0.25, rest * (0.25 + random.nextDouble() * 0.3));
                double dx = p1.x - sx, dy = p1.y - sy, dz = p1.z - sz;
                double dl = Math.sqrt(dx * dx + dy * dy + dz * dz) + 1.0E-6;
                dx /= dl; dy /= dl; dz /= dl;
                double jx = (random.nextDouble() - 0.5) * 1.6, jy = (random.nextDouble() - 0.5) * 1.6, jz = (random.nextDouble() - 0.5) * 1.6;
                double ex = sx + (dx + jx) * blen, ey = sy + (dy + jy) * blen, ez = sz + (dz + jz) * blen;
                float[] br = path(sx, sy, sz, ex, ey, ez, Math.max(2, depth - 2), roughness * 1.1, random);
                d.polyline(br, br.length / 3, width * 0.55f, width * 0.12f, rgb, 0xFFFFFF, a * 0.8f, 0f);
            }
            // titik terang di kedua ujung
            d.glow(p0.x, p0.y, p0.z, width * 2.2f, rgb, a * 0.6f);
            d.glow(p1.x, p1.y, p1.z, width * 3.0f, rgb, a * 0.7f);
        }
    }

    /**
     * Listrik yang merayap di permukaan badan: tiap tick muncul busur-busur pendek di antara titik acak
     * di sekitar badan, hidup 2-3 tick. Ikut bergerak bersama entity.
     */
    public static final class Crackle extends Effect {
        private final Entity entity;
        private final int rgb;
        private final float perTick;
        private final float width;
        private final List<Spark> sparks = new ArrayList<>();
        private float budget;
        private float strength = 1f;
        private boolean stopped;

        private record Spark(double ax, double ay, double az, double bx, double by, double bz, long seed, int born, int life) {}

        public Crackle(Entity entity, int rgb, float perTick, float width, int life) {
            super(life);
            this.entity = entity;
            this.rgb = rgb;
            this.perTick = perTick;
            this.width = width;
        }

        /** Atur kekuatan (0-1) dari luar, misalnya mengikuti amarah yang memudar. */
        public Crackle strength(float value) {
            this.strength = value;
            return this;
        }

        /** Hentikan (efek dibuang di tick berikutnya). */
        public void stop() {
            stopped = true;
        }

        public boolean active() {
            return !stopped && age < life;
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (stopped || !entity.isAlive() || entity.isRemoved()) {
                return false;
            }
            budget += perTick * strength;
            float w = entity.getBbWidth() * 0.6f, h = entity.getBbHeight();
            while (budget >= 1f) {
                budget -= 1f;
                double ax = (Vfx.random().nextDouble() - 0.5) * 2 * w, ay = Vfx.random().nextDouble() * h, az = (Vfx.random().nextDouble() - 0.5) * 2 * w;
                double bx = ax + (Vfx.random().nextDouble() - 0.5) * 0.9, by = ay + (Vfx.random().nextDouble() - 0.5) * 0.9,
                        bz = az + (Vfx.random().nextDouble() - 0.5) * 0.9;
                sparks.add(new Spark(ax, ay, az, bx, by, bz, Vfx.random().nextLong(), age, 2 + Vfx.random().nextInt(2)));
            }
            sparks.removeIf(s -> age - s.born() > s.life());
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            if (sparks.isEmpty()) {
                return;
            }
            Vec3 base = entity.getPosition(d.partialTick);
            float fade = 1f - Math.max(0f, (age + d.partialTick - (life - 10)) / 10f);
            for (Spark s : sparks) {
                Random random = new Random(s.seed());
                float[] p = path(base.x + s.ax(), base.y + s.ay(), base.z + s.az(), base.x + s.bx(), base.y + s.by(),
                        base.z + s.bz(), 3, 0.35, random);
                float a = fade * strength * (1f - (age - s.born()) / (float) (s.life() + 1));
                d.polyline(p, p.length / 3, width, width * 0.6f, rgb, 0xFFFFFF, a, a * 0.6f);
            }
        }
    }
}
