package com.shazammod.client.vfx;

import java.util.function.Supplier;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/** Kumpulan efek dasar: kilatan, gelombang kejut, cangkang energi, kerucut udara, tiang cahaya, hangus, jejak, aura. */
public final class Fx {
    private Fx() {}

    static float outCubic(float t) {
        float u = 1f - t;
        return 1f - u * u * u;
    }

    static float outQuart(float t) {
        float u = 1f - t;
        return 1f - u * u * u * u;
    }

    /** Ledakan cahaya: mengembang cepat lalu padam. */
    public static final class Flash extends Effect {
        private final double x, y, z;
        private final float radius;
        private final int rgb;
        private final float strength;

        public Flash(Vec3 p, float radius, int rgb, int life, float strength) {
            super(life);
            this.x = p.x; this.y = p.y; this.z = p.z;
            this.radius = radius;
            this.rgb = rgb;
            this.strength = strength;
        }

        @Override
        public void renderGlow(Draw d) {
            float t = progress(d.partialTick);
            float r = radius * (0.5f + 0.5f * outCubic(t));
            float a = strength * (1f - t) * (1f - t);
            d.flare(x, y, z, r, rgb, a);
        }
    }

    /** Cincin gelombang kejut yang melebar di sebuah bidang (bisa menempel di tanah yang tidak rata). */
    public static final class Wave extends Effect {
        private final double x, y, z, nx, ny, nz;
        private final double radius, width;
        private final int rgb;
        private final float strength, fill;
        private final Draw.Height ground;
        private final boolean soft;

        public Wave(Vec3 p, Vec3 normal, double radius, double width, int rgb, int life, float strength, float fill,
                    Draw.Height ground) {
            this(p, normal, radius, width, rgb, life, strength, fill, ground, false);
        }

        /** soft = true: cincin debu (tembus pandang biasa), bukan cahaya. */
        public Wave(Vec3 p, Vec3 normal, double radius, double width, int rgb, int life, float strength, float fill,
                    Draw.Height ground, boolean soft) {
            super(life);
            this.x = p.x; this.y = p.y; this.z = p.z;
            Vec3 n = normal.normalize();
            this.nx = n.x; this.ny = n.y; this.nz = n.z;
            this.radius = radius;
            this.width = width;
            this.rgb = rgb;
            this.strength = strength;
            this.fill = fill;
            this.ground = ground;
            this.soft = soft;
        }

        private void draw(Draw d) {
            float t = progress(d.partialTick);
            double r = radius * outQuart(t);
            float a = strength * (float) Math.pow(1f - t, 1.4);
            d.ring(x, y, z, nx, ny, nz, r, width * (1.0 - 0.45 * t) + r * 0.04, rgb, a, fill, ground);
        }

        @Override
        public void renderGlow(Draw d) {
            if (!soft) {
                draw(d);
            }
        }

        @Override
        public void renderSoft(Draw d) {
            if (soft) {
                draw(d);
            }
        }
    }

    /** Cangkang energi (bola atau kubah) yang mengembang, tepinya paling terang. */
    public static final class Bubble extends Effect {
        private final double x, y, z, radius, upper, power;
        private final int rgb;
        private final float strength;
        private final boolean grow;

        public Bubble(Vec3 p, double radius, int rgb, int life, float strength, double upper, double power, boolean grow) {
            super(life);
            this.x = p.x; this.y = p.y; this.z = p.z;
            this.radius = radius;
            this.rgb = rgb;
            this.strength = strength;
            this.upper = upper;
            this.power = power;
            this.grow = grow;
        }

        @Override
        public void renderGlow(Draw d) {
            float t = progress(d.partialTick);
            double r = grow ? radius * outCubic(t) : radius * (1.0 + 0.06 * t);
            float a = strength * (float) Math.pow(1f - t, 1.2);
            d.shell(x, y, z, r, rgb, a, power, upper);
        }
    }

    /** Gelombang udara berbentuk kerucut yang melesat ke depan (tepukan, sonic boom). */
    public static final class Cone extends Effect {
        private final double x, y, z, dx, dy, dz, length, spread, power;
        private final int rgb;
        private final float strength;
        private final boolean soft;

        public Cone(Vec3 apex, Vec3 dir, double length, double spread, int rgb, int life, float strength, double power, boolean soft) {
            super(life);
            this.x = apex.x; this.y = apex.y; this.z = apex.z;
            Vec3 n = dir.normalize();
            this.dx = n.x; this.dy = n.y; this.dz = n.z;
            this.length = length;
            this.spread = spread;
            this.rgb = rgb;
            this.strength = strength;
            this.power = power;
            this.soft = soft;
        }

        private void draw(Draw d) {
            float t = progress(d.partialTick);
            double len = length * outCubic(t);
            float a = strength * (float) Math.pow(1f - t, 1.5);
            d.cone(x, y, z, dx, dy, dz, len, spread, rgb, a, power);
        }

        @Override
        public void renderGlow(Draw d) {
            if (!soft) {
                draw(d);
            }
        }

        @Override
        public void renderSoft(Draw d) {
            if (soft) {
                draw(d);
            }
        }
    }

    /** Tiang cahaya dari langit (saat petir sihir menyambar). */
    public static final class Pillar extends Effect {
        private final double x, y, z, height;
        private final float width;
        private final int rgb;

        public Pillar(Vec3 base, double height, float width, int rgb, int life) {
            super(life);
            this.x = base.x; this.y = base.y; this.z = base.z;
            this.height = height;
            this.width = width;
            this.rgb = rgb;
        }

        @Override
        public void renderGlow(Draw d) {
            float t = progress(d.partialTick);
            float a = (1f - t) * (1f - t);
            d.pillar(x, y, z, y + height, width * (0.6f + 0.8f * t), rgb, 0xFFFFFF, a);
            d.glow(x, y + 0.2, z, width * 3.5f * (0.6f + t), rgb, a * 0.8f);
        }
    }

    /** Bekas hangus di tanah: bara menyala dulu, lalu jadi noda gelap yang memudar. */
    public static final class Scorch extends Effect {
        private final double x, y, z, radius;
        private final Draw.Height ground;
        private final int heat;

        public Scorch(Vec3 p, double radius, int life, int heatTicks, Draw.Height ground) {
            super(life);
            this.x = p.x; this.y = p.y; this.z = p.z;
            this.radius = radius;
            this.ground = ground;
            this.heat = heatTicks;
        }

        @Override
        public void renderSoft(Draw d) {
            float t = progress(d.partialTick);
            float a = 0.62f * Math.min(1f, (age + d.partialTick) / 3f) * Math.min(1f, (1f - t) / 0.4f);
            d.disc(x, y, z, 0, 1, 0, radius, 0x120C08, a, 0f, ground);
        }

        @Override
        public void renderGlow(Draw d) {
            float h = 1f - (age + d.partialTick) / heat;
            if (h > 0f) {
                d.disc(x, y, z, 0, 1, 0, radius * 0.75, Particles.lerpColor(0xC03010, 0xFFB040, h), h * h * 0.9f, 0f, ground);
            }
        }
    }

    /** Jejak pita yang mengikuti sebuah titik (terjangan Mercury, menukik Atlas, jejak tangan saat terbang). */
    public static final class Trail extends Effect {
        private final Entity owner;
        private final Lightning.Anchor anchor;
        private final int rgb;
        private final float width;
        private final double[] px, py, pz;
        private int count;
        private final int keep;
        private int followUntil;
        private final boolean electric;

        /**
         * @param keep   berapa tick terakhir yang membentuk jejak
         * @param follow berapa tick jejak masih menambah titik baru (sesudahnya jejak memendek dan hilang)
         */
        public Trail(Entity owner, Lightning.Anchor anchor, int rgb, float width, int keep, int follow, boolean electric) {
            super(follow + keep + 2);
            this.owner = owner;
            this.anchor = anchor;
            this.rgb = rgb;
            this.width = width;
            this.keep = keep;
            this.px = new double[keep + 1];
            this.py = new double[keep + 1];
            this.pz = new double[keep + 1];
            this.followUntil = follow;
            this.electric = electric;
            push(anchor.at(1f));
        }

        /** Perpanjang masa jejak masih mengikuti (dipanggil tiap tick selama, misalnya, masih terbang kencang). */
        public void sustain(int ticks) {
            followUntil = Math.max(followUntil, age + ticks);
        }

        public boolean following() {
            return age < followUntil;
        }

        private void push(Vec3 p) {
            if (count == px.length) {
                System.arraycopy(px, 1, px, 0, px.length - 1);
                System.arraycopy(py, 1, py, 0, py.length - 1);
                System.arraycopy(pz, 1, pz, 0, pz.length - 1);
                count--;
            }
            px[count] = p.x; py[count] = p.y; pz[count] = p.z;
            count++;
        }

        @Override
        public boolean tick(ClientLevel level) {
            age++;
            if (age < followUntil && owner.isAlive()) {
                push(anchor.at(1f));
            } else if (count > 0) {   // jejak tertinggal: memendek dari belakang
                System.arraycopy(px, 1, px, 0, Math.max(0, count - 1));
                System.arraycopy(py, 1, py, 0, Math.max(0, count - 1));
                System.arraycopy(pz, 1, pz, 0, Math.max(0, count - 1));
                count--;
            }
            return count > 1 || age < followUntil;
        }

        @Override
        public void renderGlow(Draw d) {
            if (count < 2) {
                return;
            }
            float pt = d.partialTick;
            boolean live = age < followUntil;
            Vec3 head = live ? anchor.at(pt) : new Vec3(px[count - 1], py[count - 1], pz[count - 1]);
            int n = count + (live ? 1 : 0);
            float[] pts = new float[n * 3];
            for (int i = 0; i < count; i++) {
                pts[i * 3] = (float) px[i]; pts[i * 3 + 1] = (float) py[i]; pts[i * 3 + 2] = (float) pz[i];
            }
            if (live) {
                pts[count * 3] = (float) head.x; pts[count * 3 + 1] = (float) head.y; pts[count * 3 + 2] = (float) head.z;
            }
            float fade = live ? 1f : Math.max(0f, count / (float) keep);
            d.polyline(pts, n, width * 0.12f, width, rgb, 0xFFFFFF, 0f, 0.85f * fade);
            if (electric && n > 3) {   // listrik yang berkelok di sepanjang jejak
                java.util.Random random = new java.util.Random(age * 31L + owner.getId());
                float[] arc = Lightning.path(pts[0], pts[1], pts[2], head.x, head.y, head.z, 4, 0.16, random);
                d.polyline(arc, arc.length / 3, width * 0.06f, width * 0.22f, rgb, 0xFFFFFF, 0.2f * fade, 0.9f * fade);
            }
        }
    }

    /** Cincin yang melesat searah sumbunya sambil membesar (gelombang suara/udara yang menjauh). */
    public static final class Ripple extends Effect {
        private final double x, y, z, dx, dy, dz, distance, r0, r1, width;
        private final int rgb;
        private final float strength;
        private final boolean soft;

        public Ripple(Vec3 start, Vec3 dir, double distance, double r0, double r1, double width, int rgb, int life,
                      float strength, boolean soft) {
            super(life);
            this.x = start.x; this.y = start.y; this.z = start.z;
            Vec3 n = dir.normalize();
            this.dx = n.x; this.dy = n.y; this.dz = n.z;
            this.distance = distance;
            this.r0 = r0;
            this.r1 = r1;
            this.width = width;
            this.rgb = rgb;
            this.strength = strength;
            this.soft = soft;
        }

        private void draw(Draw d) {
            float t = progress(d.partialTick);
            float e = outCubic(t);
            double r = r0 + (r1 - r0) * e;
            double s = distance * e;
            float a = strength * (float) Math.pow(1f - t, 1.3);
            d.ring(x + dx * s, y + dy * s, z + dz * s, dx, dy, dz, r, width * (1.0 - 0.4 * t), rgb, a, 0.1f, null);
        }

        @Override
        public void renderGlow(Draw d) {
            if (!soft) {
                draw(d);
            }
        }

        @Override
        public void renderSoft(Draw d) {
            if (soft) {
                draw(d);
            }
        }
    }

    /** Cahaya yang menempel di sebuah titik bergerak (kepalan yang mengumpulkan tenaga), membesar sampai puncak. */
    public static final class Glow extends Effect {
        private final Entity owner;
        private final Lightning.Anchor anchor;
        private final float radius;
        private final int rgb;
        private final int peak;

        public Glow(Entity owner, Lightning.Anchor anchor, float radius, int rgb, int life, int peak) {
            super(life);
            this.owner = owner;
            this.anchor = anchor;
            this.radius = radius;
            this.rgb = rgb;
            this.peak = Math.max(1, peak);
        }

        @Override
        public boolean tick(ClientLevel level) {
            return owner.isAlive() && super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = age + d.partialTick;
            float k = time < peak ? time / peak : Math.max(0f, 1f - (time - peak) / Math.max(1f, life - peak));
            float pulse = 0.85f + 0.15f * (float) Math.sin(time * 1.9f);
            Vec3 p = anchor.at(d.partialTick);
            d.flare(p.x, p.y, p.z, radius * (0.4f + 0.6f * k) * pulse, rgb, k * pulse);
        }
    }

    /** Nyala emas di sekeliling badan (Kulit Achilles): lidah-lidah cahaya yang naik dan berkelok. */
    public static final class Aura extends Effect {
        private final Entity entity;
        private final int rgb;
        private final Supplier<Float> strength;

        public Aura(Entity entity, int rgb, int life, Supplier<Float> strength) {
            super(life);
            this.entity = entity;
            this.rgb = rgb;
            this.strength = strength;
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (!entity.isAlive()) {
                return false;
            }
            float s = strength.get();
            if (s > 0.2f && age % 2 == 0) {
                Vec3 p = entity.position();
                double a = Vfx.random().nextDouble() * Math.PI * 2.0;
                double r = entity.getBbWidth() * (0.55 + Vfx.random().nextDouble() * 0.3);
                Vfx.ember(p.x + Math.cos(a) * r, p.y + Vfx.random().nextDouble() * entity.getBbHeight() * 0.7,
                        p.z + Math.sin(a) * r, 0, 0.035 + Vfx.random().nextDouble() * 0.03, 0, 0.07f, 18 + Vfx.random().nextInt(10));
            }
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float s = strength.get();
            if (s <= 0.01f) {
                return;
            }
            float pt = d.partialTick;
            float time = age + pt;
            Vec3 p = entity.getPosition(pt);
            double h = entity.getBbHeight();
            double w = entity.getBbWidth() * 0.62;
            int wisps = 9;
            for (int k = 0; k < wisps; k++) {
                double ang = k * Math.PI * 2.0 / wisps + time * 0.035;
                double cx = p.x + Math.cos(ang) * w, cz = p.z + Math.sin(ang) * w;
                int steps = 6;
                double lastX = cx, lastY = p.y, lastZ = cz;
                for (int i = 1; i <= steps; i++) {
                    double f = i / (double) steps;
                    double sway = Math.sin(time * 0.32 + k * 1.7 + f * 4.0) * 0.09 * f;
                    double nx = cx + Math.cos(ang + Math.PI / 2) * sway, nz = cz + Math.sin(ang + Math.PI / 2) * sway;
                    double ny = p.y + h * (0.05 + 1.0 * f) * (0.85 + 0.15 * Math.sin(time * 0.21 + k));
                    float a0 = (float) Math.sin(Math.PI * (f - 1.0 / steps)) * 0.55f * s;
                    float a1 = (float) Math.sin(Math.PI * f) * 0.55f * s;
                    d.line(lastX, lastY, lastZ, nx, ny, nz, 0.2f, 0.12f, rgb, a0, a1);
                    lastX = nx; lastY = ny; lastZ = nz;
                }
            }
            d.glow(p.x, p.y + h * 0.55, p.z, (float) (h * 0.75), rgb, 0.18f * s);
        }
    }
}
