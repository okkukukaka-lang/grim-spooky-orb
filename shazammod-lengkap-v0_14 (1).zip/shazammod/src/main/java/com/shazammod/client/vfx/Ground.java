package com.shazammod.client.vfx;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.joml.Quaternionf;

import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Efek yang menempel di tanah: peta tinggi tanah, retakan menyala, dan pecahan blok yang beterbangan. */
public final class Ground {
    private Ground() {}

    /** Tinggi tanah di sekitar sebuah titik (grid melingkar), supaya cincin & retakan mengikuti permukaan. */
    public static final class Map implements Draw.Height {
        private final int angles;
        private final int radii;
        private final double maxRadius;
        private final double[] offset;   // tinggi relatif pusat
        public final double centerY;
        public final BlockState surface;
        public final boolean found;

        private Map(int angles, int radii, double maxRadius, double[] offset, double centerY, BlockState surface, boolean found) {
            this.angles = angles;
            this.radii = radii;
            this.maxRadius = maxRadius;
            this.offset = offset;
            this.centerY = centerY;
            this.surface = surface;
            this.found = found;
        }

        /** Ambil tinggi tanah di sekitar p (p.y = kira-kira kaki). viewer = entity apa saja buat konteks tabrakan. */
        public static Map sample(ClientLevel level, Entity viewer, Vec3 p, double maxRadius, int angles, int radii) {
            double[] hit = new double[angles * (radii + 1)];
            BlockHitResult center = down(level, viewer, p.x, p.y, p.z);
            boolean found = center.getType() != HitResult.Type.MISS;
            double cy = found ? center.getLocation().y : p.y;
            BlockState surface = found ? level.getBlockState(center.getBlockPos()) : Blocks.STONE.defaultBlockState();
            for (int a = 0; a < angles; a++) {
                double ang = Math.PI * 2.0 * a / angles;
                double last = 0.0;
                for (int r = 0; r <= radii; r++) {
                    double rad = maxRadius * r / radii;
                    double x = p.x + Math.cos(ang) * rad, z = p.z + Math.sin(ang) * rad;
                    BlockHitResult h = r == 0 ? center : down(level, viewer, x, cy + last, z);
                    if (h.getType() != HitResult.Type.MISS) {
                        last = h.getLocation().y - cy;
                    }
                    hit[a * (radii + 1) + r] = last;
                }
            }
            return new Map(angles, radii, maxRadius, hit, cy, surface, found);
        }

        private static BlockHitResult down(ClientLevel level, Entity viewer, double x, double y, double z) {
            return level.clip(new ClipContext(new Vec3(x, y + 1.6, z), new Vec3(x, y - 3.5, z),
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.ANY, viewer));
        }

        /** Titik tanah di pusat. */
        public Vec3 center(Vec3 p) {
            return new Vec3(p.x, centerY + 0.04, p.z);
        }

        @Override
        public double at(double angle, double radius) {
            double a = angle / (Math.PI * 2.0) * angles;
            a = ((a % angles) + angles) % angles;
            int a0 = (int) Math.floor(a), a1 = (a0 + 1) % angles;
            double fa = a - Math.floor(a);
            double r = Math.max(0.0, Math.min(radii, radius / maxRadius * radii));
            int r0 = Math.min((int) Math.floor(r), radii), r1 = Math.min(r0 + 1, radii);
            double fr = r - r0;
            double h00 = offset[a0 * (radii + 1) + r0], h01 = offset[a0 * (radii + 1) + r1];
            double h10 = offset[a1 * (radii + 1) + r0], h11 = offset[a1 * (radii + 1) + r1];
            double h0 = h00 + (h01 - h00) * fr, h1 = h10 + (h11 - h10) * fr;
            return h0 + (h1 - h0) * fa + 0.04;
        }

        /** Warna debu dari jenis tanah. */
        public int dustColor(ClientLevel level, Vec3 p) {
            int c = surface.getMapColor(level, BlockPos.containing(p.x, centerY - 0.5, p.z)).col;
            return c == 0 ? 0x8A7A66 : Particles.lerpColor(c, 0xB8AE9C, 0.35f);
        }
    }

    /** Retakan tanah yang menjalar dari titik hantaman: membara emas-jingga lalu mendingin jadi celah gelap. */
    public static final class Cracks extends Effect {
        private final double cx, cy, cz;
        private final Map ground;
        private final List<float[]> lines = new ArrayList<>();   // tiap garis: {x0, z0, x1, z1, jarak dari pusat, lebar}
        private final float reach;
        private final int heat;
        private final int hot;

        public Cracks(Vec3 center, Map ground, int count, float length, int life, int heatTicks, int hotColor, long seed) {
            super(life);
            this.cx = center.x; this.cy = ground.centerY; this.cz = center.z;
            this.ground = ground;
            this.heat = heatTicks;
            this.hot = hotColor;
            Random random = new Random(seed);
            float max = 0f;
            for (int k = 0; k < count; k++) {
                double ang = Math.PI * 2.0 * (k + random.nextDouble() * 0.6) / count;
                max = Math.max(max, grow(random, Math.cos(ang) * 0.25, Math.sin(ang) * 0.25, ang,
                        length * (0.6f + random.nextFloat() * 0.5f), 0.09f, 0, 0f));
            }
            this.reach = max;
        }

        /** Satu retakan berkelok dari titik (x, z) yang kadang bercabang. Mengembalikan jarak terjauhnya dari pusat. */
        private float grow(Random random, double x, double z, double dir, float length, float width, int depth, float startDist) {
            float dist = startDist;
            float far = 0f;
            int segments = Math.max(2, (int) (length / 0.32f));
            for (int i = 0; i < segments; i++) {
                dir += (random.nextDouble() - 0.5) * 0.9;
                double step = 0.24 + random.nextDouble() * 0.16;
                double nx = x + Math.cos(dir) * step, nz = z + Math.sin(dir) * step;
                float w = width * (1f - i / (float) segments * 0.75f);
                lines.add(new float[] {(float) x, (float) z, (float) nx, (float) nz, dist, w});
                dist += (float) step;
                far = Math.max(far, dist);
                if (depth < 2 && random.nextFloat() < 0.22f) {
                    double side = (random.nextBoolean() ? 1 : -1) * (0.5 + random.nextDouble() * 0.5);
                    far = Math.max(far, grow(random, nx, nz, dir + side, length * 0.45f, w * 0.7f, depth + 1, dist));
                }
                x = nx;
                z = nz;
            }
            return far;
        }

        /** Seberapa jauh retakan sudah menjalar (0-1) pada waktu t. */
        private float spread(float time) {
            return Fx.outCubic(Math.min(1f, time / 5f));
        }

        private double h(double x, double z) {
            double r = Math.sqrt(x * x + z * z);
            return ground.at(Math.atan2(z, x), r) + 0.012;
        }

        @Override
        public void renderSoft(Draw d) {
            float time = age + d.partialTick;
            float shown = spread(time) * reach;
            float fade = Math.min(1f, (1f - progress(d.partialTick)) / 0.35f);
            for (float[] l : lines) {
                if (l[4] > shown) {
                    continue;
                }
                d.flatLine(cx + l[0], cy + h(l[0], l[1]), cz + l[1], cx + l[2], cy + h(l[2], l[3]), cz + l[3], 0, 1, 0,
                        l[5], 0x0E0906, 0.85f * fade, 0.85f * fade);
            }
        }

        @Override
        public void renderGlow(Draw d) {
            float time = age + d.partialTick;
            float k = 1f - time / heat;
            if (k <= 0f) {
                return;
            }
            float shown = spread(time) * reach;
            int color = Particles.lerpColor(0xC02810, hot, k);
            for (float[] l : lines) {
                if (l[4] > shown) {
                    continue;
                }
                float tip = Math.min(1f, (shown - l[4]) / 0.6f);   // ujung yang baru menjalar paling terang
                float a = k * k * (0.55f + 0.45f * (1f - tip)) + 0.15f * k;
                d.flatLine(cx + l[0], cy + h(l[0], l[1]) + 0.004, cz + l[1], cx + l[2], cy + h(l[2], l[3]) + 0.004, cz + l[3],
                        0, 1, 0, l[5] * 2.4f, color, a, a);
            }
        }
    }

    /** Pecahan blok sungguhan (tekstur tanahnya) yang terlempar, berputar, jatuh, dan memantul. */
    public static final class Debris extends Effect {
        private final BlockState state;
        private final int n;
        private final double[] x, y, z, ox, oy, oz, vx, vy, vz, floor;
        private final float[] ax, ay, az, angle, spin, size;

        public Debris(Vec3 center, Map ground, int count, double speed, double up, double ring, int life) {
            super(life);
            this.state = ground.surface.getRenderShape() == RenderShape.MODEL ? ground.surface : Blocks.STONE.defaultBlockState();
            this.n = count;
            x = new double[n]; y = new double[n]; z = new double[n];
            ox = new double[n]; oy = new double[n]; oz = new double[n];
            vx = new double[n]; vy = new double[n]; vz = new double[n];
            floor = new double[n];
            ax = new float[n]; ay = new float[n]; az = new float[n];
            angle = new float[n]; spin = new float[n]; size = new float[n];
            Random random = new Random(Vfx.random().nextLong());
            for (int i = 0; i < n; i++) {
                double a = random.nextDouble() * Math.PI * 2.0;
                double r = ring * (0.4 + random.nextDouble() * 0.8);
                x[i] = center.x + Math.cos(a) * r;
                z[i] = center.z + Math.sin(a) * r;
                y[i] = ground.centerY + ground.at(a, r) + 0.1;
                ox[i] = x[i]; oy[i] = y[i]; oz[i] = z[i];
                double s = speed * (0.5 + random.nextDouble() * 0.7);
                vx[i] = Math.cos(a) * s;
                vz[i] = Math.sin(a) * s;
                vy[i] = up * (0.6 + random.nextDouble() * 0.7);
                floor[i] = ground.centerY;
                ax[i] = (float) (random.nextDouble() - 0.5);
                ay[i] = (float) (random.nextDouble() - 0.5);
                az[i] = (float) (random.nextDouble() - 0.5);
                float len = (float) Math.sqrt(ax[i] * ax[i] + ay[i] * ay[i] + az[i] * az[i]) + 1.0E-4f;
                ax[i] /= len; ay[i] /= len; az[i] /= len;
                angle[i] = random.nextFloat() * 6.28f;
                spin[i] = (random.nextFloat() - 0.5f) * 1.5f;
                size[i] = 0.12f + random.nextFloat() * 0.2f;
            }
        }

        @Override
        public boolean tick(ClientLevel level) {
            for (int i = 0; i < n; i++) {
                ox[i] = x[i]; oy[i] = y[i]; oz[i] = z[i];
                vy[i] -= 0.06;
                vx[i] *= 0.98; vy[i] *= 0.98; vz[i] *= 0.98;
                x[i] += vx[i]; y[i] += vy[i]; z[i] += vz[i];
                angle[i] += spin[i];
                double fl = floor[i] + size[i] * 0.5;
                if (y[i] < fl) {
                    y[i] = fl;
                    if (Math.abs(vy[i]) > 0.08) {
                        vy[i] = -vy[i] * 0.32;
                        spin[i] *= 0.6f;
                    } else {
                        vy[i] = 0;
                        spin[i] *= 0.7f;
                    }
                    vx[i] *= 0.55;
                    vz[i] *= 0.55;
                }
            }
            return super.tick(level);
        }

        @Override
        public void renderSolid(PoseStack poseStack, MultiBufferSource buffers, double camX, double camY, double camZ,
                                float partialTick) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.level == null) {
                return;
            }
            float shrink = Math.min(1f, (life - age - partialTick) / 10f);
            if (shrink <= 0f) {
                return;
            }
            for (int i = 0; i < n; i++) {
                double px = ox[i] + (x[i] - ox[i]) * partialTick;
                double py = oy[i] + (y[i] - oy[i]) * partialTick;
                double pz = oz[i] + (z[i] - oz[i]) * partialTick;
                float s = size[i] * shrink;
                poseStack.pushPose();
                poseStack.translate(px - camX, py - camY, pz - camZ);
                poseStack.mulPose(new Quaternionf().rotationAxis(angle[i] + spin[i] * partialTick, ax[i], ay[i], az[i]));
                poseStack.scale(s, s, s);
                poseStack.translate(-0.5f, -0.5f, -0.5f);
                int light = LevelRenderer.getLightColor(mc.level, BlockPos.containing(px, py + 0.3, pz));
                mc.getBlockRenderer().renderSingleBlock(state, poseStack, buffers, light, OverlayTexture.NO_OVERLAY);
                poseStack.popPose();
            }
        }
    }

    /** Batu-batu kecil yang terangkat dan mengorbit pelan di sekeliling badan (Zeus Rage). */
    public static final class Orbit extends Effect {
        private final Entity entity;
        private final BlockState state;
        private final int n;
        private final float[] radius, height, phase, speed, size, tumble;
        private final Supplier strength;

        @FunctionalInterface
        public interface Supplier {
            float get();
        }

        public Orbit(Entity entity, BlockState state, int count, int life, Supplier strength) {
            super(life);
            this.entity = entity;
            this.state = state.getRenderShape() == RenderShape.MODEL ? state : Blocks.STONE.defaultBlockState();
            this.n = count;
            this.strength = strength;
            radius = new float[n]; height = new float[n]; phase = new float[n]; speed = new float[n]; size = new float[n];
            tumble = new float[n];
            Random random = new Random(Vfx.random().nextLong());
            for (int i = 0; i < n; i++) {
                radius[i] = 1.3f + random.nextFloat() * 1.1f;
                height[i] = 0.2f + random.nextFloat() * 1.8f;
                phase[i] = random.nextFloat() * 6.28f;
                speed[i] = (0.025f + random.nextFloat() * 0.03f) * (random.nextBoolean() ? 1 : -1);
                size[i] = 0.1f + random.nextFloat() * 0.14f;
                tumble[i] = random.nextFloat() * 6.28f;
            }
        }

        private boolean stopped;

        public void stop() {
            stopped = true;
        }

        public boolean active() {
            return !stopped && age < life;
        }

        @Override
        public boolean tick(ClientLevel level) {
            return !stopped && entity.isAlive() && super.tick(level);
        }

        @Override
        public void renderSolid(PoseStack poseStack, MultiBufferSource buffers, double camX, double camY, double camZ,
                                float partialTick) {
            Minecraft mc = Minecraft.getInstance();
            float s0 = strength.get();
            if (mc.level == null || s0 <= 0.02f) {
                return;
            }
            float time = age + partialTick;
            float rise = Fx.outCubic(Math.min(1f, time / 20f));
            Vec3 p = entity.getPosition(partialTick);
            for (int i = 0; i < n; i++) {
                double a = phase[i] + time * speed[i];
                double px = p.x + Math.cos(a) * radius[i];
                double pz = p.z + Math.sin(a) * radius[i];
                double py = p.y + height[i] * rise + Math.sin(time * 0.08 + phase[i]) * 0.12;
                float s = size[i] * s0;
                poseStack.pushPose();
                poseStack.translate(px - camX, py - camY, pz - camZ);
                poseStack.mulPose(new Quaternionf().rotationXYZ(tumble[i] + time * 0.03f, time * 0.02f + i, tumble[i] * 0.5f));
                poseStack.scale(s, s, s);
                poseStack.translate(-0.5f, -0.5f, -0.5f);
                int light = LevelRenderer.getLightColor(mc.level, BlockPos.containing(px, py, pz));
                mc.getBlockRenderer().renderSingleBlock(state, poseStack, buffers, light, OverlayTexture.NO_OVERLAY);
                poseStack.popPose();
            }
        }
    }
}
