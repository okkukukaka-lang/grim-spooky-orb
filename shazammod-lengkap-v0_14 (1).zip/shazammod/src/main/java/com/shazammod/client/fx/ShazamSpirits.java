package com.shazammod.client.fx;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamItems;
import com.shazammod.ShazamMod;
import com.shazammod.client.anim.Ease;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Roh enam dewa (S-H-A-Z-A-M) saat transformasi: bangkit dari tanah satu per satu, melayang mengelilingi
 * pemain, lalu melesat ke kepalan yang terangkat dan lenyap tepat saat petir menyambar.
 * Tiap roh bercahaya dengan warna totem dewanya, dan totem itu berputar di atas kepalanya.
 */
public final class ShazamSpirits {
    private ShazamSpirits() {}

    /** Urutan S-H-A-Z-A-M: Solomon, Hercules, Atlas, Zeus, Achilles, Mercury (warna dari totemnya). */
    private static final int[] COLORS = {0xA880E0, 0x7CCB5E, 0xE08A5A, 0x74B4FF, 0xFFD966, 0x5FD8E0};
    private static final float RADIUS = 2.6f;          // jarak roh dari pemain (blok)
    private static final float APPEAR_GAP = 2f;        // roh bangkit bergantian tiap 2 tick
    private static final float APPEAR_TIME = 8f;
    private static final float CONVERGE_START = ShazamAnim.SUMMON_TICKS + ShazamAnim.TRANSFORM_WINDUP - 2f;   // saat petir mulai turun
    private static final float STRIKE = ShazamAnim.SUMMON_TICKS + ShazamAnim.TRANSFORM_STRIKE;
    private static final float FIST_HEIGHT = 2.3f;     // titik kepalan di atas kepala
    private static final ResourceLocation WHITE = ShazamMod.id("textures/entity/shazam_white.png");
    private static final ResourceLocation SWIRL = ShazamMod.id("textures/entity/fx/spirit.png");

    private static final Map<Integer, Long> RITUALS = new HashMap<>();
    private static PlayerModel<AbstractClientPlayer> model;
    private static ItemStack[] totems;

    public static void start(AbstractClientPlayer player) {
        RITUALS.put(player.getId(), player.level().getGameTime());
    }

    public static void clear() {
        RITUALS.clear();
    }

    private static float appear(int i, float t) {
        return Mth.clamp((t - i * APPEAR_GAP) / APPEAR_TIME, 0f, 1f);
    }

    /** 0 = mengelilingi, 1 = sudah sampai di kepalan (makin cepat di akhir). */
    private static float converge(float t) {
        float c = Mth.clamp((t - CONVERGE_START) / (STRIKE - CONVERGE_START), 0f, 1f);
        return c * c;
    }

    /** Posisi roh ke-i relatif kaki pemain (blok, sebelum dikali ukuran badan). */
    private static Vec3 offset(int i, float t) {
        float c = converge(t);
        float a = Ease.OUT_CUBIC.apply(appear(i, t));
        double angle = Math.toRadians(i * 60.0 + t * 3.0 + c * 160.0);
        double radius = Mth.lerp(c, RADIUS, 0.12f);
        double hover = Mth.lerp(a, -1.4f, 0.3f) + 0.08 * Math.sin((t + i * 7f) * 0.15f);   // bangkit dari tanah
        double height = Mth.lerp(c, (float) hover, FIST_HEIGHT);
        return new Vec3(Math.sin(angle) * radius, height, Math.cos(angle) * radius);
    }


    // ------------------------------------------------------------------ tick: suara & partikel

    public static void tick(ClientLevel level) {
        long now = level.getGameTime();
        Iterator<Map.Entry<Integer, Long>> it = RITUALS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Long> entry = it.next();
            float t = now - entry.getValue();
            if (!(level.getEntity(entry.getKey()) instanceof AbstractClientPlayer player) || t > STRIKE) {
                it.remove();
                continue;
            }
            Vec3 feet = player.position();
            float scale = player.getScale();
            for (int i = 0; i < COLORS.length; i++) {
                if (appear(i, t) <= 0f) {
                    continue;
                }
                Vec3 p = feet.add(offset(i, t).scale(scale));
                if (t == i * APPEAR_GAP + 1f) {   // tiap roh datang dengan denting yang makin tinggi
                    level.playLocalSound(p.x, p.y, p.z, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS,
                            1.2f, 0.6f + i * 0.14f, false);
                }
                float size = Mth.lerp(converge(t), 1f, 0.3f) * scale;
                Vfx.mote(p.x + (level.random.nextDouble() - 0.5) * 0.6 * size, p.y + level.random.nextDouble() * 1.8 * size,
                        p.z + (level.random.nextDouble() - 0.5) * 0.6 * size, 0, 0.012, 0, COLORS[i], 0.1f * size, 14);
            }
            if (t == STRIKE) {
                // Roh-roh menyatu ke kepalan bersama petir: semburan cahaya enam warna
                Vec3 fist = feet.add(0, FIST_HEIGHT * scale, 0);
                for (int i = 0; i < COLORS.length; i++) {
                    for (int k = 0; k < 10; k++) {
                        Vfx.mote(fist.x, fist.y, fist.z, (level.random.nextDouble() - 0.5) * 0.5,
                                (level.random.nextDouble() - 0.3) * 0.4, (level.random.nextDouble() - 0.5) * 0.5,
                                COLORS[i], 0.14f, 16 + level.random.nextInt(10));
                    }
                }
                for (int k = 0; k < 10; k++) {
                    Vfx.glint(fist.x + (level.random.nextDouble() - 0.5) * 1.4, fist.y + (level.random.nextDouble() - 0.5) * 1.4,
                            fist.z + (level.random.nextDouble() - 0.5) * 1.4, 0xFFFFFF, 0.35f, 10 + level.random.nextInt(6));
                }
            }
        }
    }

    // ------------------------------------------------------------------ render (di dunia, kelihatan juga dari mata sendiri)

    public static void render(RenderLevelStageEvent event) {
        if (RITUALS.isEmpty() || event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) {
            return;
        }
        if (model == null) {
            model = new PlayerModel<>(mc.getEntityModels().bakeLayer(ModelLayers.PLAYER), false);
            model.hat.visible = false;
            model.jacket.visible = false;
            model.leftSleeve.visible = false;
            model.rightSleeve.visible = false;
            model.leftPants.visible = false;
            model.rightPants.visible = false;
        }
        if (totems == null) {
            totems = new ItemStack[] {
                    new ItemStack(ShazamItems.TOTEM_SOLOMON.get()), new ItemStack(ShazamItems.TOTEM_HERCULES.get()),
                    new ItemStack(ShazamItems.TOTEM_ATLAS.get()), new ItemStack(ShazamItems.TOTEM_ZEUS.get()),
                    new ItemStack(ShazamItems.TOTEM_ACHILLES.get()), new ItemStack(ShazamItems.TOTEM_MERCURY.get())};
        }
        float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        Vec3 cam = event.getCamera().getPosition();
        PoseStack poseStack = event.getPoseStack();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        for (Map.Entry<Integer, Long> entry : RITUALS.entrySet()) {
            if (!(level.getEntity(entry.getKey()) instanceof AbstractClientPlayer player)) {
                continue;
            }
            float t = level.getGameTime() - entry.getValue() + partialTick;
            if (t >= STRIKE) {
                continue;
            }
            Vec3 feet = player.getPosition(partialTick);
            float scale = player.getScale();
            float c = converge(t);
            for (int i = 0; i < COLORS.length; i++) {
                float a = appear(i, t);
                if (a <= 0f) {
                    continue;
                }
                Vec3 p = feet.add(offset(i, t).scale(scale));
                float size = Mth.lerp(c, 1f, 0.3f) * scale;
                renderSpirit(poseStack, buffers, p, feet, cam, COLORS[i], a, size, t, i, c);
                renderTotem(mc, level, poseStack, buffers, totems[i], p, cam, a, size, t, i);
            }
        }
        buffers.endBatch();
    }

    private static void renderSpirit(PoseStack poseStack, MultiBufferSource buffers, Vec3 p, Vec3 feet, Vec3 cam,
                                     int color, float appear, float size, float t, int i, float converge) {
        // Pose melayang: lengan terbuka memberkati, lalu terangkat menggapai kepalan saat menyatu
        float sway = Mth.sin((t + i * 5f) * 0.12f) * 0.08f;
        float reach = Mth.lerp(converge, 0f, -2.4f);
        setRotation(model.head, 0.15f, 0f, 0f);
        setRotation(model.body, 0f, 0f, 0f);
        setRotation(model.rightArm, -0.25f + sway + reach, 0f, 0.5f * (1f - converge));
        setRotation(model.leftArm, -0.25f - sway + reach, 0f, -0.5f * (1f - converge));
        setRotation(model.rightLeg, 0.14f, 0f, 0.04f);
        setRotation(model.leftLeg, 0.06f, 0f, -0.04f);

        poseStack.pushPose();
        poseStack.translate(p.x - cam.x, p.y - cam.y, p.z - cam.z);
        float yaw = (float) Math.toDegrees(Math.atan2(-(feet.x - p.x), feet.z - p.z));   // menghadap ke pemain
        poseStack.mulPose(Axis.YP.rotationDegrees(180f - yaw));
        poseStack.scale(-size, -size, size);
        poseStack.translate(0f, -1.501f, 0f);

        // Tubuh tembus pandang yang bercahaya, lalu pusaran energi berwarna dewanya
        int alpha = (int) (appear * 150f);
        model.renderToBuffer(poseStack, buffers.getBuffer(RenderType.entityTranslucent(WHITE)),
                LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, (alpha << 24) | color);
        float scroll = t * 0.02f;
        int r = (int) (((color >> 16) & 0xFF) * appear), g = (int) (((color >> 8) & 0xFF) * appear), b = (int) ((color & 0xFF) * appear);
        model.renderToBuffer(poseStack, buffers.getBuffer(RenderType.energySwirl(SWIRL, scroll % 1f, (scroll * 0.7f) % 1f)),
                LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, 0xFF000000 | (r << 16) | (g << 8) | b);
        poseStack.popPose();
    }

    private static void setRotation(ModelPart part, float x, float y, float z) {
        part.xRot = x;
        part.yRot = y;
        part.zRot = z;
    }

    /** Totem dewa berputar di atas kepala roh. */
    private static void renderTotem(Minecraft mc, ClientLevel level, PoseStack poseStack, MultiBufferSource buffers,
                                    ItemStack stack, Vec3 p, Vec3 cam, float appear, float size, float t, int i) {
        poseStack.pushPose();
        poseStack.translate(p.x - cam.x, p.y - cam.y + 2.15 * size, p.z - cam.z);
        poseStack.mulPose(Axis.YP.rotationDegrees(t * 8f + i * 60f));
        float s = 1.1f * size * (0.3f + 0.7f * appear);
        poseStack.scale(s, s, s);
        mc.getItemRenderer().renderStatic(stack, ItemDisplayContext.GROUND, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY,
                poseStack, buffers, level, 0);
        poseStack.popPose();
    }
}
