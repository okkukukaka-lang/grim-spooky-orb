package com.shazammod.client.vfx;

import java.util.function.Supplier;

import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

/**
 * 0.34 Efek sinematik HD untuk Lintang & Sabbac: bentuk-bentuk besar yang digambar sendiri dari geometri halus (bukan
 * gabungan efek kecil), supaya tiap skill punya "momen film" yang jelas:
 * - {@link Nova}: bola ledakan bervolume (lobus-lobus api/cahaya yang mengembang, mendingin, lalu jadi asap);
 * - {@link Plasma}: lengkung plasma surya (prominensa) yang naik-turun di sekeliling badan, dengan gumpalan mengalir;
 * - {@link Corona}: korona/semburan sinar matahari yang memancar dan berdenyut;
 * - {@link Pressure}: gelombang tekanan (bola atau kubah searah) dengan tepi terang & pita "pembiasan" gelap;
 * - {@link Vortex}: pusaran spiral (tornado api, pusaran cahaya, gerbang neraka);
 * - {@link Sigil}: segel neraka enam penjuru yang menyala di tanah;
 * - {@link Frost}: kristal es bercabang yang merambat di tanah + duri-duri es yang tumbuh;
 * - {@link Shield}: perisai energi bersel heksagon;
 * - {@link Lance}: berkas energi HD berpilin;
 * - {@link Ghost}: bayangan cahaya berbentuk badan (lesatan & pukulan secepat kilat);
 * - {@link Haze}: riak udara panas.
 * Semua efek ini sebaiknya dibuat dengan penguat (Vfx.setBoost) supaya digambar HD + bloom.
 */
public final class Hd {
    private Hd() {}

    static final Vec3 UP = new Vec3(0, 1, 0);

    /** Anchor yang bisa hilang (pemiliknya mati/hilang) -> null. */
    private static Vec3 at(Lightning.Anchor anchor, float pt) {
        try {
            return anchor.at(pt);
        } catch (RuntimeException e) {
            return null;
        }
    }

    private static double smooth(double v) {
        v = v < 0 ? 0 : (v > 1 ? 1 : v);
        return v * v * (3.0 - 2.0 * v);
    }

    // ------------------------------------------------------------------ cangkang bola dilihat dari kamera

    /** Jari-jari relatif (0 = tengah, 1 = tepi siluet) tiap pita cakram bubble(), rapat di dekat tepi. */
    private static final float[] RIM_S = {0f, 0.5f, 0.7f, 0.82f, 0.9f, 0.95f, 0.975f, 0.99f, 1f, 1.015f, 1.035f};
    /** Gelombang tekanan: tepi tipis yang sangat terang (fresnel pangkat 3), tengahnya bening. */
    private static final float[] RIM_GLOW = {0f, 0.003f, 0.023f, 0.078f, 0.18f, 0.33f, 0.47f, 0.63f, 1f, 0.35f, 0f};
    /** Pita gelap tipis tepat di dalam tepi (lapisan soft): kesan udara yang membiaskan cahaya. */
    private static final float[] RIM_DARK = {0f, 0f, 0f, 0.05f, 0.35f, 0.8f, 1f, 0.75f, 0.35f, 0.1f, 0f};
    /** Perisai: tepi terang (fresnel pangkat 2,2) dengan isian tipis. */
    private static final float[] RIM_SHIELD = {0.06f, 0.072f, 0.124f, 0.215f, 0.344f, 0.5f, 0.636f, 0.776f, 1f, 0.4f, 0f};

    /**
     * Cangkang bola berjari-jari r dilihat dari kamera = cakram menghadap kamera dengan kekuatan per pita (prof, di
     * jari-jari RIM_S). Siluetnya bulat sempurna di jarak berapa pun (cangkang segi-banyak terlihat bersudut di tepinya
     * yang paling terang). Cuma dipakai kalau kamera cukup jauh di luar bola: mengembalikan bagian yang sudah digambar
     * (0 = kamera di dalam/terlalu dekat, pakai cangkang biasa; 1 = penuh), supaya keduanya bisa dipudarkan silang.
     */
    private static float bubble(Draw d, double x, double y, double z, double r, int rgb, float a, float[] prof) {
        double vx = d.camX - x, vy = d.camY - y, vz = d.camZ - z;
        double dist = Math.sqrt(vx * vx + vy * vy + vz * vz);
        if (r <= 1.0E-3) {
            return 1f;
        }
        float out = (float) smooth((dist / r - 1.3) / 0.3);
        a *= out;
        if (a <= 0.003f) {
            return out;
        }
        double nx = vx / dist, ny = vy / dist, nz = vz / dist;
        double k = r * r / dist;   // pusat lingkaran siluet bergeser ke arah kamera
        double cx = x + nx * k, cy = y + ny * k, cz = z + nz * k;
        double rho = r * Math.sqrt(dist * dist - r * r) / dist;
        double[] e = new double[6];
        Draw.plane(nx, ny, nz, e);
        double size = rho / Math.max(0.05, dist - k);   // besar di layar
        int seg = d.hd() ? (size > 0.25 ? 112 : size > 0.08 ? 80 : 48) : 40;
        int bands = RIM_S.length;
        for (int j = 0; j < seg; j++) {
            double t0 = Math.PI * 2.0 * j / seg, t1 = Math.PI * 2.0 * (j + 1) / seg;
            double c0 = Math.cos(t0), s0 = Math.sin(t0), c1 = Math.cos(t1), s1 = Math.sin(t1);
            double dx0 = (e[0] * c0 + e[3] * s0) * rho, dy0 = (e[1] * c0 + e[4] * s0) * rho, dz0 = (e[2] * c0 + e[5] * s0) * rho;
            double dx1 = (e[0] * c1 + e[3] * s1) * rho, dy1 = (e[1] * c1 + e[4] * s1) * rho, dz1 = (e[2] * c1 + e[5] * s1) * rho;
            for (int i = 0; i + 1 < bands; i++) {
                float k0 = a * prof[i], k1 = a * prof[i + 1];
                if (k0 <= 0.003f && k1 <= 0.003f) {
                    continue;
                }
                double f0 = RIM_S[i], f1 = RIM_S[i + 1];
                d.quad(cx + dx0 * f0, cy + dy0 * f0, cz + dz0 * f0, cx + dx0 * f1, cy + dy0 * f1, cz + dz0 * f1,
                        cx + dx1 * f1, cy + dy1 * f1, cz + dz1 * f1, cx + dx1 * f0, cy + dy1 * f0, cz + dz1 * f0, rgb, k0, k1, k1, k0);
            }
        }
        return out;
    }

    // ================================================================== Nova

    /** Bola ledakan bervolume: lobus-lobus yang mengembang cepat, mendingin (panas -> warna -> gelap), lalu jadi asap. */
    public static final class Nova extends Effect {
        private final double x, y, z, radius;
        private final int hot, mid, deep, smoke;
        private final float strength;
        private final boolean flat;
        private final double[] dir;
        private final float[] rnd;

        /**
         * @param flat true = meledak di tanah (belahan bawah dipipihkan, asapnya naik)
         * @param smoke warna asap (0 = tanpa asap, misalnya ledakan cahaya murni)
         */
        public Nova(Vec3 c, double radius, int hot, int mid, int deep, int smoke, int life, float strength, boolean flat) {
            super(life);
            this.x = c.x;
            this.y = c.y;
            this.z = c.z;
            this.radius = radius;
            this.hot = hot;
            this.mid = mid;
            this.deep = deep;
            this.smoke = smoke;
            this.strength = strength;
            this.flat = flat;
            int n = Math.max(12, Math.min(30, (int) (12 + radius * 2.2)));
            this.dir = new double[n * 3];
            this.rnd = new float[n * 2];
            RandomSource r = Vfx.random();
            double golden = Math.PI * (3.0 - Math.sqrt(5.0));
            for (int i = 0; i < n; i++) {
                double yy = 1.0 - (i + 0.5) / n * 2.0;
                double rr = Math.sqrt(Math.max(0.0, 1.0 - yy * yy));
                double th = golden * i + r.nextDouble() * 0.6;
                dir[i * 3] = Math.cos(th) * rr;
                dir[i * 3 + 1] = flat && yy < 0 ? yy * 0.22 : yy;
                dir[i * 3 + 2] = Math.sin(th) * rr;
                rnd[i * 2] = r.nextFloat();
                rnd[i * 2 + 1] = r.nextFloat();
            }
        }

        private int ramp(float u) {
            if (u < 0.22f) {
                return Draw.mix(hot, mid, u / 0.22f);
            }
            if (u < 0.72f) {
                return Draw.mix(mid, deep, (u - 0.22f) / 0.5f);
            }
            return deep;
        }

        private double expand(float u) {
            return 0.12 + 0.88 * (1.0 - Math.pow(1.0 - u, 3.2));
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float u = progress(pt);
            float t = time(pt);
            float in = Math.min(1f, t / 1.2f);
            double e = expand(u);
            double r = radius * e;
            float core = (float) Math.max(0.0, 1.0 - u / 0.28);
            if (core > 0f) {   // kilatan inti
                d.glow(x, y, z, (float) (radius * (0.4 + 0.5 * e)), hot, strength * core * in);
                d.glow(x, y, z, (float) (radius * 0.2), 0xFFFFFF, strength * core * core * in);
            }
            float fade = (float) Math.pow(1.0 - u, 1.35) * strength * in;
            if (fade <= 0.01f) {
                return;
            }
            int n = rnd.length / 2;
            for (int i = 0; i < n; i++) {
                float a0 = rnd[i * 2], a1 = rnd[i * 2 + 1];
                double wob = 0.62 + 0.38 * Math.sin(t * (0.11 + a0 * 0.1) + a0 * 20.0);
                double lift = flat ? radius * 0.3 * u * (0.4 + a1) : radius * 0.12 * u * a1;
                double px = x + dir[i * 3] * r * wob, py = y + dir[i * 3 + 1] * r * wob + lift, pz = z + dir[i * 3 + 2] * r * wob;
                float size = (float) (radius * (0.32 + 0.24 * a1) * (0.55 + 0.75 * e));
                int col = ramp(Math.min(1f, u * 1.15f + a0 * 0.15f));
                d.glow(px, py, pz, size, col, fade * 0.5f);
                if (u < 0.55f) {   // inti panas di dalam tiap lobus
                    float k = 1f - u / 0.55f;
                    d.glow(x + (px - x) * 0.6, y + (py - y) * 0.6, z + (pz - z) * 0.6, size * 0.55f, ramp(u * 0.5f), fade * k * 0.6f);
                }
            }
            if (u < 0.6f) {   // cincin kejut di garis tengah
                float k = 1f - u / 0.6f;
                d.ring(x, y + 0.03, z, 0, 1, 0, r * 1.22, radius * 0.09, mid, strength * k * 0.75f, 0.04f, null);
                d.ring(x, y + 0.03, z, 0, 1, 0, r * 1.05, radius * 0.035, hot, strength * k * 0.9f, 0f, null);
            }
        }

        @Override
        public void renderSoft(Draw d) {
            if (smoke == 0) {
                return;
            }
            float pt = d.partialTick;
            float u = progress(pt);
            if (u < 0.18f) {
                return;
            }
            float t = time(pt);
            float k = Math.min(1f, (u - 0.18f) / 0.25f) * (float) Math.pow(1.0 - u, 1.1) * 0.62f * Math.min(1f, strength);
            if (k <= 0.01f) {
                return;
            }
            double r = radius * expand(u) * 1.08;
            int n = rnd.length / 2;
            int lit = Draw.mix(smoke, 0xFFFFFF, 0.14), shade = Draw.mix(smoke, 0x000000, 0.5);
            for (int i = 0; i < n; i += 2) {
                float a0 = rnd[i * 2], a1 = rnd[i * 2 + 1];
                double wob = 0.7 + 0.3 * Math.sin(t * 0.07 + a0 * 13.0);
                double rise = radius * (0.55 + 0.5 * a1) * (u - 0.18);
                double px = x + dir[i * 3] * r * wob, py = y + Math.max(dir[i * 3 + 1], -0.1) * r * wob + rise, pz = z + dir[i * 3 + 2] * r * wob;
                d.puff(px, py, pz, (float) (radius * (0.42 + 0.3 * a1) * (0.7 + 0.6 * u)), lit, shade, k);
            }
        }
    }

    // ================================================================== Plasma

    /** Lengkung plasma surya (prominensa) yang naik-turun di sekeliling sebuah titik, dengan gumpalan panas mengalir. */
    public static final class Plasma extends Effect {
        private static final int N = 13;
        private final Lightning.Anchor center;
        private final double radius;
        private final int rgb, hot;
        private final float strength;
        private final Supplier<Float> level;
        private final double[] loop;
        private final float[] pts = new float[N * 3];
        private final float[] w = new float[N];
        private final float[] a = new float[N];

        /** level = kekuatan luar per frame (null = 1), misalnya selama Mode Surya masih aktif. */
        public Plasma(Lightning.Anchor center, double radius, int loops, int rgb, int hot, int life, float strength,
                      Supplier<Float> level) {
            super(life);
            this.center = center;
            this.radius = radius;
            this.rgb = rgb;
            this.hot = hot;
            this.strength = strength;
            this.level = level;
            RandomSource r = Vfx.random();
            int n = Math.max(1, loops);
            this.loop = new double[n * 6];
            for (int i = 0; i < n; i++) {
                loop[i * 6] = r.nextDouble() * Math.PI * 2.0;                 // sudut kaki
                loop[i * 6 + 1] = (r.nextDouble() - 0.5) * 1.6;               // lintang
                loop[i * 6 + 2] = 0.55 + r.nextDouble() * 0.8;               // jarak kedua kaki (rad)
                loop[i * 6 + 3] = 0.45 + r.nextDouble() * 0.75;              // tinggi lengkung (x radius)
                loop[i * 6 + 4] = (r.nextDouble() - 0.5) * 0.02;             // hanyut
                loop[i * 6 + 5] = r.nextDouble();                             // fase
            }
        }

        @Override
        public boolean tick(net.minecraft.client.multiplayer.ClientLevel lvl) {
            if (level != null && age > 4 && safe() <= 0.001f) {
                return false;
            }
            return super.tick(lvl);
        }

        private float safe() {
            try {
                Float v = level == null ? 1f : level.get();
                return v == null ? 0f : v;
            } catch (RuntimeException e) {
                return 0f;
            }
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            Vec3 c = at(center, pt);
            if (c == null) {
                return;
            }
            float t = time(pt);
            float fade = Math.min(1f, t / 8f) * Math.min(1f, (life - t) / 10f) * strength * safe();
            if (fade <= 0.01f) {
                return;
            }
            int loops = loop.length / 6;
            for (int k = 0; k < loops; k++) {
                double th = loop[k * 6] + t * loop[k * 6 + 4];
                double lat = loop[k * 6 + 1];
                double span = loop[k * 6 + 2];
                double h = radius * loop[k * 6 + 3];
                double cyc = (t * 0.011 + loop[k * 6 + 5]) % 1.0;
                double rise = Math.sin(Math.PI * cyc);
                if (rise <= 0.03) {
                    continue;
                }
                double cl = Math.cos(lat), sl = Math.sin(lat);
                for (int j = 0; j < N; j++) {
                    double v = j / (double) (N - 1);
                    double ang = th + span * (v - 0.5);
                    double arch = Math.sin(Math.PI * v);
                    double lift = h * arch * rise;
                    double twist = Math.sin(t * 0.09 + k * 1.7 + v * 3.0) * radius * 0.08 * arch;
                    double dx = cl * Math.cos(ang), dy = sl + twist * 0.3, dz = cl * Math.sin(ang);
                    double rr = radius + lift;
                    pts[j * 3] = (float) (c.x + dx * rr);
                    pts[j * 3 + 1] = (float) (c.y + dy * rr + twist);
                    pts[j * 3 + 2] = (float) (c.z + dz * rr);
                    w[j] = (float) (radius * 0.075 * (0.45 + 0.75 * arch) * (0.85 + 0.15 * Math.sin(t * 0.6 + j)));
                    a[j] = fade * (float) ((0.3 + 0.7 * rise) * (0.55 + 0.45 * arch));
                }
                d.polyline(pts, N, w, a, rgb, hot);
                for (int b = 0; b < 2; b++) {   // gumpalan plasma yang mengalir sepanjang lengkung
                    double v = (t * 0.045 + b * 0.5 + k * 0.13) % 1.0;
                    int j = Math.min(N - 2, (int) (v * (N - 1)));
                    double f = v * (N - 1) - j;
                    double gx = pts[j * 3] + (pts[j * 3 + 3] - pts[j * 3]) * f;
                    double gy = pts[j * 3 + 1] + (pts[j * 3 + 4] - pts[j * 3 + 1]) * f;
                    double gz = pts[j * 3 + 2] + (pts[j * 3 + 5] - pts[j * 3 + 2]) * f;
                    d.glow(gx, gy, gz, (float) (radius * 0.12), hot, fade * (float) rise * 0.8f);
                }
            }
        }
    }

    // ================================================================== Corona

    /** Korona: semburan sinar yang memancar dari sebuah titik (menghadap kamera), panjangnya berdenyut, berputar pelan. */
    public static final class Corona extends Effect {
        private final Lightning.Anchor center;
        private final double r0, r1;
        private final int rgb, hot;
        private final float strength;
        private final Supplier<Float> level;
        private final float[] seed;

        public Corona(Lightning.Anchor center, double r0, double r1, int count, int rgb, int hot, int life, float strength,
                      Supplier<Float> level) {
            super(life);
            this.center = center;
            this.r0 = r0;
            this.r1 = r1;
            this.rgb = rgb;
            this.hot = hot;
            this.strength = strength;
            this.level = level;
            RandomSource r = Vfx.random();
            this.seed = new float[Math.max(4, count)];
            for (int i = 0; i < seed.length; i++) {
                seed[i] = r.nextFloat();
            }
        }

        private float ext() {
            try {
                Float v = level == null ? 1f : level.get();
                return v == null ? 0f : v;
            } catch (RuntimeException e) {
                return 0f;
            }
        }

        @Override
        public boolean tick(net.minecraft.client.multiplayer.ClientLevel lvl) {
            if (level != null && age > 4 && ext() <= 0.001f) {
                return false;
            }
            return super.tick(lvl);
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            Vec3 c = at(center, pt);
            if (c == null) {
                return;
            }
            float t = time(pt);
            float fade = Math.min(1f, t / 6f) * Math.min(1f, (life - t) / 10f) * strength * ext();
            if (fade <= 0.01f) {
                return;
            }
            // basis menghadap kamera
            double fx = c.x - d.camX, fy = c.y - d.camY, fz = c.z - d.camZ;
            double fl = Math.sqrt(fx * fx + fy * fy + fz * fz);
            if (fl < 1.0E-4) {
                return;
            }
            fx /= fl; fy /= fl; fz /= fl;
            double rx = -fz, rz = fx, rl = Math.sqrt(rx * rx + rz * rz);
            if (rl < 1.0E-4) {
                rx = 1; rz = 0; rl = 1;
            }
            rx /= rl; rz /= rl;
            double ux = -rz * fy, uy = rz * fx - rx * fz, uz = rx * fy;
            int n = seed.length;
            for (int i = 0; i < n; i++) {
                float s = seed[i];
                double ang = Math.PI * 2.0 * i / n + s * 0.4 + t * 0.006 * (i % 2 == 0 ? 1 : -1);
                double len = (r1 - r0) * (0.45 + 0.55 * (0.5 + 0.5 * Math.sin(t * (0.07 + s * 0.08) + s * 30.0)));
                double ca = Math.cos(ang), sa = Math.sin(ang);
                double dx = rx * ca + ux * sa, dy = uy * sa, dz = rz * ca + uz * sa;
                double bend = Math.sin(t * 0.05 + s * 9.0) * 0.12;
                double ex = dx + (-rx * sa + ux * ca) * bend, ey = dy + uy * ca * bend, ez = dz + (-rz * sa + uz * ca) * bend;
                double ax = c.x + dx * r0, ay = c.y + dy * r0, az = c.z + dz * r0;
                double bx = c.x + ex * (r0 + len), by = c.y + ey * (r0 + len), bz = c.z + ez * (r0 + len);
                float w = (float) (r0 * (0.18 + 0.22 * s));
                float k = fade * (0.55f + 0.45f * (float) Math.sin(t * 0.21 + s * 17.0));
                d.line(ax, ay, az, bx, by, bz, w, 0f, rgb, k * 0.8f, 0f);
                if (i % 3 == 0) {
                    d.line(ax, ay, az, ax + (bx - ax) * 0.6, ay + (by - ay) * 0.6, az + (bz - az) * 0.6, w * 0.3f, 0f, hot, k, 0f);
                }
            }
            d.glow(c.x, c.y, c.z, (float) (r0 * 2.2), rgb, 0.45f * fade);
            d.glow(c.x, c.y, c.z, (float) (r0 * 1.1), hot, 0.6f * fade);
        }
    }

    // ================================================================== Pressure

    /**
     * Gelombang tekanan: bola (cap = PI) atau kubah searah sumbu (cap < PI) yang mengembang, tepinya terang (seperti
     * udara yang dimampatkan), dengan pita gelap tipis di lapisan soft yang terlihat seperti pembiasan.
     */
    public static final class Pressure extends Effect {
        private final double x, y, z, ax, ay, az, radius, cap;
        private final int rgb;
        private final float strength;
        private final boolean refract;
        private double[] gx = new double[0], gy = new double[0], gz = new double[0];
        private float[] gk = new float[0];

        public Pressure(Vec3 c, Vec3 axis, double radius, double cap, int rgb, int life, float strength, boolean refract) {
            super(life);
            this.x = c.x;
            this.y = c.y;
            this.z = c.z;
            Vec3 n = axis.lengthSqr() < 1.0E-8 ? UP : axis.normalize();
            this.ax = n.x;
            this.ay = n.y;
            this.az = n.z;
            this.radius = radius;
            this.cap = Math.max(0.2, Math.min(Math.PI, cap));
            this.rgb = rgb;
            this.strength = strength;
            this.refract = refract;
        }

        private double reach(float u) {
            return radius * (0.06 + 0.94 * (1.0 - Math.pow(1.0 - u, 2.4)));
        }

        private void mesh(Draw d, double r, int color, float a, double power) {
            if (a <= 0.003f) {
                return;
            }
            int lat = d.hd() ? 18 : 9, lon = d.hd() ? 64 : 26;
            int w = lon + 1;
            int need = (lat + 1) * w;
            if (gx.length < need) {
                gx = new double[need];
                gy = new double[need];
                gz = new double[need];
                gk = new float[need];
            }
            double[] e = new double[6];
            Draw.plane(ax, ay, az, e);
            for (int i = 0; i <= lat; i++) {
                double th = cap * i / lat;
                double st = Math.sin(th), ct = Math.cos(th);
                double edge = cap < Math.PI - 0.01 ? 1.0 - Math.pow(th / cap, 6.0) : 1.0;
                double front = cap < Math.PI - 0.01 ? 0.35 + 0.65 * smooth(th / (cap * 0.5)) : 1.0;
                for (int j = 0; j <= lon; j++) {
                    double ph = Math.PI * 2.0 * j / lon;
                    double cp = Math.cos(ph), sp = Math.sin(ph);
                    double nx = ax * ct + (e[0] * cp + e[3] * sp) * st;
                    double ny = ay * ct + (e[1] * cp + e[4] * sp) * st;
                    double nz = az * ct + (e[2] * cp + e[5] * sp) * st;
                    double px = x + nx * r, py = y + ny * r, pz = z + nz * r;
                    int o = i * w + j;
                    gx[o] = px; gy[o] = py; gz[o] = pz;
                    double vx = d.camX - px, vy = d.camY - py, vz = d.camZ - pz;
                    double vl = Math.sqrt(vx * vx + vy * vy + vz * vz);
                    double f = vl < 1.0E-6 ? 1.0 : 1.0 - Math.abs((nx * vx + ny * vy + nz * vz) / vl);
                    gk[o] = (float) (a * Math.pow(Math.max(0.0, f), power) * edge * front);
                }
            }
            for (int i = 0; i < lat; i++) {
                for (int j = 0; j < lon; j++) {
                    int p = i * w + j, q = p + 1, s = p + w + 1, t = p + w;
                    d.quad(gx[p], gy[p], gz[p], gx[q], gy[q], gz[q], gx[s], gy[s], gz[s], gx[t], gy[t], gz[t],
                            color, gk[p], gk[q], gk[s], gk[t]);
                }
            }
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float u = progress(pt);
            float a = strength * (float) Math.pow(1.0 - u, 1.3) * Math.min(1f, time(pt) / 1.2f);
            if (a <= 0.01f) {
                return;
            }
            double r = reach(u);
            float old = d.body(0.12f);   // gelombang udara: cahaya tipis tanpa badan pekat (dulu terlihat seperti bola susu)
            if (cap >= Math.PI - 0.01) {   // bola penuh: dari luar tepinya bulat sempurna, dari dalam pakai cangkang
                float out = bubble(d, x, y, z, r, rgb, a, RIM_GLOW);
                mesh(d, r, rgb, a * (1f - out), 2.6);
            } else {
                mesh(d, r, rgb, a, 2.6);
                double cr = r * Math.sin(cap) * 0.98, off = r * Math.cos(cap) * 0.98;   // tepi kubah yang menyala
                d.ring(x + ax * off, y + ay * off, z + az * off, ax, ay, az, cr, r * 0.05, rgb, a * 0.6f, 0f, null);
            }
            d.body(old);
        }

        @Override
        public void renderSoft(Draw d) {
            if (!refract) {
                return;
            }
            float pt = d.partialTick;
            float u = progress(pt);
            float a = strength * (float) Math.pow(1.0 - u, 1.6) * 0.32f;
            if (a <= 0.01f) {
                return;
            }
            int dark = Draw.mix(rgb, 0x000000, 0.82);
            if (cap >= Math.PI - 0.01) {
                float out = bubble(d, x, y, z, reach(u), dark, a, RIM_DARK);
                mesh(d, reach(u) * 0.955, dark, a * (1f - out), 4.0);
            } else {
                mesh(d, reach(u) * 0.955, dark, a, 4.0);
            }
        }
    }

    // ================================================================== Vortex

    /** Pusaran spiral di sekitar sumbu tegak: lengan-lengan yang berputar naik (tornado api, pusaran cahaya). */
    public static final class Vortex extends Effect {
        private static final int N = 48;   // titik per lengan: lengkungnya mulus, nggak patah-patah
        private final Lightning.Anchor base;
        private final double r0, r1, height, turns;
        private final int arms, rgb, hot, smoke;
        private final float width, strength, spin;
        private final float[] pts = new float[N * 3];
        private final float[] w = new float[N];
        private final float[] a = new float[N];

        /** smoke != 0: lengan asap gelap di lapisan soft (tornado api). spin = putaran (radian/tick). */
        public Vortex(Lightning.Anchor base, double r0, double r1, double height, int arms, double turns, float width, int rgb,
                      int hot, int smoke, float spin, int life, float strength) {
            super(life);
            this.base = base;
            this.r0 = r0;
            this.r1 = r1;
            this.height = height;
            this.arms = Math.max(1, arms);
            this.turns = turns;
            this.width = width;
            this.rgb = rgb;
            this.hot = hot;
            this.smoke = smoke;
            this.spin = spin;
            this.strength = strength;
        }

        private float fade(float t) {
            return Math.min(1f, t / 6f) * Math.min(1f, (life - t) / 10f) * strength;
        }

        private void arm(Vec3 b, int k, float t, float fade, double radiusMul, double phase, float widthMul) {
            for (int j = 0; j < N; j++) {
                double v = j / (double) (N - 1);
                double ang = k * Math.PI * 2.0 / arms + v * turns * Math.PI * 2.0 + t * spin + phase;
                double rad = (r0 + (r1 - r0) * Math.pow(v, 1.15)) * radiusMul
                        * (1.0 + 0.07 * Math.sin(t * 0.3 + v * 7.0 + k) + 0.04 * Math.sin(t * 0.83 + v * 17.0 + k * 2.0));
                pts[j * 3] = (float) (b.x + Math.cos(ang) * rad);
                pts[j * 3 + 1] = (float) (b.y + v * height);
                pts[j * 3 + 2] = (float) (b.z + Math.sin(ang) * rad);
                double arch = Math.pow(Math.sin(Math.PI * v), 0.55);   // meruncing halus di kedua ujung
                w[j] = (float) (width * widthMul * (0.3 + 0.7 * arch));
                a[j] = fade * (float) arch * (0.8f + 0.2f * Mth.sin(t * 0.7f + j * 0.33f + k));
            }
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            Vec3 b = at(base, pt);
            if (b == null) {
                return;
            }
            float t = time(pt);
            float fade = fade(t);
            if (fade <= 0.01f) {
                return;
            }
            float old = d.body(1f);
            for (int k = 0; k < arms; k++) {
                arm(b, k, t, fade, 1.0, 0.0, 1f);
                d.body(old * 0.3f);   // lembaran lebar tembus pandang: pusaran terlihat bervolume
                d.strip(pts, N, w, 3.2f, a, 0.16f, rgb);
                d.body(old);
                d.polyline(pts, N, w, a, rgb, hot);   // pilinan terang
                arm(b, k, t, fade * 0.7f, 0.6, 0.9, 0.5f);   // pilinan dalam yang lebih tipis, sedikit tertinggal
                d.polyline(pts, N, w, a, rgb, hot);
            }
            d.body(old);
        }

        @Override
        public void renderSoft(Draw d) {
            if (smoke == 0) {
                return;
            }
            float pt = d.partialTick;
            Vec3 b = at(base, pt);
            if (b == null) {
                return;
            }
            float t = time(pt);
            float fade = fade(t) * 0.55f;
            if (fade <= 0.01f) {
                return;
            }
            for (int k = 0; k < arms; k++) {
                arm(b, k, t, fade, 1.25, 0.6, 2.4f);
                d.strip(pts, N, w, 1f, a, 1f, smoke);
            }
        }
    }

    // ================================================================== Sigil

    /**
     * Segel neraka di tanah: cincin ganda, lengkung-lengkung "tanduk" yang melengkung ke dalam antar penjuru, jari-jari
     * ke lingkaran tengah, cincin rune putus-putus yang berputar berlawanan, lingkaran kecil di tiap penjuru (satu per
     * iblis), dan garis-garis skala.
     */
    public static final class Sigil extends Effect {
        private final double x, y, z, radius;
        private final int rgb, hot, points;
        private final float strength, spin;
        private final double phase;
        private final Draw.Height ground;

        public Sigil(Vec3 c, double radius, int points, int rgb, int hot, int life, float strength, float spin, Draw.Height ground) {
            this(c, radius, points, rgb, hot, life, strength, spin, 0.0, ground);
        }

        /** phase = sudut awal penjuru pertama (radian), supaya pas dengan api/iblis yang muncul di penjuru itu. */
        public Sigil(Vec3 c, double radius, int points, int rgb, int hot, int life, float strength, float spin, double phase,
                     Draw.Height ground) {
            super(life);
            this.phase = phase;
            this.x = c.x;
            this.y = c.y;
            this.z = c.z;
            this.radius = radius;
            this.points = Math.max(3, points);
            this.rgb = rgb;
            this.hot = hot;
            this.strength = strength;
            this.spin = spin;
            this.ground = ground;
        }

        private double h(double px, double pz) {
            if (ground == null) {
                return 0.0;
            }
            double dx = px - x, dz = pz - z;
            return ground.at(Math.atan2(dz, dx), Math.sqrt(dx * dx + dz * dz));
        }

        /** Garis di tanah dari (ax, az) ke (bx, bz), mengikuti tinggi tanah. */
        private void line(Draw d, double ax, double az, double bx, double bz, float width, int color, float a) {
            int seg = 6;
            double px = ax, pz = az, py = y + h(ax, az) + 0.02;
            for (int i = 1; i <= seg; i++) {
                double f = i / (double) seg;
                double qx = ax + (bx - ax) * f, qz = az + (bz - az) * f, qy = y + h(qx, qz) + 0.02;
                d.flatLine(px, py, pz, qx, qy, qz, 0, 1, 0, width, color, a, a);
                px = qx; py = qy; pz = qz;
            }
        }

        /** Satu ruas pendek di tanah (titik dunia), mengikuti tinggi tanah di kedua ujungnya. */
        private void flat(Draw d, double ax, double az, double bx, double bz, float width, int color, float a) {
            d.flatLine(ax, y + h(ax, az) + 0.02, az, bx, y + h(bx, bz) + 0.02, bz, 0, 1, 0, width, color, a, a);
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float t = time(pt);
            float grow = (float) smooth(t / 8.0);
            float fade = Math.min(1f, (life - t) / 14f) * strength;
            if (fade <= 0.01f || grow <= 0.01f) {
                return;
            }
            float pulse = 0.82f + 0.18f * Mth.sin(t * 0.35f);
            float a = fade * pulse;
            double rr = radius * (0.7 + 0.3 * grow);
            double yy = y + 0.02;
            float oldBody = d.body(0.4f);
            d.disc(x, yy, z, 0, 1, 0, rr, rgb, a * grow * 0.12f, a * grow * 0.03f, ground);   // cahaya merah dari dalam segel
            d.body(oldBody);
            d.ring(x, yy, z, 0, 1, 0, rr, radius * 0.045, rgb, a * grow, 0.02f, ground);
            d.ring(x, yy, z, 0, 1, 0, rr * 0.9, radius * 0.022, hot, a * grow * 0.85f, 0f, ground);
            d.ring(x, yy, z, 0, 1, 0, rr * 0.47, radius * 0.02, rgb, a * grow * 0.7f, 0.05f, ground);
            d.ring(x, yy, z, 0, 1, 0, rr * 0.2, radius * 0.018, hot, a * grow * 0.75f, 0.12f, ground);
            double rot = phase + t * spin;
            double star = rr * 0.86;
            float lw = (float) (radius * 0.038);
            for (int i = 0; i < points; i++) {
                double a0 = rot + Math.PI * 2.0 * i / points, a1 = rot + Math.PI * 2.0 * (i + 1) / points;
                float reveal = Mth.clamp(grow * points - i * 0.5f, 0f, 1f);
                if (reveal <= 0f) {
                    continue;
                }
                // lengkung tanduk dari penjuru ke penjuru berikutnya, melengkung ke dalam (kurva Bezier), tergambar bertahap
                double p0x = x + Math.cos(a0) * star, p0z = z + Math.sin(a0) * star;
                double p2x = x + Math.cos(a1) * star, p2z = z + Math.sin(a1) * star;
                double am = (a0 + a1) * 0.5;
                double c1x = x + Math.cos(am) * rr * 0.42, c1z = z + Math.sin(am) * rr * 0.42;
                double qx = p0x, qz = p0z;
                int seg = 10;
                for (int k = 1; k <= seg; k++) {
                    double f = k / (double) seg * reveal;
                    double m0 = (1 - f) * (1 - f), m1 = 2 * f * (1 - f), m2 = f * f;
                    double nx = m0 * p0x + m1 * c1x + m2 * p2x, nz = m0 * p0z + m1 * c1z + m2 * p2z;
                    flat(d, qx, qz, nx, nz, lw * 2.2f, rgb, a * reveal * 0.3f);   // pendar lebar
                    flat(d, qx, qz, nx, nz, lw, Draw.mix(rgb, hot, 0.35), a * reveal);
                    qx = nx;
                    qz = nz;
                }
                // jari-jari dari penjuru ke lingkaran tengah
                line(d, x + Math.cos(a0) * star * 0.92, z + Math.sin(a0) * star * 0.92, x + Math.cos(a0) * rr * 0.49,
                        z + Math.sin(a0) * rr * 0.49, lw * 0.75f, hot, a * reveal * 0.8f);
            }
            int dash = 18;   // cincin rune putus-putus yang berputar berlawanan
            for (int i = 0; i < dash; i++) {
                double a0 = -rot * 1.4 + Math.PI * 2.0 * i / dash, span = Math.PI * 2.0 / dash * (i % 3 == 0 ? 0.75 : 0.45);
                double px = x + Math.cos(a0) * rr * 0.33, pz = z + Math.sin(a0) * rr * 0.33;
                for (int k = 1; k <= 3; k++) {
                    double ang = a0 + span * k / 3.0;
                    double nx = x + Math.cos(ang) * rr * 0.33, nz = z + Math.sin(ang) * rr * 0.33;
                    flat(d, px, pz, nx, nz, lw * 0.7f, hot, a * grow * 0.75f);
                    px = nx;
                    pz = nz;
                }
            }
            for (int i = 0; i < points; i++) {   // lingkaran kecil & lidah cahaya di tiap penjuru
                double ang = rot + Math.PI * 2.0 * i / points;
                double px = x + Math.cos(ang) * star, pz = z + Math.sin(ang) * star;
                double py = y + h(px, pz) + 0.03;
                d.ring(px, py, pz, 0, 1, 0, radius * 0.08, radius * 0.02, hot, a * grow, 0.15f, null);
                d.glow(px, py + 0.1, pz, (float) (radius * 0.12), rgb, a * grow * 0.5f);
            }
            int ticks = 48;   // garis skala berputar berlawanan
            for (int i = 0; i < ticks; i++) {
                double ang = -rot * 0.6 + Math.PI * 2.0 * i / ticks;
                double r0 = rr * (i % 4 == 0 ? 0.92 : 0.94), r1 = rr * 0.985;
                line(d, x + Math.cos(ang) * r0, z + Math.sin(ang) * r0, x + Math.cos(ang) * r1, z + Math.sin(ang) * r1,
                        (float) (radius * 0.012), hot, a * grow * 0.6f);
            }
        }
    }

    // ================================================================== Frost

    /** Es bercabang yang merambat di tanah (pola kristal) + duri-duri es yang tumbuh, lalu meleleh/memudar. */
    public static final class Frost extends Effect {
        private final double x, y, z, radius;
        private final int rgb;
        private final float strength;
        private final Draw.Height ground;
        private final float[] seg;      // x0, z0, x1, z1, muncul (0..1), tebal
        private final float[] spikes;   // x, z, tinggi, condong x, condong z, muncul
        private final int grow;

        public Frost(Vec3 c, double radius, int rgb, int grow, int life, float strength, Draw.Height ground) {
            super(life);
            this.x = c.x;
            this.y = c.y;
            this.z = c.z;
            this.radius = radius;
            this.rgb = rgb;
            this.grow = Math.max(1, grow);
            this.strength = strength;
            this.ground = ground;
            RandomSource r = Vfx.random();
            java.util.List<float[]> out = new java.util.ArrayList<>();
            int mains = 9 + r.nextInt(4);
            for (int m = 0; m < mains; m++) {
                double ang = Math.PI * 2.0 * m / mains + r.nextDouble() * 0.4;
                branch(out, r, 0.0, 0.0, ang, radius * (0.75 + r.nextDouble() * 0.3), 0, 0.0);
            }
            this.seg = new float[out.size() * 6];
            for (int i = 0; i < out.size(); i++) {
                System.arraycopy(out.get(i), 0, seg, i * 6, 6);
            }
            int n = 6 + (int) (radius * 2.5);
            this.spikes = new float[n * 6];
            for (int i = 0; i < n; i++) {
                double a = r.nextDouble() * Math.PI * 2.0, d = radius * (0.25 + 0.7 * Math.sqrt(r.nextDouble()));
                spikes[i * 6] = (float) (Math.cos(a) * d);
                spikes[i * 6 + 1] = (float) (Math.sin(a) * d);
                spikes[i * 6 + 2] = (float) (radius * (0.12 + r.nextDouble() * 0.22));
                spikes[i * 6 + 3] = (float) (Math.cos(a) * 0.35 + (r.nextDouble() - 0.5) * 0.3);
                spikes[i * 6 + 4] = (float) (Math.sin(a) * 0.35 + (r.nextDouble() - 0.5) * 0.3);
                spikes[i * 6 + 5] = (float) (d / radius);
            }
        }

        private static void branch(java.util.List<float[]> out, RandomSource r, double sx, double sz, double ang, double len,
                                   int depth, double start) {
            int steps = depth == 0 ? 6 : 3;
            double px = sx, pz = sz, step = len / steps;
            double total = Math.sqrt(sx * sx + sz * sz);
            for (int i = 0; i < steps; i++) {
                ang += (r.nextDouble() - 0.5) * 0.45;
                double qx = px + Math.cos(ang) * step, qz = pz + Math.sin(ang) * step;
                total += step;
                out.add(new float[] {(float) px, (float) pz, (float) qx, (float) qz, (float) (start + total), 1f - depth * 0.35f});
                if (depth < 2 && i < steps - 1) {
                    for (int s = -1; s <= 1; s += 2) {
                        if (r.nextFloat() < 0.65f) {
                            branch(out, r, qx, qz, ang + s * (0.75 + r.nextDouble() * 0.3), step * (1.4 - depth * 0.4), depth + 1, 0.0);
                        }
                    }
                }
                px = qx;
                pz = qz;
            }
        }

        private double h(double px, double pz) {
            if (ground == null) {
                return 0.0;
            }
            return ground.at(Math.atan2(pz, px), Math.sqrt(px * px + pz * pz));
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float t = time(pt);
            float front = (float) (radius * 1.15 * smooth(t / grow));
            float fade = Math.min(1f, (life - t) / (life * 0.4f)) * strength;
            if (fade <= 0.01f) {
                return;
            }
            int n = seg.length / 6;
            for (int i = 0; i < n; i++) {
                int o = i * 6;
                double dist0 = Math.sqrt(seg[o] * seg[o] + seg[o + 1] * seg[o + 1]);
                if (dist0 > front) {
                    continue;
                }
                double x0 = seg[o], z0 = seg[o + 1], x1 = seg[o + 2], z1 = seg[o + 3];
                double dist1 = Math.sqrt(x1 * x1 + z1 * z1);
                if (dist1 > front) {   // ujung yang sedang tumbuh
                    double f = (front - dist0) / Math.max(1.0E-4, dist1 - dist0);
                    x1 = x0 + (x1 - x0) * f;
                    z1 = z0 + (z1 - z0) * f;
                }
                float th = seg[o + 5];
                float a = fade * th * (0.55f + 0.45f * (float) (1.0 - dist0 / (radius * 1.2)));
                d.flatLine(x + x0, y + h(x0, z0) + 0.025, z + z0, x + x1, y + h(x1, z1) + 0.025, z + z1, 0, 1, 0,
                        (float) (radius * 0.022 * (0.6 + th)), rgb, a, a);
            }
            int m = spikes.length / 6;
            for (int i = 0; i < m; i++) {   // duri es: tumbuh begitu gelombang beku lewat
                int o = i * 6;
                double sx = spikes[o], sz = spikes[o + 1];
                double dist = Math.sqrt(sx * sx + sz * sz);
                if (dist > front) {
                    continue;
                }
                double g = smooth((front - dist) / (radius * 0.25));
                double hh = spikes[o + 2] * g;
                double bx = x + sx, by = y + h(sx, sz), bz = z + sz;
                double tx = bx + spikes[o + 3] * hh, ty = by + hh, tz = bz + spikes[o + 4] * hh;
                float w = (float) (spikes[o + 2] * 0.32);
                d.line(bx, by, bz, tx, ty, tz, w, 0f, rgb, fade * 0.85f, fade * 0.4f);
                d.line(bx, by, bz, bx + (tx - bx) * 0.8, by + (ty - by) * 0.8, bz + (tz - bz) * 0.8, w * 0.3f, 0f, 0xFFFFFF,
                        fade * 0.7f, 0f);
                float tw = (float) Math.pow(Math.max(0.0, Math.sin(t * 0.3 + i * 2.1)), 10.0);
                if (tw > 0.05f) {
                    d.glint(tx, ty, tz, (float) (spikes[o + 2] * 0.7 * tw), i * 0.7f, 0xFFFFFF, fade * tw);
                }
            }
        }

        @Override
        public void renderSoft(Draw d) {
            float pt = d.partialTick;
            float t = time(pt);
            float fade = Math.min(1f, (life - t) / (life * 0.4f)) * strength;
            double front = radius * smooth(t / grow);
            if (fade <= 0.01f || front <= 0.05) {
                return;
            }
            d.disc(x, y + 0.02, z, 0, 1, 0, front, 0xEAF7FF, 0.26f * fade, 0.04f * fade, ground);
        }
    }

    // ================================================================== Shield

    /** Perisai energi bersel heksagon di sekeliling sebuah titik (sekutu yang diselamatkan). */
    public static final class Shield extends Effect {
        /** Tepi sel heksagon (+12 segi lima) di bola satuan, x0,y0,z0,x1,y1,z1 per tepi: bola geodesik frekuensi 3. */
        private static final double[] CELLS = goldberg(3);

        private final Lightning.Anchor center;
        private final double radius;
        private final int rgb, hot;
        private final float strength;

        /**
         * Sel-sel heksagon di bola = dual dari ikosahedron yang segitiganya dibagi f×f: tiap tepi segitiga yang dipakai
         * dua segitiga jadi satu tepi sel (menghubungkan titik berat kedua segitiga itu).
         */
        private static double[] goldberg(int f) {
            double g = (1.0 + Math.sqrt(5.0)) / 2.0;
            double[][] v = {{-1, g, 0}, {1, g, 0}, {-1, -g, 0}, {1, -g, 0}, {0, -1, g}, {0, 1, g}, {0, -1, -g}, {0, 1, -g},
                    {g, 0, -1}, {g, 0, 1}, {-g, 0, -1}, {-g, 0, 1}};
            int[][] faces = {{0, 11, 5}, {0, 5, 1}, {0, 1, 7}, {0, 7, 10}, {0, 10, 11}, {1, 5, 9}, {5, 11, 4}, {11, 10, 2},
                    {10, 7, 6}, {7, 1, 8}, {3, 9, 4}, {3, 4, 2}, {3, 2, 6}, {3, 6, 8}, {3, 8, 9}, {4, 9, 5}, {2, 4, 11},
                    {6, 2, 10}, {8, 6, 7}, {9, 8, 1}};
            java.util.Map<String, Integer> ids = new java.util.HashMap<>();
            java.util.Map<Long, double[]> open = new java.util.HashMap<>();
            java.util.List<double[]> edges = new java.util.ArrayList<>();
            for (int[] fc : faces) {
                double[] a = v[fc[0]], b = v[fc[1]], c = v[fc[2]];
                int n = (f + 1) * (f + 2) / 2;
                double[][] p = new double[n][];
                int[] id = new int[n];
                for (int i = 0; i <= f; i++) {
                    for (int j = 0; i + j <= f; j++) {
                        double px = a[0] + (b[0] - a[0]) * i / f + (c[0] - a[0]) * j / f;
                        double py = a[1] + (b[1] - a[1]) * i / f + (c[1] - a[1]) * j / f;
                        double pz = a[2] + (b[2] - a[2]) * i / f + (c[2] - a[2]) * j / f;
                        double l = Math.sqrt(px * px + py * py + pz * pz);
                        int o = index(i, j, f);
                        p[o] = new double[] {px / l, py / l, pz / l};
                        String key = Math.round(px / l * 1.0E5) + "," + Math.round(py / l * 1.0E5) + "," + Math.round(pz / l * 1.0E5);
                        Integer known = ids.get(key);
                        if (known == null) {
                            known = ids.size();
                            ids.put(key, known);
                        }
                        id[o] = known;
                    }
                }
                for (int i = 0; i < f; i++) {
                    for (int j = 0; i + j < f; j++) {
                        tri(p, id, index(i, j, f), index(i + 1, j, f), index(i, j + 1, f), open, edges);
                        if (i + j < f - 1) {
                            tri(p, id, index(i + 1, j, f), index(i + 1, j + 1, f), index(i, j + 1, f), open, edges);
                        }
                    }
                }
            }
            double[] out = new double[edges.size() * 6];
            for (int i = 0; i < edges.size(); i++) {
                System.arraycopy(edges.get(i), 0, out, i * 6, 6);
            }
            return out;
        }

        /** Nomor titik (i, j) di segitiga yang dibagi f (baris i berisi f - i + 1 titik). */
        private static int index(int i, int j, int f) {
            return i * (f + 1) - i * (i - 1) / 2 + j;
        }

        private static void tri(double[][] p, int[] id, int a, int b, int c, java.util.Map<Long, double[]> open,
                                java.util.List<double[]> edges) {
            double cx = p[a][0] + p[b][0] + p[c][0], cy = p[a][1] + p[b][1] + p[c][1], cz = p[a][2] + p[b][2] + p[c][2];
            double l = Math.sqrt(cx * cx + cy * cy + cz * cz);
            double[] cen = {cx / l, cy / l, cz / l};
            int[] vs = {id[a], id[b], id[c]};
            for (int e = 0; e < 3; e++) {
                int u = vs[e], w = vs[(e + 1) % 3];
                long key = Math.min(u, w) * 100000L + Math.max(u, w);
                double[] other = open.remove(key);
                if (other == null) {
                    open.put(key, cen);
                } else {
                    edges.add(new double[] {other[0], other[1], other[2], cen[0], cen[1], cen[2]});
                }
            }
        }

        public Shield(Lightning.Anchor center, double radius, int rgb, int hot, int life, float strength) {
            super(life);
            this.center = center;
            this.radius = radius;
            this.rgb = rgb;
            this.hot = hot;
            this.strength = strength;
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            Vec3 c = at(center, pt);
            if (c == null) {
                return;
            }
            float t = time(pt);
            float in = Math.min(1f, t / 5f);
            float pop = in < 1f ? (float) (1.0 + 0.12 * Math.sin(Math.PI * in)) * (0.6f + 0.4f * in) : 1f;
            float fade = Math.min(1f, (life - t) / 10f) * strength * in;
            if (fade <= 0.01f) {
                return;
            }
            double r = radius * pop;
            float oldBody = d.body(0.25f);   // gelembung energi yang bening, bukan bola padat
            float out = bubble(d, c.x, c.y, c.z, r, rgb, 0.5f * fade, RIM_SHIELD);
            if (out < 1f) {   // kamera di dalam/terlalu dekat perisai
                d.shell(c.x, c.y, c.z, r, rgb, 0.5f * fade * (1f - out), 2.4, 1.0);
            }
            // sel heksagon: terbentuk dari bawah ke atas, pita terang menyapu naik, sel di sisi belakang lebih redup
            double vx = d.camX - c.x, vy = d.camY - c.y, vz = d.camZ - c.z;
            double vl = Math.max(1.0E-6, Math.sqrt(vx * vx + vy * vy + vz * vz));
            vx /= vl;
            vy /= vl;
            vz /= vl;
            double sweep = -1.25 + 2.5 * ((t / 22.0) % 1.0);
            double form = -1.1 + 2.4 * smooth(t / 7.0);
            float lw = (float) (r * 0.022);
            int n = CELLS.length / 6;
            for (int i = 0; i < n; i++) {
                int o = i * 6;
                double mx = (CELLS[o] + CELLS[o + 3]) * 0.5, my = (CELLS[o + 1] + CELLS[o + 4]) * 0.5, mz = (CELLS[o + 2] + CELLS[o + 5]) * 0.5;
                if (my > form) {
                    continue;
                }
                double grown = smooth((form - my) / 0.25);
                double facing = mx * vx + my * vy + mz * vz;   // > 0 = sisi yang menghadap kamera
                float face = (float) (0.38 + 0.62 * smooth((facing + 0.25) / 0.5));
                double band = Math.exp(-Math.pow((my - sweep) / 0.2, 2.0));
                float flick = 0.8f + 0.2f * Mth.sin(t * 0.45f + i * 1.7f);
                float k = fade * face * flick * (float) (grown * (0.3 + 0.7 * band));
                if (k <= 0.01f) {
                    continue;
                }
                float wl = lw * (float) (1.0 + 0.8 * band);
                d.line(c.x + CELLS[o] * r, c.y + CELLS[o + 1] * r, c.z + CELLS[o + 2] * r,
                        c.x + CELLS[o + 3] * r, c.y + CELLS[o + 4] * r, c.z + CELLS[o + 5] * r, wl, wl, Draw.mix(rgb, hot, band), k, k);
            }
            d.body(oldBody);
            if (t < 6f) {
                d.glow(c.x, c.y, c.z, (float) (r * 1.3), hot, fade * (1f - t / 6f));
            }
        }
    }

    // ================================================================== Lance

    /** Berkas energi HD dari a ke b: tumbuh cepat, inti putih, dua pilinan cahaya, cincin yang meluncur, kilau di ujung. */
    public static final class Lance extends Effect {
        private final Vec3 a, b;
        private final int rgb, hot, grow;
        private final float width;
        private final float[] pts = new float[25 * 3];
        private final float[] w = new float[25];
        private final float[] al = new float[25];

        public Lance(Vec3 a, Vec3 b, float width, int rgb, int hot, int grow, int life) {
            super(life);
            this.a = a;
            this.b = b;
            this.width = width;
            this.rgb = rgb;
            this.hot = hot;
            this.grow = Math.max(1, grow);
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float t = time(pt);
            float u = progress(pt);
            float reach = Math.min(1f, t / grow);
            float fade = (float) Math.pow(1.0 - u, 1.4) * Math.min(1f, t / 1f);
            if (fade <= 0.01f) {
                return;
            }
            double dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z;
            double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (len < 0.05) {
                return;
            }
            double ex = a.x + dx * reach, ey = a.y + dy * reach, ez = a.z + dz * reach;
            d.beam(a.x, a.y, a.z, ex, ey, ez, width * (0.65f + 0.35f * fade), rgb, hot, fade * 0.85f, fade);
            double nx = dx / len, ny = dy / len, nz = dz / len;
            double[] e = new double[6];
            Draw.plane(nx, ny, nz, e);
            for (int s = 0; s < 2; s++) {   // dua pilinan
                int n = 25;
                for (int i = 0; i < n; i++) {
                    double v = i / (double) (n - 1) * reach;
                    double ang = v * len * 4.0 + t * 0.9 + s * Math.PI;
                    double rr = width * (1.1 + 0.4 * Math.sin(v * 9.0 + t * 0.3));
                    double ox = (e[0] * Math.cos(ang) + e[3] * Math.sin(ang)) * rr;
                    double oy = (e[1] * Math.cos(ang) + e[4] * Math.sin(ang)) * rr;
                    double oz = (e[2] * Math.cos(ang) + e[5] * Math.sin(ang)) * rr;
                    pts[i * 3] = (float) (a.x + dx * v + ox);
                    pts[i * 3 + 1] = (float) (a.y + dy * v + oy);
                    pts[i * 3 + 2] = (float) (a.z + dz * v + oz);
                    w[i] = width * 0.22f;
                    al[i] = fade * 0.75f * (float) Math.sin(Math.PI * Math.min(1.0, i / (double) (n - 1) + 0.05));
                }
                d.strip(pts, n, w, 1f, al, 1f, hot);
            }
            for (int k = 0; k < 3; k++) {   // cincin yang meluncur di sepanjang berkas
                double v = ((t * 0.12 + k / 3.0) % 1.0) * reach;
                d.ring(a.x + dx * v, a.y + dy * v, a.z + dz * v, nx, ny, nz, width * (1.4 + v), width * 0.25, rgb,
                        fade * 0.55f * (float) Math.sin(Math.PI * v), 0f, null);
            }
            d.glow(ex, ey, ez, width * 7f, rgb, fade * 0.6f);
            d.glow(ex, ey, ez, width * 2.4f, 0xFFFFFF, fade);
        }
    }

    // ================================================================== Ghost

    /**
     * Bayangan cahaya berbentuk badan di posisi & arah tertentu (ditinggalkan lesatan / pukulan secepat kilat), memudar.
     * pose: 0 = berdiri, 1 = melesat (condong ke depan, lengan ke belakang), 2 = tinju kanan, 3 = tinju kiri.
     */
    public static final class Ghost extends Effect {
        private final double x, y, z, scale, fx, fz, rx, rz;
        private final int rgb, hot, pose;
        private final float strength;

        public Ghost(Vec3 feet, float bodyYaw, double scale, int pose, int rgb, int hot, int life, float strength) {
            super(life);
            this.x = feet.x;
            this.y = feet.y;
            this.z = feet.z;
            this.scale = scale;
            float yaw = bodyYaw * Mth.DEG_TO_RAD;
            this.fx = -Mth.sin(yaw);
            this.fz = Mth.cos(yaw);
            this.rx = -Mth.cos(yaw);
            this.rz = -Mth.sin(yaw);
            this.pose = pose;
            this.rgb = rgb;
            this.hot = hot;
            this.strength = strength;
        }

        /** Titik lokal (kanan, atas, depan) -> dunia, dengan condong ke depan. */
        private double[] p(double right, double up, double fwd, double lean) {
            double cl = Math.cos(lean), sl = Math.sin(lean);
            double u2 = up * cl - fwd * sl, f2 = fwd * cl + up * sl;
            return new double[] {x + (rx * right + fx * f2) * scale, y + u2 * scale, z + (rz * right + fz * f2) * scale};
        }

        private void seg(Draw d, double[] a, double[] b, float wa, float wb, int c, float k) {
            d.line(a[0], a[1], a[2], b[0], b[1], b[2], (float) (wa * scale), (float) (wb * scale), c, k, k);
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float u = progress(pt);
            float k = strength * (float) Math.pow(1.0 - u, 1.6);
            if (k <= 0.01f) {
                return;
            }
            double lean = pose == 1 ? 0.55 : (pose >= 2 ? 0.2 : 0.0);
            double[] hip = p(0, 0.78, 0, lean), neck = p(0, 1.42, 0, lean), head = p(0, 1.66, 0.02, lean);
            double[] shR = p(0.24, 1.38, 0, lean), shL = p(-0.24, 1.38, 0, lean);
            double[] handR, handL, footR, footL;
            switch (pose) {
                case 1 -> {
                    handR = p(0.3, 0.95, -0.55, lean);
                    handL = p(-0.3, 0.95, -0.55, lean);
                    footR = p(0.12, 0.05, -0.45, lean);
                    footL = p(-0.12, 0.2, 0.35, lean);
                }
                case 2 -> {
                    handR = p(0.12, 1.4, 0.8, lean);
                    handL = p(-0.3, 1.05, 0.15, lean);
                    footR = p(0.14, 0.0, -0.25, lean);
                    footL = p(-0.14, 0.0, 0.25, lean);
                }
                case 3 -> {
                    handR = p(0.3, 1.05, 0.15, lean);
                    handL = p(-0.12, 1.4, 0.8, lean);
                    footR = p(0.14, 0.0, 0.25, lean);
                    footL = p(-0.14, 0.0, -0.25, lean);
                }
                default -> {
                    handR = p(0.3, 0.75, 0.05, lean);
                    handL = p(-0.3, 0.75, 0.05, lean);
                    footR = p(0.12, 0.0, 0, lean);
                    footL = p(-0.12, 0.0, 0, lean);
                }
            }
            float body = k * 0.55f;
            seg(d, hip, neck, 0.42f, 0.5f, rgb, body);
            seg(d, shR, handR, 0.22f, 0.18f, rgb, body);
            seg(d, shL, handL, 0.22f, 0.18f, rgb, body);
            seg(d, hip, footR, 0.24f, 0.18f, rgb, body);
            seg(d, hip, footL, 0.24f, 0.18f, rgb, body);
            seg(d, hip, neck, 0.12f, 0.14f, hot, k * 0.8f);
            seg(d, shR, shL, 0.12f, 0.12f, hot, k * 0.6f);
            d.glow(head[0], head[1], head[2], (float) (0.32 * scale), rgb, k * 0.7f);
            d.glow(head[0], head[1], head[2], (float) (0.14 * scale), hot, k);
            if (pose >= 2) {   // kepalan yang memukul menyala
                double[] fist = pose == 2 ? handR : handL;
                d.glow(fist[0], fist[1], fist[2], (float) (0.35 * scale), hot, k);
            }
        }
    }

    // ================================================================== Haze

    /** Riak udara panas: pita-pita tipis tembus pandang yang naik berkelok (lapisan soft). */
    public static final class Haze extends Effect {
        private static final int N = 8;
        private final Lightning.Anchor base;
        private final double radius, height;
        private final int strands, rgb;
        private final float strength;
        private final float[] pts = new float[N * 3];
        private final float[] w = new float[N];
        private final float[] a = new float[N];

        public Haze(Lightning.Anchor base, double radius, double height, int strands, int rgb, int life, float strength) {
            super(life);
            this.base = base;
            this.radius = radius;
            this.height = height;
            this.strands = Math.max(1, strands);
            this.rgb = rgb;
            this.strength = strength;
        }

        @Override
        public void renderSoft(Draw d) {
            float pt = d.partialTick;
            Vec3 b = at(base, pt);
            if (b == null) {
                return;
            }
            float t = time(pt);
            float fade = Math.min(1f, t / 8f) * Math.min(1f, (life - t) / 12f) * strength;
            if (fade <= 0.01f) {
                return;
            }
            for (int s = 0; s < strands; s++) {
                double ang = Math.PI * 2.0 * s / strands + s * 0.37;
                double rr = radius * (0.35 + 0.65 * ((s * 0.618) % 1.0));
                double phase = (t * 0.035 + s * 0.29) % 1.0;
                for (int j = 0; j < N; j++) {
                    double v = j / (double) (N - 1);
                    double yy = b.y + (phase * 0.6 + v * 0.7) * height;
                    double sway = Math.sin(t * 0.25 + v * 6.0 + s) * radius * 0.12;
                    pts[j * 3] = (float) (b.x + Math.cos(ang) * rr + sway);
                    pts[j * 3 + 1] = (float) yy;
                    pts[j * 3 + 2] = (float) (b.z + Math.sin(ang) * rr + Math.cos(t * 0.21 + v * 5.0 + s) * radius * 0.12);
                    w[j] = (float) (radius * 0.16 * (1.0 - v * 0.5));
                    a[j] = fade * 0.09f * (float) Math.sin(Math.PI * v) * (float) Math.sin(Math.PI * phase);
                }
                d.strip(pts, N, w, 1f, a, 1f, rgb);
            }
        }
    }
}
