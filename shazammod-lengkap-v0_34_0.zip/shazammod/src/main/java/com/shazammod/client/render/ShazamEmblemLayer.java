package com.shazammod.client.render;


import org.joml.Matrix4f;
import org.joml.Vector3f;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.ShazamMod;
import com.shazammod.client.anim.Ease;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.fx.RodStrikeFx;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Lambang 3D di dada saat jadi Shazam / Black Adam, terang sendiri dan berkilau.
 * Bentuk dan warnanya dari gambar lambang juaranya (FormLook.emblem): shazam_emblem.png dan adam_emblem.png di
 * assets/shazammod/textures/entity/. Tiap piksel yang tidak transparan jadi balok kecil yang timbul dari dada
 * (maksimal 64x64 piksel).
 */
public class ShazamEmblemLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation WHITE = ShazamMod.id("textures/entity/shazam_white.png");

    // ======= Ukuran & posisi (piksel model: dada lebar 8, tinggi 12, permukaan depan di z = -2) =======
    private static final float WIDTH = 6.0f;        // lebar lambang
    private static final float TOP = 1.2f;          // jarak dari leher
    private static final float SURFACE_Z = -2.3f;   // menempel di depan baju
    private static final float DEPTH = 0.7f;        // ketebalan (timbul)
    private static final int SPARKLE_EVERY = 9;     // percikan cahaya tiap ±0,45 detik

    private static final EmblemImage[] IMAGES = new EmblemImage[FormLook.COUNT];
    private static final boolean[] LOADED = new boolean[FormLook.COUNT];

    public ShazamEmblemLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    /** Dipanggil saat resource pack dimuat ulang (F3+T). */
    public static void reset() {
        for (int i = 0; i < LOADED.length; i++) {
            LOADED[i] = false;
            IMAGES[i] = null;
        }
    }

    static EmblemImage image(FormLook look) {
        int i = look.index;
        if (!LOADED[i]) {
            LOADED[i] = true;
            IMAGES[i] = EmblemImage.load(look.emblem);
            if (IMAGES[i] == null && look != FormLook.SHAZAM) {
                IMAGES[i] = image(FormLook.SHAZAM);   // gambar juara ini hilang dari resource pack: pakai lambang Shazam
            }
        }
        return IMAGES[i];
    }

    /** Besar lambang 0-1: muncul memantul saat berubah, mengecil hilang saat kembali jadi manusia. */
    private static float size(AbstractClientPlayer player, float partialTick) {
        float t = ShazamCape.revealTime(player, partialTick);
        if (t >= 0f) {
            float s = (t - ShazamCape.EMBLEM_APPEAR) / 6f;
            return s <= 0f ? 0f : s >= 1f ? 1f : Ease.OUT_BACK.apply(s);
        }
        if (!ShazamPoses.suitIn(player)) {
            float out = ShazamPoses.suitTicks(player, partialTick);
            if (out >= 0f) {
                return Math.max(0f, 1f - out / 5f);
            }
        }
        return 0f;
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, AbstractClientPlayer player,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (player.isInvisible()) {
            return;
        }
        float size = size(player, partialTick);
        if (size <= 0.001f) {
            return;
        }
        FormLook look = FormLook.of(player.getId());
        EmblemImage img = image(look);
        if (img == null) {
            return;
        }
        int width = img.width;
        int height = img.height;
        float pixel = WIDTH / width;
        float h = pixel * height;
        float x0 = -WIDTH / 2f;
        float y0 = -h / 2f;

        poseStack.pushPose();
        this.getParentModel().body.translateAndRotate(poseStack);
        poseStack.scale(1f / 16f, 1f / 16f, 1f / 16f);
        poseStack.translate(0f, TOP + h / 2f, SURFACE_Z);
        poseStack.scale(size, size, size);
        PoseStack.Pose pose = poseStack.last();

        // 1) Balok-balok lambang, terang sendiri walau di tempat gelap
        VertexConsumer solid = buffer.getBuffer(RenderType.entityCutoutNoCull(WHITE));
        int light = LightTexture.FULL_BRIGHT;
        for (int py = 0; py < height; py++) {
            for (int px = 0; px < width; px++) {
                if (!img.filled(px, py)) {
                    continue;
                }
                int color = img.color(px, py);
                float xa = x0 + px * pixel, xb = xa + pixel;
                float ya = y0 + py * pixel, yb = ya + pixel;
                float zf = -DEPTH;
                solidQuad(solid, pose, color, light, 0f, 0f, -1f, xa, ya, zf, xb, ya, zf, xb, yb, zf, xa, yb, zf);
                if (!img.filled(px - 1, py)) {
                    solidQuad(solid, pose, color, light, -1f, 0f, 0f, xa, ya, 0f, xa, ya, zf, xa, yb, zf, xa, yb, 0f);
                }
                if (!img.filled(px + 1, py)) {
                    solidQuad(solid, pose, color, light, 1f, 0f, 0f, xb, ya, zf, xb, ya, 0f, xb, yb, 0f, xb, yb, zf);
                }
                if (!img.filled(px, py - 1)) {
                    solidQuad(solid, pose, color, light, 0f, -1f, 0f, xa, ya, 0f, xb, ya, 0f, xb, ya, zf, xa, ya, zf);
                }
                if (!img.filled(px, py + 1)) {
                    solidQuad(solid, pose, color, light, 0f, 1f, 0f, xa, yb, zf, xb, yb, zf, xb, yb, 0f, xa, yb, 0f);
                }
            }
        }

        // 2) Kilau: cahaya berdenyut di sekitar, kilatan putih menyapu, dan kilat terang saat baru muncul
        VertexConsumer additive = buffer.getBuffer(RenderType.lightning());
        float reveal = ShazamCape.revealTime(player, partialTick);
        float flash = reveal >= 0f ? Mth.clamp(1f - (reveal - ShazamCape.EMBLEM_APPEAR) / 12f, 0f, 1f) : 0f;
        flash = Math.max(flash, RodStrikeFx.glow(player, partialTick));   // 0.25: petir menghantam lambang
        float pulse = EmblemImage.pulse(ageInTicks, flash);
        float zGlow = -DEPTH - 0.03f;
        for (int py = 0; py < height; py++) {
            for (int px = 0; px < width; px++) {
                if (!img.filled(px, py)) {
                    continue;
                }
                float sweep = img.sweep(px, py, ageInTicks);
                float strength = 0.18f * pulse + 0.85f * sweep;
                if (strength <= 0.02f) {
                    continue;
                }
                float xa = x0 + px * pixel, ya = y0 + py * pixel;
                glowQuad(additive, pose, look.emblemSweep[0], look.emblemSweep[1], look.emblemSweep[2], strength,
                        xa, ya, xa + pixel, ya + pixel, zGlow);
            }
        }
        int range = EmblemImage.GLOW_RANGE;
        for (int gy = 0; gy < height + 2 * range; gy++) {
            for (int gx = 0; gx < width + 2 * range; gx++) {
                float g = img.glow(gx, gy);
                if (g <= 0f) {
                    continue;
                }
                float xa = x0 + (gx - range) * pixel, ya = y0 + (gy - range) * pixel;
                glowQuad(additive, pose, look.emblemHalo[0], look.emblemHalo[1], look.emblemHalo[2], g * pulse * 0.8f,
                        xa, ya, xa + pixel, ya + pixel, -0.05f);
            }
        }
        poseStack.popPose();
    }

    private static void solidQuad(VertexConsumer vc, PoseStack.Pose pose, int color, int light, float nx, float ny, float nz,
                                  float x1, float y1, float z1, float x2, float y2, float z2,
                                  float x3, float y3, float z3, float x4, float y4, float z4) {
        int r = (color >> 16) & 0xFF, g = (color >> 8) & 0xFF, b = color & 0xFF;
        solidVertex(vc, pose, x1, y1, z1, r, g, b, light, nx, ny, nz);
        solidVertex(vc, pose, x2, y2, z2, r, g, b, light, nx, ny, nz);
        solidVertex(vc, pose, x3, y3, z3, r, g, b, light, nx, ny, nz);
        solidVertex(vc, pose, x4, y4, z4, r, g, b, light, nx, ny, nz);
    }

    private static void solidVertex(VertexConsumer vc, PoseStack.Pose pose, float x, float y, float z, int r, int g, int b,
                                    int light, float nx, float ny, float nz) {
        vc.addVertex(pose, x, y, z).setColor(r, g, b, 255).setUv(0.5f, 0.5f)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(pose, nx, ny, nz);
    }

    /** Segi empat cahaya (aditif), dua sisi supaya terlihat dari arah mana pun. */
    private static void glowQuad(VertexConsumer vc, PoseStack.Pose pose, int r, int g, int b, float strength,
                                 float xa, float ya, float xb, float yb, float z) {
        int a = (int) (Mth.clamp(strength, 0f, 1f) * 255f);
        vc.addVertex(pose, xa, ya, z).setColor(r, g, b, a);
        vc.addVertex(pose, xb, ya, z).setColor(r, g, b, a);
        vc.addVertex(pose, xb, yb, z).setColor(r, g, b, a);
        vc.addVertex(pose, xa, yb, z).setColor(r, g, b, a);
        vc.addVertex(pose, xa, yb, z).setColor(r, g, b, a);
        vc.addVertex(pose, xb, yb, z).setColor(r, g, b, a);
        vc.addVertex(pose, xb, ya, z).setColor(r, g, b, a);
        vc.addVertex(pose, xa, ya, z).setColor(r, g, b, a);
    }

    /**
     * Lambang dada bayangan Mercury: kilat emas yang menyala (aditif), cukup setengah resolusi.
     * poseStack = pose badan bayangan yang sedang digambar, vc = render aditif (Draw.additiveType).
     */
    public static void ghostGlow(PoseStack poseStack, PlayerModel<?> model, VertexConsumer vc, float strength, FormLook look) {
        EmblemImage img = image(look);
        if (img == null || strength <= 0.02f) {
            return;
        }
        int width = img.width;
        int height = img.height;
        float pixel = WIDTH / width;
        float h = pixel * height;
        float x0 = -WIDTH / 2f;
        float y0 = -h / 2f;
        int step = width > 24 ? 2 : 1;
        float k = Mth.clamp(strength, 0f, 1.4f);
        int[] c = look.emblemHalo;
        int r = Math.min(255, (int) (c[0] * k)), g = Math.min(255, (int) ((c[1] + 10) * k)), b = Math.min(255, (int) ((c[2] + 30) * k));
        poseStack.pushPose();
        model.body.translateAndRotate(poseStack);
        poseStack.scale(1f / 16f, 1f / 16f, 1f / 16f);
        poseStack.translate(0f, TOP + h / 2f, SURFACE_Z - 0.15f);
        PoseStack.Pose pose = poseStack.last();
        for (int py = 0; py < height; py += step) {
            for (int px = 0; px < width; px += step) {
                if (!img.filled(px, py) && !(step > 1
                        && (img.filled(px + 1, py) || img.filled(px, py + 1) || img.filled(px + 1, py + 1)))) {
                    continue;
                }
                float xa = x0 + px * pixel, ya = y0 + py * pixel, xb = xa + pixel * step, yb = ya + pixel * step;
                ghostVertex(vc, pose, xa, ya, r, g, b);
                ghostVertex(vc, pose, xb, ya, r, g, b);
                ghostVertex(vc, pose, xb, yb, r, g, b);
                ghostVertex(vc, pose, xa, yb, r, g, b);
                ghostVertex(vc, pose, xa, yb, r, g, b);
                ghostVertex(vc, pose, xb, yb, r, g, b);
                ghostVertex(vc, pose, xb, ya, r, g, b);
                ghostVertex(vc, pose, xa, ya, r, g, b);
            }
        }
        poseStack.popPose();
    }

    private static void ghostVertex(VertexConsumer vc, PoseStack.Pose pose, float x, float y, int r, int g, int b) {
        vc.addVertex(pose, x, y, 0f).setColor(r, g, b, 255).setUv(0.5f, 0.5f).setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(LightTexture.FULL_BRIGHT).setNormal(pose, 0f, 0f, -1f);
    }

    /** Percikan cahaya kecil sesekali dari lambang. */
    public static void tick(ClientLevel level) {
        Minecraft mc = Minecraft.getInstance();
        for (AbstractClientPlayer player : level.players()) {
            if (player.isInvisible() || ShazamCape.revealTime(player, 0f) < ShazamCape.EMBLEM_APPEAR + 6) {
                continue;
            }
            if ((player.tickCount + player.getId()) % SPARKLE_EVERY != 0) {
                continue;
            }
            if (player == mc.player && mc.options.getCameraType().isFirstPerson()) {
                continue;
            }
            Matrix4f body = ShazamPoses.bodyMatrix(player, 1f, player.yBodyRot);
            Vector3f p = body.transformPosition(new Vector3f(
                    (level.random.nextFloat() - 0.5f) * 0.3f, 1.16f + (level.random.nextFloat() - 0.5f) * 0.3f, -0.2f));
            Vfx.glint(player.getX() + p.x, player.getY() + p.y, player.getZ() + p.z, FormLook.of(player.getId()).sparkle,
                    0.16f + level.random.nextFloat() * 0.08f, 9 + level.random.nextInt(5));
        }
    }
}
