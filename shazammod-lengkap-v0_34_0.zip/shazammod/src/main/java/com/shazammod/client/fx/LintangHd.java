package com.shazammod.client.fx;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

import com.shazammod.PassiveConditions;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Hd;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * 0.34 Lapisan VFX HD Lintang (di atas LintangFx & LintangCine): tiap skill punya ancang-ancang yang terlihat (cahaya
 * terserap masuk), hantaman bervolume (bola ledakan surya, gelombang tekanan, korona, plasma), dan sisa yang pelan
 * memudar (riak panas, es yang merambat). Mode Surya: korona & lengkung plasma mengelilingi badan selama aktif.
 * Dipanggil dari LintangCine (penguat Lintang sudah terpasang, jadi semua efek di sini digambar HD + bloom).
 */
public final class LintangHd {
    private LintangHd() {}

    // palet surya: putih panas -> emas -> jingga -> merah tembaga
    static final int SUN_WHITE = 0xFFFBEA;
    static final int SUN_GOLD = 0xFFD54A;
    static final int SUN_ORANGE = 0xFF9A1F;
    static final int SUN_COPPER = 0xD9531C;
    static final int WHITE = 0xFFFFFF;
    static final int HEAT = 0xFF6A2A;
    static final int FROST = 0xD6F4FF;
    static final int ICE = 0x8FDCFF;
    static final int CRYON = 0x3CFF86;
    static final int AIR = 0xEAF4FF;
    static final int DUST = 0xD9C18A;
    static final int DUST_SMOKE = 0x7A6A55;
    static final Vec3 UP = HdKit.UP;
    static final Vec3 DOWN = new Vec3(0, -1, 0);

    /** Mode Surya: korona & plasma yang sedang tampil per pemain (sampai game time ini). */
    private static final Map<Integer, Long> RAGE = new HashMap<>();

    public static void clear() {
        RAGE.clear();
    }

    private static boolean alive(AbstractClientPlayer p) {
        return p.isAlive() && !p.isRemoved();
    }

    private static void later(AbstractClientPlayer p, int delay, Runnable r) {
        if (delay <= 0) {
            r.run();
            return;
        }
        ShazamFx.schedule(delay, 1, (lvl, t) -> {
            if (alive(p)) {
                r.run();
            }
        });
    }

    private static Vec3 look(AbstractClientPlayer p) {
        return p.getViewVector(1f);
    }

    private static Vec3 mouth(AbstractClientPlayer p) {
        Vec3 e = p.getEyePosition(1f), l = look(p);
        return new Vec3(e.x + l.x * 0.3, e.y - 0.16 + l.y * 0.2, e.z + l.z * 0.3);
    }

    /** Nova surya (cahaya murni) atau berdebu (smoke != 0, di tanah). */
    private static void nova(Vec3 at, double radius, int life, float strength, boolean ground) {
        Vfx.add(new Hd.Nova(at, radius, SUN_WHITE, SUN_GOLD, SUN_ORANGE, ground ? DUST_SMOKE : 0, life, strength, ground));
    }

    private static void streakJet(Vec3 from, Vec3 dir, double base, double speed, double spread, int rgb, float size, int life) {
        RandomSource r = Vfx.random();
        for (int i = 0, n = HdKit.n(base); i < n; i++) {
            Vec3 d = HdKit.jitter(r, dir, spread);
            double s = speed * (0.6 + r.nextDouble() * 0.7);
            Vfx.streak(from.x, from.y, from.z, d.x * s, d.y * s, d.z * s, rgb, size * (0.7f + r.nextFloat() * 0.6f), life + r.nextInt(4));
        }
    }

    // ------------------------------------------------------------------ titik masuk

    public static void onAnim(AbstractClientPlayer p, ShazamAnim a, Vec3 pos) {
        try {
            onAnim0(p, a, pos);
        } catch (Throwable ignored) {
            // lapisan HD nggak boleh bikin game crash
        }
    }

    private static void onAnim0(AbstractClientPlayer p, ShazamAnim a, Vec3 pos) {
        ClientLevel level = HdKit.level(p);
        boolean fp = HdKit.firstPerson(p);
        float near = fp ? 0.35f : 1f;   // orang pertama: efek di badan sendiri ditipiskan supaya layar nggak tertutup
        switch (a) {
            case SUMMON -> charge(p, near);
            case TRANSFORM -> later(p, ShazamAnim.TRANSFORM_STRIKE, () -> ignite(level, p, near));
            case REVERT, KNOCKOUT -> later(p, a == ShazamAnim.REVERT ? ShazamAnim.REVERT_WINDUP : ShazamAnim.KNOCKOUT_BURST, () -> {
                Vec3 c = HdKit.chest(p);
                HdKit.streaks(c, 10, 0.32, SUN_GOLD, 0.05f, 12);
                Vfx.add(new Hd.Pressure(c, UP, 2.4, Math.PI, SUN_WHITE, 10, 0.45f * near, false));
            });
            case LAUNCH -> {
                Vec3 f = HdKit.feet(p);
                Vfx.add(new Hd.Pressure(f, DOWN, 3.6, 1.15, AIR, 12, 0.6f, true));
                streakJet(f, DOWN, 10, 0.6, 0.7, AIR, 0.06f, 7);
            }
            case LAND_HERO, CRASH -> {
                boolean big = a == ShazamAnim.CRASH;
                Vec3 f = HdKit.groundAt(level, p, HdKit.feet(p));
                Vfx.add(new Hd.Nova(f, big ? 3.0 : 1.8, 0xFFF6E0, DUST, 0x8A7A64, DUST_SMOKE, big ? 26 : 18, 0.7f, true));
                Vfx.add(new Hd.Pressure(f, UP, big ? 8.0 : 4.8, 1.45, 0xF4F0E8, 14, 0.55f, true));
                HdKit.streaks(f.add(0, 0.3, 0), big ? 16 : 8, 0.6, SUN_GOLD, 0.05f, 8);
            }
            case SONIC_BOOM -> {
                Vec3 c = HdKit.chest(p), l = look(p);
                Vfx.add(new Hd.Pressure(c.add(l.scale(0.4)), l.scale(-1), 3.6, 1.05, AIR, 14, 0.75f * near, true));
                Vfx.add(new Hd.Pressure(c, l, 2.4, 0.9, WHITE, 8, 0.6f * near, false));
                streakJet(c, l.scale(-1), 14, 0.9, 0.35, AIR, 0.06f, 7);
            }
            case LINTANG_DASH -> dash(level, p, pos, near);
            case LINTANG_EYES -> {
                Vfx.add(new Hd.Haze(pt -> p.isRemoved() ? null : p.getEyePosition(pt).add(0, 0.1, 0), 0.35, 0.8, 4, 0xFFE8D0,
                        ShazamAnim.IRIS_WINDUP + ShazamAnim.IRIS_TICKS, 0.8f));
                if (!fp) {
                    HdKit.streaksIn(p.getEyePosition(1f), 5, 0.9, HEAT, 0.03f, ShazamAnim.IRIS_WINDUP);
                }
            }
            case LINTANG_BREATH -> breath(level, p, near);
            case LINTANG_CLAP -> clap(level, p, near);
            case LINTANG_BARRAGE -> barrage(level, p, pos);
            case LINTANG_HIT -> {
                if (pos != null) {
                    nova(pos, 0.65, 8, 0.8f, false);
                    HdKit.streaks(pos, 5, 0.38, SUN_GOLD, 0.05f, 6);
                }
            }
            case LINTANG_LEAP -> later(p, ShazamAnim.LEAP_WINDUP, () -> {
                Vec3 f = HdKit.feet(p);
                Vfx.add(new Hd.Pressure(f, DOWN, 4.0, 1.2, AIR, 12, 0.6f, true));
                streakJet(f, DOWN, 12, 0.7, 0.8, AIR, 0.06f, 8);
                ShazamFx.schedule(0, 12, (lvl, t) -> {   // jejak cahaya di bawah badan selama naik
                    if (!alive(p)) {
                        return;
                    }
                    Vec3 ff = HdKit.feet(p);
                    Vfx.streak(ff.x, ff.y, ff.z, 0, -0.25, 0, SUN_GOLD, 0.08f, 6);
                });
            });
            case LINTANG_SLAM -> slam(level, p, pos != null ? pos : HdKit.feet(p));
            case LINTANG_FLARE -> flare(level, p, near);
            case LINTANG_CALL -> call(p, near);
            case LINTANG_RESCUE -> later(p, ShazamAnim.RESCUE_WINDUP, () -> {
                Vec3 c = HdKit.chest(p);
                nova(c, 1.1, 10, 0.7f * near, false);
                HdKit.streaks(c, 12, 0.6, SUN_GOLD, 0.06f, 8);
            });
            case LINTANG_SAVE -> save(level, p, pos);
            case LINTANG_LANCE, HERO_CALL -> {
                if (pos != null) {
                    Vfx.add(new Hd.Lance(HdKit.chest(p), pos, 0.2f, SUN_GOLD, SUN_WHITE, 2, 12));
                    nova(pos, 0.9, 10, 0.8f, false);
                }
            }
            case LINTANG_PULSE -> {
                if (!fp) {
                    Vfx.add(new Hd.Corona(HdKit.chestAnchor(p), 0.22, 1.25, 14, SUN_GOLD, SUN_WHITE, 14, 0.55f, null));
                }
                HdKit.streaksIn(HdKit.chest(p), 4, 1.3, SUN_GOLD, 0.04f, 7);
            }
            case LINTANG_DAWNPUNCH -> {
                if (pos != null) {
                    Vec3 dir = HdKit.norm(pos.subtract(HdKit.chest(p)));
                    nova(pos, 2.2, 18, 1f, false);
                    Vfx.add(new Hd.Pressure(pos, dir, 6.5, 1.1, SUN_WHITE, 14, 0.7f, true));
                    Vfx.add(new Hd.Corona(Lightning.Anchor.fixed(pos), 0.35, 3.2, 22, SUN_GOLD, SUN_WHITE, 18, 0.9f, null));
                    Vfx.add(new Hd.Lance(pos, pos.add(0, 12, 0), 0.5f, SUN_GOLD, SUN_WHITE, 3, 16));
                    HdKit.streaks(pos, 22, 0.75, SUN_GOLD, 0.07f, 9);
                }
            }
            case LINTANG_PARRY -> {
                if (pos != null) {
                    HdKit.shards(pos, 10, 0.32, ICE, 0.06f, 14, pos.y - 1.6);
                    Vfx.add(new Hd.Pressure(pos, UP, 1.6, Math.PI, FROST, 8, 0.6f, false));
                }
            }
            case LINTANG_BOUNCE -> {
                if (pos != null) {
                    HdKit.streaks(pos, 6, 0.42, WHITE, 0.04f, 5);
                    Vfx.add(new Hd.Pressure(pos, UP, 0.9, Math.PI, 0xE8F0FF, 6, 0.5f, false));
                }
            }
            case LINTANG_PUNCH -> {
                if (pos != null) {
                    nova(pos, 0.45, 6, 0.7f, false);
                    HdKit.streaks(pos, 3, 0.3, SUN_GOLD, 0.04f, 5);
                }
            }
            case LINTANG_FADE -> HdKit.streaks(HdKit.chest(p), 8, 0.22, SUN_ORANGE, 0.04f, 14);
            case LINTANG_RETURN -> {
                HdKit.streaksIn(HdKit.chest(p), 14, 2.2, SUN_GOLD, 0.06f, 10);
                later(p, 10, () -> {
                    if (!fp) {
                        Vfx.add(new Hd.Corona(HdKit.chestAnchor(p), 0.25, 1.6, 16, SUN_GOLD, SUN_WHITE, 16, 0.7f, null));
                    }
                });
            }
            case LINTANG_KELAM -> {
                Vec3 c = HdKit.chest(p);
                HdKit.shards(c, 6, 0.18, CRYON, 0.05f, 16, Double.NaN);
                Vfx.add(new Hd.Haze(HdKit.feetAnchor(p), 0.8, 2.2, 5, 0xB8FFD8, 40, 0.8f));
            }
            case LINTANG_RITE -> rite(level, p);
            default -> {
            }
        }
    }

    // ------------------------------------------------------------------ transformasi

    /** Mengumpulkan tenaga (sebelum Mode Surya): plasma & riak panas, cahaya terserap masuk makin deras. */
    private static void charge(AbstractClientPlayer p, float near) {
        int len = LintangCine.CHARGE_LEN;
        Vfx.add(new Hd.Plasma(HdKit.chestAnchor(p), 0.7, 4, SUN_GOLD, SUN_WHITE, len, 0.75f * near, null));
        Vfx.add(new Hd.Haze(HdKit.feetAnchor(p), 1.2, 2.6, 7, 0xFFF4E0, len, 1f));
        ShazamFx.schedule(4, len - 4, (lvl, t) -> {
            if (!alive(p)) {
                return;
            }
            Vec3 c = HdKit.chest(p);
            float k = t / (float) len;
            if (t % 2 == 0) {
                HdKit.streaksIn(c, 1 + 2 * k, 2.2 + k, SUN_GOLD, 0.05f + 0.03f * k, 9);
            }
            if (t % 18 == 0) {
                Vfx.add(new Hd.Pressure(c, UP, 1.4 + k * 1.8, Math.PI, SUN_WHITE, 10, (0.35f + 0.3f * k) * near, false));
            }
        });
        later(p, len - 30, () -> Vfx.add(new Hd.Corona(HdKit.chestAnchor(p), 0.3, 1.7, 18, SUN_GOLD, SUN_WHITE, 34, 0.7f * near, null)));
    }

    /** Mode Surya menyala: ledakan cahaya dari dalam dada. */
    private static void ignite(ClientLevel level, AbstractClientPlayer p, float near) {
        Vec3 c = HdKit.chest(p), f = HdKit.feet(p);
        nova(c, 3.4, 26, near, false);
        Vfx.add(new Hd.Pressure(c, UP, 9.0, Math.PI, SUN_WHITE, 18, 0.7f, true));
        Vfx.add(new Hd.Corona(HdKit.chestAnchor(p), 0.4, 3.4, 28, SUN_GOLD, SUN_WHITE, 30, near, null));
        Vfx.add(new Hd.Plasma(HdKit.chestAnchor(p), 0.95, 6, SUN_GOLD, SUN_WHITE, 60, 0.9f * near, null));
        HdKit.streaks(c, 26, 0.9, SUN_GOLD, 0.09f, 10);
        HdKit.flames(f, 10, 1.6, 0.12, SUN_ORANGE, 0.2f, 16);
        HdKit.fireWave(level, f, 6.0, 10, SUN_ORANGE, 0.24f, null, 0);
    }

    // ------------------------------------------------------------------ skill

    /** Lesatan Bintang: cahaya terserap (ancang-ancang), lalu jalur cahaya, kerucut uap, dan ledakan di ujung. */
    private static void dash(ClientLevel level, AbstractClientPlayer p, Vec3 pos, float near) {
        HdKit.streaksIn(HdKit.chest(p), 8, 1.5, SUN_GOLD, 0.05f, ShazamAnim.LESAT_WINDUP + 2);
        later(p, ShazamAnim.LESAT_WINDUP, () -> {
            Vec3 l = look(p);
            Vec3 start = HdKit.chest(p);
            Vec3 end = pos != null ? pos.add(0, p.getBbHeight() * 0.68, 0) : start.add(l.scale(16));
            Vec3 dir = HdKit.norm(end.subtract(start));
            Vfx.add(new Hd.Lance(start, end, 0.32f, SUN_GOLD, SUN_WHITE, ShazamAnim.LESAT_TICKS, 20));
            Vfx.add(new Hd.Pressure(start, dir.scale(-1), 3.2, 1.0, AIR, 12, 0.65f * near, true));
            RandomSource r = level.random;
            double len = end.distanceTo(start);
            for (int i = 0, n = HdKit.n(10 + len); i < n; i++) {   // garis kecepatan di sepanjang jalur
                double v = r.nextDouble();
                Vec3 q = start.add(end.subtract(start).scale(v)).add(ShazamFx.randomDir(r).scale(0.6 + r.nextDouble() * 0.6));
                Vfx.streak(q.x, q.y, q.z, dir.x * 0.18, dir.y * 0.18, dir.z * 0.18, i % 3 == 0 ? WHITE : SUN_GOLD, 0.06f, 8 + r.nextInt(6));
            }
            later(p, ShazamAnim.LESAT_TICKS, () -> {
                nova(end, 1.6, 14, 0.85f, false);
                Vfx.add(new Hd.Pressure(end, UP, 3.6, Math.PI, SUN_WHITE, 12, 0.6f, false));
                HdKit.streaks(end, 14, 0.6, SUN_GOLD, 0.06f, 8);
            });
        });
    }

    /** Napas Salju: menarik napas (kabut terhisap), lalu kristal es menyembur & es merambat di tempat yang kena. */
    private static void breath(ClientLevel level, AbstractClientPlayer p, float near) {
        HdKit.streaksIn(mouth(p), 7, 1.3, FROST, 0.04f, ShazamAnim.FROST_WINDUP);
        later(p, ShazamAnim.FROST_WINDUP, () -> {
            int[] decals = {0};
            ShazamFx.schedule(0, ShazamAnim.FROST_TICKS, (lvl, t) -> {
                if (!alive(p)) {
                    return;
                }
                Vec3 m = mouth(p), l = look(p);
                HdKit.shardJet(m.add(l.scale(0.35)), l, 2.0, 0.55, 0.24, ICE, 0.07f, 16);
                if (t % 2 == 0) {
                    streakJet(m.add(l.scale(0.35)), l, 1, 0.75, 0.2, 0xF4FBFF, 0.05f, 8);
                }
                if (t % 9 == 4 && decals[0] < 4) {   // es merambat di tempat hembusan menyentuh
                    Vec3 end = HdKit.rayEnd(lvl, p, m, l, 12.0);
                    if (end.distanceTo(m) < 11.5) {
                        Ground.Map g = ShazamFx.ground(lvl, end, 3.0);
                        if (g != null && g.found && Math.abs(g.centerY - end.y) < 1.5) {
                            Vfx.add(new Hd.Frost(g.center(end), 2.2 + decals[0] * 0.3, ICE, 10, 140, 0.9f, g));
                            HdKit.shards(end, 6, 0.25, ICE, 0.06f, 14, g.centerY);
                            decals[0]++;
                        }
                    }
                }
            });
        });
    }

    /** Tepukan Guruh: tenaga terkumpul di kedua tangan, lalu kubah tekanan udara meledak ke depan. */
    private static void clap(ClientLevel level, AbstractClientPlayer p, float near) {
        int w = ShazamAnim.SONIC_WINDUP;
        ShazamFx.schedule(0, w, (lvl, t) -> {
            if (!alive(p) || t % 2 != 0) {
                return;
            }
            for (boolean right : new boolean[] {true, false}) {
                Vec3 h = ShazamPoses.handPos(p, right, 1f);
                HdKit.streaksIn(h, 1.5, 0.7, AIR, 0.03f, 4);
            }
        });
        later(p, w, () -> {
            Vec3 l = look(p);
            Vec3 h = HdKit.chest(p).add(l.scale(0.7));
            Vfx.add(new Hd.Pressure(h, l, 11.0, 1.05, AIR, 16, 0.85f, true));
            Vfx.add(new Hd.Pressure(h, l, 6.5, 0.85, WHITE, 11, 0.7f, false));
            Vfx.add(new Hd.Pressure(h, UP, 2.4, Math.PI, WHITE, 7, 0.6f * near, false));
            Vfx.add(new Hd.Nova(h, 0.9, WHITE, 0xE6F2FF, 0xA8C8E8, 0, 8, 0.8f * near, false));
            streakJet(h, l, 18, 1.1, 0.5, 0xF4FAFF, 0.07f, 9);
        });
    }

    /** Amukan Kilat: tiap pukulan meledakkan cahaya kecil, pukulan penutup melambungkan tiang cahaya. */
    private static void barrage(ClientLevel level, AbstractClientPlayer p, Vec3 pos) {
        later(p, ShazamAnim.BARRAGE_WINDUP, () -> ShazamFx.schedule(0, ShazamAnim.BARRAGE_TICKS, (lvl, t) -> {
            if (!alive(p)) {
                return;
            }
            Vec3 c = HdKit.chest(p), l = look(p);
            Vec3 target = pos != null ? pos.add(0, 0.9, 0) : c.add(l.scale(1.4));
            RandomSource r = lvl.random;
            if (t % 2 == 0 && t < ShazamAnim.BARRAGE_TICKS - 3) {
                Vec3 hit = target.add((r.nextDouble() - 0.5) * 0.7, (r.nextDouble() - 0.5) * 0.6, (r.nextDouble() - 0.5) * 0.7);
                nova(hit, 0.55, 6, 0.75f, false);
                HdKit.streaks(hit, 4, 0.4, SUN_GOLD, 0.045f, 5);
                Vfx.add(new Hd.Pressure(hit, HdKit.norm(hit.subtract(c)), 1.2, 1.0, AIR, 6, 0.5f, false));
            }
            if (t == ShazamAnim.BARRAGE_TICKS - 2) {   // pukulan penutup: melambung
                nova(target, 1.7, 16, 1f, false);
                Vfx.add(new Hd.Lance(target, target.add(0, 9, 0), 0.45f, SUN_GOLD, SUN_WHITE, 3, 16));
                Vfx.add(new Hd.Pressure(target, UP, 4.5, 1.0, SUN_WHITE, 12, 0.7f, true));
                HdKit.streaks(target, 18, 0.7, SUN_GOLD, 0.07f, 9);
            }
        }));
    }

    /** Napak Langit: hantaman di tanah. */
    private static void slam(ClientLevel level, AbstractClientPlayer p, Vec3 pos) {
        Vec3 at = HdKit.groundAt(level, p, pos);
        Vfx.add(new Hd.Nova(at, 4.2, SUN_WHITE, SUN_GOLD, SUN_ORANGE, DUST_SMOKE, 30, 1f, true));
        Vfx.add(new Hd.Pressure(at, UP, 12.0, 1.4, SUN_WHITE, 22, 0.75f, true));
        Vfx.add(new Hd.Lance(at, at.add(0, 22, 0), 0.9f, SUN_GOLD, SUN_WHITE, 3, 22));
        HdKit.streaks(at.add(0, 0.5, 0), 30, 1.0, SUN_GOLD, 0.08f, 10);
        HdKit.flames(at, 14, 3.0, 0.12, SUN_ORANGE, 0.22f, 18);
        HdKit.fireWave(level, at, 7.0, 10, SUN_ORANGE, 0.26f, null, 0);
        Vfx.add(new Hd.Haze(Lightning.Anchor.fixed(at), 3.0, 3.0, 9, 0xFFF0D8, 80, 1f));
    }

    /** Gelegar Surya: cahaya runtuh ke dada (ancang-ancang), lalu supernova. */
    private static void flare(ClientLevel level, AbstractClientPlayer p, float near) {
        int w = ShazamAnim.FLARE_WINDUP;
        Vfx.add(new Hd.Corona(HdKit.chestAnchor(p), 0.25, 2.6, 26, SUN_GOLD, SUN_WHITE, w + 4, 0.8f * near, null));
        Vfx.add(new Hd.Plasma(HdKit.chestAnchor(p), 0.6, 5, SUN_GOLD, SUN_WHITE, w + 6, 0.8f * near, null));
        ShazamFx.schedule(0, w, (lvl, t) -> {
            if (!alive(p)) {
                return;
            }
            HdKit.streaksIn(HdKit.chest(p), 3 + t * 0.35, 4.2 - t * 0.12, SUN_GOLD, 0.07f, 6);
        });
        later(p, w, () -> {
            Vec3 c = HdKit.chest(p), f = HdKit.feet(p);
            nova(c, 9.0, 40, 1f, false);
            Vfx.add(new Hd.Pressure(c, UP, 18.0, Math.PI, SUN_WHITE, 26, 0.85f, true));
            Vfx.add(new Hd.Pressure(c, UP, 11.0, Math.PI, WHITE, 16, 0.7f, false));
            Vfx.add(new Hd.Corona(HdKit.chestAnchor(p), 0.6, 9.0, 40, SUN_GOLD, SUN_WHITE, 46, near, null));
            Vfx.add(new Hd.Plasma(HdKit.chestAnchor(p), 1.4, 8, SUN_GOLD, SUN_WHITE, 80, near, null));
            HdKit.streaks(c, 70, 1.6, SUN_GOLD, 0.12f, 14);
            HdKit.fireWave(level, f, 12.0, 16, SUN_ORANGE, 0.32f, null, 0);
            Vfx.add(new Hd.Haze(HdKit.feetAnchor(p), 4.0, 4.0, 12, 0xFFF4E0, 120, 1f));
        });
    }

    /** Serap Surya: pusaran cahaya turun ke badan, hujan foton, lalu kilatan serapan. */
    private static void call(AbstractClientPlayer p, float near) {
        int w = ShazamAnim.SUNCALL_WINDUP;
        Vfx.add(new Hd.Vortex(HdKit.feetAnchor(p), 0.5, 2.6, 9.0, 3, 1.6, 0.18f, SUN_GOLD, SUN_WHITE, 0, -0.15f, w + 30, 0.8f * near));
        ShazamFx.schedule(0, w + 20, (lvl, t) -> {
            if (!alive(p)) {
                return;
            }
            RandomSource r = lvl.random;
            for (int i = 0, n = HdKit.n(1.2); i < n; i++) {   // hujan foton ke badan
                double a = r.nextDouble() * Math.PI * 2.0, rr = r.nextDouble() * 1.6;
                Vec3 f = HdKit.feet(p);
                Vfx.streak(f.x + Math.cos(a) * rr, f.y + 6 + r.nextDouble() * 4, f.z + Math.sin(a) * rr, 0, -0.65, 0,
                        i % 2 == 0 ? SUN_GOLD : SUN_WHITE, 0.07f, 9);
            }
        });
        later(p, w, () -> {
            Vec3 c = HdKit.chest(p);
            nova(c, 1.8, 14, 0.8f * near, false);
            Vfx.add(new Hd.Plasma(HdKit.chestAnchor(p), 0.8, 4, SUN_GOLD, SUN_WHITE, 40, 0.8f * near, null));
            Vfx.add(new Hd.Pressure(c, UP, 6.0, Math.PI, SUN_WHITE, 14, 0.6f, true));
        });
    }

    /** Satu sekutu diselamatkan: kilatan kedatangan, sosok cahaya, perisai heksagon. */
    private static void save(ClientLevel level, AbstractClientPlayer p, Vec3 pos) {
        if (pos == null) {
            return;
        }
        LivingEntity ally = null;
        double best = 4.0;
        List<LivingEntity> near = level.getEntitiesOfClass(LivingEntity.class, new AABB(pos, pos).inflate(1.6), e -> e != p && e.isAlive());
        for (LivingEntity e : near) {
            double d = e.position().distanceToSqr(pos);
            if (d < best) {
                best = d;
                ally = e;
            }
        }
        Lightning.Anchor anchor;
        double radius;
        if (ally != null) {
            LivingEntity target = ally;
            double h = target.getBbHeight() * 0.5;
            anchor = pt -> target.isRemoved() ? null : target.getPosition(pt).add(0, h, 0);
            radius = Math.max(0.8, Math.max(target.getBbWidth(), target.getBbHeight()) * 0.75);
        } else {
            anchor = Lightning.Anchor.fixed(pos.add(0, 0.9, 0));
            radius = 1.2;
        }
        Vfx.add(new Hd.Shield(anchor, radius, SUN_GOLD, SUN_WHITE, 50, 0.85f));
        nova(pos.add(0, 0.6, 0), 0.9, 10, 0.7f, false);
        Vfx.add(new Hd.Ghost(pos, p.yBodyRot, p.getScale(), 0, SUN_GOLD, SUN_WHITE, 12, 0.7f));
        HdKit.streaks(pos.add(0, 0.8, 0), 8, 0.4, SUN_GOLD, 0.05f, 8);
    }

    /** Eksperimen Evolusi Surya (wujud manusia): plasma & cahaya terserap, lalu ledakan evolusi di tick 104. */
    private static void rite(ClientLevel level, AbstractClientPlayer p) {
        Supplier<Float> running = () -> LintangCine.experimentAge(p, 0f) >= 0f && alive(p) ? 1f : 0f;
        ShazamFx.schedule(14, 1, (lvl, t) -> {
            if (running.get() > 0f) {
                Vfx.add(new Hd.Plasma(HdKit.chestAnchor(p), 0.8, 4, SUN_GOLD, SUN_WHITE, 92, 0.6f, running));
                Vfx.add(new Hd.Haze(HdKit.feetAnchor(p), 1.1, 2.4, 6, 0xFFF4E0, 90, 0.9f));
            }
        });
        ShazamFx.schedule(14, 90, (lvl, t) -> {
            if (running.get() <= 0f || t % 4 != 0) {
                return;
            }
            HdKit.streaksIn(HdKit.chest(p), 1.5 + t * 0.02, 2.4, SUN_GOLD, 0.05f, 10);
        });
        ShazamFx.schedule(104, 1, (lvl, t) -> {
            if (running.get() <= 0f) {
                return;
            }
            Vec3 c = HdKit.chest(p), f = HdKit.feet(p);
            nova(c, 5.0, 32, 1f, false);
            Vfx.add(new Hd.Corona(HdKit.chestAnchor(p), 0.5, 6.0, 34, SUN_GOLD, SUN_WHITE, 40, HdKit.firstPerson(p) ? 0.35f : 1f, null));
            Vfx.add(new Hd.Pressure(c, UP, 14.0, Math.PI, SUN_WHITE, 22, 0.8f, true));
            HdKit.streaks(c, 60, 1.2, SUN_GOLD, 0.1f, 12);
            HdKit.fireWave(lvl, f, 8.0, 12, SUN_ORANGE, 0.28f, null, 0);
        });
    }

    // ------------------------------------------------------------------ tiap tick

    public static void tick(ClientLevel level) {
        try {
            tick0(level);
        } catch (Throwable ignored) {
        }
    }

    private static void tick0(ClientLevel level) {
        long now = level.getGameTime();
        RAGE.keySet().removeIf(id -> !(level.getEntity(id) instanceof AbstractClientPlayer));
        for (AbstractClientPlayer p : level.players()) {
            int id = p.getId();
            if (!ShazamClientState.isTransformed(id) || !ShazamClientState.isLintang(id) || p.isInvisible()) {
                RAGE.remove(id);
                continue;
            }
            boolean fp = HdKit.firstPerson(p);
            RandomSource r = level.random;
            // Mode Surya: korona & lengkung plasma mengelilingi badan selama aktif
            if (ShazamClientState.isRaging(id) && !fp) {
                Long until = RAGE.get(id);
                if (until == null || now >= until) {
                    Supplier<Float> on = () -> ShazamClientState.isRaging(id) && !HdKit.firstPerson(p) && alive(p) ? 1f : 0f;
                    Vfx.add(new Hd.Corona(HdKit.chestAnchor(p), 0.32, 1.9, 20, SUN_GOLD, SUN_WHITE, 200, 0.75f, on));
                    Vfx.add(new Hd.Plasma(HdKit.chestAnchor(p), 0.72, 5, SUN_GOLD, SUN_WHITE, 200, 0.8f, on));
                    RAGE.put(id, now + 190);
                }
                if (p.tickCount % 3 == 0) {
                    HdKit.flames(HdKit.feet(p), 1, 0.5, 0.05, SUN_ORANGE, 0.12f, 10);
                }
            } else {
                RAGE.remove(id);
            }
            if (fp) {
                continue;
            }
            // terbang kencang: garis cahaya di belakang lintasan
            if (ShazamClientState.isFlying(id) && !p.onGround()) {
                Vec3 m = new Vec3(p.getX() - p.xo, p.getY() - p.yo, p.getZ() - p.zo);
                double speed = m.length();
                if (speed > 0.55) {
                    Vec3 back = HdKit.chest(p).subtract(m.scale(0.8)).add(ShazamFx.randomDir(r).scale(0.35));
                    Vec3 v = m.scale(-0.12);
                    Vfx.streak(back.x, back.y, back.z, v.x, v.y, v.z, r.nextInt(3) == 0 ? WHITE : SUN_GOLD, 0.06f, 7);
                }
            }
            // Muatan Cahaya penuh: plasma kecil menyala di kedua kepalan
            if (ShazamClientState.isCharged(id) && p.tickCount % 2 == 0) {
                for (boolean right : new boolean[] {true, false}) {
                    Vec3 h = ShazamPoses.handPos(p, right, 1f);
                    Vfx.flame(h.x, h.y - 0.05, h.z, (r.nextDouble() - 0.5) * 0.01, 0.015, (r.nextDouble() - 0.5) * 0.01, SUN_GOLD,
                            0.055f, 7);
                }
            }
            // di bawah matahari: riak panas samar dari badan
            if (p.tickCount % 50 == 0 && PassiveConditions.underSun(level, p.blockPosition())) {
                Vfx.add(new Hd.Haze(HdKit.feetAnchor(p), 0.6, 2.2, 4, 0xFFF4E0, 50, 0.6f));
            }
        }
    }
}
