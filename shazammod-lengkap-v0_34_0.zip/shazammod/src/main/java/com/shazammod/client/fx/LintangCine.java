package com.shazammod.client.fx;

import com.shazammod.LintangItems;
import com.shazammod.LintangSkills;
import com.shazammod.PassiveConditions;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamSounds;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Vfx;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.Vec3;

/**
 * Lapisan sinematik Lintang (berbasis sains): eksperimen evolusi, Mode Surya, efek skill yang lebih tebal,
 * dan sistem "melemah" (Nether tanpa matahari / radiasi Cryon) yang dibaca oleh pose & layer kulit.
 * Semua titik masuk tetap memanggil LintangFx asli dulu, lalu menambah lapisan baru.
 */
public final class LintangCine {
    static final int SUN_CORE = 0xFFF6D8;
    static final int SUN = 0xFFD54A;
    static final int SUN_DEEP = 0xFF9A1F;
    static final int WHITE = 0xFFFFFF;
    static final int CRYON = 0x3CFF86;
    static final int CRYON_DEEP = 0x14A352;
    static final int CRYON_DARK = 0x0B3D24;
    static final int FROST = 0xD6F4FF;
    static final int ICE = 0x8FDCFF;
    static final int HEAT = 0xFF6A2A;
    static final int DNA = 0x7FE8FF;
    static final int DUST = 0xD9C18A;

    public static final int COLLAPSE_LEN = 72;
    public static final int EXPERIMENT_LEN = 136;
    public static final int CHARGE_LEN = 92;
    public static final int IGNITE_LEN = 40;
    private static final long NEVER = Long.MIN_VALUE / 4;

    static final class V {
        float weak;
        float weakO;
        float solar;
        float solarO;
        boolean cryon;
        long collapse = NEVER;
        long lastCollapse = NEVER;
        long experiment = NEVER;
        long charge = NEVER;
        long recover = NEVER;
        int nextBeat;
        int nextBreath;
    }

    private static final Map<Integer, V> VITALS = new HashMap<>();

    private LintangCine() {
    }

    // ------------------------------------------------------------------ titik masuk (redirect)

    public static void onAnim(AbstractClientPlayer p, ShazamAnim a, Vec3 pos) {
        float boostOld = Vfx.setBoost(LintangFx.BOOST);   // 0.33: lapisan tambahan ikut tebal (bloom)
        try {
            onAnim0(p, a, pos);
        } finally {
            Vfx.setBoost(boostOld);
        }
    }

    private static void onAnim0(AbstractClientPlayer p, ShazamAnim a, Vec3 pos) {
        if (a == ShazamAnim.LINTANG_RITE) {
            try {
                startExperiment(p);
            } catch (Throwable ignored) {
            }
            LintangHd.onAnim(p, a, pos);   // 0.34: lapisan HD
            return;
        }
        try {
            if (a == ShazamAnim.LINTANG_FADE && experimentAge(p, 0.0f) >= 0.0f && !ShazamClientState.isTransformed(p.getId())) {
                abortExperiment(p);
                return;
            }
        } catch (Throwable ignored) {
        }
        LintangFx.onAnim(p, a, pos);
        try {
            if (LintangFx.handles(p, a)) extra(p, a, pos);
        } catch (Throwable ignored) {
        }
        try {
            if (LintangFx.handles(p, a)) LintangHd.onAnim(p, a, pos);   // 0.34: lapisan HD di atas semuanya
        } catch (Throwable ignored) {
        }
    }

    public static void tick(ClientLevel level) {
        float boostOld = Vfx.setBoost(LintangFx.BOOST);   // 0.33: lapisan tambahan ikut tebal (bloom)
        try {
            tick0(level);
        } finally {
            Vfx.setBoost(boostOld);
        }
    }

    private static void tick0(ClientLevel level) {
        LintangFx.tick(level);
        try {
            tickVitals(level);
        } catch (Throwable ignored) {
        }
        LintangHd.tick(level);   // 0.34: korona Mode Surya, jejak terbang, kepalan bermuatan
    }

    public static void clear() {
        LintangFx.clear();
        VITALS.clear();
        LintangHd.clear();
    }

    public static float eyeGlow(AbstractClientPlayer p, float pt) {
        float g = LintangFx.eyeGlow(p, pt);
        try {
            return g * (1.0f - 0.85f * weakness(p, pt));
        } catch (Throwable t) {
            return g;
        }
    }

    public static void sunStrike(ClientLevel level, Vec3 pos, Ground.Map map, float scale) {
        float boostOld = Vfx.setBoost(LintangFx.BOOST);   // 0.33: lapisan tambahan ikut tebal (bloom)
        try {
            sunStrike0(level, pos, map, scale);
        } finally {
            Vfx.setBoost(boostOld);
        }
    }

    private static void sunStrike0(ClientLevel level, Vec3 pos, Ground.Map map, float scale) {
        LintangFx.sunStrike(level, pos, map, scale);
        try {
            Vec3 c = map != null ? map.center(pos) : pos;
            Vfx.add(new Fx.Flash(c.add(0.0, 0.4, 0.0), 2.4f * scale, SUN_CORE, 10, 0.9f));
            Vfx.add(new Fx.Scorch(c, 1.4 * scale, 170, 50, map));
            for (int i = 0; i < 3; i++) CineKit.heatRings(c.add(0.0, 0.3 + i * 0.5, 0.0), SUN, 1.2 + i * 0.5, 12 + i * 4);
            CineKit.sparks(c.add(0.0, 0.3, 0.0), 26, SUN, 0.32, 0.05f, 10, c.y);
        } catch (Throwable ignored) {
        }
    }

    // ------------------------------------------------------------------ kueri untuk pose & layer kulit

    public static float weakness(AbstractClientPlayer p, float pt) {
        V v = VITALS.get(p.getId());
        return v == null ? 0.0f : Mth.lerp(pt, v.weakO, v.weak);
    }

    public static float solar(AbstractClientPlayer p, float pt) {
        V v = VITALS.get(p.getId());
        return v == null ? 0.0f : Mth.lerp(pt, v.solarO, v.solar);
    }

    public static boolean cryon(AbstractClientPlayer p) {
        V v = VITALS.get(p.getId());
        return v != null && v.cryon;
    }

    private static float age(AbstractClientPlayer p, long start, float pt, int len) {
        if (start == NEVER) return -1.0f;
        float t = (float) (p.level().getGameTime() - start) + pt;
        return t >= 0.0f && t <= len ? t : -1.0f;
    }

    public static float collapseAge(AbstractClientPlayer p, float pt) {
        V v = VITALS.get(p.getId());
        return v == null ? -1.0f : age(p, v.collapse, pt, COLLAPSE_LEN);
    }

    public static float experimentAge(AbstractClientPlayer p, float pt) {
        V v = VITALS.get(p.getId());
        return v == null ? -1.0f : age(p, v.experiment, pt, EXPERIMENT_LEN);
    }

    /** Sebaran urat per bagian tubuh (kepala, badan, lengan kanan, lengan kiri, kaki kanan, kaki kiri): 0..1. */
    public static float[] spread(AbstractClientPlayer p, float pt) {
        float[] s = {1f, 1f, 1f, 1f, 1f, 1f};
        float e = experimentAge(p, pt);
        if (e >= 0.0f) {
            float k = Mth.clamp((e - 4.0f) / 70.0f, 0.0f, 1.0f);
            s[2] = Mth.clamp(k / 0.18f, 0.0f, 1.0f);
            s[1] = Mth.clamp((k - 0.12f) / 0.25f, 0.0f, 1.0f);
            s[3] = Mth.clamp((k - 0.3f) / 0.22f, 0.0f, 1.0f);
            s[0] = Mth.clamp((k - 0.45f) / 0.25f, 0.0f, 1.0f);
            s[4] = Mth.clamp((k - 0.55f) / 0.25f, 0.0f, 1.0f);
            s[5] = Mth.clamp((k - 0.6f) / 0.25f, 0.0f, 1.0f);
            return s;
        }
        float c = collapseAge(p, pt);
        if (c >= 0.0f) {
            float k = Mth.clamp(c / 26.0f, 0.0f, 1.0f);
            s[1] = Mth.clamp(k / 0.3f, 0.0f, 1.0f);
            s[0] = Mth.clamp((k - 0.2f) / 0.4f, 0.0f, 1.0f);
            s[2] = s[3] = Mth.clamp((k - 0.25f) / 0.45f, 0.0f, 1.0f);
            s[4] = s[5] = Mth.clamp((k - 0.45f) / 0.5f, 0.0f, 1.0f);
        }
        return s;
    }

    private static V vital(AbstractClientPlayer p) {
        V v = VITALS.get(p.getId());
        if (v == null) {
            v = new V();
            VITALS.put(p.getId(), v);
        }
        return v;
    }

    // ------------------------------------------------------------------ sistem melemah

    private static void tickVitals(ClientLevel level) {
        long now = level.getGameTime();
        Minecraft mc = Minecraft.getInstance();
        boolean nether = PassiveConditions.inferno(level);
        RandomSource r = level.random;
        Set<Integer> seen = new HashSet<>();
        List<AbstractClientPlayer> players = level.players();
        for (AbstractClientPlayer p : players) {
            try {
                int id = p.getId();
                seen.add(id);
                boolean lin = ShazamClientState.isTransformed(id) && ShazamClientState.isLintang(id);
                V v = VITALS.get(id);
                if (v == null) {
                    if (!lin) continue;
                    v = vital(p);
                }
                boolean local = p == mc.player;
                float target = 0.0f;
                if (lin) {
                    if (local) v.cryon = ShazamClientState.kelam;
                    else if ((p.tickCount + id) % 10 == 0) v.cryon = LintangSkills.kelamAround(level, p, false);
                    if (nether) target = 0.62f;
                    if (v.cryon) target = 1.0f;
                } else {
                    v.cryon = false;
                }
                v.weakO = v.weak;
                v.weak += (target - v.weak) * (target > v.weak ? 0.075f : 0.035f);
                if (Math.abs(target - v.weak) < 0.003f) v.weak = target;

                float sol = 0.0f;
                float e = (float) (now - v.experiment);
                if (v.experiment != NEVER && e >= 0.0f && e <= EXPERIMENT_LEN) sol = experimentSolar(e);
                float ch = (float) (now - v.charge);
                if (v.charge != NEVER && ch >= 0.0f && ch <= CHARGE_LEN + IGNITE_LEN) {
                    sol = Math.max(sol, ch < CHARGE_LEN ? 0.2f + 0.8f * (ch / CHARGE_LEN) : 1.0f - 0.75f * ((ch - CHARGE_LEN) / IGNITE_LEN));
                }
                if (lin && !nether && v.weak < 0.3f && PassiveConditions.underSun(level, p.blockPosition())) {
                    sol = Math.max(sol, 0.14f + 0.06f * Mth.sin(now * 0.15f + id));
                }
                sol *= 1.0f - v.weak;
                v.solarO = v.solar;
                v.solar += (sol - v.solar) * 0.25f;

                if (lin && v.weakO < 0.42f && v.weak >= 0.42f) {
                    if (now - v.lastCollapse > 300L) {
                        v.collapse = now;
                        v.lastCollapse = now;
                        collapseFx(level, p, local, v);
                    } else {
                        flinchFx(level, p, local, v);
                    }
                }
                if (lin && v.weakO >= 0.25f && v.weak < 0.25f && target <= 0.0f) {
                    v.recover = now;
                    recoverFx(level, p, local);
                }
                if (lin && v.weak > 0.04f) weakAmbient(level, p, local, v, r);
            } catch (Throwable ignored) {
            }
        }
        VITALS.keySet().removeIf(k -> !seen.contains(k));
        if (mc.player != null && ShazamClientState.isLintang(mc.player.getId())) cryonAmbience(level, mc.player, r);
    }

    private static float experimentSolar(float e) {
        if (e < 14.0f) return 0.15f + 0.35f * (e / 14.0f);
        if (e < 74.0f) return 0.5f + 0.5f * ((e - 14.0f) / 60.0f);
        if (e < 104.0f) return 0.55f + 0.45f * Math.abs(Mth.sin(e * 0.9f));
        if (e < 112.0f) return 1.0f;
        return Math.max(0.2f, 1.0f - (e - 112.0f) / 24.0f);
    }

    private static void collapseFx(ClientLevel level, AbstractClientPlayer p, boolean local, V v) {
        final boolean cry = v.cryon;
        Vec3 c = CineKit.chest(p);
        CineKit.sound(level, c, ShazamSounds.POWER_DOWN, 1.3f, 0.65f);
        CineKit.sound(level, c, ShazamSounds.HEARTBEAT, 1.1f, 0.85f);
        if (cry) CineKit.sound(level, c, ShazamSounds.KELAM_HUM, 1.0f, 0.75f);
        Lightning.Anchor ca = CineKit.chestAnchor(p);
        Vfx.add(new Fx.Glow(p, ca, 1.9f, cry ? CRYON : SUN, 20, 2));
        Vfx.add(new Lightning.Crackle(p, cry ? CRYON : SUN_DEEP, 1.3f, 0.035f, 30).reach(1.15));
        Vfx.add(new Fx.Ripple(c, CineKit.UP, 1.4, 0.5, 1.4, 0.1, cry ? CRYON : SUN, 12, 0.6f, true));
        ShazamFx.schedule(0, 30, (lvl, t) -> {
            Vec3 cc = CineKit.chest(p);
            int n = Vfx.count(3);
            for (int i = 0; i < n; i++) {
                Vec3 d = ShazamFx.randomDir(lvl.random);
                Vfx.mote(cc.x + d.x * 0.28, cc.y + d.y * 0.45, cc.z + d.z * 0.28, d.x * 0.04, 0.035 + Math.abs(d.y) * 0.05, d.z * 0.04,
                        Draw.mix(SUN, 0x6A6A70, t / 30.0), 0.06f, 24);
            }
            if (cry && t % 2 == 0) {
                Vec3 d = ShazamFx.randomDir(lvl.random);
                Vfx.smoke(cc.x + d.x * 0.3, cc.y + d.y * 0.5, cc.z + d.z * 0.3, d.x * 0.01, 0.02, d.z * 0.01, CRYON_DEEP, 0.22f, 26);
                Vfx.glint(cc.x + d.x * 0.32, cc.y + d.y * 0.6, cc.z + d.z * 0.32, CRYON, 0.08f, 7);
            }
        });
        ShazamFx.schedule(18, 1, (lvl, t) -> {
            Vec3 f = CineKit.feet(p);
            ShazamFx.dustPuffs(lvl, f, cry ? 0x5E7A62 : 0x8A7A68, Vfx.count(16), 0.9, 0.12);
            CineKit.shock(lvl, f, CineKit.UP, 2.2, cry ? CRYON_DEEP : 0xB8A890, 0xFFFFFF, 12, 0.45f, true);
            CineKit.sound(lvl, f, ShazamSounds.BODY_HIT, 0.9f, 0.6f);
            if (CineKit.isLocal(p)) CameraShake.add(0.6f);
        });
        if (local) {
            ScreenFx.vignette(0.8f, cry ? CRYON_DARK : 0x2A1A10, 80);
            ScreenFlash.flash(0.28f, cry ? 0x1F6B3A : 0x3A2410);
            CameraShake.add(0.35f);
        }
    }

    private static void flinchFx(ClientLevel level, AbstractClientPlayer p, boolean local, V v) {
        Vec3 c = CineKit.chest(p);
        Vfx.add(new Lightning.Crackle(p, v.cryon ? CRYON : SUN_DEEP, 0.8f, 0.03f, 12).reach(1.0));
        CineKit.sound(level, c, ShazamSounds.HEARTBEAT, 0.7f, 0.95f);
        if (local) {
            ScreenFx.vignette(0.5f, v.cryon ? CRYON_DARK : 0x2A1A10, 24);
            CameraShake.add(0.2f);
        }
    }

    private static void recoverFx(ClientLevel level, AbstractClientPlayer p, boolean local) {
        Vec3 c = CineKit.chest(p);
        CineKit.sound(level, c, ShazamSounds.POWER_UP, 1.0f, 1.2f);
        Vfx.add(new Fx.Glow(p, CineKit.chestAnchor(p), 1.6f, SUN, 18, 4));
        CineKit.shock(level, CineKit.feet(p), CineKit.UP, 3.0, SUN, SUN_CORE, 14, 0.6f, true);
        CineKit.motesOut(c, 18, SUN, 0.08, 0.06f, 16);
        if (local) ScreenFlash.flash(0.25f, 0xFFE9B0);
    }

    private static void weakAmbient(ClientLevel level, AbstractClientPlayer p, boolean local, V v, RandomSource r) {
        float w = v.weak;
        Vec3 c = CineKit.chest(p);
        if (v.cryon && r.nextFloat() < 0.55f * w) {
            Vec3 d = ShazamFx.randomDir(r);
            Vfx.glint(c.x + d.x * 0.33, c.y + d.y * 0.62, c.z + d.z * 0.33, CRYON, 0.05f + r.nextFloat() * 0.05f, 8);
        }
        if (r.nextFloat() < 0.22f * w) {
            Vec3 d = ShazamFx.randomDir(r);
            Vfx.mote(c.x + d.x * 0.3, c.y + d.y * 0.5, c.z + d.z * 0.3, d.x * 0.01, 0.025, d.z * 0.01, Draw.mix(SUN, 0x7A7A80, 0.6), 0.04f, 20);
        }
        if (--v.nextBreath <= 0) {
            v.nextBreath = (int) (48.0f - 18.0f * w);
            Vec3 m = CineKit.mouth(p);
            Vec3 l = CineKit.look(p);
            for (int i = 0; i < 3; i++) {
                Vfx.smoke(m.x, m.y, m.z, l.x * 0.035 + (r.nextDouble() - 0.5) * 0.01, -0.004 + r.nextDouble() * 0.006, l.z * 0.035 + (r.nextDouble() - 0.5) * 0.01,
                        v.cryon ? 0xBFD8C8 : 0xD8D2CC, 0.1f + i * 0.03f, 16 + i * 4);
            }
        }
        if (local && --v.nextBeat <= 0) {
            v.nextBeat = (int) (36.0f - 14.0f * w);
            ScreenFx.vignette(0.2f + 0.35f * w, v.cryon ? CRYON_DARK : 0x301810, 16);
            if (w > 0.55f) CineKit.sound(level, c, ShazamSounds.HEARTBEAT, 0.3f + 0.35f * w, 0.9f);
            CameraShake.add(0.05f * w);
        }
    }

    private static void cryonAmbience(ClientLevel level, AbstractClientPlayer me, RandomSource r) {
        Block ore = (Block) LintangItems.KELAM_ORE.get();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        int bx = (int) Math.floor(me.getX()), by = (int) Math.floor(me.getY()), bz = (int) Math.floor(me.getZ());
        int n = Vfx.count(140);
        for (int i = 0; i < n; i++) {
            int x = bx + r.nextInt(25) - 12, y = by + r.nextInt(17) - 8, z = bz + r.nextInt(25) - 12;
            m.set(x, y, z);
            if (!level.getBlockState(m).is(ore)) continue;
            double px = x + r.nextDouble(), py = y + r.nextDouble(), pz = z + r.nextDouble();
            Vfx.glint(px, py, pz, CRYON, 0.05f + r.nextFloat() * 0.06f, 10 + r.nextInt(8));
            if (r.nextFloat() < 0.35f) Vfx.mote(px, py, pz, 0.0, 0.012 + r.nextDouble() * 0.01, 0.0, CRYON_DEEP, 0.05f, 30);
        }
    }

    // ------------------------------------------------------------------ eksperimen evolusi (pengganti ritual)

    private static Vec3 lightDir(ClientLevel level) {
        double d = (level.getDayTime() % 24000L) / 24000.0 - 0.25;
        d -= Math.floor(d);
        double e = 0.5 - Math.cos(d * Math.PI) / 2.0;
        double tod = (d * 2.0 + e) / 3.0;
        double a = tod * Math.PI * 2.0;
        Vec3 s = new Vec3(-Math.sin(a), Math.cos(a), 0.0);
        if (s.y < 0.0) s = new Vec3(-s.x, -s.y, 0.0); // malam: pantulan cahaya bulan
        if (s.y < 0.25) s = new Vec3(s.x, 0.25, 0.15);
        return CineKit.norm(s);
    }

    private static boolean running(AbstractClientPlayer p, V v, long start) {
        return v.experiment == start && p.isAlive();
    }

    private static void startExperiment(AbstractClientPlayer p) {
        ClientLevel level = CineKit.level(p);
        final V v = vital(p);
        final long start = level.getGameTime();
        final boolean local = CineKit.isLocal(p);
        v.experiment = start;
        if (local) {
            ScreenFx.cinema(EXPERIMENT_LEN + 6);
            ScreenFx.vignette(0.35f, 0x0A2A3A, 40);
        }
        CineKit.sound(level, CineKit.chest(p), ShazamSounds.SHIMMER, 0.9f, 1.4f);
        // 0-14: injeksi serum di lengan
        ShazamFx.schedule(0, 16, (lvl, t) -> {
            if (!running(p, v, start)) return;
            Vec3 c = CineKit.chest(p);
            Vec3 side = CineKit.flat(new Vec3(-CineKit.look(p).z, 0.0, CineKit.look(p).x));
            Vec3 arm = c.add(side.x * 0.38, -0.12, side.z * 0.38).add(CineKit.flat(CineKit.look(p)).scale(0.25));
            Vfx.glint(arm.x, arm.y, arm.z, t < 6 ? 0xC8F4FF : SUN, 0.07f, 5);
            if (t > 4) Vfx.mote(arm.x, arm.y, arm.z, (c.x - arm.x) * 0.06, (c.y - arm.y) * 0.06 + 0.01, (c.z - arm.z) * 0.06, SUN, 0.05f, 12);
            if (t == 6) CineKit.sound(lvl, arm, ShazamSounds.ENERGY_PULSE, 0.6f, 1.6f);
        });
        // 14-74: absorpsi foton + heliks DNA + riak panas
        ShazamFx.schedule(14, 1, (lvl, t) -> {
            if (!running(p, v, start)) return;
            Vfx.add(new CineKit.PhotonStreams(p, lightDir(lvl), 26, 64, SUN, SUN_CORE));
            Vfx.add(new CineKit.Helix(p, 94, SUN, DNA));
            Vfx.add(new Fx.Glow(p, CineKit.chestAnchor(p), 1.3f, SUN, 70, 30));
            CineKit.sound(lvl, CineKit.chest(p), ShazamSounds.CHARGE, 1.0f, 1.0f);
        });
        ShazamFx.schedule(14, 60, (lvl, t) -> {
            if (!running(p, v, start)) return;
            if (t % 9 == 0) CineKit.heatRings(CineKit.feet(p).add(0.0, 0.2, 0.0), SUN, 1.2 + t * 0.012, 16);
            ShazamFx.swirlDust(lvl, p, t);
            if (t % 20 == 10) CineKit.sound(lvl, CineKit.chest(p), ShazamSounds.ENERGY_PULSE, 0.7f, 0.8f + t * 0.01f);
        });
        // 74-104: mutasi sel (kejang, berlutut, urat berkedip)
        ShazamFx.schedule(74, 30, (lvl, t) -> {
            if (!running(p, v, start)) return;
            Vec3 c = CineKit.chest(p);
            if (t % 6 == 0) Vfx.add(new Lightning.Crackle(p, t % 12 == 0 ? SUN : DNA, 1.1f, 0.035f, 8).reach(1.05));
            if (t % 3 == 0) CineKit.motesOut(c, 4, SUN_DEEP, 0.05, 0.05f, 12);
            if (t % 8 == 0) {
                CineKit.sound(lvl, c, ShazamSounds.HEARTBEAT, 0.9f, 1.0f + t * 0.02f);
                if (CineKit.isLocal(p)) {
                    CameraShake.add(0.25f + t * 0.01f);
                    ScreenFx.vignette(0.45f, 0x4A1A08, 10);
                }
            }
            if (t == 6) {
                ShazamFx.dustPuffs(lvl, CineKit.feet(p), DUST, Vfx.count(14), 0.8, 0.1);
                CineKit.sound(lvl, c, ShazamSounds.BODY_HIT, 0.8f, 0.7f);
            }
        });
        // 104: EVOLUSI - ledakan cahaya dari DALAM tubuh (bukan petir dari langit)
        ShazamFx.schedule(104, 1, (lvl, t) -> {
            if (!running(p, v, start)) return;
            evolutionBurst(lvl, p);
        });
        // 106-136: uap panas keluar dari tubuh, cahaya mengendap
        ShazamFx.schedule(106, 30, (lvl, t) -> {
            if (!running(p, v, start)) return;
            Vec3 c = CineKit.chest(p);
            RandomSource r = lvl.random;
            if (t % 2 == 0) {
                double sx = (r.nextDouble() - 0.5) * 0.6, sz = (r.nextDouble() - 0.5) * 0.6;
                Vfx.smoke(c.x + sx, c.y + 0.25, c.z + sz, sx * 0.02, 0.03 + r.nextDouble() * 0.02, sz * 0.02, 0xE8E2D8, 0.18f, 24);
            }
            if (t % 3 == 0) Vfx.glint(c.x + (r.nextDouble() - 0.5) * 0.7, c.y + (r.nextDouble() - 0.4) * 1.2, c.z + (r.nextDouble() - 0.5) * 0.7, SUN, 0.06f, 8);
        });
    }

    private static void evolutionBurst(ClientLevel level, AbstractClientPlayer p) {
        Vec3 c = CineKit.chest(p);
        Vec3 f = CineKit.feet(p);
        boolean local = CineKit.isLocal(p);
        CineKit.burst(c, 3.2f, SUN, SUN_CORE, 18, 1.0f);
        Vfx.add(new Fx.Bubble(c, 7.0, SUN, 20, 0.6f, 1.0, 2.4, true));
        CineKit.shock(level, f, CineKit.UP, 10.0, SUN, WHITE, 24, 0.9f, true);
        Vfx.add(new Fx.Ripple(c, CineKit.UP, 3.0, 0.6, 3.5, 0.25, SUN_CORE, 14, 0.75f, false));
        Vfx.add(new Fx.Pillar(f, 48.0, 1.5f, SUN, 18));
        Vfx.add(new Fx.Pillar(f, 22.0, 0.6f, SUN_CORE, 12));
        CineFx.godRays(CineKit.chestAnchor(p), SUN, 42.0, 3.4, 10, 0.9f, 36);
        CineKit.crater(level, f, 3.4, SUN_DEEP, DUST, 40);
        CineKit.sparks(c, 60, SUN, 0.42, 0.055f, 12, f.y);
        CineKit.motesOut(c, 40, SUN_CORE, 0.14, 0.07f, 22);
        ShazamFx.ringOfSparks(level, c, Vfx.count(22), SUN, 0.45);
        Vfx.add(new Lightning.Crackle(p, SUN, 1.8f, 0.045f, 26).reach(1.1));
        CineKit.sound(level, c, ShazamSounds.SHOCKWAVE, 1.6f, 0.9f);
        CineKit.sound(level, c, ShazamSounds.RESONANCE, 1.2f, 1.1f);
        if (local) {
            ScreenFlash.flash(0.95f, 0xFFF4D0);
            CameraShake.add(1.0f);
            FovKick.punch(0.6f);
        } else {
            ShazamFx.shakeAround(c, 0.6f, 26.0);
        }
    }

    private static void abortExperiment(AbstractClientPlayer p) {
        V v = vital(p);
        v.experiment = NEVER;
        ClientLevel level = CineKit.level(p);
        Vec3 c = CineKit.chest(p);
        ShazamFx.smokeCloud(level, c, 0x6A6A70, 5, 0.6);
        CineKit.sound(level, c, ShazamSounds.POWER_DOWN, 0.9f, 0.9f);
    }

    // ------------------------------------------------------------------ lapisan tambahan per skill

    /**
     * 0.33: lapisan tambahan harus meledak tepat saat gerakan utamanya (sesudah ancang-ancang), bukan saat animasi mulai.
     * Ancang-ancang diambil dari konstanta ShazamAnim yang sama dengan efek aslinya.
     */
    private static void extra(AbstractClientPlayer p, ShazamAnim a, Vec3 pos) {
        int delay = switch (a) {
            case TRANSFORM -> ShazamAnim.TRANSFORM_STRIKE;
            case REVERT -> ShazamAnim.REVERT_WINDUP;
            case LINTANG_DASH -> ShazamAnim.LESAT_WINDUP;
            case LINTANG_EYES -> ShazamAnim.IRIS_WINDUP;
            case LINTANG_BREATH -> ShazamAnim.FROST_WINDUP;
            case LINTANG_CLAP -> ShazamAnim.SONIC_WINDUP;
            case LINTANG_BARRAGE -> ShazamAnim.BARRAGE_WINDUP;
            case LINTANG_LEAP -> ShazamAnim.LEAP_WINDUP;
            case LINTANG_FLARE -> ShazamAnim.FLARE_WINDUP;
            case LINTANG_RESCUE -> ShazamAnim.RESCUE_WINDUP;
            default -> 0;
        };
        if (delay <= 0) {
            extraNow(p, a, pos);
        } else {
            ShazamFx.schedule(delay, 1, (lvl, t) -> {
                if (p.isAlive()) extraNow(p, a, pos);
            });
        }
    }

    private static void extraNow(AbstractClientPlayer p, ShazamAnim a, Vec3 pos) {
        ClientLevel level = CineKit.level(p);
        boolean local = CineKit.isLocal(p);
        V v = vital(p);
        long now = level.getGameTime();
        Vec3 c = CineKit.chest(p);
        Vec3 f = CineKit.feet(p);
        Vec3 l = CineKit.look(p);
        Vec3 at = pos != null ? pos : c;
        switch (a) {
            case SUMMON -> charge(level, p, v, now, local);
            case TRANSFORM -> ignite(level, p, local);
            case REVERT, KNOCKOUT -> {
                v.charge = NEVER;
                CineKit.motesOut(c, 26, SUN, 0.06, 0.06f, 22);
                Vfx.add(new Fx.Glow(p, CineKit.chestAnchor(p), 1.4f, SUN_DEEP, 16, 2));
                ShazamFx.smokeCloud(level, c, 0xC8C0B4, 4, 0.5);
            }
            case LAUNCH -> {
                CineKit.shock(level, f, CineKit.UP, 4.0, DUST, WHITE, 14, 0.6f, true);
                ShazamFx.dustPuffs(level, f, DUST, Vfx.count(20), 1.4, 0.2);
                Vfx.add(new Fx.Cone(f, CineKit.UP.scale(-1.0), 2.6, 0.9, 0xF2F8FF, 10, 0.45f, 2.0, true));
            }
            case LAND_HERO, CRASH -> {
                boolean big = a == ShazamAnim.CRASH;
                CineKit.crater(level, f, big ? 4.0 : 2.4, SUN_DEEP, DUST, big ? 40 : 20);
                CineKit.shock(level, f, CineKit.UP, big ? 8.0 : 5.0, DUST, WHITE, 18, 0.75f, true);
                CineKit.camera(p, f, big ? 0.8f : 0.45f, 20.0);
            }
            case SONIC_BOOM -> {
                // Kerucut uap Prandtl-Glauert: tanda tembus kecepatan suara (sains, bukan sihir)
                Vfx.add(new Fx.Cone(c.add(l.scale(0.6)), l.scale(-1.0), 3.4, 1.15, 0xF4FAFF, 12, 0.6f, 1.8, true));
                Vfx.add(new Fx.Ripple(c, l, 3.0, 0.8, 4.2, 0.35, WHITE, 12, 0.65f, true));
                Vfx.add(new Fx.Wave(c, l, 3.6, 0.22, 0xE6F2FF, 10, 0.7f, 0.06f, null));
                CineKit.camera(p, c, 0.35f, 24.0);
            }
            case LINTANG_DASH -> {
                Vfx.add(new Fx.Cone(c.add(l.scale(0.5)), l.scale(-1.0), 3.0, 0.95, 0xF4FAFF, 10, 0.55f, 2.0, true));
                Vfx.add(new Fx.Ripple(c, l, 1.6, 0.35, 2.6, 0.2, WHITE, 9, 0.75f, true));
                ShazamFx.dustPuffs(level, f, DUST, Vfx.count(12), 0.8, 0.22);
                if (pos != null) CineKit.shock(level, pos, CineKit.UP, 3.2, SUN, WHITE, 12, 0.55f, true);
                if (local) ScreenFx.speedLines(0.9f);
            }
            case LINTANG_EYES -> {
                Vec3 e = CineKit.eyes(p);
                Vfx.add(new Fx.Glow(p, Lightning.Anchor.on(p, 0.0, p.getEyeY() - p.getY(), 0.0), 0.7f, HEAT, 30, 3));
                Vfx.add(new Fx.Ripple(e, l, 7.0, 0.12, 0.8, 0.08, HEAT, 16, 0.5f, true));
                ShazamFx.schedule(0, ShazamAnim.IRIS_TICKS, (lvl, t) -> {
                    Vec3 ee = CineKit.eyes(p);
                    Vec3 ll = CineKit.look(p);
                    if (t % 2 == 0) Vfx.spark(ee.x + ll.x * 0.4, ee.y + ll.y * 0.4, ee.z + ll.z * 0.4, ll.x * 0.25, ll.y * 0.25, ll.z * 0.25, HEAT, 0.04f, 6, Double.NaN);
                    if (t % 7 == 0) CineKit.heatRings(ee.add(ll.scale(1.2)), HEAT, 0.5, 8);
                });
                if (local) ScreenFx.vignette(0.3f, 0x5A1A08, 30);
            }
            case LINTANG_BREATH -> {
                Vec3 m = CineKit.mouth(p);
                Vfx.add(new Fx.Cone(m, l, 7.5, 0.72, FROST, 16, 0.45f, 2.0, true));
                ShazamFx.schedule(0, ShazamAnim.FROST_TICKS, (lvl, t) -> {
                    Vec3 mm = CineKit.mouth(p);
                    Vec3 ll = CineKit.look(p);
                    RandomSource r = lvl.random;
                    int n = Vfx.count(3);
                    for (int i = 0; i < n; i++) {
                        double s = 0.28 + r.nextDouble() * 0.22;
                        Vfx.smoke(mm.x, mm.y, mm.z, ll.x * s + (r.nextDouble() - 0.5) * 0.06, ll.y * s + (r.nextDouble() - 0.5) * 0.05, ll.z * s + (r.nextDouble() - 0.5) * 0.06,
                                i == 0 ? WHITE : FROST, 0.16f + r.nextFloat() * 0.12f, 18 + r.nextInt(8));
                    }
                    if (t % 2 == 0) {
                        double s = 0.35 + r.nextDouble() * 0.3;
                        Vfx.spark(mm.x, mm.y, mm.z, ll.x * s, ll.y * s, ll.z * s, ICE, 0.035f, 10, Double.NaN);
                    }
                });
            }
            case LINTANG_CLAP -> {
                Vec3 h = c.add(l.scale(0.7));
                Vfx.add(new Fx.Ripple(h, l, 11.0, 0.5, 5.5, 0.65, WHITE, 16, 0.55f, true));
                Vfx.add(new Fx.Ripple(h, l, 7.0, 0.3, 3.5, 0.3, 0xD8F0FF, 12, 0.6f, false));
                Vfx.add(new Fx.Wave(h, l, 4.2, 0.25, WHITE, 12, 0.75f, 0.07f, null));
                Vfx.add(new Fx.Flash(h, 1.2f, WHITE, 6, 0.9f));
                CineKit.shock(level, f, CineKit.UP, 6.0, DUST, WHITE, 16, 0.6f, true);
                ShazamFx.dustPuffs(level, f.add(l.scale(2.0)), DUST, Vfx.count(24), 2.4, 0.3);
                CineKit.camera(p, h, 0.6f, 22.0);
                if (local) ScreenFlash.flash(0.18f, WHITE);
            }
            case LINTANG_BARRAGE -> ShazamFx.schedule(0, ShazamAnim.BARRAGE_TICKS, (lvl, t) -> {
                if (t % 2 != 0) return;
                Vec3 cc = CineKit.chest(p);
                Vec3 ll = CineKit.look(p);
                RandomSource r = lvl.random;
                Vec3 hit = cc.add(ll.scale(1.3)).add((r.nextDouble() - 0.5) * 0.7, (r.nextDouble() - 0.5) * 0.6, (r.nextDouble() - 0.5) * 0.7);
                Vfx.add(new Fx.Flash(hit, 0.55f, SUN_CORE, 4, 0.85f));
                Vfx.add(new Fx.Ripple(hit, ll, 0.8, 0.1, 0.6, 0.06, WHITE, 5, 0.6f, true));
                CineKit.sparks(hit, 5, SUN, 0.22, 0.04f, 6, hit.y - 1.3);
            });
            case LINTANG_HIT, LINTANG_PUNCH, LINTANG_PARRY, LINTANG_BOUNCE -> impact(level, p, at, 1.0f);
            case LINTANG_DAWNPUNCH -> {
                impact(level, p, at, 2.2f);
                CineFx.godRays(Lightning.Anchor.fixed(at), SUN, 30.0, 1.4, 6, 0.8f, 20);
                CineKit.camera(p, at, 0.7f, 22.0);
            }
            case LINTANG_LEAP -> {
                CineKit.shock(level, f, CineKit.UP, 3.6, DUST, WHITE, 12, 0.55f, true);
                ShazamFx.dustPuffs(level, f, DUST, Vfx.count(22), 1.2, 0.24);
                Vfx.add(new Fx.Cone(f, CineKit.UP.scale(-1.0), 2.2, 0.8, 0xF2F8FF, 9, 0.4f, 2.0, true));
            }
            case LINTANG_SLAM -> {
                CineKit.crater(level, at, 5.0, SUN_DEEP, DUST, 60);
                CineKit.shock(level, at, CineKit.UP, 11.0, SUN, WHITE, 24, 0.85f, true);
                Vfx.add(new Fx.Bubble(at, 5.0, SUN, 14, 0.55f, 0.5, 2.0, true));
                CineKit.burst(at.add(0.0, 0.4, 0.0), 1.8f, SUN, SUN_CORE, 12, 0.9f);
                ShazamFx.dustPuffs(level, at, DUST, Vfx.count(44), 3.6, 0.42);
                CineKit.camera(p, at, 1.0f, 30.0);
                CineKit.sound(level, at, ShazamSounds.EARTH_CRACK, 1.4f, 0.8f);
            }
            case LINTANG_FLARE -> {
                CineKit.burst(c, 5.5f, SUN, SUN_CORE, 24, 1.0f);
                Vfx.add(new Fx.Bubble(c, 11.0, SUN, 24, 0.7f, 1.0, 2.2, true));
                CineKit.shock(level, f, CineKit.UP, 14.0, SUN, WHITE, 30, 0.95f, true);
                CineFx.godRays(CineKit.chestAnchor(p), SUN, 50.0, 6.0, 12, 1.0f, 40);
                CineKit.sparks(c, 90, SUN, 0.55, 0.06f, 14, f.y);
                CineKit.crater(level, f, 4.0, SUN_DEEP, DUST, 50);
                ShazamFx.schedule(4, 34, (lvl, t) -> {
                    if (t % 6 == 0) CineKit.heatRings(CineKit.chest(p), SUN, 2.0 + t * 0.12, 14);
                    if (t % 2 == 0) CineKit.motesOut(CineKit.chest(p), 3, SUN_CORE, 0.12, 0.06f, 18);
                });
                if (local) {
                    ScreenFlash.flash(1.0f, 0xFFF4D0);
                    FovKick.punch(0.7f);
                }
                CineKit.camera(p, c, 1.2f, 32.0);
            }
            case LINTANG_CALL -> {
                Vfx.add(new CineKit.PhotonStreams(p, lightDir(level), 22, 46, SUN, SUN_CORE));
                Vfx.add(new Fx.Glow(p, CineKit.chestAnchor(p), 1.6f, SUN, 46, 30));
                ShazamFx.schedule(0, 40, (lvl, t) -> {
                    if (t % 8 == 0) CineKit.heatRings(CineKit.feet(p).add(0.0, 0.1, 0.0), SUN, 1.6, 14);
                });
            }
            case LINTANG_RESCUE, LINTANG_SAVE -> {
                Vfx.add(new Fx.Bubble(at.add(0.0, 0.9, 0.0), 1.7, SUN, 20, 0.6f, 1.0, 2.0, true));
                CineKit.shock(level, at, CineKit.UP, 2.6, SUN, WHITE, 14, 0.6f, true);
                CineKit.motesOut(at.add(0.0, 1.0, 0.0), 16, SUN_CORE, 0.06, 0.06f, 16);
            }
            case LINTANG_LANCE, HERO_CALL -> impact(level, p, at, 1.3f);
            case LINTANG_PULSE -> Vfx.add(new Fx.Ripple(c, CineKit.UP, 1.6, 0.5, 1.6, 0.12, SUN, 10, 0.5f, true));
            case LINTANG_FADE -> {
                if (collapseAge(p, 0.0f) < 0.0f) flinchFx(level, p, local, v);
            }
            case LINTANG_RETURN -> {
                v.collapse = NEVER;
                recoverFx(level, p, local);
            }
            case LINTANG_KELAM -> {
                v.cryon = true;
                if (now - v.lastCollapse > 300L) {
                    v.collapse = now;
                    v.lastCollapse = now;
                    v.weak = Math.max(v.weak, 0.45f);
                    collapseFx(level, p, local, v);
                } else {
                    flinchFx(level, p, local, v);
                }
            }
            default -> {
            }
        }
    }

    private static void charge(ClientLevel level, AbstractClientPlayer p, V v, long now, boolean local) {
        v.charge = now;
        boolean nether = PassiveConditions.inferno(level);
        if (!nether) {
            Vfx.add(new CineKit.PhotonStreams(p, lightDir(level), 30, CHARGE_LEN, SUN, SUN_CORE));
        }
        Vfx.add(new Fx.Glow(p, CineKit.chestAnchor(p), 1.2f, nether ? SUN_DEEP : SUN, CHARGE_LEN, CHARGE_LEN - 6));
        ShazamFx.schedule(6, CHARGE_LEN - 6, (lvl, t) -> {
            Vec3 ff = CineKit.feet(p);
            if (t % 10 == 0) CineKit.heatRings(ff.add(0.0, 0.15, 0.0), nether ? SUN_DEEP : SUN, 1.3 + t * 0.015, 16);
            ShazamFx.swirlDust(lvl, p, t);
            if (t > CHARGE_LEN - 30 && t % 4 == 0) Vfx.add(new Lightning.Crackle(p, SUN, 0.6f, 0.03f, 6).reach(1.0));
        });
        if (local) ScreenFx.vignette(0.3f, 0x4A3010, CHARGE_LEN);
    }

    private static void ignite(ClientLevel level, AbstractClientPlayer p, boolean local) {
        Vec3 c = CineKit.chest(p);
        Vec3 f = CineKit.feet(p);
        CineKit.burst(c, 2.6f, SUN, SUN_CORE, 14, 1.0f);
        CineKit.shock(level, f, CineKit.UP, 8.0, SUN, WHITE, 20, 0.85f, true);
        Vfx.add(new Fx.Ripple(c, CineKit.UP, 2.4, 0.4, 3.0, 0.2, SUN_CORE, 12, 0.7f, false));
        Vfx.add(new Fx.Pillar(f, 32.0, 1.1f, SUN, 14));
        CineKit.crater(level, f, 2.6, SUN_DEEP, DUST, 30);
        Vfx.add(new Lightning.Crackle(p, SUN, 1.7f, 0.04f, 24).reach(1.05));
        CineKit.sparks(c, 40, SUN, 0.36, 0.05f, 10, f.y);
        CineKit.sound(level, c, ShazamSounds.SHOCKWAVE, 1.3f, 1.05f);
        if (local) {
            ScreenFlash.flash(0.6f, 0xFFF0C8);
            FovKick.punch(0.45f);
        }
        CineKit.camera(p, c, 0.7f, 24.0);
    }

    private static void impact(ClientLevel level, AbstractClientPlayer p, Vec3 at, float s) {
        Vec3 dir = CineKit.norm(at.subtract(CineKit.chest(p)));
        Vfx.add(new Fx.Flash(at, 1.1f * s, SUN_CORE, 6, 0.9f));
        Vfx.add(new Fx.Wave(at, dir, 1.7 * s, 0.12 * s, SUN, 9, 0.75f, 0.05f, null));
        Vfx.add(new Fx.Ripple(at, dir, 1.4 * s, 0.2, 1.0 * s, 0.1, WHITE, 7, 0.6f, true));
        CineFx.flare(at, SUN_CORE, 6.0f * s, 0.12f, 0.85f, 10);
        CineKit.sparks(at, (int) (14 * s), SUN, 0.3 * s, 0.045f, 8, at.y - 1.2);
    }
}
