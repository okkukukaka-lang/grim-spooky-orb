package com.shazammod;

/**
 * Animasi yang dikirim server ke semua pemain di sekitar (0.30: juga dari Rival Juara, yang di client digambar sebagai
 * pemain boneka, lihat client.RivalPuppets).
 * Urutannya dipakai sebagai id di jaringan, jadi tambah yang baru di paling bawah.
 */
public enum ShazamAnim {
    TRANSFORM,
    REVERT,
    SOLOMON_SIGHT,
    HERCULES_CLAP,
    ATLAS_GROUND,
    ATLAS_DIVE,
    ATLAS_IMPACT,
    ZEUS_CALL,
    ACHILLES_ROAR,
    MERCURY_BLITZ,
    LAUNCH,
    LAND_SOFT,
    LAND_HERO,
    CRASH,
    SONIC_BOOM,
    ROLL_LEFT,
    ROLL_RIGHT,
    SUMMON,      // memanggil enam dewa sebelum petir transformasi
    ZEUS_RAGE,   // amarah Zeus: mata menyala putih
    HOOD_UP,     // tangan meraih ke belakang kepala lalu menarik hood ke depan
    HOOD_DOWN,   // tangan memegang tepi hood di dahi lalu mendorongnya ke belakang
    MERCURY_ON,  // Mode Kilat Mercury menyala: kuda-kuda, listrik meledak dari badan
    MERCURY_OFF, // Mode Kilat Mercury mati
    MERCURY_JAB, // pukulan-pukulan secepat kilat (x, y, z = titik kena)
    MERCURY_CROSS,
    MERCURY_HOOK,
    MERCURY_KICK,
    KNOCKOUT,    // serangan mematikan saat jadi Shazam: badan terhentak, kekuatan tercabut dari dada, balik jadi manusia
    // ======= Black Adam (dewa-dewa Mesir) =======
    ADAM_SHU,         // S - Pusaran Shu: lengan terentang lalu terangkat, badai pasir berputar mengangkat musuh
    ADAM_HERU,        // H - Sambaran Heru: merunduk, lalu menerjang secepat elang (x, y, z = titik akhir terjangan)
    ADAM_AMON,        // A - Tinju Amon: melompat kecil, menghantam tanah, tanah terbelah lurus ke depan (x, y, z = ujungnya)
    ADAM_ZEHUTI,      // Z - Segel Zehuti: dua jari ke pelipis lalu menunjuk, hieroglif mengikat musuh
    ADAM_ZEHUTI_MARK, // segel hieroglif di satu musuh (x, y, z = posisinya); tanpa gerakan badan
    ADAM_ATON,        // A - Sinar Aton: tangan ke langit, cakram matahari terbentuk di atas telapak
    ADAM_ATON_RAY,    // satu sinar Aton ke satu musuh (x, y, z = sasaran); tanpa gerakan badan
    ADAM_MEHEN,       // M - Lilitan Mehen: kedua lengan menyilang, ular raksasa membelit badan
    ADAM_MEHEN_BITE,  // ular Mehen mematuk satu musuh (x, y, z = sasaran); tanpa gerakan badan
    ADAM_RAGE,        // Murka Kahndaq: badan terangkat, kepalan mengepal di samping, lalu meraung - mata emas menyala
    // ======= 0.22 =======
    ADAM_CALL,        // M (Black Adam): Panggil Petir Kahndaq - kepalan ke langit, petir sihir menyambar badan sendiri
    ADAM_DEFLECT,     // proyektil memantul dari kulit Black Adam (x, y, z = titik kena); tanpa gerakan badan
    ADAM_PUNCH,       // tinju Black Adam mengenai (x, y, z = titik kena): percikan petir; tanpa gerakan badan
    KAHNDAQ_TRIAL,    // Ujian Kahndaq dimulai: Skarabe Teth-Adam diangkat, badai pasir bangkit (wujud manusia)
    KAHNDAQ_RISE,     // makhluk makam bangkit dari pasir / runtuh jadi pasir (x, y, z); tanpa gerakan badan
    KAHNDAQ_AWAKEN,   // lulus ujian: skarabe bangkit, petir Kahndaq memilih juaranya (Black Adam terbuka)
    KAHNDAQ_END,      // ujian selesai/gagal: badai pasir reda; tanpa gerakan badan
    SHAZAM_CHOSEN,    // enam totem dewa menyatu: Penyihir memilih juaranya (Shazam terbuka)
    // ======= 0.23: Shazam, juara para dewa =======
    HERCULES_THROW,   // Shift+X: Lemparan Hercules - musuh diangkat ke atas kepala lalu dilempar (x, y, z = sasaran)
    HERCULES_IMPACT,  // musuh yang dilempar menghantam (x, y, z); tanpa gerakan badan
    ATLAS_GLOBE,      // Beban Langit: bola langit jatuh ke titik ini (x, y, z); tanpa gerakan badan
    ZEUS_CHAIN_START, // petir dari ujung jari ke sasaran pertama (x, y, z); tanpa gerakan badan
    ZEUS_CHAIN,       // petir melompat dari sasaran sebelumnya ke sasaran ini (x, y, z); tanpa gerakan badan
    ACHILLES_NOVA,    // Ledakan Keberanian: damage yang ditahan perisai Achilles dilepas (lengan menghentak)
    THUNDER_PUNCH,    // Pukulan Guntur (Muatan Petir penuh) mengenai (x, y, z); tanpa gerakan badan
    MERCURY_DODGE,    // Refleks Mercury: serangan dihindari (x, y, z = posisi sebelum mengelak); tanpa gerakan badan
    HERO_CALL,        // Hati Pahlawan: makhluk tak berdosa diserang (x, y, z = penyerangnya); tanpa gerakan badan
    STORM_ABSORB,     // Penangkal Petir Hidup: petir alam diserap badan; tanpa gerakan badan
    GOD_SOLOMON,      // Badai Para Dewa: dewa di lingkaran menyerang (x, y, z = sasaran); tanpa gerakan badan
    GOD_HERCULES,
    GOD_ATLAS,
    GOD_ZEUS,
    GOD_ACHILLES,
    GOD_MERCURY,
    // ======= 0.25 =======
    ROD_STRIKE,       // Penangkal Petir Hidup: petir sihir menyambar Shazam tiap 2 detik (turun ROD_DESCENT tick, lalu
                      // menghantam dada); tanpa ganti klip badan (sentakan kecil di badan ditumpuk di atas gerakan apa pun)
    // ======= 0.26 =======
    FAMILY_CALL,      // Kekuatan Keluarga (J): kepalan ke langit, tautan petir ke keluarga, lalu (tick FAMILY_WINDUP) petir
                      // menyambar semuanya bersamaan dan lengan terbuka lebar
    // ======= 0.27 Tangan Kahndaq (Black Adam) =======
    ADAM_CATCH,       // satu proyektil berhenti di udara (pos = proyektil); tanpa gerakan badan
    ADAM_HOLD,        // telapak kanan terangkat menahan proyektil-proyektil yang melayang
    ADAM_RELEASE,     // tombol J: tangan dikibaskan, semua proyektil melesat balik ke penembaknya
    // ======= 0.28 Black Adam setara Shazam =======
    ADAM_BLOCK,       // Tangkisan Kahndaq: serangan ditahan kulit (pos = titik kena), panas matahari menyembur balik
    // ======= 0.28.1 Black Adam: kekuatan dari matahari Aton =======
    ADAM_SUN,         // Cakram Aton berdenyut tiap 2 detik: sinar bertangan menyentuh badan (ROD_DESCENT tick), lalu menyembur
    ADAM_SUNPUNCH,    // Tinju Aton: ledakan cahaya & api matahari di sasaran (pos)
    // ======= 0.29 pasif tiap 2 detik padam / menyala =======
    ADAM_SUN_SET,     // Cakram Aton terbenam (malam / Nether / End): turun ke balik punggung, mengecil, memerah, padam
    ADAM_SUN_RISE,    // Cakram Aton terbit lagi (pagi): naik dari balik punggung, membesar, keemasan, sinar terbuka
    ROD_FADE,         // petir Shazam padam (gurun / es & salju / Nether): listrik tersendat lalu habis
    // ======= 0.30 Sabbac (enam iblis S-A-B-B-A-C) =======
    SABBAC_HORNS,     // Z - Tanduk Setan: menunduk, lalu menyeruduk seperti banteng neraka (x, y, z = titik akhir)
    SABBAC_GORE,      // tanduk menyeruduk satu musuh (pos); tanpa gerakan badan
    SABBAC_AYM,       // X - Tubuh Aym: kulit membatu jadi obsidian berurat magma
    SABBAC_AYM_BURST, // Letusan Aym: cangkang magma pecah, damage yang ditahan meledak keluar
    SABBAC_CHAINS,    // C - Rantai Belial: tangan mencakar tanah, rantai neraka menyeruak
    SABBAC_CHAIN_BIND,// satu rantai membelit musuh (pos); tanpa gerakan badan
    SABBAC_BREATH,    // V - Napas Beelzebub: mendongak, lalu menyemburkan api neraka selama BREATH_TICKS
    SABBAC_ROAR,      // B - Teror Asmodeus: meraung, gelombang teror
    SABBAC_WINGS,     // N - Kepakan Crateis: sayap api terbentang, satu kepakan dahsyat
    SABBAC_HELLGATE,  // R - Gerbang Neraka: membesar jadi raksasa, lingkaran api neraka
    SABBAC_GEYSER,    // semburan api neraka dari tanah di bawah satu musuh (pos); tanpa gerakan badan
    SABBAC_CALL,      // M - Panggil Petir Neraka: petir hitam-merah menyembur dari bawah tanah ke badan sendiri
    SABBAC_LEGION,    // J - Pasukan Iblis: tangan ke tanah, retakan neraka, prajurit iblis bangkit
    SABBAC_RISE,      // satu prajurit iblis bangkit / runtuh jadi bara (pos); tanpa gerakan badan
    SABBAC_PULSE,     // Api Neraka tiap 2 detik: tanah retak membara, api & petir neraka menyembur naik menelan badan
    SABBAC_HELLPUNCH, // Tinju Neraka (Muatan Neraka penuh) mengenai (pos); tanpa gerakan badan
    SABBAC_ENGULF,    // Kulit Bara: serangan ditelan api (pos = titik kena); tanpa gerakan badan
    SABBAC_FIRE_OUT,  // Api Neraka padam (di bawah matahari / di dalam air)
    SABBAC_FIRE_IN,   // Api Neraka menyala lagi
    SABBAC_PUNCH,     // tinju Sabbac mengenai (pos): bara & api kecil; tanpa gerakan badan
    SABBAC_PACT,      // Perjanjian Enam Iblis (wujud manusia): Mahkota Sabbac diangkat, enam iblis menjawab
    // ======= 0.30 Rival Juara =======
    RIVAL_ARRIVE,     // rival juara datang (pos): petir / semburan api neraka di titik datang; tanpa gerakan badan
    RIVAL_DEPART,     // rival juara pergi (pos); tanpa gerakan badan
    // ======= 0.32 Lintang (juara bintang, L-I-N-T-A-N-G) =======
    LINTANG_DASH,      // L - Lesatan Bintang: merunduk, lalu melesat lurus (x, y, z = titik akhir)
    LINTANG_EYES,      // I - Iris Surya: mata memanas, lalu sinar panas dari kedua mata selama IRIS_TICKS
    LINTANG_BREATH,    // N - Napas Salju: menarik napas, lalu menghembus angin beku selama FROST_TICKS
    LINTANG_CLAP,      // T - Tepukan Guruh: lengan terentang ke belakang, lalu tepukan menggelegar (tick SONIC_WINDUP)
    LINTANG_BARRAGE,   // A - Amukan Kilat: rentetan pukulan secepat kilat (x, y, z = sasaran)
    LINTANG_HIT,       // satu pukulan mengenai (pos); tanpa gerakan badan
    LINTANG_LEAP,      // N - Napak Langit: melompat tinggi / menukik
    LINTANG_SLAM,      // hantaman Napak Langit di tanah (pos); tanpa gerakan badan
    LINTANG_FLARE,     // G - Gelegar Surya: menyerap cahaya, lalu meledakkannya (tick FLARE_WINDUP)
    LINTANG_CALL,      // M - Serap Surya: lengan terangkat menyerap cahaya langit
    LINTANG_RESCUE,    // J - Selamatkan: melesat ke semua sekutu
    LINTANG_SAVE,      // satu sekutu diselamatkan (pos); tanpa gerakan badan
    LINTANG_LANCE,     // tombak cahaya menyambar satu musuh (pos); tanpa gerakan badan
    LINTANG_PULSE,     // Serapan Cahaya tiap 2 detik (sinar matahari / bintang menyentuh badan); tanpa gerakan badan
    LINTANG_DAWNPUNCH, // Tinju Fajar (Muatan Cahaya penuh) mengenai (pos); tanpa gerakan badan
    LINTANG_PARRY,     // Tepisan Beku (pos = titik kena); tanpa gerakan badan
    LINTANG_BOUNCE,    // Kulit Baja: serangan lemah memantul (pos); tanpa gerakan badan
    LINTANG_PUNCH,     // tinju Lintang mengenai (pos); tanpa gerakan badan
    LINTANG_FADE,      // cahaya meredup (bawah tanah / Nether / End / dekat Kelam); tanpa gerakan badan
    LINTANG_RETURN,    // cahaya kembali; tanpa gerakan badan
    LINTANG_KELAM,     // Batu Kelam menghisap cahaya (pos); tanpa gerakan badan
    LINTANG_RITE;      // Penyatuan Bintang (wujud manusia): Kristal Bintang diangkat ke matahari

    // Waktu (tick) yang dipakai bersama oleh server dan client supaya efek pas dengan gerakan
    public static final int SUMMON_TICKS = 88;      // enam dewa datang satu per satu (lihat client.fx.GodShow), lalu kepalan diangkat
    public static final int TRANSFORM_WINDUP = 8;   // angkat kepalan ke langit
    public static final int BOLT_DESCENT = 10;      // petir turun pelan dari langit ke kepalan (slow motion)
    public static final int TRANSFORM_STRIKE = TRANSFORM_WINDUP + BOLT_DESCENT;   // tick klip TRANSFORM saat petir mengenai
    public static final int TRANSFORM_SLOWMO = 28;  // slow motion berlanjut selama kostum terbentuk (sampai hood terpasang)
    public static final int HOOD_GRAB = 6;          // tangan memegang tepi hood
    public static final int HOOD_MOVE = 10;         // hood ditarik/didorong selama ini
    public static final int HOOD_TICKS = 24;        // panjang animasi hood
    public static final int REVERT_WINDUP = 6;
    public static final int CAST_WINDUP = 5;        // Solomon, Hercules, Atlas (di tanah), Zeus
    public static final int ROAR_WINDUP = 4;        // Achilles
    public static final int ACHILLES_TICKS = 120;   // lama kulit tak tertembus
    public static final int SOLOMON_TICKS = 200;    // lama musuh "terbaca"
    public static final int BLITZ_TICKS = 6;        // lama terjangan Mercury
    public static final int RAGE_WINDUP = 9;        // Zeus Rage: membungkuk, lalu meraung ke langit
    public static final int RAGE_TICKS = 240;       // lama amarah Zeus (12 detik)
    public static final int KNOCKOUT_BURST = 3;     // terlempar balik: kekuatan tercabut keluar dari dada (lengan terentang)
    // Black Adam
    public static final int SHU_TICKS = 50;         // lama pusaran pasir Shu (lalu meledak ke luar)
    public static final int HERU_WINDUP = 3;        // merunduk sebelum menerjang
    public static final int HERU_TICKS = 5;         // lama terjangan Heru (titik awal -> titik akhir)
    public static final int AMON_WINDUP = 7;        // melompat kecil lalu kedua kepalan menghantam tanah
    public static final int AMON_SPREAD = 8;        // tanah terbelah merambat sampai ujung dalam waktu ini
    public static final int ATON_WINDUP = 8;        // cakram matahari terbentuk, lalu sinar pertama
    public static final int ATON_GAP = 2;           // jeda antar-sinar ke tiap musuh
    public static final int MEHEN_WINDUP = 6;       // ular muncul dari bayangan dan melilit
    public static final int MEHEN_TICKS = 160;      // lama lilitan Mehen (8 detik)
    public static final int ADAM_RAGE_WINDUP = 10;  // Murka Kahndaq: menahan amarah, lalu meraung
    public static final int ADAM_CALL_WINDUP = 12;  // Panggil Petir: kepalan diangkat, langit bergemuruh, lalu petir menyambar
    // Jalan mendapatkan juara
    public static final int KAHNDAQ_AWAKEN_TICKS = 70;    // upacara skarabe bangkit
    public static final int KAHNDAQ_AWAKEN_STRIKE = 52;   // petir Kahndaq menyambar (Black Adam terbuka)
    public static final int SHAZAM_CHOSEN_TICKS = 64;     // upacara enam totem
    public static final int SHAZAM_CHOSEN_STRIKE = 48;    // petir Penyihir menyambar (Shazam terbuka)
    // Shazam 0.23: juara para dewa
    public static final int THROW_LIFT = 6;         // Lemparan Hercules: musuh diangkat ke atas kepala selama ini
    public static final int THROW_RELEASE = 9;      // lalu dilempar (tick klip HERCULES_THROW)
    public static final int ATLAS_HOLD = 13;        // Beban Langit: bola langit diangkat, lalu dihantamkan di tick ini
    public static final int ATLAS_GLOBE_DROP = 9;   // bola langit jatuh selama ini sebelum hantaman
    public static final int ZEUS_HOP = 2;           // jeda antar-lompatan Petir Berantai
    public static final int NOVA_WINDUP = 2;        // Ledakan Keberanian: lengan menghentak, lalu meledak
    // 0.25: Penangkal Petir Hidup
    public static final int FAMILY_WINDUP = 10;     // 0.26 Kekuatan Keluarga: kepalan terangkat, lalu petir menyambar semua
    public static final int SUN_SET_TICKS = 32;      // 0.29: lama Cakram Aton terbenam
    public static final int SUN_RISE_TICKS = 20;     // 0.29: lama Cakram Aton terbit (denyut pertama sesudahnya)
    public static final int ROD_FADE_TICKS = 26;     // 0.29: lama listrik Shazam tersendat lalu padam
    public static final int ROD_DESCENT = 3;        // petir turun dari langit selama ini, lalu menghantam (energi, darah,
                                                    // armor pulih tepat di tick ini; SFX rod_strike retak di 0,15 detik)
    // 0.30 Sabbac
    public static final int HORN_WINDUP = 6;        // Tanduk Setan: menunduk & menggaruk tanah seperti banteng
    public static final int HORN_TICKS = 8;         // lama serudukan (titik awal -> titik akhir)
    public static final int AYM_WINDUP = 5;         // Tubuh Aym: kulit membatu
    public static final int AYM_TICKS = 140;        // lama kulit obsidian (7 detik)
    public static final int CHAIN_WINDUP = 6;       // Rantai Belial: rantai menyeruak dari tanah
    public static final int CHAIN_PULL = 20;        // lalu (1 detik kemudian) musuh yang terbelit ditarik
    public static final int BREATH_WINDUP = 8;      // Napas Beelzebub: menarik napas, lalu menyembur
    public static final int BREATH_TICKS = 40;      // lama semburan (2 detik)
    public static final int TERROR_WINDUP = 7;      // Teror Asmodeus: menahan raungan
    public static final int WINGS_WINDUP = 6;       // Kepakan Crateis: sayap terbentang, lalu mengepak
    public static final int HELLGATE_WINDUP = 12;   // Gerbang Neraka: membungkuk menahan api, lalu meraung jadi raksasa
    public static final int SABBAC_CALL_WINDUP = 12; // Panggil Petir Neraka: tanah bergemuruh, lalu petir menyembur naik
    public static final int LEGION_WINDUP = 10;     // Pasukan Iblis: tangan ke tanah, lalu prajurit bangkit
    public static final int PACT_TICKS = 80;        // Perjanjian Enam Iblis
    public static final int PACT_STRIKE = 60;       // petir neraka menyembur naik (Sabbac terbuka)
    public static final int FIRE_OUT_TICKS = 28;    // Api Neraka padam
    public static final int FIRE_IN_TICKS = 16;     // Api Neraka menyala lagi (denyut pertama sesudahnya)
    // 0.32 Lintang
    public static final int LESAT_WINDUP = 4;       // Lesatan Bintang: merunduk, lalu melesat
    public static final int LESAT_TICKS = 6;        // lama lesatan (titik awal -> titik akhir)
    public static final int IRIS_WINDUP = 6;        // Iris Surya: mata memanas
    public static final int IRIS_TICKS = 40;        // lama sinar mata (2 detik)
    public static final int FROST_WINDUP = 8;       // Napas Salju: menarik napas
    public static final int FROST_TICKS = 40;       // lama hembusan (2 detik)
    public static final int SONIC_WINDUP = 6;       // Tepukan Guruh: lengan terentang, lalu tepukan
    public static final int BARRAGE_WINDUP = 3;     // Amukan Kilat: kuda-kuda
    public static final int BARRAGE_TICKS = 24;     // lama rentetan pukulan (pukulan penutup di akhir)
    public static final int LEAP_WINDUP = 4;        // Napak Langit: merunduk, lalu melompat
    public static final int FLARE_WINDUP = 16;      // Gelegar Surya: menyerap cahaya, lalu meledak
    public static final int SUNCALL_WINDUP = 10;    // Serap Surya: lengan terangkat, lalu tiang cahaya menghunjam
    public static final int RESCUE_WINDUP = 4;      // Selamatkan: lalu melesat ke tiap sekutu (2 tick per sekutu)
    public static final int RITE_TICKS = 80;        // Penyatuan Bintang
    public static final int RITE_STRIKE = 60;       // tiang cahaya menghunjam (Lintang terbuka)
    public static final int DIM_TICKS = 24;         // cahaya Lintang meredup

    /** Penanda efek di satu titik (bukan gerakan badan): klip pemain yang sedang jalan nggak diganti. */
    public boolean isMarker() {
        return this == ADAM_ZEHUTI_MARK || this == ADAM_ATON_RAY || this == ADAM_MEHEN_BITE || this == ADAM_DEFLECT
                || this == ADAM_PUNCH || this == KAHNDAQ_RISE || this == KAHNDAQ_END
                || this == HERCULES_IMPACT || this == ATLAS_GLOBE || this == ZEUS_CHAIN_START || this == ZEUS_CHAIN
                || this == THUNDER_PUNCH || this == MERCURY_DODGE || this == HERO_CALL || this == STORM_ABSORB || isGodStrike()
                || this == ROD_STRIKE || this == ADAM_CATCH || this == ADAM_BLOCK || this == ADAM_SUN
                || this == ADAM_SUNPUNCH || this == ADAM_SUN_SET || this == ADAM_SUN_RISE || this == ROD_FADE
                || this == SABBAC_GORE || this == SABBAC_CHAIN_BIND || this == SABBAC_GEYSER || this == SABBAC_RISE
                || this == SABBAC_PULSE || this == SABBAC_HELLPUNCH || this == SABBAC_ENGULF || this == SABBAC_FIRE_OUT
                || this == SABBAC_FIRE_IN || this == SABBAC_PUNCH || this == RIVAL_ARRIVE || this == RIVAL_DEPART
                || this == LINTANG_HIT || this == LINTANG_SLAM || this == LINTANG_SAVE || this == LINTANG_LANCE
                || this == LINTANG_PULSE || this == LINTANG_DAWNPUNCH || this == LINTANG_PARRY || this == LINTANG_BOUNCE
                || this == LINTANG_PUNCH || this == LINTANG_FADE || this == LINTANG_RETURN || this == LINTANG_KELAM;
    }

    /** Serangan salah satu dewa di lingkaran Badai Para Dewa (Shazam, tombol R). */
    public boolean isGodStrike() {
        return ordinal() >= GOD_SOLOMON.ordinal() && ordinal() <= GOD_MERCURY.ordinal();
    }

    /** 0-5 = Solomon, Hercules, Atlas, Zeus, Achilles, Mercury (sama dengan urutan dewa di client.fx.GodFigures). */
    public int godIndex() {
        return ordinal() - GOD_SOLOMON.ordinal();
    }

    public static ShazamAnim godStrike(int god) {
        return values()[GOD_SOLOMON.ordinal() + Math.floorMod(god, 6)];
    }

    public static ShazamAnim byId(int id) {
        ShazamAnim[] values = values();
        return id >= 0 && id < values.length ? values[id] : null;
    }
}
