import json, os, re
# Jalankan dari mana saja: python3 tools/sfx/gen.py
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
ASSETS = os.path.join(ROOT, 'src/main/resources/assets/shazammod')
rows=[l.rstrip('\n').split('|') for l in open(os.path.join(HERE, 'names.txt'), encoding='utf-8') if l.strip()]
base=[r for r in rows][:33]; skill=rows[33:65]; rod=rows[65:66]; fam=rows[66:68]; hand=rows[68:70]; adam28=rows[70:73]; cond=rows[73:76]; sab=rows[76:96]; riv=rows[96:97]; lint=rows[97:]   # 0.25-0.32
def decl(rs): return [f'    public static final DeferredHolder<SoundEvent, SoundEvent> {c} = reg("{n}");' for n,c,*_ in rs]
java=['package com.shazammod;','','import net.minecraft.core.registries.Registries;','import net.minecraft.sounds.SoundEvent;',
'import net.minecraft.util.Mth;','import net.neoforged.neoforge.registries.DeferredHolder;','import net.neoforged.neoforge.registries.DeferredRegister;','',
'/**',
' * SFX sinematik buatan sendiri (bukan suara bawaan Minecraft). File .ogg-nya ada di assets/shazammod/sounds/,',
' * daftar variannya di assets/shazammod/sounds.json. Semua suara mono supaya terdengar dari arah sumbernya.',
' * Dibuat dengan tools/sfx/synth.py.',
' */',
'public final class ShazamSounds {','    private ShazamSounds() {}','',
'    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(Registries.SOUND_EVENT, ShazamMod.MODID);','',
'    // ------------------------------------------------ pustaka umum (0.24.1)']+decl(base)+['',
'    // ------------------------------------------------ suara khas tiap skill (0.24.2)',
'    // *_WINDUP / *_CAST / MEHEN_RISE = ancang-ancang: panjangnya PERSIS sama dengan tick ancang-ancang di ShazamAnim,',
'    // jadi puncaknya jatuh tepat di tick hantaman. Putar di pitch 1 (jangan lewat tune()) supaya panjangnya nggak berubah.']+decl(skill)+['',
'    // ------------------------------------------------ Penangkal Petir Hidup (0.25)',
'    // ROD_STRIKE = petir menyambar Shazam tiap 2 detik: desis turun 0,15 dtk (= ShazamAnim.ROD_DESCENT) lalu retakan tepat di',
'    // tick hantaman. Sama seperti ancang-ancang, putar di pitch +-1 supaya retakannya nggak bergeser.']+decl(rod)+['',
'    // ------------------------------------------------ Kekuatan Keluarga (0.26)',
'    // FAMILY_WINDUP panjangnya PERSIS ShazamAnim.FAMILY_WINDUP (10 tick) dan memuncak di tick sambaran; putar di pitch 1.']+decl(fam)+['',
'    // ------------------------------------------------ Tangan Kahndaq (0.27, Black Adam)',
'    // ADAM_CATCH = proyektil berhenti di udara (desing macet + dengung menahan), ADAM_RELEASE = semua dilempar balik.']+decl(hand)+['',
'    // ------------------------------------------------ Black Adam setara Shazam (0.28), kekuatan matahari Aton (0.28.1)',
'    // ADAM_BLOCK = Tangkisan Kahndaq (ditahan kulit, panas menyembur balik), ATON_PULSE = Cakram Aton tiap 2 detik',
'    // (semburan tepat di 0,15 dtk = ShazamAnim.ROD_DESCENT), ATON_PUNCH = Tinju Aton.']+decl(adam28)+['',
'    // ------------------------------------------------ Pasif tiap 2 detik padam / menyala (0.29)',
'    // ROD_FADE = petir Shazam padam (gurun / es / Nether), ATON_SET = Cakram Aton terbenam, ATON_RISE = terbit (mekar di 1 dtk).']+decl(cond)+['',
'    // ------------------------------------------------ Sabbac, juara enam iblis (0.30)',
'    // HELLFIRE_PULSE = Api Neraka tiap 2 detik (semburan tepat di 0,15 dtk = ShazamAnim.ROD_DESCENT). *_WINDUP panjangnya',
'    // PERSIS tick ancang-ancang di ShazamAnim (HORN_WINDUP 6, HELLGATE_WINDUP 12, SABBAC_CALL_WINDUP 12); putar di pitch 1.',
'    // BEELZEBUB_BREATH = tarikan napas BREATH_WINDUP lalu semburan BREATH_TICKS. SABBAC_PACT memuncak di PACT_STRIKE.']+decl(sab)+['',
'    // ------------------------------------------------ Rival Juara (0.30)']+decl(riv)+['',
'    // ------------------------------------------------ Lintang, juara bintang (0.32)',
'    // SOLAR_PULSE = Serapan Cahaya tiap 2 detik (sentuhan cahaya tepat di 0,15 dtk = ShazamAnim.ROD_DESCENT).',
'    // SOLAR_FLARE memuncak di 0,8 dtk (= FLARE_WINDUP), SUN_CALL di 0,5 dtk (= SUNCALL_WINDUP), LINTANG_RITE di 3 dtk',
'    // (= RITE_STRIKE). Putar di pitch 1 supaya puncaknya nggak bergeser.']+decl(lint)+['',
'    private static DeferredHolder<SoundEvent, SoundEvent> reg(String name) {',
'        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(ShazamMod.id(name)));',
'    }','',
'    // ======= Angka yang gampang diutak-atik =======',
'    /** Seberapa jauh nada SFX ikut angka pitch di kode (1 = penuh, 0 = selalu nada asli). Nada ke bawah dibiarkan',
'     *  lebih bebas supaya slow motion tetap terdengar berat. */',
'    private static final float PITCH_UP_FOLLOW = 0.4f;',
'    private static final float PITCH_DOWN_FOLLOW = 0.6f;','',
'    /**',
'     * Angka pitch lama disetel untuk suara bawaan Minecraft (misalnya 0.4 supaya guntur vanila terdengar berat,',
'     * atau 1.9 supaya terdengar kecil). SFX baru sudah dibuat dengan nada yang pas, jadi angkanya dijinakkan',
'     * supaya suaranya nggak jadi melar atau cempreng.',
'     */',
'    public static float tune(float pitch) {',
'        float p = pitch < 1f ? 1f - (1f - pitch) * PITCH_DOWN_FOLLOW : 1f + (pitch - 1f) * PITCH_UP_FOLLOW;',
'        return Mth.clamp(p, 0.55f, 1.6f);',
'    }','}','']
open(os.path.join(ROOT, 'src/main/java/com/shazammod/ShazamSounds.java'),'w',encoding='utf-8').write('\n'.join(java))
far={'thunder','transform','transform_adam','braam','sonic_boom','dread','atlas_slam','storm_gods','kahndaq_wrath','amon_quake','zeus_spear','hercules_clap','family_strike','transform_sabbac','hellgate_open','demon_call','rival_arrive','asmodeus_roar','aym_burst','transform_lintang','solar_flare','sonic_clap','lintang_rite','sun_strike'}
filemap={'transform':['transform_1'],'transform_adam':['transform_2']}
sj={}
for name,const,n,idn,en in rows:
    files=filemap.get(name,[f'{name}_{i+1}' for i in range(int(n))])
    snd=[{'name':f'shazammod:{f}','attenuation_distance':48} if name in far else f'shazammod:{f}' for f in files]
    sj[name]={'subtitle':f'subtitles.shazammod.{name}','sounds':snd}
json.dump(sj,open(os.path.join(ASSETS, 'sounds.json'),'w'),indent=2)
for lang, col in (('en_us', 4), ('id_id', 3)):   # subtitle digabung ke file bahasa yang sudah ada
    p = os.path.join(ASSETS, 'lang', lang + '.json')
    d = json.load(open(p, encoding='utf-8'))
    d.update({f'subtitles.shazammod.{r[0]}': r[col] for r in rows})
    json.dump(d, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
print(len(rows),'events')
