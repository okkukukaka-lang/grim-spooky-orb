package com.shazammod.helion3;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import com.shazammod.Helion3Skills;
import com.shazammod.HelionItems;
import com.shazammod.LintangItems;
import com.shazammod.PassiveConditions;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamAnimPayload;
import com.shazammod.ShazamForm;
import com.shazammod.ShazamPowers;
import com.shazammod.ShazamSounds;
import com.shazammod.rival.RivalChampion;
import com.shazammod.rival.RivalSpawner;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * 0.48 SUBJEK TIGA (Helion-3), Sang Penghancur Abadi (bos, rancangan orisinal). Prototipe Proyek Helion yang paling nggak
 * stabil: selnya berulang kali dihancurkan & dipaksa tumbuh lagi dengan radiasi Cryon dan sengatan cahaya buatan, jadi dia
 * nggak mengenal rasa sakit dan nggak punya tujuan selain menghancurkan apa pun yang bergerak.
 *
 * - ADAPTASI: serangan dibagi 7 jenis (Kind). Tiap kali kena jenis yang sama, tubuhnya makin kebal terhadapnya (+6%, paling
 *   kebal 60% selama nyawa itu). Pelat sel matinya menahan fisik & proyektil (x0,5) dan ledakan (x0,7); penyerang jarak
 *   dekat tertusuk duri.
 * - TIGA NYAWA: tiap kali "dibunuh" dia tumbang, kepompong sel mati menutupi tubuhnya, lalu bangkit lagi dengan darah penuh,
 *   lebih kuat (+15%), dan KEBAL TOTAL terhadap jenis serangan yang membunuhnya. Kebal Cryon = radiasi Cryon malah
 *   diserap: dia pulih dan cakar & tulangnya menguat (sampai +64%). Jadi untuk menghabisinya, tiap nyawa harus dibunuh
 *   dengan cara yang berbeda.
 * - Bertarung brutal tanpa taktik rumit: raungan (lawan terlempar, pusing, proyektil hancur), lompatan & hantaman dari udara,
 *   serudukan yang menabrak tembok, dan pukulan beruntun yang menembus serta mematahkan perisai lalu menghantam tanah.
 * - Kedatangannya memaksa Lintang & Helion-6 berhenti saling bertarung: 3,5 detik sesudah dia merangkak keluar dari tanah,
 *   keduanya datang sebagai SEKUTU di sisi pemain (RivalSpawner.allies) dan saling bersahutan lewat balon kata.
 */
public class Helion3 extends Monster {
    // ================= Angka-angka yang gampang diutak-atik =================
    public static final double HEALTH = 900.0;      // darah per nyawa
    public static final int LIVES = 3;
    private static final double SPEED = 0.3;
    private static final double SCALE = 1.45;
    public static final float BIO_ARMOR = 0.5f;     // fisik & proyektil
    public static final float BLAST_ARMOR = 0.7f;
    public static final float ADAPT_STEP = 0.06f;
    public static final float ADAPT_MAX = 0.6f;
    private static final float THORNS = 4f;
    private static final float SMASH_DAMAGE = 30f;
    private static final float POUND_DAMAGE = 24f;
    private static final float SLAM_DAMAGE = 40f;
    private static final float CHARGE_DAMAGE = 34f;
    private static final float ROAR_DAMAGE = 8f;
    private static final double ROAR_RADIUS = 10.0;
    private static final double SLAM_RADIUS = 7.0;
    private static final double POUND_RADIUS = 4.5;
    private static final float REVIVE_BUFF = 0.15f;  // tiap bangkit: damage +15%
    private static final float CLAW_STEP = 0.08f;    // tiap serapan Cryon: cakar +8%
    private static final int CLAW_MAX = 8;
    private static final float ABSORB_HEAL = 0.3f;
    private static final int XP = 600;
    public static final long COOLDOWN = 72000L;      // kemunculan alami: paling sering sekali per jam per pemain
    public static final float SPAWN_SHARE = 0.2f;    // dari kedatangan rival di malam yang memenuhi syarat
    // Waktu (tick): sama dengan pose di client (Helion3Renderer) & SFX
    public static final int EMERGE_TICKS = 60;
    public static final int EMERGE_ROAR = 48;
    public static final int ROAR_TICKS = 34;
    public static final int ROAR_HIT = 8;
    public static final int LEAP_WINDUP = 6;
    public static final int LEAP_TICKS = 18;
    public static final int CHARGE_WINDUP = 12;
    public static final int CHARGE_TICKS = 16;
    public static final int SMASH_TICKS = 40;
    public static final int SMASH_HIT1 = 9;
    public static final int SMASH_HIT2 = 20;
    public static final int SMASH_POUND = 32;
    public static final int STAGGER_TICKS = 16;
    public static final int CRASH_STAGGER = 34;
    public static final int FALL_TICKS = 30;
    public static final int REVIVE_TICKS = 70;
    public static final int DEATH_TICKS = 80;
    public static final int ALLY_DELAY = 70;
    // =========================================================================

    /** Jenis serangan yang bisa dia adaptasi (rgb = warna kilat adaptasinya). */
    public enum Kind {
        LIGHT(0xFFE9A8), CRYON(0x46FF8C), MAGIC(0x8FB4FF), COLD(0xA8F0FF), MELEE(0xC8C0B8), RANGED(0xD8B080), BLAST(0xFF9A40);

        public final int rgb;

        Kind(int rgb) {
            this.rgb = rgb;
        }
    }

    public enum Action { IDLE, EMERGE, ROAR, LEAP, CHARGE, SMASH, STAGGER, FALL, REVIVE, DEATH }

    private static final EntityDataAccessor<Integer> DATA_ACTION = SynchedEntityData.defineId(Helion3.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_ACTION_TICK = SynchedEntityData.defineId(Helion3.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_IMMUNE = SynchedEntityData.defineId(Helion3.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_LIVES = SynchedEntityData.defineId(Helion3.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_CLAWS = SynchedEntityData.defineId(Helion3.class, EntityDataSerializers.INT);

    private static final Map<UUID, Long> NEXT_NATURAL = new HashMap<>();

    private final ServerBossEvent bar = new ServerBossEvent(Component.literal(""), BossEvent.BossBarColor.PURPLE,
            BossEvent.BossBarOverlay.NOTCHED_10);
    private final float[] adapt = new float[Kind.values().length];
    private final Set<UUID> hitThisAction = new HashSet<>();
    private int lives = LIVES;
    private int immune;
    private int claws;
    private Kind lastKind;
    private Kind killKind;
    private UUID witness;
    private boolean callAllies;
    private Action action = Action.EMERGE;
    private int actionAge;
    private int staggerTicks = STAGGER_TICKS;
    private LivingEntity target;
    private int retarget;
    private int idle;
    private Vec3 from = Vec3.ZERO;
    private Vec3 to = Vec3.ZERO;
    private Vec3 dir = Vec3.ZERO;
    private long nextRoar;
    private long nextLeap;
    private long nextCharge;
    private long nextSmash;
    private long nextImmuneFx;
    private long nextAbsorbFx;

    public Helion3(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.xpReward = XP;
        this.setPersistenceRequired();
        bar.setDarkenScreen(true);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, HEALTH)
                .add(Attributes.MOVEMENT_SPEED, SPEED)
                .add(Attributes.ATTACK_DAMAGE, SMASH_DAMAGE)
                .add(Attributes.FOLLOW_RANGE, 48.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
                .add(Attributes.STEP_HEIGHT, 1.6)
                .add(Attributes.ARMOR, 10.0)
                .add(Attributes.SCALE, SCALE);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_ACTION, Action.EMERGE.ordinal());
        builder.define(DATA_ACTION_TICK, 0);
        builder.define(DATA_IMMUNE, 0);
        builder.define(DATA_LIVES, LIVES);
        builder.define(DATA_CLAWS, 0);
    }

    @Override
    protected void registerGoals() {
        // AI sendiri di customServerAiStep
    }

    // ------------------------------------------------------------------ dibaca client

    public Action action() {
        int i = this.entityData.get(DATA_ACTION);
        Action[] all = Action.values();
        return i >= 0 && i < all.length ? all[i] : Action.IDLE;
    }

    /** Tick sejak aksi sekarang dimulai (pakai waktu dunia, jadi sama di server & client). */
    public float actionTime(float partialTick) {
        return (float) ((int) this.level().getGameTime() - this.entityData.get(DATA_ACTION_TICK)) + partialTick;
    }

    public int immuneMask() {
        return this.entityData.get(DATA_IMMUNE);
    }

    public int livesLeft() {
        return this.entityData.get(DATA_LIVES);
    }

    public int claws() {
        return this.entityData.get(DATA_CLAWS);
    }

    /** Sedang muncul, tumbang, bangkit, atau hancur: nggak bisa dilukai. */
    public boolean untouchable() {
        Action a = action();
        return a == Action.EMERGE || a == Action.FALL || a == Action.REVIVE || a == Action.DEATH;
    }

    // ------------------------------------------------------------------ muncul

    /** Muncul untuk pemain ini (dipanggil RivalSpawner sebelum ditambahkan ke dunia). */
    public void setup(ServerPlayer witness, boolean callAllies) {
        this.witness = witness.getUUID();
        this.callAllies = callAllies;
        updateBar();
    }

    /** Malam di Overworld, pemainnya sudah menyentuh Proyek Helion (punya Lintang / Helion-6, atau membawa serumnya). */
    public static boolean naturalTime(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        if (level.dimension() != Level.OVERWORLD || PassiveConditions.sunUp(level)) {
            return false;
        }
        Long next = NEXT_NATURAL.get(player.getUUID());
        if (next != null && level.getGameTime() < next) {
            return false;
        }
        var data = ShazamPowers.data(player);
        return data.lintangUnlocked() || data.helionUnlocked() || carriesSerum(player);
    }

    public static void cooldown(ServerPlayer player) {
        NEXT_NATURAL.put(player.getUUID(), player.serverLevel().getGameTime() + COOLDOWN);
    }

    private static boolean carriesSerum(ServerPlayer player) {
        var inventory = player.getInventory();
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack stack = inventory.getItem(i);
            if (!stack.isEmpty() && (stack.is(HelionItems.SERUM.get()) || stack.is(LintangItems.STAR_CRYSTAL.get()))) {
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------ alat bantu

    public void anim(ShazamAnim anim, Vec3 pos) {
        if (this.level().isClientSide) {
            return;
        }
        PacketDistributor.sendToPlayersTrackingEntity(this, new ShazamAnimPayload(this.getId(), anim.ordinal(),
                (float) pos.x, (float) pos.y, (float) pos.z));
    }

    private void sound(Vec3 at, SoundEvent sound, float volume, float pitch) {
        this.level().playSound(null, at.x, at.y, at.z, sound, SoundSource.HOSTILE, volume, pitch);
    }

    private void act(Action a) {
        action = a;
        actionAge = 0;
        hitThisAction.clear();
        this.entityData.set(DATA_ACTION, a.ordinal());
        this.entityData.set(DATA_ACTION_TICK, (int) this.level().getGameTime());
    }

    private ServerPlayer witness() {
        if (witness == null || !(this.level() instanceof ServerLevel level)) {
            return null;
        }
        return level.getServer().getPlayerList().getPlayer(witness);
    }

    private Vec3 chest() {
        return this.position().add(0, this.getBbHeight() * 0.6, 0);
    }

    private Vec3 facing() {
        float yaw = this.getYRot() * Mth.DEG_TO_RAD;
        return new Vec3(-Mth.sin(yaw), 0, Mth.cos(yaw));
    }

    private void face(LivingEntity t) {
        double dx = t.getX() - this.getX(), dz = t.getZ() - this.getZ();
        float yaw = (float) (Mth.atan2(dz, dx) * Mth.RAD_TO_DEG) - 90f;
        this.setYRot(yaw);
        this.yHeadRot = yaw;
        this.yBodyRot = yaw;
        this.getLookControl().setLookAt(t, 30f, 30f);
    }

    /** Apa pun yang bergerak: pemain (bukan kreatif/penonton), juara rival, golem besi, dan monster lain. */
    private boolean isPrey(LivingEntity e) {
        if (e == this || !e.isAlive() || e instanceof Helion3) {
            return false;
        }
        if (e instanceof Player p) {
            return !p.isCreative() && !p.isSpectator();
        }
        return e instanceof RivalChampion || e instanceof IronGolem || e instanceof Enemy;
    }

    private List<LivingEntity> prey(Vec3 c, double radius) {
        return this.level().getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(radius),
                e -> isPrey(e) && e.distanceToSqr(c) <= radius * radius);
    }

    private LivingEntity pickTarget() {
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        LivingEntity hurtBy = this.getLastHurtByMob();
        for (LivingEntity e : this.level().getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate(32.0), this::isPrey)) {
            double score = Math.sqrt(e.distanceToSqr(this));
            if (championOf(e) != null) {
                score -= 12.0;
            }
            if (e == hurtBy) {
                score -= 8.0;
            }
            if (score < bestScore) {
                bestScore = score;
                best = e;
            }
        }
        return best;
    }

    private float power() {
        return (1f + REVIVE_BUFF * (LIVES - lives)) * (1f + CLAW_STEP * claws);
    }

    /** Pukulan kekuatan juara; perisai yang sedang dipakai dipatahkan dulu. */
    private boolean strike(LivingEntity e, float damage) {
        if (!isPrey(e)) {
            return false;
        }
        if (e instanceof Player p && p.isBlocking()) {
            p.getCooldowns().addCooldown(Items.SHIELD, 100);
            p.stopUsingItem();
            p.level().broadcastEntityEvent(p, (byte) 30);
        }
        e.invulnerableTime = 0;
        return e.hurt(RivalChampion.clash(this.level(), this), damage * power());
    }

    private static Vec3 away(Vec3 from, LivingEntity e) {
        Vec3 a = new Vec3(e.getX() - from.x, 0, e.getZ() - from.z);
        return a.lengthSqr() < 1.0E-4 ? Vec3.ZERO : a.normalize();
    }

    private static void push(LivingEntity e, Vec3 from, double strength, double up) {
        Vec3 a = away(from, e);
        e.push(a.x * strength, up, a.z * strength);
        e.hurtMarked = true;
    }

    private void tell(Component message) {
        for (Player p : this.level().getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(64.0))) {
            if (p instanceof ServerPlayer sp) {
                sp.displayClientMessage(message, true);
            }
        }
    }

    public static Component kindName(Kind kind) {
        return Component.translatable("helion3.shazammod.kind." + kind.name().toLowerCase(Locale.ROOT));
    }

    static String icon(Kind kind) {
        return switch (kind) {
            case LIGHT -> "\u2600";
            case CRYON -> "\u2622";
            case MAGIC -> "\u26A1";
            case COLD -> "\u2744";
            case MELEE -> "\u270A";
            case RANGED -> "\u27B6";
            case BLAST -> "\u2738";
        };
    }

    private void updateBar() {
        MutableComponent name = Component.translatable("entity.shazammod.helion3").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD);
        StringBuilder hearts = new StringBuilder("  ");
        for (int i = 0; i < LIVES; i++) {
            hearts.append(i < lives ? '\u2764' : '\u2716');
        }
        name.append(Component.literal(hearts.toString()).withStyle(ChatFormatting.RED));
        if (immune != 0) {
            name.append(Component.literal("  ").append(Component.translatable("helion3.shazammod.immune")).withStyle(ChatFormatting.GRAY));
            for (Kind k : Kind.values()) {
                if ((immune & (1 << k.ordinal())) != 0) {
                    name.append(Component.literal(" " + icon(k)).withStyle(ChatFormatting.WHITE));
                }
            }
        }
        bar.setName(name);
    }

    // ------------------------------------------------------------------ AI

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (!(this.level() instanceof ServerLevel level)) {
            return;
        }
        actionAge++;
        long now = level.getGameTime();
        if (callAllies && this.tickCount >= ALLY_DELAY) {   // Lintang & Helion-6 datang sebagai sekutu
            callAllies = false;
            ServerPlayer w = witness();
            if (w != null && w.distanceToSqr(this) < 96.0 * 96.0) {
                RivalSpawner.allies(w, this);
            }
        }
        bar.setProgress(Mth.clamp(this.getHealth() / this.getMaxHealth(), 0f, 1f));
        switch (action) {
            case EMERGE -> tickEmerge(now);
            case ROAR -> tickRoar();
            case LEAP -> tickLeap();
            case CHARGE -> tickCharge();
            case SMASH -> tickSmash();
            case STAGGER -> {
                this.getNavigation().stop();
                if (actionAge >= staggerTicks) {
                    act(Action.IDLE);
                }
            }
            case FALL -> tickFall();
            case REVIVE -> tickRevive(now);
            case DEATH -> tickDeath();
            default -> tickHunt(now);
        }
    }

    private void tickEmerge(long now) {
        this.getNavigation().stop();
        this.setDeltaMovement(0, Math.min(this.getDeltaMovement().y, 0), 0);
        if (actionAge == 1) {   // merangkak keluar dari tanah
            anim(ShazamAnim.HELION3_EMERGE, this.position());
            sound(this.position(), ShazamSounds.HELION3_EMERGE.get(), 4.0f, 1f);
            ServerPlayer w = witness();
            if (w != null) {
                w.connection.send(new ClientboundSetTitlesAnimationPacket(10, 70, 20));
                w.connection.send(new ClientboundSetTitleTextPacket(Component.translatable("title.shazammod.helion3")
                        .withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD)));
                w.connection.send(new ClientboundSetSubtitleTextPacket(Component.translatable("title.shazammod.helion3_sub")
                        .withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC)));
            }
        }
        if (actionAge == EMERGE_ROAR) {
            roarBlast(0.7f);
        }
        if (actionAge >= EMERGE_TICKS) {
            act(Action.IDLE);
            nextRoar = now + 300;
            nextLeap = now + 60;
            nextCharge = now + 100;
        }
    }

    private void tickHunt(long now) {
        if (target == null || !target.isAlive() || --retarget <= 0 || !isPrey(target) || target.distanceToSqr(this) > 48.0 * 48.0) {
            target = pickTarget();
            retarget = 40;
        }
        if (target == null) {
            this.getNavigation().stop();
            if (++idle > 1200) {   // nggak ada lagi yang bergerak: menggali kembali ke dalam tanah
                anim(ShazamAnim.HELION3_POUND, this.position());
                this.discard();
            }
            return;
        }
        idle = 0;
        this.setTarget(target);
        face(target);
        double d = Math.sqrt(this.distanceToSqr(target));
        boolean sight = this.hasLineOfSight(target);
        double reach = 3.2 + this.getBbWidth();
        if (now >= nextRoar && d < 20.0) {
            startRoar(now);
        } else if (d < reach && now >= nextSmash) {
            startSmash(now);
        } else if (sight && this.onGround() && now >= nextLeap && ((d > 9.0 && d < 26.0) || target.getY() - this.getY() > 4.0)) {
            startLeap(target, now);
        } else if (sight && this.onGround() && now >= nextCharge && d > 6.0 && d < 18.0 && Math.abs(target.getY() - this.getY()) < 3.0) {
            startCharge(target, now);
        } else {
            this.getNavigation().moveTo(target, 1.15);
        }
    }

    // ------------------------------------------------------------------ raungan

    private void startRoar(long now) {
        act(Action.ROAR);
        nextRoar = now + 380 + this.random.nextInt(200);
        this.getNavigation().stop();
        anim(ShazamAnim.HELION3_ROAR, this.position());
        sound(this.position(), ShazamSounds.HELION3_ROAR.get(), 4.0f, 0.95f + this.random.nextFloat() * 0.1f);
    }

    private void tickRoar() {
        this.getNavigation().stop();
        if (actionAge == ROAR_HIT) {
            roarBlast(1f);
        }
        if (actionAge >= ROAR_TICKS) {
            act(Action.IDLE);
        }
    }

    /** Raungan: yang dekat terlempar & pusing, proyektil di sekitarnya hancur. */
    private void roarBlast(float k) {
        Vec3 c = this.position();
        for (LivingEntity e : prey(c, ROAR_RADIUS)) {
            strike(e, ROAR_DAMAGE * k);
            push(e, c, 1.4 * k, 0.4 * k);
            e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 2));
            e.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 80, 0));
        }
        for (Projectile shot : this.level().getEntitiesOfClass(Projectile.class, this.getBoundingBox().inflate(ROAR_RADIUS),
                p -> p.getOwner() != this)) {
            shot.discard();
        }
    }

    // ------------------------------------------------------------------ lompatan & hantaman

    private void startLeap(LivingEntity t, long now) {
        act(Action.LEAP);
        nextLeap = now + 140 + this.random.nextInt(80);
        this.getNavigation().stop();
        from = this.position();
        Vec3 aim = t.position().add(t.getDeltaMovement().scale(8.0));
        BlockHitResult ground = this.level().clip(new ClipContext(aim.add(0, 1.0, 0), aim.subtract(0, 12.0, 0),
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
        to = ground.getType() == HitResult.Type.MISS ? aim : ground.getLocation();
        anim(ShazamAnim.HELION3_LEAP, to);
        sound(from, ShazamSounds.HELION3_STEP.get(), 2.5f, 0.7f);
    }

    private void tickLeap() {
        if (actionAge < LEAP_WINDUP) {
            this.getNavigation().stop();
            this.setDeltaMovement(0, this.getDeltaMovement().y, 0);
            return;
        }
        int k = actionAge - LEAP_WINDUP;
        if (k > LEAP_TICKS) {
            return;
        }
        this.setNoGravity(true);
        double u = k / (double) LEAP_TICKS;
        double height = 4.0 + from.distanceTo(to) * 0.25;
        Vec3 p = from.lerp(to, u).add(0, Math.sin(u * Math.PI) * height, 0);
        this.setDeltaMovement(p.subtract(this.position()));
        this.hurtMarked = true;
        this.fallDistance = 0f;
        if (k == LEAP_TICKS) {
            this.setNoGravity(false);
            this.setDeltaMovement(Vec3.ZERO);
            slam(this.position());
            staggerTicks = STAGGER_TICKS;
            act(Action.STAGGER);
        }
    }

    private void slam(Vec3 c) {
        anim(ShazamAnim.HELION3_SLAM, c);
        sound(c, ShazamSounds.HELION3_SLAM.get(), 4.0f, 1f);
        for (LivingEntity e : prey(c, SLAM_RADIUS)) {
            double d = Math.sqrt(e.distanceToSqr(c));
            float fall = d <= 2.5 ? 1f : (float) (2.5 / d);
            if (strike(e, SLAM_DAMAGE * fall)) {
                Vec3 a = away(c, e);
                e.push(a.x * 1.4 * fall, 0.2 + 0.9 * fall, a.z * 1.4 * fall);
                e.hurtMarked = true;
            }
        }
    }

    // ------------------------------------------------------------------ serudukan

    private void startCharge(LivingEntity t, long now) {
        act(Action.CHARGE);
        nextCharge = now + 160 + this.random.nextInt(80);
        this.getNavigation().stop();
        Vec3 d = new Vec3(t.getX() - this.getX(), 0, t.getZ() - this.getZ());
        dir = d.lengthSqr() < 1.0E-4 ? facing() : d.normalize();
        from = this.position();
        anim(ShazamAnim.HELION3_CHARGE, from.add(dir.scale(18.0)));
        sound(from, ShazamSounds.HELION3_CHARGE.get(), 3.5f, 1f);
    }

    private void tickCharge() {
        if (actionAge < CHARGE_WINDUP) {
            this.getNavigation().stop();
            this.setDeltaMovement(0, this.getDeltaMovement().y, 0);
            return;
        }
        int k = actionAge - CHARGE_WINDUP;
        if (k >= CHARGE_TICKS) {
            act(Action.IDLE);
            return;
        }
        this.setDeltaMovement(dir.x * 1.1, this.getDeltaMovement().y, dir.z * 1.1);
        this.hurtMarked = true;
        for (LivingEntity e : prey(this.position().add(dir.scale(0.8)), 2.2 + this.getBbWidth() * 0.5)) {
            if (hitThisAction.add(e.getUUID()) && strike(e, CHARGE_DAMAGE)) {
                e.push(dir.x * 2.4, 0.6, dir.z * 2.4);
                e.hurtMarked = true;
                Vec3 at = e.position().add(0, e.getBbHeight() * 0.6, 0);
                anim(ShazamAnim.HELION3_SMASH, at);
                sound(at, ShazamSounds.HELION3_SMASH.get(), 2.0f, 1f);
            }
        }
        if (k > 2 && this.horizontalCollision) {   // menabrak tembok: batu berhamburan, lalu terhuyung
            anim(ShazamAnim.HELION3_CRASH, this.position().add(dir.scale(1.2)).add(0, 1.2, 0));
            sound(this.position(), ShazamSounds.HELION3_SLAM.get(), 3.0f, 1.2f);
            staggerTicks = CRASH_STAGGER;
            act(Action.STAGGER);
        }
    }

    // ------------------------------------------------------------------ pukulan beruntun

    private void startSmash(long now) {
        act(Action.SMASH);
        nextSmash = now + 50 + this.random.nextInt(30);
        this.getNavigation().stop();
    }

    private void tickSmash() {
        this.getNavigation().stop();
        if (target != null && target.isAlive()) {
            face(target);
        }
        if (actionAge == SMASH_HIT1 || actionAge == SMASH_HIT2) {
            Vec3 front = this.position().add(facing().scale(1.4 + this.getBbWidth() * 0.5)).add(0, this.getBbHeight() * 0.45, 0);
            for (LivingEntity e : prey(front, 2.6)) {
                if (strike(e, SMASH_DAMAGE)) {
                    push(e, this.position(), 1.6, 0.45);
                }
            }
            anim(ShazamAnim.HELION3_SMASH, front);
            sound(front, ShazamSounds.HELION3_SMASH.get(), 2.4f, 0.9f + this.random.nextFloat() * 0.2f);
        }
        if (actionAge == SMASH_POUND) {   // kedua kepalan menghantam tanah
            Vec3 c = this.position();
            anim(ShazamAnim.HELION3_POUND, c);
            sound(c, ShazamSounds.HELION3_SLAM.get(), 3.0f, 1.15f);
            for (LivingEntity e : prey(c, POUND_RADIUS)) {
                if (strike(e, POUND_DAMAGE)) {
                    push(e, c, 1.2, 0.7);
                }
            }
        }
        if (actionAge >= SMASH_TICKS) {
            act(Action.IDLE);
        }
    }

    // ------------------------------------------------------------------ damage, adaptasi, nyawa

    /** Juara (pemain yang berubah wujud atau rival) di balik serangan ini. */
    static ShazamForm championOf(Entity e) {
        if (e instanceof ServerPlayer p && ShazamPowers.isTransformed(p)) {
            return ShazamPowers.data(p).champion();
        }
        if (e instanceof RivalChampion r && r.isTransformedRival()) {
            return r.form();
        }
        return null;
    }

    /** Jenis serangan: juara surya = cahaya, Helion-6 = Cryon, juara sihir = petir & sihir, lalu menurut jenis damage-nya. */
    public static Kind kindOf(DamageSource source) {
        if (source.is(DamageTypes.FREEZE)) {
            return Kind.COLD;
        }
        Entity attacker = source.getEntity();
        ShazamForm form = championOf(attacker);
        if (form != null) {
            return switch (form) {
                case LINTANG -> Kind.LIGHT;
                case HELION -> Kind.CRYON;
                case HELION3 -> Kind.MELEE;   // 0.49 Subjek Tiga lain: cakar & otot
                default -> Kind.MAGIC;
            };
        }
        if (source.is(DamageTypeTags.IS_FIRE)) {
            return Kind.LIGHT;
        }
        if (source.is(DamageTypeTags.IS_LIGHTNING) || source.is(DamageTypes.MAGIC) || source.is(DamageTypes.INDIRECT_MAGIC)
                || source.is(DamageTypes.WITHER)) {
            return Kind.MAGIC;
        }
        if (source.is(DamageTypeTags.IS_EXPLOSION)) {
            return Kind.BLAST;
        }
        if (source.is(DamageTypeTags.IS_PROJECTILE)) {
            return Kind.RANGED;
        }
        return attacker != null ? Kind.MELEE : null;
    }

    public void onIncomingDamage(LivingIncomingDamageEvent event) {
        DamageSource source = event.getSource();
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return;
        }
        if (action == Action.EMERGE || action == Action.FALL || action == Action.REVIVE || action == Action.DEATH
                || source.is(DamageTypeTags.IS_FALL) || source.is(DamageTypes.IN_WALL) || source.is(DamageTypes.DROWN)
                || source.is(DamageTypes.CRAMMING)) {
            event.setCanceled(true);
            return;
        }
        Kind kind = kindOf(source);
        if (kind == null) {
            return;
        }
        lastKind = kind;
        long now = this.level().getGameTime();
        int i = kind.ordinal();
        if ((immune & (1 << i)) != 0) {   // kebal total
            event.setCanceled(true);
            if (kind == Kind.CRYON) {
                absorb(event.getAmount(), now);
            } else if (now >= nextImmuneFx) {
                nextImmuneFx = now + 8;
                anim(ShazamAnim.HELION3_IMMUNE, new Vec3(i, 0, 0));
            }
            return;
        }
        float k = 1f - adapt[i];
        if (kind == Kind.MELEE || kind == Kind.RANGED) {
            k *= BIO_ARMOR;
        } else if (kind == Kind.BLAST) {
            k *= BLAST_ARMOR;
        }
        event.setAmount(event.getAmount() * k);
        float before = adapt[i];
        adapt[i] = Math.min(ADAPT_MAX, adapt[i] + ADAPT_STEP);
        if (before < ADAPT_MAX && adapt[i] >= ADAPT_MAX) {
            adapted(kind, false);
        }
        Entity attacker = source.getEntity();
        if (attacker instanceof LivingEntity att && source.getDirectEntity() == attacker && att.distanceToSqr(this) < 25.0
                && isPrey(att)) {
            // duri sel mati menusuk penyerang jarak dekat (lewat reflect: tusukan duri nggak memicu duri Subjek Tiga
            // yang dimainkan pemain, yang kalau dibiarkan bakal saling menusuk balik tanpa akhir)
            Helion3Skills.reflect(att, this.damageSources().thorns(this), THORNS);
        }
    }

    /** Kebal Cryon: radiasinya diserap jadi darah & cakar yang makin kuat. */
    private void absorb(float amount, long now) {
        this.heal(Math.min(amount * ABSORB_HEAL, 30f));
        if (claws < CLAW_MAX) {
            claws++;
            this.entityData.set(DATA_CLAWS, claws);
        }
        if (now >= nextAbsorbFx) {
            nextAbsorbFx = now + 10;
            anim(ShazamAnim.HELION3_ABSORB, chest());
            sound(chest(), ShazamSounds.HELION3_ABSORB.get(), 1.6f, 1f);
        }
    }

    private void adapted(Kind kind, boolean total) {
        anim(ShazamAnim.HELION3_ADAPT, new Vec3(kind.ordinal(), total ? 1 : 0, 0));
        sound(this.position(), ShazamSounds.HELION3_ADAPT.get(), 2.6f, total ? 0.8f : 1f);
        tell(Component.translatable(total ? "message.shazammod.helion3_immune" : "message.shazammod.helion3_adapt", kindName(kind))
                .withStyle(ChatFormatting.LIGHT_PURPLE));
        ShazamForm ally = kind == Kind.LIGHT || kind == Kind.COLD ? ShazamForm.LINTANG : kind == Kind.CRYON ? ShazamForm.HELION : null;
        if (ally != null) {
            RivalChampion.notifyAllies(this, ally, 5, true);
        }
        updateBar();
    }

    /** Damage yang bakal menghabisinya: dibatalkan, lalu tumbang & bangkit lagi (atau hancur di nyawa terakhir). */
    public void onDamagePre(LivingDamageEvent.Pre event) {
        if (event.getContainer().getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return;
        }
        if (untouchable()) {
            event.getContainer().setNewDamage(0f);
            return;
        }
        float toHealth = event.getContainer().getNewDamage() - this.getAbsorptionAmount();
        if (toHealth >= this.getHealth()) {
            event.getContainer().setNewDamage(0f);
            Kind killer = kindOf(event.getContainer().getSource());
            if (killer == null) {
                killer = lastKind;
            }
            if (lives > 1) {
                fall(killer);
            } else {
                finalDeath();
            }
        }
    }

    private void fall(Kind killer) {
        lives--;
        killKind = killer;
        if (killer != null) {
            immune |= 1 << killer.ordinal();
        }
        Arrays.fill(adapt, 0f);
        this.entityData.set(DATA_LIVES, lives);
        this.entityData.set(DATA_IMMUNE, immune);
        this.setNoGravity(false);
        this.getNavigation().stop();
        this.setHealth(Math.max(1f, this.getHealth()));
        act(Action.FALL);
        anim(ShazamAnim.HELION3_FALL, this.position());
        sound(this.position(), ShazamSounds.HELION3_FALL.get(), 3.0f, 1f);
        updateBar();
    }

    private void tickFall() {
        this.getNavigation().stop();
        if (actionAge >= FALL_TICKS) {   // kepompong sel mati menutupi tubuhnya, jantungnya berdetak lagi
            act(Action.REVIVE);
            anim(ShazamAnim.HELION3_REVIVE, this.position());
            sound(this.position(), ShazamSounds.HELION3_REVIVE.get(), 3.5f, 1f);
            RivalChampion.notifyAllies(this, null, 6, true);
        }
    }

    private void tickRevive(long now) {
        this.getNavigation().stop();
        if (actionAge == REVIVE_TICKS - 8) {
            roarBlast(0.8f);
        }
        if (actionAge >= REVIVE_TICKS) {
            this.setHealth(this.getMaxHealth());
            act(Action.IDLE);
            nextRoar = now + 200;
            nextLeap = now + 40;
            nextCharge = now + 60;
            if (killKind != null) {
                adapted(killKind, true);
                tell(Component.translatable("message.shazammod.helion3_revive", kindName(killKind), lives)
                        .withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD));
            }
        }
    }

    private void finalDeath() {
        lives = 0;
        this.entityData.set(DATA_LIVES, 0);
        this.setNoGravity(false);
        this.getNavigation().stop();
        act(Action.DEATH);
        anim(ShazamAnim.HELION3_DEATH, this.position());
        sound(this.position(), ShazamSounds.HELION3_DEATH.get(), 4.0f, 1f);
        updateBar();
    }

    private void tickDeath() {
        this.getNavigation().stop();
        this.setDeltaMovement(0, Math.min(this.getDeltaMovement().y, 0), 0);
        if (actionAge >= DEATH_TICKS) {
            dropRewards();
            tell(Component.translatable("message.shazammod.helion3_dead").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
            this.discard();
        }
    }

    private void dropRewards() {
        if (!(this.level() instanceof ServerLevel level)) {
            return;
        }
        Vec3 pos = this.position();
        ExperienceOrb.award(level, pos, XP);
        // 0.49: Sel Subjek Tiga (membuka wujud Subjek Tiga yang bisa dimainkan) selalu jatuh
        ItemStack[] loot = {new ItemStack(Items.NETHER_STAR), new ItemStack(HelionItems.CELL.get()),
                new ItemStack(HelionItems.SERUM.get()),
                new ItemStack(LintangItems.STAR_CRYSTAL.get()), new ItemStack(LintangItems.KELAM_SHARD.get(), 6),
                new ItemStack(Items.DIAMOND, 6)};
        for (ItemStack stack : loot) {
            ItemEntity item = new ItemEntity(level, pos.x, pos.y + 0.8, pos.z, stack);
            item.setDefaultPickUpDelay();
            item.setGlowingTag(true);
            level.addFreshEntity(item);
        }
    }

    // ------------------------------------------------------------------ bos bar & siklus hidup

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bar.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bar.removePlayer(player);
    }

    @Override
    public void remove(Entity.RemovalReason reason) {
        super.remove(reason);
        bar.removeAllPlayers();
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }
}
