# Mod Shazam untuk Minecraft 1.21.1 (NeoForge)

Versi 0.12.0. Isinya:
- Transformasi SHAZAM beranimasi, enam kekuatan S-H-A-Z-A-M, dan Energi Petir.
- Enam skill yang masing-masing punya gerakan dan efek sendiri.
- Terbang berbasis momentum dengan fisika dunia nyata (hambatan udara, belokan menikung, gravitasi saat menukik) ala Create: Lanterns: sonic boom, barrel roll, hero landing, dan kamera menikung.
- Kekuatan seperti di komik: darah 100, tahan banting, pukulan 20, dan Energi Petir 1000.
- Hood dan jubah 3D berfisika serta lambang 3D yang berkilau saat berubah (skin tetap skin aslimu), plus kostum armor 4 bagian yang bisa di-craft.
- Enam penjaga kuil beserta totemnya.

## Yang dibutuhkan

- **JDK 21**, misalnya Eclipse Temurin 21 atau Microsoft Build of OpenJDK 21.
- **Internet** untuk build pertama. Gradle, NeoForge, dan Minecraft diunduh otomatis, totalnya beberapa ratus MB.

## Bikin file .jar

**Windows:** buka folder ini, ketik `cmd` di address bar File Explorer, tekan Enter, lalu jalankan:

    gradlew build

**Mac/Linux:**

    chmod +x gradlew
    ./gradlew build

Hasilnya ada di `build/libs/shazammod-0.12.0.jar`. Taruh di folder `.minecraft/mods`, dengan NeoForge 21.1.228 atau yang lebih baru untuk Minecraft 1.21.1.

Mau ngetes tanpa install? Jalankan `gradlew runClient`.

## Kontrol

Semua tombol bisa diganti di pengaturan Controls, kategori Shazam.

| Tombol | Skill | Gerakan & efek |
|---|---|---|
| G (atau ketik `shazam`) | Transformasi | Roh enam dewa bangkit dan mengelilingimu, lalu kepalan diangkat ke langit. Dunia melambat (slow motion) dan petir sihir turun pelan dari langit selama 2 detik, sementara roh-roh melesat menyatu ke kepalan. Petir mengenai kepalan, layar berkilat, dan kostum terbentuk masih dalam slow motion; begitu selesai, dunia kembali normal. Badan jadi 10% lebih besar. |
| Z | S - Mata Solomon | Dua jari ke pelipis, huruf-huruf sihir terserap ke kepala, dan gelombang cahaya menyebar. Semua musuh dalam 48 blok bersinar dan menerima +25% damage selama 10 detik. |
| X | H - Tepukan Hercules | Tangan dibentang lebar lalu ditepuk. Gelombang kejut berbentuk kerucut menghempas musuh di depan. |
| C | A - Hantaman Atlas | Di udara: menukik dengan kedua kepalan di atas kepala. Di tanah: kepalan diangkat lalu dihantamkan. Tanah retak melingkar dan musuh terlempar ke atas. |
| V | Z - Petir Zeus | Tangan menggapai langit lalu menunjuk sasaran, dan petir menyambar titik itu. |
| B | A - Kulit Achilles | Membungkuk mengumpulkan tenaga lalu meraung. Selama 6 detik badan diselubungi energi emas dan hampir kebal, sementara musuh di sekitar terdorong dan melemah. |
| N | M - Kilat Mercury | Menerjang secepat kilat dengan bayangan berjejak. Musuh di jalur terlempar ke samping. |
| R | Zeus Rage | Membungkuk mengepalkan tinju, lalu meraung ke langit: mata menyala putih, petir menyambar di sekeliling dan menghantam musuh dalam 5 blok. Selama 12 detik pukulan +50% dan petirnya merambat ke 2 musuh terdekat, tiap detik petir memburu 2 musuh dalam 12 blok, dan lari lebih cepat. Biaya 150 energi, cooldown 60 detik. |
| H | Hood naik/turun | Kedua tangan meraih ke belakang kepala lalu menarik hood ke depan sampai dahi, atau memegang tepi hood di dahi lalu mendorongnya ke belakang. Statusnya tersimpan dan terlihat oleh pemain lain. |

## Terbang

| Kontrol | Gerakan |
|---|---|
| Spasi 2x | Lepas landas: jongkok sebentar, lalu melesat ke atas. Di udara, tekan lagi 2x untuk berhenti terbang. |
| W | Terbang ke arah pandangan (±28 blok/detik). |
| W + sprint (ditahan) | Makin lama makin ngebut sampai ±100 blok/detik. Saat menembus kecepatan tertentu muncul sonic boom: cincin uap, dentuman, dan musuh di sekitar terhempas. |
| S | Mengerem dengan hambatan udara besar (dari 100 blok/detik ±0,8 detik). Badan menegak, tangan dan kaki terayun ke depan. |
| Spasi / Shift | Naik / turun. |
| A / D | Geser ke samping (hanya di kecepatan rendah). |
| A 2x / D 2x | Barrel roll menghindar ke kiri/kanan. |

### Fisika terbang

Geraknya mengikuti fisika dunia nyata:

- **Dorongan melawan hambatan udara:** makin kencang, makin berat menambah kecepatan. Dari melayang ke 28 blok/detik butuh ±0,5 detik; dengan sprint, sonic boom di ±1,5 detik dan kecepatan puncak di ±3 detik.
- **Belokan dibatasi gaya menyamping:** makin kencang, makin lebar belokannya, dan kecepatan nggak hilang saat berbelok. Putar balik di 28 blok/detik selebar ±10 blok (±0,5 detik); di 100 blok/detik selebar ±125 blok (±2 detik), seperti pesawat jet.
- **Gravitasi:** menukik menambah kecepatan (W sambil menukik lurus sampai ±49 blok/detik), menanjak menguranginya (±23 blok/detik).
- **Meluncur:** lepas W saat kencang, Shazam meluncur dan melambat karena hambatan udara (kecepatan tinggi cepat berkurang, kecepatan rendah meluncur jauh), lalu berhenti dan melayang.

### Pose terbang

Pose badan juga dihitung dari gaya yang bekerja, lalu dihaluskan dengan pegas teredam (ada sedikit ayunan alami):

- **Melayang:** badan condong searah gaya yang dibutuhkan, seperti helikopter. Mulai maju berarti condong ke depan, bergeser berarti miring ke samping, mundur berarti condong ke belakang. Naik-turun pelan tetap tegak.
- **Meluncur:** badan sejajar lintasan dengan "hidung" sedikit naik (sudut serang), yang makin kecil saat makin kencang. Satu kepalan di depan; saat super cepat kedua kepalan di depan seperti peluru. Badan tegak saat menanjak dan kepala di bawah saat menukik.
- **Menikung:** badan miring ke dalam belokan seperti pesawat, dengan sudut sebesar arctan(percepatan menyamping ÷ gravitasi), sampai ±70° di belokan tajam. Kamera ikut miring setengahnya.
- **Arah badan:** badan menghadap arah lintasan, bukan arah kamera, jadi saat berbelok kencang badan menyusul pelan-pelan. Kepala tetap memandang ke arah kamera.
- **Tangan dan kaki:** lembam. Saat dipercepat kaki tertinggal ke belakang, saat mengerem terayun ke depan, dan makin kencang makin bergetar diterpa angin.
- **Menjelang tanah:** sekitar 0,8 detik sebelum menyentuh tanah sambil turun, badan menegak dan kaki maju untuk mendarat.

Pandangan juga melebar sesuai kecepatan. Angka-angka fisika gerak ada di bagian atas `FlightModel.java`, dan angka pose di `FlightPose.java`.

Mendarat atau jatuh dengan kencang memicu hero landing: satu lutut turun, kepalan menghantam tanah, dan gelombang kejut melukai musuh di sekitar. Menabrak dinding dengan kencang juga menimbulkan gelombang kejut.

## Kekuatan saat jadi Shazam

| Bagian | Nilai |
|---|---|
| Darah | 100 (bar darah sendiri menggantikan baris hati), pulih 2 per detik |
| Ketahanan | damage yang diterima tinggal 40%, ditambah armor +10 dan toughness +6 |
| Kebal | jatuh, petir, api, lava, tenggelam (nggak perlu napas), beku, lapar, kaktus, racun, wither |
| Kelemahan | sihir (+50% damage) |
| Pukulan tangan kosong | 20 (critical 30), musuh terpental jauh |
| Lain-lain | badan 10% lebih besar, naik blok tanpa melompat, jangkauan +1, menghancurkan blok 4x lebih cepat |
| Energi Petir | 1000, berkurang 1 per detik saat jadi Shazam (±16 menit) dan terisi 5 per detik sebagai manusia; badai petir mempercepat |

## Tampilan saat jadi Shazam

Skin kamu tetap skin aslinya. Yang muncul saat berubah adalah hood, jubah, dan lambang 3D.

- **Roh enam dewa:** begitu SHAZAM diucapkan, roh Solomon, Hercules, Atlas, Zeus, Achilles, dan Mercury bangkit dari tanah satu per satu dengan denting yang makin tinggi. Tiap roh bercahaya dengan warna totem dewanya, dan totem itu berputar di atas kepalanya. Mereka melayang mengelilingimu selama ±1,5 detik sementara huruf-huruf sihir mengalir dari lingkaran di tanah, lalu melesat ke kepalan yang terangkat dan lenyap jadi semburan cahaya enam warna tepat saat petir menyambar. Roh-roh ini digambar di dunia, jadi tetap kelihatan dari sudut pandang orang pertama.
- **Saat berubah:** kepalan menembus langit, lalu petir sihir menyambar dan Shazam terangkat melayang. Kilau emas menyapu badan dari dada, lengan, kepala, sampai kaki. Di tengah kilau itu lambang muncul memantul di dada dengan kilatan terang. Jubah terbentang ke belakang lalu jatuh ke punggung, dan hood muncul di belakang leher lalu tertarik menutupi kepala.
- **Saat kembali jadi manusia:** lambang mengecil hilang, dan jubah serta hood lenyap jadi percikan cahaya.

### Slow motion saat berubah

Begitu kepalan terangkat ke langit, dunia melambat 4× dan petir sihir turun dari langit dengan ujung yang bercahaya dan memercik, tepat 2 detik sampai mengenai kepalan. Roh enam dewa melesat menyatu ke kepalan selama petir turun. Setelah petir mengenai, dunia tetap 2× lebih lambat selama kostum terbentuk (kilau emas, lambang, jubah, sampai hood tertarik ke kepala), lalu kembali normal pelan-pelan. Semuanya ikut melambat: gerakan, partikel, jubah, dan nada suara.

- Slow motion memperlambat seluruh dunia (sama seperti `/tick rate`), jadi hanya jalan kalau kamu sendirian di server. Di server dengan pemain lain, transformasinya tetap jalan dengan kecepatan normal.
- Kalau sebelumnya kamu memakai `/tick rate` sendiri, nilai itu yang dikembalikan. Kalau transformasi batal atau kamu keluar di tengah jalan, kecepatan langsung kembali normal.
- Kalau sedang di sudut pandang orang pertama, kamera pindah ke depan (orang ketiga, menghadap wajah) selama transformasi supaya semuanya terlihat jelas, lalu kembali seperti semula.
- Kecepatan dan lamanya bisa diatur di bagian atas `ShazamSlowMo.java`. Slow motion bisa dimatikan lewat `ENABLED` di file itu, dan kamera sinematik lewat `ENABLED` di `ShazamCinematic.java`.

### Jubah dan hood (3D, berfisika)

Keduanya kain 3D yang fisikanya dihitung setiap frame dengan langkah kecil tetap (120 kali per detik), jadi gerakannya halus di FPS berapa pun. Saat digambar, permukaan kain dihaluskan dengan kurva sehingga lipatannya melengkung, bukan bersudut.

- **Jubah:** bagian atasnya menempel di bahu dan ditarik dari situ seperti kain sungguhan, tanpa pernah molor dan tanpa menembus badan, termasuk saat terbang rebah. Yang menggerakkannya:
  - Gravitasi.
  - Hambatan udara yang mendorong permukaan kain sesuai sudutnya. Bagian dekat punggung terlindung dari angin saat bergerak maju.
  - Kibaran seperti bendera, yang makin cepat dan kuat seiring laju.

  Hasilnya, saat diam jubah menggantung sampai dekat tanah. Saat jalan terangkat sekitar 35°, saat sprint sekitar 45°, dan saat terbang berkibar hampir mendatar (80–90°). Kalau diayun lalu dilepas, jubah jatuh, berayun balik sedikit, lalu tenang dalam ±2,5 detik. Di dalam air jubah melayang pelan.
- **Angin sekitar:** di luar ruangan, jubah bergoyang pelan tertiup angin yang arahnya berubah-ubah dan berembus. Angin lebih kencang saat hujan dan badai, dan tidak ada di dalam ruangan, gua, atau air.
- **Hood:** pinggirannya mengikuti wajah, sisanya kain yang ikut berayun saat menoleh, menunduk, atau terbang. Hood tetap menjaga bentuknya dan nggak pernah menutupi wajah.
- Tekan **H** untuk memakai atau melepas hood dengan tangan. Saat memakai, kedua tangan meraih ke belakang kepala, memegang tepi hood, lalu menariknya ke depan lewat atas kepala sampai dahi. Saat melepas, tangan memegang tepi hood di dahi lalu mendorongnya ke belakang sampai hood menggantung di belakang leher. Hood baru bergerak saat tangan sudah memegangnya, dan terdengar gesekan kain. Statusnya tersimpan dan terlihat oleh pemain lain.

**Hiasan emas:** jubah dan hood berwarna putih dengan list emas di tepinya: tepi kiri, kanan, dan bawah jubah, serta sekeliling bukaan hood (pinggiran wajah sampai tepi bawahnya). List emas itu timbul dari kain putih di kedua sisi, dengan tepi luar yang berkilau dan tepi dalam yang berbayang, dan sedikit menyala di tempat gelap. Karena menempel di titik-titik kain, list emas ikut berkibar bersama jubah.

**Lambang punggung:** di tengah punggung jubah ada lambang 3D yang timbul dari kain dan ikut melengkung saat jubah berkibar. Lambang ini terang sendiri, dengan cahaya berdenyut, kilatan putih yang menyapu, dan pendar emas di kain sekitarnya. Gambarnya sama dengan lambang dada, kecuali kamu menaruh gambar khusus di `.../textures/entity/shazam_cape_emblem.png` (aturannya sama dengan lambang dada).

Lebar dan ketebalan list emas, serta ukuran, posisi, dan ketebalan lambang punggung, bisa diatur di bagian atas `CapeDecor.java`.

Jubah dan hood juga muncul saat memakai Kostum Shazam (armor dada), walaupun tidak sedang jadi Shazam.

Warna dan motif keduanya ada di `.../textures/entity/shazam_cape_cloth.png`. Gambar itu dibentangkan ke seluruh jubah (kiri-kanan gambar = tepi kiri-kanan jubah, atas = bahu, bawah = ujung), dan bagian seperempat atasnya juga dipakai untuk hood. Ukuran dan fisikanya (berat kain, hambatan udara, kibaran, kehalusan gambar) bisa diatur di bagian atas `ShazamCape.java`. Angin sekitar diatur di `CapeAir.java`, dan bentuk hood di `HoodShape.java`.

### Lambang 3D di dada

Bentuk dan warna lambang diambil dari `.../textures/entity/shazam_emblem.png`. Setiap piksel yang tidak transparan jadi balok kecil yang timbul dari dada, dengan warna piksel itu. Lambang menyala sendiri walaupun di tempat gelap, dan berkilau:

- cahaya emas berdenyut di sekelilingnya,
- kilatan putih yang menyapu permukaannya setiap ±2,5 detik,
- kilat terang saat lambang pertama muncul,
- percikan cahaya kecil yang sesekali keluar.

Lambang bawaannya bintang kilau empat sudut. Untuk memakai desain sendiri, timpa file itu dengan PNG berlatar transparan, maksimal 64×64 piksel (16×16 sampai 32×32 sudah cukup). Lebarnya otomatis disesuaikan ke dada, jadi gambar yang lebih tinggi daripada lebarnya akan memanjang ke bawah. Ukuran, posisi, dan ketebalannya bisa diatur di bagian atas `ShazamEmblemLayer.java`. Setelah mengganti gambar, build ulang (atau tekan F3+T saat `runClient`).

### Mata putih Zeus Rage

Saat Zeus Rage menyala, matamu jadi putih terang dengan pendar biru-putih, kilau mendatar, dan kilatan listrik kecil di sekitarnya, lalu padam pelan saat amarahnya habis. Listrik juga menjalar di badan selama Zeus Rage aktif.

Letak mata diatur untuk skin standar: baris ke-4 wajah, kolom 1-2 dan 5-6 (wajah 8×8 dihitung dari kiri-atas seperti terlihat dari depan). Kalau mata di skin-mu ada di baris atau kolom lain, ubah `EYE_ROW`, `EYE_HEIGHT`, dan `EYES` di bagian atas `ShazamEyesLayer.java`.

## Kostum armor (bisa di-craft)

Empat bagian, pertahanannya setara netherite, dan diperbaiki pakai emas. Teksturnya ada di `.../textures/models/armor/shazam_suit_layer_1.png` dan `_layer_2.png`.

| Bagian | Resep (G = emas batangan, R = wol merah) |
|---|---|
| Kepala Kostum Shazam | `KKK / BHB / _L_`: K = wol hitam, B = pewarna cokelat, H = helm berlian, L = penangkal petir |
| Kostum Shazam | `RLR / GCG / R_R`: L = penangkal petir, C = baju zirah berlian |
| Celana Kostum Shazam | `GYG / RLR / R_R`: Y = balok emas, L = celana berlian |
| Sepatu Kostum Shazam | `G_G / RDR / G_G`: D = sepatu berlian |

(`_` = kotak kosong.) Kostum ini nggak memberi kekuatan; kekuatan Shazam tetap datang dari mengucapkan SHAZAM.

## Perintah tes

Perintah ini butuh cheat aktif.

- `/shazam unlock` dan `/shazam lock`: membuka atau mencabut kekuatan Shazam.
- `/shazam energy <0-1000>`: mengatur Energi Petir.
- `/shazam summon <solomon|hercules|atlas|zeus|achilles|mercury>`: memunculkan penjaga.

## Kalau build gagal

- **`Plugin [id: 'net.neoforged.moddev', version: '2.0.+'] was not found`:** ganti `2.0.+` di `build.gradle` dengan versi ModDevGradle yang tertulis di MDK NeoForge 1.21.1 resmi.
- **Error soal versi Java:** pastikan `JAVA_HOME` mengarah ke JDK 21.
- **Crash saat game dibuka dengan pesan `Mixin`:** salin pesan error-nya dari `logs/latest.log` untuk diperbaiki.

## Soal gradle-wrapper.jar

`gradle/wrapper/gradle-wrapper.jar` adalah pengganti ringkas untuk wrapper resmi Gradle. Sumbernya ada di `gradle/wrapper/GradleWrapperMain.java`. Cara kerjanya: mengunduh Gradle 8.14.3 sekali ke `~/.gradle/wrapper/dists`, lalu menjalankannya.

Kalau mau memakai wrapper resmi, ada dua cara:
- Kalau Gradle sudah terpasang, jalankan `gradle wrapper --gradle-version 8.14.3` di folder ini.
- Salin folder `gradle/` dan file `gradlew*` dari MDK resmi.
