package com.shazammod;

import java.util.Locale;

import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.ServerChatEvent;
import net.neoforged.neoforge.event.entity.living.LivingExperienceDropEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/** Menyambungkan event game ke logika di ShazamPowers. */
@EventBusSubscriber(modid = ShazamMod.MODID)
public final class ShazamEvents {
    private ShazamEvents() {}

    @SubscribeEvent
    public static void onChat(ServerChatEvent event) {
        // "shazam", "Shazam!", "SHAZAM!!!" semuanya dihitung
        String word = event.getRawText().toLowerCase(Locale.ROOT).replaceAll("[^a-z]", "");
        if (word.equals("shazam")) {
            ServerPlayer player = event.getPlayer();
            player.server.execute(() -> ShazamPowers.onSayShazam(player));
        }
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        ShazamSlowMo.tick(event.getServer());
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        ShazamSlowMo.end(event.getServer());
    }

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            ShazamPowers.tick(player);
        }
    }

    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        ShazamPowers.onIncomingDamage(event);
    }

    @SubscribeEvent
    public static void onExperienceDrop(LivingExperienceDropEvent event) {
        ShazamPowers.onExperienceDrop(event);
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            ShazamPowers.onLogin(player);
        }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            ShazamPowers.onRespawn(player);
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            ShazamPowers.onLogout(player);
        }
    }

    /** Pemain lain baru kelihatan: kabari dia kalau pemain ini sedang jadi Shazam. */
    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking event) {
        if (event.getTarget() instanceof ServerPlayer target && event.getEntity() instanceof ServerPlayer viewer
                && (ShazamPowers.isTransformed(target) || ShazamPowers.data(target).hoodUp())) {
            ShazamNetwork.sendStateTo(target, viewer);
        }
    }

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        ShazamCommands.register(event.getDispatcher());
    }
}
