package com.shazammod;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

/**
 * Petir sihir Shazam: cuma tampilan (petir emas tebal bercabang). Damage-nya dihitung terpisah.
 * Kalau descent > 0, petir turun pelan dari langit dulu selama descent tick, baru menyambar penuh.
 */
public class MagicBolt extends Entity {
    public static final int LIFETIME = 12;
    private static final EntityDataAccessor<Float> DATA_SIZE =
            SynchedEntityData.defineId(MagicBolt.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Integer> DATA_DESCENT =
            SynchedEntityData.defineId(MagicBolt.class, EntityDataSerializers.INT);
    private int age;

    public MagicBolt(EntityType<? extends MagicBolt> type, Level level) {
        super(type, level);
        this.noCulling = true;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(DATA_SIZE, 1.0f);
        builder.define(DATA_DESCENT, 0);
    }

    public void setBoltSize(float size) {
        this.entityData.set(DATA_SIZE, size);
    }

    public float boltSize() {
        return this.entityData.get(DATA_SIZE);
    }

    public void setDescent(int ticks) {
        this.entityData.set(DATA_DESCENT, ticks);
    }

    /** Lama petir turun dari langit sebelum menyambar (tick), 0 = langsung menyambar. */
    public int descent() {
        return this.entityData.get(DATA_DESCENT);
    }

    public int age() {
        return age;
    }

    @Override
    public void tick() {
        super.tick();
        age++;
        int strikeAge = age - descent();
        if (this.level().isClientSide) {
            if (strikeAge >= 0 && strikeAge <= 3) {
                this.level().setSkyFlashTime(2); // langit berkilat saat menyambar
            }
        } else if (strikeAge > LIFETIME) {
            this.discard();
        }
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distance) {
        return distance < 256.0 * 256.0;
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }
}
