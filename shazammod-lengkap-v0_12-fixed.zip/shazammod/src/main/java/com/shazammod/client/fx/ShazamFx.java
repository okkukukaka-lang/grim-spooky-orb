package com.shazammod.client.fx;

import java.util.ArrayList;
import java.util.List;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamPowers;
import com.shazammod.client.anim.ShazamPoses;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * Efek visual tiap skill: partikel yang muncul bertahap (gelombang, cincin debu),
 * guncangan kamera, dan kilatan layar. Dipicu oleh animasi yang dikirim server.
 */
public final class ShazamFx {
    private ShazamFx() {}

    @FunctionalInterface
    private interface Effect {
        void tick(ClientLevel level, int t);
    }

    private static final class Running {
        final int delay;
        final int duration;
        final Effect effect;
        int age;

        Running(int delay, int duration, Effect effect) {
            this.delay = delay;
            this.duration = duration;
            this.effect = effect;
        }
    }

    private static final List<Running> RUNNING = new ArrayList<>();

    private static void schedule(int delay, int duration, Effect effect) {
        RUNNING.add(new Running(delay, duration, effect));
    }

    public static void clear() {
        RUNNING.clear();
    }

    public static void tick(ClientLevel level) {
        for (Running running : new ArrayList<>(RUNNING)) {
            int t = running.age - running.delay;
            if (t >= 0) {
                running.effect.tick(level, t);
            }
            running.age++;
        }
        RUNNING.removeIf(running -> running.age - running.delay >= running.duration);
    }

    public static void onAnim(AbstractClientPlayer caster, ShazamAnim anim, Vec3 pos) {
        boolean self = caster == Minecraft.getInstance().player;
        switch (anim) {
            case TRANSFORM -> {
                // 0-18: tenaga terkumpul: gemuruh, percikan berputar naik, debu berpusar di kaki
                schedule(0, 1, (level, t) -> level.playLocalSound(caster.getX(), caster.getY(), caster.getZ(),
                        SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.WEATHER, 0.8f, slowPitch(level, 0.5f), false));
                schedule(0, ShazamAnim.TRANSFORM_STRIKE, (level, t) -> {
                    chargeSparks(level, caster, t);
                    if (self && t % 2 == 0) {
                        CameraShake.add(0.05f);
                    }
                });
                // 8-18: petir turun pelan dari langit (slow motion); listrik berkumpul di kepalan
                schedule(ShazamAnim.TRANSFORM_WINDUP, ShazamAnim.BOLT_DESCENT, (level, t) -> descentCharge(level, caster, t));
                // 18: petir sihir mengenai kepalan
                schedule(ShazamAnim.TRANSFORM_STRIKE, 1, (level, t) -> {
                    Vec3 c = caster.position();
                    smokeBurst(level, c, 90, 0.6);
                    for (int i = 0; i < 3; i++) {
                        level.addParticle(ParticleTypes.FLASH, c.x, c.y + 0.5 + i * 0.6, c.z, 0, 0, 0);
                    }
                    sparks(level, c.add(0, 1.0, 0), 60);
                    shakeAround(c, 1.0f, 32);
                    if (self) {
                        ScreenFlash.flash(1.0f);
                    }
                });
                // gelombang kejut melebar di tanah, listrik merambat di badan, debu saat mendarat
                schedule(ShazamAnim.TRANSFORM_STRIKE, 14, (level, t) -> shockRing(level, caster.position(), 0.8 + t * 0.7));
                schedule(ShazamAnim.TRANSFORM_STRIKE, 18, (level, t) -> bodyArcs(level, caster));
                schedule(ShazamAnim.TRANSFORM_STRIKE + 25, 1, (level, t) -> landingPuff(level, caster.position()));
            }
            case REVERT -> schedule(ShazamAnim.REVERT_WINDUP, 1, (level, t) -> {
                Vec3 c = caster.position();
                smokeBurst(level, c, 26, 0.3);
                level.addParticle(ParticleTypes.FLASH, c.x, c.y + 1.0, c.z, 0, 0, 0);
                shakeAround(c, 0.35f, 16);
                if (self) {
                    ScreenFlash.flash(0.55f);
                }
            });
            case SOLOMON_SIGHT -> {
                // Huruf-huruf sihir terserap ke kepala, lalu gelombang cahaya menyebar di tanah
                schedule(ShazamAnim.CAST_WINDUP, 1, (level, t) -> {
                    wisdomGlyphs(level, caster.getEyePosition(), 70);
                    if (self) {
                        CameraShake.add(0.15f);
                    }
                });
                schedule(ShazamAnim.CAST_WINDUP, 12, (level, t) ->
                        ring(level, caster.position().add(0, 0.1, 0), 1.0 + t, 28, ParticleTypes.END_ROD, 0.02));
            }
            case HERCULES_CLAP -> {
                float yaw = caster.getYRot();
                schedule(ShazamAnim.CAST_WINDUP, 1, (level, t) -> {
                    Vec3 hands = caster.getEyePosition().add(caster.getViewVector(1f).scale(0.8)).subtract(0, 0.4, 0);
                    level.addParticle(ParticleTypes.SWEEP_ATTACK, hands.x, hands.y, hands.z, 0, 0, 0);
                    level.addParticle(ParticleTypes.FLASH, hands.x, hands.y, hands.z, 0, 0, 0);
                    shakeAround(caster.position(), 0.45f, 18);
                });
                // Gelombang udara melengkung yang melebar ke depan
                schedule(ShazamAnim.CAST_WINDUP, 8, (level, t) ->
                        arcWave(level, caster.position().add(0, 1.0, 0), yaw, 1.0 + t * 1.1, 55f));
            }
            case ATLAS_DIVE -> schedule(0, 60, (level, t) -> {
                if (ShazamPoses.currentAnim(caster) != ShazamAnim.ATLAS_DIVE) {
                    return;
                }
                Vec3 c = caster.position();
                level.addParticle(ParticleTypes.CLOUD, c.x, c.y + 0.4, c.z, 0, 0.15, 0);
            });
            case ATLAS_IMPACT -> {
                Vec3 center = caster.position();
                schedule(0, 1, (level, t) -> {
                    for (int i = 0; i < 6; i++) {
                        level.addParticle(ParticleTypes.EXPLOSION, center.x + spread(level, 2.0), center.y + 0.3,
                                center.z + spread(level, 2.0), 0, 0, 0);
                    }
                    shakeAround(center, 0.9f, 28);
                });
                // Cincin pecahan tanah yang melebar
                schedule(0, 10, (level, t) -> debrisRing(level, center, 0.6 + t * 0.7, 10 + t * 3));
            }
            case ZEUS_CALL -> schedule(ShazamAnim.CAST_WINDUP, 1, (level, t) -> {
                sparks(level, pos.add(0, 0.3, 0), 40);
                shakeAround(pos, 0.35f, 14);
            });
            case ACHILLES_ROAR -> {
                schedule(ShazamAnim.ROAR_WINDUP, 1, (level, t) -> shakeAround(caster.position(), 0.35f, 16));
                // Cincin emas dari raungan
                schedule(ShazamAnim.ROAR_WINDUP, 8, (level, t) ->
                        ring(level, caster.position().add(0, 0.2, 0), 0.5 + t * 0.75, 32, ParticleTypes.WAX_ON, 0.05));
                // Kilau emas di sekitar badan selama kebal
                schedule(ShazamAnim.ROAR_WINDUP, ShazamAnim.ACHILLES_TICKS, (level, t) -> {
                    if (t % 3 != 0 || ShazamPoses.auraStrength(caster, 0f) <= 0f) {
                        return;
                    }
                    Vec3 c = caster.position();
                    level.addParticle(ParticleTypes.WAX_ON, c.x + spread(level, 0.6),
                            c.y + level.random.nextDouble() * 1.9, c.z + spread(level, 0.6), 0, 0.02, 0);
                });
            }
            case MERCURY_BLITZ -> {
                if (self) {
                    FovKick.kick(0.22f);
                }
                schedule(0, ShazamAnim.BLITZ_TICKS + 2, (level, t) -> speedLines(level, caster));
            }
            case LAUNCH -> {
                Vec3 c = caster.position();
                schedule(0, 1, (level, t) -> {
                    smokeBurst(level, c, 24, 0.35);
                    shakeAround(c, 0.3f, 14);
                });
                schedule(0, 6, (level, t) -> debrisRing(level, c, 0.8 + t * 0.5, 10 + t * 2));
            }
            case LAND_SOFT -> schedule(0, 1, (level, t) -> landingPuff(level, caster.position()));
            case LAND_HERO -> {
                Vec3 c = caster.position();
                schedule(0, 1, (level, t) -> {
                    for (int i = 0; i < 4; i++) {
                        level.addParticle(ParticleTypes.EXPLOSION, c.x + spread(level, 1.5), c.y + 0.3, c.z + spread(level, 1.5), 0, 0, 0);
                    }
                    smokeBurst(level, c, 40, 0.5);
                    shakeAround(c, 0.9f, 30);
                });
                schedule(0, 12, (level, t) -> debrisRing(level, c, 0.8 + t * 0.6, 12 + t * 3));
            }
            case CRASH -> schedule(0, 1, (level, t) -> {
                Vec3 c = caster.position().add(caster.getViewVector(1f).scale(0.8));
                for (int i = 0; i < 3; i++) {
                    level.addParticle(ParticleTypes.EXPLOSION, c.x + spread(level, 0.8), c.y + 1.0 + spread(level, 0.8), c.z + spread(level, 0.8), 0, 0, 0);
                }
                debrisRing(level, caster.position(), 1.2, 16);
                smokeBurst(level, c, 30, 0.4);
                shakeAround(c, 0.8f, 24);
            });
            case SONIC_BOOM -> {
                schedule(0, 1, (level, t) -> {
                    Vec3 c = caster.position().add(0, 0.9, 0);
                    level.addParticle(ParticleTypes.FLASH, c.x, c.y, c.z, 0, 0, 0);
                    shakeAround(caster.position(), 0.5f, 40);
                });
                schedule(0, 4, (level, t) -> vaporCone(level, caster, 1.0 + t * 0.6));
            }
            case ROLL_LEFT, ROLL_RIGHT -> schedule(0, 6, (level, t) -> {
                Vec3 c = caster.position();
                level.addParticle(ParticleTypes.CLOUD, c.x + spread(level, 0.6), c.y + level.random.nextDouble() * 1.8,
                        c.z + spread(level, 0.6), 0, 0, 0);
            });
            case SUMMON -> {
                // Roh enam dewa datang; huruf-huruf sihir mengalir dari lingkaran di tanah ke dada
                ShazamSpirits.start(caster);
                schedule(0, ShazamAnim.SUMMON_TICKS + ShazamAnim.TRANSFORM_STRIKE, (level, t) -> summonGlyphs(level, caster, t));
                if (self) {
                    ShazamCinematic.start();   // dari sudut pandang orang pertama: kamera pindah ke depan
                }
            }
            case ZEUS_RAGE -> {
                // Percikan listrik terkumpul, lalu meledak saat meraung
                schedule(0, ShazamAnim.RAGE_WINDUP, (level, t) -> rageCharge(level, caster));
                schedule(ShazamAnim.RAGE_WINDUP, 1, (level, t) -> {
                    shockRing(level, caster.position(), 1.4);
                    for (int i = 0; i < 40; i++) {
                        level.addParticle(ParticleTypes.ELECTRIC_SPARK, caster.getX(), caster.getY() + 1.2, caster.getZ(),
                                spread(level, 1.2), spread(level, 1.0) + 0.2, spread(level, 1.2));
                    }
                    if (self) {
                        CameraShake.add(0.35f);
                    }
                });
            }
            case HOOD_UP, HOOD_DOWN -> {
                // gesekan kain saat tangan memegang hood, lalu desir saat hood terpasang/terlepas
                boolean up = anim == ShazamAnim.HOOD_UP;
                schedule(ShazamAnim.HOOD_GRAB, 1, (level, t) -> level.playLocalSound(caster.getX(), caster.getEyeY(),
                        caster.getZ(), SoundEvents.ARMOR_EQUIP_LEATHER.value(), SoundSource.PLAYERS, 0.9f, up ? 1.15f : 0.95f, false));
                schedule(ShazamAnim.HOOD_GRAB + ShazamAnim.HOOD_MOVE - 2, 1, (level, t) -> level.playLocalSound(caster.getX(),
                        caster.getEyeY(), caster.getZ(), SoundEvents.WOOL_PLACE, SoundSource.PLAYERS, 0.5f, up ? 1.4f : 1.2f, false));
            }
            default -> { }
        }
    }

    /** Nada suara ikut turun saat dunia diperlambat (slow motion transformasi). */
    static float slowPitch(ClientLevel level, float pitch) {
        float rate = level.tickRateManager().tickrate();
        return pitch * Mth.clamp((float) Math.sqrt(rate / 20f), 0.5f, 1f);
    }

    /** Selama petir turun: listrik ditarik dari sekeliling ke kepalan, makin rapat menjelang sambaran. */
    private static void descentCharge(ClientLevel level, AbstractClientPlayer p, int t) {
        double fx = p.getX(), fy = p.getY() + ShazamPowers.FIST_HEIGHT * p.getScale(), fz = p.getZ();
        double radius = Math.max(0.4, 1.8 - t * 0.14);
        for (int i = 0; i < 3 + t / 2; i++) {
            double a = level.random.nextDouble() * Math.PI * 2.0, b = (level.random.nextDouble() - 0.5) * Math.PI;
            double ox = Math.cos(a) * Math.cos(b) * radius, oy = Math.sin(b) * radius, oz = Math.sin(a) * Math.cos(b) * radius;
            level.addParticle(ParticleTypes.ELECTRIC_SPARK, fx + ox, fy + oy, fz + oz, -ox * 0.15, -oy * 0.15, -oz * 0.15);
        }
        if (t % 2 == 0) {
            level.addParticle(ParticleTypes.END_ROD, fx + spread(level, 0.4), fy + spread(level, 0.3), fz + spread(level, 0.4),
                    0, 0.02, 0);
        }
    }

    /** Jejak terbang: awan di belakang, emas saat super cepat, percikan listrik di atas sonic boom. */
    public static void flightTrail(AbstractClientPlayer player, float speed, float boost) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null || speed < 0.8f) {
            return;
        }
        Vec3 from = new Vec3(player.xo, player.yo + 0.9, player.zo);
        Vec3 to = player.position().add(0, 0.9, 0);
        Vec3 back = to.subtract(from).normalize().scale(-0.25);
        int count = Math.min(10, 1 + (int) (speed * 2f));
        for (int i = 0; i < count; i++) {
            Vec3 p = from.lerp(to, i / (double) count);
            level.addParticle(ParticleTypes.CLOUD, p.x + spread(level, 0.2), p.y + spread(level, 0.25), p.z + spread(level, 0.2),
                    back.x, back.y, back.z);
            if (boost > 0.3f && i % 2 == 0) {
                level.addParticle(ParticleTypes.END_ROD, p.x + spread(level, 0.3), p.y + spread(level, 0.3), p.z + spread(level, 0.3), 0, 0, 0);
                level.addParticle(ParticleTypes.WAX_ON, p.x + spread(level, 0.3), p.y + spread(level, 0.3), p.z + spread(level, 0.3), 0, 0, 0);
            }
        }
        if (speed > 3.4f && level.random.nextInt(2) == 0) {
            level.addParticle(ParticleTypes.ELECTRIC_SPARK, to.x + spread(level, 0.4), to.y + spread(level, 0.6), to.z + spread(level, 0.4), 0, 0, 0);
        }
    }

    // ------------------------------------------------------------- pembuat partikel

    private static double spread(ClientLevel level, double amount) {
        return (level.random.nextDouble() - 0.5) * 2.0 * amount;
    }

    private static void smokeBurst(ClientLevel level, Vec3 c, int count, double speed) {
        RandomSource random = level.random;
        for (int i = 0; i < count; i++) {
            double angle = random.nextDouble() * Math.PI * 2.0;
            double v = speed * (0.6 + random.nextDouble() * 0.6);
            level.addParticle(ParticleTypes.CLOUD, c.x, c.y + 0.2 + random.nextDouble() * 1.6, c.z,
                    Math.cos(angle) * v, 0.02 + random.nextDouble() * 0.05, Math.sin(angle) * v);
        }
        for (int i = 0; i < count / 2; i++) {
            double angle = random.nextDouble() * Math.PI * 2.0;
            level.addParticle(ParticleTypes.LARGE_SMOKE, c.x + Math.cos(angle) * 0.8, c.y + random.nextDouble() * 1.8,
                    c.z + Math.sin(angle) * 0.8, Math.cos(angle) * 0.08, 0.03, Math.sin(angle) * 0.08);
        }
    }

    private static void sparks(ClientLevel level, Vec3 c, int count) {
        for (int i = 0; i < count; i++) {
            level.addParticle(ParticleTypes.ELECTRIC_SPARK, c.x, c.y, c.z,
                    spread(level, 0.5), level.random.nextDouble() * 0.5, spread(level, 0.5));
            if (i % 2 == 0) {
                level.addParticle(ParticleTypes.WAX_ON, c.x + spread(level, 0.8), c.y + spread(level, 0.8),
                        c.z + spread(level, 0.8), 0, 0, 0);
            }
        }
    }

    private static void wisdomGlyphs(ClientLevel level, Vec3 head, int count) {
        RandomSource random = level.random;
        for (int i = 0; i < count; i++) {
            double angle = random.nextDouble() * Math.PI * 2.0;
            double distance = 1.8 + random.nextDouble() * 1.2;
            // Partikel ENCHANT terbang dari (posisi + kecepatan) menuju posisi: jadi terserap ke kepala
            level.addParticle(ParticleTypes.ENCHANT, head.x, head.y, head.z,
                    Math.cos(angle) * distance, random.nextDouble() * 1.5 - 0.5, Math.sin(angle) * distance);
        }
    }

    private static void ring(ClientLevel level, Vec3 c, double radius, int points, ParticleOptions particle, double rise) {
        for (int i = 0; i < points; i++) {
            double angle = Math.PI * 2.0 * i / points;
            double cos = Math.cos(angle);
            double sin = Math.sin(angle);
            level.addParticle(particle, c.x + cos * radius, c.y, c.z + sin * radius, cos * 0.02, rise, sin * 0.02);
        }
    }

    private static void arcWave(ClientLevel level, Vec3 c, float yawDeg, double radius, float halfAngle) {
        int points = 14;
        for (int i = 0; i <= points; i++) {
            double angle = Math.toRadians(yawDeg - halfAngle + 2f * halfAngle * i / points);
            double dx = -Math.sin(angle);
            double dz = Math.cos(angle);
            double x = c.x + dx * radius;
            double z = c.z + dz * radius;
            double y = c.y + spread(level, 0.5);
            level.addParticle(ParticleTypes.CLOUD, x, y, z, dx * 0.12, 0.01, dz * 0.12);
            if (i % 3 == 0) {
                level.addParticle(ParticleTypes.POOF, x, y, z, dx * 0.05, 0.0, dz * 0.05);
            }
        }
    }

    private static void debrisRing(ClientLevel level, Vec3 c, double radius, int points) {
        RandomSource random = level.random;
        for (int i = 0; i < points; i++) {
            double angle = Math.PI * 2.0 * i / points + random.nextDouble() * 0.2;
            double cos = Math.cos(angle);
            double sin = Math.sin(angle);
            double x = c.x + cos * radius;
            double z = c.z + sin * radius;
            BlockState ground = level.getBlockState(BlockPos.containing(x, c.y - 0.5, z));
            if (!ground.isAir() && ground.getRenderShape() != RenderShape.INVISIBLE) {
                level.addParticle(new BlockParticleOption(ParticleTypes.BLOCK, ground), x, c.y + 0.1, z,
                        cos * 0.1, 0.25 + random.nextDouble() * 0.3, sin * 0.1);
            }
            if (i % 2 == 0) {
                level.addParticle(ParticleTypes.CLOUD, x, c.y + 0.2, z, cos * 0.08, 0.04, sin * 0.08);
            }
        }
    }

    private static void speedLines(ClientLevel level, AbstractClientPlayer player) {
        Vec3 motion = new Vec3(player.getX() - player.xo, player.getY() - player.yo, player.getZ() - player.zo);
        if (motion.lengthSqr() < 0.04) {
            return;
        }
        Vec3 back = motion.normalize().scale(-0.4);
        for (int i = 0; i < 6; i++) {
            level.addParticle(ParticleTypes.CLOUD, player.getX() + spread(level, 0.4),
                    player.getY() + 0.2 + level.random.nextDouble() * 1.6, player.getZ() + spread(level, 0.4),
                    back.x, back.y * 0.2, back.z);
        }
        level.addParticle(ParticleTypes.ELECTRIC_SPARK, player.getX(), player.getY() + 1.0, player.getZ(), 0, 0, 0);
    }

    /** Tenaga terkumpul sebelum petir: percikan berputar naik, debu berpusar, listrik di kepalan. */
    private static void chargeSparks(ClientLevel level, AbstractClientPlayer p, int t) {
        double angle = t * 0.9;
        for (int i = 0; i < 3; i++) {
            double a = angle + i * Math.PI * 2.0 / 3.0;
            double r = 1.1 - t * 0.08;
            level.addParticle(ParticleTypes.ELECTRIC_SPARK, p.getX() + Math.cos(a) * r, p.getY() + 0.2 + t * 0.25,
                    p.getZ() + Math.sin(a) * r, 0, 0.05, 0);
        }
        double a2 = level.random.nextDouble() * Math.PI * 2.0;
        level.addParticle(ParticleTypes.CLOUD, p.getX() + Math.cos(a2) * 1.5, p.getY() + 0.1, p.getZ() + Math.sin(a2) * 1.5,
                -Math.sin(a2) * 0.15, 0.02, Math.cos(a2) * 0.15);
        if (t >= 4) {
            level.addParticle(ParticleTypes.ELECTRIC_SPARK, p.getX() + spread(level, 0.3), p.getY() + 2.4 + spread(level, 0.3),
                    p.getZ() + spread(level, 0.3), 0, 0, 0);
        }
    }

    /** Gelombang kejut di tanah setelah petir menyambar. */
    private static void shockRing(ClientLevel level, Vec3 c, double radius) {
        int points = (int) (18 + radius * 6);
        for (int i = 0; i < points; i++) {
            double angle = Math.PI * 2.0 * i / points;
            double cos = Math.cos(angle);
            double sin = Math.sin(angle);
            double x = c.x + cos * radius;
            double z = c.z + sin * radius;
            level.addParticle(ParticleTypes.CLOUD, x, c.y + 0.15, z, cos * 0.18, 0.02, sin * 0.18);
            if (i % 3 == 0) {
                level.addParticle(ParticleTypes.ELECTRIC_SPARK, x, c.y + 0.3, z, 0, 0.05, 0);
            }
        }
        if (radius < 4.0) {
            debrisRing(level, c, radius, 8);
        }
    }

    /** Huruf-huruf sihir mengalir dari lingkaran di tanah menuju dada, dan cahaya naik dari lingkaran itu. */
    private static void summonGlyphs(ClientLevel level, AbstractClientPlayer p, int t) {
        double radius = 2.6 * p.getScale();
        for (int i = 0; i < 4; i++) {
            double angle = level.random.nextDouble() * Math.PI * 2.0;
            // ENCHANT bergerak dari (posisi + kecepatan) menuju posisi: dari lingkaran ke dada
            level.addParticle(ParticleTypes.ENCHANT, p.getX(), p.getY() + 1.2, p.getZ(),
                    Math.cos(angle) * radius, -1.1, Math.sin(angle) * radius);
        }
        if (t % 2 == 0) {
            double angle = t * 0.35;
            level.addParticle(ParticleTypes.END_ROD, p.getX() + Math.cos(angle) * radius, p.getY() + 0.05,
                    p.getZ() + Math.sin(angle) * radius, 0, 0.04, 0);
        }
    }

    /** Percikan listrik ditarik ke badan sebelum amarah Zeus menyala. */
    private static void rageCharge(ClientLevel level, AbstractClientPlayer p) {
        for (int i = 0; i < 5; i++) {
            double ox = spread(level, 1.6), oy = level.random.nextDouble() * 2.0, oz = spread(level, 1.6);
            level.addParticle(ParticleTypes.ELECTRIC_SPARK, p.getX() + ox, p.getY() + oy, p.getZ() + oz,
                    -ox * 0.2, (1.1 - oy) * 0.2, -oz * 0.2);
        }
    }

    /** Listrik yang merambat di badan sesudah tersambar. */
    private static void bodyArcs(ClientLevel level, AbstractClientPlayer p) {
        for (int i = 0; i < 4; i++) {
            level.addParticle(ParticleTypes.ELECTRIC_SPARK, p.getX() + spread(level, 0.5), p.getY() + level.random.nextDouble() * 2.2,
                    p.getZ() + spread(level, 0.5), spread(level, 0.1), 0.05, spread(level, 0.1));
        }
        if (level.random.nextInt(3) == 0) {
            level.addParticle(ParticleTypes.WAX_ON, p.getX() + spread(level, 0.6), p.getY() + level.random.nextDouble() * 2.0,
                    p.getZ() + spread(level, 0.6), 0, 0.02, 0);
        }
    }

    private static void landingPuff(ClientLevel level, Vec3 c) {
        for (int i = 0; i < 16; i++) {
            double angle = Math.PI * 2.0 * i / 16;
            level.addParticle(ParticleTypes.CLOUD, c.x + Math.cos(angle) * 0.6, c.y + 0.1, c.z + Math.sin(angle) * 0.6,
                    Math.cos(angle) * 0.12, 0.01, Math.sin(angle) * 0.12);
        }
    }

    /** Cincin uap tegak lurus arah terbang saat menembus sonic boom. */
    private static void vaporCone(ClientLevel level, AbstractClientPlayer p, double radius) {
        Vec3 motion = new Vec3(p.getX() - p.xo, p.getY() - p.yo, p.getZ() - p.zo);
        Vec3 dir = motion.lengthSqr() < 1.0E-4 ? p.getViewVector(1f) : motion.normalize();
        Vec3 up = Math.abs(dir.y) > 0.9 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0);
        Vec3 a = dir.cross(up).normalize();
        Vec3 b = dir.cross(a).normalize();
        Vec3 center = p.position().add(0, 0.9, 0).subtract(dir.scale(1.5));
        int points = 28;
        for (int i = 0; i < points; i++) {
            double angle = Math.PI * 2.0 * i / points;
            Vec3 offset = a.scale(Math.cos(angle) * radius).add(b.scale(Math.sin(angle) * radius));
            Vec3 pos = center.add(offset);
            Vec3 vel = offset.normalize().scale(0.15).subtract(dir.scale(0.1));
            level.addParticle(ParticleTypes.CLOUD, pos.x, pos.y, pos.z, vel.x, vel.y, vel.z);
        }
    }

    private static void shakeAround(Vec3 c, float amount, double radius) {
        LocalPlayer me = Minecraft.getInstance().player;
        if (me == null) {
            return;
        }
        double distance = me.position().distanceTo(c);
        if (distance < radius) {
            CameraShake.add(amount * (float) (1.0 - distance / radius));
        }
    }
}
