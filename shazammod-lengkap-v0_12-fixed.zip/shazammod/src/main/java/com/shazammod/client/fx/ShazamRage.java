package com.shazammod.client.fx;

import java.util.HashMap;
import java.util.Map;

import com.shazammod.ShazamClientState;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/** Zeus Rage di sisi client: terang-redupnya mata putih, dan listrik yang menjalar di mata dan badan. */
public final class ShazamRage {
    private ShazamRage() {}

    private static final Map<Integer, float[]> GLOW = new HashMap<>();   // {tick lalu, sekarang}

    public static void clear() {
        GLOW.clear();
    }

    /** 0 = mata normal, 1 = putih menyala penuh. */
    public static float glow(AbstractClientPlayer player, float partialTick) {
        float[] g = GLOW.get(player.getId());
        return g == null ? 0f : Mth.lerp(partialTick, g[0], g[1]);
    }

    public static void tick(ClientLevel level) {
        Minecraft mc = Minecraft.getInstance();
        GLOW.keySet().removeIf(id -> !(level.getEntity(id) instanceof AbstractClientPlayer));
        for (AbstractClientPlayer player : level.players()) {
            boolean raging = ShazamClientState.isRaging(player.getId()) && ShazamClientState.isTransformed(player.getId());
            float[] g = GLOW.get(player.getId());
            if (g == null) {
                if (!raging) {
                    continue;
                }
                g = new float[2];
                GLOW.put(player.getId(), g);
            }
            g[0] = g[1];
            g[1] = Mth.approach(g[1], raging ? 1f : 0f, raging ? 0.25f : 0.08f);   // menyala cepat, padam pelan
            if (!raging && g[1] <= 0f) {
                GLOW.remove(player.getId());
                continue;
            }
            if (g[1] < 0.5f || player.isInvisible()) {
                continue;
            }
            boolean firstPerson = player == mc.player && mc.options.getCameraType().isFirstPerson();
            if (!firstPerson && level.random.nextInt(2) == 0) {
                // percikan dari mata
                Vec3 eye = player.getEyePosition().add(player.getViewVector(1f).scale(0.3));
                level.addParticle(ParticleTypes.ELECTRIC_SPARK, eye.x + (level.random.nextDouble() - 0.5) * 0.3,
                        eye.y + (level.random.nextDouble() - 0.5) * 0.1, eye.z + (level.random.nextDouble() - 0.5) * 0.3,
                        (level.random.nextDouble() - 0.5) * 0.05, 0.03, (level.random.nextDouble() - 0.5) * 0.05);
            }
            if (player.tickCount % 2 == 0) {
                // listrik menjalar di badan
                level.addParticle(ParticleTypes.ELECTRIC_SPARK, player.getX() + (level.random.nextDouble() - 0.5) * 0.9,
                        player.getY() + level.random.nextDouble() * 2.0 * player.getScale(),
                        player.getZ() + (level.random.nextDouble() - 0.5) * 0.9,
                        (level.random.nextDouble() - 0.5) * 0.08, 0.04, (level.random.nextDouble() - 0.5) * 0.08);
            }
        }
    }
}
