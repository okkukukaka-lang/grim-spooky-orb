package com.shazammod.client.anim;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.joml.Matrix4f;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamPowers;
import com.shazammod.client.fx.ShazamFx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.ClipContext;

/**
 * Otak animasi Shazam di client. Lapisannya, dari bawah ke atas:
 * 1. pose terbang: melayang, meluncur (satu kepalan di depan), super cepat (dua kepalan di depan),
 *    mengerem. Kemiringan badan, menikung, menghadap lintasan, kelembaman tangan-kaki, getar angin, dan
 *    ancang-ancang mendarat dihitung dari fisika gerak (FlightPose), plus barrel roll,
 * 2. pose berdiri gagah saat diam,
 * 3. klip gerakan (lihat Clips).
 * Ditambah pergantian kostum, bayangan Kilat Mercury, dan aura Kulit Achilles.
 */
public final class ShazamPoses {
    private ShazamPoses() {}

    private static final int GHOST_LIFE = 10;
    private static final int ROLL_TICKS = 10;
    /** Lama kostum terbentuk / luruh (tick). */
    public static final int SUIT_TICKS = 16;

    private static final class State {
        Clip clip;
        ShazamAnim anim;
        int startAge;
        float flight, flightO;   // sedang terbang (0-1)
        float soar, soarO;       // meluncur, badan rebah (0-1)
        float boost, boostO;     // super cepat (0-1)
        float brake, brakeO;     // mengerem (0-1)
        float tilt, tiltO;       // kemiringan badan (derajat, positif = condong ke depan)
        float bank, bankO;       // menikung (derajat)
        float side, sideO;       // miring ke samping saat melayang (derajat)
        float yawOff, yawOffO;   // badan menghadap lintasan (derajat, relatif arah pandang)
        float leg, legO;         // kaki lembam (radian)
        float arm, armO;         // lengan lembam (radian)
        float flutter, flutterO; // fase getar angin
        float flutterAmp;
        final FlightPose pose = new FlightPose();
        float stance, stanceO;
        float speed;
        int idleTicks;
        int rollStart = -1000;
        int rollDir;
        int auraStart = -1;
        int auraEnd = -1;
        int ghostUntil = -1;
        float lastTilt;
        final ArrayDeque<Ghost> ghosts = new ArrayDeque<>();
        boolean wasTransformed;
        boolean suitIn;
        int suitAge = -1000;
        boolean headKnown;
        float headPX, headPY, headPZ, headXRot, headYRot, bodyXRot;
    }

    private record Ghost(double x, double y, double z, float yaw, float tilt, int age) {}

    private static final Map<Integer, State> STATES = new HashMap<>();

    public static void clear() {
        STATES.clear();
    }

    public static ShazamAnim currentAnim(Entity entity) {
        State state = STATES.get(entity.getId());
        return state == null ? null : state.anim;
    }

    /** Sudah berapa tick klip yang sedang diputar berjalan, atau -1 kalau nggak ada klip. */
    public static float animTime(Entity entity, float partialTick) {
        State state = STATES.get(entity.getId());
        return state == null || state.anim == null ? -1f : entity.tickCount + partialTick - state.startAge;
    }

    private static State stateFor(AbstractClientPlayer player) {
        State state = STATES.get(player.getId());
        if (state == null) {
            state = new State();
            state.wasTransformed = ShazamClientState.isTransformed(player.getId());
            STATES.put(player.getId(), state);
        }
        return state;
    }

    /** Mulai animasi untuk pemain ini. */
    public static void start(AbstractClientPlayer player, ShazamAnim anim) {
        State state = stateFor(player);
        switch (anim) {
            case ROLL_LEFT, ROLL_RIGHT -> {
                state.rollStart = player.tickCount;
                state.rollDir = anim == ShazamAnim.ROLL_RIGHT ? 1 : -1;
                return;
            }
            case SONIC_BOOM -> {
                return;
            }
            default -> { }
        }
        state.clip = Clips.get(anim);
        state.anim = anim;
        state.startAge = player.tickCount;
        switch (anim) {
            case ACHILLES_ROAR -> {
                state.auraStart = player.tickCount + ShazamAnim.ROAR_WINDUP;
                state.auraEnd = state.auraStart + ShazamAnim.ACHILLES_TICKS;
            }
            case MERCURY_BLITZ -> state.ghostUntil = player.tickCount + ShazamAnim.BLITZ_TICKS + 2;
            case REVERT -> state.auraEnd = -1;
            default -> { }
        }
    }

    // ---------------------------------------------------------------- tick client

    public static void tick(ClientLevel level) {
        Iterator<Map.Entry<Integer, State>> iterator = STATES.entrySet().iterator();
        while (iterator.hasNext()) {
            if (!(level.getEntity(iterator.next().getKey()) instanceof AbstractClientPlayer)) {
                iterator.remove();
            }
        }
        for (AbstractClientPlayer player : level.players()) {
            boolean transformed = ShazamClientState.isTransformed(player.getId());
            State state = STATES.get(player.getId());
            if (state == null) {
                if (!transformed) {
                    continue;
                }
                state = new State();
                state.wasTransformed = true; // baru kelihatan dan sudah jadi Shazam: tanpa animasi kostum
                STATES.put(player.getId(), state);
            }
            tickPlayer(player, state, transformed);
        }
    }

    private static void tickPlayer(AbstractClientPlayer player, State s, boolean transformed) {
        // Kostum berganti: mulai animasi terbentuk (saat transformasi) atau luruh (saat kembali jadi manusia)
        if (transformed != s.wasTransformed) {
            if (!transformed || s.anim == ShazamAnim.TRANSFORM) {
                s.suitIn = transformed;
                s.suitAge = player.tickCount;
                player.level().playLocalSound(player.getX(), player.getY() + 1.0, player.getZ(),
                        SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.5f, transformed ? 1.4f : 0.8f, false);
            }
            s.wasTransformed = transformed;
        }

        boolean selfFlying = player == Minecraft.getInstance().player && player.getAbilities().flying;
        boolean flying = transformed && !player.onGround() && (selfFlying || ShazamClientState.isFlying(player.getId()));
        double dx = player.getX() - player.xo;
        double dy = player.getY() - player.yo;
        double dz = player.getZ() - player.zo;
        float speed = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);

        s.flightO = s.flight;
        s.soarO = s.soar;
        s.boostO = s.boost;
        s.brakeO = s.brake;
        s.tiltO = s.tilt;
        s.bankO = s.bank;
        s.sideO = s.side;
        s.yawOffO = s.yawOff;
        s.legO = s.leg;
        s.armO = s.arm;
        s.flutterO = s.flutter;
        s.stanceO = s.stance;

        s.flight = approach(s.flight, flying ? 1f : 0f, 0.15f);
        s.soar = approach(s.soar, flying ? FlightPose.soarTarget(dx, dy, dz, player.yBodyRot) : 0f, 0.08f);
        s.boost = approach(s.boost, flying ? Mth.clamp((speed - 2.0f) / 1.2f, 0f, 1f) : 0f, 0.06f);
        boolean braking = flying && s.speed - speed > 0.06f && s.speed > 0.5f;
        s.brake = approach(s.brake, braking ? 1f : 0f, braking ? 0.25f : 0.08f);
        s.speed = speed;

        // Pose dari fisika gerak: condong, menikung, menghadap lintasan, tungkai lembam, getar angin, mendarat
        double ground = flying && dy < -0.15 ? groundAhead(player, dx, dy, dz) : 100.0;
        s.pose.update(dx, dy, dz, player.yBodyRot, s.flight, s.soar, s.brake, ground);
        s.tilt = s.pose.tilt;
        s.bank = s.pose.bank;
        s.side = s.pose.side;
        s.yawOff = s.pose.yaw;
        s.leg = s.pose.legSwing;
        s.arm = s.pose.armSwing;
        s.flutter = s.pose.flutter;
        s.flutterAmp = s.pose.flutterAmp;

        boolean idle = transformed && player.onGround() && speed < 0.01f && !player.swinging
                && !player.isUsingItem() && !player.isCrouching() && player.getMainHandItem().isEmpty();
        s.idleTicks = idle ? s.idleTicks + 1 : 0;
        s.stance = approach(s.stance, s.idleTicks > 20 ? 1f : 0f, 0.1f);

        if (!transformed) {
            s.auraEnd = -1;
        }
        if (s.clip != null && player.tickCount - s.startAge > s.clip.length + 1) {
            s.clip = null;
            s.anim = null;
        }
        if (s.ghostUntil >= player.tickCount) {
            s.ghosts.addLast(new Ghost(player.getX(), player.getY(), player.getZ(), player.yBodyRot, s.lastTilt, player.tickCount));
        }
        while (!s.ghosts.isEmpty() && player.tickCount - s.ghosts.peekFirst().age() > GHOST_LIFE) {
            s.ghosts.removeFirst();
        }
        if (flying && s.soar > 0.3f) {
            ShazamFx.flightTrail(player, speed, s.boost);
        }
    }

    /** Seberapa jauh lagi turun sampai menyentuh tanah, mengikuti arah lintasan (blok); 100 kalau masih jauh. */
    private static double groundAhead(AbstractClientPlayer player, double dx, double dy, double dz) {
        double reach = FlightPose.groundCheckDistance(dy);
        Vec3 path = new Vec3(dx, dy, dz).scale(reach / -dy);
        if (path.length() > 80.0) {
            path = path.normalize().scale(80.0);
        }
        Vec3 from = player.position();
        BlockHitResult hit = player.level().clip(new ClipContext(from, from.add(path), ClipContext.Block.COLLIDER,
                ClipContext.Fluid.ANY, player));
        return hit.getType() == HitResult.Type.MISS ? 100.0 : from.y - hit.getLocation().y;
    }

    private static float approach(float value, float target, float step) {
        return value < target ? Math.min(target, value + step) : Math.max(target, value - step);
    }

    // ------------------------------------------------- pose bagian tubuh (mixin)

    /** Dipanggil di akhir HumanoidModel.setupAnim untuk setiap pemain. */
    public static void apply(HumanoidModel<?> model, AbstractClientPlayer player, float ageInTicks) {
        if (ageInTicks <= 0.0001f) {
            return; // tangan orang pertama: biarkan bawaan
        }
        State s = STATES.get(player.getId());
        if (s == null) {
            return;
        }
        float pt = Mth.clamp(ageInTicks - player.tickCount, 0f, 1f);
        float headX = model.head.xRot;
        float headY = model.head.yRot;
        float flight = Mth.lerp(pt, s.flightO, s.flight);
        float stance = Mth.lerp(pt, s.stanceO, s.stance);

        if (flight > 0.001f) {
            applyFlight(model, flight, Mth.lerp(pt, s.soarO, s.soar), Mth.lerp(pt, s.boostO, s.boost),
                    Mth.lerp(pt, s.brakeO, s.brake), Mth.lerp(pt, s.tiltO, s.tilt), ageInTicks, headX,
                    Mth.lerp(pt, s.legO, s.leg), Mth.lerp(pt, s.armO, s.arm), Mth.lerp(pt, s.flutterO, s.flutter), s.flutterAmp);
            // badan diputar menghadap lintasan, kepala tetap memandang ke arah kamera
            model.head.yRot -= Mth.lerp(pt, s.yawOffO, s.yawOff) * Mth.DEG_TO_RAD;
        }
        if (stance > 0.001f) {
            applyStance(model, stance, ageInTicks);
        }
        if (s.clip != null) {
            s.clip.apply(model, ageInTicks - s.startAge, headX, headY);
        }
        model.hat.copyFrom(model.head);
        // Simpan pose akhir kepala & badan buat hood dan jubah
        s.headKnown = true;
        s.headPX = model.head.x;
        s.headPY = model.head.y;
        s.headPZ = model.head.z;
        s.headXRot = model.head.xRot;
        s.headYRot = model.head.yRot;
        s.bodyXRot = model.body.xRot;
    }

    /**
     * Matriks badan pemain tanpa posisi dunia: sama dengan yang dipakai renderer sebelum model dibalik
     * (ukuran badan, arah hadap, lalu miring/menikung/turun dari animasi). +Y ke atas, depan = -Z.
     */
    public static Matrix4f bodyMatrix(AbstractClientPlayer player, float partialTick, float bodyYaw) {
        PoseStack poseStack = new PoseStack();
        float scale = player.getScale();
        poseStack.scale(scale, scale, scale);
        poseStack.mulPose(Axis.YP.rotationDegrees(180f - bodyYaw));
        applyBodyTransform(player, poseStack, partialTick, scale);
        return new Matrix4f(poseStack.last().pose());
    }

    /** Pose kepala terakhir di ruang badan: {x, y, z poros leher, putar X, putar Y, condong badan}, atau null. */
    public static float[] headPose(AbstractClientPlayer player) {
        State s = STATES.get(player.getId());
        if (s == null || !s.headKnown) {
            return null;
        }
        return new float[] {
                -(s.headPX / 16f) * 0.9375f,
                0.9375f * (1.501f - s.headPY / 16f),
                0.9375f * (s.headPZ / 16f),
                -s.headXRot,
                -s.headYRot,
                -s.bodyXRot};
    }

    private static void applyFlight(HumanoidModel<?> m, float flight, float soar, float boost, float brake,
                                    float tilt, float age, float headX, float leg, float arm, float flutter,
                                    float flutterAmp) {
        float bob = Mth.sin(age * 0.08f);
        float hover = flight * (1f - soar);
        if (hover > 0.001f) {
            // Melayang: lengan sedikit terbuka, satu kaki agak ke belakang
            blend(m.rightArm, hover, -0.15f + bob * 0.06f, 0f, 0.3f);
            blend(m.leftArm, hover, -0.15f - bob * 0.06f, 0f, -0.3f);
            blend(m.rightLeg, hover, 0.05f + bob * 0.06f, 0f, 0.07f);
            blend(m.leftLeg, hover, 0.35f - bob * 0.04f, 0f, -0.07f);
        }
        float cruise = flight * soar * (1f - boost);
        if (cruise > 0.001f) {
            // Meluncur: kepalan kanan di depan, tangan kiri di sisi badan
            blend(m.rightArm, cruise, -3.0f, 0f, 0.05f);
            blend(m.leftArm, cruise, 0.3f + bob * 0.03f, 0f, -0.1f);
            blend(m.rightLeg, cruise, 0.1f, 0f, 0.03f);
            blend(m.leftLeg, cruise, 0.22f, 0f, -0.03f);
        }
        float fast = flight * soar * boost;
        if (fast > 0.001f) {
            // Super cepat: dua kepalan di depan, badan lurus seperti peluru
            float shiver = Mth.sin(age * 2.1f) * 0.015f;
            blend(m.rightArm, fast, -3.05f + shiver, 0f, 0.08f);
            blend(m.leftArm, fast, -3.05f - shiver, 0f, -0.08f);
            blend(m.rightLeg, fast, 0.04f, 0f, 0.01f);
            blend(m.leftLeg, fast, 0.06f, 0f, -0.01f);
        }
        float braking = flight * brake;
        if (braking > 0.001f) {
            // Mengerem: lengan ke depan menahan, kaki maju
            blend(m.rightArm, braking, -1.5f, -0.2f, 0.35f);
            blend(m.leftArm, braking, -1.5f, 0.2f, -0.35f);
            blend(m.rightLeg, braking, -0.6f, 0f, 0.05f);
            blend(m.leftLeg, braking, -0.3f, 0f, -0.05f);
        }
        // Lembam & getar angin: kaki tertinggal saat dipercepat, terayun ke depan saat mengerem;
        // makin kencang, tangan-kaki makin bergetar diterpa angin
        float f1 = Mth.sin(flutter) * flutterAmp;
        float f2 = Mth.sin(flutter * 1.13f + 1.7f) * flutterAmp;
        m.rightLeg.xRot += (leg + f1) * flight;
        m.leftLeg.xRot += (leg * 0.85f + f2) * flight;
        m.rightArm.xRot += (arm * 0.6f + f2 * 0.6f) * flight;
        m.leftArm.xRot += (arm + f1 * 0.6f) * flight;
        // Kepala tetap memandang ke depan walau badan rebah
        if (Math.abs(tilt) > 0.5f) {
            float lookAhead = Mth.clamp(headX - tilt * Mth.DEG_TO_RAD, -1.7f, 0.7f);
            m.head.xRot = Mth.lerp(flight, m.head.xRot, lookAhead);
        }
    }

    private static void applyStance(HumanoidModel<?> m, float w, float age) {
        // Berdiri gagah: kepalan di pinggang, kaki terbuka, napas pelan
        float breath = Mth.sin(age * 0.06f) * 0.03f;
        blend(m.rightArm, w, 0.2f, 0.1f, 0.45f + breath);
        blend(m.leftArm, w, 0.2f, -0.1f, -0.45f - breath);
        blend(m.rightLeg, w, 0f, 0f, 0.12f);
        blend(m.leftLeg, w, 0f, 0f, -0.12f);
    }

    private static void blend(ModelPart part, float w, float x, float y, float z) {
        part.xRot = Mth.lerp(w, part.xRot, x);
        part.yRot = Mth.lerp(w, part.yRot, y);
        part.zRot = Mth.lerp(w, part.zRot, z);
    }

    // --------------------------------------------- posisi seluruh badan (mixin)

    /** Dipanggil di akhir PlayerRenderer.setupRotations. scale = ukuran entity saat ini. */
    public static void applyBodyTransform(AbstractClientPlayer player, PoseStack poseStack, float partialTick, float scale) {
        State s = STATES.get(player.getId());
        if (s == null) {
            return;
        }
        float age = player.tickCount + partialTick;
        // Saat kostum berganti, badan tumbuh (atau menyusut) dengan mulus
        float change = age - s.suitAge;
        if (change >= 0f && change < SUIT_TICKS && scale > 0f) {
            float eased = Ease.OUT_CUBIC.apply(change / SUIT_TICKS);
            float from = s.suitIn ? 1f / scale : (1f + (float) ShazamPowers.GROWTH) / scale;
            float k = Mth.lerp(eased, from, 1f);
            poseStack.scale(k, k, k);
        }
        float flight = Mth.lerp(partialTick, s.flightO, s.flight);
        float soar = Mth.lerp(partialTick, s.soarO, s.soar);
        float tilt = Mth.lerp(partialTick, s.tiltO, s.tilt);
        float roll = Mth.lerp(partialTick, s.bankO, s.bank) + barrelRoll(s, age);
        float side = Mth.lerp(partialTick, s.sideO, s.side);
        float yaw = Mth.lerp(partialTick, s.yawOffO, s.yawOff);
        float drop = -flight * (1f - soar) * Mth.sin(age * 0.08f) * 0.04f; // naik-turun pelan saat melayang
        if (s.clip != null) {
            float t = age - s.startAge;
            float w = s.clip.weight(t);
            if (w > 0f) {
                tilt = Mth.lerp(w, tilt, s.clip.tilt(t));
                drop = Mth.lerp(w, drop, s.clip.drop(t));
                roll *= 1f - w;
                side *= 1f - w;
                yaw *= 1f - w;
            }
        }
        s.lastTilt = tilt;
        transformBody(poseStack, tilt, drop, roll, side, yaw);
    }

    private static float barrelRoll(State s, float age) {
        float t = (age - s.rollStart) / ROLL_TICKS;
        if (t < 0f || t > 1f) {
            return 0f;
        }
        return s.rollDir * 360f * Ease.IN_OUT_SINE.apply(t);
    }

    private static void transformBody(PoseStack poseStack, float tilt, float drop, float roll, float side, float yaw) {
        if (Math.abs(tilt) < 0.01f && Math.abs(drop) < 0.0005f && Math.abs(roll) < 0.01f
                && Math.abs(side) < 0.01f && Math.abs(yaw) < 0.01f) {
            return;
        }
        poseStack.translate(0f, -drop, 0f);
        poseStack.translate(0f, 0.9f, 0f);
        if (yaw != 0f) {
            poseStack.mulPose(Axis.YP.rotationDegrees(-yaw));   // menghadap arah lintasan
        }
        if (side != 0f) {
            poseStack.mulPose(Axis.ZP.rotationDegrees(-side));  // miring ke samping saat melayang
        }
        poseStack.mulPose(Axis.XP.rotationDegrees(-tilt));
        if (roll != 0f) {
            poseStack.mulPose(Axis.YP.rotationDegrees(roll)); // putar di sumbu panjang badan
        }
        poseStack.translate(0f, -0.9f, 0f);
    }

    // --------------------------------------------------- kamera pemain sendiri

    /** Kemiringan kamera: ikut menikung, dan sedikit berguling saat barrel roll. */
    public static float cameraRoll(AbstractClientPlayer player, float partialTick) {
        State s = STATES.get(player.getId());
        if (s == null) {
            return 0f;
        }
        float roll = Mth.lerp(partialTick, s.bankO, s.bank) * 0.5f;
        float t = (player.tickCount + partialTick - s.rollStart) / ROLL_TICKS;
        if (t >= 0f && t <= 1f) {
            roll += s.rollDir * 25f * Mth.sin(t * Mth.PI);
        }
        return roll;
    }

    /** 0-1: seberapa kencang pemain sedang terbang (buat melebarkan pandangan). */
    public static float flightSpeedFactor(AbstractClientPlayer player, float partialTick) {
        State s = STATES.get(player.getId());
        if (s == null) {
            return 0f;
        }
        return Mth.lerp(partialTick, s.flightO, s.flight) * Mth.clamp(s.speed / 5f, 0f, 1f);
    }

    // --------------------------------------------------- pergantian kostum

    /** Tick sejak kostum mulai terbentuk/luruh, atau -1 kalau sedang tidak berganti kostum. */
    public static float suitTicks(AbstractClientPlayer player, float partialTick) {
        State s = STATES.get(player.getId());
        if (s == null) {
            return -1f;
        }
        float t = player.tickCount + partialTick - s.suitAge;
        return t >= 0f && t < SUIT_TICKS ? t : -1f;
    }

    /** true = kostum sedang terbentuk, false = sedang luruh. */
    public static boolean suitIn(AbstractClientPlayer player) {
        State s = STATES.get(player.getId());
        return s != null && s.suitIn;
    }

    public static boolean isSuitRevealing(AbstractClientPlayer player) {
        return suitIn(player) && suitTicks(player, 0f) >= 0f;
    }

    public static boolean isSuitChanging(AbstractClientPlayer player) {
        return suitTicks(player, 0f) >= 0f;
    }

    // --------------------------------------------------- aura & bayangan

    /** 0-1: seberapa terang aura emas Kulit Achilles saat ini. */
    public static float auraStrength(AbstractClientPlayer player, float partialTick) {
        State s = STATES.get(player.getId());
        if (s == null || s.auraEnd < 0) {
            return 0f;
        }
        float now = player.tickCount + partialTick;
        if (now < s.auraStart || now > s.auraEnd) {
            return 0f;
        }
        return Math.min(1f, (now - s.auraStart) / 4f) * Math.min(1f, (s.auraEnd - now) / 10f);
    }

    /** Bayangan tembus pandang di sepanjang jalur Kilat Mercury (dipanggil dari RenderPlayerEvent.Post). */
    public static void renderGhosts(AbstractClientPlayer player, PlayerRenderer renderer, PoseStack poseStack,
                                    MultiBufferSource buffers, float partialTick) {
        State s = STATES.get(player.getId());
        if (s == null || s.ghosts.isEmpty()) {
            return;
        }
        PlayerModel<AbstractClientPlayer> model = renderer.getModel();
        ResourceLocation texture = renderer.getTextureLocation(player);
        double px = Mth.lerp(partialTick, player.xo, player.getX());
        double py = Mth.lerp(partialTick, player.yo, player.getY());
        double pz = Mth.lerp(partialTick, player.zo, player.getZ());
        float now = player.tickCount + partialTick;
        float scale = player.getScale();
        for (Ghost ghost : s.ghosts) {
            float life = (now - ghost.age()) / GHOST_LIFE;
            if (life >= 1f) {
                continue;
            }
            double dx = ghost.x() - px;
            double dy = ghost.y() - py;
            double dz = ghost.z() - pz;
            if (dx * dx + dy * dy + dz * dz < 0.36) {
                continue; // terlalu dekat dengan badan asli
            }
            int alpha = (int) ((1f - life) * 120f);
            int color = (alpha << 24) | (255 << 16) | (236 << 8) | 170;
            poseStack.pushPose();
            poseStack.translate(dx, dy, dz);
            poseStack.scale(scale, scale, scale);
            poseStack.mulPose(Axis.YP.rotationDegrees(180f - ghost.yaw()));
            transformBody(poseStack, ghost.tilt(), 0f, 0f, 0f, 0f);
            poseStack.scale(-1f, -1f, 1f);
            poseStack.scale(0.9375f, 0.9375f, 0.9375f);
            poseStack.translate(0f, -1.501f, 0f);
            model.renderToBuffer(poseStack, buffers.getBuffer(RenderType.entityTranslucent(texture)),
                    LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, color);
            poseStack.popPose();
        }
    }
}
