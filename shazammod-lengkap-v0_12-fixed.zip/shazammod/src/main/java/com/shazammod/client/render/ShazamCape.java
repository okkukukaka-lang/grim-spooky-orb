package com.shazammod.client.render;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.joml.Matrix4f;
import org.joml.Vector3f;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamItems;
import com.shazammod.ShazamMod;
import com.shazammod.client.anim.ShazamPoses;

import net.minecraft.core.BlockPos;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;

/**
 * Jubah dan hood 3D berfisika saat jadi Shazam (dan saat memakai Kostum Shazam).
 *
 * Fisikanya dihitung tiap frame dengan langkah kecil tetap (120 per detik), bukan cuma 20 kali per detik,
 * jadi gerakannya halus di FPS berapa pun. Gaya yang bekerja seperti kain sungguhan: gravitasi, hambatan
 * udara yang mendorong permukaan kain sesuai sudutnya, kibaran yang makin cepat seiring kecepatan, angin
 * sekitar (lebih kencang saat hujan atau badai, nggak ada di dalam ruangan), dan bagian yang terlindung di
 * belakang punggung. Saat digambar, permukaan kain dihaluskan supaya lipatannya melengkung.
 *
 * Tekstur kain: assets/shazammod/textures/entity/shazam_cape_cloth.png
 */
public final class ShazamCape {
    private ShazamCape() {}

    public static final ResourceLocation TEXTURE = ShazamMod.id("textures/entity/shazam_cape_cloth.png");

    // ======= Urutan muncul saat berubah (tick sejak kilau kostum mulai) =======
    public static final int EMBLEM_APPEAR = 3;
    private static final int CAPE_APPEAR = 5;
    private static final int HOOD_APPEAR = 8;
    private static final int HOOD_PULL = 12;

    // ======= Ukuran jubah (blok, sebelum dikali ukuran badan) =======
    private static final int COLS = 7;
    private static final int ROWS = 12;
    private static final float TOP_WIDTH = 0.62f;
    private static final float BOTTOM_WIDTH = 0.92f;
    private static final float LENGTH = 1.20f;
    private static final float SHOULDER_Y = 1.40f;
    private static final float BACK_Z = 0.17f;
    private static final float NECK_Y = 1.407f;

    // ======= Fisika (satuan blok dan tick) =======
    private static final int SUBSTEPS = 6;                // 120 langkah per detik
    private static final double DT = 1.0 / SUBSTEPS;
    private static final int MAX_STEPS = SUBSTEPS * 4;    // paling banyak 4 tick dikejar dalam satu frame
    private static final double MAX_LAG = 8.0;            // ketinggalan lebih dari ini (lag berat): lompati
    // jubah: kain tebal dan berat
    private static final double GRAVITY = 0.045;
    private static final double DRAG = 0.42;              // hambatan udara tegak lurus kain
    private static final double SKIN_DRAG = 0.08;         // gesekan udara searah permukaan kain
    private static final double DAMPING = 0.08;           // redaman di dalam kain
    private static final double TURBULENCE = 0.12;        // kibaran: ±12% dari laju aliran udara
    private static final int ITERATIONS = 4;
    // di dalam air: melayang pelan
    private static final double WATER_GRAVITY = 0.006;
    private static final double WATER_DRAG = 12.0;
    // hood: bentuknya dijaga, tapi tetap berayun
    private static final double HOOD_GRAVITY = 0.02;
    private static final double HOOD_DRAG = 0.3;
    private static final double HOOD_SKIN_DRAG = 0.05;
    private static final double HOOD_DAMPING = 0.3;
    private static final double HOOD_TURBULENCE = 0.06;
    private static final float HOOD_SPEED = 0.08f;        // naik/turun selesai dalam ±12 tick

    // ======= Tampilan =======
    private static final int CAPE_SMOOTH = 3;   // tiap sel jubah dipecah 3x3 saat digambar
    private static final int HOOD_SMOOTH = 2;
    private static final int CAPE_DRAW_COLS = (COLS - 1) * CAPE_SMOOTH + 1;
    private static final int CAPE_DRAW_ROWS = (ROWS - 1) * CAPE_SMOOTH + 1;
    private static final int HOOD_DRAW_COLS = (HoodShape.COLS - 1) * HOOD_SMOOTH + 1;
    private static final int HOOD_DRAW_ROWS = (HoodShape.ROWS - 1) * HOOD_SMOOTH + 1;
    private static final int[] CAPE_EDGE = ClothDecor.capeChain(CAPE_DRAW_COLS, CAPE_DRAW_ROWS);
    private static final int[] HOOD_EDGE = ClothDecor.hoodChain(HOOD_DRAW_COLS, HOOD_DRAW_ROWS);

    private static final double[] REST_X = new double[COLS * ROWS];
    private static final double[] REST_Y = new double[COLS * ROWS];
    private static final double[] REST_Z = new double[COLS * ROWS];

    static {
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                double v = r / (double) (ROWS - 1);
                double width = TOP_WIDTH + (BOTTOM_WIDTH - TOP_WIDTH) * v;
                int i = r * COLS + c;
                REST_X[i] = (c / (double) (COLS - 1) - 0.5) * width;
                REST_Y[i] = SHOULDER_Y - v * LENGTH;
                REST_Z[i] = BACK_Z + v * 0.05;
            }
        }
    }

    private static final class Gear {
        ClothSim cape;
        ClothSim hood;
        double simTime = Double.NaN;   // waktu fisika (tick), sedikit di depan waktu render
        double phase;                  // fase kibaran jubah
        double hoodPhase;
        float hoodDown;                // 0 = dipakai, 1 = diturunkan (langkah sekarang)
        float hoodDownO;               // ... langkah sebelumnya (buat interpolasi render)
        float frameYaw;                // arah badan asli di frame ini (buat koreksi pratinjau inventory)
        double wind;                   // kekuatan angin sekitar di frame ini
        float[] worldHead;             // pose kepala dari render dunia terakhir
        MatrixFrame lastHead;          // ruang kepala langkah lalu (hood ikut menoleh)
        boolean hoodTarget;            // tujuan hood terakhir (true = dipakai)
        double hoodTargetSince;        // kapan tujuan itu berubah (buat menunggu animasi tangan)
    }

    private static final Map<Integer, Gear> GEAR = new HashMap<>();
    private static long clientTicks;

    public static void clear() {
        GEAR.clear();
    }

    // ------------------------------------------------------------------ kapan dipakai

    /** Tick sejak kilau kostum mulai, 1000 kalau sudah lama jadi Shazam, atau -1 kalau bukan Shazam. */
    public static float revealTime(AbstractClientPlayer player, float partialTick) {
        if (!ShazamClientState.isTransformed(player.getId())) {
            return -1f;
        }
        if (ShazamPoses.suitIn(player)) {
            float t = ShazamPoses.suitTicks(player, partialTick);
            if (t >= 0f) {
                return t;
            }
        }
        return 1000f;
    }

    private static boolean wearsSuit(AbstractClientPlayer player) {
        return player.getItemBySlot(EquipmentSlot.CHEST).is(ShazamItems.SHAZAM_SUIT.get());
    }

    public static boolean hasCape(AbstractClientPlayer player) {
        ItemStack chest = player.getItemBySlot(EquipmentSlot.CHEST);
        if (player.isInvisible() || chest.is(Items.ELYTRA)) {
            return false;
        }
        return revealTime(player, 0f) >= CAPE_APPEAR || wearsSuit(player);
    }

    public static boolean hasHood(AbstractClientPlayer player) {
        return !player.isInvisible() && (revealTime(player, 0f) >= HOOD_APPEAR || wearsSuit(player));
    }

    private static double crouchOffset(AbstractClientPlayer player) {
        return player.isCrouching() ? -0.125 * player.getScale() : 0.0;
    }

    private static float smooth(float k) {
        k = Mth.clamp(k, 0f, 1f);
        return k * k * (3f - 2f * k);
    }

    // ------------------------------------------------------------------ ruang badan, kepala & leher

    /** Ruang lokal yang diikat ke posisi dunia. */
    private static final class MatrixFrame implements HoodShape.Frame {
        private final Matrix4f world;
        private final Matrix4f local;
        private final double ox, oy, oz;
        private final Vector3f v = new Vector3f();

        MatrixFrame(Matrix4f matrix, double ox, double oy, double oz) {
            this.world = new Matrix4f(matrix);
            this.local = new Matrix4f(matrix).invert();
            this.ox = ox;
            this.oy = oy;
            this.oz = oz;
        }

        @Override
        public void toLocal(double[] p) {
            v.set((float) (p[0] - ox), (float) (p[1] - oy), (float) (p[2] - oz));
            local.transformPosition(v);
            p[0] = v.x; p[1] = v.y; p[2] = v.z;
        }

        @Override
        public void toWorld(double[] p) {
            v.set((float) p[0], (float) p[1], (float) p[2]);
            world.transformPosition(v);
            p[0] = ox + v.x; p[1] = oy + v.y; p[2] = oz + v.z;
        }

        double[] direction(float x, float y, float z) {
            Vector3f d = world.transformDirection(new Vector3f(x, y, z)).normalize();
            return new double[] {d.x, d.y, d.z};
        }
    }

    private static float crouchDrop(AbstractClientPlayer player) {
        return player.isCrouching() ? -0.246f : 0f;
    }

    /** Kepala: poros leher + putaran kepala (pakai pose dari animasi kalau ada). */
    private static Matrix4f headMatrix(AbstractClientPlayer player, Matrix4f body, float[] pose) {
        Matrix4f m = new Matrix4f(body);
        if (pose != null) {
            return m.translate(pose[0], pose[1], pose[2]).rotateY(pose[4]).rotateX(pose[3]);
        }
        float yaw = Mth.wrapDegrees(player.yHeadRot - player.yBodyRot);
        return m.translate(0f, NECK_Y + crouchDrop(player), 0f)
                .rotateY(-yaw * Mth.DEG_TO_RAD).rotateX(-player.getXRot() * Mth.DEG_TO_RAD);
    }

    /** Leher: poros leher tanpa putaran kepala (buat hood yang diturunkan). */
    private static Matrix4f neckMatrix(AbstractClientPlayer player, Matrix4f body, float[] pose) {
        Matrix4f m = new Matrix4f(body);
        if (pose != null) {
            return m.translate(pose[0], pose[1], pose[2]).rotateX(pose[5]);
        }
        return m.translate(0f, NECK_Y + crouchDrop(player), 0f);
    }

    // ------------------------------------------------------------------ tick client: muncul & lenyap

    public static void tick(ClientLevel level) {
        clientTicks++;
        Iterator<Map.Entry<Integer, Gear>> it = GEAR.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Gear> entry = it.next();
            Gear gear = entry.getValue();
            if (!(level.getEntity(entry.getKey()) instanceof AbstractClientPlayer player)) {
                it.remove();
                continue;
            }
            if (gear.cape != null && !hasCape(player)) {
                dissolve(level, gear.cape);
                gear.cape = null;
            }
            if (gear.hood != null && !hasHood(player)) {
                dissolve(level, gear.hood);
                gear.hood = null;
                gear.lastHead = null;
            }
            if (gear.cape == null && gear.hood == null) {
                it.remove();
            }
        }
        for (AbstractClientPlayer player : level.players()) {
            boolean cape = hasCape(player);
            boolean hood = hasHood(player);
            if (!cape && !hood) {
                continue;
            }
            Gear gear = GEAR.computeIfAbsent(player.getId(), id -> new Gear());
            float reveal = revealTime(player, 1f);
            Matrix4f body = ShazamPoses.bodyMatrix(player, 1f, player.yBodyRot);
            double ox = player.getX(), oy = player.getY() + crouchOffset(player), oz = player.getZ();
            if (cape && gear.cape == null) {
                gear.cape = new ClothSim(COLS, ROWS, REST_X, REST_Y, REST_Z, 1.0, 0.5, 0.2, 0.15);
                gear.cape.addTethers(REST_X, REST_Y, REST_Z);
                placeCape(gear.cape, body, ox, oy, oz, reveal >= 0f && reveal < 20f);
            }
            if (hood && gear.hood == null) {
                gear.hood = HoodShape.create();
                boolean pulling = reveal >= 0f && reveal < HOOD_PULL;
                float start = (pulling || !ShazamClientState.isHoodUp(player.getId())) ? 1f : 0f;
                gear.hoodDown = start;
                gear.hoodDownO = start;
                gear.hoodTarget = start < 0.5f;
                gear.hoodTargetSince = clientTicks;
                MatrixFrame head = new MatrixFrame(headMatrix(player, body, gear.worldHead), ox, oy, oz);
                placeHood(gear.hood, smooth(start), head);
                gear.lastHead = head;
            }
        }
    }

    /** Kain lenyap jadi percikan cahaya (saat kembali jadi manusia). */
    private static void dissolve(ClientLevel level, ClothSim sim) {
        if (!sim.isReady()) {
            return;
        }
        for (int i = 0; i < sim.count; i += 3) {
            level.addParticle(ParticleTypes.END_ROD, sim.x[i], sim.y[i], sim.z[i],
                    (level.random.nextDouble() - 0.5) * 0.04, 0.02 + level.random.nextDouble() * 0.03,
                    (level.random.nextDouble() - 0.5) * 0.04);
        }
    }

    /** Jubah baru: saat berubah, terbentang ke belakang lalu jatuh. Selain itu langsung menggantung. */
    private static void placeCape(ClothSim sim, Matrix4f m, double ox, double oy, double oz, boolean unfurl) {
        double[] wx = new double[sim.count], wy = new double[sim.count], wz = new double[sim.count];
        Vector3f tmp = new Vector3f();
        for (int i = 0; i < sim.count; i++) {
            double v = (i / COLS) / (double) (ROWS - 1);
            if (unfurl) {
                tmp.set((float) REST_X[i], (float) (SHOULDER_Y - 0.05 * v), (float) (BACK_Z + LENGTH * v));
            } else {
                tmp.set((float) REST_X[i], (float) REST_Y[i], (float) REST_Z[i]);
            }
            m.transformPosition(tmp);
            wx[i] = ox + tmp.x; wy[i] = oy + tmp.y; wz[i] = oz + tmp.z;
        }
        sim.reset(wx, wy, wz);
    }

    /** Pasang hood langsung di bentuknya (dipakai atau terbalik di belakang leher). */
    private static void placeHood(ClothSim sim, float down, HoodShape.Frame head) {
        double[] wx = new double[sim.count], wy = new double[sim.count], wz = new double[sim.count];
        double[] p = new double[3];
        for (int i = 0; i < sim.count; i++) {
            HoodShape.flipped(i, Math.PI * down, p);
            head.toWorld(p);
            wx[i] = p[0]; wy[i] = p[1]; wz[i] = p[2];
        }
        sim.reset(wx, wy, wz);
    }

    // ------------------------------------------------------------------ tiap frame: fisika dengan langkah kecil tetap

    /** Dipanggil sekali tiap frame sebelum dunia digambar. */
    public static void frame(ClientLevel level, float partialTick) {
        if (GEAR.isEmpty()) {
            return;
        }
        double now = clientTicks - 1 + partialTick;
        for (Map.Entry<Integer, Gear> entry : GEAR.entrySet()) {
            if (!(level.getEntity(entry.getKey()) instanceof AbstractClientPlayer player)) {
                continue;
            }
            Gear gear = entry.getValue();
            gear.frameYaw = Mth.rotLerp(partialTick, player.yBodyRotO, player.yBodyRot);
            gear.wind = windStrength(level, player);
            if (Double.isNaN(gear.simTime) || now - gear.simTime > MAX_LAG || gear.simTime - now > 1.0) {
                gear.simTime = now;   // baru mulai atau lag berat: lanjut dari sini
                continue;
            }
            int steps = 0;
            while (gear.simTime < now && steps < MAX_STEPS) {
                gear.simTime += DT;
                step(player, gear, gear.simTime);
                steps++;
            }
            if (gear.simTime < now) {
                gear.simTime = now;
            }
        }
    }

    /** Angin sekitar: nggak ada di dalam ruangan atau di air, lebih kencang saat hujan dan badai. */
    private static double windStrength(ClientLevel level, AbstractClientPlayer player) {
        if (player.isInWater()) {
            return 0.0;
        }
        BlockPos pos = BlockPos.containing(player.getEyePosition());
        if (!level.canSeeSky(pos)) {
            return 0.0;
        }
        if (level.isThundering()) {
            return CapeAir.THUNDER;
        }
        return level.isRainingAt(pos) ? CapeAir.RAIN : 1.0;
    }

    private static void step(AbstractClientPlayer player, Gear gear, double time) {
        float p = (float) Mth.clamp(time - (clientTicks - 1), 0.0, 1.0);   // posisi di antara tick lalu dan sekarang
        float yaw = Mth.rotLerp(p, player.yBodyRotO, player.yBodyRot);
        Matrix4f body = ShazamPoses.bodyMatrix(player, p, yaw);
        double ox = Mth.lerp(p, player.xo, player.getX());
        double oy = Mth.lerp(p, player.yo, player.getY()) + crouchOffset(player);
        double oz = Mth.lerp(p, player.zo, player.getZ());
        double vx = player.getX() - player.xo, vy = player.getY() - player.yo, vz = player.getZ() - player.zo;
        double[] ambient = new double[3];
        CapeAir.ambient(time, gear.wind, ambient);
        MatrixFrame bodyFrame = new MatrixFrame(body, ox, oy, oz);
        double[] side = bodyFrame.direction(1f, 0f, 0f);
        double[] back = bodyFrame.direction(0f, 0f, 1f);
        boolean water = player.isInWater();
        if (gear.cape != null) {
            stepCape(player, gear, body, bodyFrame, ox, oy, oz, ambient, vx, vy, vz, side, back, water);
        }
        if (gear.hood != null) {
            stepHood(player, gear, body, ox, oy, oz, ambient, vx, vy, vz, side, back, water, revealTime(player, p), p);
        }
    }

    private static void stepCape(AbstractClientPlayer player, Gear gear, Matrix4f m, MatrixFrame bodyFrame,
                                 double ox, double oy, double oz, double[] ambient, double vx, double vy, double vz,
                                 double[] side, double[] back, boolean water) {
        ClothSim sim = gear.cape;
        Vector3f tmp = new Vector3f();
        double[] ax = new double[COLS], ay = new double[COLS], az = new double[COLS];
        double cx = 0, cy = 0, cz = 0;
        for (int c = 0; c < COLS; c++) {
            tmp.set((float) REST_X[c], (float) REST_Y[c], (float) REST_Z[c]);
            m.transformPosition(tmp);
            ax[c] = ox + tmp.x; ay[c] = oy + tmp.y; az[c] = oz + tmp.z;
            cx += ax[c]; cy += ay[c]; cz += az[c];
        }
        if (sim.distanceToCenter(cx / COLS, cy / COLS, cz / COLS) > 8.0) {
            placeCape(sim, m, ox, oy, oz, false);   // teleport: pasang ulang
            return;
        }
        double flow = CapeAir.flow(ambient, vx, vy, vz);
        CapeAir.fill(sim, ambient, vx, vy, vz, bodyFrame, side, back, gear.phase,
                water ? 0.0 : TURBULENCE, water ? WATER_DRAG : 1.0, true);
        gear.phase += CapeAir.FLUTTER_RATE * flow * DT;

        Matrix4f inverse = new Matrix4f(m).invert();
        double floor = player.onGround() ? player.getY() + 0.03 : Double.NEGATIVE_INFINITY;
        ClothSim.Collider collider = (s, i) -> {
            tmp.set((float) (s.x[i] - ox), (float) (s.y[i] - oy), (float) (s.z[i] - oz));
            inverse.transformPosition(tmp);
            boolean moved = false;
            if (Math.abs(tmp.x) < 0.36f && tmp.y > 0.05f && tmp.y < 1.47f && tmp.z < 0.15f) {
                tmp.z = 0.15f;   // punggung: kain tetap di belakang badan (juga saat terbang rebah)
                moved = true;
            }
            if (Math.abs(tmp.x) < 0.3f && tmp.y > 1.48f && tmp.y < 1.95f && Math.abs(tmp.z) < 0.3f) {
                float toBack = 0.3f - tmp.z, toTop = 1.95f - tmp.y, toLeft = tmp.x + 0.3f, toRight = 0.3f - tmp.x;
                float min = Math.min(Math.min(toBack, toTop), Math.min(toLeft, toRight));
                if (min == toBack) {
                    tmp.z = 0.3f;
                } else if (min == toTop) {
                    tmp.y = 1.95f;
                } else if (min == toLeft) {
                    tmp.x = -0.3f;
                } else {
                    tmp.x = 0.3f;
                }
                moved = true;
            }
            if (moved) {
                m.transformPosition(tmp);
                s.x[i] = ox + tmp.x; s.y[i] = oy + tmp.y; s.z[i] = oz + tmp.z;
                // gesekan: kain yang menempel di badan melambat
                s.px[i] += (s.x[i] - s.px[i]) * 0.15; s.py[i] += (s.y[i] - s.py[i]) * 0.15; s.pz[i] += (s.z[i] - s.pz[i]) * 0.15;
            }
            if (s.y[i] < floor) {
                s.y[i] = floor;
                s.px[i] += (s.x[i] - s.px[i]) * 0.3; s.pz[i] += (s.z[i] - s.pz[i]) * 0.3;
            }
        };
        sim.step(DT, ax, ay, az, water ? WATER_GRAVITY : GRAVITY, DRAG, SKIN_DRAG, DAMPING, ITERATIONS,
                player.getScale(), collider);
    }

    private static void stepHood(AbstractClientPlayer player, Gear gear, Matrix4f body, double ox, double oy, double oz,
                                 double[] ambient, double vx, double vy, double vz, double[] side, double[] back,
                                 boolean water, float reveal, float p) {
        ClothSim sim = gear.hood;
        boolean pulling = reveal >= 0f && reveal < HOOD_PULL;   // saat berubah: hood di belakang leher dulu
        boolean up = ShazamClientState.isHoodUp(player.getId()) && !pulling;
        double now = clientTicks - 1 + p;
        if (up != gear.hoodTarget) {
            gear.hoodTarget = up;
            gear.hoodTargetSince = now;
        }
        // Dipakai/dilepas dengan tangan: hood baru bergerak setelah tangan memegangnya
        float speed = HOOD_SPEED;
        ShazamAnim anim = ShazamPoses.currentAnim(player);
        if (anim == ShazamAnim.HOOD_UP || anim == ShazamAnim.HOOD_DOWN) {
            speed = ShazamPoses.animTime(player, p) < ShazamAnim.HOOD_GRAB ? 0f : 1f / ShazamAnim.HOOD_MOVE;
        } else if (now - gear.hoodTargetSince < 2.0 && !pulling) {
            speed = 0f;   // tunggu sebentar: animasi tangannya mungkin baru sampai
        }
        gear.hoodDownO = gear.hoodDown;
        gear.hoodDown = Mth.approach(gear.hoodDown, up ? 0f : 1f, (float) (speed * DT));
        float down = smooth(gear.hoodDown);

        MatrixFrame head = new MatrixFrame(headMatrix(player, body, gear.worldHead), ox, oy, oz);
        MatrixFrame neck = new MatrixFrame(neckMatrix(player, body, gear.worldHead), ox, oy, oz);
        int cols = HoodShape.COLS;
        double[] ax = new double[cols], ay = new double[cols], az = new double[cols];
        double[] rimPos = new double[3];
        double cx = 0, cy = 0, cz = 0;
        for (int c = 0; c < cols; c++) {
            HoodShape.rim(c, down, head, neck, rimPos);
            ax[c] = rimPos[0]; ay[c] = rimPos[1]; az[c] = rimPos[2];
            cx += rimPos[0]; cy += rimPos[1]; cz += rimPos[2];
        }
        if (gear.lastHead == null || sim.distanceToCenter(cx / cols, cy / cols, cz / cols) > 8.0) {
            placeHood(sim, down, head);   // teleport: pasang ulang
            gear.lastHead = head;
            return;
        }
        double flow = CapeAir.flow(ambient, vx, vy, vz);
        CapeAir.fill(sim, ambient, vx, vy, vz, neck, side, back, gear.hoodPhase,
                water ? 0.0 : HOOD_TURBULENCE, water ? WATER_DRAG : 1.0, false);
        gear.hoodPhase += CapeAir.FLUTTER_RATE * flow * DT;

        ClothSim.Collider collider = HoodShape.collider(head, neck);
        sim.snapshot();
        HoodShape.follow(sim, gear.lastHead, head, HoodShape.FOLLOW_TURN);
        sim.simulate(DT, ax, ay, az, water ? WATER_GRAVITY : HOOD_GRAVITY, HOOD_DRAG, HOOD_SKIN_DRAG, HOOD_DAMPING,
                HoodShape.iterations(down), player.getScale(), collider);
        HoodShape.settle(sim, down, head, collider, DT);
        gear.lastHead = head;
    }

    // ------------------------------------------------------------------ render

    /** Dipanggil dari RenderPlayerEvent.Post (titik asal = posisi render pemain). */
    public static void render(AbstractClientPlayer player, PlayerRenderer renderer, PoseStack poseStack,
                              MultiBufferSource buffers, float partialTick, int packedLight) {
        Gear gear = GEAR.get(player.getId());
        if (gear == null || player.isInvisible() || Double.isNaN(gear.simTime)) {
            return;
        }
        Vec3 offset = renderer.getRenderOffset(player, partialTick);
        double ox = Mth.lerp(partialTick, player.xo, player.getX()) + offset.x;
        double oy = Mth.lerp(partialTick, player.yo, player.getY()) + offset.y;
        double oz = Mth.lerp(partialTick, player.zo, player.getZ()) + offset.z;
        // posisi kain di waktu frame ini: di antara dua langkah fisika terakhir
        double now = clientTicks - 1 + partialTick;
        float alpha = (float) Mth.clamp(1.0 - (gear.simTime - now) / DT, 0.0, 1.0);

        // Saat pratinjau inventory, badan diputar sementara: kain ikut dikoreksi
        float renderYaw = Mth.rotLerp(partialTick, player.yBodyRotO, player.yBodyRot);
        Matrix4f renderM = ShazamPoses.bodyMatrix(player, partialTick, renderYaw);
        Matrix4f realM = ShazamPoses.bodyMatrix(player, partialTick, gear.frameYaw);
        Matrix4f correction = new Matrix4f(renderM).mul(realM.invert());
        float[] headPose = ShazamPoses.headPose(player);
        if (Math.abs(Mth.wrapDegrees(renderYaw - gear.frameYaw)) < 0.5f) {
            gear.worldHead = headPose;   // render dunia: simpan pose kepala buat fisika
        }

        VertexConsumer consumer = buffers.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        PoseStack.Pose pose = poseStack.last();
        Vector3f tmp = new Vector3f();
        float[][] cape = null;   // {x, y, z, nx, ny, nz} tiap titik (sudah dihaluskan), buat list emas & lambang
        float[][] hood = null;

        if (gear.cape != null && gear.cape.isReady() && hasCape(player)) {
            ClothSim sim = gear.cape;
            float[] vx = new float[sim.count], vy = new float[sim.count], vz = new float[sim.count];
            for (int i = 0; i < sim.count; i++) {
                if (i < COLS) {
                    tmp.set((float) REST_X[i], (float) REST_Y[i], (float) REST_Z[i]);   // menempel persis di bahu
                    renderM.transformPosition(tmp);
                } else {
                    interpolated(sim, i, alpha, ox, oy, oz, tmp);
                    correction.transformPosition(tmp);
                }
                vx[i] = tmp.x; vy[i] = tmp.y; vz[i] = tmp.z;
            }
            cape = smoothed(vx, vy, vz, COLS, ROWS, CAPE_SMOOTH);
            grid(consumer, pose, cape, CAPE_DRAW_COLS, CAPE_DRAW_ROWS, 0f, 1f, packedLight);
        }

        if (gear.hood != null && gear.hood.isReady() && hasHood(player)) {
            ClothSim sim = gear.hood;
            int cols = HoodShape.COLS;
            float down = smooth(Mth.lerp(alpha, gear.hoodDownO, gear.hoodDown));
            MatrixFrame head = new MatrixFrame(headMatrix(player, renderM, headPose), 0, 0, 0);
            MatrixFrame neck = new MatrixFrame(neckMatrix(player, renderM, headPose), 0, 0, 0);
            float[] vx = new float[sim.count], vy = new float[sim.count], vz = new float[sim.count];
            double[] p = new double[3];
            for (int i = 0; i < sim.count; i++) {
                if (i < cols) {
                    HoodShape.rim(i, down, head, neck, p);   // pinggiran menempel persis di wajah/leher
                    vx[i] = (float) p[0]; vy[i] = (float) p[1]; vz[i] = (float) p[2];
                } else {
                    interpolated(sim, i, alpha, ox, oy, oz, tmp);
                    correction.transformPosition(tmp);
                    vx[i] = tmp.x; vy[i] = tmp.y; vz[i] = tmp.z;
                }
            }
            hood = smoothed(vx, vy, vz, cols, HoodShape.ROWS, HOOD_SMOOTH);
            grid(consumer, pose, hood, HOOD_DRAW_COLS, HOOD_DRAW_ROWS, 0f, 0.25f, packedLight);
        }

        // Hiasan: list emas timbul di tepi, lalu lambang 3D bercahaya di tengah punggung jubah.
        // (Buffer kain di atas nggak dipakai lagi setelah ganti jenis render.)
        if (cape != null || hood != null) {
            VertexConsumer gold = buffers.getBuffer(RenderType.entityCutoutNoCull(CapeDecor.WHITE));
            if (cape != null) {
                CapeDecor.trim(gold, pose, cape[0], cape[1], cape[2], cape[3], cape[4], cape[5],
                        CAPE_DRAW_COLS, CAPE_DRAW_ROWS, CAPE_EDGE, CapeDecor.CAPE_TRIM_WIDTH, packedLight);
            }
            if (hood != null) {
                CapeDecor.trim(gold, pose, hood[0], hood[1], hood[2], hood[3], hood[4], hood[5],
                        HOOD_DRAW_COLS, HOOD_DRAW_ROWS, HOOD_EDGE, CapeDecor.HOOD_TRIM_WIDTH, packedLight);
            }
            if (cape != null) {
                float reveal = revealTime(player, partialTick);
                float flash = reveal >= 0f ? Mth.clamp(1f - (reveal - CAPE_APPEAR) / 12f, 0f, 1f) : 0f;
                CapeDecor.backEmblem(buffers, pose, cape[0], cape[1], cape[2], cape[3], cape[4], cape[5],
                        CAPE_DRAW_COLS, CAPE_DRAW_ROWS, TOP_WIDTH, BOTTOM_WIDTH, LENGTH,
                        player.tickCount + partialTick, flash);
            }
        }
    }

    private static void interpolated(ClothSim sim, int i, float alpha, double ox, double oy, double oz, Vector3f out) {
        out.set((float) (Mth.lerp(alpha, sim.rx[i], sim.x[i]) - ox),
                (float) (Mth.lerp(alpha, sim.ry[i], sim.y[i]) - oy),
                (float) (Mth.lerp(alpha, sim.rz[i], sim.z[i]) - oz));
    }

    /** Haluskan permukaan kain lalu hitung normalnya: {x, y, z, nx, ny, nz}. */
    private static float[][] smoothed(float[] vx, float[] vy, float[] vz, int cols, int rows, int factor) {
        float[][] g = ClothDecor.refine(vx, vy, vz, cols, rows, factor);
        int nc = (cols - 1) * factor + 1, nr = (rows - 1) * factor + 1;
        float[] nx = new float[g[0].length], ny = new float[g[0].length], nz = new float[g[0].length];
        ClothDecor.normals(g[0], g[1], g[2], nc, nr, nx, ny, nz);
        return new float[][] {g[0], g[1], g[2], nx, ny, nz};
    }

    /** Gambar kain sebagai grid segi empat. g = {x, y, z, nx, ny, nz}. */
    private static void grid(VertexConsumer vc, PoseStack.Pose pose, float[][] g, int cols, int rows,
                             float v0, float v1, int light) {
        for (int r = 0; r < rows - 1; r++) {
            for (int c = 0; c < cols - 1; c++) {
                int a = r * cols + c;
                gridVertex(vc, pose, g, a, cols, rows, v0, v1, light);
                gridVertex(vc, pose, g, a + cols, cols, rows, v0, v1, light);
                gridVertex(vc, pose, g, a + cols + 1, cols, rows, v0, v1, light);
                gridVertex(vc, pose, g, a + 1, cols, rows, v0, v1, light);
            }
        }
    }

    private static void gridVertex(VertexConsumer vc, PoseStack.Pose pose, float[][] g, int i, int cols, int rows,
                                   float v0, float v1, int light) {
        float u = (i % cols) / (float) (cols - 1);
        float v = v0 + (v1 - v0) * ((i / cols) / (float) (rows - 1));
        vc.addVertex(pose, g[0][i], g[1][i], g[2][i]).setColor(255, 255, 255, 255).setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(pose, g[3][i], g[4][i], g[5][i]);
    }
}
