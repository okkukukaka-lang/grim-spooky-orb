package com.shazammod.client.fx;

import net.neoforged.neoforge.client.event.ComputeFovModifierEvent;

/** Pandangan melebar sesaat saat Kilat Mercury, biar terasa ngebut. */
public final class FovKick {
    private FovKick() {}

    private static float kick;

    public static void kick(float amount) {
        kick = Math.max(kick, amount);
    }

    public static void clear() {
        kick = 0f;
    }

    public static void tick() {
        kick = Math.max(0f, kick - 0.03f);
    }

    public static void apply(ComputeFovModifierEvent event) {
        if (kick > 0f) {
            event.setNewFovModifier(event.getNewFovModifier() * (1f + kick));
        }
    }
}
