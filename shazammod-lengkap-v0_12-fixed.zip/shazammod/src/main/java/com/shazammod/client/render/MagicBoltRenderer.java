package com.shazammod.client.render;

import org.joml.Matrix4f;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.MagicBolt;

import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;

/**
 * Petir sihir emas: jalur zig-zag dari langit dengan tiga lapis cahaya
 * (pendar luar, emas, inti putih) dan beberapa cabang. Bentuknya berganti tiap 2 tick dan berkedip.
 * Petir transformasi turun dulu dari langit (ujungnya bercahaya dan memercik) sebelum menyambar penuh;
 * jalurnya sama, jadi saat menyambar bentuknya menyambung.
 */
public class MagicBoltRenderer extends EntityRenderer<MagicBolt> {
    private static final int SEGMENTS = 22;
    private static final float SEGMENT_HEIGHT = 4.0f;

    public MagicBoltRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public void render(MagicBolt bolt, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        float age = bolt.age() + partialTick;
        float size = bolt.boltSize();
        int descent = bolt.descent();
        if (descent > 0 && age < descent) {
            renderDescent(bolt, age / descent, age, size, poseStack, buffer);
            return;
        }
        float strikeAge = age - descent;
        float strength = flicker(strikeAge);
        if (strength <= 0.01f) {
            return;
        }
        RandomSource random = RandomSource.create(bolt.getId() * 31L + (long) (strikeAge / 2f));

        float[] xs = new float[SEGMENTS + 1];
        float[] zs = new float[SEGMENTS + 1];
        for (int i = 1; i <= SEGMENTS; i++) {
            xs[i] = xs[i - 1] + (random.nextFloat() - 0.5f) * 1.6f * size;
            zs[i] = zs[i - 1] + (random.nextFloat() - 0.5f) * 1.6f * size;
        }

        VertexConsumer consumer = buffer.getBuffer(RenderType.lightning());
        Matrix4f pose = poseStack.last().pose();
        for (int i = 0; i < SEGMENTS; i++) {
            float y1 = i * SEGMENT_HEIGHT;
            float y2 = (i + 1) * SEGMENT_HEIGHT;
            segment(consumer, pose, xs[i], y1, zs[i], xs[i + 1], y2, zs[i + 1], 0.85f * size, 255, 150, 40, (int) (55 * strength));
            segment(consumer, pose, xs[i], y1, zs[i], xs[i + 1], y2, zs[i + 1], 0.38f * size, 255, 210, 90, (int) (120 * strength));
            segment(consumer, pose, xs[i], y1, zs[i], xs[i + 1], y2, zs[i + 1], 0.14f * size, 255, 250, 225, (int) (230 * strength));
        }

        // Cabang-cabang yang menjalar ke bawah
        int branches = 2 + (int) (size * 1.5f);
        for (int b = 0; b < branches; b++) {
            int start = 3 + random.nextInt(SEGMENTS - 6);
            float x = xs[start];
            float y = start * SEGMENT_HEIGHT;
            float z = zs[start];
            float dirX = (random.nextFloat() - 0.5f) * 3.0f * size;
            float dirZ = (random.nextFloat() - 0.5f) * 3.0f * size;
            int length = 3 + random.nextInt(4);
            for (int i = 0; i < length; i++) {
                float nx = x + dirX * 0.5f + (random.nextFloat() - 0.5f) * size;
                float ny = y - SEGMENT_HEIGHT * 0.8f;
                float nz = z + dirZ * 0.5f + (random.nextFloat() - 0.5f) * size;
                float fade = 1f - i / (float) length;
                segment(consumer, pose, x, y, z, nx, ny, nz, 0.3f * size * fade, 255, 200, 80, (int) (90 * strength * fade));
                segment(consumer, pose, x, y, z, nx, ny, nz, 0.08f * size, 255, 245, 210, (int) (200 * strength * fade));
                x = nx;
                y = ny;
                z = nz;
            }
        }
    }

    /**
     * Petir sedang turun: jalur dari langit sampai ujungnya saja (progress 0 = di langit, 1 = sampai kepalan),
     * dengan bola cahaya di ujung dan percikan bercabang yang berganti tiap tick.
     */
    private void renderDescent(MagicBolt bolt, float progress, float age, float size, PoseStack poseStack,
                               MultiBufferSource buffer) {
        RandomSource random = RandomSource.create(bolt.getId() * 31L);   // jalur sama dengan saat menyambar
        float[] xs = new float[SEGMENTS + 1];
        float[] zs = new float[SEGMENTS + 1];
        for (int i = 1; i <= SEGMENTS; i++) {
            xs[i] = xs[i - 1] + (random.nextFloat() - 0.5f) * 1.6f * size;
            zs[i] = zs[i - 1] + (random.nextFloat() - 0.5f) * 1.6f * size;
        }
        float top = SEGMENTS * SEGMENT_HEIGHT;
        float reach = (float) Math.pow(Mth.clamp(progress, 0f, 1f), 1.35);   // makin dekat makin cepat
        float tipY = top * (1f - reach);
        float pulse = 0.75f + 0.25f * Mth.sin(age * 2.2f);
        VertexConsumer consumer = buffer.getBuffer(RenderType.lightning());
        Matrix4f pose = poseStack.last().pose();
        float tipX = xs[SEGMENTS];
        float tipZ = zs[SEGMENTS];
        for (int i = SEGMENTS - 1; i >= 0; i--) {
            float y1 = i * SEGMENT_HEIGHT;
            float y2 = (i + 1) * SEGMENT_HEIGHT;
            if (y2 <= tipY) {
                break;
            }
            float x1 = xs[i], z1 = zs[i];
            if (y1 < tipY) {   // segmen paling bawah dipotong di ujung petir
                float f = (tipY - y1) / SEGMENT_HEIGHT;
                x1 = Mth.lerp(f, xs[i], xs[i + 1]);
                z1 = Mth.lerp(f, zs[i], zs[i + 1]);
                y1 = tipY;
            }
            tipX = x1;
            tipZ = z1;
            segment(consumer, pose, x1, y1, z1, xs[i + 1], y2, zs[i + 1], 0.55f * size, 255, 150, 40, (int) (45 * pulse));
            segment(consumer, pose, x1, y1, z1, xs[i + 1], y2, zs[i + 1], 0.24f * size, 255, 210, 90, (int) (110 * pulse));
            segment(consumer, pose, x1, y1, z1, xs[i + 1], y2, zs[i + 1], 0.09f * size, 255, 250, 225, (int) (230 * pulse));
        }
        // Bola cahaya di ujung petir
        float flare = 0.7f * size * pulse;
        segment(consumer, pose, tipX, tipY - flare, tipZ, tipX, tipY + flare, tipZ, flare * 0.5f, 255, 225, 130, 110);
        segment(consumer, pose, tipX - flare, tipY, tipZ, tipX + flare, tipY, tipZ, flare * 0.35f, 255, 240, 190, 140);
        segment(consumer, pose, tipX, tipY, tipZ - flare, tipX, tipY, tipZ + flare, flare * 0.35f, 255, 240, 190, 140);
        // Percikan bercabang dari ujung, mencari jalan ke bawah
        RandomSource sparks = RandomSource.create(bolt.getId() * 17L + (long) age);
        for (int b = 0; b < 3; b++) {
            float x = tipX, y = tipY, z = tipZ;
            int length = 1 + sparks.nextInt(3);
            for (int k = 0; k < length; k++) {
                float nx = x + (sparks.nextFloat() - 0.5f) * 1.4f * size;
                float ny = y - (0.6f + sparks.nextFloat() * 0.8f) * size;
                float nz = z + (sparks.nextFloat() - 0.5f) * 1.4f * size;
                float fade = 1f - k / (float) length;
                segment(consumer, pose, x, y, z, nx, ny, nz, 0.06f * size, 255, 245, 210, (int) (200 * fade * pulse));
                x = nx;
                y = ny;
                z = nz;
            }
        }
    }

    private static float flicker(float age) {
        if (age > MagicBolt.LIFETIME) {
            return 0f;
        }
        float fade = 1f - Math.max(0f, age - 4f) / (MagicBolt.LIFETIME - 4f);
        int step = (int) age;
        if (step > 3 && step % 3 == 1) {
            return fade * 0.35f; // berkedip
        }
        return fade;
    }

    /** Kotak tipis dari titik 1 ke titik 2 (empat sisi). */
    private static void segment(VertexConsumer vc, Matrix4f m, float x1, float y1, float z1, float x2, float y2, float z2,
                                float w, int r, int g, int b, int a) {
        if (a <= 0 || w <= 0f) {
            return;
        }
        quad(vc, m, x1 - w, y1, z1 - w, x1 + w, y1, z1 - w, x2 + w, y2, z2 - w, x2 - w, y2, z2 - w, r, g, b, a);
        quad(vc, m, x1 + w, y1, z1 - w, x1 + w, y1, z1 + w, x2 + w, y2, z2 + w, x2 + w, y2, z2 - w, r, g, b, a);
        quad(vc, m, x1 + w, y1, z1 + w, x1 - w, y1, z1 + w, x2 - w, y2, z2 + w, x2 + w, y2, z2 + w, r, g, b, a);
        quad(vc, m, x1 - w, y1, z1 + w, x1 - w, y1, z1 - w, x2 - w, y2, z2 - w, x2 - w, y2, z2 + w, r, g, b, a);
    }

    /** Satu sisi, digambar bolak-balik supaya kelihatan dari arah mana pun. */
    private static void quad(VertexConsumer vc, Matrix4f m,
                             float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz,
                             int r, int g, int b, int a) {
        vc.addVertex(m, ax, ay, az).setColor(r, g, b, a);
        vc.addVertex(m, bx, by, bz).setColor(r, g, b, a);
        vc.addVertex(m, cx, cy, cz).setColor(r, g, b, a);
        vc.addVertex(m, dx, dy, dz).setColor(r, g, b, a);
        vc.addVertex(m, dx, dy, dz).setColor(r, g, b, a);
        vc.addVertex(m, cx, cy, cz).setColor(r, g, b, a);
        vc.addVertex(m, bx, by, bz).setColor(r, g, b, a);
        vc.addVertex(m, ax, ay, az).setColor(r, g, b, a);
    }

    @Override
    public ResourceLocation getTextureLocation(MagicBolt bolt) {
        return TextureAtlas.LOCATION_BLOCKS;
    }
}
