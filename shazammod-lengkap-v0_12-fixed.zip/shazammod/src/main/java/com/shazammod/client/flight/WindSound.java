package com.shazammod.client.flight;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;

/** Suara angin saat terbang; makin kencang makin keras dan tinggi. */
public class WindSound extends AbstractTickableSoundInstance {
    private final LocalPlayer player;

    public WindSound(LocalPlayer player) {
        super(SoundEvents.ELYTRA_FLYING, SoundSource.PLAYERS, SoundInstance.createUnseededRandom());
        this.player = player;
        this.looping = true;
        this.delay = 0;
        this.volume = 0.0f;
    }

    @Override
    public boolean canStartSilent() {
        return true;
    }

    @Override
    public void tick() {
        if (player.isRemoved() || !ShazamFlight.isFlying()) {
            this.stop();
            return;
        }
        this.x = player.getX();
        this.y = player.getY();
        this.z = player.getZ();
        double speed = ShazamFlight.speed();
        this.volume = (float) Mth.clamp((speed - 0.3) / 3.0, 0.0, 1.0);
        this.pitch = (float) (0.8 + Math.min(speed, 5.0) * 0.1);
    }
}
