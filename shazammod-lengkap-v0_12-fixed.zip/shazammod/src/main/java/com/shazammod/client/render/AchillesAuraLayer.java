package com.shazammod.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.client.anim.ShazamPoses;

import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/** Kulit Achilles: selubung energi emas yang berpendar di seluruh badan selama hampir kebal. */
public class AchillesAuraLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation SWIRL = ResourceLocation.withDefaultNamespace("textures/entity/creeper/creeper_armor.png");

    public AchillesAuraLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, AbstractClientPlayer player,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        float strength = ShazamPoses.auraStrength(player, partialTick);
        if (strength <= 0.01f) {
            return;
        }
        float scroll = ageInTicks * 0.01f;
        VertexConsumer consumer = buffer.getBuffer(RenderType.energySwirl(SWIRL, scroll % 1.0f, (scroll * 0.7f) % 1.0f));
        poseStack.pushPose();
        poseStack.translate(0.0f, 0.75f, 0.0f);
        poseStack.scale(1.08f, 1.05f, 1.08f);
        poseStack.translate(0.0f, -0.75f, 0.0f);
        int r = (int) (255 * strength);
        int g = (int) (190 * strength);
        int b = (int) (60 * strength);
        this.getParentModel().renderToBuffer(poseStack, consumer, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY,
                0xFF000000 | (r << 16) | (g << 8) | b);
        poseStack.popPose();
    }
}
