package com.shazammod.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.ShazamMod;

import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Hiasan jubah dan hood: list emas yang timbul di tepi kain, dan lambang 3D bercahaya di tengah punggung jubah.
 * Semuanya mengikuti bentuk kain yang sedang berkibar.
 */
public final class CapeDecor {
    private CapeDecor() {}

    public static final ResourceLocation WHITE = ShazamMod.id("textures/entity/shazam_white.png");
    /** Lambang khusus punggung (opsional). Kalau nggak ada, dipakai lambang dada. */
    public static final ResourceLocation BACK_EMBLEM = ShazamMod.id("textures/entity/shazam_cape_emblem.png");

    // ======= List emas (blok) =======
    public static final float CAPE_TRIM_WIDTH = 0.085f;
    public static final float HOOD_TRIM_WIDTH = 0.06f;
    private static final float TRIM_RAISE = 0.025f;     // seberapa timbul dari kain putih (tiap sisi)
    private static final int TRIM_MIN_LIGHT = 10;       // sedikit menyala di tempat gelap
    private static final int[] GOLD = {242, 194, 66};
    private static final int[] GOLD_EDGE = {255, 228, 128};   // tepi luar berkilau
    private static final int[] GOLD_SHADE = {184, 134, 36};   // tepi dalam berbayang

    // ======= Lambang punggung =======
    private static final float BACK_EMBLEM_WIDTH = 0.42f;   // lebar (blok)
    private static final float BACK_EMBLEM_CENTER = 0.5f;   // 0 = bahu, 1 = ujung jubah
    private static final float BACK_EMBLEM_BASE = 0.008f;   // jarak dari kain
    private static final float BACK_EMBLEM_RAISE = 0.035f;  // ketebalan (timbul)

    private static EmblemImage backImage;
    private static boolean backLoaded;

    /** Dipanggil saat resource pack dimuat ulang (F3+T). */
    public static void reset() {
        backLoaded = false;
        backImage = null;
    }

    private static EmblemImage backImage() {
        if (!backLoaded) {
            backLoaded = true;
            backImage = EmblemImage.load(BACK_EMBLEM);
            if (backImage == null) {
                backImage = ShazamEmblemLayer.image();
            }
        }
        return backImage;
    }

    private static int brighten(int light) {
        return LightTexture.pack(Math.max(LightTexture.block(light), TRIM_MIN_LIGHT), LightTexture.sky(light));
    }

    /** List emas timbul di sepanjang rantai tepi kain. */
    public static void trim(VertexConsumer vc, PoseStack.Pose pose, float[] vx, float[] vy, float[] vz,
                            float[] nx, float[] ny, float[] nz, int cols, int rows, int[] chain, float width, int light) {
        float[] quads = new float[chain.length * 4 * ClothDecor.STRIDE];
        int count = ClothDecor.trim(vx, vy, vz, nx, ny, nz, cols, rows, chain, width, TRIM_RAISE, quads);
        int lit = brighten(light);
        for (int q = 0; q < count; q++) {
            int o = q * ClothDecor.STRIDE;
            int kind = (int) quads[o + 15];
            int[] col = kind == ClothDecor.OUTER ? GOLD_EDGE : kind == ClothDecor.INNER ? GOLD_SHADE : GOLD;
            for (int v = 0; v < 4; v++) {
                vc.addVertex(pose, quads[o + v * 3], quads[o + v * 3 + 1], quads[o + v * 3 + 2])
                        .setColor(col[0], col[1], col[2], 255).setUv(0.5f, 0.5f).setOverlay(OverlayTexture.NO_OVERLAY)
                        .setLight(lit).setNormal(pose, quads[o + 12], quads[o + 13], quads[o + 14]);
            }
        }
    }

    /**
     * Lambang 3D di tengah punggung jubah: balok-balok timbul yang menempel di kain (ikut melengkung),
     * terang sendiri, dengan cahaya berdenyut, kilatan menyapu, dan pendar emas di sekelilingnya.
     */
    public static void backEmblem(MultiBufferSource buffers, PoseStack.Pose pose, float[] vx, float[] vy, float[] vz,
                                  float[] nx, float[] ny, float[] nz, int cols, int rows,
                                  float topWidth, float bottomWidth, float length, float time, float flash) {
        EmblemImage img = backImage();
        if (img == null) {
            return;
        }
        int range = EmblemImage.GLOW_RANGE;
        int gw = img.width + 2 * range + 1;
        int gh = img.height + 2 * range + 1;
        float pix = BACK_EMBLEM_WIDTH / img.width;
        float top = BACK_EMBLEM_CENTER * length - img.height * pix / 2f;

        // Titik-titik sudut piksel di permukaan kain (dilihat dari belakang: kiri gambar = kiri), dan arah ke luar
        float[] px = new float[gw * gh], py = new float[gw * gh], pz = new float[gw * gh];
        float[] ox = new float[gw * gh], oy = new float[gw * gh], oz = new float[gw * gh];
        float[] s = new float[6];
        for (int gy = 0; gy < gh; gy++) {
            for (int gx = 0; gx < gw; gx++) {
                float xOff = (gx - range - img.width / 2f) * pix;
                float t = (top + (gy - range) * pix) / length;
                float width = topWidth + (bottomWidth - topWidth) * Mth.clamp(t, 0f, 1f);
                ClothDecor.sample(vx, vy, vz, nx, ny, nz, cols, rows,
                        (0.5f + xOff / width) * (cols - 1), t * (rows - 1), s);
                int k = gy * gw + gx;
                px[k] = s[0]; py[k] = s[1]; pz[k] = s[2];
                ox[k] = -s[3]; oy[k] = -s[4]; oz[k] = -s[5];   // normal grid menghadap badan; luar = kebalikannya
            }
        }
        float base = BACK_EMBLEM_BASE;
        float raised = BACK_EMBLEM_BASE + BACK_EMBLEM_RAISE;

        // 1) Balok-balok lambang (terang sendiri)
        VertexConsumer solid = buffers.getBuffer(RenderType.entityCutoutNoCull(WHITE));
        int light = LightTexture.FULL_BRIGHT;
        for (int y = 0; y < img.height; y++) {
            for (int x = 0; x < img.width; x++) {
                if (!img.filled(x, y)) {
                    continue;
                }
                int color = img.color(x, y);
                int k00 = (y + range) * gw + (x + range), k10 = k00 + 1, k01 = k00 + gw, k11 = k01 + 1;
                float cx = (px[k00] + px[k10] + px[k01] + px[k11]) / 4f;
                float cy = (py[k00] + py[k10] + py[k01] + py[k11]) / 4f;
                float cz = (pz[k00] + pz[k10] + pz[k01] + pz[k11]) / 4f;
                // permukaan atas, menghadap keluar dari kain
                face(solid, pose, color, light, new float[][] {
                        at(px, py, pz, ox, oy, oz, k00, raised), at(px, py, pz, ox, oy, oz, k10, raised),
                        at(px, py, pz, ox, oy, oz, k11, raised), at(px, py, pz, ox, oy, oz, k01, raised)},
                        ox[k00], oy[k00], oz[k00]);
                // dinding di sisi yang bersebelahan dengan piksel kosong
                if (!img.filled(x - 1, y)) {
                    wall(solid, pose, color, light, px, py, pz, ox, oy, oz, base, raised, k00, k01, cx, cy, cz);
                }
                if (!img.filled(x + 1, y)) {
                    wall(solid, pose, color, light, px, py, pz, ox, oy, oz, base, raised, k10, k11, cx, cy, cz);
                }
                if (!img.filled(x, y - 1)) {
                    wall(solid, pose, color, light, px, py, pz, ox, oy, oz, base, raised, k00, k10, cx, cy, cz);
                }
                if (!img.filled(x, y + 1)) {
                    wall(solid, pose, color, light, px, py, pz, ox, oy, oz, base, raised, k01, k11, cx, cy, cz);
                }
            }
        }

        // 2) Kilau (aditif): denyut + kilatan menyapu di lambang, pendar emas di kain sekitarnya
        VertexConsumer glow = buffers.getBuffer(RenderType.lightning());
        float pulse = EmblemImage.pulse(time, flash);
        for (int y = 0; y < img.height; y++) {
            for (int x = 0; x < img.width; x++) {
                if (!img.filled(x, y)) {
                    continue;
                }
                float strength = 0.18f * pulse + 0.85f * img.sweep(x, y, time);
                if (strength > 0.02f) {
                    int k00 = (y + range) * gw + (x + range);
                    glowQuad(glow, pose, px, py, pz, ox, oy, oz, raised + 0.004f, k00, k00 + 1, k00 + gw + 1, k00 + gw,
                            255, 250, 225, strength);
                }
            }
        }
        for (int gy = 0; gy < gh - 1; gy++) {
            for (int gx = 0; gx < gw - 1; gx++) {
                float g = img.glow(gx, gy);
                if (g > 0f) {
                    int k00 = gy * gw + gx;
                    glowQuad(glow, pose, px, py, pz, ox, oy, oz, base * 0.5f, k00, k00 + 1, k00 + gw + 1, k00 + gw,
                            255, 205, 90, g * pulse * 0.8f);
                }
            }
        }
    }

    /** Dinding balok di antara sudut a dan b, dari kain (base) sampai permukaan (raised), menghadap menjauhi pusat piksel. */
    private static void wall(VertexConsumer vc, PoseStack.Pose pose, int color, int light,
                             float[] px, float[] py, float[] pz, float[] ox, float[] oy, float[] oz,
                             float base, float raised, int a, int b, float cx, float cy, float cz) {
        float rx = (px[a] + px[b]) / 2f - cx, ry = (py[a] + py[b]) / 2f - cy, rz = (pz[a] + pz[b]) / 2f - cz;
        face(vc, pose, color, light, new float[][] {
                at(px, py, pz, ox, oy, oz, a, base), at(px, py, pz, ox, oy, oz, b, base),
                at(px, py, pz, ox, oy, oz, b, raised), at(px, py, pz, ox, oy, oz, a, raised)}, rx, ry, rz);
    }

    /** Satu sisi balok (4 titik). Normalnya diarahkan searah (rx, ry, rz) supaya terang-gelapnya benar. */
    private static void face(VertexConsumer vc, PoseStack.Pose pose, int color, int light, float[][] p,
                             float rx, float ry, float rz) {
        float ux = p[2][0] - p[0][0], uy = p[2][1] - p[0][1], uz = p[2][2] - p[0][2];
        float vx = p[3][0] - p[1][0], vy = p[3][1] - p[1][1], vz = p[3][2] - p[1][2];
        float nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
        if (nx * rx + ny * ry + nz * rz < 0f) {
            nx = -nx; ny = -ny; nz = -nz;
        }
        float len = Mth.sqrt(nx * nx + ny * ny + nz * nz);
        if (len < 1.0E-7f) {
            nx = rx; ny = ry; nz = rz;
            len = Math.max(Mth.sqrt(nx * nx + ny * ny + nz * nz), 1.0E-7f);
        }
        int r = (color >> 16) & 0xFF, g = (color >> 8) & 0xFF, bl = color & 0xFF;
        for (float[] v : p) {
            vc.addVertex(pose, v[0], v[1], v[2]).setColor(r, g, bl, 255).setUv(0.5f, 0.5f)
                    .setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(pose, nx / len, ny / len, nz / len);
        }
    }

    private static float[] at(float[] px, float[] py, float[] pz, float[] ox, float[] oy, float[] oz, int k, float h) {
        return new float[] {px[k] + ox[k] * h, py[k] + oy[k] * h, pz[k] + oz[k] * h};
    }

    /** Segi empat cahaya (aditif) di atas kain, dua sisi. */
    private static void glowQuad(VertexConsumer vc, PoseStack.Pose pose, float[] px, float[] py, float[] pz,
                                 float[] ox, float[] oy, float[] oz, float h, int a, int b, int c, int d,
                                 int r, int g, int bl, float strength) {
        int alpha = (int) (Mth.clamp(strength, 0f, 1f) * 255f);
        int[] order = {a, b, c, d, d, c, b, a};
        for (int k : order) {
            vc.addVertex(pose, px[k] + ox[k] * h, py[k] + oy[k] * h, pz[k] + oz[k] * h).setColor(r, g, bl, alpha);
        }
    }
}
