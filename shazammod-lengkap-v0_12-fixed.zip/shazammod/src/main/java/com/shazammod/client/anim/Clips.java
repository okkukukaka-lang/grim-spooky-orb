package com.shazammod.client.anim;

import java.util.EnumMap;
import java.util.Map;

import com.shazammod.ShazamAnim;

/**
 * Semua gerakan Shazam. Panduan angka (derajat):
 * - Lengan xRot: 0 = turun, -90 = lurus ke depan, -180 = lurus ke atas, positif = ke belakang.
 * - Lengan zRot: kanan positif / kiri negatif = membuka ke samping.
 * - Lengan yRot (saat lurus ke depan): kanan negatif / kiri positif = ke arah tengah.
 * - Kaki xRot: negatif = ke depan. Kepala xRot: negatif = mendongak.
 * - tilt: positif = seluruh badan condong ke depan. drop: badan turun (blok).
 */
public final class Clips {
    private Clips() {}

    private static final Map<ShazamAnim, Clip> CLIPS = new EnumMap<>(ShazamAnim.class);

    public static Clip get(ShazamAnim anim) {
        return CLIPS.get(anim);
    }

    static {
        // Transformasi: membungkuk mengumpulkan tenaga, kepalan menembus langit, disambar petir (tick 8),
        // terangkat melayang dengan kedua lengan terbuka menerima kekuatan, lalu turun berdiri gagah
        // Transformasi: membungkuk, kepalan ke langit (tick 7), lalu ditahan menegang selama petir turun pelan
        // (tick 8-18, slow motion). Tick 18 petir mengenai: tersentak, terangkat dengan lengan terbuka, berdiri gagah.
        CLIPS.put(ShazamAnim.TRANSFORM, Clip.builder(54)
                .key(0, Ease.LINEAR).rightArm(-20, 0, -4).leftArm(4, 0, -6).head(-5, 0, 0).legs(3).tilt(0)
                .key(3, Ease.OUT_CUBIC).rightArm(18, 0, 14).leftArm(18, 0, -14).head(12, 0, 0).legs(9).tilt(12).drop(0.16f)
                .key(7, Ease.OUT_QUAD).rightArm(-178, 0, -6).leftArm(25, 0, -14).head(-42, 0, 0).legs(6).tilt(-10).drop(-0.06f)
                .key(12, Ease.IN_OUT_SINE).rightArm(-183, 0, -4).leftArm(28, 0, -16).head(-48, 0, 0).tilt(-12).drop(-0.08f)
                .key(17, Ease.IN_OUT_SINE).rightArm(-177, 0, -7).leftArm(24, 0, -13).head(-44, 0, 0).tilt(-10).drop(-0.05f)
                .key(19, Ease.OUT_QUAD).head(-18, 0, 0).tilt(-3).drop(0.12f)
                .key(24, Ease.OUT_CUBIC).rightArm(-152, 0, -34).leftArm(-152, 0, 34).head(-32, 0, 0).legs(10).tilt(-12).drop(-0.35f)
                .key(36, Ease.IN_OUT_SINE).rightArm(-158, 0, -38).leftArm(-158, 0, 38).head(-36, 0, 0).tilt(-8).drop(-0.42f)
                .key(43, Ease.IN_OUT_SINE).rightArm(-20, 0, 30).leftArm(-20, 0, -30).head(6, 0, 0).legs(10).tilt(7).drop(0.14f)
                .key(50, Ease.OUT_CUBIC).rightArm(10, 0, 24).leftArm(10, 0, -24).head(-10, 0, 0).legs(8).tilt(-3).drop(0f)
                .fade(2, 5).build());

        // Memakai hood: kedua tangan meraih ke belakang kepala (tick 5), memegang tepi hood (6),
        // menariknya ke depan lewat atas kepala sampai dahi (16), lalu turun lagi.
        CLIPS.put(ShazamAnim.HOOD_UP, Clip.builder(ShazamAnim.HOOD_TICKS)
                .key(0, Ease.LINEAR).rightArm(-20, 0, 6).leftArm(-20, 0, -6)
                .key(5, Ease.IN_OUT_SINE).rightArm(-196, 0, -12).leftArm(-196, 0, 12).head(12, 0, 0)
                .key(6, Ease.LINEAR)
                .key(16, Ease.IN_OUT_SINE).rightArm(-140, 0, -14).leftArm(-140, 0, 14).head(6, 0, 0)
                .key(18, Ease.LINEAR)
                .key(24, Ease.OUT_CUBIC).rightArm(-5, 0, 4).leftArm(-5, 0, -4).head(0, 0, 0)
                .fade(2, 4).build());

        // Melepas hood: tangan memegang tepi hood di dahi (tick 5-6), mendorongnya ke belakang lewat atas kepala
        // sambil sedikit mendongak (16), lalu turun lagi.
        CLIPS.put(ShazamAnim.HOOD_DOWN, Clip.builder(ShazamAnim.HOOD_TICKS)
                .key(0, Ease.LINEAR).rightArm(-20, 0, 6).leftArm(-20, 0, -6)
                .key(5, Ease.IN_OUT_SINE).rightArm(-145, 0, -14).leftArm(-145, 0, 14).head(8, 0, 0)
                .key(6, Ease.LINEAR)
                .key(16, Ease.IN_OUT_SINE).rightArm(-200, 0, -10).leftArm(-200, 0, 10).head(-14, 0, 0)
                .key(18, Ease.LINEAR)
                .key(24, Ease.OUT_CUBIC).rightArm(-5, 0, 4).leftArm(-5, 0, -4).head(0, 0, 0)
                .fade(2, 4).build());

        // Memanggil enam dewa: kepala tertunduk dan lengan terbuka menerima, lalu menatap roh-roh yang datang
        // sambil sedikit terangkat. Setelah tick 28 dilanjutkan TRANSFORM (kepalan ke langit, petir).
        CLIPS.put(ShazamAnim.SUMMON, Clip.builder(28)
                .key(0, Ease.LINEAR).rightArm(-8, 0, 10).leftArm(-8, 0, -10).head(10, 0, 0).tilt(2)
                .key(8, Ease.OUT_CUBIC).rightArm(-22, 0, 40).leftArm(-22, 0, -40).head(18, 0, 0).legs(3).tilt(4).drop(0.04f)
                .key(18, Ease.IN_OUT_SINE).rightArm(-30, 0, 52).leftArm(-30, 0, -52).head(-24, 0, 0).legs(2).tilt(-6).drop(-0.1f)
                .key(28, Ease.IN_OUT_SINE).rightArm(-34, 0, 56).leftArm(-34, 0, -56).head(-30, 0, 0).legs(2).tilt(-8).drop(-0.14f)
                .fade(4, 3).build());

        // Zeus Rage: membungkuk dengan kepalan mengepal, lalu meraung ke langit dengan lengan menghentak
        // ke bawah-samping (tick 9: mata menyala, petir menyambar)
        CLIPS.put(ShazamAnim.ZEUS_RAGE, Clip.builder(26)
                .key(0, Ease.OUT_CUBIC).rightArm(14, 0, 8).leftArm(14, 0, -8).head(20, 0, 0).tilt(8).drop(0.08f)
                .key(6, Ease.IN_QUAD).rightArm(26, 0, 16).leftArm(26, 0, -16).head(26, 0, 0).legs(4).tilt(13).drop(0.15f)
                .key(9, Ease.OUT_BACK).rightArm(32, 0, 44).leftArm(32, 0, -44).head(-52, 0, 0).legs(7).tilt(-16).drop(-0.04f)
                .key(19, Ease.LINEAR)
                .key(26, Ease.IN_OUT_SINE).rightArm(8, 0, 16).leftArm(8, 0, -16).head(-8, 0, 0).legs(3).tilt(-2).drop(0f)
                .fade(2, 5).build());

        // Kembali jadi manusia: kepalan ke atas lagi, petir (tick 6), badan lunglai
        CLIPS.put(ShazamAnim.REVERT, Clip.builder(22)
                .key(0, Ease.LINEAR).rightArm(-20, 0, -4).leftArm(4, 0, -6).head(-5, 0, 0)
                .key(5, Ease.OUT_CUBIC).rightArm(-178, 0, -6).leftArm(10, 0, -8).head(-35, 0, 0)
                .key(8, Ease.OUT_QUAD).rightArm(-120, 0, 0).head(-8, 0, 0).drop(0.14f)
                .key(16, Ease.IN_OUT_SINE).rightArm(0, 0, 4).leftArm(0, 0, -4).head(10, 0, 0).drop(0.04f)
                .fade(2, 5).build());

        // S - Mata Solomon: dua jari ke pelipis, berkonsentrasi
        CLIPS.put(ShazamAnim.SOLOMON_SIGHT, Clip.builder(18)
                .key(0, Ease.LINEAR).rightArm(-30, -10, 0).leftArm(3, 0, -5).head(3, 0, 0)
                .key(4, Ease.OUT_CUBIC).rightArm(-142, -34, 0).leftArm(6, 0, -8).head(14, 0, 0)
                .key(12, Ease.LINEAR)
                .key(18, Ease.IN_OUT_SINE).rightArm(-10, 0, 6).head(0, 0, 0)
                .fade(3, 5).build());

        // H - Tepukan Hercules: tangan dibentang lebar, lalu ditepuk keras di depan (tick 6)
        CLIPS.put(ShazamAnim.HERCULES_CLAP, Clip.builder(14)
                .key(0, Ease.LINEAR).rightArm(-35, 25, 0).leftArm(-35, -25, 0).head(-2, 0, 0).tilt(-2)
                .key(4, Ease.OUT_CUBIC).rightArm(-85, 80, 0).leftArm(-85, -80, 0).head(-5, 0, 0).tilt(-9)
                .key(6, Ease.OUT_BACK).rightArm(-88, -22, 0).leftArm(-88, 22, 0).tilt(8).drop(0.05f)
                .key(10, Ease.LINEAR)
                .key(14, Ease.IN_OUT_SINE).rightArm(-55, -12, 0).leftArm(-55, 12, 0).tilt(2).drop(0f)
                .fade(2, 4).build());

        // A - Atlas di tanah: kedua kepalan diangkat tinggi, siap menghantam
        CLIPS.put(ShazamAnim.ATLAS_GROUND, Clip.builder(14)
                .key(0, Ease.LINEAR).rightArm(-30, 0, 6).leftArm(-30, 0, -6).head(-5, 0, 0).tilt(-2)
                .key(4, Ease.OUT_CUBIC).rightArm(-176, 0, 14).leftArm(-176, 0, -14).head(-20, 0, 0).tilt(-10).drop(-0.15f)
                .fade(2, 4).build());

        // A - Atlas dari udara: menukik dengan kedua kepalan di atas kepala
        CLIPS.put(ShazamAnim.ATLAS_DIVE, Clip.builder(60)
                .key(0, Ease.OUT_CUBIC).rightArm(-168, 0, 12).leftArm(-168, 0, -12).head(-35, 0, 0)
                        .rightLeg(18, 0, 3).leftLeg(28, 0, -3).tilt(30)
                .key(6, Ease.IN_OUT_SINE).tilt(38)
                .fade(2, 6).build());

        // A - Atlas mendarat: kepalan menghantam tanah, badan setengah berlutut
        CLIPS.put(ShazamAnim.ATLAS_IMPACT, Clip.builder(18)
                .key(0, Ease.OUT_QUAD).rightArm(-42, -14, 0).leftArm(-42, 14, 0).head(-25, 0, 0)
                        .rightLeg(-60, 0, 8).leftLeg(40, 0, -8).tilt(30).drop(0.45f)
                .key(8, Ease.LINEAR)
                .key(18, Ease.IN_OUT_SINE).rightArm(6, 0, 18).leftArm(6, 0, -18).head(-5, 0, 0)
                        .rightLeg(0, 0, 8).leftLeg(0, 0, -8).tilt(0).drop(0f)
                .fade(1, 5).build());

        // Z - Petir Zeus: tangan menggapai langit, lalu menunjuk sasaran (petir di tick 5)
        CLIPS.put(ShazamAnim.ZEUS_CALL, Clip.builder(16)
                .key(0, Ease.LINEAR).rightArm(-30, 0, -6).leftArm(4, 0, -6).head(-5, 0, 0)
                .key(4, Ease.OUT_CUBIC).rightArm(-176, 0, -8).leftArm(10, 0, -14).head(-35, 0, 0).tilt(-5)
                .key(5, Ease.LINEAR)
                .key(8, Ease.OUT_QUAD).rightArm(-90, 0, 0).aim(1f).leftArm(25, 0, -18).head(0, 0, 0).tilt(6)
                .key(16, Ease.IN_OUT_SINE).rightArm(-70, 0, 0).tilt(2)
                .fade(2, 5).build());

        // A - Kulit Achilles: membungkuk mengumpulkan tenaga, lalu meraung dengan dada membusung
        CLIPS.put(ShazamAnim.ACHILLES_ROAR, Clip.builder(22)
                .key(0, Ease.OUT_CUBIC).rightArm(28, 0, 20).leftArm(28, 0, -20).head(18, 0, 0).tilt(10).drop(0.1f)
                .key(4, Ease.IN_QUAD).rightArm(36, 0, 26).leftArm(36, 0, -26).head(22, 0, 0).tilt(14).drop(0.16f)
                .key(7, Ease.OUT_BACK).rightArm(18, 0, 58).leftArm(18, 0, -58).head(-35, 0, 0).tilt(-14).drop(0f)
                .key(16, Ease.LINEAR)
                .key(22, Ease.IN_OUT_SINE).rightArm(4, 0, 14).leftArm(4, 0, -14).head(-5, 0, 0).tilt(-2)
                .fade(2, 5).build());

        // M - Kilat Mercury: menerjang dengan tinju di depan, badan condong rendah
        CLIPS.put(ShazamAnim.MERCURY_BLITZ, Clip.builder(12)
                .key(0, Ease.OUT_CUBIC).rightArm(-80, -8, 0).leftArm(55, 0, -10)
                        .rightLeg(-38, 0, 0).leftLeg(42, 0, 0).head(-25, 0, 0).tilt(28)
                .key(7, Ease.LINEAR)
                .key(12, Ease.IN_OUT_SINE).rightArm(-15, 0, 5).leftArm(12, 0, -5)
                        .rightLeg(-5, 0, 0).leftLeg(5, 0, 0).head(-5, 0, 0).tilt(4)
                .fade(1, 4).build());

        // Lepas landas: jongkok mengumpulkan tenaga, lalu melesat dengan kepalan ke atas
        CLIPS.put(ShazamAnim.LAUNCH, Clip.builder(16)
                .key(0, Ease.OUT_QUAD).rightArm(22, 0, 12).leftArm(22, 0, -12).head(12, 0, 0)
                        .rightLeg(-35, 0, 4).leftLeg(-20, 0, -4).tilt(14).drop(0.28f)
                .key(4, Ease.OUT_QUAD).rightArm(-178, 0, -6).leftArm(15, 0, -12).head(-30, 0, 0)
                        .rightLeg(8, 0, 2).leftLeg(16, 0, -2).tilt(-4).drop(-0.1f)
                .key(10, Ease.LINEAR)
                .key(16, Ease.IN_OUT_SINE).rightArm(-60, 0, 10).leftArm(10, 0, -10).head(-10, 0, 0)
                        .rightLeg(5, 0, 2).leftLeg(10, 0, -2).tilt(0).drop(0f)
                .fade(1, 6).build());

        // Mendarat pelan: lutut menekuk sedikit
        CLIPS.put(ShazamAnim.LAND_SOFT, Clip.builder(10)
                .key(0, Ease.OUT_QUAD).rightArm(-25, 0, 22).leftArm(-25, 0, -22).head(5, 0, 0)
                        .rightLeg(-25, 0, 6).leftLeg(-12, 0, -6).tilt(10).drop(0.2f)
                .key(10, Ease.IN_OUT_SINE).rightArm(0, 0, 8).leftArm(0, 0, -8).head(0, 0, 0)
                        .rightLeg(0, 0, 4).leftLeg(0, 0, -4).tilt(0).drop(0f)
                .fade(1, 4).build());

        // Hero landing: satu lutut turun, kepalan menghantam tanah, lengan lain ke belakang
        CLIPS.put(ShazamAnim.LAND_HERO, Clip.builder(28)
                .key(0, Ease.OUT_QUAD).rightArm(-28, -10, 8).leftArm(48, 0, -38).head(-38, 0, 0)
                        .rightLeg(-78, 0, 10).leftLeg(58, 0, -10).tilt(34).drop(0.58f)
                .key(14, Ease.LINEAR)
                .key(28, Ease.IN_OUT_SINE).rightArm(10, 0, 24).leftArm(10, 0, -24).head(-8, 0, 0)
                        .rightLeg(0, 0, 8).leftLeg(0, 0, -8).tilt(-3).drop(0f)
                .fade(1, 6).build());

        // Menabrak: lengan menahan di depan muka, badan terpental ke belakang
        CLIPS.put(ShazamAnim.CRASH, Clip.builder(18)
                .key(0, Ease.OUT_QUAD).rightArm(-115, -28, 0).leftArm(-115, 28, 0).head(18, 0, 0)
                        .rightLeg(-20, 0, 6).leftLeg(10, 0, -6).tilt(-22).drop(0.08f)
                .key(6, Ease.OUT_CUBIC).tilt(-12)
                .key(18, Ease.IN_OUT_SINE).rightArm(0, 0, 8).leftArm(0, 0, -8).head(0, 0, 0)
                        .rightLeg(0, 0, 4).leftLeg(0, 0, -4).tilt(0).drop(0f)
                .fade(1, 5).build());
    }
}
