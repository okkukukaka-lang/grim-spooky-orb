package com.shazammod;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Salinan data Shazam di sisi client. Sengaja nggak memakai class khusus client,
 * supaya aman dimuat juga di server dedicated.
 */
public final class ShazamClientState {
    private ShazamClientState() {}

    // HUD pemain sendiri
    public static boolean unlocked;        // punya paling nggak satu juara
    public static boolean transformed;
    public static boolean storm;
    /** Berkah Aton: Black Adam di bawah matahari (darah pulih lebih cepat, energi malah terisi). */
    public static boolean sun;
    /** Juara yang sudah didapat: Shazam (enam totem) dan Black Adam (Skarabe Teth-Adam). */
    public static boolean hasShazam, hasAdam;
    public static float energy = ShazamPowers.MAX_ENERGY;
    /** Juara yang dipilih pemain sendiri (lihat ShazamForm). */
    public static int form;
    private static List<Integer> cooldowns = List.of();

    // Status semua pemain yang kelihatan, dan antrean animasi yang baru datang
    private static final Map<Integer, ShazamStatePayload> STATES = new HashMap<>();
    private static final ArrayDeque<ShazamAnimPayload> ANIMS = new ArrayDeque<>();

    public static void update(ShazamSyncPayload payload) {
        unlocked = payload.has(ShazamSyncPayload.UNLOCKED);
        transformed = payload.has(ShazamSyncPayload.TRANSFORMED);
        storm = payload.has(ShazamSyncPayload.STORM);
        sun = payload.has(ShazamSyncPayload.SUN);
        hasShazam = payload.has(ShazamSyncPayload.HAS_SHAZAM);
        hasAdam = payload.has(ShazamSyncPayload.HAS_ADAM);
        energy = payload.energy();
        cooldowns = payload.cooldowns();
        form = payload.form();
    }

    /** Pemain sendiri memilih Black Adam. */
    public static boolean isAdam() {
        return form == ShazamForm.BLACK_ADAM.ordinal();
    }

    /** Sisa cooldown skill ke-index, dalam tick. */
    public static int cooldown(int index) {
        return index < cooldowns.size() ? cooldowns.get(index) : 0;
    }

    /** Sisa waktu pulih (tick) sesudah terlempar balik jadi manusia; dikirim sesudah cooldown semua skill. */
    public static int recovery() {
        return cooldown(ShazamNetwork.SKILL_SLOTS);
    }

    /** Black Adam: sisa cooldown Panggil Petir Kahndaq (tombol M), dikirim paling belakang. */
    public static int callCooldown() {
        return cooldown(ShazamNetwork.SKILL_SLOTS + 1);
    }

    public static void onState(ShazamStatePayload payload) {
        STATES.put(payload.entityId(), payload);
    }

    public static boolean isTransformed(int entityId) {
        ShazamStatePayload state = STATES.get(entityId);
        return state != null && state.transformed();
    }

    public static boolean isRaging(int entityId) {
        ShazamStatePayload state = STATES.get(entityId);
        return state != null && state.rage();
    }

    public static boolean isHoodUp(int entityId) {
        ShazamStatePayload state = STATES.get(entityId);
        return state != null && state.hood();
    }

    /** Mode Kilat Mercury sedang menyala. */
    public static boolean isMercury(int entityId) {
        ShazamStatePayload state = STATES.get(entityId);
        return state != null && state.mercury();
    }

    /** Juara pemain ini (tampilan jubah, lambang, dewa, warna efek). Belum ada kabar = Shazam. */
    public static ShazamForm form(int entityId) {
        ShazamStatePayload state = STATES.get(entityId);
        return state == null ? ShazamForm.SHAZAM : ShazamForm.byId(state.form());
    }

    public static boolean isAdam(int entityId) {
        return form(entityId) == ShazamForm.BLACK_ADAM;
    }

    public static boolean isFlying(int entityId) {
        ShazamStatePayload state = STATES.get(entityId);
        return state != null && state.flying();
    }

    /** Muatan Petir Shazam penuh: kepalan menyala, Pukulan Guntur siap. */
    public static boolean isCharged(int entityId) {
        ShazamStatePayload state = STATES.get(entityId);
        return state != null && state.charged();
    }

    /** Muatan Petir pemain sendiri (0-100), dikirim sesudah cooldown Panggil Petir. */
    public static int charge() {
        return cooldown(ShazamNetwork.SKILL_SLOTS + 2);
    }

    /** Sisa jeda Refleks Mercury pemain sendiri (tick, 0 = siap). */
    public static int dodgeCooldown() {
        return cooldown(ShazamNetwork.SKILL_SLOTS + 3);
    }

    /** 0.26: sisa cooldown Kekuatan Keluarga (tombol J) pemain sendiri (tick, 0 = siap). */
    public static int familyCooldown() {
        return cooldown(ShazamNetwork.SKILL_SLOTS + 4);
    }

    /** 0.27 Black Adam: jumlah proyektil yang sedang tertahan Tangan Kahndaq. */
    public static int heldCount() {
        return cooldown(ShazamNetwork.SKILL_SLOTS + 5);
    }

    public static void onAnim(ShazamAnimPayload payload) {
        if (ANIMS.size() < 256) {
            ANIMS.add(payload);
        }
    }

    public static ShazamAnimPayload pollAnim() {
        return ANIMS.poll();
    }

    public static void reset() {
        unlocked = false;
        transformed = false;
        storm = false;
        sun = false;
        hasShazam = false;
        hasAdam = false;
        energy = ShazamPowers.MAX_ENERGY;
        form = 0;
        cooldowns = List.of();
        STATES.clear();
        ANIMS.clear();
    }
}
