package com.shazammod;

/**
 * Animasi yang dikirim server ke semua pemain di sekitar.
 * Urutannya dipakai sebagai id di jaringan, jadi tambah yang baru di paling bawah.
 */
public enum ShazamAnim {
    TRANSFORM,
    REVERT,
    SOLOMON_SIGHT,
    HERCULES_CLAP,
    ATLAS_GROUND,
    ATLAS_DIVE,
    ATLAS_IMPACT,
    ZEUS_CALL,
    ACHILLES_ROAR,
    MERCURY_BLITZ,
    LAUNCH,
    LAND_SOFT,
    LAND_HERO,
    CRASH,
    SONIC_BOOM,
    ROLL_LEFT,
    ROLL_RIGHT,
    SUMMON,      // memanggil enam dewa sebelum petir transformasi
    ZEUS_RAGE,   // amarah Zeus: mata menyala putih
    HOOD_UP,     // tangan meraih ke belakang kepala lalu menarik hood ke depan
    HOOD_DOWN,   // tangan memegang tepi hood di dahi lalu mendorongnya ke belakang
    MERCURY_ON,  // Mode Kilat Mercury menyala: kuda-kuda, listrik meledak dari badan
    MERCURY_OFF, // Mode Kilat Mercury mati
    MERCURY_JAB, // pukulan-pukulan secepat kilat (x, y, z = titik kena)
    MERCURY_CROSS,
    MERCURY_HOOK,
    MERCURY_KICK,
    KNOCKOUT,    // serangan mematikan saat jadi Shazam: badan terhentak, kekuatan tercabut dari dada, balik jadi manusia
    // ======= Black Adam (dewa-dewa Mesir) =======
    ADAM_SHU,         // S - Pusaran Shu: lengan terentang lalu terangkat, badai pasir berputar mengangkat musuh
    ADAM_HERU,        // H - Sambaran Heru: merunduk, lalu menerjang secepat elang (x, y, z = titik akhir terjangan)
    ADAM_AMON,        // A - Tinju Amon: melompat kecil, menghantam tanah, tanah terbelah lurus ke depan (x, y, z = ujungnya)
    ADAM_ZEHUTI,      // Z - Segel Zehuti: dua jari ke pelipis lalu menunjuk, hieroglif mengikat musuh
    ADAM_ZEHUTI_MARK, // segel hieroglif di satu musuh (x, y, z = posisinya); tanpa gerakan badan
    ADAM_ATON,        // A - Sinar Aton: tangan ke langit, cakram matahari terbentuk di atas telapak
    ADAM_ATON_RAY,    // satu sinar Aton ke satu musuh (x, y, z = sasaran); tanpa gerakan badan
    ADAM_MEHEN,       // M - Lilitan Mehen: kedua lengan menyilang, ular raksasa membelit badan
    ADAM_MEHEN_BITE,  // ular Mehen mematuk satu musuh (x, y, z = sasaran); tanpa gerakan badan
    ADAM_RAGE,        // Murka Kahndaq: badan terangkat, kepalan mengepal di samping, lalu meraung - mata emas menyala
    // ======= 0.22 =======
    ADAM_CALL,        // M (Black Adam): Panggil Petir Kahndaq - kepalan ke langit, petir sihir menyambar badan sendiri
    ADAM_DEFLECT,     // proyektil memantul dari kulit Black Adam (x, y, z = titik kena); tanpa gerakan badan
    ADAM_PUNCH,       // tinju Black Adam mengenai (x, y, z = titik kena): percikan petir; tanpa gerakan badan
    KAHNDAQ_TRIAL,    // Ujian Kahndaq dimulai: Skarabe Teth-Adam diangkat, badai pasir bangkit (wujud manusia)
    KAHNDAQ_RISE,     // makhluk makam bangkit dari pasir / runtuh jadi pasir (x, y, z); tanpa gerakan badan
    KAHNDAQ_AWAKEN,   // lulus ujian: skarabe bangkit, petir Kahndaq memilih juaranya (Black Adam terbuka)
    KAHNDAQ_END,      // ujian selesai/gagal: badai pasir reda; tanpa gerakan badan
    SHAZAM_CHOSEN,    // enam totem dewa menyatu: Penyihir memilih juaranya (Shazam terbuka)
    // ======= 0.23: Shazam, juara para dewa =======
    HERCULES_THROW,   // Shift+X: Lemparan Hercules - musuh diangkat ke atas kepala lalu dilempar (x, y, z = sasaran)
    HERCULES_IMPACT,  // musuh yang dilempar menghantam (x, y, z); tanpa gerakan badan
    ATLAS_GLOBE,      // Beban Langit: bola langit jatuh ke titik ini (x, y, z); tanpa gerakan badan
    ZEUS_CHAIN_START, // petir dari ujung jari ke sasaran pertama (x, y, z); tanpa gerakan badan
    ZEUS_CHAIN,       // petir melompat dari sasaran sebelumnya ke sasaran ini (x, y, z); tanpa gerakan badan
    ACHILLES_NOVA,    // Ledakan Keberanian: damage yang ditahan perisai Achilles dilepas (lengan menghentak)
    THUNDER_PUNCH,    // Pukulan Guntur (Muatan Petir penuh) mengenai (x, y, z); tanpa gerakan badan
    MERCURY_DODGE,    // Refleks Mercury: serangan dihindari (x, y, z = posisi sebelum mengelak); tanpa gerakan badan
    HERO_CALL,        // Hati Pahlawan: makhluk tak berdosa diserang (x, y, z = penyerangnya); tanpa gerakan badan
    STORM_ABSORB,     // Penangkal Petir Hidup: petir alam diserap badan; tanpa gerakan badan
    GOD_SOLOMON,      // Badai Para Dewa: dewa di lingkaran menyerang (x, y, z = sasaran); tanpa gerakan badan
    GOD_HERCULES,
    GOD_ATLAS,
    GOD_ZEUS,
    GOD_ACHILLES,
    GOD_MERCURY,
    // ======= 0.25 =======
    ROD_STRIKE,       // Penangkal Petir Hidup: petir sihir menyambar Shazam tiap 2 detik (turun ROD_DESCENT tick, lalu
                      // menghantam dada); tanpa ganti klip badan (sentakan kecil di badan ditumpuk di atas gerakan apa pun)
    // ======= 0.26 =======
    FAMILY_CALL,      // Kekuatan Keluarga (J): kepalan ke langit, tautan petir ke keluarga, lalu (tick FAMILY_WINDUP) petir
                      // menyambar semuanya bersamaan dan lengan terbuka lebar
    // ======= 0.27 Tangan Kahndaq (Black Adam) =======
    ADAM_CATCH,       // satu proyektil berhenti di udara (pos = proyektil); tanpa gerakan badan
    ADAM_HOLD,        // telapak kanan terangkat menahan proyektil-proyektil yang melayang
    ADAM_RELEASE;     // tombol J: tangan dikibaskan, semua proyektil melesat balik ke penembaknya

    // Waktu (tick) yang dipakai bersama oleh server dan client supaya efek pas dengan gerakan
    public static final int SUMMON_TICKS = 88;      // enam dewa datang satu per satu (lihat client.fx.GodShow), lalu kepalan diangkat
    public static final int TRANSFORM_WINDUP = 8;   // angkat kepalan ke langit
    public static final int BOLT_DESCENT = 10;      // petir turun pelan dari langit ke kepalan (slow motion)
    public static final int TRANSFORM_STRIKE = TRANSFORM_WINDUP + BOLT_DESCENT;   // tick klip TRANSFORM saat petir mengenai
    public static final int TRANSFORM_SLOWMO = 28;  // slow motion berlanjut selama kostum terbentuk (sampai hood terpasang)
    public static final int HOOD_GRAB = 6;          // tangan memegang tepi hood
    public static final int HOOD_MOVE = 10;         // hood ditarik/didorong selama ini
    public static final int HOOD_TICKS = 24;        // panjang animasi hood
    public static final int REVERT_WINDUP = 6;
    public static final int CAST_WINDUP = 5;        // Solomon, Hercules, Atlas (di tanah), Zeus
    public static final int ROAR_WINDUP = 4;        // Achilles
    public static final int ACHILLES_TICKS = 120;   // lama kulit tak tertembus
    public static final int SOLOMON_TICKS = 200;    // lama musuh "terbaca"
    public static final int BLITZ_TICKS = 6;        // lama terjangan Mercury
    public static final int RAGE_WINDUP = 9;        // Zeus Rage: membungkuk, lalu meraung ke langit
    public static final int RAGE_TICKS = 240;       // lama amarah Zeus (12 detik)
    public static final int KNOCKOUT_BURST = 3;     // terlempar balik: kekuatan tercabut keluar dari dada (lengan terentang)
    // Black Adam
    public static final int SHU_TICKS = 50;         // lama pusaran pasir Shu (lalu meledak ke luar)
    public static final int HERU_WINDUP = 3;        // merunduk sebelum menerjang
    public static final int HERU_TICKS = 5;         // lama terjangan Heru (titik awal -> titik akhir)
    public static final int AMON_WINDUP = 7;        // melompat kecil lalu kedua kepalan menghantam tanah
    public static final int AMON_SPREAD = 8;        // tanah terbelah merambat sampai ujung dalam waktu ini
    public static final int ATON_WINDUP = 8;        // cakram matahari terbentuk, lalu sinar pertama
    public static final int ATON_GAP = 2;           // jeda antar-sinar ke tiap musuh
    public static final int MEHEN_WINDUP = 6;       // ular muncul dari bayangan dan melilit
    public static final int MEHEN_TICKS = 160;      // lama lilitan Mehen (8 detik)
    public static final int ADAM_RAGE_WINDUP = 10;  // Murka Kahndaq: menahan amarah, lalu meraung
    public static final int ADAM_CALL_WINDUP = 12;  // Panggil Petir: kepalan diangkat, langit bergemuruh, lalu petir menyambar
    // Jalan mendapatkan juara
    public static final int KAHNDAQ_AWAKEN_TICKS = 70;    // upacara skarabe bangkit
    public static final int KAHNDAQ_AWAKEN_STRIKE = 52;   // petir Kahndaq menyambar (Black Adam terbuka)
    public static final int SHAZAM_CHOSEN_TICKS = 64;     // upacara enam totem
    public static final int SHAZAM_CHOSEN_STRIKE = 48;    // petir Penyihir menyambar (Shazam terbuka)
    // Shazam 0.23: juara para dewa
    public static final int THROW_LIFT = 6;         // Lemparan Hercules: musuh diangkat ke atas kepala selama ini
    public static final int THROW_RELEASE = 9;      // lalu dilempar (tick klip HERCULES_THROW)
    public static final int ATLAS_HOLD = 13;        // Beban Langit: bola langit diangkat, lalu dihantamkan di tick ini
    public static final int ATLAS_GLOBE_DROP = 9;   // bola langit jatuh selama ini sebelum hantaman
    public static final int ZEUS_HOP = 2;           // jeda antar-lompatan Petir Berantai
    public static final int NOVA_WINDUP = 2;        // Ledakan Keberanian: lengan menghentak, lalu meledak
    // 0.25: Penangkal Petir Hidup
    public static final int FAMILY_WINDUP = 10;     // 0.26 Kekuatan Keluarga: kepalan terangkat, lalu petir menyambar semua
    public static final int ROD_DESCENT = 3;        // petir turun dari langit selama ini, lalu menghantam (energi, darah,
                                                    // armor pulih tepat di tick ini; SFX rod_strike retak di 0,15 detik)

    /** Penanda efek di satu titik (bukan gerakan badan): klip pemain yang sedang jalan nggak diganti. */
    public boolean isMarker() {
        return this == ADAM_ZEHUTI_MARK || this == ADAM_ATON_RAY || this == ADAM_MEHEN_BITE || this == ADAM_DEFLECT
                || this == ADAM_PUNCH || this == KAHNDAQ_RISE || this == KAHNDAQ_END
                || this == HERCULES_IMPACT || this == ATLAS_GLOBE || this == ZEUS_CHAIN_START || this == ZEUS_CHAIN
                || this == THUNDER_PUNCH || this == MERCURY_DODGE || this == HERO_CALL || this == STORM_ABSORB || isGodStrike()
                || this == ROD_STRIKE || this == ADAM_CATCH;
    }

    /** Serangan salah satu dewa di lingkaran Badai Para Dewa (Shazam, tombol R). */
    public boolean isGodStrike() {
        return ordinal() >= GOD_SOLOMON.ordinal() && ordinal() <= GOD_MERCURY.ordinal();
    }

    /** 0-5 = Solomon, Hercules, Atlas, Zeus, Achilles, Mercury (sama dengan urutan dewa di client.fx.GodFigures). */
    public int godIndex() {
        return ordinal() - GOD_SOLOMON.ordinal();
    }

    public static ShazamAnim godStrike(int god) {
        return values()[GOD_SOLOMON.ordinal() + Math.floorMod(god, 6)];
    }

    public static ShazamAnim byId(int id) {
        ShazamAnim[] values = values();
        return id >= 0 && id < values.length ? values[id] : null;
    }
}
