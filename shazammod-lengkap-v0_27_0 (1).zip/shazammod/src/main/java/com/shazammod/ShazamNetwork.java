package com.shazammod;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/** Jalur komunikasi client <-> server: tombol, data HUD, status juara (Shazam / Black Adam), dan animasi. */
@EventBusSubscriber(modid = ShazamMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public final class ShazamNetwork {
    private ShazamNetwork() {}

    public static final int ACTION_TRANSFORM = 0; // 1-7 = skill S-H-A-Z-A-M + amarah (dewa-dewa juara yang dipilih)
    public static final int ACTION_HOOD = 20;
    public static final int ACTION_FORM = 21;     // ganti juara: Shazam <-> Black Adam (cuma saat wujud manusia)
    public static final int ACTION_ADAM_CALL = 22; // Black Adam (tombol M): Panggil Petir Kahndaq
    public static final int ACTION_FAMILY = 23;    // 0.26 Shazam (tombol J): Kekuatan Keluarga

    @SubscribeEvent
    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("9");   // naikkan tiap format paket berubah
        registrar.playToServer(ShazamActionPayload.TYPE, ShazamActionPayload.STREAM_CODEC, ShazamNetwork::handleAction);
        registrar.playToServer(ShazamFlightPayload.TYPE, ShazamFlightPayload.STREAM_CODEC, ShazamNetwork::handleFlight);
        registrar.playToServer(ShazamMercuryPayload.TYPE, ShazamMercuryPayload.STREAM_CODEC, ShazamNetwork::handleMercury);
        registrar.playToClient(ShazamSyncPayload.TYPE, ShazamSyncPayload.STREAM_CODEC, ShazamNetwork::handleSync);
        registrar.playToClient(ShazamStatePayload.TYPE, ShazamStatePayload.STREAM_CODEC, ShazamNetwork::handleState);
        registrar.playToClient(ShazamAnimPayload.TYPE, ShazamAnimPayload.STREAM_CODEC, ShazamNetwork::handleAnim);
    }

    private static void handleAction(ShazamActionPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            if (!(context.player() instanceof ServerPlayer player)) {
                return;
            }
            int action = payload.action();
            if (action == ACTION_TRANSFORM) {
                ShazamPowers.onSayShazam(player);
            } else if (action >= 1 && action <= SKILL_SLOTS) {
                // tombol yang sama, dewa yang beda: Z X C V B N R = S-H-A-Z-A-M + amarah juara yang dipilih
                if (ShazamPowers.data(player).isBlackAdam()) {
                    AdamSkills.use(player, AdamSkills.Skill.values()[action - 1]);
                } else {
                    ShazamSkills.use(player, ShazamSkills.Skill.values()[action - 1]);
                }
            } else if (action == ACTION_HOOD) {
                ShazamPowers.toggleHood(player);
            } else if (action == ACTION_FORM) {
                ShazamPowers.switchForm(player);
            } else if (action == ACTION_ADAM_CALL) {
                AdamSkills.callLightning(player);
            } else if (action == ACTION_FAMILY) {
                // tombol J: Shazam = Kekuatan Keluarga, Black Adam = Tangan Kahndaq (lempar balik proyektil yang tertahan)
                if (ShazamPowers.data(player).isBlackAdam()) {
                    AdamCatch.release(player, true);
                } else {
                    ShazamFamily.use(player);
                }
            }
        });
    }

    private static void handleFlight(ShazamFlightPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            if (context.player() instanceof ServerPlayer player) {
                ShazamFlightServer.handle(player, payload.action(), payload.speed());
            }
        });
    }

    private static void handleMercury(ShazamMercuryPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            if (context.player() instanceof ServerPlayer player) {
                ShazamMercury.strike(player, payload.target(), payload.move());
            }
        });
    }

    private static void handleSync(ShazamSyncPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> ShazamClientState.update(payload));
    }

    private static void handleState(ShazamStatePayload payload, IPayloadContext context) {
        context.enqueueWork(() -> ShazamClientState.onState(payload));
    }

    private static void handleAnim(ShazamAnimPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> ShazamClientState.onAnim(payload));
    }

    /** Jumlah tombol skill tiap juara (enam dewa + amarah); dua juara sama banyak, jadi HUD-nya sama. */
    public static final int SKILL_SLOTS = 7;

    /** Data HUD (energi, cooldown skill juara yang dipilih, waktu pulih) untuk pemain itu sendiri. */
    public static void sync(ServerPlayer player) {
        ShazamData data = ShazamPowers.data(player);
        List<Integer> cooldowns = new ArrayList<>();
        if (data.isBlackAdam()) {
            for (AdamSkills.Skill skill : AdamSkills.Skill.values()) {
                cooldowns.add(AdamSkills.cooldownTicks(player, skill));
            }
        } else {
            for (ShazamSkills.Skill skill : ShazamSkills.Skill.values()) {
                cooldowns.add(ShazamSkills.cooldownTicks(player, skill));
            }
        }
        cooldowns.add(ShazamPowers.recoveryTicks(player));   // sesudah 7 skill: waktu pulih sesudah serangan mematikan
        cooldowns.add(AdamSkills.callCooldownTicks(player)); // Panggil Petir Kahndaq (Black Adam)
        cooldowns.add(ShazamPassives.charge(player));          // Muatan Petir Shazam (0-100)
        cooldowns.add(ShazamPassives.dodgeCooldown(player));   // Refleks Mercury: sisa jeda (tick)
        cooldowns.add(ShazamFamily.cooldownTicks(player));     // 0.26 Kekuatan Keluarga: sisa cooldown (tick)
        cooldowns.add(AdamCatch.heldCount(player));            // 0.27 Tangan Kahndaq: jumlah proyektil yang tertahan
        int flags = (data.anyUnlocked() ? ShazamSyncPayload.UNLOCKED : 0)
                | (data.transformed() ? ShazamSyncPayload.TRANSFORMED : 0)
                | (ShazamPowers.isInStorm(player) ? ShazamSyncPayload.STORM : 0)
                | (data.isBlackAdam() && ShazamPowers.isInSun(player) ? ShazamSyncPayload.SUN : 0)
                | (data.unlocked() ? ShazamSyncPayload.HAS_SHAZAM : 0)
                | (data.adamUnlocked() ? ShazamSyncPayload.HAS_ADAM : 0);
        PacketDistributor.sendToPlayer(player, new ShazamSyncPayload(flags, data.energy(), cooldowns,
                data.champion().ordinal()));
    }

    /** Status Shazam pemain ini, ke dirinya dan semua yang melihatnya. */
    public static void broadcastState(ServerPlayer player) {
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, statePayload(player));
    }

    public static void sendStateTo(ServerPlayer target, ServerPlayer viewer) {
        PacketDistributor.sendToPlayer(viewer, statePayload(target));
    }

    private static ShazamStatePayload statePayload(ServerPlayer player) {
        ShazamData data = ShazamPowers.data(player);
        boolean transformed = data.transformed();
        boolean rage = ShazamSkills.isRageActive(player) || AdamSkills.isRageActive(player);
        return new ShazamStatePayload(player.getId(), transformed, transformed && player.getAbilities().flying, data.hoodUp(),
                transformed && rage, transformed && ShazamMercury.isActive(player), data.champion().ordinal(),
                transformed && ShazamPassives.isCharged(player));
    }

    /** Animasi untuk pemain lain saja (pemain itu sendiri sudah memutarnya duluan di client-nya). */
    public static void playAnimToOthers(ServerPlayer player, ShazamAnim anim) {
        playAnimToOthers(player, anim, player.position());
    }

    public static void playAnimToOthers(ServerPlayer player, ShazamAnim anim, Vec3 pos) {
        PacketDistributor.sendToPlayersTrackingEntity(player, new ShazamAnimPayload(player.getId(), anim.ordinal(),
                (float) pos.x, (float) pos.y, (float) pos.z));
    }

    public static void playAnim(ServerPlayer player, ShazamAnim anim) {
        playAnim(player, anim, player.position());
    }

    public static void playAnim(ServerPlayer player, ShazamAnim anim, Vec3 pos) {
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(player,
                new ShazamAnimPayload(player.getId(), anim.ordinal(), (float) pos.x, (float) pos.y, (float) pos.z));
    }
}
