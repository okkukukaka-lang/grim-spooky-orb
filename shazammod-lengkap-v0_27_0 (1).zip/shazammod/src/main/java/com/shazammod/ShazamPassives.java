package com.shazammod;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Pasif khas Shazam (0.23). Black Adam itu tank yang buas (kulitnya memantulkan proyektil, kekuatannya dari matahari);
 * Shazam pahlawan yang lincah, dilindungi para dewa, dan kekuatannya dari badai:
 *
 * Muatan Petir          : memukul, dipukul, terbang kencang, berlari dengan Mode Kilat, dan berdiri di bawah hujan atau badai
 *                         mengisi listrik di badan. Penuh = kepalan menyala dan pukulan berikutnya jadi Pukulan Guntur
 *                         (petir dari langit, damage x1,75, hempasan jauh, petir merambat ke 3 musuh lain).
 * Refleks Mercury       : sekali tiap 1,8 detik (0.25; dulu 8 detik), satu serangan (pukulan, panah, bola api) dihindari dengan
 *                         kedipan secepat kilat.
 * Hati Pahlawan         : villager, hewan peliharaan, atau pemain lain diserang monster di dekat Shazam: penyerangnya ditandai
 *                         (bersinar, +25% damage dari Shazam) dan Shazam dapat Amarah Pahlawan (pukulan +25% selama 8 detik).
 * Keluarga Shazam       : sekutu (pemain lain, villager, hewan peliharaan) dalam 10 blok dapat Resistance I.
 * Penangkal Petir Hidup : (0.25) tiap 2 detik petir sihir turun dari langit menyambar dada Shazam, di mana pun (siang,
 *                         malam, di dalam ruangan). Tiap sambaran: Energi Petir pulih, darah pulih, armor yang dipakai pulih,
 *                         Perisai Petir (hati emas) terisi lagi, dan Muatan Petir penuh, jadi pukulan berikutnya Pukulan Guntur.
 *                         Petir alam atau trisula Channeling yang menyambar Shazam juga diserap (lebih besar: +150 energi,
 *                         +40 darah) dan menggantikan sambaran berikutnya.
 */
public final class ShazamPassives {
    private ShazamPassives() {}

    // ================= Angka-angka yang gampang diutak-atik =================
    public static final float MAX_CHARGE = 100f;
    public static final float CHARGE_PER_HIT = 9f;            // tiap pukulan tangan kosong ke musuh
    private static final float CHARGE_PER_HURT = 4f;          // tiap kena serangan
    private static final float CHARGE_FLIGHT = 0.3f;          // per tick, dikali kecepatan terbang di atas 0,5 blok/tick
    private static final float CHARGE_MERCURY = 0.35f;        // per tick selama berlari dengan Mode Kilat Mercury
    private static final float CHARGE_STORM = 0.3f;           // per tick di bawah badai petir
    private static final float RAIN_MULTIPLIER = 2f;          // kehujanan: semua muatan masuk 2x
    public static final float THUNDER_PUNCH_MULTIPLIER = 1.75f;
    private static final float THUNDER_CHAIN_DAMAGE = 14f;
    private static final double THUNDER_CHAIN_RADIUS = 7.0;
    private static final int THUNDER_CHAIN_TARGETS = 3;
    private static final double THUNDER_KNOCKBACK = 1.8;
    public static final int DODGE_COOLDOWN_TICKS = 36;        // Refleks Mercury: sekali tiap 1,8 detik (dulu 160 = 8 detik)
    private static final double DODGE_SPEED = 1.15;           // kecepatan mengelak ke samping (blok/tick)
    private static final double HERO_RADIUS = 24.0;
    private static final int HERO_TICKS = 160;                // Amarah Pahlawan: 8 detik
    public static final float HERO_MULTIPLIER = 1.25f;
    private static final int HERO_GAP = 40;                   // paling sering tiap 2 detik
    private static final double FAMILY_RADIUS = 10.0;
    private static final int ABSORB_GAP = 30;                 // satu sambaran petir cuma dihitung sekali
    private static final float ABSORB_ENERGY = 150f;
    private static final float ABSORB_HEAL = 40f;
    // Penangkal Petir Hidup (0.25): petir sihir menyambar Shazam tiap 2 detik
    public static final int ROD_INTERVAL_TICKS = 40;          // tiap 2 detik sekali (20 tick = 1 detik)
    private static final float ROD_ENERGY = 100f;             // Energi Petir yang pulih tiap sambaran (penuh 1000)
    private static final float ROD_HEAL = 40f;                // darah yang pulih tiap sambaran (penuh 300)
    private static final float ROD_ARMOR_REPAIR = 1.0f;       // armor yang dipakai: bagian durability yang pulih (1 = penuh, 0 = mati)
    private static final float ROD_SHIELD = 20f;              // Perisai Petir: hati emas diisi lagi sampai segini (20 = 10 hati, 0 = mati)
    private static final float ROD_SPLASH_DAMAGE = 0f;        // > 0: sambarannya ikut melukai monster di sekitar (pemain & sekutu aman)
    private static final double ROD_SPLASH_RADIUS = 3.5;
    private static final float ROD_VOLUME = 1.5f;             // keras suara sambaran (terdengar sampai ±16 blok x angka ini)
    // =========================================================================

    private static final ResourceLocation ROD_SHIELD_ID = ShazamMod.id("rod_shield");
    private static final EquipmentSlot[] ARMOR_SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS,
            EquipmentSlot.FEET};

    private static final Map<UUID, Float> CHARGE = new HashMap<>();
    private static final Map<UUID, Long> DODGE_READY = new HashMap<>();
    private static final Map<UUID, Long> HERO_UNTIL = new HashMap<>();
    private static final Map<UUID, Long> HERO_NEXT = new HashMap<>();
    private static final Map<UUID, Long> ABSORB_NEXT = new HashMap<>();
    private static final Map<UUID, Long> ROD_NEXT = new HashMap<>();

    /** Sedang berwujud Shazam (bukan Black Adam). */
    public static boolean isShazam(ServerPlayer player) {
        ShazamData data = ShazamPowers.data(player);
        return data.transformed() && !data.isBlackAdam();
    }

    private static void sound(ServerPlayer player, Vec3 at, SoundEvent sound, float volume, float pitch) {
        player.serverLevel().playSound(null, at.x, at.y, at.z, sound, SoundSource.PLAYERS, volume, pitch);
    }

    private static List<LivingEntity> enemies(ServerPlayer player, Vec3 center, double radius) {
        return player.serverLevel().getEntitiesOfClass(LivingEntity.class, new AABB(center, center).inflate(radius),
                m -> m.isAlive() && m instanceof Enemy && m.distanceToSqr(center) <= radius * radius);
    }

    /** Dipanggil tiap tick selama berwujud Shazam (dari ShazamSkills.tick). */
    public static void tick(ServerPlayer player) {
        double moved = Math.sqrt(player.distanceToSqr(player.xo, player.yo, player.zo));
        if (player.getAbilities().flying && moved > 0.5) {
            addCharge(player, (float) (moved - 0.5) * CHARGE_FLIGHT);
        }
        if (ShazamMercury.isActive(player) && moved > 0.3) {
            addCharge(player, CHARGE_MERCURY);
        }
        if (ShazamPowers.isInStorm(player)) {
            addCharge(player, CHARGE_STORM);
        }
        rodTick(player);   // Penangkal Petir Hidup: petir menyambar tiap 2 detik
        if (player.tickCount % 40 == 0) {
            family(player);
        }
    }

    public static void reset(ServerPlayer player) {
        UUID id = player.getUUID();
        CHARGE.remove(id);
        HERO_UNTIL.remove(id);
        ROD_NEXT.remove(id);   // berubah lagi nanti: sambaran pertama 2 detik sesudah petir transformasi
        removeShield(player);
    }

    public static void forget(UUID id) {
        CHARGE.remove(id);
        DODGE_READY.remove(id);
        HERO_UNTIL.remove(id);
        HERO_NEXT.remove(id);
        ABSORB_NEXT.remove(id);
        ROD_NEXT.remove(id);
    }

    // ------------------------------------------------------------------ Muatan Petir

    public static int charge(ServerPlayer player) {
        return Math.round(CHARGE.getOrDefault(player.getUUID(), 0f));
    }

    public static boolean isCharged(ServerPlayer player) {
        return CHARGE.getOrDefault(player.getUUID(), 0f) >= MAX_CHARGE;
    }

    public static void addCharge(ServerPlayer player, float amount) {
        if (amount <= 0f || !isShazam(player)) {
            return;
        }
        if (player.level().isRainingAt(player.blockPosition())) {
            amount *= RAIN_MULTIPLIER;
        }
        float old = CHARGE.getOrDefault(player.getUUID(), 0f);
        float now = Math.min(MAX_CHARGE, old + amount);
        CHARGE.put(player.getUUID(), now);
        if (old < MAX_CHARGE && now >= MAX_CHARGE) {
            sound(player, player.position(), ShazamSounds.ENERGY_PULSE.get(), 1.0f, ShazamSounds.tune(1.8f));
            sound(player, player.position(), ShazamSounds.SHIMMER.get(), 1.2f, ShazamSounds.tune(1.6f));
            player.displayClientMessage(Component.translatable("message.shazammod.charged").withStyle(ChatFormatting.YELLOW), true);
            ShazamNetwork.broadcastState(player);   // pemain lain melihat kepalannya menyala
        }
    }

    /** Muatan penuh dipakai pukulan ini (jadi Pukulan Guntur). */
    public static boolean consumeCharge(ServerPlayer player) {
        if (!isShazam(player) || !isCharged(player)) {
            return false;
        }
        CHARGE.put(player.getUUID(), 0f);
        ShazamNetwork.broadcastState(player);
        return true;
    }

    /**
     * Pukulan Guntur: dipanggil di tengah event damage pukulannya (damage-nya sudah dikali). Petir dari langit di sasaran;
     * hempasan dan petir yang merambat ke musuh lain menyusul satu tick kemudian, sesudah event ini selesai.
     */
    public static void thunderPunch(ServerPlayer player, LivingEntity target) {
        ServerLevel level = player.serverLevel();
        Vec3 at = target.position().add(0, target.getBbHeight() * 0.6, 0);
        ShazamNetwork.playAnim(player, ShazamAnim.THUNDER_PUNCH, at);
        ShazamPowers.spawnBolt(level, target.position(), 1.4f, 0);
        level.playSound(null, at.x, at.y, at.z, ShazamSounds.THUNDER_PUNCH.get(), SoundSource.PLAYERS, 2.0f, 1f);
        ShazamPowers.schedule(player, 1, p -> {
            if (target.isAlive()) {
                Vec3 dir = new Vec3(target.getX() - p.getX(), 0, target.getZ() - p.getZ());
                dir = dir.lengthSqr() < 1.0E-4 ? Vec3.ZERO : dir.normalize();
                target.push(dir.x * THUNDER_KNOCKBACK, 0.55, dir.z * THUNDER_KNOCKBACK);
                target.hurtMarked = true;
            }
            List<LivingEntity> near = enemies(p, target.position(), THUNDER_CHAIN_RADIUS);
            near.remove(target);
            near.sort(Comparator.comparingDouble(m -> m.distanceToSqr(target)));
            for (int i = 0; i < Math.min(THUNDER_CHAIN_TARGETS, near.size()); i++) {
                ShazamPowers.strikeLightning(p, near.get(i).position(), THUNDER_CHAIN_DAMAGE, 0.9, 0.7f);
            }
        });
    }

    /** Kena serangan juga menambah muatan (dipanggil ShazamPowers). */
    public static void onHurt(ServerPlayer victim) {
        addCharge(victim, CHARGE_PER_HURT);
    }

    // ------------------------------------------------------------------ Refleks Mercury

    public static int dodgeCooldown(ServerPlayer player) {
        Long ready = DODGE_READY.get(player.getUUID());
        if (ready == null) {
            return 0;
        }
        long left = ready - player.level().getGameTime();
        return left > 0 ? (int) left : 0;
    }

    /**
     * Serangan dari makhluk (pukulan, panah, bola api, ...) dihindari kalau refleksnya siap: Shazam melesat ke samping secepat
     * kilat, meninggalkan bayangan. Bukan serangan (jatuh, api, ledakan, void): nggak dihindari.
     */
    public static boolean tryDodge(ServerPlayer victim, DamageSource source) {
        if (!isShazam(victim) || ShazamSkills.isAchillesActive(victim)) {
            return false;   // Perisai Achilles sedang menahan semuanya: refleksnya disimpan
        }
        Entity attacker = source.getEntity();
        Entity direct = source.getDirectEntity();
        if ((attacker == null && direct == null) || attacker == victim
                || source.is(DamageTypeTags.BYPASSES_INVULNERABILITY) || source.is(DamageTypeTags.IS_EXPLOSION)) {
            return false;
        }
        long now = victim.level().getGameTime();
        Long ready = DODGE_READY.get(victim.getUUID());
        if (ready != null && now < ready) {
            return false;
        }
        DODGE_READY.put(victim.getUUID(), now + DODGE_COOLDOWN_TICKS);
        Entity from = direct != null ? direct : attacker;
        Vec3 away = new Vec3(victim.getX() - from.getX(), 0, victim.getZ() - from.getZ());
        if (away.lengthSqr() < 1.0E-4) {
            Vec3 look = victim.getViewVector(1f);
            away = new Vec3(-look.x, 0, -look.z);
        }
        away = away.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : away.normalize();
        Vec3 side = new Vec3(-away.z, 0, away.x).scale(victim.getRandom().nextBoolean() ? 1.0 : -1.0);
        Vec3 velocity = side.scale(DODGE_SPEED).add(away.scale(0.35));
        ShazamNetwork.playAnim(victim, ShazamAnim.MERCURY_DODGE, victim.position());
        victim.setDeltaMovement(velocity.x, 0.12, velocity.z);
        victim.hurtMarked = true;
        sound(victim, victim.position(), ShazamSounds.MERCURY_BLINK.get(), 1.2f, 0.95f + victim.getRandom().nextFloat() * 0.1f);
        return true;
    }

    // ------------------------------------------------------------------ Hati Pahlawan & Keluarga Shazam

    private static boolean isAlly(LivingEntity entity) {
        return entity instanceof AbstractVillager || (entity instanceof TamableAnimal pet && pet.isTame())
                || (entity instanceof Player player && !player.isSpectator());
    }

    public static float heroMultiplier(ServerPlayer attacker) {
        Long until = HERO_UNTIL.get(attacker.getUUID());
        return until != null && until > attacker.level().getGameTime() ? HERO_MULTIPLIER : 1f;
    }

    /** Makhluk tak berdosa diserang monster: Shazam di sekitar mendengar panggilannya (dipanggil untuk semua damage). */
    public static void onInnocentHurt(LivingEntity victim, DamageSource source) {
        if (!(victim.level() instanceof ServerLevel level) || !(source.getEntity() instanceof LivingEntity attacker)
                || !(attacker instanceof Enemy) || attacker == victim || !isAlly(victim)
                || (victim instanceof ServerPlayer hurtPlayer && isShazam(hurtPlayer))) {
            return;
        }
        long now = level.getGameTime();
        AABB area = victim.getBoundingBox().inflate(HERO_RADIUS);
        for (ServerPlayer hero : level.getEntitiesOfClass(ServerPlayer.class, area, ShazamPassives::isShazam)) {
            Long next = HERO_NEXT.get(hero.getUUID());
            if (hero == victim || (next != null && now < next)) {
                continue;
            }
            HERO_NEXT.put(hero.getUUID(), now + HERO_GAP);
            HERO_UNTIL.put(hero.getUUID(), now + HERO_TICKS);
            ShazamSkills.expose(attacker, HERO_TICKS);
            attacker.addEffect(new MobEffectInstance(MobEffects.GLOWING, HERO_TICKS, 0, false, false));
            ShazamNetwork.playAnim(hero, ShazamAnim.HERO_CALL, attacker.position().add(0, attacker.getBbHeight() * 0.6, 0));
            hero.displayClientMessage(Component.translatable("message.shazammod.hero_call").withStyle(ChatFormatting.GOLD), true);
        }
    }

    /** Keluarga Shazam: sekutu di sekitar ikut terlindungi kekuatan petir sihir. */
    private static void family(ServerPlayer player) {
        for (LivingEntity ally : player.serverLevel().getEntitiesOfClass(LivingEntity.class,
                player.getBoundingBox().inflate(FAMILY_RADIUS), e -> e != player && e.isAlive() && isAlly(e))) {
            ally.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 60, 0, true, false, true));
        }
    }

    // ------------------------------------------------------------------ Penangkal Petir Hidup (0.25)

    /** Hitung mundur sambaran berikutnya; dipanggil tiap tick selama berwujud Shazam. */
    private static void rodTick(ServerPlayer player) {
        if (player.isSpectator()) {
            return;
        }
        UUID id = player.getUUID();
        long now = player.level().getGameTime();
        Long next = ROD_NEXT.get(id);
        if (next == null) {   // baru berubah: petir transformasi baru saja menyambar, jadi yang pertama 2 detik lagi
            ROD_NEXT.put(id, now + ROD_INTERVAL_TICKS);
            return;
        }
        if (now >= next) {
            ROD_NEXT.put(id, now + ROD_INTERVAL_TICKS);
            rodStrike(player);
        }
    }

    /**
     * Petir sihir dipanggil ke dada Shazam seperti di film: di client petirnya turun dari langit selama ROD_DESCENT tick
     * (badan memancarkan busur listrik ke atas menyambutnya), lalu menghantam dada, badan tersentak, mata & lambang menyala,
     * dan listrik merayap di badan (lihat client.fx.RodStrikeFx). Kekuatannya masuk tepat di tick hantaman.
     */
    private static void rodStrike(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        ShazamNetwork.playAnim(player, ShazamAnim.ROD_STRIKE, player.position());
        // Satu suara yang sudah di-mix (tools/sfx/synth.py: rod_strike): desis petir turun 0,15 detik -> retakan tepat di
        // tick hantaman -> dentum sub -> guntur pendek -> dengung tenaga yang merasuk badan. Menempel ke badan Shazam (ikut
        // terbang), nadanya cuma digeser sedikit supaya retakannya tetap jatuh di tick hantaman.
        level.playSound(null, player, ShazamSounds.ROD_STRIKE.get(), SoundSource.PLAYERS, ROD_VOLUME,
                ShazamSlowMo.pitch(level.getServer(), 0.97f + player.getRandom().nextFloat() * 0.06f));
        ShazamPowers.schedule(player, ShazamAnim.ROD_DESCENT, p -> {
            if (!isShazam(p)) {
                return;   // keburu balik jadi manusia
            }
            empower(p, ROD_ENERGY, ROD_HEAL);
            if (ROD_SPLASH_DAMAGE > 0f) {
                DamageSource source = ShazamPowers.lightningSource(p);
                for (LivingEntity foe : enemies(p, p.position(), ROD_SPLASH_RADIUS)) {
                    foe.hurt(source, ROD_SPLASH_DAMAGE);
                }
            }
        });
    }

    /** Petir menyatu dengan badan: energi, darah, dan armor pulih, Perisai Petir terisi, Pukulan Guntur siap. */
    private static void empower(ServerPlayer player, float energy, float heal) {
        UUID id = player.getUUID();
        ShazamData data = ShazamPowers.data(player);
        ShazamPowers.setData(player, data.withEnergy(data.energy() + energy));
        player.heal(heal);
        repairArmor(player);
        refillShield(player);
        boolean wasCharged = isCharged(player);
        CHARGE.put(id, MAX_CHARGE);   // kepalan berlistrik: pukulan tangan kosong berikutnya jadi Pukulan Guntur
        if (!wasCharged) {
            ShazamNetwork.broadcastState(player);   // pemain lain melihat kepalannya menyala
        }
        ShazamNetwork.sync(player);
    }

    /** Armor yang sedang dipakai (kostum Shazam atau armor apa pun) pulih. */
    private static void repairArmor(ServerPlayer player) {
        if (ROD_ARMOR_REPAIR <= 0f) {
            return;
        }
        for (EquipmentSlot slot : ARMOR_SLOTS) {
            ItemStack stack = player.getItemBySlot(slot);
            if (!stack.isEmpty() && stack.isDamageableItem() && stack.isDamaged()) {
                int fix = Math.max(1, Math.round(stack.getMaxDamage() * ROD_ARMOR_REPAIR));
                stack.setDamageValue(Math.max(0, stack.getDamageValue() - fix));
            }
        }
    }

    /**
     * Perisai Petir: armor Shazam (dari Atlas) nggak pernah berkurang, jadi "armor pulih" juga dibuat kelihatan sebagai
     * hati emas (absorption) yang habis kena serangan dan terisi lagi tiap sambaran.
     */
    private static void refillShield(ServerPlayer player) {
        if (ROD_SHIELD <= 0f) {
            return;
        }
        AttributeInstance max = player.getAttribute(Attributes.MAX_ABSORPTION);
        if (max == null) {
            return;
        }
        if (max.getModifier(ROD_SHIELD_ID) == null) {
            max.addTransientModifier(new AttributeModifier(ROD_SHIELD_ID, ROD_SHIELD, AttributeModifier.Operation.ADD_VALUE));
        }
        if (player.getAbsorptionAmount() < ROD_SHIELD) {
            player.setAbsorptionAmount(ROD_SHIELD);
        }
    }

    /** Balik jadi manusia / respawn: Perisai Petir ikut hilang. */
    private static void removeShield(ServerPlayer player) {
        AttributeInstance max = player.getAttribute(Attributes.MAX_ABSORPTION);
        if (max != null && max.getModifier(ROD_SHIELD_ID) != null) {
            max.removeModifier(ROD_SHIELD_ID);
            player.setAbsorptionAmount(player.getAbsorptionAmount());   // dipangkas ke batas yang baru
        }
    }

    /** Petir alam atau trisula Channeling yang menyambar Shazam diserap jadi kekuatan (lebih besar dari sambaran biasa). */
    public static void absorbLightning(ServerPlayer player) {
        if (!isShazam(player)) {
            return;
        }
        UUID id = player.getUUID();
        long now = player.level().getGameTime();
        Long next = ABSORB_NEXT.get(id);
        if (next != null && now < next) {
            return;
        }
        ABSORB_NEXT.put(id, now + ABSORB_GAP);
        ROD_NEXT.put(id, now + ROD_INTERVAL_TICKS);   // petir alam ini menggantikan sambaran berikutnya
        empower(player, ABSORB_ENERGY, ABSORB_HEAL);
        ShazamNetwork.playAnim(player, ShazamAnim.STORM_ABSORB, player.position());
        sound(player, player.position(), ShazamSounds.POWER_UP.get(), 1.2f, ShazamSounds.tune(1.6f));
        sound(player, player.position(), ShazamSounds.DIVINE.get(), 0.6f, ShazamSounds.tune(1.6f));
        player.displayClientMessage(Component.translatable("message.shazammod.storm_absorb").withStyle(ChatFormatting.AQUA), true);
    }
}
