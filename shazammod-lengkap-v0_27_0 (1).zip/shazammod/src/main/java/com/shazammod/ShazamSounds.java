package com.shazammod;

import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.Mth;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * SFX sinematik buatan sendiri (bukan suara bawaan Minecraft). File .ogg-nya ada di assets/shazammod/sounds/,
 * daftar variannya di assets/shazammod/sounds.json. Semua suara mono supaya terdengar dari arah sumbernya.
 * Dibuat dengan tools/sfx/synth.py.
 */
public final class ShazamSounds {
    private ShazamSounds() {}

    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(Registries.SOUND_EVENT, ShazamMod.MODID);

    // ------------------------------------------------ pustaka umum (0.24.1)
    public static final DeferredHolder<SoundEvent, SoundEvent> THUNDER = reg("thunder");
    public static final DeferredHolder<SoundEvent, SoundEvent> LIGHTNING_STRIKE = reg("lightning_strike");
    public static final DeferredHolder<SoundEvent, SoundEvent> IMPACT = reg("impact");
    public static final DeferredHolder<SoundEvent, SoundEvent> IMPACT_RING = reg("impact_ring");
    public static final DeferredHolder<SoundEvent, SoundEvent> BODY_HIT = reg("body_hit");
    public static final DeferredHolder<SoundEvent, SoundEvent> WHOOSH = reg("whoosh");
    public static final DeferredHolder<SoundEvent, SoundEvent> WHOOSH_HEAVY = reg("whoosh_heavy");
    public static final DeferredHolder<SoundEvent, SoundEvent> POWER_UP = reg("power_up");
    public static final DeferredHolder<SoundEvent, SoundEvent> AURA_SWELL = reg("aura_swell");
    public static final DeferredHolder<SoundEvent, SoundEvent> POWER_DOWN = reg("power_down");
    public static final DeferredHolder<SoundEvent, SoundEvent> ENERGY_PULSE = reg("energy_pulse");
    public static final DeferredHolder<SoundEvent, SoundEvent> CHARGE = reg("charge");
    public static final DeferredHolder<SoundEvent, SoundEvent> RISER = reg("riser");
    public static final DeferredHolder<SoundEvent, SoundEvent> SHIMMER = reg("shimmer");
    public static final DeferredHolder<SoundEvent, SoundEvent> RESONANCE = reg("resonance");
    public static final DeferredHolder<SoundEvent, SoundEvent> SPELL = reg("spell");
    public static final DeferredHolder<SoundEvent, SoundEvent> SONIC_BOOM = reg("sonic_boom");
    public static final DeferredHolder<SoundEvent, SoundEvent> DIVINE = reg("divine");
    public static final DeferredHolder<SoundEvent, SoundEvent> PUNCH = reg("punch");
    public static final DeferredHolder<SoundEvent, SoundEvent> PUNCH_CRIT = reg("punch_crit");
    public static final DeferredHolder<SoundEvent, SoundEvent> DEFLECT = reg("deflect");
    public static final DeferredHolder<SoundEvent, SoundEvent> DARK_HISS = reg("dark_hiss");
    public static final DeferredHolder<SoundEvent, SoundEvent> DREAD = reg("dread");
    public static final DeferredHolder<SoundEvent, SoundEvent> HEARTBEAT = reg("heartbeat");
    public static final DeferredHolder<SoundEvent, SoundEvent> SAND_BURST = reg("sand_burst");
    public static final DeferredHolder<SoundEvent, SoundEvent> EARTH_CRACK = reg("earth_crack");
    public static final DeferredHolder<SoundEvent, SoundEvent> FIRE_BLAST = reg("fire_blast");
    public static final DeferredHolder<SoundEvent, SoundEvent> SHOCKWAVE = reg("shockwave");
    public static final DeferredHolder<SoundEvent, SoundEvent> WIND_LOOP = reg("wind_loop");
    public static final DeferredHolder<SoundEvent, SoundEvent> CAPE_SNAP = reg("cape_snap");
    public static final DeferredHolder<SoundEvent, SoundEvent> BRAAM = reg("braam");
    public static final DeferredHolder<SoundEvent, SoundEvent> TRANSFORM = reg("transform");
    public static final DeferredHolder<SoundEvent, SoundEvent> TRANSFORM_ADAM = reg("transform_adam");

    // ------------------------------------------------ suara khas tiap skill (0.24.2)
    // *_WINDUP / *_CAST / MEHEN_RISE = ancang-ancang: panjangnya PERSIS sama dengan tick ancang-ancang di ShazamAnim,
    // jadi puncaknya jatuh tepat di tick hantaman. Putar di pitch 1 (jangan lewat tune()) supaya panjangnya nggak berubah.
    public static final DeferredHolder<SoundEvent, SoundEvent> SOLOMON_CAST = reg("solomon_cast");
    public static final DeferredHolder<SoundEvent, SoundEvent> SOLOMON_SIGHT = reg("solomon_sight");
    public static final DeferredHolder<SoundEvent, SoundEvent> HERCULES_WINDUP = reg("hercules_windup");
    public static final DeferredHolder<SoundEvent, SoundEvent> HERCULES_CLAP = reg("hercules_clap");
    public static final DeferredHolder<SoundEvent, SoundEvent> HERCULES_THROW = reg("hercules_throw");
    public static final DeferredHolder<SoundEvent, SoundEvent> ATLAS_WINDUP = reg("atlas_windup");
    public static final DeferredHolder<SoundEvent, SoundEvent> ATLAS_SLAM = reg("atlas_slam");
    public static final DeferredHolder<SoundEvent, SoundEvent> ZEUS_WINDUP = reg("zeus_windup");
    public static final DeferredHolder<SoundEvent, SoundEvent> ZEUS_SPEAR = reg("zeus_spear");
    public static final DeferredHolder<SoundEvent, SoundEvent> ACHILLES_WINDUP = reg("achilles_windup");
    public static final DeferredHolder<SoundEvent, SoundEvent> ACHILLES_WARCRY = reg("achilles_warcry");
    public static final DeferredHolder<SoundEvent, SoundEvent> COURAGE_NOVA = reg("courage_nova");
    public static final DeferredHolder<SoundEvent, SoundEvent> STORM_WINDUP = reg("storm_windup");
    public static final DeferredHolder<SoundEvent, SoundEvent> STORM_GODS = reg("storm_gods");
    public static final DeferredHolder<SoundEvent, SoundEvent> THUNDER_PUNCH = reg("thunder_punch");
    public static final DeferredHolder<SoundEvent, SoundEvent> MERCURY_BLINK = reg("mercury_blink");
    public static final DeferredHolder<SoundEvent, SoundEvent> SHU_VORTEX = reg("shu_vortex");
    public static final DeferredHolder<SoundEvent, SoundEvent> SHU_BURST = reg("shu_burst");
    public static final DeferredHolder<SoundEvent, SoundEvent> HERU_DIVE = reg("heru_dive");
    public static final DeferredHolder<SoundEvent, SoundEvent> HERU_LAND = reg("heru_land");
    public static final DeferredHolder<SoundEvent, SoundEvent> AMON_WINDUP = reg("amon_windup");
    public static final DeferredHolder<SoundEvent, SoundEvent> AMON_QUAKE = reg("amon_quake");
    public static final DeferredHolder<SoundEvent, SoundEvent> ZEHUTI_CAST = reg("zehuti_cast");
    public static final DeferredHolder<SoundEvent, SoundEvent> ZEHUTI_SEAL = reg("zehuti_seal");
    public static final DeferredHolder<SoundEvent, SoundEvent> ATON_WINDUP = reg("aton_windup");
    public static final DeferredHolder<SoundEvent, SoundEvent> ATON_RAY = reg("aton_ray");
    public static final DeferredHolder<SoundEvent, SoundEvent> MEHEN_RISE = reg("mehen_rise");
    public static final DeferredHolder<SoundEvent, SoundEvent> MEHEN_COIL = reg("mehen_coil");
    public static final DeferredHolder<SoundEvent, SoundEvent> MEHEN_BITE = reg("mehen_bite");
    public static final DeferredHolder<SoundEvent, SoundEvent> KAHNDAQ_WINDUP = reg("kahndaq_windup");
    public static final DeferredHolder<SoundEvent, SoundEvent> KAHNDAQ_WRATH = reg("kahndaq_wrath");
    public static final DeferredHolder<SoundEvent, SoundEvent> CALL_WINDUP = reg("call_windup");

    // ------------------------------------------------ Penangkal Petir Hidup (0.25)
    // ROD_STRIKE = petir menyambar Shazam tiap 2 detik: desis turun 0,15 dtk (= ShazamAnim.ROD_DESCENT) lalu retakan tepat di
    // tick hantaman. Sama seperti ancang-ancang, putar di pitch +-1 supaya retakannya nggak bergeser.
    public static final DeferredHolder<SoundEvent, SoundEvent> ROD_STRIKE = reg("rod_strike");

    // ------------------------------------------------ Kekuatan Keluarga (0.26)
    // FAMILY_WINDUP panjangnya PERSIS ShazamAnim.FAMILY_WINDUP (10 tick) dan memuncak di tick sambaran; putar di pitch 1.
    public static final DeferredHolder<SoundEvent, SoundEvent> FAMILY_WINDUP = reg("family_windup");
    public static final DeferredHolder<SoundEvent, SoundEvent> FAMILY_STRIKE = reg("family_strike");

    // ------------------------------------------------ Tangan Kahndaq (0.27, Black Adam)
    // ADAM_CATCH = proyektil berhenti di udara (desing macet + dengung menahan), ADAM_RELEASE = semua dilempar balik.
    public static final DeferredHolder<SoundEvent, SoundEvent> ADAM_CATCH = reg("adam_catch");
    public static final DeferredHolder<SoundEvent, SoundEvent> ADAM_RELEASE = reg("adam_release");

    private static DeferredHolder<SoundEvent, SoundEvent> reg(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(ShazamMod.id(name)));
    }

    // ======= Angka yang gampang diutak-atik =======
    /** Seberapa jauh nada SFX ikut angka pitch di kode (1 = penuh, 0 = selalu nada asli). Nada ke bawah dibiarkan
     *  lebih bebas supaya slow motion tetap terdengar berat. */
    private static final float PITCH_UP_FOLLOW = 0.4f;
    private static final float PITCH_DOWN_FOLLOW = 0.6f;

    /**
     * Angka pitch lama disetel untuk suara bawaan Minecraft (misalnya 0.4 supaya guntur vanila terdengar berat,
     * atau 1.9 supaya terdengar kecil). SFX baru sudah dibuat dengan nada yang pas, jadi angkanya dijinakkan
     * supaya suaranya nggak jadi melar atau cempreng.
     */
    public static float tune(float pitch) {
        float p = pitch < 1f ? 1f - (1f - pitch) * PITCH_DOWN_FOLLOW : 1f + (pitch - 1f) * PITCH_UP_FOLLOW;
        return Mth.clamp(p, 0.55f, 1.6f);
    }
}
