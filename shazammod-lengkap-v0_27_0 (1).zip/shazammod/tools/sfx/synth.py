"""
Synth SFX sinematik untuk mod Shazam.
Semua suara dibuat dari nol (numpy/scipy), mono 44.1 kHz (Minecraft butuh mono untuk suara berposisi).
"""
import numpy as np
from scipy import signal
import os, subprocess, json, sys

SR = 44100
OUT = sys.argv[1] if len(sys.argv) > 1 else "out"


# ------------------------------------------------------------------ dasar
def t_axis(dur):
    return np.arange(int(dur * SR)) / SR


def pad(x, dur):
    n = int(dur * SR)
    if len(x) >= n:
        return x[:n]
    return np.concatenate([x, np.zeros(n - len(x))])


def mix(*parts):
    n = max(len(p) for p in parts)
    out = np.zeros(n)
    for p in parts:
        out[:len(p)] += p
    return out


def at(x, sec, total=None):
    """Geser x mulai di detik sec."""
    off = np.zeros(int(sec * SR))
    y = np.concatenate([off, x])
    return pad(y, total) if total else y


def white(n, rng):
    return rng.standard_normal(n)


def pink(n, rng):
    w = rng.standard_normal(n)
    b, a = [0.049922035, -0.095993537, 0.050612699, -0.004408786], [1, -2.494956002, 2.017265875, -0.522189400]
    return signal.lfilter(b, a, w) * 4


def brown(n, rng):
    w = rng.standard_normal(n)
    y = signal.lfilter([1], [1, -0.995], w)
    return y / (np.max(np.abs(y)) + 1e-9)


def sos(kind, f, order=2):
    if kind == "bp":
        return signal.butter(order, [max(f[0], 10) / (SR / 2), min(f[1], SR / 2 - 100) / (SR / 2)], "band", output="sos")
    return signal.butter(order, min(max(f, 10), SR / 2 - 100) / (SR / 2), kind, output="sos")


def lp(x, f, o=2): return signal.sosfilt(sos("low", f, o), x)
def hp(x, f, o=2): return signal.sosfilt(sos("high", f, o), x)
def bp(x, lo, hi, o=2): return signal.sosfilt(sos("bp", (lo, hi), o), x)


def sweep_filter(x, f_curve, kind="low", q=0.9, block=256):
    """Filter yang frekuensinya berubah sepanjang waktu (state-variable filter per-sampel, blok koefisien)."""
    y = np.zeros_like(x)
    low = band = 0.0
    n = len(x)
    fc = np.interp(np.arange(n), np.linspace(0, n - 1, len(f_curve)), f_curve)
    damp = 1.0 / q
    for i in range(0, n, block):
        f = min(fc[i], SR / 6)
        g = 2 * np.sin(np.pi * f / SR)
        seg = x[i:i + block]
        out = np.empty_like(seg)
        for j, s in enumerate(seg):
            high = s - low - damp * band
            band += g * high
            low += g * band
            out[j] = low if kind == "low" else (band if kind == "band" else high)
        y[i:i + block] = out
    return y


def env_exp(n, tau):
    return np.exp(-np.arange(n) / (tau * SR))


def env_adsr(dur, a, d, s, r, curve=2.0):
    n = int(dur * SR)
    na, nd, nr = int(a * SR), int(d * SR), int(r * SR)
    ns = max(n - na - nd - nr, 0)
    e = np.concatenate([
        np.linspace(0, 1, max(na, 1)) ** curve,
        np.linspace(1, s, max(nd, 1)),
        np.full(ns, s),
        np.linspace(s, 0, max(nr, 1)) ** 1.5 if s > 0 else np.zeros(max(nr, 1)),
    ])
    return pad(e, dur)


def osc(freq, dur, kind="sine", phase=0.0):
    """freq bisa angka atau array (sweep)."""
    n = int(dur * SR)
    f = np.full(n, freq) if np.isscalar(freq) else np.interp(np.arange(n), np.linspace(0, n - 1, len(freq)), freq)
    ph = 2 * np.pi * np.cumsum(f) / SR + phase
    if kind == "sine":
        return np.sin(ph)
    if kind == "saw":   # saw band-limited kasar (polyBLEP sederhana)
        p = (ph / (2 * np.pi)) % 1.0
        dt = f / SR
        y = 2 * p - 1
        m1 = p < dt
        y[m1] -= (lambda t: t + t - t * t - 1)(p[m1] / dt[m1])
        m2 = p > 1 - dt
        y[m2] -= (lambda t: t * t + t + t + 1)((p[m2] - 1) / dt[m2])
        return y
    if kind == "tri":
        return 2 / np.pi * np.arcsin(np.sin(ph))
    if kind == "square":
        return np.tanh(4 * np.sin(ph))
    raise ValueError(kind)


def exp_sweep(f0, f1, dur, k=6.0):
    t = np.linspace(0, 1, int(dur * SR))
    return f1 + (f0 - f1) * np.exp(-k * t)


def supersaw(freq, dur, voices=7, detune=0.012, rng=None):
    rng = rng or np.random.default_rng(0)
    y = 0
    for v in range(voices):
        d = 1 + detune * (v - (voices - 1) / 2) / ((voices - 1) / 2)
        f = freq * d if np.isscalar(freq) else np.asarray(freq) * d
        y = y + osc(f, dur, "saw", rng.uniform(0, 2 * np.pi))
    return y / voices


def sat(x, drive=2.0):
    return np.tanh(x * drive) / np.tanh(drive)


def norm(x, peak=0.89):
    m = np.max(np.abs(x))
    return x if m < 1e-9 else x * (peak / m)


def fade(x, fin=0.002, fout=0.05):
    n = len(x)
    a, b = int(fin * SR), int(fout * SR)
    e = np.ones(n)
    if a:
        e[:a] = np.linspace(0, 1, a)
    if b:
        e[-b:] *= np.linspace(1, 0, b) ** 2
    return x * e


def reverb(x, decay=2.0, mix_=0.35, pre=0.012, bright=6000, rng=None, size=1.0):
    """Reverb konvolusi dengan IR buatan (noise yang meluruh, makin gelap di ekornya)."""
    rng = rng or np.random.default_rng(7)
    n = int(decay * 1.4 * SR)
    ir = rng.standard_normal(n) * env_exp(n, decay / 6.9)
    # ekor makin gelap
    w = np.linspace(0, 1, n) ** 0.7
    ir = lp(ir, bright) * (1 - w) + lp(ir, bright * 0.3) * w
    # pantulan awal
    er = np.zeros(int(0.08 * SR * size))
    for k in range(12):
        idx = int(rng.uniform(0.004, 0.075) * SR * size)
        if idx < len(er):
            er[idx] += rng.uniform(-0.6, 0.6)
    ir = mix(er, at(ir, pre))
    ir /= np.sqrt(np.sum(ir ** 2)) + 1e-9
    wet = signal.fftconvolve(x, ir)[: len(x) + len(ir)]
    dry = np.concatenate([x, np.zeros(len(wet) - len(x))])
    return dry * (1 - mix_) + wet * mix_ * 1.6


def trim_tail(x, thresh_db=-62):
    th = 10 ** (thresh_db / 20) * np.max(np.abs(x))
    idx = np.where(np.abs(x) > th)[0]
    end = idx[-1] + int(0.02 * SR) if len(idx) else len(x)
    return x[:end]


def limiter(x, ceiling=0.89, release=0.08):
    """Limiter sederhana dengan look-ahead kecil supaya suara keras tetap tebal tanpa pecah."""
    env = np.abs(x)
    env = signal.lfilter([1], [1, -np.exp(-1 / (release * SR))], env) * (1 - np.exp(-1 / (release * SR)))
    env = np.maximum(env, np.abs(x))
    gain = np.minimum(1.0, ceiling / (env + 1e-9))
    gain = signal.filtfilt([0.02], [1, -0.98], gain)
    return x * np.minimum(gain, 1.0)


def crackle(dur, density, rng, lo=2000, hi=9000, decay=0.003, curve=None):
    """Percikan listrik / retakan: impuls acak tersaring."""
    n = int(dur * SR)
    y = np.zeros(n)
    dens = np.full(n, density) if curve is None else np.interp(np.arange(n), np.linspace(0, n - 1, len(curve)), curve) * density
    p = dens / SR
    hits = np.where(rng.random(n) < p)[0]
    ker_n = int(decay * 6 * SR)
    ker = rng.standard_normal(ker_n) * env_exp(ker_n, decay)
    for h in hits:
        a = rng.uniform(0.3, 1.0) * (1 if rng.random() < 0.5 else -1)
        e = min(n, h + ker_n)
        y[h:e] += a * ker[: e - h]
    return bp(y, lo, hi)


def bell(freq, dur, rng, partials=((1, 1), (2.76, 0.5), (5.4, 0.25), (8.93, 0.12)), tau=0.8, detune=0.0015):
    y = 0
    for r, a in partials:
        f = freq * r * (1 + rng.uniform(-detune, detune))
        if f > 16000:
            continue
        y = y + a * osc(f, dur) * env_exp(int(dur * SR), tau / (r ** 0.5))
    n = int(dur * SR)
    att = np.minimum(1, np.arange(n) / (0.002 * SR))
    rel = np.minimum(1, (n - np.arange(n)) / (min(0.6, dur * 0.4) * SR)) ** 2   # ekor nggak terpotong
    return y * att * rel


def formant(x, vowel="a"):
    F = {"a": [(800, 1.0), (1150, 0.6), (2900, 0.25)], "o": [(450, 1.0), (800, 0.5), (2830, 0.15)],
         "u": [(325, 1.0), (700, 0.35), (2530, 0.1)], "e": [(400, 1.0), (1600, 0.5), (2700, 0.25)]}[vowel]
    y = 0
    for f, a in F:
        y = y + a * bp(x, f * 0.85, f * 1.15, 2)
    return y


def choir(freqs, dur, rng, vowel="a", vib=5.2):
    t = t_axis(dur)
    y = 0
    for f in freqs:
        for v in range(4):
            vf = f * (1 + rng.uniform(-0.006, 0.006)) * (1 + 0.004 * np.sin(2 * np.pi * (vib + rng.uniform(-0.5, 0.5)) * t + rng.uniform(0, 6)))
            y = y + osc(vf, dur, "saw", rng.uniform(0, 6))
    y = formant(y, vowel) + 0.15 * lp(y, 900)
    return y


def reverse_swell(dur, rng, lo=600, hi=12000):
    """'Reverse cymbal' / tarikan napas sebelum hantaman."""
    n = int(dur * SR)
    x = hp(white(n, rng), lo) * env_exp(n, dur / 4)[::-1]
    x = sweep_filter(x, np.linspace(1500, hi, 64), "low", 0.8)
    return x


def sub_drop(f0, f1, dur, tau, k=5.0):
    n = int(dur * SR)
    return osc(exp_sweep(f0, f1, dur, k), dur) * env_exp(n, tau) * np.minimum(1, np.arange(n) / (0.003 * SR))


# ------------------------------------------------------------------ resep suara
def thunder(rng, v):
    dur = 6.0 + v * 0.4
    n = int(dur * SR)
    # retakan awal: beberapa sambaran di 0-200 ms
    crack = crackle(0.35, 900, rng, 1500, 12000, 0.0025, np.linspace(1, 0.05, 50) ** 2) * 1.6
    snap = hp(white(int(0.03 * SR), rng), 900) * env_exp(int(0.03 * SR), 0.006) * 2.5
    # gemuruh: brown noise lowpass yang menutup + gelombang ledakan kecil acak
    rum = brown(n, rng)
    bursts = np.zeros(n)
    tt = 0.15
    while tt < dur * 0.75:
        k = int(tt * SR)
        L = int(rng.uniform(0.3, 1.1) * SR)
        e = env_adsr(L / SR, rng.uniform(0.03, 0.2), 0.1, 0.6, L / SR * 0.6) * rng.uniform(0.4, 1.0) * np.exp(-tt / 2.2)
        bursts[k:k + len(e)] += e[: max(0, min(len(e), n - k))]
        tt += rng.uniform(0.18, 0.55)
    base = env_adsr(dur, 0.06, 0.6, 0.55, dur * 0.7) * 0.6
    rum = sweep_filter(rum, np.geomspace(1400, 110, 80), "low", 0.8) * (base + bursts)
    rum = rum + 0.6 * lp(pink(n, rng), 300) * (bursts * 0.7)
    sub = sub_drop(62, 32, dur, 1.6, 2.0) * 0.55
    y = mix(snap, crack, rum * 1.4, sub)
    y = reverb(sat(y, 1.6), 3.5, 0.3, rng=rng, size=2.0)
    return y


def lightning_strike(rng, v):
    dur = 2.2
    n = int(dur * SR)
    snap = hp(white(int(0.02 * SR), rng), 2000) * env_exp(int(0.02 * SR), 0.004) * 3
    zap_curve = np.concatenate([np.ones(10), np.linspace(1, 0, 40) ** 3])
    zap = crackle(1.1, 2600, rng, 1800, 14000, 0.0015, zap_curve) * 1.5
    # dengung listrik (arc buzz)
    buzzf = 95 + v * 12
    buzz = osc(buzzf * (1 + 0.03 * rng.standard_normal(int(1.0 * SR)).cumsum() / 300), 1.0, "saw")
    buzz = bp(sat(buzz, 3), 300, 4000) * env_exp(int(1.0 * SR), 0.18) * (0.6 + 0.4 * (rng.random(int(1.0 * SR)) > 0.35))
    boom = sub_drop(140, 38, 1.6, 0.35, 7) * 1.3
    body = lp(white(int(0.6 * SR), rng), 500) * env_exp(int(0.6 * SR), 0.09) * 1.2
    y = mix(snap, zap, buzz * 0.45, boom, body)
    return reverb(sat(y, 1.8), 2.2, 0.3, rng=rng)


def impact(rng, v):
    dur = 3.2
    click = hp(white(int(0.008 * SR), rng), 3000) * env_exp(int(0.008 * SR), 0.0015) * 2
    kick = sub_drop(150 - v * 10, 34, 1.8, 0.45, 9) * 1.6
    body = lp(white(int(0.5 * SR), rng), 380) * env_exp(int(0.5 * SR), 0.07) * 2.2
    crunch = bp(white(int(0.25 * SR), rng), 600, 4000) * env_exp(int(0.25 * SR), 0.04) * 0.9
    debris = crackle(1.5, 140, rng, 300, 3500, 0.006, np.linspace(1, 0, 40) ** 2) * 0.7
    rumble = lp(brown(int(dur * SR), rng), 160) * env_adsr(dur, 0.02, 0.3, 0.4, dur * 0.8) * 0.8
    y = mix(click, kick, body, crunch, at(debris, 0.05), rumble)
    y = sat(y, 2.2)
    return reverb(y, 2.6, 0.28, rng=rng, size=1.6)


def impact_ring(rng, v):
    dur = 3.5
    f = [196.0, 174.6, 220.0][v % 3]
    ring = bell(f, dur, rng, ((1, 1), (2.32, 0.6), (3.86, 0.4), (5.12, 0.25), (6.9, 0.15)), tau=1.3, detune=0.004)
    low = bell(f / 2, dur, rng, ((1, 1), (1.5, 0.3)), tau=1.6) * 0.7
    hit = hp(white(int(0.02 * SR), rng), 2500) * env_exp(int(0.02 * SR), 0.004)
    y = mix(ring * 0.6, low * 0.6, hit)
    return reverb(y, 3.0, 0.4, rng=rng, size=1.8)


def body_hit(rng, v):
    dur = 0.9
    thump = sub_drop(110, 45, dur, 0.12, 10) * 1.4
    slap = bp(white(int(0.12 * SR), rng), 250, 2500) * env_exp(int(0.12 * SR), 0.025)
    y = sat(mix(thump, slap), 2.5)
    return reverb(y, 0.9, 0.18, rng=rng)


def whoosh(rng, v, heavy=False):
    dur = (1.35 if heavy else 0.95) + v * 0.06
    n = int(dur * SR)
    x = pink(n, rng) if heavy else white(n, rng)
    peak = rng.uniform(0.45, 0.6)
    shape = np.concatenate([np.linspace(0, 1, int(peak * 64)) ** 2.2, np.linspace(1, 0, 64 - int(peak * 64)) ** 1.4])
    if heavy:
        fcurve = 140 + 1300 * shape
    else:
        fcurve = 350 + 3800 * shape
    y = sweep_filter(x, fcurve, "band", 1.6 if not heavy else 1.2)
    amp = np.interp(np.arange(n), np.linspace(0, n - 1, len(shape)), shape)
    y = y * amp
    if heavy:   # kepakan/flutter berat + sub
        flutter = 1 + 0.35 * np.sin(2 * np.pi * np.linspace(9, 4, n).cumsum() / SR)
        y = y * flutter + osc(exp_sweep(70, 40, dur, 2), dur) * amp ** 2 * 0.35
    return reverb(y, 1.2, 0.2, rng=rng)


def power_up(rng, v):
    rdur, tail = 1.3, 3.0
    f = np.geomspace(110, 440, int(rdur * SR)) * (1 + v * 0.06)
    riser = supersaw(f, rdur, 7, 0.015, rng) + 0.6 * supersaw(f * 1.5, rdur, 5, 0.015, rng)
    riser = sweep_filter(riser, np.geomspace(300, 7000, 64), "low", 1.2) * np.linspace(0.05, 1, int(rdur * SR)) ** 2
    nz = sweep_filter(white(int(rdur * SR), rng), np.geomspace(500, 10000, 64), "band", 2) * np.linspace(0, 1, int(rdur * SR)) ** 3
    hit_t = rdur
    chord = [440, 554.4, 659.3, 880]
    pad_ = sum(supersaw(c * (1 + v * 0.06), tail, 5, 0.01, rng) for c in chord) * env_adsr(tail, 0.005, 0.4, 0.3, tail * 0.7)
    pad_ = lp(pad_, 5000) * 0.5
    shim = sum(bell(rng.choice([1760, 2217, 2637, 3520]), tail, rng, tau=0.6) * 0.3 for _ in range(8))
    boom = sub_drop(90, 40, 1.5, 0.4, 6)
    y = mix(riser * 0.6, nz * 0.25, at(pad_, hit_t), at(shim, hit_t + 0.02), at(boom, hit_t))
    return reverb(sat(y, 1.4), 2.8, 0.38, rng=rng, size=1.5)


def aura_swell(rng, v):
    dur = 3.2
    root = [146.8, 130.8][v % 2]
    ch = choir([root, root * 1.5, root * 2, root * 2.52], dur, rng, "a")
    e = env_adsr(dur, 1.6, 0.4, 0.8, 1.0, 1.6)
    low = supersaw(root / 2, dur, 5, 0.008, rng)
    low = lp(low, 600) * e * 0.6
    air = reverse_swell(dur * 0.6, rng, 1000, 9000) * 0.2
    y = mix(ch * e, low, at(air, dur * 0.35))
    return reverb(y, 3.5, 0.45, rng=rng, size=2.2)


def power_down(rng, v):
    dur = 2.0
    f = np.geomspace(520, 70, int(dur * SR)) * (1 + v * 0.05)
    tone = supersaw(f, dur, 6, 0.02, rng)
    tone = sweep_filter(tone, np.geomspace(6000, 250, 64), "low", 1.4) * env_adsr(dur, 0.01, 0.2, 0.7, 1.3)
    nz = sweep_filter(white(int(dur * SR), rng), np.geomspace(8000, 300, 64), "band", 1.5) * env_exp(int(dur * SR), 0.5) * 0.4
    zap = crackle(0.5, 600, rng, 2000, 9000, 0.002, np.linspace(1, 0, 20)) * 0.5
    y = mix(tone * 0.7, nz, zap)
    return reverb(y, 2.0, 0.35, rng=rng)


def energy_pulse(rng, v):
    dur = 1.3
    f = [523.25, 587.3, 659.3][v % 3]
    n = int(dur * SR)
    mod = osc(f * 2.01, dur) * 3.0 * env_exp(n, 0.15)
    car = np.sin(2 * np.pi * np.cumsum(np.full(n, f)) / SR + mod)
    car = car * env_exp(n, 0.35) * np.minimum(1, np.arange(n) / (0.003 * SR))
    sub = osc(f / 4, dur) * env_exp(n, 0.12) * 0.6
    sh = bell(f * 4, dur, rng, tau=0.4) * 0.25
    y = mix(car * 0.7, sub, sh)
    return reverb(y, 1.8, 0.4, rng=rng)


def charge(rng, v, dur=2.2):
    n = int(dur * SR)
    t = np.linspace(0, 1, n)
    f = 80 * (1 + 5 * t ** 2) * (1 + v * 0.05)
    tone = supersaw(f, dur, 6, 0.02, rng) + 0.5 * supersaw(f * 2, dur, 4, 0.02, rng)
    trem = 0.6 + 0.4 * np.sin(2 * np.pi * np.cumsum(3 + 22 * t ** 2) / SR)
    tone = sweep_filter(tone, np.geomspace(200, 8000, 64), "low", 1.5) * trem * t ** 1.5
    nz = sweep_filter(white(n, rng), np.geomspace(400, 12000, 64), "band", 2.5) * t ** 3
    zap = crackle(dur, 400, rng, 2500, 12000, 0.0015, np.linspace(0, 1, 50) ** 3) * 0.6
    y = mix(tone * 0.7, nz * 0.35, zap)
    y = fade(y, 0.01, 0.015)
    return reverb(y, 1.6, 0.25, rng=rng)


def riser(rng, v):
    """Tarikan sebelum petir transformasi menyambar: berhenti mendadak (hantamannya dari TRANSFORM)."""
    dur = 2.6
    n = int(dur * SR)
    t = np.linspace(0, 1, n)
    rs = reverse_swell(dur, rng, 400, 14000) * 0.6
    f = 55 * 2 ** (3 * t ** 1.6)
    sh = sweep_filter(supersaw(f, dur, 8, 0.02, rng), np.geomspace(200, 9000, 64), "low", 1.6) * t ** 2
    pulse = osc(np.geomspace(2, 16, n), dur, "sine") * 0.5 + 0.5
    hb = sub_drop(60, 40, dur, 10, 1) * pulse * t * 0.6
    y = mix(rs, sh * 0.6, hb)
    y = y * np.concatenate([np.ones(n - int(0.01 * SR)), np.linspace(1, 0, int(0.01 * SR))])
    return reverb(y, 1.2, 0.15, rng=rng)


def shimmer(rng, v):
    dur = 2.4
    scale = [1046.5, 1174.7, 1318.5, 1568, 1760, 2093, 2349.3, 2637, 3136]
    y = np.zeros(int(dur * SR))
    k = 0.0
    for i in range(10 + v * 2):
        b = bell(rng.choice(scale) * (1 if rng.random() > 0.2 else 0.5), dur - k, rng, tau=0.7) * rng.uniform(0.3, 0.8)
        y += at(b, k, dur)
        k += rng.uniform(0.015, 0.07)
    sp = hp(crackle(0.8, 300, rng, 5000, 14000, 0.001, np.linspace(1, 0, 20)), 5000) * 0.2
    y = mix(y, sp)
    return reverb(y, 2.4, 0.5, rng=rng, bright=9000)


def resonance(rng, v):
    dur = 3.0
    f = [220.0, 196.0][v % 2]
    n = int(dur * SR)
    y = 0
    for r, a in ((1, 1), (2.71, 0.5), (5.15, 0.3), (8.4, 0.12)):
        beat = 1 + 0.5 * np.sin(2 * np.pi * rng.uniform(1.5, 4) * t_axis(dur))
        y = y + a * osc(f * r, dur) * beat
    e = env_adsr(dur, 0.25, 0.4, 0.7, 1.8)
    pad_ = lp(supersaw(f / 2, dur, 5, 0.01, rng), 800) * 0.3
    y = (y * 0.4 + pad_) * e
    return reverb(y, 3.0, 0.5, rng=rng)


def spell(rng, v):
    dur = 1.8
    n = int(dur * SR)
    t = t_axis(dur)
    swirl = sweep_filter(white(n, rng), 1500 + 1200 * np.sin(2 * np.pi * 2.5 * np.linspace(0, dur, 64)) + np.linspace(0, 2500, 64), "band", 3)
    swirl *= env_adsr(dur, 0.25, 0.3, 0.5, 1.0) * 0.5
    f0 = [392, 440][v % 2]
    tones = 0
    for i, r in enumerate([1, 1.5, 2, 3]):
        tones = tones + osc(f0 * r * (1 + 0.01 * np.sin(2 * np.pi * 6 * t)), dur) * env_adsr(dur, 0.05 + i * 0.12, 0.3, 0.4, 1.0) * (0.5 / (i + 1))
    sh = shimmer(rng, 0)[: n] * 0.3
    y = mix(swirl, tones, sh)
    return reverb(y, 2.2, 0.45, rng=rng)


def sonic_boom(rng, v):
    dur = 3.0
    pre = reverse_swell(0.35, rng, 800, 9000) * 0.5
    n1 = hp(white(int(0.012 * SR), rng), 400) * env_exp(int(0.012 * SR), 0.003) * 3
    n2 = at(n1 * -0.8, 0.045)
    boom = sub_drop(110, 30, 2.2, 0.55, 5) * 1.7
    air = sweep_filter(white(int(1.5 * SR), rng), np.geomspace(5000, 200, 64), "low", 0.9) * env_exp(int(1.5 * SR), 0.3)
    y = mix(pre, at(mix(n1, n2, boom, air * 0.9), 0.35))
    return reverb(sat(y, 2.0), 2.6, 0.3, rng=rng, size=2.0)


def divine(rng, v):
    dur = 3.6
    root = [261.6, 293.7][v % 2]
    ch = choir([root, root * 1.25, root * 1.5, root * 2], dur, rng, "o" if v else "a")
    e = env_adsr(dur, 0.12, 0.6, 0.6, 2.4)
    bells_ = sum(at(bell(root * m, dur - 0.05 * i, rng, tau=1.2), 0.05 * i, dur) * 0.25 for i, m in enumerate([4, 5, 6, 8]))
    y = mix(ch * e * 0.8, bells_, sub_drop(80, 50, dur, 0.6, 3) * 0.5)
    return reverb(y, 3.6, 0.5, rng=rng, size=2.2, bright=8000)


def punch(rng, v, crit=False):
    dur = 0.9 if not crit else 1.4
    pre = sweep_filter(white(int(0.09 * SR), rng), np.linspace(800, 3000, 16), "band", 1.5) * np.linspace(0, 1, int(0.09 * SR)) ** 2 * 0.5
    k = sub_drop(130 - v * 8, 48, dur, 0.11, 12) * 1.7
    smack = bp(white(int(0.07 * SR), rng), 400, 5000) * env_exp(int(0.07 * SR), 0.012) * 1.5
    y = mix(pre, at(mix(k, smack), 0.09))
    if crit:
        crk = hp(white(int(0.015 * SR), rng), 3000) * env_exp(int(0.015 * SR), 0.002) * 2.5
        ring = bell(880 + v * 60, 1.2, rng, tau=0.5) * 0.25
        y = mix(y, at(crk, 0.09), at(ring, 0.1))
    return reverb(sat(y, 2.4), 1.1, 0.2, rng=rng)


def deflect(rng, v):
    dur = 1.6
    ring = bell(620 + v * 70, dur, rng, ((1, 1), (2.41, 0.6), (3.9, 0.45), (5.6, 0.3), (7.8, 0.2)), tau=0.45, detune=0.006)
    hit = hp(white(int(0.012 * SR), rng), 2000) * env_exp(int(0.012 * SR), 0.003) * 2
    th = sub_drop(100, 60, 0.4, 0.06, 8)
    return reverb(mix(ring * 0.6, hit, th), 1.5, 0.3, rng=rng)


def dark_hiss(rng, v):
    dur = 2.2
    n = int(dur * SR)
    hs = formant(white(n, rng), "u" if v else "o") * 0.7 + hp(white(n, rng), 3500) * 0.25
    hs *= env_adsr(dur, 0.08, 0.3, 0.5, 1.4) * (0.75 + 0.25 * np.sin(2 * np.pi * 11 * t_axis(dur)))
    drone = sat(lp(supersaw(np.linspace(55, 46, n), dur, 5, 0.03, rng), 500), 3) * env_adsr(dur, 0.1, 0.4, 0.6, 1.3) * 0.6
    rev = (lp(white(int(0.5 * SR), rng), 2500) * env_exp(int(0.5 * SR), 0.12))[::-1] * 0.5
    y = mix(rev, at(mix(hs, drone), 0.5))
    return reverb(y, 2.4, 0.4, rng=rng)


def dread(rng, v):
    dur = 4.0
    n = int(dur * SR)
    root = [41.2, 43.65][v % 2]
    cl = 0
    for f in (root, root * 1.06, root * 2, root * 2.12, root * 3):
        cl = cl + supersaw(f, dur, 4, 0.01, rng)
    cl = sweep_filter(cl, np.concatenate([np.geomspace(150, 1400, 20), np.geomspace(1400, 200, 44)]), "low", 1.5)
    cl = sat(cl * env_adsr(dur, 0.04, 0.6, 0.6, 2.6), 2.5)
    rs = reverse_swell(1.0, rng, 300, 8000) * 0.4
    y = mix(rs, at(mix(cl * 0.7, sub_drop(70, 35, dur - 1, 1.2, 3) * 0.8), 1.0))
    return reverb(y, 3.5, 0.4, rng=rng, size=2.0)


def heartbeat(rng, v):
    dur = 1.4
    def beat(a):
        return mix(sub_drop(70, 38, 0.5, 0.08, 6) * a, lp(white(int(0.05 * SR), rng), 200) * env_exp(int(0.05 * SR), 0.015) * a * 0.6)
    y = mix(beat(1.4), at(beat(1.0), 0.24))
    return reverb(sat(y, 2), 1.4, 0.25, rng=rng)


def sand_burst(rng, v):
    dur = 1.8
    n = int(dur * SR)
    gr = crackle(dur, 4000, rng, 1500, 11000, 0.0008, np.concatenate([np.linspace(0.2, 1, 6), np.linspace(1, 0, 40) ** 2])) * 0.7
    body = sweep_filter(pink(n, rng), np.geomspace(3000, 400, 64), "low", 0.8) * env_adsr(dur, 0.02, 0.4, 0.4, 1.2)
    th = sub_drop(90, 45, 0.8, 0.15, 6) * 0.8
    return reverb(mix(gr, body * 0.9, th), 1.6, 0.3, rng=rng)


def earth_crack(rng, v):
    dur = 2.2
    n = int(dur * SR)
    cr = 0
    for lo, hi in ((150, 600), (500, 1800), (1500, 5000)):
        cr = cr + crackle(1.2, 120, rng, lo, hi, 0.008, np.linspace(1, 0, 30) ** 1.5)
    rum = lp(brown(n, rng), 120) * env_adsr(dur, 0.03, 0.5, 0.5, 1.5)
    k = sub_drop(100, 35, 1.5, 0.3, 6)
    return reverb(sat(mix(cr * 1.2, rum, k), 2), 2.0, 0.3, rng=rng)


def fire_blast(rng, v):
    dur = 1.8
    n = int(dur * SR)
    roar = sweep_filter(pink(n, rng), np.concatenate([np.geomspace(300, 2400, 16), np.geomspace(2400, 400, 48)]), "band", 1.0)
    roar *= env_adsr(dur, 0.04, 0.4, 0.5, 1.2) * (0.7 + 0.3 * np.abs(lp(rng.standard_normal(n), 25)) * 6)
    cr = crackle(dur, 250, rng, 1500, 7000, 0.002, np.linspace(1, 0, 20)) * 0.4
    th = sub_drop(80, 40, 1.0, 0.2, 5)
    return reverb(sat(mix(roar * 1.2, cr, th), 1.8), 1.6, 0.25, rng=rng)


def shockwave(rng, v):
    dur = 3.0
    n = int(dur * SR)
    rum = sweep_filter(brown(n, rng), np.geomspace(900, 80, 64), "low", 0.8) * env_adsr(dur, 0.01, 0.5, 0.5, 2.0) * 1.4
    air = sweep_filter(white(n, rng), np.geomspace(6000, 300, 64), "band", 1.2) * env_exp(n, 0.45) * 0.6
    k = sub_drop(75, 28, dur, 0.9, 3) * 1.2
    return reverb(sat(mix(rum, air, k), 1.8), 2.8, 0.3, rng=rng, size=2.0)


def wind_loop(rng, v):
    """Angin terbang yang bisa diputar ulang tanpa sambungan (6 detik)."""
    dur = 6.0
    n = int(dur * SR)
    L = n + int(1.0 * SR)
    x = pink(L, rng)
    # modulasi periodik (kelipatan 1/dur) supaya loop mulus
    tt = np.arange(L) / SR
    mod = 0.6 + 0.25 * np.sin(2 * np.pi * tt / dur * 2) + 0.15 * np.sin(2 * np.pi * tt / dur * 5 + 1)
    fc = 500 + 700 * (0.5 + 0.5 * np.sin(2 * np.pi * np.linspace(0, L / SR, 96) / dur * 3))
    y = sweep_filter(x, fc, "band", 0.9) * mod
    y = y + 0.4 * lp(x, 250) * mod
    y = y + 0.12 * hp(x, 4000) * mod
    # crossfade ujung ke awal
    xf = int(1.0 * SR)
    a = y[:n].copy()
    w = np.linspace(0, 1, xf)
    a[:xf] = a[:xf] * w + y[n:n + xf] * (1 - w)
    return a


def cape_snap(rng, v):
    dur = 0.55
    n = int(dur * SR)
    x = bp(white(n, rng), 700, 4500)
    fl = 0.5 + 0.5 * np.sign(np.sin(2 * np.pi * np.cumsum(np.linspace(28, 14, n)) / SR)) * 0.6
    e = env_adsr(dur, 0.03, 0.08, 0.4, 0.35)
    snap = hp(white(int(0.01 * SR), rng), 1500) * env_exp(int(0.01 * SR), 0.002) * 0.5
    y = mix(x * fl * e * 0.8, at(snap, 0.04))
    return reverb(y, 0.6, 0.12, rng=rng)


def braam(rng, v):
    dur = 4.5
    n = int(dur * SR)
    root = [55.0, 49.0, 51.9][v % 3]
    y = 0
    for f, a in ((root, 1), (root * 1.5, 0.7), (root * 2, 0.6), (root * 3, 0.25)):
        y = y + a * supersaw(f, dur, 7, 0.01, rng)
    fc = np.concatenate([np.geomspace(250, 2200, 6), np.geomspace(2200, 300, 58)])
    y = sweep_filter(y, fc, "low", 2.0)
    y = sat(y * env_adsr(dur, 0.015, 1.0, 0.6, 3.0) * 1.5, 3.0)
    sub = osc(root / 2 if root > 50 else root, dur) * env_adsr(dur, 0.01, 1.0, 0.6, 3.0) * 0.6
    hit = sub_drop(120, 40, 1.2, 0.25, 8) * 0.9
    out = mix(y * 0.8, sub, hit)
    return reverb(out, 4.0, 0.35, rng=rng, size=2.4)


def transform(rng, v):
    """Hantaman SHAZAM!: retakan petir + braam + sub + hujan percikan + paduan suara ilahi di ekornya."""
    dur = 7.0
    crack = mix(hp(white(int(0.03 * SR), rng), 1500) * env_exp(int(0.03 * SR), 0.005) * 3,
                crackle(0.8, 2400, rng, 1500, 14000, 0.002, np.linspace(1, 0, 30) ** 2) * 1.6)
    b = braam(rng, 1 if v else 0)
    kick = sub_drop(160, 30, 2.5, 0.7, 7) * 1.6
    th = thunder(rng, 0) * 0.55
    if v == 0:   # Shazam: ekor ilahi yang terang
        tail = divine(rng, 0) * 0.5
    else:        # Black Adam: ekor gelap
        tail = dread(rng, 0)[int(1.0 * SR):] * 0.6
    y = mix(crack, b * 0.9, kick, at(th, 0.05), at(tail, 0.35))
    y = limiter(sat(y, 1.3), 0.95)
    return y


RECIPES = {
    # nama: (fungsi, jumlah varian, gain relatif)
    "thunder": (thunder, 3, 1.0),
    "lightning_strike": (lightning_strike, 3, 1.0),
    "impact": (impact, 3, 1.0),
    "impact_ring": (impact_ring, 3, 0.75),
    "body_hit": (body_hit, 2, 0.9),
    "whoosh": (lambda r, v: whoosh(r, v, False), 3, 0.85),
    "whoosh_heavy": (lambda r, v: whoosh(r, v, True), 3, 0.9),
    "power_up": (power_up, 2, 0.85),
    "aura_swell": (aura_swell, 2, 0.8),
    "power_down": (power_down, 2, 0.8),
    "energy_pulse": (energy_pulse, 3, 0.7),
    "charge": (charge, 2, 0.8),
    "riser": (riser, 2, 0.85),
    "shimmer": (shimmer, 3, 0.7),
    "resonance": (resonance, 2, 0.7),
    "spell": (spell, 2, 0.75),
    "sonic_boom": (sonic_boom, 2, 1.0),
    "divine": (divine, 2, 0.8),
    "punch": (lambda r, v: punch(r, v, False), 3, 0.95),
    "punch_crit": (lambda r, v: punch(r, v, True), 2, 0.95),
    "deflect": (deflect, 2, 0.8),
    "dark_hiss": (dark_hiss, 2, 0.8),
    "dread": (dread, 2, 0.9),
    "heartbeat": (heartbeat, 1, 1.0),
    "sand_burst": (sand_burst, 2, 0.8),
    "earth_crack": (earth_crack, 2, 0.95),
    "fire_blast": (fire_blast, 2, 0.9),
    "shockwave": (shockwave, 2, 0.95),
    "wind_loop": (wind_loop, 1, 0.8),
    "cape_snap": (cape_snap, 2, 0.6),
    "braam": (braam, 3, 1.0),
    "transform": (transform, 2, 1.0),   # varian 1 = Black Adam (dipilih lewat event terpisah)
}


# ================================================================== SFX khas tiap skill (0.24.2)
# Ancang-ancang (windup) dibuat dengan panjang PERSIS sama dengan tick ancang-ancang di ShazamAnim
# (1 tick = 0.05 dtk), jadi puncaknya jatuh tepat di tick hantaman seperti VFX 0.24.

def cut_at(y, sec, tail=0.025, rise=1.8):
    """Potong tepat di detik sec (= tick hantaman), dengan crescendo yang memuncak di titik itu dan ekor
    pendek yang meluruh cepat supaya nggak 'klik'."""
    n = int(sec * SR)
    y = pad(y, sec + tail).copy()
    y[:n] *= (0.08 + 0.92 * np.linspace(0, 1, n) ** rise)
    y[n:] *= np.exp(-np.arange(len(y) - n) / (tail / 5 * SR))
    return y


def reverse_of(x, dur):
    """Gema yang dibalik: membesar lalu berakhir di titik serangnya (efek 'reverse' film)."""
    r = x[::-1]
    n = int(dur * SR)
    return r[-n:] if len(r) >= n else np.concatenate([np.zeros(n - len(r)), r])


def comb_sweep(x, f0, f1, fb=0.85):
    """Comb filter yang nadanya menyapu: bunyi logam 'shiiing' seperti bilah ditarik."""
    n = len(x)
    f = np.geomspace(f0, f1, n)
    y = np.zeros(n)
    for i in range(n):
        j = i - SR / f[i]
        if j >= 1:
            k = int(j)
            fr = j - k
            d = y[k] * (1 - fr) + y[k + 1] * fr
        else:
            d = 0.0
        y[i] = x[i] + fb * d
    return y


def transient(n_sec, lo, tau, amp, rng):
    n = int(n_sec * SR)
    return hp(white(n, rng), lo) * env_exp(n, tau) * amp


def war_horn(dur, root, rng):
    tt = t_axis(dur)
    bend = 1 - 0.06 * np.exp(-tt / 0.08)                       # nada menyendok naik di awal
    vib = 1 + 0.006 * np.sin(2 * np.pi * 5.5 * tt) * np.minimum(1, tt / 0.5)
    y = 0
    for r, a in ((1, 1), (1.5, 0.6), (2, 0.55), (3, 0.2)):
        y = y + a * supersaw(root * r * bend * vib, dur, 5, 0.006, rng)
    y = sweep_filter(y, np.concatenate([np.geomspace(300, 3500, 8), np.full(40, 3000), np.geomspace(3000, 800, 16)]), "low", 1.4)
    y = formant(y, "o") * 0.7 + y * 0.5
    return sat(y * env_adsr(dur, 0.04, 0.3, 0.8, dur * 0.5), 2.2)


def screech(dur, rng, f0=3000):
    """Pekik elang: nada tinggi yang naik sedikit lalu turun, kasar."""
    n = int(dur * SR)
    t = np.linspace(0, 1, n)
    jit = 1 + 0.01 * lp(rng.standard_normal(n), 60) * 20
    f = f0 * (1.0 + 0.12 * np.sin(np.pi * t)) * (1 - 0.25 * t) * jit
    car = np.sin(2 * np.pi * np.cumsum(f) / SR + osc(f * 0.5, dur) * 1.8)
    rough = bp(white(n, rng), f0 * 0.6, f0 * 1.6) * 0.35
    y = (car * 0.7 + rough) * env_adsr(dur, 0.02, 0.1, 0.7, dur * 0.6)
    return hp(sat(y, 2.0), 900)


def rattle(dur, rng, rate=24.0):
    """Getar ekor ular."""
    n = int(dur * SR)
    gate = lp((np.sin(2 * np.pi * np.cumsum(np.full(n, rate)) / SR) > 0.2).astype(float), 400)
    return bp(white(n, rng), 2500, 9000) * gate


def roar(dur, f0, rng):
    """Raungan buatan: sumber kasar + formant yang bergeser 'aaa' -> 'ooo'."""
    n = int(dur * SR)
    t = np.linspace(0, 1, n)
    jit = 1 + 0.04 * lp(rng.standard_normal(n), 30) * 25
    f = f0 * (1 + 0.25 * np.sin(np.pi * np.minimum(t * 1.4, 1))) * jit
    src = osc(f, dur, "saw") + 0.3 * osc(f * 0.5, dur, "square")
    src = src * (1 + 0.5 * lp(rng.standard_normal(n), 80) * 15)
    x = src + bp(white(n, rng), 300, 4000) * 0.5
    w = np.clip(t * 1.5, 0, 1)
    y = formant(x, "a") * (1 - w) + formant(x, "o") * w + lp(src, 400) * 0.4
    return sat(y * env_adsr(dur, 0.08, 0.3, 0.8, dur * 0.5) * 2.0, 3.0)


def thunder_crack(rng, amp=1.0):
    return mix(transient(0.03, 1500, 0.005, 3.0 * amp, rng),
               crackle(0.7, 2400, rng, 1500, 14000, 0.002, np.linspace(1, 0, 30) ** 2) * 1.4 * amp)


# ---------------------------------------------------------------- Shazam
def solomon_cast(rng, v):            # 5 tick
    d = 0.25
    n = int(d * SR)
    rs = reverse_of(reverb(bell(1318.5, 1.5, rng, tau=0.5), 2.0, 0.3, rng=rng), 0.6)[-n:]
    wh = formant(white(n, rng), "e") * np.linspace(0, 1, n) ** 2 * 0.5      # bisikan ditarik masuk
    tone = osc(np.geomspace(660, 1320, n), d) * np.linspace(0, 1, n) ** 3 * 0.25
    return cut_at(mix(rs, wh, tone), d)


def solomon_sight(rng, v):
    dur = 3.5
    n = int(0.6 * SR)
    shing = sweep_filter(white(n, rng) * env_exp(n, 0.12), np.geomspace(2500, 7000, 32), "band", 12)
    root = [349.2, 392.0][v % 2]
    ch = choir([root, root * 1.25, root * 1.5, root * 2], dur, rng, "a") * env_adsr(dur, 0.03, 0.5, 0.45, 2.5)
    bells_ = mix(*[at(bell(root * m, dur - 0.03 * i, rng, tau=1.0), 0.03 * i, dur) * 0.3 for i, m in enumerate([2, 3, 4, 5, 6])])
    y = mix(shing * 0.8, ch * 0.6, bells_, sub_drop(90, 45, 0.8, 0.15, 6) * 0.9)
    return reverb(y, 3.2, 0.45, rng=rng, size=2.0, bright=9000)


def hercules_windup(rng, v):         # 5 tick
    d = 0.25
    rs = reverse_of(lightning_strike(rng, 0), d) * 0.8
    cr = crackle(d, 1500, rng, 2000, 12000, 0.0015, np.linspace(0.1, 1, 20) ** 2) * 0.6
    return cut_at(mix(rs, cr, reverse_swell(d, rng, 500, 9000) * 0.6), d)


def hercules_clap(rng, v):
    """Tepukan guntur di tick 5, gada avatar Hercules menghantam tanah 2 tick kemudian (sudah di dalam file)."""
    dur = 4.0

    def palm():
        L = int(0.06 * SR)
        return bp(white(L, rng), 900, 5000) * env_exp(L, 0.009)
    clap = mix(palm() * 2.2, at(palm() * 1.6, 0.006), at(palm(), 0.014))
    boom = sub_drop(130 - v * 8, 34, 2.2, 0.5, 7) * 1.5
    mace = mix(sub_drop(110, 32, 1.6, 0.35, 9) * 1.4, lp(white(int(0.4 * SR), rng), 300) * env_exp(int(0.4 * SR), 0.06) * 1.6,
               crackle(1.0, 120, rng, 300, 3000, 0.006, np.linspace(1, 0, 30) ** 2) * 0.6)
    roll = lp(brown(int(dur * SR), rng), 220) * env_adsr(dur, 0.08, 0.6, 0.4, dur * 0.8) * 0.9
    y = mix(clap, thunder_crack(rng, 0.9), boom, at(mace, 0.10), at(roll, 0.05))
    return reverb(sat(y, 2.0), 3.0, 0.32, rng=rng, size=2.0)


def hercules_throw(rng, v):
    dur = 1.4
    n = int(dur * SR)
    pre_n = int(0.05 * SR)
    pre = sweep_filter(white(pre_n, rng), np.geomspace(500, 3500, 8), "band", 2.0) * np.linspace(0, 1, pre_n) ** 2 * 0.8
    away = sweep_filter(pink(n, rng), np.geomspace(3000, 250, 48), "band", 1.3) * env_exp(n, 0.35)
    tumble = 0.65 + 0.35 * np.sin(2 * np.pi * np.cumsum(np.linspace(14, 6, n)) / SR)   # badan musuh berputar
    y = mix(pre, at(mix(transient(0.012, 3000, 0.002, 0.9, rng), away * tumble * 2.0, sub_drop(95, 40, 0.9, 0.18, 6) * 1.3), 0.05))
    return reverb(y, 1.5, 0.25, rng=rng)


def atlas_windup(rng, v):            # 13 tick: langit turun ke kepalan
    d = 0.65
    n = int(d * SR)
    t = np.linspace(0, 1, n)
    wf = 1400 * 2 ** (-1.6 * t) * (1 + 0.006 * np.sin(2 * np.pi * 7 * t * d))
    whistle = osc(wf, d) * t ** 1.5 * 0.35 + bp(white(n, rng), 600, 3000) * t ** 2 * 0.15
    rum = sweep_filter(brown(n, rng), np.geomspace(120, 1200, 32), "low", 0.9) * t ** 2 * 1.4
    sub = osc(np.geomspace(30, 48, n), d) * t ** 2 * 0.7
    return cut_at(sat(mix(whistle, rum, sub, reverse_swell(d, rng, 300, 10000) * 0.5), 1.5), d)


def atlas_slam(rng, v):
    y = mix(sub_drop(170, 28, 2.5, 0.8, 8) * 1.2, impact(rng, v) * 0.9, braam(rng, v) * 0.75,
            at(shockwave(rng, v) * 0.7, 0.02), at(earth_crack(rng, v) * 0.6, 0.05), impact_ring(rng, v) * 0.35)
    return limiter(sat(y, 1.3), 0.95)


def zeus_windup(rng, v):             # 5 tick
    d = 0.25
    n = int(d * SR)
    t = np.linspace(0, 1, n)
    whine = sweep_filter(supersaw(np.geomspace(300, 2400, n), d, 5, 0.02, rng), np.geomspace(800, 9000, 16), "low", 2) * t ** 2 * 0.6
    cr = crackle(d, 3000, rng, 2500, 14000, 0.0012, np.linspace(0.05, 1, 20) ** 2) * 0.8
    return cut_at(mix(whine, cr, reverse_swell(d, rng, 1000, 12000) * 0.5), d)


def zeus_spear(rng, v):
    """Tombak petir dilempar Zeus: lecutan, zap yang menukik, dentuman. Gunturnya dari strikeLightning."""
    whip = mix(transient(0.008, 4000, 0.0012, 3.0, rng), at(transient(0.01, 2000, 0.002, 1.5, rng), 0.004))
    n = int(0.9 * SR)
    zapf = np.geomspace(3200 - v * 300, 180, n)
    zap = np.sin(2 * np.pi * np.cumsum(zapf) / SR + osc(np.geomspace(1800, 120, n), 0.9) * 4 * env_exp(n, 0.25)) * env_exp(n, 0.16) * 0.7
    cr = crackle(1.2, 2600, rng, 1800, 14000, 0.0015, np.concatenate([np.ones(5), np.linspace(1, 0, 40) ** 2])) * 1.2
    y = mix(whip, zap, cr, sub_drop(150, 32, 2.6, 0.6, 7) * 1.6)
    return limiter(reverb(sat(y, 1.8), 2.6, 0.25, rng=rng, size=2.0), 0.95)


def achilles_windup(rng, v):         # 4 tick: tombak ditarik
    d = 0.2
    n = int(d * SR)
    t = np.linspace(0, 1, n)
    shing = hp(comb_sweep(hp(white(n, rng), 1500) * (0.2 + t ** 1.5) * 0.3, 900, 3200, 0.9), 800) * t
    return cut_at(mix(shing * 0.6, reverse_swell(d, rng, 800, 11000) * 0.5), d)


def achilles_warcry(rng, v):
    """Raungan Achilles: tiupan terompet perang + hentakan kaki, tusukan tombak 1 tick kemudian."""
    horn = war_horn(3.0, [110.0, 98.0][v % 2], rng) * 0.8
    stomp = mix(sub_drop(120, 40, 0.9, 0.16, 9) * 1.5, lp(white(int(0.15 * SR), rng), 400) * env_exp(int(0.15 * SR), 0.03) * 1.2)
    n = int(0.5 * SR)
    thrust = sweep_filter(white(n, rng), np.geomspace(6000, 900, 24), "band", 2.5) * env_exp(n, 0.1) * 1.2
    spear = mix(thrust, sub_drop(90, 50, 0.8, 0.14, 5) * 0.9, bell(1318.5, 2.0, rng, tau=0.6) * 0.25)
    y = mix(stomp, horn, at(spear, 0.05), at(shimmer(rng, 2) * 0.35, 0.1))
    return reverb(y, 3.0, 0.35, rng=rng, size=2.0)


def courage_nova(rng, v):
    dur = 4.0
    root = [293.7, 329.6][v % 2]
    ch = choir([root, root * 1.25, root * 1.5, root * 2], dur, rng, "a") * env_adsr(dur, 0.01, 0.4, 0.4, 2.8)
    n = int(0.8 * SR)
    shing = sweep_filter(white(n, rng) * env_exp(n, 0.15), np.geomspace(3000, 9000, 24), "band", 10)
    m = int(1.2 * SR)
    air = sweep_filter(white(m, rng), np.geomspace(7000, 300, 32), "low", 0.9) * env_exp(m, 0.25) * 0.8
    y = mix(transient(0.015, 2000, 0.003, 2.5, rng), sub_drop(140, 36, 2.0, 0.5, 7) * 1.5, air, shing * 0.9, ch * 0.7,
            at(shimmer(rng, 0) * 0.4, 0.05))
    return reverb(sat(y, 1.6), 3.2, 0.35, rng=rng, size=2.0)


def storm_windup(rng, v):            # 9 tick
    d = 0.45
    n = int(d * SR)
    t = np.linspace(0, 1, n)
    wind = sweep_filter(pink(n, rng), np.geomspace(300, 3000, 24), "band", 1.2) * t ** 1.5
    ch = choir([146.8, 220.0, 293.7], 1.5, rng, "a") * env_adsr(1.5, 0.01, 0.3, 0.5, 1.0)
    inhale = reverse_of(reverb(ch, 1.5, 0.6, rng=rng), d) * 0.6                # paduan suara yang 'menarik napas'
    cr = crackle(d, 1800, rng, 2000, 13000, 0.0015, np.linspace(0, 1, 20) ** 3) * 0.7
    sub = osc(np.geomspace(35, 55, n), d) * t ** 2 * 0.6
    return cut_at(sat(mix(wind, inhale, cr, sub), 1.4), d)


def storm_gods(rng, v):
    """Pembuka Badai Para Dewa: braam mayor yang heroik, paduan suara, dan enam lonceng (enam dewa)."""
    dur = 5.0
    root = 73.4
    y = 0
    for f, a in ((root, 1), (root * 1.5, 0.7), (root * 2, 0.6), (root * 2.52, 0.35), (root * 3, 0.25)):
        y = y + a * supersaw(f, dur, 7, 0.01, rng)
    fc = np.concatenate([np.geomspace(250, 2600, 6), np.geomspace(2600, 400, 58)])
    br = sat(sweep_filter(y, fc, "low", 2.0) * env_adsr(dur, 0.015, 1.0, 0.6, 3.2) * 1.5, 2.8)
    ch = choir([293.7, 370.0, 440.0, 587.3, 740.0, 880.0], dur, rng, "a") * env_adsr(dur, 0.05, 0.8, 0.6, 3.0)
    bells_ = mix(*[at(bell(587.3 * m, 3.5, rng, tau=1.2), 0.1 + 0.06 * i) * 0.22 for i, m in enumerate([1, 1.25, 1.5, 2, 2.5, 3])])
    out = mix(thunder_crack(rng), sub_drop(160, 30, 2.6, 0.7, 7) * 1.6, br * 0.8, ch * 0.5, bells_)
    return limiter(reverb(out, 4.0, 0.35, rng=rng, size=2.4), 0.95)


def thunder_punch(rng, v):
    roll = lp(brown(int(3.0 * SR), rng), 200) * env_adsr(3.0, 0.1, 0.5, 0.4, 2.2) * 0.8
    y = mix(punch(rng, v, True), lightning_strike(rng, v) * 0.8, sub_drop(120, 30, 2.5, 0.6, 6) * 1.3, at(roll, 0.08))
    return limiter(sat(y, 1.4), 0.95)


def mercury_blink(rng, v):
    n = int(0.16 * SR)
    zip_ = sweep_filter(white(n, rng), np.geomspace(800, 9000, 16), "band", 2.5) * np.sin(np.linspace(0, np.pi, n)) ** 2
    m = int(0.2 * SR)
    tone = osc(np.geomspace(1800 + v * 200, 3600, m), 0.2) * env_exp(m, 0.05) * 0.25
    tail = mix(transient(0.006, 4000, 0.001, 0.7, rng), crackle(0.25, 2000, rng, 3000, 14000, 0.0008, np.linspace(1, 0, 10)) * 0.6, tone)
    return reverb(mix(zip_ * 0.9, at(tail, 0.12)), 1.2, 0.3, rng=rng, bright=9000)


# ---------------------------------------------------------------- Black Adam
def shu_vortex(rng, v):              # 50 tick pusaran
    dur = 2.7
    n = int(dur * SR)
    rot = 0.5 + 0.5 * np.sin(2 * np.pi * np.cumsum(np.linspace(2.5, 4.5, n)) / SR)
    howl = sweep_filter(pink(n, rng), 350 + 1500 * rot[:: max(1, n // 128)], "band", 3.0)
    grains = crackle(dur, 3500, rng, 2500, 11000, 0.0006) * (0.4 + 0.6 * rot) * 0.5
    y = (howl * 1.1 + lp(pink(n, rng), 300) * 0.6 + grains) * env_adsr(dur, 0.35, 0.3, 0.85, 0.6) * (0.7 + 0.3 * rot)
    return reverb(y, 1.8, 0.25, rng=rng)


def shu_burst(rng, v):
    m = int(2.0 * SR)
    blast = sweep_filter(white(m, rng), np.geomspace(9000, 400, 48), "low", 0.8) * env_exp(m, 0.35) * 1.2
    y = mix(transient(0.02, 1500, 0.004, 2.0, rng), sub_drop(110, 32, 2.0, 0.5, 6) * 1.5, blast, at(sand_burst(rng, v) * 0.9, 0.02))
    return reverb(sat(y, 1.8), 2.4, 0.3, rng=rng, size=1.8)


def heru_dive(rng, v):
    """Merunduk 3 tick (tarikan napas), lalu pekik elang + desing terjangan selama 5 tick."""
    jet_n = int(0.7 * SR)
    arc = np.sin(np.linspace(0, np.pi, jet_n))
    jet = sweep_filter(white(jet_n, rng), np.concatenate([np.geomspace(600, 6000, 10), np.geomspace(6000, 500, 30)]), "band", 1.6) * arc ** 1.5 * 1.1
    sub = osc(np.geomspace(90, 45, jet_n), 0.7) * arc ** 2 * 0.4
    dive = mix(screech(0.42, rng, [2900, 2600][v % 2]) * 0.6, jet, sub)
    return reverb(mix(reverse_swell(0.15, rng, 800, 10000) * 0.6, at(dive, 0.15)), 1.8, 0.3, rng=rng)


def heru_land(rng, v):
    imp = mix(sub_drop(140, 38, 1.4, 0.3, 9) * 1.5, lp(white(int(0.3 * SR), rng), 450) * env_exp(int(0.3 * SR), 0.05) * 1.6,
              transient(0.01, 2500, 0.002, 1.8, rng))
    y = mix(imp, at(sand_burst(rng, v) * 0.8, 0.01), at(whoosh(rng, 2, True) * 0.4, 0.05))
    return reverb(sat(y, 2.0), 1.8, 0.25, rng=rng)


def amon_windup(rng, v):             # 7 tick
    d = 0.35
    n = int(d * SR)
    t = np.linspace(0, 1, n)
    up = sweep_filter(pink(n, rng), np.geomspace(250, 2500, 16), "band", 1.4) * np.sin(np.linspace(0, np.pi * 0.9, n)) * 0.8
    rum = sweep_filter(brown(n, rng), np.geomspace(100, 600, 16), "low", 0.9) * t ** 2 * 1.3
    sub = osc(np.geomspace(32, 50, n), d) * t ** 2 * 0.7
    return cut_at(sat(mix(up, rum, sub, reverse_swell(d, rng, 300, 8000) * 0.4), 1.5), d)


def amon_quake(rng, v):
    dur = 4.5

    def fist():
        return mix(sub_drop(150, 34, 1.6, 0.35, 9) * 1.3, lp(white(int(0.25 * SR), rng), 420) * env_exp(int(0.25 * SR), 0.05) * 1.6,
                   transient(0.008, 2500, 0.0015, 1.6, rng))
    hit = mix(fist(), at(fist() * 0.85, 0.018))                       # dua kepalan
    tear = sweep_filter(brown(int(2.5 * SR), rng), np.geomspace(900, 90, 48), "band", 3.0) * env_adsr(2.5, 0.05, 0.4, 0.6, 1.8) * 1.6
    cr = 0
    for lo, hi in ((150, 700), (500, 2200), (1500, 6000)):
        cr = cr + crackle(1.4, 160, rng, lo, hi, 0.007, np.concatenate([np.linspace(0.3, 1, 8), np.linspace(1, 0, 30) ** 1.5]))
    rum = lp(brown(int(dur * SR), rng), 140) * env_adsr(dur, 0.03, 0.6, 0.5, 3.0)
    return reverb(sat(mix(hit, at(tear, 0.03), at(cr * 1.1, 0.02), rum), 2.0), 3.0, 0.3, rng=rng, size=2.0)


def zehuti_cast(rng, v):             # 5 tick
    d = 0.25
    wh = reverb(formant(white(int(1.0 * SR), rng), "u") * env_exp(int(1.0 * SR), 0.25), 1.5, 0.6, rng=rng)
    low = reverb(bell(98.0, 2.0, rng, ((1, 1), (2.4, 0.5), (3.9, 0.3)), tau=0.8), 1.5, 0.5, rng=rng)
    return cut_at(mix(reverse_of(wh, d), reverse_of(low, d) * 0.7), d, rise=2.6)


def zehuti_seal(rng, v):
    dur = 4.5
    gong = bell([98.0, 87.3][v % 2], dur, rng, ((1, 1), (1.47, 0.6), (2.09, 0.5), (2.56, 0.35), (3.28, 0.25), (4.1, 0.15)),
                tau=1.8, detune=0.004) * 0.8
    ch = choir([146.8, 174.6, 220.0], dur, rng, "u") * env_adsr(dur, 0.06, 0.6, 0.5, 3.0) * 0.6
    hiss = formant(white(int(1.5 * SR), rng), "o") * env_adsr(1.5, 0.2, 0.3, 0.3, 1.0) * 0.25
    y = mix(gong, ch, sub_drop(80, 38, 1.2, 0.3, 5), at(hiss, 0.3))
    return reverb(y, 3.8, 0.45, rng=rng, size=2.2)


def aton_windup(rng, v):             # 8 tick: cakram matahari terbentuk
    d = 0.4
    n = int(d * SR)
    t = np.linspace(0, 1, n)
    chord = mix(*[supersaw(f * np.geomspace(0.85, 1.0, n), d, 5, 0.012, rng) for f in (220.0, 277.2, 329.6, 440.0)])
    chord = sweep_filter(chord, np.geomspace(300, 7000, 16), "low", 1.6) * t ** 1.6 * 0.6
    siz = crackle(d, 3000, rng, 3000, 12000, 0.0008, np.linspace(0.1, 1, 20) ** 2) * 0.5
    roar_ = sweep_filter(pink(n, rng), np.geomspace(300, 2500, 16), "band", 1.0) * t ** 2 * 0.6
    return cut_at(sat(mix(chord, siz, roar_), 1.4), d)


def aton_ray(rng, v):
    dur = 1.6
    n = int(dur * SR)
    f = [880.0, 830.6, 932.3][v % 3]
    k = int(0.05 * SR)
    bf = f * np.concatenate([np.geomspace(1.25, 1.0, k), np.ones(n - k)])
    beam = np.sin(2 * np.pi * np.cumsum(bf) / SR + osc(bf * 1.5, dur) * 2.5 * env_exp(n, 0.2)) * env_exp(n, 0.22)
    beam = lp(beam + 0.5 * supersaw(f / 2, dur, 5, 0.01, rng) * env_exp(n, 0.18), 7000) * 0.6
    siz = crackle(dur, 2500, rng, 2500, 12000, 0.001, np.linspace(1, 0, 30) ** 1.5) * 0.6
    burn = sweep_filter(pink(n, rng), np.geomspace(2500, 400, 32), "band", 1.0) * env_adsr(dur, 0.01, 0.2, 0.4, 1.0) * 0.8
    y = mix(transient(0.01, 2500, 0.002, 1.6, rng), sub_drop(110, 45, 0.6, 0.1, 8) * 0.9, beam, siz, burn)
    return reverb(sat(y, 1.5), 1.6, 0.3, rng=rng)


def mehen_rise(rng, v):              # 6 tick: ular muncul dari bayangan
    d = 0.3
    n = int(d * SR)
    t = np.linspace(0, 1, n)
    sl = sweep_filter(pink(n, rng), np.geomspace(300, 1800, 16), "band", 1.5) * t * 0.6
    dr = sat(lp(supersaw(np.geomspace(41, 55, n), d, 5, 0.03, rng), 400), 3) * t ** 2 * 0.5
    return cut_at(mix(rattle(d, rng, 26) * t ** 1.2 * 0.7, sl, dr, reverse_swell(d, rng, 800, 9000) * 0.3), d)


def mehen_coil(rng, v):
    thump = mix(sub_drop(100, 38, 1.2, 0.25, 7) * 1.3, lp(white(int(0.2 * SR), rng), 350) * env_exp(int(0.2 * SR), 0.05))
    rt = rattle(1.4, rng, 30) * env_adsr(1.4, 0.02, 0.3, 0.5, 0.9) * 0.5
    sq = lp(supersaw(55 * (1 + 0.03 * np.sin(2 * np.pi * 1.7 * t_axis(2.0))), 2.0, 5, 0.02, rng), 700)
    sq = sat(sq * env_adsr(2.0, 0.15, 0.5, 0.6, 1.2), 2.5) * 0.5                 # lilitan yang meremas
    return reverb(mix(thump, at(rt, 0.05), sq, at(dark_hiss(rng, v) * 0.5, 0.1)), 2.5, 0.3, rng=rng)


def mehen_bite(rng, v):
    crunch = crackle(0.25, 900, rng, 600, 5000, 0.004, np.linspace(1, 0, 10) ** 2) * 1.1
    hs = formant(white(int(0.8 * SR), rng), "o") * env_adsr(0.8, 0.02, 0.2, 0.4, 0.5) * 0.4
    y = mix(transient(0.006, 3000, 0.001, 2.2, rng), at(transient(0.008, 1800, 0.0015, 1.6, rng), 0.012), at(crunch, 0.01),
            sub_drop(120, 50, 0.5, 0.08, 9) * 0.9, at(hs, 0.04))
    return reverb(sat(y, 2.0), 1.2, 0.25, rng=rng)


def kahndaq_windup(rng, v):          # 10 tick: amarah tertahan
    d = 0.5
    n = int(d * SR)
    t = np.linspace(0, 1, n)
    beats = mix(*[at(sub_drop(70, 38, 0.3, 0.06, 6) * a, s) for s, a in ((0.0, 0.7), (0.22, 0.85), (0.38, 1.0))])
    growl = sweep_filter(supersaw(np.geomspace(46, 62, n), d, 6, 0.03, rng), np.geomspace(200, 1500, 16), "low", 1.5)
    growl = sat(growl * t ** 1.5 * 1.5, 3.0) * 0.6
    return cut_at(mix(beats * 1.2, growl, reverse_swell(d, rng, 400, 9000) * 0.5), d)


def kahndaq_wrath(rng, v):
    r = reverb(roar(1.8, [82.0, 73.0][v % 2], rng) * 0.6, 2.5, 0.35, rng=rng)
    y = mix(thunder_crack(rng, 0.9), sub_drop(150, 28, 2.6, 0.8, 7) * 1.5, braam(rng, 1) * 0.8, at(r, 0.05),
            at(dread(rng, v)[int(1.0 * SR):] * 0.5, 0.2))
    return limiter(sat(y, 1.3), 0.95)


def call_windup(rng, v):             # 12 tick: langit bergemuruh
    d = 0.6
    n = int(d * SR)
    t = np.linspace(0, 1, n)
    rum = sweep_filter(brown(n, rng), np.geomspace(150, 1000, 16), "low", 0.9) * t ** 2 * 1.2
    tone = sweep_filter(supersaw(np.geomspace(55, 110, n), d, 6, 0.02, rng), np.geomspace(200, 4000, 16), "low", 1.5) * t ** 2 * 0.5
    cr = crackle(d, 1200, rng, 2000, 12000, 0.0015, np.linspace(0, 1, 20) ** 3) * 0.6
    return cut_at(sat(mix(reverse_of(thunder(rng, 2), d), rum, tone, cr), 1.4), d)


# ---------------------------------------------------------------- 0.25: Penangkal Petir Hidup
ROD_HIT = 3 * 0.05   # ShazamAnim.ROD_DESCENT tick: petir turun, lalu menghantam dada Shazam


def rod_strike(rng, v):
    """Petir menyambar Shazam (tiap 2 detik). Satu file yang sudah di-mix, diputar saat petir mulai turun:
    0-0,15 dtk desis petir yang turun (ancang-ancang 3 tick, makin rapat, memuncak tepat sebelum hantaman) ->
    retakan supersonik TEPAT di 0,15 dtk (tick hantaman) -> robekan udara, dentum sub di dada, guntur pendek ->
    dengung tenaga yang merasuk badan (nadanya naik = pulih), denting kecil (Pukulan Guntur siap), dan listrik yang
    merayap di badan. Total < 2 dtk supaya sambaran berikutnya nggak menumpuk jadi bising."""
    hit = ROD_HIT
    n0 = int(hit * SR)
    ramp = np.linspace(0, 1, n0)
    # 1) ancang-ancang: lompatan petir (stepped leader) yang makin rapat + desis yang naik, cuma sayup lalu memuncak
    lead = crackle(hit, 900 + 150 * v, rng, 3000, 13000, 0.0008, np.linspace(0.1, 1.0, 24) ** 2)
    hiss = sweep_filter(white(n0, rng), np.geomspace(1600, 10000, 16), "band", 3.0) * ramp ** 2 * 0.5
    whine = osc(np.geomspace(700 + 70 * v, 2800, n0), hit) * ramp ** 3 * 0.1
    pre = (lead * 0.6 + hiss + whine) * (0.04 + 0.96 * ramp ** 2.6) * 0.32
    # 2) hantaman: retakan supersonik berlapis (klik, retak, robekan yang menyapu turun), desis listrik singkat
    crack = mix(transient(0.012, 3000, 0.0018, 4.0, rng),
                at(bp(white(int(0.03 * SR), rng), 900, 5000) * env_exp(int(0.03 * SR), 0.006) * 3.0, 0.002),
                at(transient(0.01, 2000, 0.002, 2.2, rng), 0.011 + 0.004 * v),
                at(transient(0.01, 2500, 0.002, 1.6, rng), 0.024 + 0.003 * v))
    tn = int(0.12 * SR)
    tear = sweep_filter(white(tn, rng), np.geomspace(9000, 900, 16), "band", 1.5) * env_exp(tn, 0.035) * 1.1
    zap = crackle(0.5, 2200, rng, 1800, 14000, 0.0012, np.concatenate([np.ones(4), np.linspace(1, 0, 24) ** 3])) * 0.8
    # dentum di dada + guntur pendek yang bergulung 2-3 kali lalu habis
    boom = sub_drop(140 - 9 * v, 36, 1.3, 0.26, 7) * 1.25
    thump = lp(white(int(0.4 * SR), rng), 380) * env_exp(int(0.4 * SR), 0.06) * 0.9
    rn = int(1.4 * SR)
    bursts = np.zeros(rn)
    tt = 0.06 + rng.uniform(0, 0.04)
    for _ in range(3):
        k = int(tt * SR)
        L = int(rng.uniform(0.22, 0.45) * SR)
        e = env_adsr(L / SR, rng.uniform(0.03, 0.08), 0.08, 0.6, L / SR * 0.6) * rng.uniform(0.5, 1.0) * np.exp(-tt / 0.5)
        bursts[k:k + len(e)] += e[: max(0, min(len(e), rn - k))]
        tt += rng.uniform(0.16, 0.3)
    roll = sweep_filter(brown(rn, rng), np.geomspace(900, 120, 40), "low", 0.8)
    roll = roll * (env_adsr(1.4, 0.02, 0.25, 0.3, 0.95) * 0.35 + bursts) * 0.55
    # 3) tenaga merasuk badan: dengung listrik yang nadanya naik (energi, darah, armor pulih) dengan getar cepat
    hn = int(1.3 * SR)
    hf = (98 + 11 * v) * (1 + 0.3 * (1 - np.exp(-np.arange(hn) / (0.2 * SR))))
    hum = osc(hf, 1.3, "saw") + 0.5 * osc(hf * 2.01, 1.3, "saw")
    hum = bp(sat(hum, 3.0), 160, 3600)
    hum = hum * (0.6 + 0.4 * np.sin(2 * np.pi * np.cumsum(np.geomspace(42, 14, hn)) / SR)) * env_adsr(1.3, 0.03, 0.35, 0.4, 0.8)
    un = int(0.6 * SR)
    up = osc(np.geomspace(330, 1320, un), 0.6) * env_adsr(0.6, 0.06, 0.2, 0.5, 0.35) * 0.16
    up = up + osc(np.geomspace(660, 2640, un), 0.6) * env_adsr(0.6, 0.08, 0.2, 0.4, 0.3) * 0.05
    ding = bell(2637.0 * (1 + 0.03 * v), 0.9, rng, tau=0.35) * 0.07   # kepalan berlistrik: Pukulan Guntur siap
    body = crackle(1.3, 150, rng, 2500, 12000, 0.0008, np.linspace(1, 0.05, 30) ** 1.5) * 0.55   # listrik merayap di badan
    tail = mix(at(roll, 0.015), at(sat(hum, 1.3), 0.05) * 0.2, at(up, 0.08), at(ding, 0.4), at(body, 0.12))
    body_hit = mix(boom, thump, tear, zap * 0.7)
    wet = reverb(mix(sat(body_hit, 1.4), tail), 1.2, 0.2, rng=rng, size=1.3)
    strike = mix(crack, wet)
    y = mix(pre, at(strike, hit))
    # dipadatkan seperti SFX film: retakannya tetap puncak paling tajam, tapi dentum & dengungnya ikut tebal
    y = sat(y / (np.max(np.abs(y)) + 1e-9) * 3.0, 1.0)
    total = 1.95
    y = pad(y, total)
    y[-int(0.45 * SR):] *= np.linspace(1, 0, int(0.45 * SR)) ** 2
    return limiter(y, 0.95)


# ---------------------------------------------------------------- 0.26: Kekuatan Keluarga
FAMILY_HIT = 10 * 0.05   # ShazamAnim.FAMILY_WINDUP


def family_windup(rng, v):           # 10 tick: kepalan terangkat, tautan petir ke keluarga, memuncak di tick sambaran
    d = FAMILY_HIT
    n = int(d * SR)
    ramp = np.linspace(0, 1, n)
    swell = reverse_swell(d, rng, 500, 13000) * 0.9
    ch = choir([146.8, 220.0, 293.7, 370.0], d, rng, "a") * ramp ** 2 * 0.35          # paduan suara mulai bangkit
    zap = crackle(d, 1600, rng, 2500, 13000, 0.0009, np.linspace(0.1, 1.0, 20) ** 2) * 0.55
    rise = osc(np.geomspace(220, 880, n), d, "saw")
    rise = bp(sat(rise, 2.0), 300, 5000) * ramp ** 2.5 * 0.18
    return cut_at(mix(swell, ch, zap, rise), d, rise=1.6)


def family_strike(rng, v):           # petir menyambar seluruh keluarga bersamaan + paduan suara megah
    dur = 3.6
    cracks = thunder_crack(rng, 1.2)
    for k, off in enumerate((0.012, 0.027, 0.045)):   # beberapa petir menyambar hampir bersamaan
        cracks = mix(cracks, at(thunder_crack(rng, 0.75 - 0.12 * k), off))
    boom = sub_drop(150, 32, 2.8, 0.55, 6) * 1.7
    body = lp(white(int(0.6 * SR), rng), 450) * env_exp(int(0.6 * SR), 0.09) * 1.2
    roll = lp(brown(int(3.0 * SR), rng), 220) * env_adsr(3.0, 0.05, 0.6, 0.35, 2.0) * 0.7
    chord = [146.8, 220.0, 293.7, 370.0, 440.0]          # D mayor: megah & hangat
    ch = choir(chord, dur, rng, "a") * env_adsr(dur, 0.12, 0.6, 0.6, 2.2) * 0.55
    ch = ch + choir([c * 2 for c in chord[1:4]], dur, rng, "o") * env_adsr(dur, 0.25, 0.6, 0.45, 2.0) * 0.2
    bells = mix(*[at(bell(f, 2.6, rng, tau=0.9) * 0.16, 0.06 + 0.05 * i) for i, f in enumerate((1174.7, 1480.0, 1760.0, 2349.3))])
    tail = crackle(2.2, 300, rng, 2500, 12000, 0.0008, np.linspace(1, 0.05, 30) ** 1.4) * 0.45
    y = mix(cracks, boom, body, at(roll, 0.05), at(ch, 0.02), bells, at(tail, 0.15))
    return limiter(reverb(sat(y, 1.4), 3.4, 0.3, rng=rng, size=2.2), 0.95)


# ---------------------------------------------------------------- 0.27: Tangan Kahndaq (Black Adam)
def adam_catch(rng, v):              # proyektil berhenti di udara: desing yang macet mendadak + dengung listrik menahan
    dur = 0.9
    n_in = int(0.09 * SR)
    whiz = sweep_filter(white(n_in, rng), np.geomspace(2500, 7000, 12), "band", 3.0) * np.linspace(0.2, 1, n_in) ** 2 * 0.8
    stop = mix(transient(0.012, 2500, 0.002, 2.2, rng),
               crackle(0.12, 2600, rng, 2200, 12000, 0.0009, np.linspace(1, 0, 12) ** 2) * 1.1)
    m = int(0.18 * SR)
    vwomp = osc(np.geomspace(1300 + 120 * v, 140, m), 0.18) * env_exp(m, 0.06) * 0.55      # nada anjlok: "membeku"
    ping = bell(1975.5 * (1 + 0.04 * v), 0.6, rng, tau=0.18) * 0.18                          # denting logam
    hn = int(0.75 * SR)
    hum = osc(82 + 9 * v, 0.75, "saw") + 0.5 * osc((82 + 9 * v) * 2.02, 0.75, "saw")
    hum = bp(sat(hum, 2.5), 140, 3200) * (0.65 + 0.35 * np.sin(2 * np.pi * 31 * np.arange(hn) / SR)) * env_adsr(0.75, 0.01, 0.2, 0.5, 0.45)
    fizz = crackle(0.7, 260, rng, 3000, 12000, 0.0007, np.linspace(1, 0.1, 20)) * 0.5
    y = mix(whiz, at(mix(stop, vwomp, ping, hum * 0.35, fizz), 0.085))
    return reverb(sat(pad(y, dur), 1.4), 1.0, 0.2, rng=rng, bright=9000)


def adam_release(rng, v):            # tangan dikibaskan: semua proyektil melesat balik dengan petir membara
    dur = 2.0
    pre = reverse_swell(0.1, rng, 800, 9000) * 0.6
    wn = int(0.5 * SR)
    whoosh = sweep_filter(white(wn, rng), np.concatenate([np.geomspace(400, 5000, 10), np.geomspace(5000, 600, 20)]), "band", 1.8)
    whoosh = whoosh * env_adsr(0.5, 0.03, 0.15, 0.5, 0.3) * 1.2
    crack = thunder_crack(rng, 1.0)
    boom = sub_drop(120, 34, 1.4, 0.3, 6) * 1.2
    zips = np.zeros(int(1.0 * SR))
    for k in range(6):   # desing proyektil yang melesat balik satu per satu
        zn = int(0.22 * SR)
        z = sweep_filter(white(zn, rng), np.geomspace(9000, 1800 + 300 * k, 12), "band", 4.0) * env_exp(zn, 0.07)
        off = int((0.03 + 0.045 * k + rng.uniform(0, 0.02)) * SR)
        zips[off:off + zn] += z * (0.8 - 0.08 * k)
    sizzle = crackle(0.9, 900, rng, 2500, 13000, 0.001, np.linspace(1, 0, 25) ** 2) * 0.6
    y = mix(pre, at(mix(whoosh, crack * 0.9, boom, zips, sizzle), 0.1))
    return limiter(reverb(sat(pad(y, dur), 1.4), 1.8, 0.25, rng=rng, size=1.5), 0.95)


WINDUPS = {"solomon_cast", "hercules_windup", "atlas_windup", "zeus_windup", "achilles_windup", "storm_windup",
           "amon_windup", "zehuti_cast", "aton_windup", "mehen_rise", "kahndaq_windup", "call_windup", "family_windup"}

RECIPES.update({
    "solomon_cast": (solomon_cast, 1, 0.75),
    "solomon_sight": (solomon_sight, 2, 0.85),
    "hercules_windup": (hercules_windup, 1, 0.75),
    "hercules_clap": (hercules_clap, 2, 1.0),
    "hercules_throw": (hercules_throw, 2, 0.9),
    "atlas_windup": (atlas_windup, 1, 0.85),
    "atlas_slam": (atlas_slam, 2, 1.0),
    "zeus_windup": (zeus_windup, 1, 0.75),
    "zeus_spear": (zeus_spear, 2, 1.0),
    "achilles_windup": (achilles_windup, 1, 0.7),
    "achilles_warcry": (achilles_warcry, 2, 1.0),
    "courage_nova": (courage_nova, 2, 0.95),
    "storm_windup": (storm_windup, 1, 0.8),
    "storm_gods": (storm_gods, 1, 1.0),
    "thunder_punch": (thunder_punch, 2, 1.0),
    "mercury_blink": (mercury_blink, 2, 0.8),
    "shu_vortex": (shu_vortex, 1, 0.85),
    "shu_burst": (shu_burst, 2, 1.0),
    "heru_dive": (heru_dive, 2, 0.9),
    "heru_land": (heru_land, 2, 0.95),
    "amon_windup": (amon_windup, 1, 0.8),
    "amon_quake": (amon_quake, 2, 1.0),
    "zehuti_cast": (zehuti_cast, 1, 0.75),
    "zehuti_seal": (zehuti_seal, 2, 0.9),
    "aton_windup": (aton_windup, 1, 0.8),
    "aton_ray": (aton_ray, 3, 0.9),
    "mehen_rise": (mehen_rise, 1, 0.8),
    "mehen_coil": (mehen_coil, 1, 0.9),
    "mehen_bite": (mehen_bite, 2, 0.9),
    "kahndaq_windup": (kahndaq_windup, 1, 0.85),
    "kahndaq_wrath": (kahndaq_wrath, 2, 1.0),
    "call_windup": (call_windup, 1, 0.85),
    # 0.25
    "rod_strike": (rod_strike, 3, 0.9),
    # 0.26
    "family_windup": (family_windup, 1, 0.8),
    "family_strike": (family_strike, 2, 1.0),
    # 0.27
    "adam_catch": (adam_catch, 3, 0.8),
    "adam_release": (adam_release, 2, 1.0),
})


def render(name, fn, v, gain):
    import zlib; rng = np.random.default_rng(zlib.crc32(f"{name}:{v}".encode()))
    y = fn(rng, v)
    if name != "wind_loop":
        y = trim_tail(y)
        y = fade(y, 0.0005, 0.02 if name in WINDUPS else 0.08)
    y = hp(y, 25, 2)                 # buang DC/infrasonik
    y = limiter(norm(y, 0.95), 0.92)
    y = norm(y, 0.89 * gain)
    if name in WINDUPS:   # ancang-ancang: disamakan kerasnya (RMS), jangan sampai menutupi hantamannya
        rms = np.sqrt(np.mean(y ** 2)) + 1e-9
        y = y * min(10 ** (-19 / 20) / rms, 0.89 / (np.max(np.abs(y)) + 1e-9))
    return y.astype(np.float32)


def encode(y, path):
    raw = path + ".raw"
    y.tofile(raw)
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "f32le", "-ar", str(SR), "-ac", "1", "-i", raw,
                    "-c:a", "libvorbis", "-q:a", "6", path], check=True)
    os.remove(raw)


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    only = sys.argv[2:] if len(sys.argv) > 2 else None
    stats = {}
    for name, (fn, count, gain) in RECIPES.items():
        if only and name not in only:
            continue
        for v in range(count):
            y = render(name, fn, v, gain)
            fname = f"{name}_{v + 1}.ogg"
            encode(y, os.path.join(OUT, fname))
            rms = 20 * np.log10(np.sqrt(np.mean(y ** 2)) + 1e-9)
            stats[fname] = (round(len(y) / SR, 2), round(float(rms), 1))
            print(fname, stats[fname], flush=True)
