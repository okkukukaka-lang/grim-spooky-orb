package com.shazammod;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/**
 * 0.50 Aksara, Sang Penulis Ulang (orisinal): automaton berwujud wayang, tubuh hitam bergurat prada emas, topeng gading
 * tanpa wajah, mahkota bilah emas, dan enam Cakram Sabda yang mengorbit di punggungnya. Tiap cakram memegang satu ranah
 * kenyataan. Juara dengan skill terbanyak di mod ini: tiap tombol punya dua sabda (biasa & sambil menahan Shift/jongkok),
 * berbagi satu cooldown supaya HUD-nya tetap tujuh kotak.
 *
 *   Z  Sabda Daya   Sinar Daya (sinar merah ikut bidikan)          | Shift: Ledak Daya (ledakan tenaga melingkar)
 *   X  Sabda Ruang  Lipat Ruang (pindah ke titik bidik, implosi)    | Shift: Gerbang Ruang (musuh ditelan, dijatuhkan dari langit)
 *   C  Sabda Benak  Tusuk Benak (tombak benak, sasaran terkunci)     | Shift: Kuasa Benak (monster saling serang)
 *   V  Sabda Maya   Ubah Maya (monster kecil jadi makhluk jinak)     | Shift: Cermin Maya (tak terlihat, serangan pertama x1,8)
 *   B  Sabda Kala   Henti Kala (waktu berhenti, damage ditabung)     | Shift: Putar Kala (kembali ke 5 detik lalu)
 *   N  Sabda Atma   Rampas Atma (jiwa disedot lalu dicabut)          | Shift: Tirai Atma (damage separuh, sebagian dipantulkan)
 *   R  Sabda Purna  mode puncak 20 detik                             | Shift: Penghapusan (butuh keenam sabda tertulis)
 *   M  Lontar Cakram (enam cakram ke enam musuh, tiap ranah beda)    | Shift: Perisai Sabda (depan: proyektil memantul)
 *   J  Langkah Ruang (berpindah sekejap, kebal sesaat)               | Shift: Tulis Ulang Diri (pulih & bersih dari efek buruk)
 *
 * Pasif:
 *   Halo Sabda        tiap 2 detik keenam cakram berdenyut: energi & darah pulih, kepalan bermuatan (ShazamPassives)
 *   Tinju Enam Sabda  pukulan bermuatan: ledakan enam warna, musuh di sekitar terkunci sebentar
 *   Tangkal Ruang     kadang serangan dilipat ke ruang lain dan Aksara muncul di belakang penyerangnya
 *   Sabda Lengkap     memakai keenam ranah dalam satu wujud = semua damage +10% dan Penghapusan terbuka
 */
public final class AksaraSkills {
    private AksaraSkills() {}

    /** Warna tiap ranah (dipakai juga oleh client untuk cakram, HUD, dan efek): Daya, Ruang, Benak, Maya, Kala, Atma, Purna. */
    public static final int[] RGB = {0xFF3048, 0x8A6CFF, 0x40E6FF, 0xFF4FC8, 0xFFB840, 0x5CFFA0, 0xFFF2C8};
    public static final String[] SABDA_IDS = {"daya", "ruang", "benak", "maya", "kala", "atma", "purna"};
    public static final int ALL_SIX = 0b111111;

    /** Slot: 0-6 = Z X C V B N R, 7 = M, 8 = J. Dua sabda per slot (biasa, Shift) berbagi cooldown slotnya. */
    public enum Skill {
        SINAR_DAYA(0, 45f, 160), LEDAK_DAYA(0, 70f, 240),
        LIPAT_RUANG(1, 30f, 90), GERBANG_RUANG(1, 55f, 260),
        TUSUK_BENAK(2, 30f, 120), KUASA_BENAK(2, 60f, 400),
        UBAH_MAYA(3, 50f, 240), CERMIN_MAYA(3, 35f, 300),
        HENTI_KALA(4, 80f, 600), PUTAR_KALA(4, 50f, 400),
        RAMPAS_ATMA(5, 45f, 260), TIRAI_ATMA(5, 50f, 360),
        SABDA_PURNA(6, 200f, 1500), PENGHAPUSAN(6, 300f, 1500),
        LONTAR_CAKRAM(7, 35f, 180), PERISAI_SABDA(7, 30f, 180),
        LANGKAH_RUANG(8, 12f, 40), TULIS_ULANG(8, 60f, 600);

        public final int slot;
        public final float cost;
        public final int cooldownTicks;

        Skill(int slot, float cost, int cooldownTicks) {
            this.slot = slot;
            this.cost = cost;
            this.cooldownTicks = cooldownTicks;
        }
    }

    public static final int SLOTS = 9;

    // ================= Angka-angka yang gampang diutak-atik =================
    // Z - Sinar Daya
    private static final double BEAM_RANGE = 40.0;
    private static final double BEAM_WIDTH = 1.15;
    private static final float BEAM_DAMAGE = 6f;            // tiap 2 tick, 16 kali
    // Shift+Z - Ledak Daya
    private static final float NOVA_DAMAGE = 70f;
    public static final double NOVA_RADIUS = 9.0;
    // X - Lipat Ruang
    private static final double FOLD_RANGE = 34.0;
    public static final double FOLD_RADIUS = 4.5;
    private static final float FOLD_OUT_DAMAGE = 26f;       // implosi di titik berangkat
    private static final float FOLD_IN_DAMAGE = 34f;        // implosi di titik tiba
    // Shift+X - Gerbang Ruang
    public static final double GATE_DISTANCE = 6.0;
    public static final double GATE_PULL_RADIUS = 9.0;
    private static final double GATE_SWALLOW = 1.8;
    public static final double GATE_DROP_HEIGHT = 22.0;
    private static final float GATE_DAMAGE = 30f;
    private static final int GATE_MAX = 12;
    // C - Tusuk Benak
    private static final double LANCE_RANGE = 30.0;
    private static final float LANCE_DAMAGE = 48f;
    private static final int LANCE_STUN = 60;
    private static final double LANCE_CHAIN_RADIUS = 7.0;
    private static final int LANCE_CHAINS = 2;
    // Shift+C - Kuasa Benak
    public static final double DOMINION_RADIUS = 16.0;
    private static final float DOMINION_DAMAGE = 12f;
    // V - Ubah Maya
    private static final double REWRITE_RANGE = 28.0;
    public static final double REWRITE_RADIUS = 5.0;
    private static final float REWRITE_MAX_HEALTH = 40f;    // monster sekecil ini ditulis ulang jadi makhluk jinak
    private static final float REWRITE_DAMAGE = 52f;        // yang lebih besar: damage + rapuh
    private static final int BRITTLE_TICKS = 160;
    public static final float BRITTLE_MULTIPLIER = 1.3f;
    // Shift+V - Cermin Maya
    public static final float VEIL_STRIKE = 1.8f;
    // B - Henti Kala
    public static final double TIMESTOP_RADIUS = 16.0;
    public static final float TIMESTOP_INTEREST = 1.5f;     // damage yang ditabung ditagih x1,5
    // Shift+B - Putar Kala
    private static final double REWIND_PUSH_RADIUS = 6.0;
    // N - Rampas Atma
    public static final double SOUL_RADIUS = 14.0;
    private static final int SOUL_MAX = 5;
    private static final float SOUL_DRAIN = 4f;             // tiap 5 tick
    private static final float SOUL_HEAL_SHARE = 0.5f;
    private static final float SOUL_RIP_DAMAGE = 30f;
    private static final float SOUL_ENERGY = 60f;           // tiap jiwa yang tercabut sampai mati
    // Shift+N - Tirai Atma
    public static final float WARD_TAKEN = 0.5f;
    private static final float WARD_REFLECT = 0.25f;
    private static final double WARD_ALLY_RADIUS = 10.0;
    // R - Sabda Purna
    public static final float PURNA_DAMAGE = 1.35f;
    public static final float PURNA_TAKEN = 0.65f;
    private static final float PURNA_BURST_DAMAGE = 40f;
    public static final double PURNA_BURST_RADIUS = 8.0;
    // Shift+R - Penghapusan
    public static final double ERASE_RADIUS = 24.0;
    private static final float ERASE_DAMAGE = 120f;
    private static final float ERASE_THRESHOLD = 0.25f;     // sisa darah di bawah segini = terhapus
    private static final float ERASE_MAX_HEALTH = 150f;     // bos & bos kecil nggak bisa terhapus (cuma kena damage)
    // M - Lontar Cakram / Perisai Sabda
    public static final double DISC_RANGE = 20.0;
    private static final float DISC_DAMAGE = 30f;
    private static final float SHIELD_MELEE = 0.2f;
    // J - Langkah Ruang / Tulis Ulang Diri
    private static final double STEP_RANGE = 10.0;
    private static final int STEP_IFRAMES = 8;
    private static final float SELF_HEAL = 0.3f;
    // Pasif
    private static final float PHASE_CHANCE = 0.2f;
    private static final float PHASE_CHANCE_PURNA = 0.35f;
    private static final int PHASE_COOLDOWN = 30;
    public static final float COMPLETE_DAMAGE = 1.1f;      // Sabda Lengkap
    private static final float SIXFOLD_DAMAGE = 22f;
    public static final double SIXFOLD_RADIUS = 5.0;
    private static final float PUNCH_ENERGY = 4f;
    public static final float REGEN_PER_SECOND = 4f;        // x2 saat Sabda Purna
    public static final float DRAIN_PER_SECOND = 1f;        // 0 saat Sabda Purna
    public static final float RECHARGE_PER_SECOND = 6f;     // wujud manusia
    // =========================================================================

    private static final String PIN_TAG = "shazammod_aksara_pin";

    private static final Map<UUID, State> STATES = new HashMap<>();
    /** Makhluk & proyektil yang sedang ditahan Henti Kala / Tusuk Benak (uuid -> penahanan). */
    private static final Map<UUID, Pin> PINNED = new HashMap<>();
    /** Musuh yang rapuh sesudah Ubah Maya (uuid -> game time habis). */
    private static final Map<UUID, Long> BRITTLE = new HashMap<>();

    /** Keadaan satu Aksara (hilang saat keluar dari server). */
    private static final class State {
        final long[] readyAt = new long[SLOTS];
        long busyUntil;
        long purnaUntil;
        int inscribed;                       // sabda yang sudah tertulis di wujud ini (bit 0-5)
        long timeStopUntil;
        Vec3 timeStopCenter;
        final List<Pin> pins = new ArrayList<>();
        long veilUntil;
        long shieldUntil;
        long wardUntil;
        long phaseReadyAt;
        long iframesUntil;
        long dominionUntil;
        final List<Mob> dominated = new ArrayList<>();
        final ArrayDeque<Snapshot> history = new ArrayDeque<>();
    }

    private static final class Pin {
        final UUID owner;
        final Entity entity;
        long until;
        boolean time;                        // Henti Kala (damage ditabung), bukan cuma terkunci
        final boolean hadNoAi;
        final boolean hadNoGravity;
        final Vec3 motion;
        final Vec3 pos;
        float stored;

        Pin(UUID owner, Entity entity, long until, boolean time) {
            this.owner = owner;
            this.entity = entity;
            this.until = until;
            this.time = time;
            this.hadNoAi = entity instanceof Mob mob && mob.isNoAi();
            this.hadNoGravity = entity.isNoGravity();
            this.motion = entity.getDeltaMovement();
            this.pos = entity.position();
        }
    }

    private record Snapshot(Vec3 pos, float yRot, float xRot, float health, ResourceKey<Level> dimension, long time) {}

    private static State state(ServerPlayer player) {
        return STATES.computeIfAbsent(player.getUUID(), id -> new State());
    }

    private static long now(Entity entity) {
        return entity.level().getGameTime();
    }

    // ----------------------------------------------------------- Pakai skill (tombol)

    /** Tombol Z X C V B N R (key 0-6). Jongkok / Shift = sabda keduanya. */
    public static void useKey(ServerPlayer player, int key) {
        if (key < 0 || key > 6) {
            return;
        }
        use(player, Skill.values()[key * 2 + (player.isShiftKeyDown() ? 1 : 0)]);
    }

    /** Tombol M: Lontar Cakram / Shift: Perisai Sabda. */
    public static void discKey(ServerPlayer player) {
        use(player, player.isShiftKeyDown() ? Skill.PERISAI_SABDA : Skill.LONTAR_CAKRAM);
    }

    /** Tombol J: Langkah Ruang / Shift: Tulis Ulang Diri. */
    public static void stepKey(ServerPlayer player) {
        use(player, player.isShiftKeyDown() ? Skill.TULIS_ULANG : Skill.LANGKAH_RUANG);
    }

    public static void use(ServerPlayer player, Skill skill) {
        if (!ShazamPowers.isAksara(player)) {
            if (ShazamPowers.data(player).anyUnlocked()) {
                msg(player, "message.shazammod.aksara.not_transformed", ChatFormatting.GRAY);
            }
            return;
        }
        State s = state(player);
        long now = now(player);
        if (now < s.busyUntil || slotCooldown(player, skill.slot) > 0) {
            return;
        }
        if (ShazamPowers.data(player).energy() < skill.cost) {
            player.displayClientMessage(Component.translatable("message.shazammod.skill_no_energy", Math.round(skill.cost))
                    .withStyle(ChatFormatting.RED), true);
            return;
        }
        boolean used = switch (skill) {
            case SINAR_DAYA -> sinarDaya(player, s);
            case LEDAK_DAYA -> ledakDaya(player, s);
            case LIPAT_RUANG -> lipatRuang(player, s);
            case GERBANG_RUANG -> gerbangRuang(player, s);
            case TUSUK_BENAK -> tusukBenak(player, s);
            case KUASA_BENAK -> kuasaBenak(player, s);
            case UBAH_MAYA -> ubahMaya(player, s);
            case CERMIN_MAYA -> cerminMaya(player, s);
            case HENTI_KALA -> hentiKala(player, s);
            case PUTAR_KALA -> putarKala(player, s);
            case RAMPAS_ATMA -> rampasAtma(player, s);
            case TIRAI_ATMA -> tiraiAtma(player, s);
            case SABDA_PURNA -> sabdaPurna(player, s);
            case PENGHAPUSAN -> penghapusan(player, s);
            case LONTAR_CAKRAM -> lontarCakram(player, s);
            case PERISAI_SABDA -> perisaiSabda(player, s);
            case LANGKAH_RUANG -> langkahRuang(player, s);
            case TULIS_ULANG -> tulisUlang(player, s);
        };
        if (!used) {
            return;   // tiap skill sudah memberi tahu kenapa gagal
        }
        ShazamData data = ShazamPowers.data(player);
        ShazamPowers.setData(player, data.withEnergy(data.energy() - skill.cost));
        s.readyAt[skill.slot] = now + skill.cooldownTicks;
        if (skill.slot < 6) {
            inscribe(player, s, skill.slot);
        }
        ShazamNetwork.sync(player);
    }

    /** Sisa cooldown satu slot (0-6 = Z..R, 7 = M, 8 = J). */
    public static int slotCooldown(ServerPlayer player, int slot) {
        State s = STATES.get(player.getUUID());
        if (s == null || slot < 0 || slot >= SLOTS) {
            return 0;
        }
        long left = s.readyAt[slot] - now(player);
        return left > 0 ? (int) left : 0;
    }

    public static int phaseCooldownTicks(ServerPlayer player) {
        State s = STATES.get(player.getUUID());
        if (s == null) {
            return 0;
        }
        long left = s.phaseReadyAt - now(player);
        return left > 0 ? (int) left : 0;
    }

    private static int left(ServerPlayer player, long until) {
        long left = until - now(player);
        return left > 0 ? (int) left : 0;
    }

    public static int purnaTicks(ServerPlayer player) {
        State s = STATES.get(player.getUUID());
        return s == null ? 0 : left(player, s.purnaUntil);
    }

    public static int inscribed(ServerPlayer player) {
        State s = STATES.get(player.getUUID());
        return s == null ? 0 : s.inscribed;
    }

    public static int timeStopTicks(ServerPlayer player) {
        State s = STATES.get(player.getUUID());
        return s == null || s.timeStopCenter == null ? 0 : left(player, s.timeStopUntil);
    }

    public static int veilTicks(ServerPlayer player) {
        State s = STATES.get(player.getUUID());
        return s == null ? 0 : left(player, s.veilUntil);
    }

    public static int shieldTicks(ServerPlayer player) {
        State s = STATES.get(player.getUUID());
        return s == null ? 0 : left(player, s.shieldUntil);
    }

    public static int wardTicks(ServerPlayer player) {
        State s = STATES.get(player.getUUID());
        return s == null ? 0 : left(player, s.wardUntil);
    }

    /** Efek dijalankan beberapa tick lagi, dibatalkan kalau pemain keburu balik jadi manusia. */
    private static void later(ServerPlayer player, int delay, Consumer<ServerPlayer> action) {
        ShazamPowers.schedule(player, delay, p -> {
            if (ShazamPowers.isAksara(p)) {
                action.accept(p);
            }
        });
    }

    private static void busy(ServerPlayer player, State s, int ticks) {
        s.busyUntil = Math.max(s.busyUntil, now(player) + ticks);
    }

    // ----------------------------------------------------------- Sabda tertulis

    private static void inscribe(ServerPlayer player, State s, int sabda) {
        int bit = 1 << sabda;
        if ((s.inscribed & bit) != 0) {
            return;
        }
        s.inscribed |= bit;
        int count = Integer.bitCount(s.inscribed);
        boolean full = s.inscribed == ALL_SIX;
        ShazamNetwork.playAnim(player, ShazamAnim.SABDA_INSCRIBE, new Vec3(sabda, full ? 1 : 0, 0));
        if (full) {
            sound(player, player.position(), ShazamSounds.AKSARA_PULSE.get(), 1.6f, 1.25f);
            msg(player, "message.shazammod.aksara.complete", ChatFormatting.GOLD, ChatFormatting.BOLD);
        } else {
            player.displayClientMessage(Component.translatable("message.shazammod.aksara.inscribed",
                    Component.translatable("sabda.shazammod." + SABDA_IDS[sabda]), count).withStyle(ChatFormatting.YELLOW), true);
        }
    }

    // ----------------------------------------------------------- Angka buat ShazamPowers & HUD

    public static boolean isPurnaActive(ServerPlayer player) {
        State s = STATES.get(player.getUUID());
        return s != null && ShazamPowers.isAksara(player) && now(player) < s.purnaUntil;
    }

    /** Pengali semua damage Aksara: Sabda Purna dan Sabda Lengkap. */
    public static float power(ServerPlayer player) {
        State s = STATES.get(player.getUUID());
        if (s == null) {
            return 1f;
        }
        float k = s.inscribed == ALL_SIX ? COMPLETE_DAMAGE : 1f;
        return now(player) < s.purnaUntil ? k * PURNA_DAMAGE : k;
    }

    public static float punchMultiplier(ServerPlayer attacker) {
        return ShazamPowers.AKSARA_PUNCH_MULTIPLIER * power(attacker);
    }

    public static float damageTakenMultiplier(ServerPlayer victim) {
        State s = STATES.get(victim.getUUID());
        float k = ShazamPowers.AKSARA_DAMAGE_TAKEN_MULTIPLIER;
        if (s != null) {
            long now = now(victim);
            if (now < s.purnaUntil) {
                k *= PURNA_TAKEN;
            }
            if (now < s.wardUntil) {
                k *= WARD_TAKEN;
            }
        }
        return k;
    }

    public static float regenPerSecond(ServerPlayer player) {
        return isPurnaActive(player) ? REGEN_PER_SECOND * 2f : REGEN_PER_SECOND;
    }

    public static float energyPerSecond(ServerPlayer player, boolean transformed) {
        if (!transformed) {
            return RECHARGE_PER_SECOND;
        }
        return isPurnaActive(player) ? 0f : -DRAIN_PER_SECOND;
    }

    // ----------------------------------------------------------- Tiap tick

    public static void tick(ServerPlayer player) {
        State s = state(player);
        long now = now(player);
        // Putar Kala: jejak 5 detik terakhir (tiap 5 tick)
        if (player.tickCount % 5 == 0) {
            s.history.addLast(new Snapshot(player.position(), player.getYRot(), player.getXRot(), player.getHealth(),
                    player.level().dimension(), now));
            while (s.history.size() > ShazamAnim.AKSARA_REWIND_BACK / 5 + 1) {
                s.history.removeFirst();
            }
        }
        // Sabda Purna: cooldown berjalan 1,6x lebih cepat, lalu padam
        if (s.purnaUntil != 0L) {
            if (now >= s.purnaUntil) {
                s.purnaUntil = 0L;
                ShazamNetwork.playAnim(player, ShazamAnim.SABDA_PURNA_END, player.position());
                msg(player, "message.shazammod.aksara.purna_end", ChatFormatting.GRAY);
                ShazamNetwork.broadcastState(player);
            } else if (player.tickCount % 5 < 3) {
                for (int i = 0; i < SLOTS; i++) {
                    if (s.readyAt[i] > now) {
                        s.readyAt[i]--;
                    }
                }
            }
        }
        // Henti Kala & Tusuk Benak: yang tertahan tetap diam, yang habis dilepas
        if (s.timeStopCenter != null) {
            if (now >= s.timeStopUntil) {
                resumeTime(player, s);
            } else if (player.tickCount % 3 == 0) {
                captureTime(player, s);   // yang baru masuk wilayah (atau baru ditembakkan) ikut berhenti
            }
        }
        tickPins(player, s, now);
        // Kuasa Benak: monster terus mencari sesamanya
        if (s.dominionUntil != 0L) {
            if (now >= s.dominionUntil) {
                for (Mob mob : s.dominated) {
                    if (mob.isAlive()) {
                        mob.setTarget(null);
                    }
                }
                s.dominated.clear();
                s.dominionUntil = 0L;
            } else if (player.tickCount % 10 == 0) {
                retarget(player, s);
            }
        }
        // Cermin Maya: monster kehilangan jejak
        if (s.veilUntil != 0L) {
            if (now >= s.veilUntil) {
                endVeil(player, s, false);
            } else if (player.tickCount % 10 == 0) {
                for (Mob mob : player.serverLevel().getEntitiesOfClass(Mob.class, player.getBoundingBox().inflate(32.0),
                        m -> m.getTarget() == player)) {
                    mob.setTarget(null);
                }
            }
        }
        ShazamPassives.tick(player);   // Halo Sabda tiap 2 detik, Tinju Enam Sabda, Hati Pahlawan
    }

    /** Hentikan skill yang sedang berjalan (balik jadi manusia, respawn). Cooldown tetap; sabda tertulis hilang. */
    public static void cancelActive(ServerPlayer player) {
        State s = STATES.get(player.getUUID());
        if (s == null) {
            return;
        }
        if (s.timeStopCenter != null) {
            resumeTime(player, s);
        }
        releaseAll(s);
        for (Mob mob : s.dominated) {
            if (mob.isAlive()) {
                mob.setTarget(null);
            }
        }
        s.dominated.clear();
        s.dominionUntil = 0L;
        if (s.veilUntil != 0L) {
            endVeil(player, s, false);
        }
        s.purnaUntil = 0L;
        s.inscribed = 0;
        s.busyUntil = 0L;
        s.shieldUntil = 0L;
        s.wardUntil = 0L;
        s.iframesUntil = 0L;
        s.history.clear();
    }

    public static void forget(UUID id) {
        State s = STATES.remove(id);
        if (s != null) {
            releaseAll(s);
            for (Mob mob : s.dominated) {
                if (mob.isAlive()) {
                    mob.setTarget(null);
                }
            }
        }
    }

    /** Server berhenti: semua yang tertahan dilepas (supaya nggak tersimpan tanpa AI). */
    public static void clear() {
        for (State s : STATES.values()) {
            releaseAll(s);
        }
        STATES.clear();
        PINNED.clear();
        BRITTLE.clear();
    }

    /** Makhluk yang tersimpan saat sedang ditahan (chunk ditutup di tengah Henti Kala): dilepas lagi waktu dimuat. */
    public static void onEntityJoin(EntityJoinLevelEvent event) {
        Entity entity = event.getEntity();
        if (event.getLevel().isClientSide() || !entity.getTags().contains(PIN_TAG) || PINNED.containsKey(entity.getUUID())) {
            return;
        }
        entity.removeTag(PIN_TAG);
        if (entity instanceof Mob mob) {
            mob.setNoAi(false);
        }
        if (entity instanceof Projectile) {
            entity.setNoGravity(false);
        }
    }

    // ----------------------------------------------------------- Alat bantu

    private static void msg(ServerPlayer player, String key, ChatFormatting... style) {
        player.displayClientMessage(Component.translatable(key).withStyle(style), true);
    }

    private static boolean isEnemy(LivingEntity m) {
        return m.isAlive() && m instanceof Enemy && !DemonSoldier.isFriendly(m);
    }

    private static List<LivingEntity> enemies(ServerPlayer player, Vec3 center, double radius) {
        return player.serverLevel().getEntitiesOfClass(LivingEntity.class, new AABB(center, center).inflate(radius),
                m -> isEnemy(m) && m.distanceToSqr(center) <= radius * radius);
    }

    private static List<LivingEntity> closest(ServerPlayer player, Vec3 center, double radius, int max) {
        List<LivingEntity> list = new ArrayList<>(enemies(player, center, radius));
        list.sort(Comparator.comparingDouble(m -> m.distanceToSqr(center)));
        return list.size() > max ? new ArrayList<>(list.subList(0, max)) : list;
    }

    private static void sound(ServerPlayer player, Vec3 at, SoundEvent sound, float volume, float pitch) {
        player.serverLevel().playSound(null, at.x, at.y, at.z, sound, SoundSource.PLAYERS, volume, pitch);
    }

    private static Vec3 flat(Vec3 v) {
        Vec3 f = new Vec3(v.x, 0, v.z);
        return f.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : f.normalize();
    }

    private static Vec3 away(Vec3 center, Entity entity) {
        Vec3 a = new Vec3(entity.getX() - center.x, 0, entity.getZ() - center.z);
        return a.lengthSqr() < 1.0E-4 ? Vec3.ZERO : a.normalize();
    }

    private static Vec3 chest(Entity entity) {
        return entity.position().add(0, entity.getBbHeight() * 0.55, 0);
    }

    private static double segmentDistance(Vec3 p, Vec3 a, Vec3 b) {
        Vec3 ab = b.subtract(a);
        double len2 = ab.lengthSqr();
        double t = len2 < 1.0E-8 ? 0.0 : Mth.clamp(p.subtract(a).dot(ab) / len2, 0.0, 1.0);
        return p.distanceTo(a.add(ab.scale(t)));
    }

    private static void hit(ServerPlayer player, LivingEntity m, float damage) {
        m.invulnerableTime = 0;
        m.hurt(ShazamPowers.forceSource(player), damage * power(player));
    }

    /** Gelombang melingkar: damage penuh di tengah, turun sampai 40% di tepi. Mengembalikan jumlah yang kena. */
    private static int shock(ServerPlayer player, Vec3 c, double radius, float damage, double push, double lift) {
        int hits = 0;
        for (LivingEntity m : enemies(player, c, radius)) {
            double d = Math.sqrt(m.distanceToSqr(c));
            float k = (float) Mth.clamp(1.25 - d / radius, 0.4, 1.0);
            hit(player, m, damage * k);
            Vec3 a = away(c, m);
            m.push(a.x * push * k, lift * k, a.z * push * k);
            m.hurtMarked = true;
            hits++;
        }
        return hits;
    }

    /** Ujung pandangan: blok pertama yang kena (mundur sedikit), atau sejauh range. */
    private static Vec3 aimEnd(ServerPlayer player, double range) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getViewVector(1f).normalize();
        BlockHitResult hit = player.serverLevel().clip(new ClipContext(eye, eye.add(look.scale(range)),
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        return hit.getType() == HitResult.Type.MISS ? eye.add(look.scale(range)) : hit.getLocation().subtract(look.scale(0.6));
    }

    private static Vec3 ground(ServerPlayer player, Vec3 p) {
        BlockHitResult down = player.serverLevel().clip(new ClipContext(p, p.add(0, -24.0, 0), ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, player));
        return down.getType() == HitResult.Type.MISS ? p : down.getLocation();
    }

    /** Titik bebas untuk badan pemain di dekat target (mundur ke arah from kalau tertutup). null = nggak ada. */
    private static Vec3 freeSpot(ServerPlayer player, Vec3 target, Vec3 from) {
        Vec3 back = from.subtract(target);
        double len = back.length();
        Vec3 step = len < 1.0E-4 ? Vec3.ZERO : back.scale(0.5 / len);
        Vec3 p = target;
        for (int i = 0; i < 24; i++) {
            AABB box = player.getBoundingBox().move(p.subtract(player.position()));
            if (player.serverLevel().noCollision(player, box)) {
                return p;
            }
            AABB up = box.move(0, 1.0, 0);
            if (player.serverLevel().noCollision(player, up)) {
                return p.add(0, 1.0, 0);
            }
            if (i * 0.5 > len) {
                break;
            }
            p = p.add(step);
        }
        return null;
    }

    private static void teleport(ServerPlayer player, Vec3 to) {
        player.teleportTo(to.x, to.y, to.z);
        player.fallDistance = 0f;
    }

    /** Musuh yang paling dekat ke arah bidikan (dalam kerucut), terlihat langsung. */
    private static LivingEntity lookTarget(ServerPlayer player, double range, double coneDegrees) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getViewVector(1f).normalize();
        double cos = Math.cos(Math.toRadians(coneDegrees));
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        for (LivingEntity m : enemies(player, eye, range)) {
            Vec3 to = chest(m).subtract(eye);
            double d = to.length();
            if (d < 1.0E-3) {
                continue;
            }
            double dot = to.scale(1.0 / d).dot(look);
            if (dot < cos || !player.hasLineOfSight(m)) {
                continue;
            }
            double score = (1.0 - dot) * 40.0 + d * 0.05;
            if (score < bestScore) {
                bestScore = score;
                best = m;
            }
        }
        return best;
    }

    private static boolean rewritable(LivingEntity m) {
        return m instanceof Mob && !(m instanceof Player) && m.getMaxHealth() <= REWRITE_MAX_HEALTH && !m.hasCustomName()
                && !(m instanceof com.shazammod.rival.RivalChampion) && !(m instanceof com.shazammod.helion3.Helion3)
                && !(m instanceof com.shazammod.guardian.ShazamGuardian);
    }

    private static boolean erasable(LivingEntity m) {
        return !(m instanceof Player) && m.getMaxHealth() < ERASE_MAX_HEALTH
                && !(m instanceof com.shazammod.rival.RivalChampion) && !(m instanceof com.shazammod.helion3.Helion3)
                && !(m instanceof com.shazammod.guardian.ShazamGuardian);
    }

    // ----------------------------------------------------------- Penahanan (Henti Kala & Tusuk Benak)

    private static void pin(ServerPlayer owner, State s, Entity e, int ticks, boolean time) {
        long until = now(owner) + ticks;
        Pin old = PINNED.get(e.getUUID());
        if (old != null) {
            old.until = Math.max(old.until, until);
            old.time |= time;
            return;
        }
        if (!(e instanceof Mob) && !(e instanceof Projectile)) {
            return;
        }
        Pin pin = new Pin(owner.getUUID(), e, until, time);
        PINNED.put(e.getUUID(), pin);
        s.pins.add(pin);
        e.addTag(PIN_TAG);
        if (e instanceof Mob mob) {
            mob.getNavigation().stop();
            mob.setTarget(null);
            mob.setNoAi(true);
        } else {
            e.setNoGravity(true);
        }
        e.setDeltaMovement(Vec3.ZERO);
        e.hurtMarked = true;
    }

    private static void tickPins(ServerPlayer player, State s, long now) {
        for (Iterator<Pin> it = s.pins.iterator(); it.hasNext(); ) {
            Pin pin = it.next();
            Entity e = pin.entity;
            if (e.isRemoved() || (e instanceof LivingEntity l && !l.isAlive())) {
                PINNED.remove(e.getUUID());
                it.remove();
                continue;
            }
            if (now >= pin.until) {
                it.remove();
                release(player, pin);
                continue;
            }
            e.setDeltaMovement(Vec3.ZERO);
            if (e instanceof Projectile) {
                e.setPos(pin.pos.x, pin.pos.y, pin.pos.z);
            }
        }
    }

    private static void release(ServerPlayer owner, Pin pin) {
        Entity e = pin.entity;
        PINNED.remove(e.getUUID());
        e.removeTag(PIN_TAG);
        if (e instanceof Mob mob) {
            mob.setNoAi(pin.hadNoAi);
        } else {
            e.setNoGravity(pin.hadNoGravity);
            e.setDeltaMovement(pin.motion);
        }
        e.hurtMarked = true;
        if (owner != null && pin.time && pin.stored > 0f && e instanceof LivingEntity living && living.isAlive()) {
            // waktu menagih: semua damage yang ditabung masuk sekaligus
            living.invulnerableTime = 0;
            living.hurt(ShazamPowers.forceSource(owner), pin.stored * TIMESTOP_INTEREST);
            ShazamNetwork.playAnim(owner, ShazamAnim.SABDA_HIT, chest(living));
        }
    }

    private static void releaseAll(State s) {
        for (Pin pin : s.pins) {
            Entity e = pin.entity;
            PINNED.remove(e.getUUID());
            if (e.isRemoved()) {
                continue;
            }
            e.removeTag(PIN_TAG);
            if (e instanceof Mob mob) {
                mob.setNoAi(pin.hadNoAi);
            } else {
                e.setNoGravity(pin.hadNoGravity);
                e.setDeltaMovement(pin.motion);
            }
        }
        s.pins.clear();
        s.timeStopCenter = null;
    }

    public static boolean isPinned(Entity entity) {
        return PINNED.containsKey(entity.getUUID());
    }

    // ----------------------------------------------------------- Damage dari & ke siapa saja (ShazamPowers)

    /**
     * Dipanggil untuk semua damage (sesudah pengali juara): Ubah Maya membuat musuh rapuh, Cermin Maya menebalkan serangan
     * pertama, dan Henti Kala menabung damage ke musuh yang berhenti (ditagih x1,5 saat waktu berjalan lagi).
     */
    public static void onAnyDamage(LivingIncomingDamageEvent event) {
        LivingEntity victim = event.getEntity();
        DamageSource source = event.getSource();
        if (source.getEntity() instanceof ServerPlayer attacker && attacker != victim && ShazamPowers.isAksara(attacker)) {
            Long brittle = BRITTLE.get(victim.getUUID());
            if (brittle != null) {
                if (brittle > now(victim)) {
                    event.setAmount(event.getAmount() * BRITTLE_MULTIPLIER);
                } else {
                    BRITTLE.remove(victim.getUUID());
                }
            }
            State s = STATES.get(attacker.getUUID());
            if (s != null && s.veilUntil != 0L && now(attacker) < s.veilUntil) {
                event.setAmount(event.getAmount() * VEIL_STRIKE);
                endVeil(attacker, s, true);
            }
        }
        Pin pin = PINNED.get(victim.getUUID());
        if (pin != null && pin.time && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            pin.stored += event.getAmount();
            event.setCanceled(true);
        }
    }

    /**
     * Serangan ke Aksara, sebelum tahan banting dihitung. true = dibatalkan (Langkah Ruang, proyektil dipantulkan
     * Perisai Sabda, atau Tangkal Ruang).
     */
    public static boolean defend(ServerPlayer victim, DamageSource source, LivingIncomingDamageEvent event) {
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return false;
        }
        State s = STATES.get(victim.getUUID());
        if (s == null) {
            return false;
        }
        long now = now(victim);
        if (now < s.iframesUntil) {
            return true;
        }
        Entity direct = source.getDirectEntity();
        Entity attacker = source.getEntity();
        if (now < s.shieldUntil && direct instanceof Projectile projectile && fromFront(victim, projectile.position())) {
            Vec3 v = projectile.getDeltaMovement();
            projectile.setDeltaMovement(v.scale(-1.15));
            projectile.setOwner(victim);
            projectile.hurtMarked = true;
            ShazamNetwork.playAnim(victim, ShazamAnim.SABDA_BLOCK, projectile.position());
            sound(victim, projectile.position(), ShazamSounds.AKSARA_SHIELD.get(), 1.2f, 1.4f);
            return true;
        }
        if (attacker instanceof LivingEntity att && att != victim && now >= s.phaseReadyAt && now >= s.busyUntil
                && victim.getRandom().nextFloat() < (now < s.purnaUntil ? PHASE_CHANCE_PURNA : PHASE_CHANCE)) {
            s.phaseReadyAt = now + PHASE_COOLDOWN;
            phase(victim, att);
            return true;
        }
        return false;
    }

    /** Serangan yang tetap masuk (sesudah tahan banting): Perisai Sabda menahan pukulan depan, Tirai Atma memantulkan. */
    public static void onIncoming(ServerPlayer victim, DamageSource source, LivingIncomingDamageEvent event) {
        if (source.is(DamageTypeTags.BYPASSES_RESISTANCE)) {
            return;
        }
        State s = STATES.get(victim.getUUID());
        if (s == null) {
            return;
        }
        long now = now(victim);
        Entity direct = source.getDirectEntity();
        if (now < s.shieldUntil && direct != null && fromFront(victim, direct.position())) {
            event.setAmount(event.getAmount() * SHIELD_MELEE);
            ShazamNetwork.playAnim(victim, ShazamAnim.SABDA_BLOCK, chest(victim).add(flat(victim.getViewVector(1f)).scale(0.8)));
            sound(victim, victim.position(), ShazamSounds.AKSARA_SHIELD.get(), 1.0f, 0.9f);
        }
        if (now < s.wardUntil && source.getEntity() instanceof LivingEntity att && att != victim && att.isAlive()) {
            reflect(victim, att, event.getAmount() * WARD_REFLECT / Math.max(0.05f, damageTakenMultiplier(victim)));
        }
    }

    private static boolean reflecting;

    /** Pantulan Tirai Atma; nggak memicu pantulan balik (dua Aksara yang saling pukul). */
    private static void reflect(ServerPlayer owner, LivingEntity attacker, float amount) {
        if (reflecting || amount <= 0.5f) {
            return;
        }
        reflecting = true;
        try {
            attacker.invulnerableTime = 0;
            attacker.hurt(ShazamPowers.forceSource(owner), amount);
            ShazamNetwork.playAnim(owner, ShazamAnim.SABDA_SOUL_RIP, chest(attacker));
        } finally {
            reflecting = false;
        }
    }

    private static boolean fromFront(ServerPlayer victim, Vec3 from) {
        Vec3 to = new Vec3(from.x - victim.getX(), 0, from.z - victim.getZ());
        if (to.lengthSqr() < 1.0E-4) {
            return true;
        }
        return to.normalize().dot(flat(victim.getViewVector(1f))) >= 0.25;
    }

    /** Tangkal Ruang: ruang dilipat, Aksara muncul di belakang penyerangnya (atau menyamping kalau tertutup). */
    private static void phase(ServerPlayer victim, LivingEntity attacker) {
        Vec3 from = victim.position();
        Vec3 dest = null;
        if (attacker.distanceToSqr(victim) < 64.0) {
            Vec3 behind = attacker.position().subtract(flat(attacker.getViewVector(1f)).scale(1.8));
            dest = freeSpot(victim, behind, attacker.position());
        }
        if (dest == null) {
            Vec3 side = flat(victim.getViewVector(1f)).yRot(victim.getRandom().nextBoolean() ? 1.5708f : -1.5708f);
            dest = freeSpot(victim, from.add(side.scale(2.2)), from);
        }
        ShazamNetwork.playAnim(victim, ShazamAnim.SABDA_PHASE, dest == null ? from : dest);
        sound(victim, from, ShazamSounds.AKSARA_PARRY.get(), 1.2f, 0.95f + victim.getRandom().nextFloat() * 0.1f);
        if (dest != null) {
            // dipindah satu tick kemudian: jangan memindahkan pemain di tengah event damage-nya sendiri
            final Vec3 to = dest;
            ShazamPowers.schedule(victim, 1, p -> {
                if (!ShazamPowers.isAksara(p) || p.level() != attacker.level()) {
                    return;
                }
                Vec3 face = attacker.position().subtract(to);
                float yaw = (float) (Mth.atan2(face.z, face.x) * Mth.RAD_TO_DEG) - 90f;
                p.teleportTo(p.serverLevel(), to.x, to.y, to.z, yaw, p.getXRot());
                p.fallDistance = 0f;
            });
        }
    }

    // ----------------------------------------------------------- Berubah wujud & tinju

    /** Cakram Sabda mengunci di punggung saat berubah: gelombang aksara menghempas monster di sekitar. */
    public static void transformBurst(ServerPlayer caster, Vec3 pos, float damage, double radius) {
        State s = state(caster);
        s.inscribed = 0;
        s.history.clear();
        if (damage <= 0f) {
            return;
        }
        DamageSource source = ShazamPowers.forceSource(caster);
        for (LivingEntity target : enemies(caster, pos, radius)) {
            target.hurt(source, damage);
            Vec3 a = away(pos, target);
            target.push(a.x * 1.6, 0.45, a.z * 1.6);
            target.hurtMarked = true;
        }
    }

    /** Tinju tangan kosong mengenai: percikan aksara di titik kena, sedikit energi kembali. */
    public static void onPunch(ServerPlayer attacker, LivingEntity hit) {
        Vec3 at = chest(hit);
        ShazamNetwork.playAnim(attacker, ShazamAnim.SABDA_PUNCH, at);
        sound(attacker, at, ShazamSounds.AKSARA_PUNCH.get(), 0.8f, 0.95f + attacker.getRandom().nextFloat() * 0.15f);
        ShazamData d = ShazamPowers.data(attacker);
        if (d.energy() < ShazamPowers.MAX_ENERGY) {
            ShazamPowers.setData(attacker, d.withEnergy(Math.min(ShazamPowers.MAX_ENERGY, d.energy() + PUNCH_ENERGY)));
        }
    }

    /**
     * Tinju Enam Sabda (muatan penuh, padanan Pukulan Guntur; damage-nya sudah dikali di event yang sama): ledakan enam warna,
     * sasaran terlempar, musuh di sekitarnya terhempas dan benaknya terkunci sebentar.
     */
    public static void sixfoldPunch(ServerPlayer player, LivingEntity target) {
        Vec3 at = chest(target);
        ShazamNetwork.playAnim(player, ShazamAnim.SABDA_SIXFOLD, at);
        sound(player, at, ShazamSounds.AKSARA_SIXFOLD.get(), 2.0f, 1f);
        ShazamPowers.schedule(player, 1, p -> {
            if (target.isAlive()) {
                Vec3 dir = away(p.position(), target);
                target.push(dir.x * 2.2, 0.55, dir.z * 2.2);
                target.hurtMarked = true;
            }
            State s = state(p);
            for (LivingEntity m : enemies(p, target.position(), SIXFOLD_RADIUS)) {
                if (m == target) {
                    continue;
                }
                hit(p, m, SIXFOLD_DAMAGE);
                Vec3 a = away(target.position(), m);
                m.push(a.x * 1.1, 0.35, a.z * 1.1);
                m.hurtMarked = true;
                if (m instanceof Mob) {
                    pin(p, s, m, 20, false);
                }
            }
        });
    }

    // ----------------------------------------------------------- Z - Sabda Daya

    private static boolean sinarDaya(ServerPlayer player, State s) {
        ShazamNetwork.playAnim(player, ShazamAnim.AKSARA_BEAM);
        busy(player, s, ShazamAnim.AKSARA_BEAM_WINDUP + ShazamAnim.AKSARA_BEAM_TICKS);
        sound(player, player.position(), ShazamSounds.AKSARA_BEAM.get(), 2.0f, 1f);
        for (int t = ShazamAnim.AKSARA_BEAM_WINDUP; t < ShazamAnim.AKSARA_BEAM_WINDUP + ShazamAnim.AKSARA_BEAM_TICKS; t += 2) {
            final boolean last = t + 2 >= ShazamAnim.AKSARA_BEAM_WINDUP + ShazamAnim.AKSARA_BEAM_TICKS;
            later(player, t, p -> beamTick(p, last));
        }
        return true;
    }

    private static void beamTick(ServerPlayer player, boolean last) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getViewVector(1f).normalize();
        Vec3 start = eye.add(look.scale(0.6)).add(0, -0.25, 0);
        Vec3 end = aimEnd(player, BEAM_RANGE);
        for (LivingEntity m : enemies(player, start.add(end).scale(0.5), start.distanceTo(end) * 0.5 + 2.0)) {
            if (segmentDistance(chest(m), start, end) <= BEAM_WIDTH + m.getBbWidth() * 0.5) {
                hit(player, m, BEAM_DAMAGE);
                m.push(look.x * 0.12, 0.02, look.z * 0.12);
                m.hurtMarked = true;
            }
        }
        if (last) {
            ShazamNetwork.playAnim(player, ShazamAnim.SABDA_HIT, end);
            shock(player, end, 2.5, BEAM_DAMAGE * 3f, 0.8, 0.3);
        }
    }

    private static boolean ledakDaya(ServerPlayer player, State s) {
        ShazamNetwork.playAnim(player, ShazamAnim.AKSARA_NOVA);
        busy(player, s, ShazamAnim.AKSARA_NOVA_WINDUP + 4);
        sound(player, player.position(), ShazamSounds.AKSARA_NOVA.get(), 3.0f, 1f);
        later(player, ShazamAnim.AKSARA_NOVA_WINDUP, p -> {
            Vec3 c = p.position().add(0, 1.0, 0);
            shock(p, c, NOVA_RADIUS, NOVA_DAMAGE, 2.2, 0.9);
        });
        return true;
    }

    // ----------------------------------------------------------- X - Sabda Ruang

    private static boolean lipatRuang(ServerPlayer player, State s) {
        Vec3 aim = aimEnd(player, FOLD_RANGE);
        Vec3 target = player.onGround() && !player.getAbilities().flying ? ground(player, aim.add(0, 0.5, 0)) : aim;
        Vec3 dest = freeSpot(player, target, player.position());
        if (dest == null || dest.distanceToSqr(player.position()) < 4.0) {
            msg(player, "message.shazammod.aksara.blocked", ChatFormatting.GRAY);
            return false;
        }
        ShazamNetwork.playAnim(player, ShazamAnim.AKSARA_FOLD, dest);
        busy(player, s, ShazamAnim.AKSARA_FOLD_SNAP + 2);
        sound(player, player.position(), ShazamSounds.AKSARA_FOLD.get(), 1.6f, 1f);
        final Vec3 to = dest;
        later(player, ShazamAnim.AKSARA_FOLD_SNAP, p -> {
            Vec3 from = p.position();
            implode(p, from.add(0, 1.0, 0), FOLD_OUT_DAMAGE, false);
            teleport(p, to);
            implode(p, to.add(0, 1.0, 0), FOLD_IN_DAMAGE, true);
            sound(p, to, ShazamSounds.AKSARA_FOLD.get(), 1.6f, 1.25f);
        });
        return true;
    }

    /** Ruang terlipat di satu titik: musuh di sekitarnya tersedot ke tengah dan terluka. */
    private static void implode(ServerPlayer player, Vec3 c, float damage, boolean stun) {
        ShazamNetwork.playAnim(player, ShazamAnim.SABDA_IMPLODE, c);
        State s = state(player);
        for (LivingEntity m : enemies(player, c, FOLD_RADIUS)) {
            hit(player, m, damage);
            Vec3 in = c.subtract(chest(m));
            double d = in.length();
            if (d > 0.3) {
                Vec3 pull = in.scale(Math.min(1.2, d * 0.3) / d);
                m.push(pull.x, pull.y + 0.15, pull.z);
                m.hurtMarked = true;
            }
            if (stun) {
                pin(player, s, m, 20, false);
            }
        }
    }

    private static boolean gerbangRuang(ServerPlayer player, State s) {
        Vec3 dir = flat(player.getViewVector(1f));
        Vec3 gate = player.position().add(dir.scale(GATE_DISTANCE)).add(0, 1.3, 0);
        ShazamNetwork.playAnim(player, ShazamAnim.AKSARA_GATE, gate);
        busy(player, s, ShazamAnim.AKSARA_GATE_SWALLOW + 2);
        sound(player, gate, ShazamSounds.AKSARA_GATE.get(), 2.6f, 1f);
        final Set<UUID> swallowed = new HashSet<>();
        final double drop = skyRoom(player, gate);
        for (int t = ShazamAnim.AKSARA_GATE_OPEN; t <= ShazamAnim.AKSARA_GATE_SWALLOW; t += 2) {
            final boolean last = t + 2 > ShazamAnim.AKSARA_GATE_SWALLOW;
            later(player, t, p -> gateTick(p, gate, swallowed, last, drop));
        }
        return true;
    }

    /**
     * Tinggi gerbang langit di atas gerbang (paling tinggi GATE_DROP_HEIGHT), dipendekkan kalau ada atap / langit-langit
     * gua: musuh nggak boleh dimuntahkan ke dalam batu (mati tercekik, bukan jatuh).
     */
    private static double skyRoom(ServerPlayer player, Vec3 gate) {
        BlockHitResult up = player.serverLevel().clip(new ClipContext(gate, gate.add(0, GATE_DROP_HEIGHT + 3.0, 0),
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        if (up.getType() == HitResult.Type.MISS) {
            return GATE_DROP_HEIGHT;
        }
        return Math.max(0.0, up.getLocation().y - gate.y - 3.5);
    }

    private static void gateTick(ServerPlayer player, Vec3 gate, Set<UUID> swallowed, boolean last, double drop) {
        for (LivingEntity m : enemies(player, gate, GATE_PULL_RADIUS)) {
            if (swallowed.contains(m.getUUID())) {
                continue;
            }
            Vec3 in = gate.subtract(chest(m));
            double d = in.length();
            if ((d <= GATE_SWALLOW || last) && swallowed.size() < GATE_MAX) {
                swallowed.add(m.getUUID());
                Vec3 out = gate.add((player.getRandom().nextDouble() - 0.5) * (drop > 4.0 ? 3.0 : 0.0), drop,
                        (player.getRandom().nextDouble() - 0.5) * (drop > 4.0 ? 3.0 : 0.0));
                ShazamNetwork.playAnim(player, ShazamAnim.SABDA_IMPLODE, chest(m));
                hit(player, m, GATE_DAMAGE);
                m.teleportTo(out.x, out.y, out.z);
                m.setDeltaMovement(0, -1.2, 0);
                m.hurtMarked = true;
                ShazamNetwork.playAnim(player, ShazamAnim.SABDA_SKYGATE, out.add(0, 1.0, 0));
            } else if (d > 0.1) {
                Vec3 pull = in.scale(0.42 / d);
                m.setDeltaMovement(m.getDeltaMovement().scale(0.5).add(pull));
                m.hurtMarked = true;
            }
        }
        if (last && !swallowed.isEmpty()) {
            sound(player, gate.add(0, drop, 0), ShazamSounds.AKSARA_GATE.get(), 2.6f, 1.3f);
        }
    }

    // ----------------------------------------------------------- C - Sabda Benak

    private static boolean tusukBenak(ServerPlayer player, State s) {
        LivingEntity target = lookTarget(player, LANCE_RANGE, 9.0);
        if (target == null) {
            msg(player, "message.shazammod.aksara.no_target", ChatFormatting.GRAY);
            return false;
        }
        ShazamNetwork.playAnim(player, ShazamAnim.AKSARA_LANCE, chest(target));
        busy(player, s, ShazamAnim.AKSARA_LANCE_HIT + 2);
        sound(player, player.position(), ShazamSounds.AKSARA_LANCE.get(), 1.8f, 1f);
        later(player, ShazamAnim.AKSARA_LANCE_HIT, p -> {
            if (!target.isAlive()) {
                return;
            }
            State st = state(p);
            hit(p, target, LANCE_DAMAGE);
            pin(p, st, target, LANCE_STUN, false);
            ShazamNetwork.playAnim(p, ShazamAnim.SABDA_STUN, chest(target));
            int chained = 0;
            for (LivingEntity m : closest(p, target.position(), LANCE_CHAIN_RADIUS, LANCE_CHAINS + 1)) {
                if (m == target || chained >= LANCE_CHAINS) {
                    continue;
                }
                hit(p, m, LANCE_DAMAGE * 0.5f);
                pin(p, st, m, LANCE_STUN / 2, false);
                ShazamNetwork.playAnim(p, ShazamAnim.SABDA_STUN, chest(m));
                chained++;
            }
        });
        return true;
    }

    private static boolean kuasaBenak(ServerPlayer player, State s) {
        ShazamNetwork.playAnim(player, ShazamAnim.AKSARA_DOMINION);
        busy(player, s, ShazamAnim.AKSARA_DOMINION_HIT + 2);
        sound(player, player.position(), ShazamSounds.AKSARA_DOMINION.get(), 2.4f, 1f);
        later(player, ShazamAnim.AKSARA_DOMINION_HIT, p -> {
            State st = state(p);
            st.dominated.clear();
            for (LivingEntity m : enemies(p, p.position(), DOMINION_RADIUS)) {
                hit(p, m, DOMINION_DAMAGE);
                m.addEffect(new MobEffectInstance(MobEffects.GLOWING, ShazamAnim.AKSARA_DOMINION_TICKS, 0, false, false), p);
                if (m instanceof Mob mob) {
                    st.dominated.add(mob);
                }
                ShazamNetwork.playAnim(p, ShazamAnim.SABDA_STUN, chest(m));
            }
            st.dominionUntil = now(p) + ShazamAnim.AKSARA_DOMINION_TICKS;
            retarget(p, st);
            p.displayClientMessage(Component.translatable("message.shazammod.aksara.dominion", st.dominated.size())
                    .withStyle(ChatFormatting.AQUA), true);
        });
        return true;
    }

    /** Kuasa Benak: tiap monster yang dikuasai menyerang monster lain terdekat. */
    private static void retarget(ServerPlayer player, State s) {
        for (Mob mob : s.dominated) {
            if (!mob.isAlive() || isPinned(mob)) {
                continue;
            }
            LivingEntity best = null;
            double bestD = Double.MAX_VALUE;
            for (LivingEntity other : enemies(player, mob.position(), 14.0)) {
                if (other == mob) {
                    continue;
                }
                double d = other.distanceToSqr(mob);
                if (d < bestD) {
                    bestD = d;
                    best = other;
                }
            }
            mob.setTarget(best);
        }
    }

    // ----------------------------------------------------------- V - Sabda Maya

    private static boolean ubahMaya(ServerPlayer player, State s) {
        Vec3 aim = aimEnd(player, REWRITE_RANGE);
        Vec3 c = ground(player, aim.add(0, 0.5, 0)).add(0, 0.6, 0);
        ShazamNetwork.playAnim(player, ShazamAnim.AKSARA_REWRITE, c);
        busy(player, s, ShazamAnim.AKSARA_REWRITE_HIT + 2);
        sound(player, c, ShazamSounds.AKSARA_REWRITE.get(), 2.2f, 1f);
        later(player, ShazamAnim.AKSARA_REWRITE_HIT, p -> rewrite(p, c));
        return true;
    }

    private static void rewrite(ServerPlayer player, Vec3 c) {
        ServerLevel level = player.serverLevel();
        int changed = 0;
        for (LivingEntity m : enemies(player, c, REWRITE_RADIUS)) {
            if (rewritable(m)) {
                Mob calm = player.getRandom().nextBoolean() ? EntityType.CHICKEN.create(level) : EntityType.RABBIT.create(level);
                if (calm != null) {
                    calm.moveTo(m.getX(), m.getY(), m.getZ(), m.getYRot(), 0f);
                    ShazamNetwork.playAnim(player, ShazamAnim.SABDA_POOF, chest(m));
                    m.discard();
                    level.addFreshEntity(calm);
                    changed++;
                    continue;
                }
            }
            hit(player, m, REWRITE_DAMAGE);
            BRITTLE.put(m.getUUID(), now(player) + BRITTLE_TICKS);
            m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 1), player);
            Vec3 a = away(c, m);
            m.push(a.x * 0.8, 0.5, a.z * 0.8);
            m.hurtMarked = true;
            ShazamNetwork.playAnim(player, ShazamAnim.SABDA_HIT, chest(m));
        }
        // proyektil di wilayah itu ditulis ulang jadi... nggak ada
        for (Projectile projectile : level.getEntitiesOfClass(Projectile.class, new AABB(c, c).inflate(REWRITE_RADIUS),
                pr -> pr.getOwner() != player)) {
            ShazamNetwork.playAnim(player, ShazamAnim.SABDA_POOF, projectile.position());
            projectile.discard();
        }
        if (changed > 0) {
            player.displayClientMessage(Component.translatable("message.shazammod.aksara.rewritten", changed)
                    .withStyle(ChatFormatting.LIGHT_PURPLE), true);
        }
    }

    private static boolean cerminMaya(ServerPlayer player, State s) {
        ShazamNetwork.playAnim(player, ShazamAnim.AKSARA_VEIL);
        busy(player, s, ShazamAnim.AKSARA_VEIL_HIT + 1);
        sound(player, player.position(), ShazamSounds.AKSARA_VEIL.get(), 1.6f, 1f);
        later(player, ShazamAnim.AKSARA_VEIL_HIT, p -> {
            State st = state(p);
            st.veilUntil = now(p) + ShazamAnim.AKSARA_VEIL_TICKS;
            p.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, ShazamAnim.AKSARA_VEIL_TICKS, 0, false, false, true));
            for (Mob mob : p.serverLevel().getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(32.0),
                    m -> m.getTarget() == p)) {
                mob.setTarget(null);
            }
            msg(p, "message.shazammod.aksara.veil", ChatFormatting.LIGHT_PURPLE);
        });
        return true;
    }

    private static void endVeil(ServerPlayer player, State s, boolean struck) {
        s.veilUntil = 0L;
        player.removeEffect(MobEffects.INVISIBILITY);
        ShazamNetwork.playAnim(player, ShazamAnim.SABDA_VEIL_END, chest(player));
        sound(player, player.position(), ShazamSounds.AKSARA_VEIL.get(), 1.2f, struck ? 1.5f : 0.8f);
    }

    // ----------------------------------------------------------- B - Sabda Kala

    private static boolean hentiKala(ServerPlayer player, State s) {
        if (s.timeStopCenter != null) {
            return false;
        }
        ShazamNetwork.playAnim(player, ShazamAnim.AKSARA_TIMESTOP);
        busy(player, s, ShazamAnim.AKSARA_TIMESTOP_HIT + 2);
        sound(player, player.position(), ShazamSounds.AKSARA_TIMESTOP.get(), 3.0f, 1f);
        later(player, ShazamAnim.AKSARA_TIMESTOP_HIT, p -> {
            State st = state(p);
            st.timeStopCenter = p.position().add(0, 1.0, 0);
            st.timeStopUntil = now(p) + ShazamAnim.AKSARA_TIMESTOP_TICKS;
            captureTime(p, st);
            msg(p, "message.shazammod.aksara.timestop", ChatFormatting.GOLD);
        });
        return true;
    }

    private static void captureTime(ServerPlayer player, State s) {
        Vec3 c = s.timeStopCenter;
        int ticks = (int) Math.max(1L, s.timeStopUntil - now(player));
        for (LivingEntity m : enemies(player, c, TIMESTOP_RADIUS)) {
            pin(player, s, m, ticks, true);
        }
        for (Projectile projectile : player.serverLevel().getEntitiesOfClass(Projectile.class,
                new AABB(c, c).inflate(TIMESTOP_RADIUS), pr -> pr.getOwner() != player && pr.distanceToSqr(c)
                        <= TIMESTOP_RADIUS * TIMESTOP_RADIUS && pr.getDeltaMovement().lengthSqr() > 1.0E-3)) {
            pin(player, s, projectile, ticks, true);
        }
    }

    private static void resumeTime(ServerPlayer player, State s) {
        Vec3 c = s.timeStopCenter;
        s.timeStopCenter = null;
        float total = 0f;
        for (Pin pin : s.pins) {
            if (pin.time) {
                total += pin.stored;
                pin.until = 0L;   // dilepas di tickPins berikutnya (damage-nya ditagih di sana)
            }
        }
        tickPins(player, s, now(player));
        if (c != null) {
            ShazamNetwork.playAnim(player, ShazamAnim.SABDA_TIME_END, c);
            sound(player, c, ShazamSounds.AKSARA_TIMERESUME.get(), 3.0f, 1f);
            if (total > 0f) {
                player.displayClientMessage(Component.translatable("message.shazammod.aksara.time_resume",
                        Math.round(total * TIMESTOP_INTEREST)).withStyle(ChatFormatting.GOLD), true);
            }
        }
    }

    private static boolean putarKala(ServerPlayer player, State s) {
        Snapshot back = null;
        for (Snapshot snap : s.history) {
            if (snap.dimension().equals(player.level().dimension())) {
                back = snap;
                break;
            }
        }
        if (back == null || back.pos().distanceToSqr(player.position()) < 1.0 && back.health() <= player.getHealth()) {
            msg(player, "message.shazammod.aksara.no_history", ChatFormatting.GRAY);
            return false;
        }
        final Snapshot to = back;
        ShazamNetwork.playAnim(player, ShazamAnim.AKSARA_REWIND, to.pos());
        busy(player, s, ShazamAnim.AKSARA_REWIND_HIT + 2);
        sound(player, player.position(), ShazamSounds.AKSARA_REWIND.get(), 2.0f, 1f);
        later(player, ShazamAnim.AKSARA_REWIND_HIT, p -> {
            p.teleportTo(p.serverLevel(), to.pos().x, to.pos().y, to.pos().z, to.yRot(), to.xRot());
            p.fallDistance = 0f;
            if (to.health() > p.getHealth()) {
                p.setHealth(Math.min(p.getMaxHealth(), to.health()));
            }
            p.clearFire();
            cleanse(p);
            state(p).history.clear();
            Vec3 c = to.pos().add(0, 1.0, 0);
            ShazamNetwork.playAnim(p, ShazamAnim.SABDA_IMPLODE, c);
            for (LivingEntity m : enemies(p, c, REWIND_PUSH_RADIUS)) {
                Vec3 a = away(c, m);
                m.push(a.x * 1.4, 0.4, a.z * 1.4);
                m.hurtMarked = true;
            }
            msg(p, "message.shazammod.aksara.rewind", ChatFormatting.GOLD);
        });
        return true;
    }

    private static void cleanse(ServerPlayer player) {
        List<MobEffectInstance> bad = new ArrayList<>();
        for (MobEffectInstance effect : player.getActiveEffects()) {
            if (effect.getEffect().value().getCategory() == MobEffectCategory.HARMFUL) {
                bad.add(effect);
            }
        }
        for (MobEffectInstance effect : bad) {
            player.removeEffect(effect.getEffect());
        }
    }

    // ----------------------------------------------------------- N - Sabda Atma

    private static boolean rampasAtma(ServerPlayer player, State s) {
        List<LivingEntity> targets = closest(player, player.position(), SOUL_RADIUS, SOUL_MAX);
        targets.removeIf(m -> !player.hasLineOfSight(m));
        if (targets.isEmpty()) {
            msg(player, "message.shazammod.aksara.no_target", ChatFormatting.GRAY);
            return false;
        }
        ShazamNetwork.playAnim(player, ShazamAnim.AKSARA_SOUL);
        busy(player, s, ShazamAnim.AKSARA_SOUL_RIP + 2);
        sound(player, player.position(), ShazamSounds.AKSARA_SOUL.get(), 2.2f, 1f);
        for (int t = ShazamAnim.AKSARA_SOUL_WINDUP; t < ShazamAnim.AKSARA_SOUL_RIP; t += 5) {
            later(player, t, p -> {
                float healed = 0f;
                for (LivingEntity m : targets) {
                    if (m.isAlive() && m.distanceToSqr(p) < SOUL_RADIUS * SOUL_RADIUS * 1.6) {
                        hit(p, m, SOUL_DRAIN);
                        healed += SOUL_DRAIN * power(p) * SOUL_HEAL_SHARE;
                    }
                }
                if (healed > 0f) {
                    p.heal(healed * ShazamPowers.healScale(p));
                }
            });
        }
        later(player, ShazamAnim.AKSARA_SOUL_RIP, p -> {
            int souls = 0;
            for (LivingEntity m : targets) {
                if (!m.isAlive()) {
                    continue;
                }
                hit(p, m, SOUL_RIP_DAMAGE);
                ShazamNetwork.playAnim(p, ShazamAnim.SABDA_SOUL_RIP, chest(m));
                if (!m.isAlive()) {
                    souls++;
                }
            }
            if (souls > 0) {
                ShazamData d = ShazamPowers.data(p);
                ShazamPowers.setData(p, d.withEnergy(d.energy() + SOUL_ENERGY * souls));
                p.displayClientMessage(Component.translatable("message.shazammod.aksara.souls", souls)
                        .withStyle(ChatFormatting.GREEN), true);
            }
            sound(p, p.position(), ShazamSounds.AKSARA_SOUL.get(), 2.0f, 1.4f);
        });
        return true;
    }

    private static boolean tiraiAtma(ServerPlayer player, State s) {
        ShazamNetwork.playAnim(player, ShazamAnim.AKSARA_WARD);
        busy(player, s, ShazamAnim.AKSARA_WARD_HIT + 2);
        sound(player, player.position(), ShazamSounds.AKSARA_WARD.get(), 2.0f, 1f);
        later(player, ShazamAnim.AKSARA_WARD_HIT, p -> {
            state(p).wardUntil = now(p) + ShazamAnim.AKSARA_WARD_TICKS;
            int allies = 0;
            for (LivingEntity ally : p.serverLevel().getEntitiesOfClass(LivingEntity.class,
                    p.getBoundingBox().inflate(WARD_ALLY_RADIUS), e -> e != p && e.isAlive()
                            && (e instanceof Player || (e instanceof TamableAnimal pet && pet.isOwnedBy(p))))) {
                ally.addEffect(new MobEffectInstance(MobEffects.REGENERATION, ShazamAnim.AKSARA_WARD_TICKS, 1), p);
                ally.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, ShazamAnim.AKSARA_WARD_TICKS, 1), p);
                ShazamNetwork.playAnim(p, ShazamAnim.SABDA_SOUL_RIP, chest(ally));
                allies++;
            }
            p.displayClientMessage(Component.translatable("message.shazammod.aksara.ward", allies)
                    .withStyle(ChatFormatting.GREEN), true);
        });
        return true;
    }

    // ----------------------------------------------------------- R - Sabda Purna & Penghapusan

    private static boolean sabdaPurna(ServerPlayer player, State s) {
        ShazamNetwork.playAnim(player, ShazamAnim.AKSARA_PURNA);
        busy(player, s, ShazamAnim.AKSARA_PURNA_HIT + 2);
        sound(player, player.position(), ShazamSounds.AKSARA_PURNA.get(), 3.5f, 1f);
        later(player, ShazamAnim.AKSARA_PURNA_HIT, p -> {
            State st = state(p);
            st.purnaUntil = now(p) + ShazamAnim.AKSARA_PURNA_TICKS;
            shock(p, p.position().add(0, 1.0, 0), PURNA_BURST_RADIUS, PURNA_BURST_DAMAGE, 1.8, 0.6);
            msg(p, "message.shazammod.aksara.purna", ChatFormatting.GOLD, ChatFormatting.BOLD);
            ShazamNetwork.broadcastState(p);
            ShazamNetwork.sync(p);
        });
        return true;
    }

    private static boolean penghapusan(ServerPlayer player, State s) {
        if (s.inscribed != ALL_SIX && !player.isCreative()) {
            player.displayClientMessage(Component.translatable("message.shazammod.aksara.need_six",
                    Integer.bitCount(s.inscribed)).withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        ShazamNetwork.playAnim(player, ShazamAnim.AKSARA_ERASE);
        busy(player, s, ShazamAnim.AKSARA_ERASE_HIT + 10);
        // suaranya memuncak tepat di AKSARA_ERASE_HIT (lihat tools/sfx/aksara_sfx.py)
        sound(player, player.position(), ShazamSounds.AKSARA_ERASE.get(), 4.0f, 1f);
        later(player, ShazamAnim.AKSARA_ERASE_HIT, p -> {
            State st = state(p);
            Vec3 c = p.position().add(0, 1.0, 0);
            int erased = 0;
            for (LivingEntity m : enemies(p, c, ERASE_RADIUS)) {
                double d = Math.sqrt(m.distanceToSqr(c));
                float k = (float) Mth.clamp(1.0 - d / ERASE_RADIUS * 0.5, 0.5, 1.0);
                hit(p, m, ERASE_DAMAGE * k);
                if (m.isAlive() && erasable(m) && m.getHealth() < m.getMaxHealth() * ERASE_THRESHOLD) {
                    ShazamNetwork.playAnim(p, ShazamAnim.SABDA_ERASED, chest(m));
                    m.invulnerableTime = 0;
                    m.hurt(ShazamPowers.forceSource(p), m.getHealth() + 50f);
                    erased++;
                } else if (!m.isAlive()) {
                    ShazamNetwork.playAnim(p, ShazamAnim.SABDA_ERASED, chest(m));
                    erased++;
                }
                Vec3 a = away(c, m);
                m.push(a.x * 2.4, 0.8, a.z * 2.4);
                m.hurtMarked = true;
            }
            st.inscribed = 0;
            p.displayClientMessage(Component.translatable("message.shazammod.aksara.erase", erased)
                    .withStyle(ChatFormatting.WHITE, ChatFormatting.BOLD), true);
            ShazamNetwork.sync(p);
        });
        return true;
    }

    // ----------------------------------------------------------- M - Lontar Cakram / Perisai Sabda

    private static boolean lontarCakram(ServerPlayer player, State s) {
        List<LivingEntity> targets = closest(player, player.position(), DISC_RANGE, 6);
        targets.removeIf(m -> !player.hasLineOfSight(m));
        if (targets.isEmpty()) {
            msg(player, "message.shazammod.aksara.no_target", ChatFormatting.GRAY);
            return false;
        }
        ShazamNetwork.playAnim(player, ShazamAnim.AKSARA_DISCS);
        busy(player, s, ShazamAnim.AKSARA_DISCS_THROW + 2);
        sound(player, player.position(), ShazamSounds.AKSARA_DISC.get(), 1.8f, 1f);
        for (int i = 0; i < 6; i++) {
            final int sabda = i;
            final LivingEntity target = targets.get(i % targets.size());
            later(player, ShazamAnim.AKSARA_DISCS_THROW + ShazamAnim.AKSARA_DISCS_FLIGHT + i, p -> discHit(p, target, sabda));
        }
        return true;
    }

    private static void discHit(ServerPlayer player, LivingEntity m, int sabda) {
        Vec3 at = chest(m);
        // dikirim berurutan Daya..Atma: client menghitung ranah cakramnya dari urutan ini
        ShazamNetwork.playAnim(player, ShazamAnim.SABDA_DISC, at);
        if (!m.isAlive()) {
            return;
        }
        sound(player, at, ShazamSounds.AKSARA_PUNCH.get(), 0.9f, 1.1f + sabda * 0.08f);
        switch (sabda) {
            case 0 -> hit(player, m, DISC_DAMAGE * 1.5f);
            case 1 -> {
                hit(player, m, DISC_DAMAGE);
                Vec3 in = player.position().subtract(m.position());
                double d = in.length();
                if (d > 2.5) {
                    Vec3 pull = in.scale(Math.min(1.4, d * 0.15) / d);
                    m.push(pull.x, 0.3, pull.z);
                    m.hurtMarked = true;
                }
            }
            case 2 -> {
                hit(player, m, DISC_DAMAGE);
                pin(player, state(player), m, 40, false);
            }
            case 3 -> {
                hit(player, m, DISC_DAMAGE);
                m.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 40, 1), player);
            }
            case 4 -> {
                hit(player, m, DISC_DAMAGE);
                m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 2), player);
            }
            default -> {
                hit(player, m, DISC_DAMAGE);
                player.heal(12f * ShazamPowers.healScale(player));
            }
        }
    }

    private static boolean perisaiSabda(ServerPlayer player, State s) {
        ShazamNetwork.playAnim(player, ShazamAnim.AKSARA_SHIELD);
        sound(player, player.position(), ShazamSounds.AKSARA_SHIELD.get(), 1.6f, 1f);
        s.shieldUntil = now(player) + ShazamAnim.AKSARA_SHIELD_TICKS;
        msg(player, "message.shazammod.aksara.shield", ChatFormatting.LIGHT_PURPLE);
        return true;
    }

    // ----------------------------------------------------------- J - Langkah Ruang / Tulis Ulang Diri

    private static boolean langkahRuang(ServerPlayer player, State s) {
        Vec3 look = player.getViewVector(1f).normalize();
        Vec3 dir = player.getAbilities().flying ? look : flat(look);
        Vec3 dest = freeSpot(player, player.position().add(dir.scale(STEP_RANGE)), player.position());
        if (dest == null || dest.distanceToSqr(player.position()) < 2.0) {
            msg(player, "message.shazammod.aksara.blocked", ChatFormatting.GRAY);
            return false;
        }
        ShazamNetwork.playAnim(player, ShazamAnim.AKSARA_STEP, dest);
        sound(player, player.position(), ShazamSounds.AKSARA_STEP.get(), 1.3f, 1f);
        teleport(player, dest);
        s.iframesUntil = now(player) + STEP_IFRAMES;
        return true;
    }

    private static boolean tulisUlang(ServerPlayer player, State s) {
        ShazamNetwork.playAnim(player, ShazamAnim.AKSARA_SELF);
        busy(player, s, ShazamAnim.AKSARA_SELF_HIT + 2);
        sound(player, player.position(), ShazamSounds.AKSARA_WARD.get(), 1.6f, 1.3f);
        later(player, ShazamAnim.AKSARA_SELF_HIT, p -> {
            p.heal(p.getMaxHealth() * SELF_HEAL * ShazamPowers.healScale(p));
            p.clearFire();
            cleanse(p);
            msg(p, "message.shazammod.aksara.self", ChatFormatting.GOLD);
        });
        return true;
    }
}
