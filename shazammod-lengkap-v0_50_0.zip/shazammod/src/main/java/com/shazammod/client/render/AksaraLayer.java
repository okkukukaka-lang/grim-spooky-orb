package com.shazammod.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamMod;
import com.shazammod.client.fx.AksaraFx;
import com.shazammod.client.fx.ShazamRage;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;

/**
 * 0.50 Aksara (orisinal): seluruh tubuh pemain jadi automaton wayang (tekstur 256 px di tata letak UV kulit, dibuat
 * tools/textures/aksara_textures.py):
 *
 *   1) tubuh grafit hitam bergurat prada, topeng gading di muka (bagian dasar model);
 *   2) kain parang nila-prada di pinggang & paha, sabuk, kalung (lapisan luar; lapisan luar kulit asli disembunyikan);
 *   3) gurat prada yang menyala & berdenyut mengikuti Halo Sabda (makin putih-terang saat Sabda Purna & sesudah skill);
 *   4) bentuk 3D dari AksaraGeo: mahkota bilah, sumping, topeng, pelat bahu, kelat & gelang, dan halo enam Cakram Sabda.
 */
public class AksaraLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation SKIN = ShazamMod.id("textures/entity/aksara/skin.png");
    private static final ResourceLocation GLOW = ShazamMod.id("textures/entity/aksara/glow.png");
    private static final int FULLBRIGHT = 15728880;
    private static final float ARM_INFLATE = 1.04f;

    public AksaraLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    public static boolean active(AbstractClientPlayer player) {
        return !player.isInvisible() && ShazamClientState.isTransformed(player.getId())
                && ShazamClientState.isAksara(player.getId());
    }

    /** RenderPlayerEvent.Pre: lapisan luar kulit asli disembunyikan (diganti lapisan luar Aksara di render()). */
    public static void pre(AbstractClientPlayer player, PlayerModel<AbstractClientPlayer> m) {
        try {
            if (!active(player)) {
                return;
            }
            m.hat.visible = false;
            m.jacket.visible = false;
            m.rightSleeve.visible = false;
            m.leftSleeve.visible = false;
            m.rightPants.visible = false;
            m.leftPants.visible = false;
        } catch (Throwable ignored) {
            // lapisan kostum nggak boleh bikin game crash
        }
    }

    private static AksaraGeo.Look look(AbstractClientPlayer p, float pt) {
        AksaraGeo.Look look = new AksaraGeo.Look();
        look.age = p.tickCount + pt + p.getId() * 13f;
        look.purna = Mth.clamp(ShazamRage.glow(p, pt), 0f, 1f);
        look.flare = AksaraFx.flare(p, pt);
        look.discsOut = AksaraFx.discsOut(p, pt);
        for (int i = 0; i < 6; i++) {
            look.disc[i] = AksaraFx.discGlow(p, i, pt);
        }
        return look;
    }

    /** Terang gurat prada di kulit: denyut halo + Sabda Purna + kilatan skill; menyala penuh sesaat sesudah berubah. */
    private static float glow(AbstractClientPlayer p, AksaraGeo.Look look, float pt) {
        float pulse = AksaraFx.pulse(p, pt);
        float k = 0.42f + 0.25f * pulse + 0.45f * look.purna + 0.5f * look.flare;
        float reveal = ShazamCape.revealTime(p, pt);
        if (reveal >= 0f && reveal < 16f) {
            k = Math.max(k, 1.3f * (1f - reveal / 16f));
        }
        return k;
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buffers, int light, AbstractClientPlayer p, float limbSwing,
                       float limbAmount, float pt, float ageInTicks, float netHeadYaw, float headPitch) {
        try {
            if (!active(p)) {
                return;
            }
            PlayerModel<AbstractClientPlayer> m = getParentModel();
            int overlay = LivingEntityRenderer.getOverlayCoords(p, 0f);
            AksaraGeo.Look look = look(p, pt);
            // 1) tubuh grafit & topeng, lalu 2) kain, sabuk, kalung di lapisan luar
            VertexConsumer skin = buffers.getBuffer(RenderType.entityCutoutNoCull(SKIN));
            base(m.head, ps, skin, light, overlay);
            for (ModelPart[] pair : body(m)) {
                base(pair[1], ps, skin, light, overlay);
            }
            shell(m.hat, m.head, ps, skin, light, overlay);
            for (ModelPart[] pair : body(m)) {
                shell(pair[0], pair[1], ps, skin, light, overlay);
            }
            // 3) gurat prada yang menyala
            float glow = glow(p, look, pt);
            if (glow > 0.02f) {
                VertexConsumer lines = buffers.getBuffer(RenderType.eyes(GLOW));
                int c = color(look.purna > 0.3f ? 0xFFF4DC : 0xFFE0A0, glow);
                glowPart(m.head, ps, lines, c);
                for (ModelPart[] pair : body(m)) {
                    glowPart(pair[1], ps, lines, c);
                }
            }
            // 4) mahkota, topeng, perhiasan, dan halo enam cakram
            AksaraGeo.render(m.head, m.body, m.rightArm, m.leftArm, m.rightLeg, m.leftLeg, ps, buffers, light, overlay, look);
        } catch (Throwable ignored) {
            // lapisan kostum nggak boleh bikin game crash
        }
    }

    /** Tangan orang pertama: lengan grafit bergurat prada, kelat bahu, gelang, pelat bahu. */
    public static void firstPersonArm(PoseStack ps, MultiBufferSource buffers, int light, AbstractClientPlayer p, HumanoidArm arm) {
        try {
            if (!active(p)) {
                return;
            }
            Minecraft mc = Minecraft.getInstance();
            if (!(mc.getEntityRenderDispatcher().getRenderer(p) instanceof PlayerRenderer renderer)) {
                return;
            }
            PlayerModel<AbstractClientPlayer> m = renderer.getModel();
            boolean right = arm == HumanoidArm.RIGHT;
            ModelPart base = right ? m.rightArm : m.leftArm;
            ModelPart sleeve = right ? m.rightSleeve : m.leftSleeve;
            m.attackTime = 0f;
            m.crouching = false;
            m.swimAmount = 0f;
            m.setupAnim(p, 0f, 0f, 0f, 0f, 0f);
            base.xRot = 0f;
            sleeve.xRot = 0f;
            float pt = mc.getTimer().getGameTimeDeltaPartialTick(false);
            AksaraGeo.Look look = look(p, pt);
            VertexConsumer skin = buffers.getBuffer(RenderType.entityCutoutNoCull(SKIN));
            scaled(base, ps, skin, light, 0xFFFFFFFF, ARM_INFLATE);
            scaled(sleeve, ps, skin, light, 0xFFFFFFFF, ARM_INFLATE * 1.02f);
            scaled(base, ps, buffers.getBuffer(RenderType.eyes(GLOW)), FULLBRIGHT,
                    color(look.purna > 0.3f ? 0xFFF4DC : 0xFFE0A0, glow(p, look, pt)), ARM_INFLATE);
            base.xScale = ARM_INFLATE;
            base.yScale = ARM_INFLATE;
            base.zScale = ARM_INFLATE;
            AksaraGeo.renderArm(base, !right, ps, buffers, light);
            base.xScale = 1f;
            base.yScale = 1f;
            base.zScale = 1f;
        } catch (Throwable ignored) {
            // tangan orang pertama nggak boleh bikin game crash
        }
    }

    /** Badan, lengan, kaki: {lapisan luar, bagian dasar}. */
    private static ModelPart[][] body(PlayerModel<AbstractClientPlayer> m) {
        return new ModelPart[][] {{m.jacket, m.body}, {m.rightSleeve, m.rightArm}, {m.leftSleeve, m.leftArm},
                {m.rightPants, m.rightLeg}, {m.leftPants, m.leftLeg}};
    }

    private static void base(ModelPart part, PoseStack ps, VertexConsumer vc, int light, int overlay) {
        if (part != null && part.visible) {
            part.render(ps, vc, light, overlay, 0xFFFFFFFF);
        }
    }

    private static void glowPart(ModelPart part, PoseStack ps, VertexConsumer vc, int color) {
        if (part != null && part.visible) {
            part.render(ps, vc, FULLBRIGHT, OverlayTexture.NO_OVERLAY, color);
        }
    }

    /** Lapisan luar dipaksa terlihat (di pre() disembunyikan supaya kulit asli pemain nggak ikut digambar). */
    private static void shell(ModelPart outer, ModelPart base, PoseStack ps, VertexConsumer vc, int light, int overlay) {
        if (outer == null || base == null || !base.visible) {
            return;
        }
        boolean visible = outer.visible;
        outer.visible = true;
        outer.render(ps, vc, light, overlay, 0xFFFFFFFF);
        outer.visible = visible;
    }

    private static void scaled(ModelPart part, PoseStack ps, VertexConsumer vc, int light, int color, float scale) {
        if (part == null) {
            return;
        }
        boolean visible = part.visible;
        part.visible = true;
        part.xScale = scale;
        part.yScale = scale;
        part.zScale = scale;
        part.render(ps, vc, light, OverlayTexture.NO_OVERLAY, color);
        part.xScale = 1f;
        part.yScale = 1f;
        part.zScale = 1f;
        part.visible = visible;
    }

    /** Warna cahaya aditif: kekuatan dikalikan ke RGB (jenis render "eyes" mengabaikan alpha). */
    private static int color(int rgb, float k) {
        k = Mth.clamp(k, 0f, 1f);
        int r = (int) (((rgb >> 16) & 255) * k);
        int g = (int) (((rgb >> 8) & 255) * k);
        int b = (int) ((rgb & 255) * k);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }
}
