package com.shazammod.client.render;

import com.shazammod.AksaraSkills;
import com.shazammod.ShazamMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.shazammod.client.vfx.Draw;

import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * 0.50 Bentuk 3D Aksara (orisinal), menempel pada bagian badan model pemain (ikut gerak & putarannya), memakai alat gambar
 * titik Helion3Geo.Out. Angka dalam piksel model (1/16 blok) di ruang bagian badannya.
 *
 *   kepala  : topeng gading tanpa wajah (celah mata menyala, garis prada tegak di tengah), pita mahkota prada, tujuh
 *             bilah mahkota yang mengipas (paling tinggi di tengah), sumping melengkung di kedua pelipis, permata dahi
 *   badan   : kalung bulan sabit prada, permata aksara di dada, sabuk prada, kain uncal menggantung di depan, dan
 *             HALO: enam Cakram Sabda mengorbit di punggung (tiap cakram satu warna ranah), makin besar & cepat saat
 *             Sabda Purna, padam sebentar saat dilempar (Lontar Cakram)
 *   lengan  : pelat bahu gelap bertepi prada, kelat bahu, gelang pergelangan
 *   kaki    : gelang kaki prada
 */
public final class AksaraGeo {
    public static final ResourceLocation GOLD = ShazamMod.id("textures/entity/aksara/gold.png");
    public static final ResourceLocation PLATE = ShazamMod.id("textures/entity/aksara/plate.png");
    private static final int FULLBRIGHT = 15728880;
    private static final int IVORY = 0xF1E6D2, GRAPHITE = 0x2B2A36, BRONZE = 0x5C4A34;
    private static final int GOLD_GLOW = 0xFFD27A, PURNA_GLOW = 0xFFF6E0;

    private AksaraGeo() {}

    /** Keadaan halo & cahaya yang dihitung AksaraLayer dari AksaraFx (per pemain, per frame). */
    public static final class Look {
        public float age;          // waktu (tick + pt)
        public float purna;        // 0..1 Sabda Purna
        public float flare;        // 0..1 kilatan sesudah skill
        public float discsOut;     // 0..1 cakram sedang dilempar (halo kosong)
        public final float[] disc = new float[6];   // 0..1 terang tiap cakram
    }

    // ------------------------------------------------------------------ bentuk

    /** Topeng gading menutup muka (z = -4), dengan tonjolan hidung tipis. */
    private static void mask(Helion3Geo.Out o) {
        o.slab(0f, -4.05f, -4.18f, 3.75f, 0f, 0f, 0f, 3.8f, 0f, 0f, 0f, 0.2f);
        o.prism(0f, -5.4f, -4.38f, 0f, -2.6f, -4.62f, 0.32f, 0.22f, 0.3f, 0.6f, true);
        o.slab(0f, -0.55f, -4.15f, 2.6f, 0f, 0f, 0f, 0.45f, 0.05f, 0f, -0.05f, 0.22f);   // dagu
    }

    /** Pita & bilah mahkota, sumping, plat dahi (prada). */
    private static void crown(Helion3Geo.Out o) {
        o.slab(0f, -7.05f, 0f, 4.32f, 0f, 0f, 0f, 0.42f, 0f, 0f, 0f, 4.32f);             // pita mahkota
        o.slab(0f, -8.45f, -4.2f, 2.5f, 0f, 0f, 0f, 1.45f, 0.08f, 0f, -0.12f, 0.26f);     // jamang (plat dahi)
        for (int i = -3; i <= 3; i++) {                                                   // tujuh bilah mengipas
            float x = i * 1.05f;
            float h = 6.6f - Math.abs(i) * 1.15f;
            float z = -3.2f + Math.abs(i) * 0.45f;
            o.prism(x, -7.4f, z, x * 1.32f, -7.4f - h, z + 1.2f + Math.abs(i) * 0.3f, 0.42f, 0f, 1f, 0f, false);
        }
        for (int i = -2; i <= 2; i++) {                                                   // bilah belakang yang pendek
            float x = i * 1.5f;
            o.prism(x, -7.4f, 3.4f, x * 1.2f, -10.4f + Math.abs(i) * 0.6f, 4.6f, 0.36f, 0f, 1f, 0f, false);
        }
        for (int s = -1; s <= 1; s += 2) {                                                // sumping melengkung
            o.curve(4.15f * s, -4.6f, 0.2f, 6.6f * s, -6.2f, 1.8f, 5.6f * s, -9.6f, 4.6f, 0.62f, 5);
            o.curve(4.15f * s, -3.4f, 0.8f, 5.6f * s, -3.0f, 2.6f, 5.0f * s, -5.2f, 4.8f, 0.42f, 4);
        }
    }

    /** Kalung bulan sabit, sabuk, uncal (prada). */
    private static void bodyGold(Helion3Geo.Out o) {
        for (int s = -1; s <= 1; s += 2) {
            o.prism(0.4f * s, 1.6f, -2.32f, 3.6f * s, 0.4f, -2.12f, 0.42f, 0.3f, 0.9f, 0.4f, true);   // kalung
            o.prism(0.6f * s, 2.6f, -2.3f, 2.4f * s, 1.9f, -2.2f, 0.26f, 0.18f, 0.9f, 0.4f, true);
        }
        o.slab(0f, 11.25f, 0f, 4.3f, 0f, 0f, 0f, 0.55f, 0f, 0f, 0f, 2.3f);                // sabuk
        o.slab(0f, 11.25f, -2.4f, 1.1f, 0f, 0f, 0f, 0.95f, 0f, 0f, 0f, 0.2f);              // timang (gesper)
        o.slab(0f, 14.6f, -2.42f, 1.25f, 0f, 0f, 0f, 2.6f, 0f, 0f, -0.06f, 0.12f);         // uncal
        o.slab(0f, 18.0f, -2.48f, 0.8f, 0f, 0f, 0f, 1.0f, 0f, 0f, -0.04f, 0.1f);
        o.gem(0f, 19.4f, -2.5f, 0.55f, 0.75f, 0.3f);
        // dudukan halo di punggung
        o.slab(0f, 3.0f, 2.25f, 1.1f, 0f, 0f, 0f, 1.1f, 0f, 0f, 0f, 0.3f);
        o.prism(0f, 3.0f, 2.4f, 0f, 3.0f, 4.6f, 0.28f, 0.2f, 0.9f, 0.4f, true);
    }

    /** Lengan kanan: kelat bahu & gelang (prada). Kiri: cermin. */
    private static void armGold(Helion3Geo.Out o) {
        o.slab(-1f, 1.2f, 0f, 2.25f, 0f, 0f, 0f, 0.45f, 0f, 0f, 0f, 2.25f);               // kelat bahu
        o.slab(-3.25f, 1.2f, 0f, 0.2f, 0f, 0f, 0f, 1.1f, 0f, 0f, 0f, 0.9f);                // hiasan kelat
        o.slab(-1f, 8.7f, 0f, 2.2f, 0f, 0f, 0f, 0.5f, 0f, 0f, 0f, 2.2f);                  // gelang
        o.slab(-1.4f, -2.25f, 0f, 2.55f, -0.5f, 0f, 0.12f, 0.16f, 0f, 0f, 0f, 2.55f);      // tepi pelat bahu
    }

    /** Pelat bahu gelap. */
    private static void armPlate(Helion3Geo.Out o) {
        o.slab(-1.45f, -2.6f, 0f, 2.45f, -0.5f, 0f, 0.15f, 0.55f, 0f, 0f, 0f, 2.42f);
    }

    private static void legGold(Helion3Geo.Out o) {
        o.slab(0f, 10.9f, 0f, 2.18f, 0f, 0f, 0f, 0.4f, 0f, 0f, 0f, 2.18f);
    }

    // ------------------------------------------------------------------ halo

    private static final int DISC_SIDES = 12;

    /** Satu cakram pipih menghadap ke belakang (normal +z) di (cx, cy, cz), diputar spin radian di bidangnya. */
    private static void disc(Helion3Geo.Out o, float cx, float cy, float cz, float r, float thick, float spin) {
        float z0 = cz - thick * 0.5f, z1 = cz + thick * 0.5f;
        for (int i = 0; i < DISC_SIDES; i++) {
            float a0 = spin + i * Mth.TWO_PI / DISC_SIDES, a1 = spin + (i + 1) * Mth.TWO_PI / DISC_SIDES;
            float x0 = cx + Mth.cos(a0) * r, y0 = cy + Mth.sin(a0) * r;
            float x1 = cx + Mth.cos(a1) * r, y1 = cy + Mth.sin(a1) * r;
            o.quad(cx, cy, z1, x0, y0, z1, x1, y1, z1, cx, cy, z1, cx, cy, cz, 0.5f, 0.5f, 1f, 1f);   // muka belakang
            o.quad(cx, cy, z0, x1, y1, z0, x0, y0, z0, cx, cy, z0, cx, cy, cz, 0.5f, 0.5f, 1f, 1f);   // muka depan
            o.quad(x0, y0, z0, x1, y1, z0, x1, y1, z1, x0, y0, z1, cx, cy, cz, 0f, 0f, 1f, 0.25f);    // tepi
        }
    }

    /** Bingkai cakram: cincin pipih (prada) di tepi, sedikit lebih tebal dari badan cakram. */
    private static void rim(Helion3Geo.Out o, float cx, float cy, float cz, float r, float width, float thick, float spin) {
        float z0 = cz - thick * 0.5f, z1 = cz + thick * 0.5f;
        float ri = r - width;
        for (int i = 0; i < DISC_SIDES; i++) {
            float a0 = spin + i * Mth.TWO_PI / DISC_SIDES, a1 = spin + (i + 1) * Mth.TWO_PI / DISC_SIDES;
            float c0 = Mth.cos(a0), s0 = Mth.sin(a0), c1 = Mth.cos(a1), s1 = Mth.sin(a1);
            o.quad(cx + c0 * ri, cy + s0 * ri, z1, cx + c0 * r, cy + s0 * r, z1, cx + c1 * r, cy + s1 * r, z1,
                    cx + c1 * ri, cy + s1 * ri, z1, cx, cy, cz, 0f, 0f, 1f, 1f);
            o.quad(cx + c1 * ri, cy + s1 * ri, z0, cx + c1 * r, cy + s1 * r, z0, cx + c0 * r, cy + s0 * r, z0,
                    cx + c0 * ri, cy + s0 * ri, z0, cx, cy, cz, 0f, 0f, 1f, 1f);
            o.quad(cx + c0 * r, cy + s0 * r, z0, cx + c1 * r, cy + s1 * r, z0, cx + c1 * r, cy + s1 * r, z1,
                    cx + c0 * r, cy + s0 * r, z1, cx, cy, cz, 0f, 0f, 1f, 1f);
        }
    }

    /** Aksara bercahaya di muka cakram: bintang enam sudut tipis + titik tengah (di depan & belakang). */
    private static void glyph(Helion3Geo.Out o, float cx, float cy, float cz, float r, float spin, float side) {
        float z = cz + side;
        float w = r * 0.12f;
        for (int k = 0; k < 6; k++) {
            float a = spin * -1.6f + k * Mth.TWO_PI / 6f;
            float b = a + Mth.TWO_PI / 3f;
            float ax = cx + Mth.cos(a) * r * 0.72f, ay = cy + Mth.sin(a) * r * 0.72f;
            float bx = cx + Mth.cos(b) * r * 0.72f, by = cy + Mth.sin(b) * r * 0.72f;
            float nx = -(by - ay), ny = bx - ax;
            float nl = Mth.sqrt(nx * nx + ny * ny) + 1.0E-5f;
            nx = nx / nl * w;
            ny = ny / nl * w;
            o.quad(ax - nx, ay - ny, z, bx - nx, by - ny, z, bx + nx, by + ny, z, ax + nx, ay + ny, z,
                    cx, cy, cz, 0f, 0f, 1f, 1f);
        }
        float c = r * 0.2f;
        o.quad(cx - c, cy, z, cx, cy - c, z, cx + c, cy, z, cx, cy + c, z, cx, cy, cz, 0f, 0f, 1f, 1f);
    }

    /** Titik pusat cakram ke-i di ruang badan. */
    private static float[] discCenter(int i, Look look) {
        float orbit = 7.6f + 1.6f * look.purna;
        float speed = 0.012f + 0.03f * look.purna;
        float a = look.age * speed + i * Mth.TWO_PI / 6f + Mth.HALF_PI;
        float bob = Mth.sin(look.age * 0.09f + i) * 0.35f;
        return new float[] {Mth.cos(a) * orbit, 3.0f - Mth.sin(a) * orbit + bob, 6.4f + 0.6f * look.purna};
    }

    private static float discRadius(Look look) {
        return 2.05f + 0.75f * look.purna;
    }

    // ------------------------------------------------------------------ gambar

    /** Semua bagian 3D di badan (sesudah kulit & cahaya kulit digambar AksaraLayer). */
    public static void render(ModelPart head, ModelPart body, ModelPart rightArm, ModelPart leftArm, ModelPart rightLeg,
                              ModelPart leftLeg, PoseStack ps, MultiBufferSource buffers, int light, int overlay, Look look) {
        Helion3Geo.Out o = new Helion3Geo.Out();
        o.light = light;
        o.overlay = overlay;
        boolean halo = look.discsOut < 0.5f;
        // 1) prada (tekstur emas)
        o.vc = buffers.getBuffer(RenderType.entityCutoutNoCull(GOLD));
        Helion3Geo.tint(o, 0xFFFFFF, 1f);
        Helion3Geo.part(head, ps, o, 1f, AksaraGeo::crown);
        Helion3Geo.part(body, ps, o, 1f, AksaraGeo::bodyGold);
        Helion3Geo.part(rightArm, ps, o, 1f, AksaraGeo::armGold);
        Helion3Geo.part(leftArm, ps, o, -1f, AksaraGeo::armGold);
        Helion3Geo.part(rightLeg, ps, o, 1f, AksaraGeo::legGold);
        Helion3Geo.part(leftLeg, ps, o, -1f, AksaraGeo::legGold);
        if (halo) {
            float r = discRadius(look);
            Helion3Geo.part(body, ps, o, 1f, out -> {
                for (int i = 0; i < 6; i++) {
                    float[] c = discCenter(i, look);
                    rim(out, c[0], c[1], c[2], r, 0.42f, 0.62f, look.age * 0.05f + i);
                }
            });
        }
        // 2) topeng gading, pelat bahu grafit, badan cakram perunggu (satu tekstur, beda warna)
        o.vc = buffers.getBuffer(RenderType.entityCutoutNoCull(PLATE));
        Helion3Geo.tint(o, IVORY, 1f);
        Helion3Geo.part(head, ps, o, 1f, AksaraGeo::mask);
        Helion3Geo.tint(o, GRAPHITE, 1f);
        Helion3Geo.part(rightArm, ps, o, 1f, AksaraGeo::armPlate);
        Helion3Geo.part(leftArm, ps, o, -1f, AksaraGeo::armPlate);
        if (halo) {
            Helion3Geo.tint(o, BRONZE, 1f);
            float r = discRadius(look) - 0.3f;
            Helion3Geo.part(body, ps, o, 1f, out -> {
                for (int i = 0; i < 6; i++) {
                    float[] c = discCenter(i, look);
                    disc(out, c[0], c[1], c[2], r, 0.4f, look.age * 0.05f + i);
                }
            });
        }
        // 3) cahaya: aksara di tiap cakram (warna ranahnya), celah mata, permata dahi & dada
        o.vc = buffers.getBuffer(RenderType.eyes(Draw.WHITE));
        o.light = FULLBRIGHT;
        o.overlay = OverlayTexture.NO_OVERLAY;
        float hot = Mth.clamp(0.55f + 0.45f * look.purna + 0.5f * look.flare, 0f, 1f);
        Helion3Geo.tint(o, look.purna > 0.3f ? PURNA_GLOW : GOLD_GLOW, hot);
        Helion3Geo.part(head, ps, o, 1f, out -> {
            out.slab(-1.55f, -4.45f, -4.42f, 0.95f, 0f, 0f, 0f, 0.17f, 0f, 0f, 0f, 0.05f);   // celah mata
            out.slab(1.55f, -4.45f, -4.42f, 0.95f, 0f, 0f, 0f, 0.17f, 0f, 0f, 0f, 0.05f);
            out.slab(0f, -2.3f, -4.42f, 0.09f, 0f, 0f, 0f, 1.75f, 0f, 0f, 0f, 0.04f);        // garis prada tegak
            out.gem(0f, -8.5f, -4.55f, 0.55f, 0.7f, 0.3f);                                   // permata dahi
        });
        Helion3Geo.part(body, ps, o, 1f, out -> out.gem(0f, 3.4f, -2.45f, 0.85f, 1.05f, 0.4f));   // permata dada
        if (halo) {
            float r = discRadius(look);
            float fade = 1f - look.discsOut * 2f;
            for (int i = 0; i < 6; i++) {
                final int k = i;
                float glow = Mth.clamp((0.35f + 0.65f * look.disc[i]) * fade, 0f, 1f);
                if (glow < 0.02f) {
                    continue;
                }
                Helion3Geo.tint(o, AksaraSkills.RGB[i], glow);
                Helion3Geo.part(body, ps, o, 1f, out -> {
                    float[] c = discCenter(k, look);
                    float spin = look.age * 0.05f + k;
                    glyph(out, c[0], c[1], c[2], r - 0.5f, spin, 0.24f);
                    glyph(out, c[0], c[1], c[2], r - 0.5f, spin, -0.24f);
                });
            }
            if (look.purna > 0.05f) {   // Sabda Purna: tali cahaya putih-emas menghubungkan keenam cakram
                Helion3Geo.tint(o, PURNA_GLOW, look.purna * 0.8f);
                Helion3Geo.part(body, ps, o, 1f, out -> {
                    for (int i = 0; i < 6; i++) {
                        float[] a = discCenter(i, look), b = discCenter((i + 1) % 6, look);
                        out.prism(a[0], a[1], a[2], b[0], b[1], b[2], 0.14f, 0.14f, 0f, 1f, false);
                    }
                });
            }
        }
    }

    /** Lengan orang pertama: kelat bahu, gelang, pelat bahu. */
    public static void renderArm(ModelPart arm, boolean left, PoseStack ps, MultiBufferSource buffers, int light) {
        Helion3Geo.Out o = new Helion3Geo.Out();
        o.light = light;
        o.overlay = OverlayTexture.NO_OVERLAY;
        float sx = left ? -1f : 1f;
        o.vc = buffers.getBuffer(RenderType.entityCutoutNoCull(GOLD));
        Helion3Geo.tint(o, 0xFFFFFF, 1f);
        Helion3Geo.part(arm, ps, o, sx, AksaraGeo::armGold);
        o.vc = buffers.getBuffer(RenderType.entityCutoutNoCull(PLATE));
        Helion3Geo.tint(o, GRAPHITE, 1f);
        Helion3Geo.part(arm, ps, o, sx, AksaraGeo::armPlate);
    }
}
