package com.shazammod;

/**
 * Juara yang dipilih pemain. Semuanya berubah dengan kata ajaibnya sendiri, tapi kekuatannya dari sumber yang beda:
 *
 * SHAZAM     : Solomon, Hercules, Atlas, Zeus, Achilles, Mercury (jubah putih, petir emas). Kata: SHAZAM.
 * BLACK_ADAM : Shu, Heru, Amon, Zehuti, Aton, Mehen - dewa-dewa Mesir, juara Kahndaq (jubah hitam, petir emas-jingga).
 *              Kata: SHAZAM.
 * SABBAC     : 0.30 - Satan, Aym, Belial, Beelzebub, Asmodeus, Crateis - enam iblis, juara neraka (jubah merah darah,
 *              tanduk, petir neraka merah-hitam yang menyembur dari bawah tanah). Kata: SABBAC.
 *
 * LINTANG    : 0.32 - juara bintang (orisinal): tubuhnya menyimpan cahaya matahari & bintang (jubah biru toska tua,
 *              list platina, lambang matahari delapan sinar). Kata: LINTANG.
 *
 * HELION     : 0.43 - Projek Helion-6 (radiasi Batu Cryon, lemah di bawah matahari). Tanpa kata ajaib: tombol Transformasi.
 * HELION3    : 0.49 - Subjek Tiga (Helion-3) yang bisa dimainkan: raksasa sel mati yang beradaptasi, tumbuh duri tulang,
 *              dan bangkit lagi sesudah tumbang. Tanpa kata ajaib: tombol Transformasi.
 * AKSARA     : 0.50 - Aksara, Sang Penulis Ulang (orisinal): automaton wayang hitam-prada dengan enam Cakram Sabda di
 *              punggungnya. Tiap cakram satu ranah: Daya, Ruang, Benak, Maya, Kala, Atma. Kata: AKSARA.
 *
 * Urutannya dipakai sebagai id di save dan di jaringan, jadi tambah yang baru di paling bawah.
 */
public enum ShazamForm {
    SHAZAM("shazam"),
    BLACK_ADAM("black_adam"),
    SABBAC("sabbac"),
    LINTANG("lintang"),   // 0.32
    HELION("helion"),     // 0.43 Projek Helion-6 (radiasi Batu Cryon, lemah di bawah matahari)
    HELION3("helion3"),   // 0.49 Subjek Tiga yang bisa dimainkan (adaptasi, duri tulang, bangkit lagi)
    AKSARA("aksara");     // 0.50 Aksara, Sang Penulis Ulang (enam Sabda: Daya, Ruang, Benak, Maya, Kala, Atma)

    public final String id;

    ShazamForm(String id) {
        this.id = id;
    }

    public static ShazamForm byId(int id) {
        ShazamForm[] values = values();
        return id >= 0 && id < values.length ? values[id] : SHAZAM;
    }

    public static ShazamForm byName(String name) {
        for (ShazamForm form : values()) {
            if (form.id.equals(name)) {
                return form;
            }
        }
        return null;
    }

    /** Juara berikutnya (tombol ganti juara). */
    public ShazamForm next() {
        ShazamForm[] values = values();
        return values[(ordinal() + 1) % values.length];
    }

    /** Jenis petir sihir (lihat MagicBolt): 0 = emas Shazam, 1 = emas-jingga Black Adam, 2 = petir neraka Sabbac. */
    public int boltVariant() {
        return switch (this) {
            case BLACK_ADAM -> 1;
            case SABBAC -> 2;
            case LINTANG -> 3;   // 0.32 tiang cahaya matahari
            default -> 0;
        };
    }

    /** Kata ajaib yang diucapkan untuk berubah (dan untuk balik jadi manusia). */
    public String magicWord() {
        return switch (this) {
            case SABBAC -> "sabbac";
            case LINTANG -> "lintang";
            case HELION -> "helion";
            case HELION3 -> "helion3";
            case AKSARA -> "aksara";   // 0.50
            default -> "shazam";
        };
    }
}
