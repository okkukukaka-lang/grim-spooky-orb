"""SFX Aksara, Sang Penulis Ulang (0.50). Dibuat dari nol dengan alat yang sama dengan synth.py.

    python3 tools/sfx/aksara_sfx.py src/main/resources/assets/shazammod/sounds [nama ...]

Ciri suaranya: logam gamelan (gong & bonang dengan "ombak", dua nada yang sedikit berselisih sehingga berdenyut), paduan
suara yang tenang, denting aksara yang tinggi, dan tiap ranah punya satu nada sendiri dari tangga lima nada (Daya paling
rendah .. Atma paling tinggi, Purna = akor semuanya). Waktu puncak dikunci ke tick animasi (lihat ShazamAnim.AKSARA_*):

    aksara_transform  cakram mengunci di 2,2 dtk (AKSARA_MORPH_BURST 44)
    aksara_beam       sinar mulai 0,4 dtk (AKSARA_BEAM_WINDUP 8), selesai 2,0 dtk
    aksara_nova       meledak di 1,1 dtk (AKSARA_NOVA_WINDUP 22)
    aksara_fold       jentikan di 0,25 dtk (AKSARA_FOLD_SNAP 5)
    aksara_gate       terbuka di 0,5 dtk (AKSARA_GATE_OPEN 10)
    aksara_lance      menusuk di 0,45 dtk (AKSARA_LANCE_HIT 9)
    aksara_dominion   gelombang di 0,9 dtk (AKSARA_DOMINION_HIT 18)
    aksara_rewrite    kenyataan pecah di 0,8 dtk (AKSARA_REWRITE_HIT 16)
    aksara_timestop   waktu berhenti di 0,6 dtk (AKSARA_TIMESTOP_HIT 12)
    aksara_rewind     tiba di 0,5 dtk (AKSARA_REWIND_HIT 10)
    aksara_soul       jiwa dicabut di 2,4 dtk (AKSARA_SOUL_RIP 48)
    aksara_ward       mekar di 0,6 dtk (AKSARA_WARD_HIT 12)
    aksara_purna      meledak di 1,7 dtk (AKSARA_PURNA_HIT 34)
    aksara_erase      menghapus di 3,2 dtk (AKSARA_ERASE_HIT 64)
    aksara_rite       menyatu di 7,5 dtk (AKSARA_RITE_BURST 150), aksara menggurat 2,5-5,5 dtk
Putar di pitch 1 supaya puncaknya nggak bergeser.
"""
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
_argv = sys.argv
sys.argv = [sys.argv[0]]          # synth.py membaca sys.argv[1] sebagai folder keluaran saat diimpor
import synth as s                 # noqa: E402
sys.argv = _argv

SR = s.SR
# tangga lima nada (mirip slendro, dari 196 Hz): satu nada per ranah, Daya .. Atma
SCALE = [196.0, 225.3, 259.2, 298.0, 342.7, 392.0]


# ------------------------------------------------------------------ alat bantu

def gong(f, dur, rng, tau=1.6, beat=2.2, bright=1.0):
    """Gong gamelan: parsial inharmonik + 'ombak' (dua salinan berselisih beat Hz) + dentum lembut di awal."""
    partials = ((1.0, 1.0), (2.0, 0.32 * bright), (2.76, 0.22 * bright), (4.07, 0.12 * bright), (5.43, 0.07 * bright))
    a = s.bell(f, dur, rng, partials, tau, 0.002)
    b = s.bell(f + beat, dur, rng, partials, tau, 0.002)
    n = int(dur * SR)
    knock = s.bp(s.pink(int(0.06 * SR), rng), 120, 900, 2) * s.env_exp(int(0.06 * SR), 0.015) * 0.4
    return s.mix(a * 0.6 + b * 0.6, knock)[:n]


def bonang(f, dur, rng, tau=0.45):
    """Bonang / kenong kecil: denting logam pendek berombak."""
    partials = ((1.0, 1.0), (1.51, 0.35), (2.42, 0.25), (3.13, 0.12), (4.9, 0.06))
    a = s.bell(f, dur, rng, partials, tau, 0.002)
    b = s.bell(f * 1.006, dur, rng, partials, tau, 0.002)
    return (a + b) * 0.55


def chime(f, dur, rng, tau=0.35):
    """Denting aksara: lonceng kaca tinggi."""
    return s.bell(f, dur, rng, ((1, 1), (2.32, 0.45), (4.25, 0.25), (6.8, 0.12)), tau, 0.003)


def shimmer(dur, rng, lo=3000, hi=11000, amp=0.4):
    n = int(dur * SR)
    return s.bp(s.white(n, rng), lo, hi, 2) * s.env_exp(n, dur / 3) * amp


def pad(freqs, dur, rng, vowel="a", attack=0.4, release=0.6):
    y = s.choir(freqs, dur, rng, vowel)
    env = s.env_adsr(dur, attack, 0.2, 0.8, release)
    return y * env * 0.12


def swell(dur, rng, lo=500, hi=9000):
    return s.reverse_swell(dur, rng, lo, hi)


def whoosh(dur, rng, f0=300.0, fpk=1800.0, f1=500.0, peak=0.55):
    return s.air_whoosh(dur, rng, f0, fpk, f1, 1.1, peak)


def tone(f, dur, kind="sine"):
    return s.osc(f, dur, kind)


def env_hit(dur, tau):
    return s.env_exp(int(dur * SR), tau)


def place(total, *items):
    """items: (detik, sinyal) -> satu sinyal sepanjang total detik."""
    out = np.zeros(int(total * SR))
    for sec, x in items:
        i = int(sec * SR)
        if i >= len(out):
            continue
        e = min(len(out), i + len(x))
        out[i:e] += x[:e - i]
    return out


def tape(x, f0=1.0, f1=0.25):
    """Pita yang melambat: nada & tempo turun bersamaan (resample dengan kecepatan yang berubah)."""
    n = len(x)
    speed = np.geomspace(f0, f1, n)
    pos = np.cumsum(speed)
    pos = pos[pos < n - 1]
    return np.interp(pos, np.arange(n), x)


# ------------------------------------------------------------------ resep

def aksara_transform(rng, v):
    total, hit = 3.6, 2.2
    parts = []
    for i in range(6):                         # enam cakram datang satu per satu (nada ranahnya)
        t = 0.3 + i * 0.2 + (hit - 0.3 - i * 0.2) * 0.85
        parts.append((t, bonang(SCALE[i] * 2, 0.9, rng) * 0.5))
        parts.append((t - 0.25, whoosh(0.35, rng, 600, 2600, 900, 0.8) * 0.25))
    parts.append((0.0, pad([SCALE[0], SCALE[2], SCALE[4]], hit, rng, "o", 1.4, 0.2)))
    parts.append((hit - 1.4, swell(1.4, rng) * 0.6))
    parts.append((hit, gong(SCALE[0] / 2, 3.0, rng, 2.2, 1.6) * 1.3))
    parts.append((hit, s.thump(rng, 70, 32, 1.6, 0.4, 0.8, 0.5)))
    parts.append((hit, shimmer(1.2, rng, amp=0.5)))
    parts.append((hit, pad([SCALE[0], SCALE[2], SCALE[4], SCALE[5] * 2], 1.3, rng, "a", 0.01, 1.0) * 1.4))
    return s.reverb(place(total, *parts), 2.6, 0.32, rng=rng)


def aksara_revert(rng, v):
    parts = [(i * 0.09, bonang(SCALE[5 - i] * 2, 0.6, rng) * 0.4) for i in range(6)]
    parts.append((0.0, whoosh(0.9, rng, 1800, 900, 200, 0.2) * 0.5))
    return s.reverb(place(1.6, *parts), 1.8, 0.3, rng=rng)


def aksara_pulse(rng, v):
    start = v * 2
    parts = [(i * 0.07, bonang(SCALE[(start + i) % 6] * 4, 0.45, rng, 0.25) * 0.25) for i in range(6)]
    t = s.t_axis(0.9)
    hum = (tone(SCALE[0], 0.9) + tone(SCALE[0] * 1.5, 0.9) * 0.5) * np.minimum(1, t / 0.05) * np.exp(-t / 0.35) * 0.18
    parts.append((0.0, hum))
    return s.reverb(place(1.1, *parts), 1.2, 0.25, rng=rng)


def aksara_punch(rng, v):
    f = SCALE[(v * 3) % 6] * 4
    hit = s.thump(rng, 120, 60, 0.35, 0.08, 0.6, 0.6) * 0.9
    return s.reverb(place(0.6, (0.0, hit), (0.0, chime(f, 0.5, rng, 0.18) * 0.45), (0.0, shimmer(0.25, rng, amp=0.25))),
                    0.8, 0.18, rng=rng)


def aksara_sixfold(rng, v):
    chord = sum(bonang(f * 2, 1.4, rng, 0.6) for f in SCALE) * 0.28
    hit = s.thump(rng, 90, 36, 1.0, 0.25, 0.9, 0.7) * 1.2
    noise = s.bp(s.white(int(0.4 * SR), rng), 400, 7000, 2) * env_hit(0.4, 0.06) * 0.6
    return s.reverb(place(1.6, (0.0, hit), (0.0, chord), (0.0, noise), (0.0, shimmer(0.8, rng, amp=0.4))), 1.6, 0.3, rng=rng)


def aksara_beam(rng, v):
    total, start, end = 2.6, 0.4, 2.0
    charge = s.osc(np.geomspace(180, 900, int(start * SR)), start, "saw")
    charge = s.lp(charge, 2500) * np.linspace(0, 1, len(charge)) ** 2 * 0.4
    dur = end - start
    m = int(dur * SR)
    tt = np.arange(m) / SR
    body = (s.osc(98 * (1 + 0.01 * np.sin(2 * np.pi * 7 * tt)), dur, "saw") + s.osc(147, dur, "saw") * 0.6
            + s.osc(196.5, dur, "saw") * 0.4)
    body = s.lp(body, 1600) * 0.35
    hiss = s.bp(s.white(m, rng), 2000, 9000, 2) * (0.25 + 0.1 * np.sin(2 * np.pi * 11 * tt))
    sing = np.sin(2 * np.pi * np.cumsum(784 * (1 + 0.004 * np.sin(2 * np.pi * 5.5 * tt))) / SR) * 0.12
    env = np.minimum(1, tt / 0.03) * np.minimum(1, (dur - tt) / 0.08)
    beam = (body + hiss + sing) * env
    blast = s.thump(rng, 110, 40, 0.6, 0.15, 0.7, 0.5)
    y = place(total, (0.0, charge), (start, beam), (start, s.thump(rng, 140, 70, 0.3, 0.06, 0.5, 0.5) * 0.7),
              (end - 0.05, blast), (end - 0.05, gong(SCALE[0], 0.6, rng, 0.4) * 0.4))
    return s.reverb(y, 1.4, 0.22, rng=rng)


def aksara_nova(rng, v):
    total, hit = 3.0, 1.1
    gather = swell(hit, rng, 300, 9000) * 0.7
    tt = s.t_axis(hit)
    rise = s.osc(np.geomspace(60, 240, len(tt)), hit, "saw")
    rise = s.lp(rise, 1200) * (tt / hit) ** 2 * 0.4
    boom = s.thump(rng, 80, 26, 2.0, 0.55, 1.0, 0.7) * 1.4
    noise = s.bp(s.white(int(1.2 * SR), rng), 150, 8000, 2) * env_hit(1.2, 0.2) * 0.9
    crack = s.crackle(1.0, 300, rng, 1200, 9000, 0.003, curve=np.geomspace(1.0, 0.02, 32)) * 0.5
    y = place(total, (0.0, gather), (0.0, rise), (hit, boom), (hit, noise), (hit, crack),
              (hit, gong(SCALE[0] / 2, 1.8, rng, 1.2) * 0.7))
    return s.reverb(y, 2.2, 0.3, rng=rng)


def aksara_fold(rng, v):
    snap = 0.25
    suck = swell(snap, rng, 800, 10000) * 0.6
    pop = s.bp(s.white(int(0.05 * SR), rng), 1500, 9000, 2) * env_hit(0.05, 0.006) * 1.2
    sub = s.sub_drop(220, 60, 0.3, 0.07) * 0.6
    return s.reverb(place(0.8, (0.0, suck), (snap, pop), (snap, sub), (snap, chime(SCALE[1] * 4, 0.5, rng, 0.2) * 0.4)),
                    1.0, 0.25, rng=rng)


def aksara_gate(rng, v):
    total, open_ = 2.6, 0.5
    n = int(total * SR)
    t = np.arange(n) / SR
    drone = (s.osc(SCALE[1] / 2, total, "saw") + s.osc(SCALE[1] / 2 * 1.007, total, "saw")) * 0.5
    drone = s.sweep_filter(drone, np.concatenate([np.geomspace(200, 1400, 20), np.geomspace(1400, 300, 44)]), "low", 1.3)
    drone = drone * np.minimum(1, t / 0.3) * np.minimum(1, (total - t) / 0.4) * 0.5
    swirl = s.sweep_filter(s.pink(n, rng), 600 + 500 * np.sin(np.linspace(0, 14, 64)), "band", 3.0) * 0.4
    y = place(total, (0.0, drone), (0.0, swirl * np.minimum(1, t / 0.5)))
    y = y + place(total, (open_, gong(SCALE[1] / 2, 2.0, rng, 1.4) * 0.8), (open_, s.thump(rng, 60, 30, 1.0, 0.3, 0.7, 0.4)))
    return s.reverb(y, 2.4, 0.3, rng=rng)


def aksara_lance(rng, v):
    total, hit = 1.2, 0.45
    m = int(hit * SR)
    tt = np.arange(m) / SR
    zing = np.sin(2 * np.pi * np.cumsum(np.geomspace(700, 3200, m) * (1 + 0.01 * np.sin(2 * np.pi * 9 * tt))) / SR)
    zing = zing * (tt / hit) ** 1.5 * 0.35
    stab = chime(SCALE[2] * 8, 0.7, rng, 0.25) * 0.6
    glass = s.crackle(0.3, 600, rng, 3000, 11000, 0.0015) * 0.5
    y = place(total, (0.0, zing), (hit, stab), (hit, glass), (hit, s.thump(rng, 160, 80, 0.3, 0.05, 0.4, 0.6) * 0.6))
    return s.reverb(y, 1.4, 0.3, rng=rng)


def aksara_dominion(rng, v):
    total, hit = 2.4, 0.9
    n = int(total * SR)
    t = np.arange(n) / SR
    wob = (np.sin(2 * np.pi * SCALE[2] * t) + np.sin(2 * np.pi * SCALE[2] * 1.012 * t)) * (0.5 + 0.5 * np.sin(2 * np.pi * 6 * t))
    wob = wob * np.minimum(1, t / 0.6) * np.exp(-np.maximum(0, t - hit) / 0.7) * 0.25
    wave = whoosh(1.2, rng, 200, 1400, 300, 0.25) * 0.6
    y = place(total, (0.0, wob), (hit, wave), (hit, pad([SCALE[2], SCALE[4], SCALE[2] * 2], 1.4, rng, "e", 0.01, 0.9) * 1.3),
              (hit, s.thump(rng, 70, 35, 0.9, 0.25, 0.5, 0.3) * 0.7))
    return s.reverb(y, 2.0, 0.3, rng=rng)


def aksara_rewrite(rng, v):
    total, hit = 1.6, 0.8
    scratches = np.zeros(int(hit * SR))
    k = 0.0
    while k < hit - 0.05:                     # goresan "menulis" (klik-klik tersaring)
        seg = s.bp(s.white(int(0.04 * SR), rng), 2500, 8000, 2) * env_hit(0.04, 0.01) * rng.uniform(0.2, 0.5)
        i = int(k * SR)
        scratches[i:i + len(seg)] += seg[:len(scratches) - i]
        k += rng.uniform(0.04, 0.09)
    pop = s.bp(s.white(int(0.25 * SR), rng), 300, 9000, 2) * env_hit(0.25, 0.04) * 0.8
    crushed = np.round(chime(SCALE[3] * 4, 0.6, rng, 0.3) * 6) / 6 * 0.4   # nada "rusak" (bitcrush)
    rev = bonang(SCALE[3] * 2, 0.5, rng)[::-1] * 0.4
    y = place(total, (0.0, scratches), (hit - 0.5, rev), (hit, pop), (hit, crushed),
              (hit, s.thump(rng, 130, 50, 0.5, 0.1, 0.6, 0.5) * 0.7))
    return s.reverb(y, 1.4, 0.28, rng=rng)


def aksara_veil(rng, v):
    total = 1.2
    glass = sum(chime(f * 6, 1.0, rng, 0.4) * 0.18 for f in (SCALE[3], SCALE[5], SCALE[1]))
    sw = whoosh(0.8, rng, 400, 3000, 600, 0.4) * 0.45
    return s.reverb(place(total, (0.0, glass), (0.05, sw), (0.0, shimmer(1.0, rng, 4000, 12000, 0.3))), 1.8, 0.35, rng=rng)


def aksara_timestop(rng, v):
    total, hit = 2.4, 0.6
    tick = s.bp(s.white(int(0.02 * SR), rng), 2000, 7000, 2) * env_hit(0.02, 0.004)
    tock = s.bp(s.white(int(0.02 * SR), rng), 900, 3500, 2) * env_hit(0.02, 0.005)
    chord = sum(tone(f * 2, 1.6, "tri") for f in (SCALE[4], SCALE[0], SCALE[2])) * 0.12
    stopped = tape(chord, 1.0, 0.2)
    y = place(total, (0.0, tick), (0.2, tock), (0.4, tick), (hit, stopped), (hit, gong(SCALE[4] / 2, 1.8, rng, 1.5, 0.6) * 0.9),
              (hit, s.thump(rng, 65, 30, 1.2, 0.35, 0.6, 0.3) * 0.8), (hit - 0.3, swell(0.3, rng) * 0.5))
    return s.reverb(y, 2.6, 0.35, rng=rng)


def aksara_timeresume(rng, v):
    total = 1.8
    chord = sum(tone(f * 2, 0.8, "tri") for f in (SCALE[4], SCALE[0], SCALE[2])) * 0.12
    start = tape(chord, 0.2, 1.0)
    ticks = []
    for i in range(10):
        ticks.append((0.5 + i * 0.06, s.bp(s.white(int(0.015 * SR), rng), 2000, 7000, 2) * env_hit(0.015, 0.003) * 0.6))
    y = place(total, (0.0, start), (0.45, s.thump(rng, 90, 30, 1.2, 0.35, 0.9, 0.6) * 1.1),
              (0.45, s.bp(s.white(int(0.6 * SR), rng), 200, 7000, 2) * env_hit(0.6, 0.12) * 0.7),
              (0.45, gong(SCALE[4] / 2, 1.2, rng, 0.9) * 0.6), *ticks)
    return s.reverb(y, 2.0, 0.3, rng=rng)


def aksara_rewind(rng, v):
    total, hit = 1.4, 0.5
    g = gong(SCALE[4], 0.5, rng, 0.4)
    rev = g[::-1] * 0.7
    back = whoosh(0.5, rng, 2000, 600, 200, 0.85) * 0.5
    y = place(total, (0.0, rev), (0.0, back), (hit, chime(SCALE[4] * 4, 0.6, rng, 0.25) * 0.5),
              (hit, s.thump(rng, 120, 60, 0.4, 0.08, 0.5, 0.5) * 0.6))
    return s.reverb(y, 1.6, 0.3, rng=rng)


def aksara_soul(rng, v):
    total, rip = 3.2, 2.4
    wail = s.choir([SCALE[5], SCALE[5] * 1.5], rip, rng, "u") * 0.1
    tt = s.t_axis(rip)
    wail = wail * np.minimum(1, tt / 0.4) * (0.7 + 0.3 * np.sin(2 * np.pi * 0.8 * tt))
    drain = s.bp(s.pink(int(rip * SR), rng), 300, 2500, 2) * 0.12 * np.minimum(1, tt / 0.5)
    tear = s.bp(s.white(int(0.5 * SR), rng), 300, 6000, 2) * env_hit(0.5, 0.08) * 0.9
    y = place(total, (0.0, wail), (0.0, drain), (rip, tear), (rip, gong(SCALE[5] / 2, 0.9, rng, 0.7) * 0.6),
              (rip, s.thump(rng, 90, 40, 0.8, 0.2, 0.7, 0.4) * 0.8))
    return s.reverb(y, 2.4, 0.35, rng=rng)


def aksara_ward(rng, v):
    total, hit = 2.0, 0.6
    sw = pad([SCALE[5], SCALE[5] * 1.25, SCALE[5] * 1.5], hit + 0.6, rng, "o", hit, 0.6) * 1.2
    bloom = sum(chime(f * 4, 1.2, rng, 0.5) * 0.22 for f in (SCALE[5], SCALE[3], SCALE[1]))
    return s.reverb(place(total, (0.0, sw), (hit, bloom), (hit, shimmer(0.8, rng, amp=0.25))), 2.2, 0.35, rng=rng)


def aksara_purna(rng, v):
    total, hit = 4.0, 1.7
    parts = [(0.1 + i * 0.22, bonang(SCALE[i] * 2, 1.2, rng, 0.6) * 0.5) for i in range(6)]
    parts.append((0.0, pad([SCALE[0], SCALE[2], SCALE[4]], hit, rng, "a", 1.2, 0.1) * 1.2))
    parts.append((hit - 1.2, swell(1.2, rng, 400, 12000) * 0.8))
    parts.append((hit, gong(SCALE[0] / 2, 3.0, rng, 2.4, 1.8) * 1.4))
    parts.append((hit, gong(SCALE[0], 2.4, rng, 1.8, 2.6) * 0.8))
    parts.append((hit, s.thump(rng, 75, 26, 2.2, 0.6, 1.0, 0.6) * 1.3))
    parts.append((hit, pad([SCALE[0], SCALE[2], SCALE[4], SCALE[0] * 2, SCALE[5] * 2], 2.2, rng, "a", 0.02, 1.6) * 1.5))
    parts.append((hit, shimmer(1.6, rng, amp=0.5)))
    return s.reverb(place(total, *parts), 3.0, 0.35, rng=rng)


def aksara_erase(rng, v):
    total, hit = 6.2, 3.2
    n = int(hit * SR)
    tt = np.arange(n) / SR
    drone = sum(tone(f, hit, "saw") + tone(f * 1.004, hit, "saw") for f in SCALE[:4]) * 0.06
    drone = s.sweep_filter(drone, np.geomspace(200, 4000, 64), "low", 1.1) * (tt / hit) ** 1.5
    rise = swell(hit, rng, 300, 14000) * 0.8
    whiteout = s.bp(s.white(int(2.5 * SR), rng), 80, 14000, 2) * env_hit(2.5, 0.5) * 1.1
    boom = s.thump(rng, 70, 20, 3.0, 0.8, 1.0, 0.8) * 1.5
    ring = sum(gong(f / 2, 3.0, rng, 2.6, 1.4) for f in (SCALE[0], SCALE[2], SCALE[4])) * 0.5
    y = place(total, (0.0, drone), (0.0, rise), (hit, whiteout), (hit, boom), (hit + 0.3, ring),
              (hit, pad([SCALE[0], SCALE[4], SCALE[0] * 2], 2.8, rng, "a", 0.05, 2.0) * 1.2))
    return s.reverb(y, 3.4, 0.38, rng=rng)


def aksara_disc(rng, v):
    total = 1.0
    parts = []
    for i in range(6):
        d = 0.5
        m = int(d * SR)
        tt = np.arange(m) / SR
        whirr = s.bp(s.white(m, rng), 600 + i * 150, 3000 + i * 300, 2) * (0.5 + 0.5 * np.sin(2 * np.pi * (28 + 4 * i) * tt))
        whirr = whirr * np.minimum(1, tt / 0.05) * np.exp(-tt / 0.25) * 0.3
        parts.append((i * 0.03, whirr))
    parts.append((0.0, whoosh(0.6, rng, 300, 2200, 700, 0.35) * 0.5))
    return s.reverb(place(total, *parts), 1.0, 0.22, rng=rng)


def aksara_shield(rng, v):
    clang = s.mix(bonang(SCALE[1] * 2, 0.8, rng, 0.35) * 0.7, chime(SCALE[1] * 6, 0.6, rng, 0.2) * 0.3)
    t = s.t_axis(0.8)
    hum = (tone(SCALE[1], 0.8) + tone(SCALE[1] * 1.5, 0.8) * 0.6) * np.minimum(1, t / 0.02) * np.exp(-t / 0.3) * 0.25
    return s.reverb(place(0.9, (0.0, clang), (0.0, hum), (0.0, s.thump(rng, 150, 80, 0.25, 0.05, 0.4, 0.6) * 0.5)),
                    1.0, 0.22, rng=rng)


def aksara_step(rng, v):
    suck = swell(0.12, rng, 1500, 12000) * 0.5
    pop = s.bp(s.white(int(0.04 * SR), rng), 1500, 9000, 2) * env_hit(0.04, 0.005)
    return s.reverb(place(0.45, (0.0, suck), (0.12, pop), (0.12, chime(SCALE[1] * 8, 0.3, rng, 0.12) * 0.3)),
                    0.7, 0.2, rng=rng)


def aksara_parry(rng, v):
    fwip = whoosh(0.18, rng, 1200, 4500, 1500, 0.4) * 0.6
    return s.reverb(place(0.5, (0.0, fwip), (0.1, chime(SCALE[1] * 6, 0.4, rng, 0.15) * 0.45),
                          (0.1, s.thump(rng, 160, 90, 0.2, 0.04, 0.3, 0.4) * 0.4)), 0.8, 0.22, rng=rng)


def aksara_rite(rng, v):
    total, read, etch, burst = 9.0, 2.5, 5.5, 7.5
    n = int(burst * SR)
    tt = np.arange(n) / SR
    drone = (tone(SCALE[0] / 2, burst, "saw") + tone(SCALE[0] / 2 * 1.006, burst, "saw")) * 0.12
    drone = s.lp(drone, 700) * np.minimum(1, tt / 1.5)
    parts = [(0.0, drone), (0.0, pad([SCALE[0], SCALE[2]], read, rng, "o", 1.2, 0.5) * 0.8)]
    for i in range(6):                            # tiap aksara menggurat badan
        parts.append((read + i * 0.5, bonang(SCALE[i] * 2, 1.2, rng, 0.5) * 0.55))
        parts.append((read + i * 0.5, chime(SCALE[i] * 8, 0.6, rng, 0.2) * 0.2))
    parts.append((etch, pad([SCALE[0], SCALE[2], SCALE[4]], burst - etch, rng, "a", 1.5, 0.1) * 1.2))
    parts.append((burst - 1.5, swell(1.5, rng, 300, 12000) * 0.8))
    parts.append((burst, gong(SCALE[0] / 2, 3.0, rng, 2.4, 1.6) * 1.4))
    parts.append((burst, s.thump(rng, 70, 26, 2.0, 0.55, 1.0, 0.6) * 1.3))
    parts.append((burst, shimmer(1.4, rng, amp=0.5)))
    return s.reverb(place(total, *parts), 2.8, 0.32, rng=rng)


RECIPES = {
    "aksara_transform": (aksara_transform, 1, 1.0),
    "aksara_revert": (aksara_revert, 1, 0.8),
    "aksara_pulse": (aksara_pulse, 3, 0.6),
    "aksara_punch": (aksara_punch, 2, 0.9),
    "aksara_sixfold": (aksara_sixfold, 1, 1.0),
    "aksara_beam": (aksara_beam, 1, 0.95),
    "aksara_nova": (aksara_nova, 1, 1.0),
    "aksara_fold": (aksara_fold, 1, 0.85),
    "aksara_gate": (aksara_gate, 1, 0.95),
    "aksara_lance": (aksara_lance, 1, 0.9),
    "aksara_dominion": (aksara_dominion, 1, 0.9),
    "aksara_rewrite": (aksara_rewrite, 1, 0.9),
    "aksara_veil": (aksara_veil, 1, 0.8),
    "aksara_timestop": (aksara_timestop, 1, 1.0),
    "aksara_timeresume": (aksara_timeresume, 1, 1.0),
    "aksara_rewind": (aksara_rewind, 1, 0.85),
    "aksara_soul": (aksara_soul, 1, 0.9),
    "aksara_ward": (aksara_ward, 1, 0.8),
    "aksara_purna": (aksara_purna, 1, 1.0),
    "aksara_erase": (aksara_erase, 1, 1.0),
    "aksara_disc": (aksara_disc, 1, 0.85),
    "aksara_shield": (aksara_shield, 1, 0.85),
    "aksara_step": (aksara_step, 1, 0.75),
    "aksara_rite": (aksara_rite, 1, 1.0),
    "aksara_parry": (aksara_parry, 1, 0.8),
}
WINDUPS = set()
LOOPS = set()

s.RECIPES.update(RECIPES)
s.WINDUPS.update(WINDUPS)
s.LOOPS.update(LOOPS)

if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "out"
    only = sys.argv[2:] if len(sys.argv) > 2 else None
    os.makedirs(out, exist_ok=True)
    for name, (fn, count, gain) in RECIPES.items():
        if only and name not in only:
            continue
        for v in range(count):
            y = s.render(name, fn, v, gain)
            fname = f"{name}_{v + 1}.ogg"
            s.encode(y, os.path.join(out, fname))
            rms = 20 * np.log10(np.sqrt(np.mean(y ** 2)) + 1e-9)
            print(fname, round(len(y) / SR, 2), "dtk", round(float(rms), 1), "dB", flush=True)
