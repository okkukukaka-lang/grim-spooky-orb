"""Tekstur Aksara, Sang Penulis Ulang (0.50, desain orisinal).

Automaton berwujud wayang: tubuh grafit hitam bergurat prada emas (sulur & ceplok kawung), topeng gading tanpa wajah
dengan celah mata tipis dan satu garis prada tegak, aksara enam kelopak di dada, kain parang nila-prada yang dililit di
paha, dan jubah panjang nila-hitam bermotif parang prada. Warna ranah (dipakai cakram & HUD) ada di AksaraSkills.RGB.

    python3 aksara_textures.py ASSETS_DIR [PREVIEW.png]

Menulis (tata letak UV pemain 64x64, skala 4):
  textures/entity/aksara/skin.png        256x256  tubuh (base) + kain paha (lapisan luar, alpha)
  textures/entity/aksara/glow.png        256x256  gurat prada, celah mata, aksara dada yang menyala (RenderType.eyes)
  textures/entity/aksara/gold.png        16x16    logam prada (mahkota, sumping, kelat, cincin cakram)
  textures/entity/aksara/plate.png       16x16    bahan polos terang (diberi warna di kode: gading, grafit, perunggu)
  textures/entity/aksara/cape_cloth.png  64x128   jubah nila-hitam bermotif parang prada
  textures/entity/aksara_emblem.png      32x32    lambang aksara enam kelopak
  textures/item/lontar_sabda.png         16x16    ikon Lontar Sabda
"""
import os
import sys

import numpy as np
from PIL import Image

S = 4
N = 64 * S
rng = np.random.default_rng(50)

GRAPHITE = np.array([28, 27, 36], float)
GRAPHITE_HI = np.array([58, 56, 72], float)
GOLD = np.array([226, 178, 76], float)
GOLD_HI = np.array([255, 232, 160], float)
GOLD_SH = np.array([132, 92, 30], float)
IVORY = np.array([239, 229, 208], float)
IVORY_SH = np.array([190, 176, 150], float)
INDIGO = np.array([34, 30, 70], float)
INDIGO_DK = np.array([18, 16, 34], float)
GLOW = np.array([255, 214, 130], float)
GLOW_HOT = np.array([255, 246, 220], float)
SABDA = [np.array(c, float) for c in ((255, 48, 72), (138, 108, 255), (64, 230, 255), (255, 79, 200), (255, 184, 64),
                                       (92, 255, 160))]


def noise(h, w, cell, amp):
    gh, gw = h // cell + 2, w // cell + 2
    g = rng.random((gh, gw))
    yy, xx = np.mgrid[0:h, 0:w]
    fy, fx = yy / cell, xx / cell
    y0, x0 = fy.astype(int), fx.astype(int)
    ty, tx = fy - y0, fx - x0
    ty, tx = ty * ty * (3 - 2 * ty), tx * tx * (3 - 2 * tx)
    a = g[y0, x0] * (1 - tx) + g[y0, x0 + 1] * tx
    b = g[y0 + 1, x0] * (1 - tx) + g[y0 + 1, x0 + 1] * tx
    return (a * (1 - ty) + b * ty - 0.5) * 2 * amp


def seg_dist(x, y, ax, ay, bx, by):
    dx, dy = bx - ax, by - ay
    L2 = dx * dx + dy * dy + 1e-9
    t = np.clip(((x - ax) * dx + (y - ay) * dy) / L2, 0, 1)
    return np.hypot(x - (ax + t * dx), y - (ay + t * dy))


class Face:
    """Satu sisi kubus model (w x h piksel model, digambar S kali lebih rapat)."""

    def __init__(self, w, h, base=GRAPHITE, sheen=0.10):
        self.w, self.h = w, h
        ys, xs = np.mgrid[0:h * S, 0:w * S]
        self.x, self.y = (xs + 0.5) / S, (ys + 0.5) / S
        hh, ww = self.x.shape
        k = 1.0 + noise(hh, ww, 3, 0.05) + noise(hh, ww, 10, 0.08)
        self.rgb = np.clip(base[None, None] * k[..., None], 0, 255)
        # kilau logam lembut: garis terang miring yang lebar
        band = np.clip(1 - np.abs((self.x / max(w, 1)) * 0.8 - (self.y / max(h, 1)) * 0.6 - 0.1) / 0.35, 0, 1)
        self.rgb = np.clip(self.rgb + GRAPHITE_HI[None, None] * band[..., None] * sheen * 3, 0, 255)
        self.alpha = np.full((hh, ww), 255.0)
        self.glow = np.zeros((hh, ww, 3))

    def shade(self, edge=0.28, top=0.1):
        u = (self.x / self.w) * 2 - 1
        v = self.y / self.h
        k = 1.0 - edge * np.abs(u) ** 2.2 + top * (0.5 - v)
        self.rgb = np.clip(self.rgb * k[..., None], 0, 255)

    def clear(self):
        self.alpha[:] = 0.0

    def line(self, pts, width=0.16, glow=0.75, rgb=GOLD):
        """Gurat prada: garis emas berbevel (tepi atas terang, bawah gelap) yang juga menyala tipis di glow."""
        m = np.zeros_like(self.x)
        for (ax, ay), (bx, by) in zip(pts[:-1], pts[1:]):
            d = seg_dist(self.x, self.y, ax, ay, bx, by)
            m = np.maximum(m, np.clip(1 - d / width, 0, 1))
        hard = (m > 0.25).astype(float)
        bevel = np.clip(m * 1.6, 0, 1)
        col = rgb * (0.75 + 0.35 * bevel[..., None]) if rgb.ndim == 1 else rgb
        self.rgb = self.rgb * (1 - hard[..., None]) + np.clip(col, 0, 255) * hard[..., None]
        self.glow = np.maximum(self.glow, GLOW[None, None] * (m ** 1.5)[..., None] * glow)
        return hard

    def spiral(self, cx, cy, r, turns=1.6, sign=1.0, width=0.14, glow=0.75):
        t = np.linspace(0, 1, 40)
        a = sign * t * turns * 2 * np.pi
        rr = r * (1 - t * 0.85)
        pts = list(zip(cx + np.cos(a) * rr, cy + np.sin(a) * rr))
        self.line(pts, width, glow)

    def kawung(self, cx, cy, r, glow=0.8):
        """Ceplok kawung: empat kelopak lonjong mengelilingi titik tengah (motif batik)."""
        for k in range(4):
            ang = k * np.pi / 2 + np.pi / 4
            px, py = cx + np.cos(ang) * r * 0.55, cy + np.sin(ang) * r * 0.55
            ca, sa = np.cos(ang), np.sin(ang)
            u = (self.x - px) * ca + (self.y - py) * sa
            v = -(self.x - px) * sa + (self.y - py) * ca
            d = np.hypot(u / (r * 0.5), v / (r * 0.28))
            ring = np.clip(1 - np.abs(d - 1) / 0.22, 0, 1)
            hard = ring > 0.3
            self.rgb = np.where(hard[..., None], GOLD, self.rgb)
            self.glow = np.maximum(self.glow, GLOW[None, None] * ring[..., None] ** 1.5 * glow)
        dot = np.hypot(self.x - cx, self.y - cy) < r * 0.14
        self.rgb = np.where(dot[..., None], GOLD_HI, self.rgb)
        self.glow = np.maximum(self.glow, GLOW_HOT[None, None] * dot[..., None] * glow)

    def petals(self, cx, cy, r, glow=1.0):
        """Aksara enam kelopak (lambang Aksara): enam kelopak warna ranah mengelilingi inti emas."""
        for k in range(6):
            ang = -np.pi / 2 + k * np.pi / 3
            px, py = cx + np.cos(ang) * r * 0.55, cy + np.sin(ang) * r * 0.55
            ca, sa = np.cos(ang), np.sin(ang)
            u = (self.x - px) * ca + (self.y - py) * sa
            v = -(self.x - px) * sa + (self.y - py) * ca
            d = np.hypot(u / (r * 0.45), v / (r * 0.2))
            fill = d < 1
            self.rgb = np.where(fill[..., None], GOLD * 0.6 + SABDA[k] * 0.4, self.rgb)
            self.glow = np.maximum(self.glow, SABDA[k][None, None] * np.clip(1 - d, 0, 1)[..., None] ** 0.7 * glow)
        core = np.hypot(self.x - cx, self.y - cy) < r * 0.2
        self.rgb = np.where(core[..., None], GOLD_HI, self.rgb)
        self.glow = np.maximum(self.glow, GLOW_HOT[None, None] * core[..., None] * glow)

    def band(self, y0, y1, glow=0.4):
        inside = (self.y >= y0) & (self.y < y1)
        v = (self.y - y0) / max(y1 - y0, 1e-3)
        col = GOLD_HI * (1 - v[..., None]) + GOLD_SH * v[..., None]
        self.rgb = np.where(inside[..., None], col, self.rgb)
        self.alpha = np.where(inside, 255.0, self.alpha)
        edge = inside & ((v < 0.2) | (v > 0.8))
        self.glow = np.maximum(self.glow, GLOW[None, None] * edge[..., None] * glow)

    def parang(self, y0, y1, glow=0.35, scale=1.0):
        """Kain parang: dasar nila, pita emas berbentuk S yang miring berulang, tepi bawah berumbai emas."""
        inside = (self.y >= y0) & (self.y < y1)
        hh, ww = self.x.shape
        base = INDIGO[None, None] * (1.0 + noise(hh, ww, 2, 0.08))[..., None]
        diag = (self.x + self.y) / (2.2 * scale)
        ph = diag - np.floor(diag)
        wave = 0.5 + 0.35 * np.sin((self.x - self.y) / (1.3 * scale) * np.pi)
        s_band = np.abs(ph - wave) < 0.09
        dots = (np.abs(ph - (wave + 0.5) % 1.0) < 0.05) & (np.sin(self.x * 3.1 / scale) > 0.7)
        col = np.where(s_band[..., None], GOLD, base)
        col = np.where(dots[..., None], GOLD_HI, col)
        col = np.where(((self.y >= y1 - 0.5) & inside)[..., None], GOLD_SH, col)   # tepi bawah
        self.rgb = np.where(inside[..., None], col, self.rgb)
        self.alpha = np.where(inside, 255.0, self.alpha)
        self.glow = np.maximum(self.glow, GLOW[None, None] * (s_band & inside)[..., None] * glow)


def put(img, glow, u, v, f):
    hh, ww = f.x.shape
    y0, x0 = v * S, u * S
    img[y0:y0 + hh, x0:x0 + ww, :3] = np.clip(f.rgb, 0, 255)
    img[y0:y0 + hh, x0:x0 + ww, 3] = f.alpha
    glow[y0:y0 + hh, x0:x0 + ww] = np.maximum(glow[y0:y0 + hh, x0:x0 + ww], f.glow)


def box(img, glow, u, v, w, h, d, faces):
    top, bottom, right, front, left, back = faces
    put(img, glow, u + d, v, top)
    put(img, glow, u + d + w, v, bottom)
    put(img, glow, u, v + d, right)
    put(img, glow, u + d, v + d, front)
    put(img, glow, u + d + w, v + d, left)
    put(img, glow, u + d + w + d, v + d, back)


def six(w, h, d):
    return [Face(w, d), Face(w, d), Face(d, h), Face(w, h), Face(d, h), Face(w, h)]


# ------------------------------------------------------------------ bagian badan

def head_faces(outer):
    f = six(8, 8, 8)
    top, bottom, right, front, left, back = f
    if outer:
        for x in f:
            x.clear()
        return f
    for face in f:
        face.shade(0.24, 0.08)
    # topeng gading tanpa wajah: lonjong halus, celah mata tipis, garis prada tegak, alis prada melengkung
    hh, ww = front.x.shape
    d = np.hypot((front.x - 4.0) / 3.9, (front.y - 4.1) / 4.2)
    mask = d < 1.0
    shade = np.clip(1 - d, 0, 1)
    col = IVORY[None, None] * (0.86 + 0.14 * shade[..., None] ** 0.5) * (1.0 + noise(hh, ww, 4, 0.03))[..., None]
    col = col * (1 - 0.12 * np.clip(np.abs(front.x - 4.0) / 4.0, 0, 1) ** 2)[..., None]
    front.rgb = np.where(mask[..., None], col, front.rgb)
    for ex in (2.45, 5.55):   # celah mata
        slit = (np.abs(front.y - 4.4) < 0.17) & (np.abs(front.x - ex) < 0.95)
        front.rgb = np.where(slit[..., None], np.array([16, 12, 20], float), front.rgb)
        front.glow = np.maximum(front.glow, GLOW_HOT[None, None] * slit[..., None])
    front.line([(4.0, 0.5), (4.0, 7.6)], 0.09, 0.9)                              # garis prada tegak
    front.line([(0.9, 3.4), (2.0, 2.8), (3.2, 2.95), (3.85, 3.3)], 0.1, 0.6)      # alis prada
    front.line([(7.1, 3.4), (6.0, 2.8), (4.8, 2.95), (4.15, 3.3)], 0.1, 0.6)
    front.rgb = np.where(((~mask) & (d < 1.08))[..., None], GOLD_SH, front.rgb)   # bingkai topeng
    # sisi & belakang kepala: sulur prada
    for side, sgn in ((right, 1.0), (left, -1.0)):
        side.spiral(4.0, 4.6, 2.2, 1.5, sgn, 0.12, 0.7)
        side.line([(0.3, 6.8), (2.6, 6.2), (5.4, 6.4), (7.7, 6.9)], 0.11, 0.55)
    back.kawung(4.0, 4.4, 2.8, 0.7)
    back.line([(0.5, 7.2), (7.5, 7.2)], 0.12, 0.5)
    top.kawung(4.0, 4.0, 3.0, 0.5)
    return f


def body_faces(outer):
    f = six(8, 12, 4)
    top, bottom, right, front, left, back = f
    if outer:
        for x in f:
            x.clear()
        return f
    for face in f:
        face.shade(0.26, 0.10)
    # dada: aksara enam kelopak, sulur simetris yang keluar dari aksara, garis prada ke pinggang
    front.petals(4.0, 3.6, 2.2, 1.0)
    for sgn in (1.0, -1.0):
        cx = 4.0 + sgn * 2.6
        front.spiral(cx, 6.8, 1.3, 1.4, sgn, 0.11, 0.7)
        front.line([(4.0 + sgn * 0.6, 5.6), (4.0 + sgn * 1.6, 7.4), (4.0 + sgn * 1.4, 10.3), (4.0 + sgn * 0.4, 11.6)],
                   0.11, 0.65)
        front.line([(4.0 + sgn * 2.0, 1.2), (4.0 + sgn * 3.6, 2.2), (4.0 + sgn * 3.7, 4.4)], 0.1, 0.55)
    front.line([(4.0, 5.9), (4.0, 11.8)], 0.08, 0.5)
    # punggung: dudukan halo (lingkaran prada) & sulur
    yy = np.hypot(back.x - 4.0, back.y - 3.0)
    ring = np.abs(yy - 1.6) < 0.18
    back.rgb = np.where(ring[..., None], GOLD, back.rgb)
    back.glow = np.maximum(back.glow, GLOW[None, None] * ring[..., None] * 0.9)
    back.kawung(4.0, 3.0, 1.2, 0.6)
    for sgn in (1.0, -1.0):
        back.spiral(4.0 + sgn * 2.4, 7.6, 1.4, 1.3, -sgn, 0.11, 0.6)
    back.line([(4.0, 4.9), (4.0, 11.8)], 0.09, 0.55)
    for side in (right, left):
        side.line([(2.0, 0.4), (2.0, 11.6)], 0.09, 0.5)
        side.kawung(2.0, 6.0, 1.3, 0.5)
    for face in (front, back, right, left):   # sabuk prada di pinggang (3D-nya menutupi juga)
        face.band(10.6, 11.9, 0.35)
    return f


def limb_faces(outer, arm):
    f = six(4, 12, 4)
    top, bottom, right, front, left, back = f
    if outer:
        for x in f:
            x.clear()
        if not arm:   # kain parang di paha (lapisan celana)
            for face in (right, front, left, back):
                face.parang(0.0, 6.5, 0.35, 2.2)
        return f
    for face in f:
        face.shade(0.3, 0.08)
    for face in (front, back, right, left):
        face.line([(2.0, 0.3), (2.0, 11.7)], 0.09, 0.55)
        face.spiral(2.0, 5.4 if arm else 8.0, 1.0, 1.3, 1.0 if face is not left else -1.0, 0.1, 0.55)
        if arm:
            face.band(3.0, 3.8, 0.35)     # kelat bahu
            face.band(10.2, 11.2, 0.35)   # gelang
        else:
            face.band(10.4, 11.3, 0.35)   # gelang kaki
    bottom.rgb = np.clip(bottom.rgb * 0.8, 0, 255)
    return f


def skin(out):
    img = np.zeros((N, N, 4), float)
    glow = np.zeros((N, N, 3), float)
    box(img, glow, 0, 0, 8, 8, 8, head_faces(False))
    box(img, glow, 32, 0, 8, 8, 8, head_faces(True))
    box(img, glow, 16, 16, 8, 12, 4, body_faces(False))
    box(img, glow, 16, 32, 8, 12, 4, body_faces(True))
    box(img, glow, 40, 16, 4, 12, 4, limb_faces(False, True))
    box(img, glow, 40, 32, 4, 12, 4, limb_faces(True, True))
    box(img, glow, 32, 48, 4, 12, 4, limb_faces(False, True))
    box(img, glow, 48, 48, 4, 12, 4, limb_faces(True, True))
    box(img, glow, 0, 16, 4, 12, 4, limb_faces(False, False))
    box(img, glow, 0, 32, 4, 12, 4, limb_faces(True, False))
    box(img, glow, 16, 48, 4, 12, 4, limb_faces(False, False))
    box(img, glow, 0, 48, 4, 12, 4, limb_faces(True, False))
    from scipy import ndimage
    soft = np.stack([ndimage.gaussian_filter(glow[..., c], 1.6) for c in range(3)], -1) * 1.4
    g = np.clip(glow * 1.0 + soft * 0.6, 0, 255)
    gimg = np.zeros((N, N, 4), np.uint8)
    gimg[..., :3] = g.astype(np.uint8)
    gimg[..., 3] = 255
    d = os.path.join(out, "textures/entity/aksara")
    os.makedirs(d, exist_ok=True)
    Image.fromarray(np.clip(img, 0, 255).astype(np.uint8), "RGBA").save(os.path.join(d, "skin.png"))
    Image.fromarray(gimg, "RGBA").save(os.path.join(d, "glow.png"))
    return img, gimg


def gold(out):
    """Logam prada 16x16: v = 0 terang di atas, gelap di bawah; kilau mendatar & bintik halus."""
    n = 16
    ys, xs = np.mgrid[0:n, 0:n]
    v = (ys + 0.5) / n
    u = (xs + 0.5) / n
    col = GOLD_HI[None, None] * (1 - v[..., None]) ** 1.2 + GOLD_SH[None, None] * v[..., None] ** 0.9
    col = col * (1.0 + 0.12 * np.sin(u * 9.0 + v * 4.0))[..., None] * (1.0 + noise(n, n, 2, 0.05))[..., None]
    hi = np.abs(v - 0.28) < 0.06
    col = np.where(hi[..., None], np.minimum(255, col * 1.25), col)
    img = np.zeros((n, n, 4), np.uint8)
    img[..., :3] = np.clip(col, 0, 255).astype(np.uint8)
    img[..., 3] = 255
    Image.fromarray(img, "RGBA").save(os.path.join(out, "textures/entity/aksara/gold.png"))


def plate(out):
    """Bahan polos terang 16x16 (warnanya dari kode): sedikit bintik & gradasi supaya nggak datar."""
    n = 16
    ys, xs = np.mgrid[0:n, 0:n]
    v = (ys + 0.5) / n
    k = 0.92 + 0.08 * (1 - v) + noise(n, n, 2, 0.03) + noise(n, n, 5, 0.02)
    col = np.clip(240 * k, 0, 255)
    img = np.zeros((n, n, 4), np.uint8)
    img[..., :3] = col[..., None].astype(np.uint8)
    img[..., 3] = 255
    Image.fromarray(img, "RGBA").save(os.path.join(out, "textures/entity/aksara/plate.png"))


def cape(out):
    """Jubah 64x128: nila-hitam, motif parang prada miring, list prada di tepi bawah & kedua sisi."""
    w, h = 64, 128
    ys, xs = np.mgrid[0:h, 0:w]
    x, y = xs + 0.5, ys + 0.5
    base = INDIGO_DK[None, None] * (1.0 + noise(h, w, 3, 0.07) + noise(h, w, 12, 0.06))[..., None]
    base = base + INDIGO[None, None] * 0.35 * (y / h)[..., None]
    diag = (x + y) / 14.0
    ph = diag - np.floor(diag)
    wave = 0.5 + 0.3 * np.sin((x - y) / 9.0 * np.pi)
    s_band = np.abs(ph - wave) < 0.07
    s_edge = (np.abs(ph - wave) < 0.11) & ~s_band
    dots = (np.abs(ph - (wave + 0.5) % 1.0) < 0.05) & (np.sin(x * 0.45) > 0.55)
    col = np.where(s_band[..., None], GOLD * 0.95, base)
    col = np.where(s_edge[..., None], GOLD_SH * 0.7, col)
    col = np.where(dots[..., None], GOLD_HI * 0.85, col)
    border = (y > h - 7) | (x < 2) | (x > w - 3)
    trim = (y > h - 7) & (np.abs(((x / 4.0) % 1.0) - 0.5) < 0.18) & (y < h - 2)
    col = np.where(border[..., None], GOLD_SH, col)
    col = np.where(trim[..., None], GOLD_HI, col)
    img = np.zeros((h, w, 4), np.uint8)
    img[..., :3] = np.clip(col, 0, 255).astype(np.uint8)
    img[..., 3] = 255
    Image.fromarray(img, "RGBA").save(os.path.join(out, "textures/entity/aksara/cape_cloth.png"))


def emblem(out):
    """Lambang 32x32: aksara enam kelopak di dalam lingkaran prada."""
    n = 32
    f = Face(8, 8, np.array([0, 0, 0], float), 0.0)
    f.rgb[:] = 0
    f.alpha[:] = 0
    d = np.hypot(f.x - 4.0, f.y - 4.0)
    disk = d < 3.9
    f.alpha = np.where(disk, 255.0, 0.0)
    f.rgb = np.where(disk[..., None], INDIGO_DK, f.rgb)
    ring = np.abs(d - 3.55) < 0.28
    f.rgb = np.where(ring[..., None], GOLD, f.rgb)
    f.petals(4.0, 4.0, 3.0, 1.0)
    img = np.zeros((n, n, 4), np.uint8)
    img[..., :3] = np.clip(f.rgb, 0, 255).astype(np.uint8)
    img[..., 3] = np.clip(f.alpha, 0, 255).astype(np.uint8)
    Image.fromarray(img, "RGBA").save(os.path.join(out, "textures/entity/aksara_emblem.png"))


def lontar_item(out):
    """Ikon Lontar Sabda 16x16: daun lontar panjang miring berlapis prada, tali pengikat, enam aksara berwarna ranah."""
    n = 16
    img = np.zeros((n, n, 4), float)
    ys, xs = np.mgrid[0:n, 0:n]
    x, y = xs + 0.5, ys + 0.5
    # sumbu daun: dari kiri bawah ke kanan atas
    ax, ay, bx, by = 2.0, 13.0, 14.0, 3.0
    dx, dy = bx - ax, by - ay
    L = np.hypot(dx, dy)
    t = ((x - ax) * dx + (y - ay) * dy) / (L * L)
    dist = np.abs((x - ax) * dy - (y - ay) * dx) / L
    leaf = (t > 0) & (t < 1) & (dist < 2.3)
    edge = leaf & (dist > 1.7)
    leaf_col = np.array([214, 178, 112], float) * (0.85 + 0.15 * np.cos(t * 30))[..., None]
    img[..., :3] = np.where(leaf[..., None], leaf_col, 0)
    img[..., :3] = np.where(edge[..., None], GOLD_SH, img[..., :3])
    img[..., 3] = np.where(leaf, 255, 0)
    for k in range(6):   # enam aksara berwarna
        tk = 0.15 + k * 0.14
        cx, cy = ax + dx * tk, ay + dy * tk
        m = np.hypot(x - cx, y - cy) < 0.75
        img[..., :3] = np.where(m[..., None], SABDA[k], img[..., :3])
    tie = (np.abs(t - 0.5) < 0.04) & (dist < 2.6)   # tali pengikat prada
    img[..., :3] = np.where(tie[..., None], GOLD_HI, img[..., :3])
    img[..., 3] = np.where(tie, 255, img[..., 3])
    out_dir = os.path.join(out, "textures/item")
    os.makedirs(out_dir, exist_ok=True)
    Image.fromarray(np.clip(img, 0, 255).astype(np.uint8), "RGBA").save(os.path.join(out_dir, "lontar_sabda.png"))


def preview(path, img, gimg):
    """Pratinjau: kulit, cahaya, dan gabungan kulit + cahaya (dibesarkan 2x)."""
    base = Image.fromarray(np.clip(img, 0, 255).astype(np.uint8), "RGBA")
    g = Image.fromarray(gimg, "RGBA")
    combo = np.clip(img[..., :3] * 0.7 + gimg[..., :3].astype(float) * 0.9, 0, 255).astype(np.uint8)
    c = Image.fromarray(np.dstack([combo, np.clip(img[..., 3], 0, 255).astype(np.uint8)]), "RGBA")
    sheet = Image.new("RGBA", (N * 3 + 20, N), (40, 40, 48, 255))
    sheet.paste(base, (0, 0), base)
    sheet.paste(g, (N + 10, 0))
    sheet.paste(c, (2 * N + 20, 0), c)
    sheet = sheet.resize((sheet.width * 2, sheet.height * 2), Image.NEAREST)
    sheet.save(path)


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "out"
    img, gimg = skin(out)
    gold(out)
    plate(out)
    cape(out)
    emblem(out)
    lontar_item(out)
    if len(sys.argv) > 2:
        preview(sys.argv[2], img, gimg)
    print("ok")
