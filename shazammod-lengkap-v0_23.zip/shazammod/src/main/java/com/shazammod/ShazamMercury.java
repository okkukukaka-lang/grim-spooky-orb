package com.shazammod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.phys.Vec3;

/**
 * M - Mode Kilat Mercury (tombol N): tekan sekali nyala, tekan lagi mati. Auto-hit-nya bisa dimatikan/dinyalakan
 * dengan tombol M (cuma di client: client yang memilih sasaran, server tetap memeriksa tiap pukulan).
 *
 * Selama nyala, client pemain itu sendiri yang menggerakkan badannya: lari super cepat kalau nggak ada musuh, dan
 * otomatis melesat ke tiap monster di sekitar lalu memukulnya satu per satu (lihat client.flight.MercuryMode).
 * Server cuma memeriksa tiap pukulan (mode menyala, sasarannya monster yang hidup, jaraknya masuk akal, jeda
 * antar-pukulan), lalu memberi damage, suara, dan animasi untuk pemain lain. Energi berkurang selama mode nyala
 * dan tiap kali memukul; kalau menipis, mode mati sendiri.
 */
public final class ShazamMercury {
    private ShazamMercury() {}

    // ================= Angka-angka yang gampang diutak-atik =================
    public static final float START_COST = 15f;          // energi saat dinyalakan
    public static final float DRAIN_PER_SECOND = 3f;     // energi per detik selama nyala (energi penuh cukup ±5 menit)
    public static final float STRIKE_COST = 1f;          // energi per pukulan
    public static final float MIN_ENERGY = 5f;           // di bawah ini mode mati sendiri
    public static final float KILL_DAMAGE = 1000f;       // monster biasa: sekali pukul langsung mati
    public static final float BOSS_DAMAGE = 60f;         // bos dipukul bertubi-tubi, bukan langsung mati
    public static final float BOSS_HEALTH = 150f;        // darah maksimum segini ke atas dihitung bos (juga Wither & Ender Dragon)
    public static final boolean INSTAKILL_BOSSES = false; // true = bos juga langsung mati sekali pukul
    private static final double TRUSTED_REACH = 7.5;     // jarak pemain-sasaran maksimum yang dipercaya dari client (termasuk lag)
    private static final int MIN_STRIKE_GAP = 2;         // tick minimal antar-pukulan
    private static final int TOGGLE_GAP = 4;             // anti tekan dobel
    // =========================================================================

    private static final class Mode {
        long lastStrike = -100;
    }

    private static final Map<UUID, Mode> ACTIVE = new HashMap<>();
    private static final Map<UUID, Long> LAST_TOGGLE = new HashMap<>();

    public static boolean isActive(ServerPlayer player) {
        return ACTIVE.containsKey(player.getUUID());
    }

    /** Tombol N: nyalakan atau matikan mode. */
    public static void toggle(ServerPlayer player) {
        long now = player.level().getGameTime();
        Long last = LAST_TOGGLE.get(player.getUUID());
        if (last != null && now - last < TOGGLE_GAP) {
            return;
        }
        LAST_TOGGLE.put(player.getUUID(), now);
        if (isActive(player)) {
            stop(player, true);
            player.displayClientMessage(Component.translatable("message.shazammod.mercury_off").withStyle(ChatFormatting.GRAY), true);
            return;
        }
        ShazamData data = ShazamPowers.data(player);
        if (data.energy() < START_COST + MIN_ENERGY) {
            player.displayClientMessage(Component.translatable("message.shazammod.skill_no_energy",
                    Math.round(START_COST + MIN_ENERGY)).withStyle(ChatFormatting.RED), true);
            return;
        }
        ShazamPowers.setData(player, data.withEnergy(data.energy() - START_COST));
        ACTIVE.put(player.getUUID(), new Mode());
        ShazamNetwork.playAnim(player, ShazamAnim.MERCURY_ON);
        ServerLevel level = player.serverLevel();
        level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.0f, 1.8f);
        level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, 0.6f, 1.7f);
        player.displayClientMessage(Component.translatable("message.shazammod.mercury_on",
                Component.keybind("key.shazammod.mercury_auto")).withStyle(ChatFormatting.AQUA), true);
        ShazamNetwork.broadcastState(player);
        ShazamNetwork.sync(player);
    }

    /** Matikan mode (tombol, energi menipis, balik jadi manusia, respawn). */
    public static void stop(ServerPlayer player, boolean effects) {
        if (ACTIVE.remove(player.getUUID()) == null) {
            return;
        }
        if (effects) {
            ShazamNetwork.playAnim(player, ShazamAnim.MERCURY_OFF);
            player.serverLevel().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.BEACON_DEACTIVATE,
                    SoundSource.PLAYERS, 0.7f, 1.6f);
        }
        ShazamNetwork.broadcastState(player);
    }

    /** Tiap tick selama jadi Shazam. */
    public static void tick(ServerPlayer player) {
        if (!isActive(player)) {
            return;
        }
        ShazamData data = ShazamPowers.data(player);
        float energy = data.energy() - DRAIN_PER_SECOND / 20f;
        if (energy <= MIN_ENERGY) {
            stop(player, true);
            player.displayClientMessage(Component.translatable("message.shazammod.mercury_tired").withStyle(ChatFormatting.RED), true);
            return;
        }
        ShazamPowers.setData(player, data.withEnergy(energy));
    }

    /**
     * Client memukul sasaran. move = jenis pukulan (0 jab, 1 cross, 2 hook, 3 tendangan), cuma buat animasi.
     * Cuma monster yang bisa kena: pemain lain, hewan peliharaan, dan villager aman.
     */
    public static void strike(ServerPlayer player, int targetId, int move) {
        Mode mode = ACTIVE.get(player.getUUID());
        if (mode == null || !ShazamPowers.isTransformed(player)) {
            return;
        }
        ServerLevel level = player.serverLevel();
        long now = level.getGameTime();
        if (now - mode.lastStrike < MIN_STRIKE_GAP) {
            return;
        }
        if (!(level.getEntity(targetId) instanceof LivingEntity target) || !(target instanceof Enemy) || !target.isAlive()
                || target.isInvulnerable()) {
            return;
        }
        double reach = TRUSTED_REACH + target.getBbWidth();   // musuh raksasa (ghast, Ender Dragon): jaraknya dari titik kakinya
        if (player.distanceToSqr(target) > reach * reach) {
            return;
        }
        mode.lastStrike = now;
        ShazamData data = ShazamPowers.data(player);
        ShazamPowers.setData(player, data.withEnergy(Math.max(0f, data.energy() - STRIKE_COST)));

        Vec3 dir = new Vec3(target.getX() - player.getX(), 0, target.getZ() - player.getZ());
        if (dir.lengthSqr() < 1.0E-4) {
            Vec3 look = player.getViewVector(1f);
            dir = new Vec3(look.x, 0, look.z);
        }
        dir = dir.lengthSqr() < 1.0E-4 ? new Vec3(0, 0, 1) : dir.normalize();
        boolean boss = !INSTAKILL_BOSSES && isBoss(target);
        target.invulnerableTime = 0;   // pukulan bertubi-tubi tetap kena semua
        target.hurt(ShazamPowers.forceSource(player), boss ? BOSS_DAMAGE : KILL_DAMAGE);
        // badannya terpental searah pukulan (mob yang mati tetap jatuh terlempar selama animasi matinya)
        double fling = boss ? 0.25 : (move == 3 ? 2.2 : 1.6);
        target.push(dir.x * fling, boss ? 0.05 : (move == 2 ? 0.75 : 0.45), dir.z * fling);

        Vec3 hit = target.position().add(0, target.getBbHeight() * 0.6, 0);
        ShazamNetwork.playAnimToOthers(player, strikeAnim(move), hit);
        level.playSound(null, hit.x, hit.y, hit.z, SoundEvents.PLAYER_ATTACK_CRIT, SoundSource.PLAYERS, 1.0f,
                1.2f + level.random.nextFloat() * 0.3f);
        level.playSound(null, hit.x, hit.y, hit.z, SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.PLAYERS, 0.9f,
                0.75f + level.random.nextFloat() * 0.2f);
        level.playSound(null, hit.x, hit.y, hit.z, SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, 0.3f, 1.9f);
    }

    public static ShazamAnim strikeAnim(int move) {
        return switch (move & 3) {
            case 0 -> ShazamAnim.MERCURY_JAB;
            case 1 -> ShazamAnim.MERCURY_CROSS;
            case 2 -> ShazamAnim.MERCURY_HOOK;
            default -> ShazamAnim.MERCURY_KICK;
        };
    }

    private static boolean isBoss(LivingEntity entity) {
        return entity instanceof WitherBoss || entity instanceof EnderDragon || entity.getMaxHealth() >= BOSS_HEALTH;
    }

    public static void forget(UUID id) {
        ACTIVE.remove(id);
        LAST_TOGGLE.remove(id);
    }
}
