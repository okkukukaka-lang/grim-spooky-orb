package com.shazammod.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.client.anim.ShazamPoses;

import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

import com.shazammod.ShazamMod;

/**
 * Kilau emas saat berubah: menyapu dada dulu, lalu lengan, kepala, dan kaki. Di tengah kilau itu
 * lambang, jubah, dan hood muncul. Saat kembali jadi manusia, kilaunya menyapu dengan urutan terbalik.
 * Skin pemain sendiri nggak diganti.
 */
public class SuitRevealLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation SHIMMER = ShazamMod.id("textures/entity/fx/weave.png");
    private static final int[] DELAY_IN = {0, 3, 6, 8};   // badan, lengan, kepala, kaki
    private static final int[] DELAY_OUT = {8, 6, 3, 0};
    private static final float FADE = 7f;

    public SuitRevealLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    private static ModelPart[] group(PlayerModel<AbstractClientPlayer> m, int index) {
        return switch (index) {
            case 0 -> new ModelPart[] {m.body, m.jacket};
            case 1 -> new ModelPart[] {m.rightArm, m.rightSleeve, m.leftArm, m.leftSleeve};
            case 2 -> new ModelPart[] {m.head, m.hat};
            default -> new ModelPart[] {m.rightLeg, m.rightPants, m.leftLeg, m.leftPants};
        };
    }

    /** 0-1: seberapa jauh bagian ini sudah terbentuk (atau luruh). */
    private static float progress(float t, boolean in, int index) {
        return Mth.clamp((t - (in ? DELAY_IN[index] : DELAY_OUT[index])) / FADE, 0f, 1f);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, AbstractClientPlayer player,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        float t = ShazamPoses.suitTicks(player, partialTick);
        if (t < 0f || player.isInvisible()) {
            return;
        }
        boolean in = ShazamPoses.suitIn(player);
        PlayerModel<AbstractClientPlayer> model = this.getParentModel();
        int[] tone = FormLook.of(player.getId()).suitShimmer;   // emas Shazam / emas membara Black Adam

        // Kilau emas di bagian yang sedang tersapu
        float scroll = ageInTicks * 0.02f;
        VertexConsumer shimmer = buffer.getBuffer(RenderType.energySwirl(SHIMMER, scroll % 1f, (scroll * 0.5f) % 1f));
        for (int g = 0; g < 4; g++) {
            float glow = Mth.sin(progress(t, in, g) * Mth.PI);
            if (glow <= 0.05f) {
                continue;
            }
            int color = 0xFF000000 | ((int) (tone[0] * glow) << 16) | ((int) (tone[1] * glow) << 8) | (int) (tone[2] * glow);
            float inflate = 1f + 0.14f * glow; // selubung cahaya yang tebal
            for (ModelPart part : group(model, g)) {
                part.xScale = inflate;
                part.yScale = inflate;
                part.zScale = inflate;
                part.render(poseStack, shimmer, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, color);
                part.xScale = 1f;
                part.yScale = 1f;
                part.zScale = 1f;
            }
        }
    }
}
