package com.shazammod.client.render;

import java.io.InputStream;
import java.util.Optional;

import org.slf4j.Logger;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.logging.LogUtils;

import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.util.Mth;

/**
 * Gambar lambang yang sudah dibaca: warna tiap piksel, dan cahaya di sekitarnya.
 * Dipakai lambang dada dan lambang punggung jubah. Tiap piksel yang tidak transparan jadi balok timbul.
 */
public final class EmblemImage {
    private static final Logger LOGGER = LogUtils.getLogger();
    public static final int GLOW_RANGE = 2;     // cahaya sampai 2 piksel di luar lambang
    public static final int MAX_SIZE = 64;
    private static final float SWEEP_PERIOD = 50f;   // kilatan menyapu tiap 2,5 detik

    public final int width;
    public final int height;
    private final int[] colors;   // ARGB, 0 = kosong
    private final float[] glow;   // (width + 2*GLOW_RANGE) x (height + 2*GLOW_RANGE)

    private EmblemImage(int width, int height, int[] colors, float[] glow) {
        this.width = width;
        this.height = height;
        this.colors = colors;
        this.glow = glow;
    }

    public int color(int x, int y) {
        return colors[y * width + x];
    }

    public boolean filled(int x, int y) {
        return x >= 0 && y >= 0 && x < width && y < height && colors[y * width + x] != 0;
    }

    /** Kuat cahaya di sel (gx, gy) pada grid yang diperluas GLOW_RANGE ke tiap sisi. */
    public float glow(int gx, int gy) {
        return glow[gy * (width + 2 * GLOW_RANGE) + gx];
    }

    /** Denyut cahaya, ditambah kilat saat lambang baru muncul (flash 0-1). */
    public static float pulse(float time, float flash) {
        return 0.6f + 0.25f * Mth.sin(time * 0.15f) + flash;
    }

    /** Kilatan putih yang menyapu lambang secara diagonal: 0-1 untuk piksel (x, y). */
    public float sweep(int x, int y, float time) {
        float phase = (time % SWEEP_PERIOD) / SWEEP_PERIOD * 1.6f - 0.3f;
        float along = (x + y) / (float) (width + height);
        return Math.max(0f, 1f - Math.abs(along - phase) / 0.12f);
    }

    /** Baca gambar lambang; null kalau file-nya nggak ada atau nggak bisa dibaca. */
    public static EmblemImage load(ResourceLocation location) {
        Optional<Resource> resource = Minecraft.getInstance().getResourceManager().getResource(location);
        if (resource.isEmpty()) {
            return null;
        }
        try (InputStream in = resource.get().open(); NativeImage image = NativeImage.read(in)) {
            int w = image.getWidth();
            int h = image.getHeight();
            if (w > MAX_SIZE || h > MAX_SIZE) {
                LOGGER.warn("Lambang {} terlalu besar ({}x{}), maksimal {}x{}", location, w, h, MAX_SIZE, MAX_SIZE);
                return null;
            }
            int[] c = new int[w * h];
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    int abgr = image.getPixelRGBA(x, y);
                    if ((abgr >>> 24) >= 128) {
                        int r = abgr & 0xFF, g = (abgr >> 8) & 0xFF, b = (abgr >> 16) & 0xFF;
                        c[y * w + x] = 0xFF000000 | (r << 16) | (g << 8) | b;
                    }
                }
            }
            int gw = w + 2 * GLOW_RANGE, gh = h + 2 * GLOW_RANGE;
            float[] g = new float[gw * gh];
            for (int gy = 0; gy < gh; gy++) {
                for (int gx = 0; gx < gw; gx++) {
                    int px = gx - GLOW_RANGE, py = gy - GLOW_RANGE;
                    if (inside(c, w, h, px, py)) {
                        continue;
                    }
                    int nearest = Integer.MAX_VALUE;
                    for (int dy = -GLOW_RANGE; dy <= GLOW_RANGE; dy++) {
                        for (int dx = -GLOW_RANGE; dx <= GLOW_RANGE; dx++) {
                            if (inside(c, w, h, px + dx, py + dy)) {
                                nearest = Math.min(nearest, Math.max(Math.abs(dx), Math.abs(dy)));
                            }
                        }
                    }
                    g[gy * gw + gx] = nearest == 1 ? 0.55f : nearest == 2 ? 0.2f : 0f;
                }
            }
            return new EmblemImage(w, h, c, g);
        } catch (Exception e) {
            LOGGER.warn("Gagal membaca lambang {}", location, e);
            return null;
        }
    }

    private static boolean inside(int[] c, int w, int h, int x, int y) {
        return x >= 0 && y >= 0 && x < w && y < h && c[y * w + x] != 0;
    }
}
