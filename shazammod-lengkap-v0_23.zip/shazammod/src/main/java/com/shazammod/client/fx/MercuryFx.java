package com.shazammod.client.fx;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.shazammod.ShazamClientState;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.flight.MercuryMode;
import com.shazammod.client.flight.ShazamFlight;
import com.shazammod.client.flight.WindSound;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * Efek Mode Kilat Mercury untuk semua pemain yang modenya menyala:
 * - listrik biru tebal merayap di badan, makin deras saat makin kencang;
 * - lari kencang: sambaran petir tebal yang terseret di belakang mengikuti lintasan lari, busur listrik yang melompat
 *   antar-bayangan berjejak (lihat SpeedForce), pendar biru di sekitar badan, jejak listrik di kaki, debu
 *   tersibak dan terseret udara di belakang kaki, bongkahan tanah sungguhan yang terlempar, percikan listrik di
 *   tiap langkah, cipratan & riak saat lari di atas air;
 * - mulai melesat dari diam: hentakan udara, debu tersembur ke belakang, tanah retak;
 * - mengerem atau berbelok tajam: kaki menggerus tanah, percikan dan debu terlempar ke depan;
 * - tiap pukulan: kilatan, gelombang kejut searah pukulan, udara terdorong, percikan, dan busur listrik.
 * Pemain sendiri di sudut pandang orang pertama: yang menempel di badan nggak digambar (menutupi layar),
 * diganti garis kecepatan, pandangan yang melebar, dan suara angin.
 */
public final class MercuryFx {
    private MercuryFx() {}

    private static final int COLOR = ShazamFx.MERCURY;   // biru muda
    private static final int WHITE = 0xEAFBFF;
    private static final double FAST = 0.6;               // blok/tick: mulai terhitung kencang
    private static final Vec3 UP = new Vec3(0, 1, 0);

    private static final class State {
        Lightning.Crackle crackle;
        SpeedForce force;
        Fx.Trail feet;
        Vec3 lastVel = Vec3.ZERO;
        int ticks;
        int lastCalm = -100;
        int lastBurst = -100;
        int lastSkid = -100;
    }

    private static final Map<Integer, State> STATES = new HashMap<>();
    private static WindSound wind;

    public static void clear() {
        STATES.clear();
        wind = null;
    }

    public static void tick(ClientLevel level) {
        Minecraft mc = Minecraft.getInstance();
        Iterator<Map.Entry<Integer, State>> it = STATES.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, State> e = it.next();
            if (!(level.getEntity(e.getKey()) instanceof AbstractClientPlayer p) || !on(p)) {
                if (e.getValue().crackle != null) {
                    e.getValue().crackle.stop();
                }
                it.remove();
            }
        }
        for (AbstractClientPlayer player : level.players()) {
            if (on(player)) {
                tickPlayer(level, mc, player, STATES.computeIfAbsent(player.getId(), id -> new State()));
            }
        }
    }

    private static boolean on(AbstractClientPlayer p) {
        return ShazamClientState.isTransformed(p.getId()) && ShazamClientState.isMercury(p.getId()) && !p.isInvisible();
    }

    private static void tickPlayer(ClientLevel level, Minecraft mc, AbstractClientPlayer p, State s) {
        s.ticks++;
        RandomSource r = level.random;
        boolean self = p == mc.player;
        boolean firstPerson = self && mc.options.getCameraType().isFirstPerson();
        Vec3 vel = new Vec3(p.getX() - p.xo, p.getY() - p.yo, p.getZ() - p.zo);
        double total = vel.length();
        double speed = Math.sqrt(vel.x * vel.x + vel.z * vel.z);
        Vec3 dir = speed > 1.0E-4 ? new Vec3(vel.x / speed, 0, vel.z / speed) : Vec3.ZERO;
        Vec3 change = vel.subtract(s.lastVel);
        double prev = Math.sqrt(s.lastVel.x * s.lastVel.x + s.lastVel.z * s.lastVel.z);
        Vec3 prevDir = prev > 1.0E-4 ? new Vec3(s.lastVel.x / prev, 0, s.lastVel.z / prev) : Vec3.ZERO;
        s.lastVel = vel;
        float k = (float) Math.min(1.0, total / 2.6);

        // listrik yang merayap di badan: tebal, deras, busurnya makin panjang saat makin kencang
        if (s.crackle == null || !s.crackle.active()) {
            s.crackle = new Lightning.Crackle(p, COLOR, 1.5f, 0.058f, 20 * 60 * 10);
            Vfx.add(s.crackle);
        }
        s.crackle.strength(firstPerson ? 0f : 0.4f + 0.6f * k).reach(0.9 + 0.35 * k);

        boolean ground = p.onGround();
        boolean water = self ? MercuryMode.isOnWater() : waterBelow(level, p);
        if (total > FAST) {
            // petir speed force: sambaran tebal yang terseret mengikuti lintasan + listrik antar-bayangan
            if (s.force == null || !s.force.following()) {
                s.force = new SpeedForce(p);
                Vfx.add(s.force);
            }
            s.force.sustain(2);
            s.force.strength(0.3f + 0.7f * (float) Math.min(1.0, (total - FAST) / 1.4));
            // jejak listrik di kaki (menyala di tanah sepanjang jalur lari)
            if (s.feet == null || !s.feet.following()) {
                s.feet = new Fx.Trail(p, pt -> p.getPosition(pt).add(0, 0.1, 0), COLOR, 0.34f, 4, 3, true);
                Vfx.add(s.feet);
            }
            s.feet.sustain(2);
            // busur petir yang menyambar dari badan ke belakang, makin banyak saat makin kencang
            int arcs = total > 1.8 ? 2 : 1;
            for (int i = 0; i < arcs && !(firstPerson && i == 0 && r.nextBoolean()); i++) {
                double h = (0.25 + r.nextDouble() * 0.6) * p.getBbHeight();
                Vec3 from = p.position().add(0, h, 0);
                double back = 1.0 + r.nextDouble() * 1.4;   // pendek: kamera F5 ada di belakang
                Vec3 to = from.add(-vel.x / total * back + (r.nextDouble() - 0.5) * 1.0, (r.nextDouble() - 0.5) * 1.1,
                        -vel.z / total * back + (r.nextDouble() - 0.5) * 1.0);
                Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(from), Lightning.Anchor.fixed(to), r.nextInt(3) == 0 ? WHITE : COLOR,
                        0.058f, 2 + r.nextInt(2), 1, 1, 0.32));
            }
            if (water) {
                spray(p, dir, speed, r, s);
            } else if (ground) {
                wake(level, p, dir, speed, r, s);
            }
            for (int i = 0; i < 2; i++) {   // percikan listrik di tiap langkah
                Vec3 v = ShazamFx.randomDir(r).scale(0.14).add(-dir.x * speed * 0.08, 0.1, -dir.z * speed * 0.08);
                Vfx.spark(p.getX(), p.getY() + 0.1, p.getZ(), v.x, v.y, v.z, r.nextBoolean() ? COLOR : WHITE, 0.06f,
                        7 + r.nextInt(5), p.getY());
            }
            if (self) {
                ScreenFx.speedLines((float) Math.min(1.0, (total - FAST) / 1.6));
                if (!ShazamFlight.isFlying() && (wind == null || wind.isStopped()) && p instanceof LocalPlayer local) {
                    wind = new WindSound(local, () -> movement(local),
                            () -> MercuryMode.isActive() && !ShazamFlight.isFlying());
                    mc.getSoundManager().play(wind);
                }
            }
        }
        // mulai melesat dari diam: hentakan udara & debu tersembur ke belakang
        if (speed < 0.35) {
            s.lastCalm = s.ticks;
        } else if (speed > 0.9 && ground && s.ticks - s.lastCalm <= 8 && s.ticks - s.lastBurst > 20) {
            s.lastBurst = s.ticks;
            burst(level, p, dir, r, self);
        }
        // mengerem atau berbelok tajam: kaki menggerus tanah
        if ((ground || water) && prev > 0.8 && change.length() > 0.22 && s.ticks - s.lastSkid > 1) {
            s.lastSkid = s.ticks;
            skid(level, p, prevDir, r, water);
        }
    }

    private static double movement(LocalPlayer p) {
        double dx = p.getX() - p.xo, dy = p.getY() - p.yo, dz = p.getZ() - p.zo;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    /** Debu tersibak di belakang kaki dan terseret udara di belakang badan; bongkahan tanah terlempar saat sangat kencang. */
    private static void wake(ClientLevel level, AbstractClientPlayer p, Vec3 dir, double speed, RandomSource r, State s) {
        int dust = dustColor(level, p);
        for (int i = 0, n = Vfx.count(1 + speed * 0.8); i < n; i++) {
            double back = 0.3 + r.nextDouble() * 0.6, side = (r.nextDouble() - 0.5) * 0.6;
            double x = p.getX() - dir.x * back - dir.z * side, z = p.getZ() - dir.z * back + dir.x * side;
            double vx = dir.x * speed * 0.18 + (r.nextDouble() - 0.5) * 0.06, vz = dir.z * speed * 0.18 + (r.nextDouble() - 0.5) * 0.06;
            Vfx.dust(x, p.getY() + 0.1, z, vx, 0.03 + speed * 0.025 + r.nextDouble() * 0.03, vz, dust,
                    (float) (0.35 + speed * 0.12 + r.nextDouble() * 0.2), 16 + r.nextInt(10));
        }
        if (speed > 1.6 && s.ticks % 5 == 0) {   // bongkahan tanah sungguhan (tekstur blok di bawah kaki)
            Ground.Map map = ShazamFx.ground(level, p.position(), 0.8);
            if (map != null && map.found) {
                Vfx.add(new Ground.Debris(map.center(p.position()), map, 2, 0.1, 0.22, 0.3, 24));
            }
        }
    }

    /** Lari di atas air: cipratan yang jatuh lagi, kabut air, dan riak melebar di permukaan. */
    private static void spray(AbstractClientPlayer p, Vec3 dir, double speed, RandomSource r, State s) {
        for (int i = 0, n = Vfx.count(1 + speed); i < n; i++) {
            double back = 0.2 + r.nextDouble() * 0.5, side = (r.nextDouble() - 0.5) * 0.5;
            double x = p.getX() - dir.x * back - dir.z * side, z = p.getZ() - dir.z * back + dir.x * side;
            double up = 0.18 + r.nextDouble() * 0.22 + speed * 0.05;
            Vfx.spark(x, p.getY() + 0.05, z, dir.x * speed * 0.12 + (r.nextDouble() - 0.5) * 0.12, up,
                    dir.z * speed * 0.12 + (r.nextDouble() - 0.5) * 0.12, 0xDDEEFF, 0.04f, 12 + r.nextInt(6), p.getY() - 0.2);
            if (i % 2 == 0) {
                Vfx.dust(x, p.getY() + 0.1, z, dir.x * speed * 0.1, 0.03, dir.z * speed * 0.1, 0xE6F2FF,
                        (float) (0.3 + r.nextDouble() * 0.25), 12 + r.nextInt(6));
            }
        }
        if (s.ticks % 3 == 0) {
            Vfx.add(new Fx.Wave(new Vec3(p.getX(), p.getY() + 0.02, p.getZ()), UP, 1.6 + speed * 0.4, 0.18, 0xCFE8FF, 16,
                    0.35f, 0f, null, true));
        }
    }

    /** Mulai melesat: hentakan udara dan debu tersembur ke belakang, tanah di bawah kaki retak. */
    private static void burst(ClientLevel level, AbstractClientPlayer p, Vec3 dir, RandomSource r, boolean self) {
        if (dir.lengthSqr() < 1.0E-4) {
            return;
        }
        Vec3 back = dir.scale(-1);
        Vec3 c = p.position().add(0, 0.9, 0);
        Vfx.add(new Fx.Flash(c, 1.0f, COLOR, 6, 0.7f));
        Vfx.add(new Fx.Cone(c.add(back.scale(0.4)), back, 3.2, 0.55, 0xEAF4FF, 10, 0.4f, 2.0, true));
        Vfx.add(new Fx.Ripple(c, back, 1.6, 0.4, 2.2, 0.25, WHITE, 9, 0.6f, false));
        int dust = dustColor(level, p);
        for (int i = 0, n = Vfx.count(10); i < n; i++) {
            Vec3 v = back.scale(0.25 + r.nextDouble() * 0.3).add((r.nextDouble() - 0.5) * 0.2, 0.04 + r.nextDouble() * 0.06,
                    (r.nextDouble() - 0.5) * 0.2);
            Vfx.dust(p.getX(), p.getY() + 0.15, p.getZ(), v.x, v.y, v.z, dust, 0.5f + r.nextFloat() * 0.4f, 20 + r.nextInt(12));
        }
        Ground.Map map = ShazamFx.ground(level, p.position(), 1.6);
        if (map != null && map.found) {
            Vfx.add(new Ground.Cracks(map.center(p.position()), map, 4, 0.9f, 70, 14, COLOR, r.nextLong()));
        }
        level.playLocalSound(p.getX(), p.getY(), p.getZ(), SoundEvents.PHANTOM_SWOOP, SoundSource.PLAYERS, 0.9f, 1.7f, false);
        if (self) {
            FovKick.kick(0.1f);
            CameraShake.add(0.08f);
        }
    }

    /** Mengerem/berbelok tajam: percikan gesekan dan debu terlempar ke depan (searah gerak sebelumnya). */
    private static void skid(ClientLevel level, AbstractClientPlayer p, Vec3 dir, RandomSource r, boolean water) {
        for (int i = 0, n = Vfx.count(3); i < n; i++) {
            Vec3 v = dir.scale(0.2 + r.nextDouble() * 0.25).add((r.nextDouble() - 0.5) * 0.25, 0.08 + r.nextDouble() * 0.12,
                    (r.nextDouble() - 0.5) * 0.25);
            int c = water ? 0xDDEEFF : (r.nextInt(3) == 0 ? WHITE : 0xFFD9A0);
            Vfx.spark(p.getX(), p.getY() + 0.05, p.getZ(), v.x, v.y, v.z, c, 0.045f, 8 + r.nextInt(6), p.getY() - 0.1);
        }
        Vfx.dust(p.getX(), p.getY() + 0.1, p.getZ(), dir.x * 0.15, 0.03, dir.z * 0.15, water ? 0xE6F2FF : dustColor(level, p),
                0.55f, 18);
    }

    // ------------------------------------------------------------------ dipicu animasi

    /** Satu pukulan secepat kilat yang kena (hit = titik kena di badan musuh). */
    public static void strike(AbstractClientPlayer caster, Vec3 hit, boolean self) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) {
            return;
        }
        RandomSource r = level.random;
        Vec3 from = caster.position().add(0, caster.getBbHeight() * 0.62, 0);
        Vec3 dir = hit.subtract(from);
        dir = dir.lengthSqr() < 1.0E-4 ? caster.getViewVector(1f) : dir.normalize();
        Vfx.add(new Fx.Flash(hit, 1.6f, WHITE, 6, 1f));
        Vfx.add(new Fx.Flash(hit, 0.9f, COLOR, 10, 0.8f));
        Vfx.add(new Fx.Ripple(hit, dir, 1.6, 0.25, 1.9, 0.22, 0xF2FCFF, 8, 0.85f, false));   // gelombang kejut searah pukulan
        Vfx.add(new Fx.Cone(hit, dir, 2.6, 0.45, 0xEAF6FF, 8, 0.4f, 2.0, true));          // udara terdorong ke belakang musuh
        for (int i = 0, n = Vfx.count(12); i < n; i++) {
            Vec3 v = dir.scale(0.35 + r.nextDouble() * 0.3).add(ShazamFx.randomDir(r).scale(0.2));
            Vfx.spark(hit.x, hit.y, hit.z, v.x, v.y, v.z, i % 3 == 0 ? 0xFFFFFF : COLOR, 0.05f, 6 + r.nextInt(6), hit.y - 2.0);
        }
        for (int i = 0; i < 2; i++) {
            Vfx.glint(hit.x + (r.nextDouble() - 0.5) * 0.5, hit.y + (r.nextDouble() - 0.5) * 0.5, hit.z + (r.nextDouble() - 0.5) * 0.5,
                    WHITE, 0.32f, 6 + r.nextInt(4));
        }
        // busur listrik dari kepalan ke titik kena, lalu memercik keluar dari badan musuh
        Vec3 fist = ShazamPoses.handPos(caster, true, 1f);
        Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(fist), Lightning.Anchor.fixed(hit), COLOR, 0.075f, 3, 1, 1, 0.25));
        for (int i = 0; i < 3; i++) {
            Vec3 end = hit.add(dir.scale(0.6)).add(ShazamFx.randomDir(r).scale(1.1));
            Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(hit), Lightning.Anchor.fixed(end), i == 0 ? WHITE : COLOR, 0.06f, 3, 1, 1,
                    0.35));
        }
        if (self) {
            CameraShake.add(0.1f);
            ScreenFlash.flash(0.05f, 0xE8F8FF);
            FovKick.punch(-0.03f);
        }
    }

    /** Mengumpulkan tenaga sebelum menyala: cahaya biru terhisap ke badan, listrik kecil merambat dari tanah. */
    public static void charge(AbstractClientPlayer caster, int t) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) {
            return;
        }
        RandomSource r = level.random;
        Vec3 chest = caster.position().add(0, 1.0 * caster.getScale(), 0);
        for (int i = 0, n = Vfx.count(5); i < n; i++) {
            Vec3 off = ShazamFx.randomDir(r).scale(1.6 + r.nextDouble() * 0.8);
            Vfx.mote(chest.x + off.x, chest.y + off.y * 0.7, chest.z + off.z, -off.x * 0.2, -off.y * 0.14, -off.z * 0.2,
                    i % 2 == 0 ? COLOR : WHITE, 0.07f, 5);
        }
        if (t % 2 == 0) {
            double a = r.nextDouble() * Math.PI * 2.0, d = 1.2 + r.nextDouble();
            Vec3 from = caster.position().add(Math.cos(a) * d, 0.05, Math.sin(a) * d);
            Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(from), Lightning.Anchor.on(caster, 0, 1.0, 0), COLOR, 0.05f, 2, 1, 1,
                    0.25));
        }
    }

    /** Mode menyala: listrik meledak dari badan, gelombang di tanah, busur listrik merambat keluar. */
    public static void on(AbstractClientPlayer caster, boolean self) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) {
            return;
        }
        Vec3 c = caster.position();
        Vec3 chest = c.add(0, 1.1 * caster.getScale(), 0);
        Vfx.add(new Fx.Flash(chest, 2.0f, COLOR, 9, 1f));
        Vfx.add(new Fx.Bubble(chest, 2.4, 0xBFF6FF, 9, 0.55f, 1.0, 2.4, true));
        Ground.Map map = ShazamFx.ground(level, c, 3.2);
        if (map != null) {
            Vfx.add(new Fx.Wave(map.center(c), UP, 3.2, 0.3, COLOR, 12, 0.85f, 0.1f, map));
            ShazamFx.dustPuffs(level, map.center(c), map.dustColor(level, c), 8, 0.8, 0.12);
        }
        ShazamFx.groundArcs(level, c, 6, 3.2, COLOR, 6);
        ShazamFx.ringOfSparks(level, chest, 22, COLOR, 0.4);
        Vfx.add(new Lightning.Crackle(caster, WHITE, 3.0f, 0.05f, 12));   // listrik meledak sesaat
        if (self) {
            ScreenFx.vignette(0.35f, 0x05213A, 8);
            ScreenFlash.flash(0.12f, 0xDDF8FF);
            FovKick.kick(0.12f);
            CameraShake.add(0.15f);
        }
    }

    /** Mode mati: listrik padam memercik. */
    public static void off(AbstractClientPlayer caster) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) {
            return;
        }
        Vec3 chest = caster.position().add(0, 1.1 * caster.getScale(), 0);
        Vfx.add(new Fx.Flash(chest, 1.2f, COLOR, 8, 0.6f));
        ShazamFx.ringOfSparks(level, chest, 10, COLOR, 0.25);
    }

    // ------------------------------------------------------------------ alat bantu

    private static int dustColor(ClientLevel level, AbstractClientPlayer p) {
        BlockPos pos = p.blockPosition().below();
        BlockState state = level.getBlockState(pos);
        int c = state.getMapColor(level, pos).col;
        return c == 0 ? 0x8A7A66 : Draw.mix(c, 0xB8AE9C, 0.35);
    }

    private static boolean waterBelow(ClientLevel level, AbstractClientPlayer p) {
        return !p.isInWater() && level.getFluidState(BlockPos.containing(p.getX(), p.getY() - 0.25, p.getZ())).is(FluidTags.WATER);
    }
}
