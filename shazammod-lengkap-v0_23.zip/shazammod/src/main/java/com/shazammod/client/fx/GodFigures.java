package com.shazammod.client.fx;

import com.shazammod.client.fx.GodMesh.Frame;

/**
 * Bentuk enam dewa (murni Java): tiap dewa punya badan, pakaian, dan pusakanya sendiri, digerakkan rangka
 * sederhana (panggul - dada - kepala, lengan & kaki dengan IK dua tulang).
 *
 * S - Solomon : raja bijak berjubah ungu, mahkota emas, janggut panjang, kitab terbuka, segel di telapak tangan.
 * H - Hercules: berotot besar, berkerudung kepala singa, gada kayu di bahu.
 * A - Atlas   : raksasa berlutut memanggul bola langit bercincin emas.
 * Z - Zeus    : raja dewa berjanggut putih, mahkota daun salam, petir di tangan kanan siap dilempar.
 * A - Achilles: pahlawan berhelm jambul merah, perisai bundar, tombak, jubah merah.
 * M - Mercury : ramping, topi bersayap, sandal bersayap, tongkat caduceus, berjinjit menunjuk langit.
 *
 * Ruang dewa: lihat {@link GodMesh}. Ukuran dasar tinggi badan 1,9; di dunia dikali {@link #SCALE}.
 */
public final class GodFigures {
    private GodFigures() {}

    public static final int SOLOMON = 0;
    public static final int HERCULES = 1;
    public static final int ATLAS = 2;
    public static final int ZEUS = 3;
    public static final int ACHILLES = 4;
    public static final int MERCURY = 5;
    /** Jumlah dewa yang datang dalam satu ritual (satu jajaran). */
    public static final int COUNT = 6;

    // Dewa-dewa Mesir milik Black Adam (jajaran kedua, lihat EgyptFigures): S-H-A-Z-A-M yang lain
    public static final int SHU = 6;
    public static final int HERU = 7;
    public static final int AMON = 8;
    public static final int ZEHUTI = 9;
    public static final int ATON = 10;
    public static final int MEHEN = 11;
    /** Dewa pertama jajaran Mesir. */
    public static final int EGYPT = 6;
    /** Jumlah semua dewa (dua jajaran). */
    public static final int TOTAL = 12;

    /** Warna cahaya tiap dewa (sama dengan warna totem/skill-nya). */
    public static final int[] AURA = {0xB48CFF, 0xC8F59A, 0xFFA45C, 0xFFD45A, 0xFFC24A, 0x86F0FF,
            // Shu (udara, biru langit pucat), Heru (elang, emas membara), Amon (lapis lazuli), Zehuti (bulan, hijau
            // malakit), Aton (cakram matahari, emas terang), Mehen (ular, merah akik)
            0xA8DCFF, 0xFFA640, 0x6E9CFF, 0x7FF2C4, 0xFFD54A, 0xFF6A4A};
    /** Blok per satuan dasar (tinggi dewa di dunia = 1,9 x ini). */
    public static final float[] SCALE = {1.68f, 1.7f, 1.74f, 1.76f, 1.68f, 1.62f,
            1.66f, 1.72f, 1.76f, 1.7f, 1.7f, 1.74f};

    /** Jajaran (0 = dewa Shazam, EGYPT = dewa Mesir Black Adam) + urutan 0..5 = id dewa. */
    public static int id(int pantheon, int slot) {
        return pantheon + slot;
    }

    /** Urutan dewa di jajarannya (0..5, S-H-A-Z-A-M dari kiri ke kanan). */
    public static int slot(int god) {
        return god % COUNT;
    }

    /** Keadaan gerak satu dewa (diisi GodShow). */
    public static final class Pose {
        /** Waktu ritual (tick): napas, kain berkibar. */
        public float time;
        /** Tick sejak dewa ini mulai muncul (pose masuk). */
        public float tau = 1000f;
        /** 0..1: pusaka diarahkan ke kepalan. */
        public float converge;
        /** Titik kepalan di ruang dewa (ukuran dasar). */
        public float aimX = 0f, aimY = 1.5f, aimZ = 2.6f;

        public Pose set(Pose o) {
            time = o.time;
            tau = o.tau;
            converge = o.converge;
            aimX = o.aimX;
            aimY = o.aimY;
            aimZ = o.aimZ;
            return this;
        }
    }

    public static void build(int god, Pose p, GodMesh m) {
        m.clear();
        switch (god) {
            case SOLOMON -> solomon(m, p);
            case HERCULES -> hercules(m, p);
            case ATLAS -> atlas(m, p);
            case ZEUS -> zeus(m, p);
            case ACHILLES -> achilles(m, p);
            case SHU -> EgyptFigures.shu(m, p);
            case HERU -> EgyptFigures.heru(m, p);
            case AMON -> EgyptFigures.amon(m, p);
            case ZEHUTI -> EgyptFigures.zehuti(m, p);
            case ATON -> EgyptFigures.aton(m, p);
            case MEHEN -> EgyptFigures.mehen(m, p);
            default -> mercury(m, p);
        }
    }

    // ================================================================== ukuran badan

    static final class Body {
        double hip = 1.0, waist = 0.10, chestLen = 0.46;
        double shoulderX = 0.20, shoulderY = 0.40, shoulderZ = -0.01;
        double neck = 0.07, neckR = 0.055;
        double headRx = 0.097, headRy = 0.125, headRz = 0.11;
        double upper = 0.30, fore = 0.27, thigh = 0.45, shin = 0.44, hipX = 0.095;
        double limb = 1.0;
        double chestRx = 0.19, chestRz = 0.125, waistRx = 0.15, waistRz = 0.10, hipRx = 0.165, hipRz = 0.11;
    }

    private static final Body SOLOMON_BODY = new Body();
    private static final Body HERCULES_BODY = new Body();
    private static final Body ATLAS_BODY = new Body();
    private static final Body ZEUS_BODY = new Body();
    private static final Body ACHILLES_BODY = new Body();
    private static final Body MERCURY_BODY = new Body();

    static {
        Body b = SOLOMON_BODY;
        b.chestRx = 0.17; b.chestRz = 0.115; b.waistRx = 0.15; b.waistRz = 0.105; b.hipRx = 0.16; b.hipRz = 0.11;
        b.shoulderX = 0.19; b.headRx = 0.095;

        b = HERCULES_BODY;
        b.hip = 1.03; b.chestRx = 0.245; b.chestRz = 0.16; b.waistRx = 0.19; b.waistRz = 0.13; b.hipRx = 0.2; b.hipRz = 0.135;
        b.shoulderX = 0.245; b.limb = 1.38; b.neckR = 0.075; b.headRx = 0.1;

        b = ATLAS_BODY;
        b.chestRx = 0.265; b.chestRz = 0.17; b.waistRx = 0.21; b.waistRz = 0.14; b.hipRx = 0.21; b.hipRz = 0.14;
        b.shoulderX = 0.27; b.limb = 1.45; b.neckR = 0.082; b.headRx = 0.102; b.upper = 0.31; b.fore = 0.28;

        b = ZEUS_BODY;
        b.hip = 1.04; b.chestRx = 0.23; b.chestRz = 0.15; b.waistRx = 0.18; b.waistRz = 0.125; b.hipRx = 0.19; b.hipRz = 0.13;
        b.shoulderX = 0.235; b.limb = 1.22; b.neckR = 0.068; b.headRx = 0.1;

        b = ACHILLES_BODY;
        b.hip = 1.03; b.chestRx = 0.21; b.chestRz = 0.14; b.waistRx = 0.165; b.waistRz = 0.115; b.hipRx = 0.175; b.hipRz = 0.12;
        b.shoulderX = 0.215; b.limb = 1.12; b.neckR = 0.062;

        b = MERCURY_BODY;
        b.chestRx = 0.172; b.chestRz = 0.112; b.waistRx = 0.138; b.waistRz = 0.098; b.hipRx = 0.152; b.hipRz = 0.104;
        b.shoulderX = 0.19; b.limb = 0.95; b.neckR = 0.058; b.headRx = 0.094;
    }

    // ================================================================== rangka

    static final class Rig {
        final Frame pelvis = new Frame(), chest = new Frame(), head = new Frame();
        final Frame f1 = new Frame(), f2 = new Frame(), f3 = new Frame();
        final double[] shL = new double[3], shR = new double[3], elL = new double[3], elR = new double[3];
        final double[] wrL = new double[3], wrR = new double[3];
        final double[] hpL = new double[3], hpR = new double[3], knL = new double[3], knR = new double[3];
        final double[] anL = new double[3], anR = new double[3];
        double hc;
        Body b;

        /** Panggul di (x, hip + y, z), putar (derajat): yaw, condong ke depan, miring; dada: bungkuk, samping, putar; kepala. */
        void torso(Body body, double x, double y, double z, double yaw, double lean, double roll,
                   double bend, double side, double twist, double headPitch, double headYaw, double headRoll) {
            b = body;
            pelvis.identity().at(x, body.hip + y, z).rotY(yaw).rotX(lean).rotZ(roll);
            chest.set(pelvis).move(0, body.waist, 0).rotX(bend).rotZ(side).rotY(twist);
            head.set(chest).move(0, body.chestLen + body.neck, 0.01).rotX(headPitch).rotY(headYaw).rotZ(headRoll);
            chest.point(body.shoulderX, body.shoulderY, body.shoulderZ, shL, 0);
            chest.point(-body.shoulderX, body.shoulderY, body.shoulderZ, shR, 0);
            pelvis.point(body.hipX, -0.045, 0, hpL, 0);
            pelvis.point(-body.hipX, -0.045, 0, hpR, 0);
            hc = body.headRy * 0.88;
        }

        void armL(double tx, double ty, double tz, double px, double py, double pz) {
            ik(shL, tx, ty, tz, b.upper, b.fore, px, py, pz, elL, wrL);
        }

        void armR(double tx, double ty, double tz, double px, double py, double pz) {
            ik(shR, tx, ty, tz, b.upper, b.fore, px, py, pz, elR, wrR);
        }

        void legL(double tx, double ty, double tz, double px, double py, double pz) {
            ik(hpL, tx, ty, tz, b.thigh, b.shin, px, py, pz, knL, anL);
        }

        void legR(double tx, double ty, double tz, double px, double py, double pz) {
            ik(hpR, tx, ty, tz, b.thigh, b.shin, px, py, pz, knR, anR);
        }
    }

    static final Rig RIG = new Rig();

    /**
     * IK dua tulang: dari pangkal s ke sasaran t (dipotong kalau kejauhan), siku/lutut ke arah pole p.
     * Hasil: sendi tengah (mid) dan ujung (end).
     */
    static void ik(double[] s, double tx, double ty, double tz, double l1, double l2, double px, double py, double pz,
                   double[] mid, double[] end) {
        double dx = tx - s[0], dy = ty - s[1], dz = tz - s[2];
        double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (d < 1.0E-6) {
            dx = 0; dy = -1; dz = 0; d = 1;
        }
        double ux = dx / d, uy = dy / d, uz = dz / d;
        double dc = Math.max(Math.abs(l1 - l2) + 0.01, Math.min((l1 + l2) * 0.998, d));
        double a = (l1 * l1 - l2 * l2 + dc * dc) / (2.0 * dc);
        double h = Math.sqrt(Math.max(0.0, l1 * l1 - a * a));
        double pd = px * ux + py * uy + pz * uz;
        double qx = px - ux * pd, qy = py - uy * pd, qz = pz - uz * pd;
        double ql = Math.sqrt(qx * qx + qy * qy + qz * qz);
        if (ql < 1.0E-6) {
            qx = Math.abs(ux) < 0.9 ? 1 : 0;
            qy = Math.abs(ux) < 0.9 ? 0 : 1;
            qz = 0;
            pd = qx * ux + qy * uy;
            qx -= ux * pd; qy -= uy * pd; qz -= uz * pd;
            ql = Math.sqrt(qx * qx + qy * qy + qz * qz);
        }
        qx /= ql; qy /= ql; qz /= ql;
        mid[0] = s[0] + ux * a + qx * h;
        mid[1] = s[1] + uy * a + qy * h;
        mid[2] = s[2] + uz * a + qz * h;
        end[0] = s[0] + ux * dc;
        end[1] = s[1] + uy * dc;
        end[2] = s[2] + uz * dc;
    }

    // ================================================================== alat bantu angka

    static double clamp01(double v) {
        return v < 0 ? 0 : (v > 1 ? 1 : v);
    }

    static double smooth(double v) {
        v = clamp01(v);
        return v * v * (3 - 2 * v);
    }

    static double outCubic(double v) {
        v = clamp01(v);
        double u = 1 - v;
        return 1 - u * u * u;
    }

    static double outBack(double v) {
        v = clamp01(v);
        double c = 1.7;
        double u = v - 1;
        return 1 + (c + 1) * u * u * u + c * u * u;
    }

    static double lerp(double t, double a, double b) {
        return a + (b - a) * t;
    }

    /** Arah satuan dari a ke b ditulis ke out. */
    static void dir(double[] a, double bx, double by, double bz, double[] out) {
        double dx = bx - a[0], dy = by - a[1], dz = bz - a[2];
        double l = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (l < 1.0E-9) {
            out[0] = 0; out[1] = 0; out[2] = 1;
            return;
        }
        out[0] = dx / l; out[1] = dy / l; out[2] = dz / l;
    }

    // ================================================================== bagian badan

    /** Badan (dada sampai selangkangan) dari tumpukan cincin yang mengikuti panggul & dada. */
    static void torso(GodMesh m, Rig r, int color, float op, float gl) {
        Body b = r.b;
        int n = 9;
        double[] px = new double[n], py = new double[n], pz = new double[n], ax = new double[n * 3], az = new double[n * 3];
        double[] rx = new double[n], rz = new double[n];
        ringAt(r.chest, 0, b.chestLen + 0.005, -0.005, b.neckR * 1.1, b.neckR, px, py, pz, ax, az, rx, rz);
        ringAt(r.chest, 1, b.chestLen - 0.045, 0.0, b.shoulderX * 0.84, b.chestRz * 0.8, px, py, pz, ax, az, rx, rz);
        ringAt(r.chest, 2, b.chestLen - 0.12, 0.006, b.chestRx, b.chestRz * 0.95, px, py, pz, ax, az, rx, rz);
        ringAt(r.chest, 3, b.chestLen * 0.55, 0.008, b.chestRx * 0.97, b.chestRz, px, py, pz, ax, az, rx, rz);
        ringAt(r.chest, 4, b.chestLen * 0.25, 0.004, (b.chestRx + b.waistRx) * 0.5, (b.chestRz + b.waistRz) * 0.5,
                px, py, pz, ax, az, rx, rz);
        ringAt(r.chest, 5, 0.0, 0.0, b.waistRx, b.waistRz, px, py, pz, ax, az, rx, rz);
        ringAt(r.pelvis, 6, -0.04, -0.004, b.hipRx, b.hipRz, px, py, pz, ax, az, rx, rz);
        ringAt(r.pelvis, 7, -0.13, 0.0, b.hipRx * 0.72, b.hipRz * 0.8, px, py, pz, ax, az, rx, rz);
        ringAt(r.pelvis, 8, -0.175, 0.0, 0.01, 0.01, px, py, pz, ax, az, rx, rz);
        m.mat(color, op, gl).rings(px, py, pz, ax, az, rx, rz, n, 12, null);
        // leher
        double[] neck = new double[6];
        r.chest.point(0, b.chestLen - 0.04, -0.005, neck, 0);
        r.head.point(0, 0.05, 0.0, neck, 3);
        m.tube(neck, new double[] {b.neckR, b.neckR * 0.92}, 2, 8, false, r.chest.zx, r.chest.zy, r.chest.zz, 1.0);
    }

    private static void ringAt(Frame f, int k, double ly, double lz, double rxv, double rzv, double[] px, double[] py,
                               double[] pz, double[] ax, double[] az, double[] rx, double[] rz) {
        px[k] = f.px(0, ly, lz);
        py[k] = f.py(0, ly, lz);
        pz[k] = f.pz(0, ly, lz);
        ax[k * 3] = f.xx; ax[k * 3 + 1] = f.xy; ax[k * 3 + 2] = f.xz;
        az[k * 3] = f.zx; az[k * 3 + 1] = f.zy; az[k * 3 + 2] = f.zz;
        rx[k] = rxv;
        rz[k] = rzv;
    }

    /** Otot dada, perut, bahu, dan trapezius untuk dewa yang kekar. */
    static void muscles(GodMesh m, Rig r, int color, float op, float gl, double size) {
        Body b = r.b;
        m.mat(color, op, gl);
        for (int s = -1; s <= 1; s += 2) {
            m.ellipsoid(r.chest, s * 0.072 * size, b.chestLen * 0.7, b.chestRz * 0.78, 0.088 * size, 0.06 * size, 0.05, 8, 5);
            m.ellipsoid(r.chest, s * 0.1 * size, b.chestLen - 0.025, -0.02, 0.075 * size, 0.04, 0.055, 6, 4);
        }
        m.ellipsoid(r.chest, 0, b.chestLen * 0.3, b.waistRz * 0.8, 0.075 * size, 0.12, 0.045, 7, 5);
    }

    /** Bulatan bahu. */
    static void deltoids(GodMesh m, Rig r, int color, float op, float gl, double size) {
        m.mat(color, op, gl);
        for (int s = -1; s <= 1; s += 2) {
            double[] sh = s > 0 ? r.shL : r.shR;
            Frame f = r.f1.set(r.chest).at(sh[0], sh[1], sh[2]).move(s * 0.015, 0.012, 0);
            m.ellipsoid(f, 0, 0, 0, 0.072 * size, 0.078 * size, 0.074 * size, 8, 6);
        }
    }

    /** Lengan: lengan atas, siku, lengan bawah. r0..r4 = jari-jari bahu, otot, siku, lengan bawah, pergelangan. */
    static void arm(GodMesh m, double[] sh, double[] el, double[] wr, double r0, double r1, double r2, double r3, double r4,
                    double refX, double refY, double refZ) {
        double[] pts = {
                sh[0], sh[1], sh[2],
                lerp(0.45, sh[0], el[0]), lerp(0.45, sh[1], el[1]), lerp(0.45, sh[2], el[2]),
                el[0], el[1], el[2],
                lerp(0.35, el[0], wr[0]), lerp(0.35, el[1], wr[1]), lerp(0.35, el[2], wr[2]),
                wr[0], wr[1], wr[2]};
        m.tube(pts, new double[] {r0, r1, r2, r3, r4}, 5, 8, true, refX, refY, refZ, 1.0);
    }

    static void limbArm(GodMesh m, Rig r, boolean left, double limb) {
        double[] sh = left ? r.shL : r.shR, el = left ? r.elL : r.elR, wr = left ? r.wrL : r.wrR;
        arm(m, sh, el, wr, 0.058 * limb, 0.063 * limb, 0.046 * limb, 0.05 * limb, 0.035 * limb, r.chest.zx, r.chest.zy, r.chest.zz);
    }

    /** Telapak/kepalan di ujung lengan, menghadap palm (petunjuk arah). fist = kepalan (lebih bulat). */
    static void hand(GodMesh m, Rig r, boolean left, double size, double palmX, double palmY, double palmZ, boolean fist) {
        double[] el = left ? r.elL : r.elR, wr = left ? r.wrL : r.wrR;
        double[] d = new double[3];
        dir(el, wr[0], wr[1], wr[2], d);
        Frame f = r.f2.identity().at(wr[0], wr[1], wr[2]).aim(d[0], d[1], d[2], palmX, palmY, palmZ);
        if (fist) {
            m.ellipsoid(f, 0, 0.05 * size, 0.004, 0.044 * size, 0.05 * size, 0.04 * size, 7, 5);
        } else {
            m.ellipsoid(f, 0, 0.058 * size, 0, 0.042 * size, 0.064 * size, 0.022 * size, 7, 5);
            // ibu jari
            m.ellipsoid(f, 0.036 * size, 0.035 * size, 0.012, 0.013 * size, 0.032 * size, 0.013 * size, 5, 3);
        }
        double tx = f.px(0, 0.09 * size, 0), ty = f.py(0, 0.09 * size, 0), tz = f.pz(0, 0.09 * size, 0);
        m.anchor(left ? GodMesh.HAND_L : GodMesh.HAND_R, tx, ty, tz);
        m.anchorDir(left ? GodMesh.HAND_L : GodMesh.HAND_R, f.zx, f.zy, f.zz);
    }

    /** Kaki: paha, lutut, betis; telapak kaki menghadap fwd dan menunduk toe derajat (jinjit). */
    static void leg(GodMesh m, Rig r, boolean left, double limb, double fwdX, double fwdZ, double toe, boolean foot) {
        double[] hp = left ? r.hpL : r.hpR, kn = left ? r.knL : r.knR, an = left ? r.anL : r.anR;
        double[] pts = {
                hp[0], hp[1], hp[2],
                lerp(0.4, hp[0], kn[0]), lerp(0.4, hp[1], kn[1]), lerp(0.4, hp[2], kn[2]),
                kn[0], kn[1], kn[2],
                lerp(0.3, kn[0], an[0]), lerp(0.3, kn[1], an[1]), lerp(0.3, kn[2], an[2]),
                an[0], an[1], an[2]};
        m.tube(pts, new double[] {0.086 * limb, 0.083 * limb, 0.057 * limb, 0.061 * limb, 0.04 * limb}, 5, 8, true,
                r.pelvis.zx, r.pelvis.zy, r.pelvis.zz, 1.0);
        if (foot) {
            footAt(m, r, an, fwdX, fwdZ, toe, Math.sqrt(limb));
        }
    }

    static void footAt(GodMesh m, Rig r, double[] an, double fwdX, double fwdZ, double toe, double size) {
        double t = Math.toRadians(toe);
        double l = Math.sqrt(fwdX * fwdX + fwdZ * fwdZ);
        double hx = fwdX / l, hz = fwdZ / l;
        double dx = hx * Math.cos(t), dy = -Math.sin(t), dz = hz * Math.cos(t);
        Frame f = r.f2.identity().at(an[0], an[1], an[2]).aim(dx, dy, dz, 0, 1, 0);
        m.ellipsoid(f, 0, 0.07 * size, -0.025 * size, 0.043 * size, 0.11 * size, 0.034 * size, 7, 5);
    }

    /** Kepala: tengkorak, rahang, hidung, alis, telinga; mengisi titik mata & kepala. */
    static void head(GodMesh m, Rig r, int skin, float op, float gl, boolean ears) {
        Body b = r.b;
        Frame h = r.head;
        double hc = r.hc;
        m.mat(skin, op, gl);
        m.ellipsoid(h, 0, hc, 0, b.headRx, b.headRy, b.headRz, 12, 9);
        m.ellipsoid(h, 0, hc - 0.05, 0.02, b.headRx * 0.8, b.headRy * 0.58, b.headRz * 0.82, 10, 6);
        Frame n = r.f1.set(h).move(0, hc - 0.008, b.headRz * 0.93).rotX(-14);
        m.ellipsoid(n, 0, 0, 0, 0.018, 0.034, 0.024, 6, 4);
        m.ellipsoid(h, 0, hc + 0.03, b.headRz * 0.84, 0.068, 0.016, 0.03, 8, 4);
        if (ears) {
            for (int s = -1; s <= 1; s += 2) {
                m.ellipsoid(h, s * b.headRx * 0.97, hc - 0.005, -0.008, 0.014, 0.03, 0.021, 5, 3);
            }
        }
        m.anchor(GodMesh.HEAD, h.px(0, hc, 0), h.py(0, hc, 0), h.pz(0, hc, 0));
        m.anchorDir(GodMesh.HEAD, h.zx, h.zy, h.zz);
        m.anchor(GodMesh.EYE_L, h.px(0.037, hc + 0.008, b.headRz * 0.9), h.py(0.037, hc + 0.008, b.headRz * 0.9),
                h.pz(0.037, hc + 0.008, b.headRz * 0.9));
        m.anchor(GodMesh.EYE_R, h.px(-0.037, hc + 0.008, b.headRz * 0.9), h.py(-0.037, hc + 0.008, b.headRz * 0.9),
                h.pz(-0.037, hc + 0.008, b.headRz * 0.9));
        m.anchorDir(GodMesh.EYE_L, h.zx, h.zy, h.zz);
        m.anchorDir(GodMesh.EYE_R, h.zx, h.zy, h.zz);
        double[] c = new double[3];
        r.chest.point(0, b.chestLen * 0.6, b.chestRz, c, 0);
        m.anchor(GodMesh.CHEST, c[0], c[1], c[2]);
    }

    /** Rambut pendek menutup ubun-ubun & belakang kepala. */
    static void hairCap(GodMesh m, Rig r, int color, float op, float gl, double puff, double depth) {
        Body b = r.b;
        m.mat(color, op, gl).ellipsoid(r.head, 0, r.hc + 0.012, -0.012, b.headRx * puff, b.headRy * (puff - 0.01),
                b.headRz * puff, 14, 7, 0.0, Math.PI * depth, Math.PI * 0.28);
    }

    /** Rambut panjang terurai di belakang sampai bahu (kain tipis dua sisi, ujungnya berayun). */
    static void longHair(GodMesh m, Rig r, int color, float op, float gl, double len, double sway) {
        Body b = r.b;
        int n = 6;
        double[] ys = new double[n], cz = new double[n], cx = new double[n], rx = new double[n], rz = new double[n];
        for (int k = 0; k < n; k++) {
            double u = k / (double) (n - 1);
            ys[k] = r.hc + 0.03 - len * u;
            cx[k] = sway * u * u;
            cz[k] = -0.012 - 0.05 * u;
            rx[k] = b.headRx * (1.08 + 0.32 * u);
            rz[k] = b.headRz * (1.05 + 0.05 * u);
        }
        m.mat(color, op, gl).lathe(r.head, cx, ys, cz, rx, rz, n, 12, Math.PI * 0.98, Math.PI * 2.02,
                (k, a) -> 1.0 + 0.05 * Math.sin(a * 11.0 + k), true);
    }

    /**
     * Janggut: tumpukan cincin dari pipi ke bawah. len = panjang, width = lebar, fwd = menjorok ke depan,
     * curls = keriting (0-1), sway = ujung berayun ke samping.
     */
    static void beard(GodMesh m, Rig r, int color, float op, float gl, double len, double width, double fwd, double curls,
                      double sway) {
        Body b = r.b;
        int n = 8;
        double[] ys = new double[n], cz = new double[n], cx = new double[n], rx = new double[n], rz = new double[n];
        for (int k = 0; k < n; k++) {
            double u = k / (double) (n - 1);
            double taper = Math.sqrt(Math.max(0.0, 1.0 - Math.pow(u, 2.2)));
            ys[k] = r.hc - 0.028 - len * u;
            cz[k] = 0.01 + fwd * u + 0.03 * Math.sin(Math.PI * u);
            cx[k] = sway * u * u;
            rx[k] = Math.max(0.002, width * (1.0 - 0.18 * u) * taper);
            rz[k] = Math.max(0.002, b.headRz * 0.78 * (1.0 - 0.3 * u) * taper);
        }
        m.mat(color, op, gl).lathe(r.head, cx, ys, cz, rx, rz, n, 14, 0.0, Math.PI * 2.0,
                (k, a) -> 1.0 + curls * 0.07 * Math.sin(a * 7.0 + k * 2.1), false);
        // kumis
        for (int s = -1; s <= 1; s += 2) {
            double[] p = new double[9];
            r.head.point(s * 0.006, r.hc - 0.04, b.headRz + 0.006, p, 0);
            r.head.point(s * 0.035, r.hc - 0.05, b.headRz - 0.004, p, 3);
            r.head.point(s * 0.054, r.hc - 0.078, b.headRz - 0.03, p, 6);
            m.tube(p, new double[] {0.012, 0.009, 0.003}, 3, 6, true, 0, 1, 0, 1.0);
        }
    }

    /** Lingkaran tertutup (cincin hiasan) di frame f: elips rx/rz pada ketinggian y, tebal t. */
    static void loop(GodMesh m, Frame f, double y, double rx, double rz, double cz, double t, int seg) {
        double[] p = new double[seg * 3];
        for (int i = 0; i < seg; i++) {
            double a = Math.PI * 2.0 * i / seg;
            f.point(rx * Math.cos(a), y, cz + rz * Math.sin(a), p, i * 3);
        }
        double[] rad = new double[seg];
        java.util.Arrays.fill(rad, t);
        m.tube(p, rad, seg, 4, false, f.yx, f.yy, f.yz, 1.0, true);
    }

    /** Kain menjuntai (pita): titik-titik garis tengah + arah lebar (sumbu X frame) + lebar. */
    static void cloth(GodMesh m, double[] pts, double[] w, double[] width, int n, int across, double curl) {
        m.ribbon(pts, w, width, n, across, curl);
    }

    // ================================================================== S - SOLOMON

    private static final int SOL_SKIN = 0xEADCFF, SOL_ROBE = 0x7048CC, SOL_CAPE = 0x9C7AF2, SOL_GOLD = 0xFFD27A;
    private static final int SOL_HAIR = 0xF4F0FF, SOL_GEM = 0xFF7AD9, SOL_PAGE = 0xFFF6DA, SOL_BOOK = 0x5A3A9A;

    static void solomon(GodMesh m, Pose p) {
        Rig r = RIG;
        Body b = SOLOMON_BODY;
        double t = p.time, c = smooth(p.converge);
        double breath = Math.sin(t * 0.08);
        double open = smooth((p.tau - 11.0) / 6.0);           // kitab terbuka
        double bless = smooth((p.tau - 9.0) / 7.0);           // tangan kanan terangkat memberkati
        r.torso(b, 0, 0, 0, 0, -2 + breath * 0.5, 0, breath * 0.8, 0, 2, lerp(c, 9, -12), lerp(c, 4, 0), 0);

        // tangan kiri memegang kitab di depan dada
        double[] tmp = new double[3];
        r.chest.point(0.09, 0.2, 0.3, tmp, 0);
        r.armL(tmp[0], tmp[1], tmp[2], 0.5, -1, -0.2);
        // tangan kanan: turun -> memberkati setinggi bahu -> menunjuk kepalan
        double[] hang = new double[3], up = new double[3];
        r.chest.point(-0.25, -0.05, 0.12, hang, 0);
        r.chest.point(-0.36, 0.42, 0.24, up, 0);
        double hx = lerp(bless, hang[0], up[0]), hy = lerp(bless, hang[1], up[1]), hz = lerp(bless, hang[2], up[2]);
        double[] aim = new double[3];
        dir(r.shR, p.aimX, p.aimY, p.aimZ, aim);
        hx = lerp(c, hx, r.shR[0] + aim[0] * 0.55);
        hy = lerp(c, hy, r.shR[1] + aim[1] * 0.55);
        hz = lerp(c, hz, r.shR[2] + aim[2] * 0.55);
        r.armR(hx, hy, hz, -0.3, -1, -0.3);

        // badan, kepala, rambut, janggut
        torso(m, r, SOL_ROBE, 0.9f, 0.05f);
        head(m, r, SOL_SKIN, 0.9f, 0.05f, false);
        hairCap(m, r, SOL_HAIR, 0.88f, 0.12f, 1.07, 0.56);
        longHair(m, r, SOL_HAIR, 0.85f, 0.12f, 0.36, Math.sin(t * 0.07) * 0.015);
        beard(m, r, SOL_HAIR, 0.9f, 0.14f, 0.38, 0.09, 0.05, 0.5, Math.sin(t * 0.06 + 1) * 0.02);

        // jubah panjang sampai tanah (menggantung lurus ke bawah)
        Frame robe = r.f3.identity().at(r.pelvis.ox, 0, r.pelvis.oz);
        int n = 7;
        double[] ys = {1.36, 1.12, 0.9, 0.62, 0.34, 0.1, 0.005};
        double[] rx = {0.185, 0.17, 0.205, 0.255, 0.31, 0.37, 0.39};
        double[] rz = {0.13, 0.13, 0.165, 0.205, 0.25, 0.31, 0.33};
        double[] cz = {0.012, 0.0, 0.0, 0.01, 0.02, 0.03, 0.03};
        double[] amp = {0.0, 0.01, 0.022, 0.036, 0.05, 0.06, 0.062};
        double wave = t * 0.05;
        GodMesh.Fold folds = (k, a) -> 1.0 + amp[k] * Math.sin(a * 9.0 + 0.8 * Math.sin(wave + k * 0.7));
        m.mat(SOL_ROBE, 0.9f, 0.05f).lathe(robe, null, ys, cz, rx, rz, n, 20, 0, Math.PI * 2, folds, false);
        // pinggiran emas di kelim
        double[] hem = new double[20 * 3];
        for (int i = 0; i < 20; i++) {
            double a = Math.PI * 2.0 * i / 20;
            double mm = folds.at(6, a);
            robe.point(rx[6] * mm * Math.cos(a), 0.03, cz[6] + rz[6] * mm * Math.sin(a), hem, i * 3);
        }
        double[] hemR = new double[20];
        java.util.Arrays.fill(hemR, 0.016);
        m.mat(SOL_GOLD, 0.95f, 0.55f).tube(hem, hemR, 20, 4, false, 0, 1, 0, 1.0, true);

        // jubah bahu (mozzetta) dengan pinggiran emas
        Frame ch = r.chest;
        double[] cy = {b.chestLen + 0.03, b.chestLen - 0.03, b.chestLen - 0.11, b.chestLen - 0.2};
        double[] crx = {0.07, 0.205, 0.255, 0.262};
        double[] crz = {0.064, 0.15, 0.172, 0.18};
        double[] ccz = {-0.004, 0.0, 0.004, 0.006};
        m.mat(SOL_CAPE, 0.92f, 0.08f).lathe(ch, null, cy, ccz, crx, crz, 4, 18, 0, Math.PI * 2, null, false);
        loop(m.mat(SOL_GOLD, 0.95f, 0.55f), ch, b.chestLen - 0.2, 0.262, 0.18, 0.006, 0.012, 18);

        // lengan jubah lebar (bell sleeve) + tangan
        m.mat(SOL_ROBE, 0.9f, 0.05f);
        arm(m, r.shL, r.elL, r.wrL, 0.07, 0.075, 0.078, 0.095, 0.125, ch.zx, ch.zy, ch.zz);
        arm(m, r.shR, r.elR, r.wrR, 0.07, 0.075, 0.078, 0.095, 0.125, ch.zx, ch.zy, ch.zz);
        m.mat(SOL_SKIN, 0.9f, 0.05f);
        hand(m, r, true, 1.0, 0, 1, 0.2, false);
        hand(m, r, false, 1.0, lerp(bless, 1, 0.2), lerp(bless, 0, -0.3), lerp(bless, 0, 1), false);

        // selempang emas di depan
        for (int s = -1; s <= 1; s += 2) {
            double[] sp = new double[4 * 3], sw = new double[4 * 3], wd = {0.07, 0.07, 0.068, 0.065};
            ch.point(s * 0.085, b.chestLen - 0.02, 0.1, sp, 0);
            ch.point(s * 0.08, b.chestLen * 0.45, b.chestRz + 0.035, sp, 3);
            sp[6] = r.pelvis.ox + s * 0.085; sp[7] = 0.75; sp[8] = r.pelvis.oz + 0.2;
            sp[9] = r.pelvis.ox + s * 0.09 + Math.sin(t * 0.05 + s) * 0.01; sp[10] = 0.42; sp[11] = r.pelvis.oz + 0.27;
            for (int k = 0; k < 4; k++) {
                sw[k * 3] = ch.xx; sw[k * 3 + 1] = ch.xy; sw[k * 3 + 2] = ch.xz;
            }
            m.mat(SOL_GOLD, 0.95f, 0.4f).ribbon(sp, sw, wd, 4, 2, 0.0);
        }

        // mahkota emas bergerigi + permata
        Frame h = r.head;
        double hc = r.hc;
        double[] ky = {hc + 0.118, hc + 0.072, hc + 0.056};
        double[] krx = {0.086, 0.103, 0.104}, krz = {0.096, 0.113, 0.114};
        m.mat(SOL_GOLD, 0.97f, 0.6f).lathe(h, null, ky, null, krx, krz, 3, 16, 0, Math.PI * 2, null, true);
        for (int i = 0; i < 8; i++) {
            double a = Math.PI * 2.0 * i / 8 + Math.PI / 2;
            double tall = i % 2 == 0 ? 0.075 : 0.05;
            double bx = Math.cos(a) * 0.09, bz = Math.sin(a) * 0.1;
            m.spike(h.px(bx, hc + 0.108, bz), h.py(bx, hc + 0.108, bz), h.pz(bx, hc + 0.108, bz),
                    h.px(bx * 1.12, hc + 0.108 + tall, bz * 1.12), h.py(bx * 1.12, hc + 0.108 + tall, bz * 1.12),
                    h.pz(bx * 1.12, hc + 0.108 + tall, bz * 1.12), 0.017, 5);
        }
        m.mat(SOL_GEM, 1f, 1f).ellipsoid(h, 0, hc + 0.084, 0.118, 0.018, 0.02, 0.012, 8, 5);

        // kitab: dua sampul berengsel + halaman bercahaya
        double[] hl = new double[3];
        dir(r.elL, r.wrL[0], r.wrL[1], r.wrL[2], hl);
        Frame bk = r.f3.identity().at(r.wrL[0] + hl[0] * 0.07, r.wrL[1] + 0.05, r.wrL[2] + hl[2] * 0.07)
                .aim(0.1, -0.3, 1, -0.05, 1, -0.75);
        double half = lerp(open, 80, 18);
        for (int s = -1; s <= 1; s += 2) {
            Frame cv = r.f1.set(bk).rotY(-s * half);
            m.mat(SOL_BOOK, 0.95f, 0.15f).box(cv, s * 0.088, 0, -0.007, 0.088, 0.118, 0.008);
            m.mat(SOL_PAGE, 0.95f, 0.85f).box(cv, s * 0.082, 0, 0.007, 0.08, 0.11, 0.009);
        }
        m.anchor(GodMesh.FOCUS, bk.px(0, 0, 0.12), bk.py(0, 0, 0.12), bk.pz(0, 0, 0.12));
        m.anchorDir(GodMesh.FOCUS, bk.zx, bk.zy, bk.zz);
        // segel di telapak kanan
        m.anchor(GodMesh.EXTRA, m.anchor[GodMesh.HAND_R * 3], m.anchor[GodMesh.HAND_R * 3 + 1], m.anchor[GodMesh.HAND_R * 3 + 2]);
        m.anchorDir(GodMesh.EXTRA, m.anchorDir[GodMesh.HAND_R * 3], m.anchorDir[GodMesh.HAND_R * 3 + 1],
                m.anchorDir[GodMesh.HAND_R * 3 + 2]);
        m.extraSize = (float) bless;
    }

    // ================================================================== H - HERCULES

    private static final int HER_SKIN = 0xE4F6CC, HER_PELT = 0xEBB95C, HER_MANE = 0xC88A3E, HER_CLUB = 0xB8915A;
    private static final int HER_GOLD = 0xFFD978, HER_BEARD = 0x9C7A4A;

    static void hercules(GodMesh m, Pose p) {
        Rig r = RIG;
        Body b = HERCULES_BODY;
        double t = p.time, c = smooth(p.converge);
        double breath = Math.sin(t * 0.085);
        // bobot pose: melompat (0-9), mendarat (9-11), bangkit (11-17)
        double fly = p.tau < 9 ? 1.0 : 0.0;
        double land = p.tau < 9 ? 0.0 : (p.tau < 11 ? smooth((p.tau - 9) / 1.2) : 1.0 - smooth((p.tau - 11.5) / 5.5));
        double idle = 1.0 - Math.max(fly, land);
        double rootY = -0.02 * idle - 0.34 * land + 0.08 * fly;
        double lean = 2 * idle + 24 * land - 8 * fly;
        r.torso(b, 0, rootY, 0, 0, lean + breath * 0.6, 0, -3 * idle + 8 * land, 0, -4 * idle,
                lerp(c, 6 * idle - 10 * fly - 8 * land, -14), 0, 0);
        double[] tmp = new double[3];

        // kaki
        double lfx = 0.17 * idle + 0.26 * land + 0.15 * fly, lfy = 0.07 * (idle + land) + 0.52 * fly, lfz = 0.06 * idle + 0.12 * land + 0.2 * fly;
        double rfx = -0.16 * idle - 0.24 * land - 0.14 * fly, rfy = 0.07 * (idle + land) + 0.6 * fly, rfz = -0.05 * idle - 0.1 * land - 0.12 * fly;
        r.legL(lfx, lfy, lfz, 0.25, 0.2, 1);
        r.legR(rfx, rfy, rfz, -0.25, 0.2, 1);

        // tangan kanan memegang gada: di bahu (diam), di atas kepala (melompat), menghantam tanah (mendarat)
        double[] gripIdle = new double[3];
        r.chest.point(-0.2, 0.33, 0.2, gripIdle, 0);
        double ghx = gripIdle[0] * idle + (-0.12) * fly + (-0.14) * land;
        double ghy = gripIdle[1] * idle + 2.02 * fly + 0.72 * land;
        double ghz = gripIdle[2] * idle + (-0.05) * fly + 0.5 * land;
        double[] aim = new double[3];
        dir(r.shR, p.aimX, p.aimY, p.aimZ, aim);
        ghx = lerp(c, ghx, r.shR[0] + aim[0] * 0.5);
        ghy = lerp(c, ghy, r.shR[1] + aim[1] * 0.5);
        ghz = lerp(c, ghz, r.shR[2] + aim[2] * 0.5);
        r.armR(ghx, ghy, ghz, -0.3, -1, 0.2);
        // arah gada
        double cdx = -0.18 * idle + 0.05 * fly + 0.12 * land, cdy = 0.78 * idle + 0.6 * fly - 0.55 * land;
        double cdz = -0.6 * idle - 0.8 * fly + 0.82 * land;
        cdx = lerp(c, cdx, aim[0]);
        cdy = lerp(c, cdy, aim[1]);
        cdz = lerp(c, cdz, aim[2]);
        // tangan kiri: berkacak pinggang (diam), ke depan (melompat), kepalan menyentuh tanah (mendarat)
        r.pelvis.point(0.23, 0.04, 0.02, tmp, 0);
        double lhx = tmp[0] * idle + 0.32 * fly + 0.26 * land;
        double lhy = tmp[1] * idle + 1.45 * fly + 0.1 * land;
        double lhz = tmp[2] * idle + 0.32 * fly + 0.3 * land;
        r.armL(lhx, lhy, lhz, 1, 0.1 * idle, -0.5 * idle + 0.3);

        // badan kekar
        torso(m, r, HER_SKIN, 0.9f, 0.05f);
        muscles(m, r, HER_SKIN, 0.9f, 0.05f, 1.15);
        deltoids(m, r, HER_SKIN, 0.9f, 0.05f, b.limb * 0.95);
        m.mat(HER_SKIN, 0.9f, 0.05f);
        limbArm(m, r, true, b.limb);
        limbArm(m, r, false, b.limb);
        hand(m, r, true, 1.2, 0, 0, 1, true);
        hand(m, r, false, 1.2, 1, 0, 0, true);
        leg(m, r, true, b.limb, 0.15, 1, fly * 35, true);
        leg(m, r, false, b.limb, -0.15, 1, fly * 35, true);
        head(m, r, HER_SKIN, 0.9f, 0.05f, true);
        beard(m, r, HER_BEARD, 0.9f, 0.06f, 0.15, 0.092, 0.025, 1.0, 0.0);
        hairCap(m, r, HER_BEARD, 0.9f, 0.05f, 1.06, 0.5);

        // cawat kulit singa + ikat pinggang emas
        Frame pv = r.pelvis;
        double[] ly = {0.08, -0.05, -0.16, -0.22};
        double[] lrx = {b.hipRx * 1.04, b.hipRx * 1.12, b.hipRx * 1.2, b.hipRx * 1.23};
        double[] lrz = {b.hipRz * 1.1, b.hipRz * 1.22, b.hipRz * 1.34, b.hipRz * 1.38};
        m.mat(HER_PELT, 0.92f, 0.1f).lathe(pv, null, ly, null, lrx, lrz, 4, 16, 0, Math.PI * 2,
                (k, a) -> 1.0 + 0.06 * k * Math.abs(Math.sin(a * 4 + 0.5)), false);
        loop(m.mat(HER_GOLD, 0.95f, 0.5f), pv, 0.07, b.hipRx * 1.06, b.hipRz * 1.14, 0, 0.016, 16);

        // kulit singa: kepala singa jadi kerudung (moncong & taring di atas dahi), surai lebat membingkai wajah,
        // cakar terikat di dada, kulitnya menjuntai di punggung
        Frame h = r.head;
        double hc = r.hc;
        m.mat(HER_PELT, 0.93f, 0.12f);
        m.ellipsoid(h, 0, hc + 0.078, -0.012, 0.124, 0.068, 0.15, 14, 8);
        m.ellipsoid(h, 0, hc + 0.096, 0.095, 0.088, 0.046, 0.065, 10, 6);
        m.ellipsoid(h, 0, hc + 0.064, 0.152, 0.062, 0.042, 0.066, 10, 6);
        m.mat(0x7A5030, 0.95f, 0.05f).ellipsoid(h, 0, hc + 0.082, 0.212, 0.026, 0.018, 0.017, 6, 4);
        for (int s = -1; s <= 1; s += 2) {
            Frame ear = r.f1.set(h).move(s * 0.084, hc + 0.125, -0.035).rotZ(-s * 25);
            m.mat(HER_PELT, 0.93f, 0.12f).ellipsoid(ear, 0, 0.02, 0, 0.024, 0.032, 0.011, 6, 4);
            m.mat(0xFFFFF0, 0.95f, 0.5f).spike(h.px(s * 0.04, hc + 0.035, 0.19), h.py(s * 0.04, hc + 0.035, 0.19),
                    h.pz(s * 0.04, hc + 0.035, 0.19), h.px(s * 0.036, hc - 0.016, 0.176), h.py(s * 0.036, hc - 0.016, 0.176),
                    h.pz(s * 0.036, hc - 0.016, 0.176), 0.01, 5);
        }
        m.anchor(GodMesh.EXTRA2, h.px(0, hc + 0.112, 0.14), h.py(0, hc + 0.112, 0.14), h.pz(0, hc + 0.112, 0.14));
        int mn = 6;
        double[] my = {hc + 0.13, hc + 0.05, hc - 0.04, hc - 0.13, hc - 0.22, hc - 0.3};
        double[] mrx = {0.135, 0.175, 0.205, 0.235, 0.255, 0.25}, mrz = {0.155, 0.17, 0.18, 0.19, 0.19, 0.17};
        double[] mcz = {-0.015, -0.02, -0.035, -0.05, -0.07, -0.085};
        m.mat(HER_MANE, 0.92f, 0.1f).lathe(h, null, my, mcz, mrx, mrz, mn, 18, Math.PI * 0.71, Math.PI * 2.29,
                (k, a) -> 1.0 + 0.15 * Math.abs(Math.sin(a * 6.0 + k * 1.3)), true);
        // cakar terikat di dada
        double[] knot = new double[3];
        r.chest.point(0, b.chestLen - 0.15, b.chestRz + 0.035, knot, 0);
        for (int s = -1; s <= 1; s += 2) {
            double[] paw = new double[9];
            r.chest.point(s * 0.17, b.chestLen - 0.01, 0.05, paw, 0);
            r.chest.point(s * 0.09, b.chestLen - 0.08, b.chestRz + 0.02, paw, 3);
            paw[6] = knot[0]; paw[7] = knot[1]; paw[8] = knot[2];
            m.mat(HER_PELT, 0.93f, 0.12f).tube(paw, new double[] {0.04, 0.036, 0.03}, 3, 7, true, r.chest.zx, r.chest.zy,
                    r.chest.zz, 1.0);
        }
        m.ellipsoid(r.f1.identity(), knot[0], knot[1], knot[2], 0.045, 0.04, 0.035, 8, 6);
        // kulit di punggung
        double sway = Math.sin(t * 0.06) * 0.03 + fly * 0.2;
        double[] pp = new double[5 * 3], pw = new double[5 * 3];
        r.chest.point(0, b.chestLen + 0.01, -0.12, pp, 0);
        r.chest.point(0, b.chestLen * 0.5, -b.chestRz - 0.05, pp, 3);
        pv.point(0, -0.05, -b.hipRz - 0.07, pp, 6);
        pp[9] = pv.ox + sway * 0.4; pp[10] = 0.62 + fly * 0.2; pp[11] = pv.oz - 0.27 - fly * 0.2;
        pp[12] = pv.ox + sway; pp[13] = 0.36 + fly * 0.3; pp[14] = pv.oz - 0.32 - fly * 0.4;
        for (int k = 0; k < 5; k++) {
            Frame f = k < 2 ? r.chest : pv;
            pw[k * 3] = f.xx; pw[k * 3 + 1] = f.xy; pw[k * 3 + 2] = f.xz;
        }
        m.mat(HER_PELT, 0.92f, 0.1f).ribbon(pp, pw, new double[] {0.34, 0.5, 0.46, 0.38, 0.28}, 5, 5, 0.85);

        // gada kayu berbonggol
        double[] cd = {cdx, cdy, cdz};
        double cl = Math.sqrt(cd[0] * cd[0] + cd[1] * cd[1] + cd[2] * cd[2]);
        cd[0] /= cl; cd[1] /= cl; cd[2] /= cl;
        double gx = r.wrR[0], gy = r.wrR[1], gz = r.wrR[2];
        double[] club = new double[6 * 3];
        double[] at = {-0.09, 0.0, 0.3, 0.55, 0.76, 0.9};
        for (int k = 0; k < 6; k++) {
            club[k * 3] = gx + cd[0] * at[k];
            club[k * 3 + 1] = gy + cd[1] * at[k];
            club[k * 3 + 2] = gz + cd[2] * at[k];
        }
        m.mat(HER_CLUB, 0.93f, 0.12f).tube(club, new double[] {0.03, 0.036, 0.056, 0.082, 0.102, 0.08}, 6, 8, true, 0, 0, 1,
                1.0);
        Frame cf = r.f1.identity().at(gx, gy, gz).aim(cd[0], cd[1], cd[2], 0, 0, 1);
        for (int k = 0; k < 6; k++) {
            double a = k * 2.1, along = 0.5 + k * 0.07;
            double rr = 0.06 + k * 0.006;
            m.ellipsoid(cf, Math.cos(a) * rr, along, Math.sin(a) * rr, 0.028, 0.03, 0.028, 6, 4);
        }
        m.anchor(GodMesh.FOCUS, gx + cd[0] * 0.8, gy + cd[1] * 0.8, gz + cd[2] * 0.8);
        m.anchorDir(GodMesh.FOCUS, cd[0], cd[1], cd[2]);
    }

    // ================================================================== A - ATLAS

    private static final int ATL_SKIN = 0xF2B27C, ATL_HAIR = 0xFFE4C0, ATL_CLOTH = 0xC4703A, ATL_GOLD = 0xFFE7A0;
    private static final int ATL_GLOBE = 0x9C4A20;

    /** Jari-jari bola langit Atlas (ukuran dasar). */
    public static final double GLOBE_R = 0.62;

    /** Putaran bola langit (radian) pada waktu t; dipakai juga untuk bintang-bintangnya. */
    public static double globeSpin(double t) {
        return t * 0.012;
    }

    static void atlas(GodMesh m, Pose p) {
        Rig r = RIG;
        Body b = ATLAS_BODY;
        double t = p.time, c = smooth(p.converge);
        double strain = Math.sin(t * 0.07);
        double tremble = Math.sin(t * 1.9) * 0.15 * (1 - c);
        double lift = c * 0.18;   // saat menyatu: bola langit diangkat tinggi
        r.torso(b, 0, -0.38 + strain * 0.008 + lift * 0.6, 0.05, 0, 16 - lift * 30, 0, 12 + strain + tremble - lift * 20, 0, 0,
                lerp(c, 22, -10), 0, 0);
        // kaki: kiri berpijak di depan, lutut kanan di tanah
        r.legL(0.15, 0.07, 0.4, 0.1, 0.6, 1);
        r.legR(-0.13, 0.08, -0.42, 0, -0.6, 0.8);
        // bola langit di atas bahu
        double gcx = 0, gcy = 1.84 + strain * 0.01 + lift, gcz = -0.28 + lift * 0.3;
        double[] hand = new double[3];
        for (int s = -1; s <= 1; s += 2) {
            hand[0] = gcx + s * GLOBE_R * 0.83;
            hand[1] = gcy - GLOBE_R * 0.42;
            hand[2] = gcz + GLOBE_R * 0.37;
            if (s > 0) {
                r.armL(hand[0], hand[1], hand[2], 1, 0, 0.5);
            } else {
                r.armR(hand[0], hand[1], hand[2], -1, 0, 0.5);
            }
        }

        torso(m, r, ATL_SKIN, 0.92f, 0.06f);
        muscles(m, r, ATL_SKIN, 0.92f, 0.06f, 1.25);
        deltoids(m, r, ATL_SKIN, 0.92f, 0.06f, b.limb * 0.98);
        m.mat(ATL_SKIN, 0.92f, 0.06f);
        limbArm(m, r, true, b.limb);
        limbArm(m, r, false, b.limb);
        hand(m, r, true, 1.25, -1, 0, 0, false);
        hand(m, r, false, 1.25, 1, 0, 0, false);
        leg(m, r, true, b.limb, 0.1, 1, 0, true);
        leg(m, r, false, b.limb, 0, -1, 30, true);
        head(m, r, ATL_SKIN, 0.92f, 0.06f, true);
        hairCap(m, r, ATL_HAIR, 0.9f, 0.12f, 1.08, 0.52);
        beard(m, r, ATL_HAIR, 0.92f, 0.12f, 0.24, 0.1, 0.035, 1.0, 0.0);
        loop(m.mat(ATL_GOLD, 0.95f, 0.5f), r.head, r.hc + 0.045, b.headRx * 1.08, b.headRz * 1.08, -0.008, 0.01, 14);

        // kain pinggang
        Frame pv = r.pelvis;
        double[] ly = {0.09, -0.06, -0.18, -0.26};
        double[] lrx = {b.hipRx * 1.04, b.hipRx * 1.14, b.hipRx * 1.26, b.hipRx * 1.3};
        double[] lrz = {b.hipRz * 1.1, b.hipRz * 1.28, b.hipRz * 1.45, b.hipRz * 1.5};
        m.mat(ATL_CLOTH, 0.92f, 0.08f).lathe(pv, null, ly, null, lrx, lrz, 4, 16, 0, Math.PI * 2,
                (k, a) -> 1.0 + 0.04 * k * Math.sin(a * 7 + 1.0), false);
        loop(m.mat(ATL_GOLD, 0.95f, 0.5f), pv, 0.07, b.hipRx * 1.06, b.hipRz * 1.14, 0, 0.016, 16);

        // bola langit: kulit tembus pandang + cincin-cincin emas, berputar pelan
        Frame g = r.f3.identity().at(gcx, gcy, gcz).rotZ(-18).rotY(Math.toDegrees(globeSpin(t)));
        m.mat(ATL_GLOBE, 0.56f, 0.12f).ellipsoid(g, 0, 0, 0, GLOBE_R, GLOBE_R, GLOBE_R, 20, 12);
        m.mat(ATL_GOLD, 0.95f, 0.75f);
        loop(m, g, 0, GLOBE_R * 1.015, GLOBE_R * 1.015, 0, 0.014, 26);
        Frame e = r.f1.set(g).rotX(23.4);
        loop(m, e, 0, GLOBE_R * 1.03, GLOBE_R * 1.03, 0, 0.012, 26);
        Frame mer = r.f1.set(g).rotZ(90);
        loop(m, mer, 0, GLOBE_R * 1.02, GLOBE_R * 1.02, 0, 0.011, 26);
        mer.set(g).rotZ(90).rotX(90);
        loop(m, mer, 0, GLOBE_R * 1.02, GLOBE_R * 1.02, 0, 0.011, 26);
        m.spike(g.px(0, GLOBE_R * 0.95, 0), g.py(0, GLOBE_R * 0.95, 0), g.pz(0, GLOBE_R * 0.95, 0),
                g.px(0, GLOBE_R * 1.22, 0), g.py(0, GLOBE_R * 1.22, 0), g.pz(0, GLOBE_R * 1.22, 0), 0.02, 5);
        m.spike(g.px(0, -GLOBE_R * 0.95, 0), g.py(0, -GLOBE_R * 0.95, 0), g.pz(0, -GLOBE_R * 0.95, 0),
                g.px(0, -GLOBE_R * 1.22, 0), g.py(0, -GLOBE_R * 1.22, 0), g.pz(0, -GLOBE_R * 1.22, 0), 0.02, 5);
        m.anchor(GodMesh.FOCUS, gcx, gcy, gcz);
        m.anchorDir(GodMesh.EXTRA, g.yx, g.yy, g.yz);
        m.anchorDir(GodMesh.EXTRA2, g.xx, g.xy, g.xz);
        m.anchor(GodMesh.EXTRA, gcx, gcy, gcz);
        m.extraSize = (float) GLOBE_R;
    }

    // ================================================================== Z - ZEUS

    private static final int ZEU_SKIN = 0xFFE2BC, ZEU_ROBE = 0xEDEBFA, ZEU_GOLD = 0xFFD45A, ZEU_HAIR = 0xFFFFFF;
    private static final int ZEU_BOLT = 0xFFF6C8;

    static void zeus(GodMesh m, Pose p) {
        Rig r = RIG;
        Body b = ZEUS_BODY;
        double t = p.time, c = smooth(p.converge);
        double breath = Math.sin(t * 0.08);
        double land = p.tau < 16 ? 1.0 - smooth((p.tau - 4) / 9.0) : 0.0;   // sedikit merunduk waktu turun bersama petir
        double throwIt = c;
        r.torso(b, 0, -0.03 - 0.12 * land, 0, 0, 3 + 10 * land + throwIt * 8 + breath * 0.5, 0, breath * 0.7 + 4 * land,
                0, -14 + throwIt * 22, lerp(c, 6, -12), lerp(c, 8, 0), 0);
        r.legL(0.14, 0.07, 0.22, 0.1, 0.3, 1);
        r.legR(-0.14, 0.07, -0.2, -0.1, 0.3, 1);

        // tangan kanan mengangkat petir siap dilempar -> dilempar ke arah kepalan saat menyatu
        double[] aim = new double[3];
        dir(r.shR, p.aimX, p.aimY, p.aimZ, aim);
        double hx = lerp(throwIt, -0.32, r.shR[0] + aim[0] * 0.56);
        double hy = lerp(throwIt, 2.03 + 0.05 * land, r.shR[1] + aim[1] * 0.56);
        double hz = lerp(throwIt, -0.15, r.shR[2] + aim[2] * 0.56);
        r.armR(hx, hy, hz, lerp(throwIt, -0.6, -0.4), lerp(throwIt, -0.2, -1), lerp(throwIt, -0.8, -0.2));
        // tangan kiri terulur memerintah
        r.armL(0.34, 1.48 + 0.02 * breath, 0.52, 0.3, -1, 0);

        torso(m, r, ZEU_SKIN, 0.9f, 0.08f);
        muscles(m, r, ZEU_SKIN, 0.9f, 0.08f, 1.05);
        deltoids(m, r, ZEU_SKIN, 0.9f, 0.08f, b.limb * 0.92);
        m.mat(ZEU_SKIN, 0.9f, 0.08f);
        limbArm(m, r, true, b.limb);
        limbArm(m, r, false, b.limb);
        hand(m, r, true, 1.1, 0, -1, 0.3, false);
        hand(m, r, false, 1.1, 0, 0, 1, true);
        leg(m, r, true, b.limb, 0.12, 1, 0, true);
        leg(m, r, false, b.limb, -0.1, 1, 0, true);
        head(m, r, ZEU_SKIN, 0.9f, 0.08f, false);
        hairCap(m, r, ZEU_HAIR, 0.88f, 0.2f, 1.09, 0.56);
        longHair(m, r, ZEU_HAIR, 0.86f, 0.2f, 0.34, Math.sin(t * 0.07) * 0.02);
        beard(m, r, ZEU_HAIR, 0.9f, 0.22f, 0.32, 0.1, 0.06, 1.0, Math.sin(t * 0.06) * 0.015);

        // mahkota daun salam emas
        Frame h = r.head;
        double hc = r.hc;
        Frame wr = r.f1.set(h).move(0, hc + 0.05, -0.006).rotX(-10);
        loop(m.mat(ZEU_GOLD, 0.95f, 0.55f), wr, 0, b.headRx * 1.06, b.headRz * 1.06, 0, 0.007, 16);
        Frame leaf = r.f2;
        for (int side = -1; side <= 1; side += 2) {
            for (int k = 0; k < 7; k++) {
                // dari belakang (270 derajat) ke depan, berhenti sebelum dahi
                double a = Math.toRadians(270 + side * (12 + k * 22));
                double lx = b.headRx * 1.07 * Math.cos(a), lz = b.headRz * 1.07 * Math.sin(a);
                double tx = -Math.sin(a) * side, tz = Math.cos(a) * side;   // menghadap ke depan sepanjang lingkaran
                leaf.set(wr).at(wr.px(lx, 0, lz), wr.py(lx, 0, lz), wr.pz(lx, 0, lz))
                        .aim(wr.dx(tx, (k % 2 == 0 ? 0.45 : -0.25), tz), wr.dy(tx, (k % 2 == 0 ? 0.45 : -0.25), tz),
                                wr.dz(tx, (k % 2 == 0 ? 0.45 : -0.25), tz), wr.dx(Math.cos(a), 0, Math.sin(a)),
                                wr.dy(Math.cos(a), 0, Math.sin(a)), wr.dz(Math.cos(a), 0, Math.sin(a)));
                m.ellipsoid(leaf, 0, 0.022, 0, 0.012, 0.028, 0.004, 4, 3);
            }
        }

        // himation: rok panjang dari pinggang + selempang di dada (bahu kanan terbuka) + jubah di bahu kiri
        Frame robe = r.f3.identity().at(r.pelvis.ox, 0, r.pelvis.oz);
        int n = 6;
        double[] ys = {1.12, 0.98, 0.76, 0.54, 0.4, 0.33};
        double[] rx = {0.19, 0.205, 0.245, 0.28, 0.3, 0.305};
        double[] rz = {0.135, 0.15, 0.19, 0.22, 0.235, 0.24};
        double[] cz = {0.0, 0.0, 0.02, 0.03, 0.035, 0.035};
        double[] amp = {0.0, 0.015, 0.03, 0.045, 0.055, 0.058};
        double wave = t * 0.05;
        GodMesh.Fold folds = (k, a) -> 1.0 + amp[k] * Math.sin(a * 10.0 + 0.9 * Math.sin(wave + k * 0.6));
        m.mat(ZEU_ROBE, 0.9f, 0.12f).lathe(robe, null, ys, cz, rx, rz, n, 20, 0, Math.PI * 2, folds, false);
        double[] hem = new double[20 * 3];
        for (int i = 0; i < 20; i++) {
            double a = Math.PI * 2.0 * i / 20;
            double mm = folds.at(5, a);
            robe.point(rx[5] * mm * Math.cos(a), 0.345, cz[5] + rz[5] * mm * Math.sin(a), hem, i * 3);
        }
        double[] hemR = new double[20];
        java.util.Arrays.fill(hemR, 0.014);
        m.mat(ZEU_GOLD, 0.95f, 0.55f).tube(hem, hemR, 20, 4, false, 0, 1, 0, 1.0, true);
        // selempang dari bahu kiri ke pinggang kanan (depan & belakang)
        for (int s = -1; s <= 1; s += 2) {
            double[] sp = new double[4 * 3];
            r.chest.point(0.15, b.chestLen - 0.005, s * 0.05, sp, 0);
            r.chest.point(0.03, b.chestLen * 0.62, s * (b.chestRz + 0.014), sp, 3);
            r.chest.point(-0.11, b.chestLen * 0.26, s * (b.chestRz * 0.95 + 0.012), sp, 6);
            r.pelvis.point(-0.17, 0.05, s * 0.09, sp, 9);
            double[] sw = new double[4 * 3];
            for (int k = 0; k < 4; k++) {
                int a = Math.max(0, k - 1) * 3, bb = Math.min(3, k + 1) * 3;
                double tx = sp[bb] - sp[a], ty = sp[bb + 1] - sp[a + 1], tz = sp[bb + 2] - sp[a + 2];
                // lebar = garis singgung x arah depan dada
                double wx = ty * r.chest.zz - tz * r.chest.zy, wy = tz * r.chest.zx - tx * r.chest.zz, wz = tx * r.chest.zy - ty * r.chest.zx;
                double wl = Math.sqrt(wx * wx + wy * wy + wz * wz);
                sw[k * 3] = wx / wl; sw[k * 3 + 1] = wy / wl; sw[k * 3 + 2] = wz / wl;
            }
            m.mat(ZEU_ROBE, 0.9f, 0.12f).ribbon(sp, sw, new double[] {0.13, 0.16, 0.17, 0.16}, 4, 3, 0.0);
        }
        double[] mp = new double[4 * 3], mw = new double[4 * 3];
        r.chest.point(0.18, b.chestLen, -0.03, mp, 0);
        r.chest.point(0.2, b.chestLen * 0.45, -b.chestRz - 0.03, mp, 3);
        double sway = Math.sin(t * 0.055) * 0.02;
        mp[6] = r.pelvis.ox + 0.22 + sway; mp[7] = 0.72; mp[8] = r.pelvis.oz - 0.22;
        mp[9] = r.pelvis.ox + 0.23 + sway * 2; mp[10] = 0.36; mp[11] = r.pelvis.oz - 0.26;
        for (int k = 0; k < 4; k++) {
            Frame f = k < 2 ? r.chest : r.pelvis;
            mw[k * 3] = f.xx; mw[k * 3 + 1] = f.xy; mw[k * 3 + 2] = f.xz;
        }
        m.mat(ZEU_ROBE, 0.88f, 0.12f).ribbon(mp, mw, new double[] {0.16, 0.26, 0.3, 0.28}, 4, 3, 0.4);

        // petir (keraunos) di tangan kanan
        double[] bd = new double[3];
        double bdx = lerp(throwIt, 0.12, aim[0]), bdy = lerp(throwIt, 0.28, aim[1]), bdz = lerp(throwIt, 1.0, aim[2]);
        double bl = Math.sqrt(bdx * bdx + bdy * bdy + bdz * bdz);
        bd[0] = bdx / bl; bd[1] = bdy / bl; bd[2] = bdz / bl;
        double[] hd = new double[3];
        dir(r.elR, r.wrR[0], r.wrR[1], r.wrR[2], hd);
        Frame bf = r.f3.identity().at(r.wrR[0] + hd[0] * 0.06, r.wrR[1] + hd[1] * 0.06, r.wrR[2] + hd[2] * 0.06)
                .aim(bd[0], bd[1], bd[2], 0, 1, 0);
        thunderbolt(m, bf, t);
        m.anchor(GodMesh.FOCUS, bf.ox, bf.oy, bf.oz);
        m.anchorDir(GodMesh.FOCUS, bd[0], bd[1], bd[2]);
        double tip = 0.43 * BOLT_SIZE;
        m.anchor(GodMesh.EXTRA, bf.px(0, tip, 0), bf.py(0, tip, 0), bf.pz(0, tip, 0));
        m.anchor(GodMesh.EXTRA2, bf.px(0, -tip, 0), bf.py(0, -tip, 0), bf.pz(0, -tip, 0));
    }

    /** Ukuran petir Zeus. */
    private static final double BOLT_SIZE = 1.45;

    /** Petir Zeus: pegangan di tengah, tiap ujung bercabang tiga zig-zag yang runcing. */
    static void thunderbolt(GodMesh m, Frame f, double t) {
        double k0 = BOLT_SIZE, kr = 1.25;
        m.mat(ZEU_BOLT, 1f, 1f);
        double[] grip = new double[6];
        f.point(0, -0.075 * k0, 0, grip, 0);
        f.point(0, 0.075 * k0, 0, grip, 3);
        m.tube(grip, new double[] {0.026 * kr, 0.026 * kr}, 2, 7, true, f.zx, f.zy, f.zz, 1.0);
        loop(m, f, 0, 0.034 * kr, 0.034 * kr, 0, 0.012, 8);
        double flick = Math.sin(t * 1.7) * 0.006;
        for (int s = -1; s <= 1; s += 2) {
            double[][] prongs = {
                    {0, 0.07, 0.02, 0.13, -0.026, 0.19, 0.02, 0.26, -0.012, 0.33, 0.0, 0.43},
                    {0, 0.07, 0.042, 0.11, 0.085, 0.16, 0.068, 0.22, 0.102, 0.27, 0.086, 0.32},
                    {0, 0.07, -0.042, 0.11, -0.085, 0.16, -0.068, 0.22, -0.102, 0.27, -0.086, 0.32}};
            double[][] radii = {{0.022, 0.02, 0.017, 0.013, 0.008, 0.0}, {0.016, 0.015, 0.013, 0.01, 0.006, 0.0},
                    {0.016, 0.015, 0.013, 0.01, 0.006, 0.0}};
            for (int k = 0; k < 3; k++) {
                double[] pts = new double[6 * 3];
                double[] rad = new double[6];
                for (int i = 0; i < 6; i++) {
                    double lx = (prongs[k][i * 2] + (i > 0 ? flick : 0)) * k0, ly = s * prongs[k][i * 2 + 1] * k0;
                    f.point(lx, ly, 0, pts, i * 3);
                    rad[i] = radii[k][i] * kr;
                }
                m.tube(pts, rad, 6, 6, true, f.zx, f.zy, f.zz, 1.0);
            }
        }
    }

    // ================================================================== A - ACHILLES

    private static final int ACH_SKIN = 0xFFE4C2, ACH_GOLD = 0xF2B540, ACH_BRONZE = 0xE0A040, ACH_RED = 0xEE4636;
    private static final int ACH_LEATHER = 0xD9A050, ACH_WOOD = 0xC89A5E;

    static void achilles(GodMesh m, Pose p) {
        Rig r = RIG;
        Body b = ACHILLES_BODY;
        double t = p.time, c = smooth(p.converge);
        double breath = Math.sin(t * 0.09);
        // berlutut di balik perisai di tengah api (0-12), bangkit sambil menghentak perisai (12-18)
        double crouch = p.tau < 12 ? 1.0 : 1.0 - smooth((p.tau - 12) / 5.0);
        double thrust = p.tau < 11 ? 0.0 : Math.max(0.0, 1.0 - Math.abs(p.tau - 13.5) / 3.5);
        r.torso(b, 0, -0.03 - 0.22 * crouch, 0, 0, 2 + 14 * crouch + breath * 0.5, 0, 3 * crouch, 0, -6 + 10 * thrust,
                lerp(c, 4 - 6 * crouch, -12), 0, 0);
        r.legL(0.15, 0.07, 0.16 + 0.1 * crouch, 0.15, 0.3, 1);
        r.legR(-0.15, 0.07, -0.12 - 0.08 * crouch, -0.15, 0.3, 1);

        // perisai di lengan kiri
        double lhx = lerp(crouch, 0.08, 0.04) + thrust * 0.02;
        double lhy = lerp(crouch, 1.22, 1.24) + thrust * 0.08;
        double lhz = lerp(crouch, 0.42, 0.4) + thrust * 0.16;
        r.armL(lhx, lhy, lhz, 1, -0.3, 0);
        // tombak di tangan kanan: tegak (diam), rendah ke depan (berlutut), menunjuk kepalan (menyatu)
        double[] aim = new double[3];
        dir(r.shR, p.aimX, p.aimY, p.aimZ, aim);
        double ghx = lerp(crouch, -0.3, -0.28), ghy = lerp(crouch, 1.22, 0.92), ghz = lerp(crouch, 0.18, 0.22);
        ghx = lerp(c, ghx, r.shR[0] + aim[0] * 0.35);
        ghy = lerp(c, ghy, r.shR[1] + 0.12 + aim[1] * 0.35);
        ghz = lerp(c, ghz, r.shR[2] + aim[2] * 0.35);
        r.armR(ghx, ghy, ghz, -0.5, -1, -0.3);
        double sdx = lerp(crouch, 0.01, 0.0), sdy = lerp(crouch, 1.0, 0.4), sdz = lerp(crouch, 0.02, 0.92);
        sdx = lerp(c, sdx, aim[0]);
        sdy = lerp(c, sdy, aim[1]);
        sdz = lerp(c, sdz, aim[2]);
        double sl = Math.sqrt(sdx * sdx + sdy * sdy + sdz * sdz);
        sdx /= sl; sdy /= sl; sdz /= sl;

        // badan berbaju zirah emas
        torso(m, r, ACH_GOLD, 0.94f, 0.22f);
        muscles(m, r, ACH_GOLD, 0.94f, 0.22f, 1.0);
        Frame pv = r.pelvis;
        loop(m.mat(ACH_BRONZE, 0.95f, 0.3f), r.chest, 0.01, b.waistRx * 1.06, b.waistRz * 1.08, 0, 0.018, 16);
        // pelindung bahu
        for (int s = -1; s <= 1; s += 2) {
            double[] sh = s > 0 ? r.shL : r.shR;
            Frame f = r.f1.set(r.chest).at(sh[0], sh[1], sh[2]).move(s * 0.012, 0.02, 0).rotZ(-s * 18);
            m.mat(ACH_GOLD, 0.95f, 0.25f).ellipsoid(f, 0, 0, 0, 0.1, 0.075, 0.1, 12, 6, 0, Math.PI * 0.55, 0);
        }
        m.mat(ACH_SKIN, 0.9f, 0.06f);
        limbArm(m, r, true, b.limb);
        limbArm(m, r, false, b.limb);
        hand(m, r, true, 1.05, 1, 0, 0, true);
        hand(m, r, false, 1.05, -1, 0, 0, true);
        leg(m, r, true, b.limb, 0.15, 1, 0, true);
        leg(m, r, false, b.limb, -0.15, 1, 0, true);
        // pelindung lengan & tulang kering
        for (int s = -1; s <= 1; s += 2) {
            double[] el = s > 0 ? r.elL : r.elR, wr = s > 0 ? r.wrL : r.wrR;
            double[] br = {lerp(0.35, el[0], wr[0]), lerp(0.35, el[1], wr[1]), lerp(0.35, el[2], wr[2]),
                    lerp(0.95, el[0], wr[0]), lerp(0.95, el[1], wr[1]), lerp(0.95, el[2], wr[2])};
            m.mat(ACH_GOLD, 0.95f, 0.25f).tube(br, new double[] {0.06 * b.limb, 0.046 * b.limb}, 2, 8, true, 0, 1, 0, 1.0);
            double[] kn = s > 0 ? r.knL : r.knR, an = s > 0 ? r.anL : r.anR;
            double[] gr = {lerp(0.06, kn[0], an[0]), lerp(0.06, kn[1], an[1]), lerp(0.06, kn[2], an[2]),
                    lerp(0.4, kn[0], an[0]), lerp(0.4, kn[1], an[1]), lerp(0.4, kn[2], an[2]),
                    lerp(0.9, kn[0], an[0]), lerp(0.9, kn[1], an[1]), lerp(0.9, kn[2], an[2])};
            m.tube(gr, new double[] {0.068 * b.limb, 0.074 * b.limb, 0.052 * b.limb}, 3, 8, true, pv.zx, pv.zy, pv.zz, 1.0);
        }
        // rok bertali (pteruges)
        double[] ly = {0.06, -0.04, -0.16, -0.27};
        double[] lrx = {b.hipRx * 1.06, b.hipRx * 1.14, b.hipRx * 1.28, b.hipRx * 1.36};
        double[] lrz = {b.hipRz * 1.12, b.hipRz * 1.26, b.hipRz * 1.46, b.hipRz * 1.56};
        m.mat(ACH_LEATHER, 0.93f, 0.15f).lathe(pv, null, ly, null, lrx, lrz, 4, 28, 0, Math.PI * 2,
                (k, a) -> 1.0 + 0.06 * Math.tanh(4.0 * Math.sin(a * 14.0)) * (k > 0 ? 1 : 0), false);

        // jubah merah di punggung
        double flutter = Math.sin(t * 0.07) * 0.025;
        double[] cp = new double[5 * 3], cw = new double[5 * 3];
        r.chest.point(0, b.chestLen - 0.01, -0.11, cp, 0);
        r.chest.point(0, b.chestLen * 0.45, -b.chestRz - 0.05, cp, 3);
        pv.point(0, -0.05, -b.hipRz - 0.09, cp, 6);
        cp[9] = pv.ox + flutter; cp[10] = 0.55 + crouch * 0.1; cp[11] = pv.oz - 0.3 - crouch * 0.1;
        cp[12] = pv.ox + flutter * 2; cp[13] = 0.28 + crouch * 0.18; cp[14] = pv.oz - 0.4 - crouch * 0.2;
        for (int k = 0; k < 5; k++) {
            Frame f = k < 2 ? r.chest : pv;
            cw[k * 3] = f.xx; cw[k * 3 + 1] = f.xy; cw[k * 3 + 2] = f.xz;
        }
        m.mat(ACH_RED, 0.9f, 0.15f).ribbon(cp, cw, new double[] {0.36, 0.46, 0.5, 0.52, 0.54}, 5, 4, 0.45);

        // kepala + helm berjambul
        head(m, r, ACH_SKIN, 0.9f, 0.06f, false);
        Frame h = r.head;
        double hc = r.hc;
        m.mat(ACH_GOLD, 0.95f, 0.28f).ellipsoid(h, 0, hc + 0.012, -0.004, b.headRx * 1.14, b.headRy * 1.1, b.headRz * 1.14,
                16, 8, 0, Math.PI * 0.5, Math.PI * 0.3);
        for (int s = -1; s <= 1; s += 2) {
            Frame cg = r.f1.set(h).move(s * 0.083, hc - 0.04, 0.055).rotZ(s * 6).rotY(-s * 22);
            m.ellipsoid(cg, 0, 0, 0, 0.022, 0.068, 0.055, 8, 6);
        }
        m.box(h, 0, hc - 0.005, b.headRz * 1.13, 0.012, 0.05, 0.012);
        // jambul merah: busur dari dahi ke tengkuk
        int cn = 9;
        double[] cr = new double[cn * 3], crad = new double[cn];
        for (int k = 0; k < cn; k++) {
            double u = k / (double) (cn - 1);
            double a = Math.toRadians(lerp(u, 32, -150));
            double tall = 0.05 + 0.085 * Math.sin(Math.PI * Math.min(1.0, u * 1.25));
            double rad = 0.135 + tall * 0.5;
            h.point(0, hc + 0.01 + Math.cos(a) * rad, Math.sin(a) * rad - 0.01, cr, k * 3);
            crad[k] = Math.max(0.006, tall * 0.5 / 4.2);
        }
        m.mat(ACH_RED, 0.93f, 0.22f).tube(cr, crad, cn, 8, true, h.xx, h.xy, h.xz, 4.2);

        // perisai bundar
        double scx = lerp(0.5, r.elL[0], r.wrL[0]), scy = lerp(0.5, r.elL[1], r.wrL[1]), scz = lerp(0.5, r.elL[2], r.wrL[2]);
        double snx = 0.35 + 0.1 * thrust, sny = 0.05 + 0.15 * crouch, snz = 1.0;
        Frame sf = r.f3.identity().at(scx + snx * 0.07, scy, scz + 0.07).aim(snx, sny, snz, 0, 1, 0);
        shield(m, sf);
        m.anchor(GodMesh.EXTRA, sf.px(0, 0.09, 0), sf.py(0, 0.09, 0), sf.pz(0, 0.09, 0));
        m.anchorDir(GodMesh.EXTRA, sf.yx, sf.yy, sf.yz);
        m.anchorDir(GodMesh.EXTRA2, sf.zx, sf.zy, sf.zz);
        m.extraSize = 0.36f;

        // tombak
        double len = 2.5;
        double bx = r.wrR[0] - sdx * 1.15, by = r.wrR[1] - sdy * 1.15, bz = r.wrR[2] - sdz * 1.15;
        Frame spf = r.f1.identity().at(bx, by, bz).aim(sdx, sdy, sdz, 1, 0, 0);
        double[] shaft = new double[6];
        spf.point(0, 0, 0, shaft, 0);
        spf.point(0, len, 0, shaft, 3);
        m.mat(ACH_WOOD, 0.93f, 0.12f).tube(shaft, new double[] {0.017, 0.016}, 2, 6, true, spf.xx, spf.xy, spf.xz, 1.0);
        m.mat(ACH_GOLD, 0.97f, 0.7f).ellipsoid(spf, 0, len + 0.14, 0, 0.042, 0.16, 0.011, 8, 6);
        double[] collar = new double[6];
        spf.point(0, len - 0.03, 0, collar, 0);
        spf.point(0, len + 0.02, 0, collar, 3);
        m.tube(collar, new double[] {0.022, 0.02}, 2, 6, true, spf.xx, spf.xy, spf.xz, 1.0);
        m.spike(spf.px(0, 0.05, 0), spf.py(0, 0.05, 0), spf.pz(0, 0.05, 0), spf.px(0, -0.07, 0), spf.py(0, -0.07, 0),
                spf.pz(0, -0.07, 0), 0.016, 5);
        m.anchor(GodMesh.FOCUS, spf.px(0, len + 0.26, 0), spf.py(0, len + 0.26, 0), spf.pz(0, len + 0.26, 0));
        m.anchorDir(GodMesh.FOCUS, sdx, sdy, sdz);
        m.anchor(GodMesh.EXTRA2, spf.px(0, len + 0.12, 0), spf.py(0, len + 0.12, 0), spf.pz(0, len + 0.12, 0));
    }

    /** Perisai bundar cembung (aspis): sumbu Y frame = arah hadap perisai. */
    static void shield(GodMesh m, Frame f) {
        double R = 0.36;
        double[] ys = {0.09, 0.083, 0.068, 0.058, 0.05, 0.034, 0.012, -0.004, -0.018, -0.024, -0.026};
        double[] rs = {0.0, 0.035, 0.06, 0.08, 0.17, 0.27, R * 0.985, R, R * 0.975, R * 0.86, 0.0};
        m.mat(ACH_GOLD, 0.95f, 0.16f).lathe(f, null, ys, null, rs, rs, ys.length, 26, 0, Math.PI * 2, null, false);
        m.mat(ACH_BRONZE, 0.97f, 0.45f);
        loop(m, f, 0.004, R * 1.005, R * 1.005, 0, 0.018, 28);
        loop(m, f, 0.05, 0.2, 0.2, 0, 0.01, 22);
    }

    // ================================================================== M - MERCURY

    private static final int MER_SKIN = 0xEAFDFF, MER_TUNIC = 0xF4FCFF, MER_CAPE = 0x84D6FF, MER_HAT = 0xD6F6FF;
    private static final int MER_WING = 0xFFFFFF, MER_GOLD = 0xFFE08A, MER_SNAKE = 0xB8F0D0;

    static void mercury(GodMesh m, Pose p) {
        Rig r = RIG;
        Body b = MERCURY_BODY;
        double t = p.time, c = smooth(p.converge);
        // berlari secepat kilat (0-8), mengerem (8-10), berjinjit di satu kaki (10-14)
        double run = p.tau < 8 ? 1.0 : 1.0 - smooth((p.tau - 8) / 2.5);
        double brake = p.tau < 7 ? 0.0 : Math.max(0.0, 1.0 - Math.abs(p.tau - 9.0) / 2.5);
        double idle = 1.0 - run;
        double bob = Math.sin(t * 0.11) * 0.012;
        double stride = Math.sin(p.tau * 2.4);
        r.torso(b, 0, 0.12 * idle + 0.05 * run + bob, 0, 0, 8 * idle + 30 * run - 12 * brake, -5 * idle, 4 * idle, -3 * idle, 0,
                lerp(c, -10 * idle - 8 * run, -14), 0, 0);
        // kaki: kiri lurus berjinjit, kanan ditekuk ke belakang; berlari: melangkah lebar
        r.legL(lerp(run, 0.06, 0.1), lerp(run, 0.21 + bob, 0.42 + 0.2 * stride), lerp(run, 0.03, 0.42 * stride),
                0, 0.2, 1);
        r.legR(lerp(run, -0.08, -0.1), lerp(run, 0.64 + bob, 0.42 - 0.2 * stride), lerp(run, -0.36, -0.42 * stride),
                0, -0.4, 1);
        // tangan kanan menunjuk langit (atau kepalan saat menyatu); tangan kiri memegang caduceus
        double[] aim = new double[3];
        dir(r.shR, p.aimX, p.aimY, p.aimZ, aim);
        double rhx = lerp(run, -0.1, -0.26), rhy = lerp(run, 2.3, 1.2 - 0.15 * stride), rhz = lerp(run, 0.16, -0.35 * stride);
        rhx = lerp(c, rhx, r.shR[0] + aim[0] * 0.56);
        rhy = lerp(c, rhy, r.shR[1] + aim[1] * 0.56);
        rhz = lerp(c, rhz, r.shR[2] + aim[2] * 0.56);
        r.armR(rhx, rhy, rhz, -1, 0, -0.2);
        r.armL(lerp(run, 0.24, 0.26), lerp(run, 1.0, 1.15 + 0.12 * stride), lerp(run, 0.16, 0.3 * stride), 1, -0.5, -0.5);

        torso(m, r, MER_TUNIC, 0.9f, 0.1f);
        deltoids(m, r, MER_SKIN, 0.9f, 0.08f, b.limb * 0.9);
        m.mat(MER_SKIN, 0.9f, 0.08f);
        limbArm(m, r, true, b.limb);
        limbArm(m, r, false, b.limb);
        hand(m, r, true, 0.95, 1, 0, 0, true);
        hand(m, r, false, 0.95, 0, 0, 1, false);
        leg(m, r, true, b.limb, 0.05, 1, lerp(run, 62, 20), true);
        leg(m, r, false, b.limb, -0.05, 1, lerp(run, 35, 20), true);
        head(m, r, MER_SKIN, 0.9f, 0.08f, true);
        hairCap(m, r, 0xFFF4D0, 0.88f, 0.1f, 1.06, 0.55);

        // tunik pendek berkibar + ikat pinggang
        Frame pv = r.pelvis;
        double flutter = t * 0.16;
        double[] ly = {0.08, -0.05, -0.18, -0.28};
        double[] lrx = {b.hipRx * 1.06, b.hipRx * 1.18, b.hipRx * 1.34, b.hipRx * 1.44};
        double[] lrz = {b.hipRz * 1.14, b.hipRz * 1.3, b.hipRz * 1.52, b.hipRz * 1.64};
        double[] lcz = {0, -0.005 - 0.03 * run, -0.01 - 0.07 * run, -0.015 - 0.11 * run};
        m.mat(MER_TUNIC, 0.9f, 0.1f).lathe(pv, null, ly, lcz, lrx, lrz, 4, 18, 0, Math.PI * 2,
                (k, a) -> 1.0 + 0.045 * k * Math.sin(a * 9 + flutter + k), false);
        loop(m.mat(MER_CAPE, 0.95f, 0.45f), r.chest, 0.01, b.waistRx * 1.07, b.waistRz * 1.1, 0, 0.014, 14);

        // jubah pendek (chlamys) berkibar ke belakang
        double wind = 0.15 + run * 0.35;
        double[] cp = new double[5 * 3], cw = new double[5 * 3];
        r.chest.point(-0.1, b.chestLen - 0.01, -0.06, cp, 0);
        r.chest.point(0.0, b.chestLen * 0.55, -b.chestRz - 0.05, cp, 3);
        double wav = Math.sin(t * 0.21);
        cp[6] = r.chest.ox + 0.02 + wav * 0.02; cp[7] = r.chest.oy + 0.1 - wind * 0.1; cp[8] = r.chest.oz - 0.25 - wind * 0.35;
        cp[9] = r.chest.ox + 0.03 - wav * 0.03; cp[10] = r.chest.oy - 0.12 + wind * 0.05; cp[11] = r.chest.oz - 0.35 - wind * 0.6;
        cp[12] = r.chest.ox + 0.04 + wav * 0.05; cp[13] = r.chest.oy - 0.3 + wind * 0.15; cp[14] = r.chest.oz - 0.45 - wind * 0.85;
        for (int k = 0; k < 5; k++) {
            cw[k * 3] = r.chest.xx; cw[k * 3 + 1] = r.chest.xy; cw[k * 3 + 2] = r.chest.xz;
        }
        m.mat(MER_CAPE, 0.88f, 0.2f).ribbon(cp, cw, new double[] {0.3, 0.36, 0.4, 0.42, 0.4}, 5, 3, 0.3);

        // topi bersayap (petasos)
        Frame h = r.head;
        double hc = r.hc;
        m.mat(MER_HAT, 0.93f, 0.25f).ellipsoid(h, 0, hc + 0.03, -0.005, b.headRx * 1.12, b.headRy * 0.98, b.headRz * 1.12, 14, 7,
                0, Math.PI * 0.46, 0);
        double[] by = {hc + 0.045, hc + 0.045};
        double[] brx = {b.headRx * 1.08, b.headRx * 1.62}, brz = {b.headRz * 1.08, b.headRz * 1.62};
        m.lathe(h, null, by, null, brx, brz, 2, 18, 0, Math.PI * 2, null, true);
        double flap = Math.sin(t * 0.35) * 6;
        Frame wf = r.f1;
        for (int s = -1; s <= 1; s += 2) {
            wf.set(h).move(s * b.headRx * 1.05, hc + 0.06, -0.03);
            wf.aim(h.dx(s * 0.35, 0.8, -0.55), h.dy(s * 0.35, 0.8, -0.55), h.dz(s * 0.35, 0.8, -0.55), h.xx * s, h.xy * s, h.xz * s);
            wf.rotZ(s * flap);
            m.mat(MER_WING, 0.9f, 0.45f).featherFan(wf, 4, Math.toRadians(70), 0.19, 0.022, 0.006);
        }
        // sayap di pergelangan kaki
        for (int s = -1; s <= 1; s += 2) {
            double[] an = s > 0 ? r.anL : r.anR;
            wf.identity().at(an[0] + s * 0.04, an[1] + 0.02, an[2] - 0.02);
            wf.aim(s * 0.3, 0.55, -0.8, s, 0, 0).rotZ(s * flap);
            m.featherFan(wf, 3, Math.toRadians(60), 0.13, 0.018, 0.005);
        }

        // caduceus: tongkat emas, dua ular melilit, sepasang sayap, bola di puncak
        double ax0 = r.wrL[0] + 0.02 - 0.05 * run, ay0 = r.wrL[1] - 0.42, az0 = r.wrL[2] - 0.04;
        double ax1 = r.wrL[0] + 0.07, ay1 = r.wrL[1] + 0.56, az1 = r.wrL[2] + 0.05 + 0.2 * run;
        double[] staff = {ax0, ay0, az0, ax1, ay1, az1};
        m.mat(MER_GOLD, 0.96f, 0.55f).tube(staff, new double[] {0.016, 0.014}, 2, 6, true, 1, 0, 0, 1.0);
        double dx = ax1 - ax0, dy = ay1 - ay0, dz = az1 - az0;
        double dl = Math.sqrt(dx * dx + dy * dy + dz * dz);
        Frame cf = r.f2.identity().at(ax0, ay0, az0).aim(dx / dl, dy / dl, dz / dl, 0, 0, 1);
        for (int s = 0; s < 2; s++) {
            int sn = 13;
            double[] sp = new double[sn * 3], sr = new double[sn];
            for (int i = 0; i < sn; i++) {
                double u = 0.15 + 0.68 * i / (sn - 1);
                double a = Math.PI * 2.0 * 2.25 * u + s * Math.PI;
                double rr = 0.034 * (0.6 + 0.4 * Math.sin(Math.PI * Math.min(1, u * 1.2)));
                cf.point(Math.cos(a) * rr, u * dl, Math.sin(a) * rr, sp, i * 3);
                sr[i] = 0.011 * (0.4 + 0.6 * Math.min(1.0, (u - 0.15) * 4.0));
            }
            m.mat(MER_SNAKE, 0.93f, 0.35f).tube(sp, sr, sn, 5, true, dx / dl, dy / dl, dz / dl, 1.0);
            int last = (sn - 1) * 3;
            m.ellipsoid(r.f3.identity(), sp[last], sp[last + 1] + 0.012, sp[last + 2], 0.02, 0.016, 0.026, 6, 4);
        }
        m.mat(MER_GOLD, 0.97f, 0.7f).ellipsoid(cf, 0, dl + 0.02, 0, 0.032, 0.032, 0.032, 8, 6);
        for (int s = -1; s <= 1; s += 2) {
            wf.set(cf).move(s * 0.02, dl - 0.06, 0).rotZ(-s * 62);
            m.mat(MER_WING, 0.9f, 0.45f).featherFan(wf, 3, Math.toRadians(55), 0.12, 0.016, 0.005);
        }
        m.anchor(GodMesh.FOCUS, cf.px(0, dl + 0.02, 0), cf.py(0, dl + 0.02, 0), cf.pz(0, dl + 0.02, 0));
        m.anchorDir(GodMesh.FOCUS, dx / dl, dy / dl, dz / dl);
        m.anchor(GodMesh.EXTRA, m.anchor[GodMesh.HAND_R * 3], m.anchor[GodMesh.HAND_R * 3 + 1], m.anchor[GodMesh.HAND_R * 3 + 2]);
        m.anchor(GodMesh.EXTRA2, r.anL[0], r.anL[1] - 0.1, r.anL[2] + 0.03);
        m.extraSize = (float) run;
    }
}
