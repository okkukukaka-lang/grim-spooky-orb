package com.shazammod.client.anim;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.joml.Matrix4f;
import org.joml.Vector3f;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamPowers;
import com.shazammod.client.fx.ShazamFx;
import com.shazammod.client.render.CapeDecor;
import com.shazammod.client.render.FormLook;
import com.shazammod.client.render.ShazamCape;
import com.shazammod.client.render.ShazamEmblemLayer;
import com.shazammod.client.vfx.Draw;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.ClipContext;

/**
 * Otak animasi Shazam di client. Lapisannya, dari bawah ke atas:
 * 1. pose terbang: melayang, meluncur (satu kepalan di depan), super cepat (dua kepalan di depan),
 *    mengerem. Kemiringan badan, menikung, menghadap lintasan, kelembaman tangan-kaki, getar angin, dan
 *    ancang-ancang mendarat dihitung dari fisika gerak (FlightPose), plus barrel roll,
 * 2. pose berdiri gagah saat diam,
 * 3. lari super cepat Mode Kilat Mercury: lutut didorong tinggi, lengan memompa, bahu berputar, badan condong ke
 *    depan dan ke dalam tikungan, naik-turun tiap langkah, dan pose mengerem yang tergelincir,
 * 4. klip gerakan (lihat Clips).
 * Ditambah pergantian kostum, bayangan berjejak Mercury (lengkap dengan jubah, mantel, hood, list emas, dan
 * pendar listrik di tepi siluetnya), dan aura Kulit Achilles.
 */
public final class ShazamPoses {
    private ShazamPoses() {}

    // ======= Bayangan berjejak (afterimage) =======
    private static final float GHOST_LIFE = 10f;                   // terjangan Kilat Mercury (tick)
    private static final float MERCURY_GHOST_LIFE = 6.5f;          // lari super cepat: ±0,3 detik
    private static final double GHOST_SPACING = 1.1;               // jarak antar-bayangan terjangan (blok)
    private static final double MERCURY_GHOST_SPACING = 1.05;      // lari super cepat: tiap ±1 blok (seperti foto strobo)
    private static final float GHOST_MAX_GAP = 1f;                 // paling jarang satu bayangan tiap tick
    private static final int MAX_GHOSTS = 22;
    private static final float GHOST_ALPHA = 0.46f;                // kepekatan bayangan terbaru (0-1)
    private static final float GHOST_RIM = 0.95f;                  // terang pendar listrik di tepi siluet bayangan terbaru
    private static final float GHOST_CLOTH_GLOW = 0.45f;           // pendar di kain bayangan (dibanding badan)
    private static final double GHOST_NEAR = 1.3, GHOST_CLEAR = 4.2; // bayangan sedekat ini ke kamera memudar (nggak menutupi layar)
    private static final int BLITZ_GHOST = 0xFFECAA;
    private static final int MERCURY_GHOST = 0xB4E4FF;             // bayangan terbaru: biru muda terang
    private static final int MERCURY_GHOST_OLD = 0x2F6BFF;         // makin tua makin biru listrik pekat
    private static final int MERCURY_RIM = 0x33B4FF;               // pendar tepi: biru listrik jenuh
    private static final int MERCURY_RIM_FRESH = 0xA8ECFF;
    private static final int BLITZ_RIM = 0xFFC860;
    private static final int GHOST_GOLD = 0xF5CF6E;
    private static final int HERU_GHOST = 0xFFC27A;                // Sambaran Heru (Black Adam): emas membara
    private static final int HERU_RIM = 0xFF8A2A;
    // ======= Lari super cepat =======
    private static final float RUN_BANK_G = 0.5f;                  // makin kecil, makin miring saat menikung
    private static final float RUN_BANK_MAX = 32f;                 // condong ke dalam tikungan paling banyak (derajat)
    private static final float SKID_TILT = -16f;                   // mengerem: badan condong ke belakang (derajat)
    private static final float SKID_DROP = 0.14f;                  // mengerem: badan merendah (blok)
    private static final float TWO_PI = (float) (Math.PI * 2.0);
    private static final int ROLL_TICKS = 10;
    /** Lama klip lama memudar saat klip baru mulai (tick), supaya pergantian gerakan nggak meloncat. */
    private static final float XFADE = 4f;
    /** Lama kostum terbentuk / luruh (tick). */
    public static final int SUIT_TICKS = 16;

    private static final class State {
        Clip clip;
        ShazamAnim anim;
        int startAge;
        Clip prevClip;           // klip yang baru saja diganti (masih memudar)
        int prevStart;
        int prevCut;
        float flight, flightO;   // sedang terbang (0-1)
        float soar, soarO;       // meluncur, badan rebah (0-1)
        float boost, boostO;     // super cepat (0-1)
        float brake, brakeO;     // mengerem (0-1)
        float tilt, tiltO;       // kemiringan badan (derajat, positif = condong ke depan)
        float bank, bankO;       // menikung (derajat)
        float side, sideO;       // miring ke samping saat melayang (derajat)
        float yawOff, yawOffO;   // badan menghadap lintasan (derajat, relatif arah pandang)
        float leg, legO;         // kaki lembam (radian)
        float arm, armO;         // lengan lembam (radian)
        float flutter, flutterO; // fase getar angin
        float flutterAmp;
        final FlightPose pose = new FlightPose();
        float stance, stanceO;
        float run, runO;         // lari super cepat Mode Kilat (0-1)
        float phase, phaseO;     // fase langkah (radian)
        float lean, leanO;       // condong badan saat lari (derajat)
        float lastHoriz;
        float speed;
        int idleTicks;
        int rollStart = -1000;
        int rollDir;
        int auraStart = -1;
        int auraEnd = -1;
        int ghostUntil = -1;
        final float[] lastBody = new float[5];   // {tilt, drop, roll, side, yaw} badan di render terakhir
        final ArrayDeque<Ghost> ghosts = new ArrayDeque<>();
        double ghostX, ghostY, ghostZ;           // posisi bayangan terakhir
        float ghostTime = -1000f;
        float runSide, runSideO;                 // lari: condong ke dalam tikungan (derajat)
        float skid, skidO;                       // lari: mengerem tergelincir (0-1)
        float headingX, headingZ;                // arah lari tick lalu (satuan)
        boolean wasTransformed;
        boolean suitIn;
        int suitAge = -1000;
    }

    /**
     * Satu bayangan, dibekukan persis seperti frame saat dibuat: titik asal render, arah badan, ukuran, pose seluruh
     * badan {tilt, drop, roll, side, yaw}, pose tiap bagian tubuh (atau null), kain (atau null), waktu lahir & umur.
     */
    private record Ghost(double x, double y, double z, float yaw, float scale, float[] body, float[] pose,
                         ShazamCape.GhostCloth cloth, float born, float life, boolean mercury) {}

    private static final Map<Integer, State> STATES = new HashMap<>();
    /**
     * Pose akhir bagian tubuh tiap pemain dari render terakhir (semua pemain, bukan cuma Shazam), dipakai jubah,
     * hood, mantel, dan efek. Enam bagian berurutan (kepala, badan, lengan kanan, lengan kiri, kaki kanan,
     * kaki kiri), masing-masing {x, y, z, xRot, yRot, zRot}. Satuan model (piksel, radian). Lihat BodyRig.
     */
    private static final Map<Integer, float[]> PARTS = new HashMap<>();
    public static final int PART_VALUES = 36;
    /**
     * Matriks badan sesungguhnya dari render terakhir tiap pemain (relatif ke posisi render): sama dengan
     * bodyMatrix, ditambah pose bawaan Minecraft seperti berenang, merangkak, terbang elytra, dan jatuh mati.
     */
    private static final Map<Integer, Matrix4f> BODIES = new HashMap<>();
    private static final Matrix4f RENDER_ORIGIN = new Matrix4f();

    public static void clear() {
        STATES.clear();
        PARTS.clear();
        BODIES.clear();
    }

    public static ShazamAnim currentAnim(Entity entity) {
        State state = STATES.get(entity.getId());
        return state == null ? null : state.anim;
    }

    /** Sudah berapa tick klip yang sedang diputar berjalan, atau -1 kalau nggak ada klip. */
    public static float animTime(Entity entity, float partialTick) {
        State state = STATES.get(entity.getId());
        return state == null || state.anim == null ? -1f : entity.tickCount + partialTick - state.startAge;
    }

    private static State stateFor(AbstractClientPlayer player) {
        State state = STATES.get(player.getId());
        if (state == null) {
            state = new State();
            state.wasTransformed = ShazamClientState.isTransformed(player.getId());
            STATES.put(player.getId(), state);
        }
        return state;
    }

    /** Mulai animasi untuk pemain ini. */
    public static void start(AbstractClientPlayer player, ShazamAnim anim) {
        if (anim.isMarker()) {
            return;   // efek di satu titik saja (segel, sinar, patukan): gerakan badan yang sedang jalan nggak diganti
        }
        State state = stateFor(player);
        switch (anim) {
            case ROLL_LEFT, ROLL_RIGHT -> {
                if (ShazamClientState.isAdam(player.getId())) {
                    // Black Adam nggak berakrobat: melesat menyamping tegak, meninggalkan bayangan emas membara
                    state.ghostUntil = player.tickCount + 6;
                    return;
                }
                state.rollStart = player.tickCount;
                state.rollDir = anim == ShazamAnim.ROLL_RIGHT ? 1 : -1;
                return;
            }
            case SONIC_BOOM -> {
                return;
            }
            default -> { }
        }
        if (state.clip != null) {   // klip yang sedang jalan memudar pelan, nggak langsung hilang
            state.prevClip = state.clip;
            state.prevStart = state.startAge;
            state.prevCut = player.tickCount;
        }
        state.clip = Clips.get(anim, ShazamClientState.form(player.getId()));
        state.anim = anim;
        state.startAge = player.tickCount;
        switch (anim) {
            case ACHILLES_ROAR -> {
                state.auraStart = player.tickCount + ShazamAnim.ROAR_WINDUP;
                state.auraEnd = state.auraStart + ShazamAnim.ACHILLES_TICKS;
            }
            case MERCURY_BLITZ -> state.ghostUntil = player.tickCount + ShazamAnim.BLITZ_TICKS + 2;
            case ADAM_HERU -> state.ghostUntil = player.tickCount + ShazamAnim.HERU_WINDUP + ShazamAnim.HERU_TICKS + 2;
            case REVERT, KNOCKOUT -> state.auraEnd = -1;
            default -> { }
        }
    }

    /** Bayangan berjejak sesaat (Refleks Mercury: Shazam mengelak secepat kilat). */
    public static void ghostBurst(AbstractClientPlayer player, int ticks) {
        State state = stateFor(player);
        state.ghostUntil = Math.max(state.ghostUntil, player.tickCount + ticks);
    }

    // ---------------------------------------------------------------- tick client

    public static void tick(ClientLevel level) {
        Iterator<Map.Entry<Integer, State>> iterator = STATES.entrySet().iterator();
        while (iterator.hasNext()) {
            if (!(level.getEntity(iterator.next().getKey()) instanceof AbstractClientPlayer)) {
                iterator.remove();
            }
        }
        PARTS.keySet().removeIf(id -> !(level.getEntity(id) instanceof AbstractClientPlayer));
        BODIES.keySet().removeIf(id -> !(level.getEntity(id) instanceof AbstractClientPlayer));
        for (AbstractClientPlayer player : level.players()) {
            boolean transformed = ShazamClientState.isTransformed(player.getId());
            State state = STATES.get(player.getId());
            if (state == null) {
                if (!transformed) {
                    continue;
                }
                state = new State();
                state.wasTransformed = true; // baru kelihatan dan sudah jadi Shazam: tanpa animasi kostum
                STATES.put(player.getId(), state);
            }
            tickPlayer(player, state, transformed);
        }
    }

    private static void tickPlayer(AbstractClientPlayer player, State s, boolean transformed) {
        // Kostum berganti: mulai animasi terbentuk (saat transformasi) atau luruh (saat kembali jadi manusia)
        if (transformed != s.wasTransformed) {
            if (!transformed || s.anim == ShazamAnim.TRANSFORM) {
                s.suitIn = transformed;
                s.suitAge = player.tickCount;
                player.level().playLocalSound(player.getX(), player.getY() + 1.0, player.getZ(),
                        SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.5f, transformed ? 1.4f : 0.8f, false);
            }
            s.wasTransformed = transformed;
        }

        boolean selfFlying = player == Minecraft.getInstance().player && player.getAbilities().flying;
        boolean flying = transformed && !player.onGround() && (selfFlying || ShazamClientState.isFlying(player.getId()));
        double dx = player.getX() - player.xo;
        double dy = player.getY() - player.yo;
        double dz = player.getZ() - player.zo;
        float speed = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);

        s.flightO = s.flight;
        s.soarO = s.soar;
        s.boostO = s.boost;
        s.brakeO = s.brake;
        s.tiltO = s.tilt;
        s.bankO = s.bank;
        s.sideO = s.side;
        s.yawOffO = s.yawOff;
        s.legO = s.leg;
        s.armO = s.arm;
        s.flutterO = s.flutter;
        s.stanceO = s.stance;
        s.runO = s.run;
        s.phaseO = s.phase;
        s.leanO = s.lean;
        s.runSideO = s.runSide;
        s.skidO = s.skid;

        s.flight = approach(s.flight, flying ? 1f : 0f, 0.15f);
        s.soar = approach(s.soar, flying ? FlightPose.soarTarget(dx, dy, dz, player.yBodyRot) : 0f, 0.08f);
        s.boost = approach(s.boost, flying ? Mth.clamp((speed - 2.0f) / 1.2f, 0f, 1f) : 0f, 0.06f);
        boolean braking = flying && s.speed - speed > 0.06f && s.speed > 0.5f;
        s.brake = approach(s.brake, braking ? 1f : 0f, braking ? 0.25f : 0.08f);
        s.speed = speed;

        // Pose dari fisika gerak: condong, menikung, menghadap lintasan, tungkai lembam, getar angin, mendarat
        double ground = flying && dy < -0.15 ? groundAhead(player, dx, dy, dz) : 100.0;
        s.pose.update(dx, dy, dz, player.yBodyRot, s.flight, s.soar, s.brake, ground);
        s.tilt = s.pose.tilt;
        s.bank = s.pose.bank;
        s.side = s.pose.side;
        s.yawOff = s.pose.yaw;
        s.leg = s.pose.legSwing;
        s.arm = s.pose.armSwing;
        s.flutter = s.pose.flutter;
        s.flutterAmp = s.pose.flutterAmp;

        boolean idle = transformed && player.onGround() && speed < 0.01f && !player.swinging
                && !player.isUsingItem() && !player.isCrouching() && player.getMainHandItem().isEmpty();
        s.idleTicks = idle ? s.idleTicks + 1 : 0;
        s.stance = approach(s.stance, s.idleTicks > 20 ? 1f : 0f, 0.1f);

        // Mode Kilat Mercury: lari super cepat. Langkah makin rapat saat makin kencang, badan condong ke depan
        // (lebih condong saat mempercepat, menegak saat mengerem), dan bayangan berjejak di belakang.
        boolean mercury = transformed && ShazamClientState.isMercury(player.getId());
        float horiz = (float) Math.sqrt(dx * dx + dz * dz);
        boolean running = mercury && !flying && horiz > 0.45f && (player.onGround() || horiz > 0.9f);
        s.run = approach(s.run, running ? 1f : 0f, running ? 0.2f : 0.1f);
        s.phase += Mth.clamp(0.16f + horiz * 0.07f, 0.16f, 0.34f) * TWO_PI;
        if (s.phase > TWO_PI * 100f) {
            s.phase -= TWO_PI * 100f;
            s.phaseO -= TWO_PI * 100f;
        }
        float accel = Mth.clamp((horiz - s.lastHoriz) / 0.2f, -1f, 1f);
        float leanTarget = running ? 14f + 16f * Mth.clamp(horiz / 2.6f, 0f, 1f) + 12f * accel : 0f;
        s.lean += (leanTarget - s.lean) * 0.3f;
        // condong ke dalam tikungan seperti pelari di lintasan melengkung: gaya ke pusat = laju x laju belok
        float turn = 0f;
        if (horiz > 0.05f) {
            float hx = (float) dx / horiz, hz = (float) dz / horiz;
            if (s.lastHoriz > 0.3f) {
                turn = (float) Math.asin(Mth.clamp(s.headingZ * hx - s.headingX * hz, -1f, 1f));   // + = belok kiri
            }
            s.headingX = hx;
            s.headingZ = hz;
        }
        float bank = running ? -(float) Math.toDegrees(Math.atan(horiz * turn / RUN_BANK_G)) : 0f;
        s.runSide += (Mth.clamp(bank, -RUN_BANK_MAX, RUN_BANK_MAX) - s.runSide) * 0.3f;
        // mengerem dari lari kencang: kaki depan menancap, badan condong ke belakang dan merendah
        float decel = s.lastHoriz - horiz;
        boolean skidding = mercury && !flying && player.onGround() && s.lastHoriz > 0.6f && decel > 0.06f;
        s.skid = approach(s.skid, skidding ? Mth.clamp((decel - 0.04f) / 0.14f, 0.4f, 1f) : 0f, skidding ? 0.35f : 0.12f);
        s.lastHoriz = horiz;
        if (mercury && speed > 0.6f) {
            s.ghostUntil = Math.max(s.ghostUntil, player.tickCount);
        }

        if (!transformed) {
            s.auraEnd = -1;
        }
        if (s.clip != null && player.tickCount - s.startAge > s.clip.length + 1) {
            s.clip = null;
            s.anim = null;
        }
        if (s.prevClip != null && player.tickCount - s.prevCut > XFADE + 1) {
            s.prevClip = null;
        }
        // bayangan baru dibuat saat digambar (renderGhosts), di sini cuma yang sudah habis umurnya dibuang
        while (!s.ghosts.isEmpty() && (player.tickCount - s.ghosts.peekFirst().born() > s.ghosts.peekFirst().life() + 1f
                || player.tickCount + 1f < s.ghosts.peekFirst().born())) {
            s.ghosts.removeFirst();
        }
        if (flying && s.soar > 0.3f) {
            ShazamFx.flightTrail(player, speed, s.boost);
        }
    }

    /** Seberapa jauh lagi turun sampai menyentuh tanah, mengikuti arah lintasan (blok); 100 kalau masih jauh. */
    private static double groundAhead(AbstractClientPlayer player, double dx, double dy, double dz) {
        double reach = FlightPose.groundCheckDistance(dy);
        Vec3 path = new Vec3(dx, dy, dz).scale(reach / -dy);
        if (path.length() > 80.0) {
            path = path.normalize().scale(80.0);
        }
        Vec3 from = player.position();
        BlockHitResult hit = player.level().clip(new ClipContext(from, from.add(path), ClipContext.Block.COLLIDER,
                ClipContext.Fluid.ANY, player));
        return hit.getType() == HitResult.Type.MISS ? 100.0 : from.y - hit.getLocation().y;
    }

    private static float approach(float value, float target, float step) {
        return value < target ? Math.min(target, value + step) : Math.max(target, value - step);
    }

    // ------------------------------------------------- pose bagian tubuh (mixin)

    /** Dipanggil di akhir HumanoidModel.setupAnim untuk setiap pemain. */
    public static void apply(HumanoidModel<?> model, AbstractClientPlayer player, float ageInTicks) {
        if (ageInTicks <= 0.0001f) {
            return; // tangan orang pertama: biarkan bawaan
        }
        State s = STATES.get(player.getId());
        if (s == null) {
            capture(model, player);
            return;
        }
        float pt = Mth.clamp(ageInTicks - player.tickCount, 0f, 1f);
        float headX = model.head.xRot;
        float headY = model.head.yRot;
        // perpindahan antar-pose (melayang, meluncur, ngebut, mengerem, berdiri gagah) dibuat melengkung:
        // mulai dan berhenti pelan, bukan berubah dengan kecepatan tetap lalu berhenti mendadak
        float flight = Clip.ease(Mth.lerp(pt, s.flightO, s.flight));
        float stance = Clip.ease(Mth.lerp(pt, s.stanceO, s.stance));

        boolean adam = ShazamClientState.isAdam(player.getId());
        if (flight > 0.001f) {
            applyFlight(model, adam, flight, Clip.ease(Mth.lerp(pt, s.soarO, s.soar)), Clip.ease(Mth.lerp(pt, s.boostO, s.boost)),
                    Clip.ease(Mth.lerp(pt, s.brakeO, s.brake)), Mth.lerp(pt, s.tiltO, s.tilt), ageInTicks, headX,
                    Mth.lerp(pt, s.legO, s.leg), Mth.lerp(pt, s.armO, s.arm), Mth.lerp(pt, s.flutterO, s.flutter), s.flutterAmp);
            // badan diputar menghadap lintasan, kepala tetap memandang ke arah kamera
            model.head.yRot -= Mth.lerp(pt, s.yawOffO, s.yawOff) * Mth.DEG_TO_RAD;
        }
        if (stance > 0.001f) {
            applyStance(model, adam, stance, ageInTicks);
        }
        float run = Clip.ease(Mth.lerp(pt, s.runO, s.run));
        float skid = Clip.ease(Mth.lerp(pt, s.skidO, s.skid));
        if (run > 0.001f || skid > 0.001f) {
            applyRun(model, run, skid, Mth.lerp(pt, s.phaseO, s.phase), Mth.lerp(pt, s.leanO, s.lean), headX);
        }
        if (s.prevClip != null) {
            float fade = 1f - Clip.ease((ageInTicks - s.prevCut) / XFADE);
            if (fade > 0f) {
                s.prevClip.apply(model, ageInTicks - s.prevStart, headX, headY, fade);
            }
        }
        if (s.clip != null) {
            s.clip.apply(model, ageInTicks - s.startAge, headX, headY);
        }
        model.hat.copyFrom(model.head);
        capture(model, player);
    }

    /** Simpan pose akhir semua bagian tubuh buat hood, mantel, jubah, dan efek. */
    private static void capture(HumanoidModel<?> model, AbstractClientPlayer player) {
        float[] p = PARTS.computeIfAbsent(player.getId(), id -> new float[PART_VALUES]);
        ModelPart[] parts = {model.head, model.body, model.rightArm, model.leftArm, model.rightLeg, model.leftLeg};
        for (int k = 0; k < parts.length; k++) {
            ModelPart part = parts[k];
            int o = k * 6;
            p[o] = part.x;
            p[o + 1] = part.y;
            p[o + 2] = part.z;
            p[o + 3] = part.xRot;
            p[o + 4] = part.yRot;
            p[o + 5] = part.zRot;
        }
    }

    /** Salinan pose semua bagian tubuh dari render terakhir (lihat PARTS), atau null kalau belum pernah digambar. */
    public static float[] parts(AbstractClientPlayer player) {
        float[] p = PARTS.get(player.getId());
        return p == null ? null : p.clone();
    }

    /**
     * Matriks badan pemain tanpa posisi dunia: sama dengan yang dipakai renderer sebelum model dibalik
     * (ukuran badan, arah hadap, lalu miring/menikung/turun dari animasi). +Y ke atas, depan = -Z.
     */
    public static Matrix4f bodyMatrix(AbstractClientPlayer player, float partialTick, float bodyYaw) {
        PoseStack poseStack = new PoseStack();
        float scale = player.getScale();
        poseStack.scale(scale, scale, scale);
        poseStack.mulPose(Axis.YP.rotationDegrees(180f - bodyYaw));
        applyBodyTransform(player, poseStack, partialTick, scale);
        return new Matrix4f(poseStack.last().pose());
    }

    /** Dipanggil dari RenderPlayerEvent.Pre: titik asal render pemain (sebelum badan diputar). */
    public static void beginBodyCapture(PoseStack poseStack) {
        RENDER_ORIGIN.set(poseStack.last().pose());
    }

    /** Dipanggil di akhir PlayerRenderer.setupRotations: simpan matriks badan yang benar-benar dipakai model. */
    public static void endBodyCapture(AbstractClientPlayer player, PoseStack poseStack) {
        Matrix4f body = new Matrix4f(RENDER_ORIGIN).invert().mul(poseStack.last().pose());
        BODIES.put(player.getId(), body);
    }

    /** Matriks badan dari render terakhir pemain ini (lihat BODIES), atau null kalau belum pernah digambar. */
    public static Matrix4f renderedBody(AbstractClientPlayer player) {
        Matrix4f m = BODIES.get(player.getId());
        return m == null ? null : new Matrix4f(m);
    }

    /** Pose kepala terakhir di ruang badan: {x, y, z poros leher, putar X, putar Y, condong badan}, atau null. */
    public static float[] headPose(AbstractClientPlayer player) {
        float[] p = PARTS.get(player.getId());
        if (p == null) {
            return null;
        }
        return new float[] {
                -(p[0] / 16f) * 0.9375f,
                0.9375f * (1.501f - p[1] / 16f),
                0.9375f * (p[2] / 16f),
                -p[3],
                -p[4],
                -p[9]};
    }

    /**
     * Pose kedua lengan terakhir di ruang badan: {kanan: x, y, z poros bahu, putar Z, Y, X; kiri: sama}, atau null.
     * Matriks lengan = badan · translate(x, y, z) · rotateZ · rotateY · rotateX (lihat armMatrix).
     */
    public static float[] armPose(AbstractClientPlayer player) {
        float[] p = PARTS.get(player.getId());
        if (p == null) {
            return null;
        }
        float[] out = new float[12];
        for (int k = 0; k < 2; k++) {
            int o = 12 + k * 6;
            out[k * 6] = -(p[o] / 16f) * 0.9375f;
            out[k * 6 + 1] = 0.9375f * (1.501f - p[o + 1] / 16f);
            out[k * 6 + 2] = 0.9375f * (p[o + 2] / 16f);
            out[k * 6 + 3] = p[o + 5];
            out[k * 6 + 4] = -p[o + 4];
            out[k * 6 + 5] = -p[o + 3];
        }
        return out;
    }

    /** Matriks lengan (kanan atau kiri) di ruang badan. pose = hasil armPose, atau null untuk lengan lurus ke bawah. */
    public static Matrix4f armMatrix(Matrix4f body, float[] pose, boolean right) {
        Matrix4f m = new Matrix4f(body);
        if (pose == null) {
            return m.translate(right ? 0.293f : -0.293f, 1.290f, 0f);
        }
        int o = right ? 0 : 6;
        return m.translate(pose[o], pose[o + 1], pose[o + 2]).rotateZ(pose[o + 3]).rotateY(pose[o + 4]).rotateX(pose[o + 5]);
    }

    /** Posisi kepalan tangan di dunia (buat efek yang keluar dari tangan). */
    public static Vec3 handPos(AbstractClientPlayer player, boolean right, float partialTick) {
        Minecraft mc = Minecraft.getInstance();
        if (player == mc.player && mc.options.getCameraType().isFirstPerson()) {
            // orang pertama: badan nggak digambar, jadi efek keluar dari tangan yang terlihat di layar
            Vec3 eye = player.getEyePosition(partialTick);
            Vec3 look = player.getViewVector(partialTick);
            Vec3 side = look.cross(new Vec3(0, 1, 0));
            side = side.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : side.normalize();
            Vec3 up = side.cross(look);
            return eye.add(look.scale(0.55)).add(side.scale(right ? 0.32 : -0.32)).add(up.scale(-0.28));
        }
        float yaw = Mth.rotLerp(partialTick, player.yBodyRotO, player.yBodyRot);
        Matrix4f arm = armMatrix(bodyMatrix(player, partialTick, yaw), armPose(player), right);
        org.joml.Vector3f p = arm.transformPosition(new org.joml.Vector3f(right ? 0.0586f : -0.0586f, -0.56f, 0f));
        double crouch = player.isCrouching() ? -0.125 * player.getScale() : 0.0;
        return new Vec3(Mth.lerp(partialTick, player.xo, player.getX()) + p.x,
                Mth.lerp(partialTick, player.yo, player.getY()) + crouch + p.y,
                Mth.lerp(partialTick, player.zo, player.getZ()) + p.z);
    }

    private static void applyFlight(HumanoidModel<?> m, boolean adam, float flight, float soar, float boost, float brake,
                                    float tilt, float age, float headX, float leg, float arm, float flutter,
                                    float flutterAmp) {
        if (adam) {
            applyAdamFlight(m, flight, soar, boost, brake, tilt, age, headX, leg, flutter, flutterAmp);
            return;
        }
        float bob = Mth.sin(age * 0.08f);
        float hover = flight * (1f - soar);
        if (hover > 0.001f) {
            // Melayang: lengan sedikit terbuka, satu kaki agak ke belakang
            blend(m.rightArm, hover, -0.15f + bob * 0.06f, 0f, 0.3f);
            blend(m.leftArm, hover, -0.15f - bob * 0.06f, 0f, -0.3f);
            blend(m.rightLeg, hover, 0.05f + bob * 0.06f, 0f, 0.07f);
            blend(m.leftLeg, hover, 0.35f - bob * 0.04f, 0f, -0.07f);
        }
        float cruise = flight * soar * (1f - boost);
        if (cruise > 0.001f) {
            // Meluncur: kepalan kanan di depan, tangan kiri di sisi badan
            blend(m.rightArm, cruise, -3.0f, 0f, 0.05f);
            blend(m.leftArm, cruise, 0.3f + bob * 0.03f, 0f, -0.1f);
            blend(m.rightLeg, cruise, 0.1f, 0f, 0.03f);
            blend(m.leftLeg, cruise, 0.22f, 0f, -0.03f);
        }
        float fast = flight * soar * boost;
        if (fast > 0.001f) {
            // Super cepat: dua kepalan di depan, badan lurus seperti peluru
            float shiver = Mth.sin(age * 2.1f) * 0.015f;
            blend(m.rightArm, fast, -3.05f + shiver, 0f, 0.08f);
            blend(m.leftArm, fast, -3.05f - shiver, 0f, -0.08f);
            blend(m.rightLeg, fast, 0.04f, 0f, 0.01f);
            blend(m.leftLeg, fast, 0.06f, 0f, -0.01f);
        }
        float braking = flight * brake;
        if (braking > 0.001f) {
            // Mengerem: lengan ke depan menahan, kaki maju
            blend(m.rightArm, braking, -1.5f, -0.2f, 0.35f);
            blend(m.leftArm, braking, -1.5f, 0.2f, -0.35f);
            blend(m.rightLeg, braking, -0.6f, 0f, 0.05f);
            blend(m.leftLeg, braking, -0.3f, 0f, -0.05f);
        }
        // Lembam & getar angin: kaki tertinggal saat dipercepat, terayun ke depan saat mengerem;
        // makin kencang, tangan-kaki makin bergetar diterpa angin
        float f1 = Mth.sin(flutter) * flutterAmp;
        float f2 = Mth.sin(flutter * 1.13f + 1.7f) * flutterAmp;
        m.rightLeg.xRot += (leg + f1) * flight;
        m.leftLeg.xRot += (leg * 0.85f + f2) * flight;
        m.rightArm.xRot += (arm * 0.6f + f2 * 0.6f) * flight;
        m.leftArm.xRot += (arm + f1 * 0.6f) * flight;
        // Kepala tetap memandang ke depan walau badan rebah
        if (Math.abs(tilt) > 0.5f) {
            float lookAhead = Mth.clamp(headX - tilt * Mth.DEG_TO_RAD, -1.7f, 0.7f);
            m.head.xRot = Mth.lerp(flight, m.head.xRot, lookAhead);
        }
    }

    /**
     * Lari super cepat seperti sprinter: lutut didorong tinggi ke depan dan kaki belakang menolak jauh, lengan
     * memompa kuat berlawanan dengan kaki (sedikit menyilang di depan badan), bahu ikut berputar mengikuti ayunan
     * lengan, kaki dimajukan mengimbangi badan yang condong (supaya tetap menapak di bawah badan), dan kepala tetap
     * memandang ke depan. skid = mengerem: kaki depan menancap, kaki belakang menahan, tangan terentang mengimbangi.
     */
    private static void applyRun(HumanoidModel<?> m, float w, float skid, float phase, float leanDeg, float headX) {
        float run = w * (1f - skid);
        float tilt = (leanDeg * (1f - skid) + SKID_TILT * skid) * Mth.DEG_TO_RAD;
        if (run > 0.001f) {
            float lean = leanDeg * Mth.DEG_TO_RAD;
            float sw = Mth.sin(phase);
            float legBase = -lean * 0.9f;
            // ayunan ke depan (lutut naik) lebih tinggi daripada tolakan ke belakang
            float right = sw > 0f ? 1.45f * sw : 1.0f * sw;
            float left = sw < 0f ? -1.45f * sw : -1.0f * sw;
            blend(m.rightLeg, run, legBase - right, 0f, 0.04f);
            blend(m.leftLeg, run, legBase - left, 0f, -0.04f);
            blend(m.rightArm, run, 1.35f * sw - 0.3f, 0.2f * Math.min(sw, 0f), 0.1f);
            blend(m.leftArm, run, -1.35f * sw - 0.3f, 0.2f * Math.max(sw, 0f), -0.1f);
            // bahu berputar mengikuti lengan (pinggul nggak); bahu membawa lengannya, seperti ayunan pukulan vanilla
            float twist = run * 0.16f * sw;
            m.body.yRot += twist;
            m.rightArm.z = Mth.sin(m.body.yRot) * 5f;
            m.rightArm.x = -Mth.cos(m.body.yRot) * 5f;
            m.leftArm.z = -Mth.sin(m.body.yRot) * 5f;
            m.leftArm.x = Mth.cos(m.body.yRot) * 5f;
            m.rightArm.yRot += twist;
            m.leftArm.yRot += twist;
        }
        if (skid > 0.001f) {
            // badan sudah condong ke belakang 16 derajat: kaki depan ±47 derajat ke depan, kaki belakang hampir tegak
            blend(m.rightLeg, skid, -0.55f, 0.1f, 0.12f);                                 // kaki depan menancap
            blend(m.leftLeg, skid, 0.4f, -0.05f, -0.1f);                                  // kaki belakang menahan
            blend(m.rightArm, skid, -1.1f, 0.25f, 0.85f);                                 // tangan terentang
            blend(m.leftArm, skid, -0.4f, -0.2f, -1.05f);
        }
        float k = Math.max(w, skid);
        m.head.xRot = Mth.lerp(k, m.head.xRot, Mth.clamp(headX - tilt, -1.4f, 0.8f));
    }

    /**
     * Terbang Black Adam (seperti di film): bukan kepalan di depan ala Superman, tapi melayang tegak dengan kedua lengan
     * lurus di sisi badan dan kepalan mengepal, kaki rapat lurus, mengancam. Saat meluncur, lengan tertarik ke belakang
     * sepanjang badan seperti peluru; saat mengerem, badan menegak dan kaki menapak udara.
     */
    private static void applyAdamFlight(HumanoidModel<?> m, float flight, float soar, float boost, float brake, float tilt,
                                        float age, float headX, float leg, float flutter, float flutterAmp) {
        float breath = Mth.sin(age * 0.06f);
        float hover = flight * (1f - soar);
        if (hover > 0.001f) {
            // Melayang tegak: lengan lurus sedikit menjauh dari badan, kepalan mengepal; kaki rapat, ujung kaki turun
            blend(m.rightArm, hover, 0.08f + breath * 0.02f, 0f, 0.2f);
            blend(m.leftArm, hover, 0.08f - breath * 0.02f, 0f, -0.2f);
            blend(m.rightLeg, hover, 0.06f, 0f, 0.03f);
            blend(m.leftLeg, hover, 0.1f, 0f, -0.03f);
        }
        float cruise = flight * soar;
        if (cruise > 0.001f) {
            // Meluncur: lengan tertarik ke belakang sepanjang badan, kaki lurus rapat (makin kencang makin rapat)
            float tight = 0.5f + 0.5f * boost;
            blend(m.rightArm, cruise, 0.42f + 0.18f * tight, 0f, 0.16f - 0.08f * tight);
            blend(m.leftArm, cruise, 0.42f + 0.18f * tight, 0f, -0.16f + 0.08f * tight);
            blend(m.rightLeg, cruise, 0.08f, 0f, 0.02f);
            blend(m.leftLeg, cruise, 0.12f, 0f, -0.02f);
        }
        float braking = flight * brake;
        if (braking > 0.001f) {
            // Mengerem: dada membusung, lengan sedikit terbuka ke bawah, satu kaki maju
            blend(m.rightArm, braking, 0.2f, 0f, 0.5f);
            blend(m.leftArm, braking, 0.2f, 0f, -0.5f);
            blend(m.rightLeg, braking, -0.45f, 0f, 0.06f);
            blend(m.leftLeg, braking, 0.15f, 0f, -0.06f);
        }
        float f1 = Mth.sin(flutter) * flutterAmp * 0.6f;
        float f2 = Mth.sin(flutter * 1.13f + 1.7f) * flutterAmp * 0.6f;
        m.rightLeg.xRot += (leg * 0.6f + f1) * flight;
        m.leftLeg.xRot += (leg * 0.5f + f2) * flight;
        m.rightArm.xRot += f2 * 0.3f * flight;
        m.leftArm.xRot += f1 * 0.3f * flight;
        if (Math.abs(tilt) > 0.5f) {
            float lookAhead = Mth.clamp(headX - tilt * Mth.DEG_TO_RAD, -1.7f, 0.7f);
            m.head.xRot = Mth.lerp(flight, m.head.xRot, lookAhead);
        }
    }

    private static void applyStance(HumanoidModel<?> m, boolean adam, float w, float age) {
        float breath = Mth.sin(age * 0.06f) * 0.03f;
        if (adam) {
            // Black Adam: kedua lengan bersilang di dada seperti firaun, kaki terbuka lebar, dagu sedikit terangkat
            blend(m.rightArm, w, -1.02f + breath, -0.62f, 0.08f);
            blend(m.leftArm, w, -1.12f - breath, 0.6f, -0.08f);
            blend(m.rightLeg, w, 0f, 0f, 0.17f);
            blend(m.leftLeg, w, 0f, 0f, -0.17f);
            m.head.xRot -= 0.12f * w;
            return;
        }
        // Berdiri gagah: kepalan di pinggang, kaki terbuka, napas pelan
        blend(m.rightArm, w, 0.2f, 0.1f, 0.45f + breath);
        blend(m.leftArm, w, 0.2f, -0.1f, -0.45f - breath);
        blend(m.rightLeg, w, 0f, 0f, 0.12f);
        blend(m.leftLeg, w, 0f, 0f, -0.12f);
    }

    private static void blend(ModelPart part, float w, float x, float y, float z) {
        part.xRot = Mth.lerp(w, part.xRot, x);
        part.yRot = Mth.lerp(w, part.yRot, y);
        part.zRot = Mth.lerp(w, part.zRot, z);
    }

    // --------------------------------------------- posisi seluruh badan (mixin)

    /** Dipanggil di akhir PlayerRenderer.setupRotations. scale = ukuran entity saat ini. */
    public static void applyBodyTransform(AbstractClientPlayer player, PoseStack poseStack, float partialTick, float scale) {
        State s = STATES.get(player.getId());
        if (s == null) {
            return;
        }
        float age = player.tickCount + partialTick;
        // Saat kostum berganti, badan tumbuh (atau menyusut) dengan mulus
        float change = age - s.suitAge;
        if (change >= 0f && change < SUIT_TICKS && scale > 0f) {
            float eased = Ease.OUT_CUBIC.apply(change / SUIT_TICKS);
            float from = s.suitIn ? 1f / scale : (1f + (float) ShazamPowers.GROWTH) / scale;
            float k = Mth.lerp(eased, from, 1f);
            poseStack.scale(k, k, k);
        }
        float flight = Clip.ease(Mth.lerp(partialTick, s.flightO, s.flight));
        float soar = Clip.ease(Mth.lerp(partialTick, s.soarO, s.soar));
        float tilt = Mth.lerp(partialTick, s.tiltO, s.tilt);
        float roll = Mth.lerp(partialTick, s.bankO, s.bank) + barrelRoll(s, age);
        float side = Mth.lerp(partialTick, s.sideO, s.side);
        float yaw = Mth.lerp(partialTick, s.yawOffO, s.yawOff);
        float drop = -flight * (1f - soar) * Mth.sin(age * 0.08f) * 0.04f; // naik-turun pelan saat melayang
        float run = Clip.ease(Mth.lerp(partialTick, s.runO, s.run));
        float skid = Clip.ease(Mth.lerp(partialTick, s.skidO, s.skid));
        if (run > 0.001f || skid > 0.001f) {
            // lari super cepat: condong ke depan dan ke dalam tikungan, naik-turun tiap langkah (melayang di antara
            // langkah, turun saat menapak), bergoyang sedikit ke kaki tumpuan; mengerem: condong ke belakang, merendah
            float phase = Mth.lerp(partialTick, s.phaseO, s.phase);
            float stride = run * (1f - skid);
            tilt += stride * Mth.lerp(partialTick, s.leanO, s.lean) + skid * SKID_TILT;
            drop += stride * (Math.abs(Mth.cos(phase)) * 0.1f - 0.05f) + skid * SKID_DROP;
            side += run * Mth.lerp(partialTick, s.runSideO, s.runSide) + stride * 2.2f * Mth.sin(phase);
        }
        float[] b = BODY_TMP;
        b[0] = tilt; b[1] = drop; b[2] = roll; b[3] = side; b[4] = yaw;
        if (s.prevClip != null) {   // klip lama yang sedang memudar
            float fade = 1f - Clip.ease((age - s.prevCut) / XFADE);
            if (fade > 0f) {
                blendBody(s.prevClip, age - s.prevStart, age, fade, b);
            }
        }
        if (s.clip != null) {
            blendBody(s.clip, age - s.startAge, age, 1f, b);
        }
        System.arraycopy(b, 0, s.lastBody, 0, 5);
        transformBody(poseStack, b[0], b[1], b[2], b[3], b[4]);
    }

    private static final float[] BODY_TMP = new float[5];

    /** Campur pose seluruh badan dari klip (b = {tilt, drop, roll, side, yaw}). */
    private static void blendBody(Clip clip, float t, float age, float scale, float[] b) {
        float w = clip.weight(t) * scale;
        if (w <= 0f) {
            return;
        }
        float shake = clip.shake(t) * w;
        b[0] = Mth.lerp(w, b[0], clip.tilt(t)) + shake * Clip.noise(age, 0.3f);
        b[1] = Mth.lerp(w, b[1], clip.drop(t));
        b[2] *= 1f - w;
        b[3] = Mth.lerp(w, b[3], clip.lean(t)) + shake * Clip.noise(age, 2.1f);
        b[4] = Mth.lerp(w, b[4], clip.spin(t));
    }

    private static float barrelRoll(State s, float age) {
        float t = (age - s.rollStart) / ROLL_TICKS;
        if (t < 0f || t > 1f) {
            return 0f;
        }
        return s.rollDir * 360f * Ease.IN_OUT_SINE.apply(t);
    }

    private static void transformBody(PoseStack poseStack, float tilt, float drop, float roll, float side, float yaw) {
        if (Math.abs(tilt) < 0.01f && Math.abs(drop) < 0.0005f && Math.abs(roll) < 0.01f
                && Math.abs(side) < 0.01f && Math.abs(yaw) < 0.01f) {
            return;
        }
        poseStack.translate(0f, -drop, 0f);
        poseStack.translate(0f, 0.9f, 0f);
        if (yaw != 0f) {
            poseStack.mulPose(Axis.YP.rotationDegrees(-yaw));   // menghadap arah lintasan
        }
        if (side != 0f) {
            poseStack.mulPose(Axis.ZP.rotationDegrees(-side));  // miring ke samping saat melayang
        }
        poseStack.mulPose(Axis.XP.rotationDegrees(-tilt));
        if (roll != 0f) {
            poseStack.mulPose(Axis.YP.rotationDegrees(roll)); // putar di sumbu panjang badan
        }
        poseStack.translate(0f, -0.9f, 0f);
    }

    // --------------------------------------------------- kamera pemain sendiri

    /** Kemiringan kamera: ikut menikung, dan sedikit berguling saat barrel roll. */
    public static float cameraRoll(AbstractClientPlayer player, float partialTick) {
        State s = STATES.get(player.getId());
        if (s == null) {
            return 0f;
        }
        float roll = Mth.lerp(partialTick, s.bankO, s.bank) * 0.5f;
        float t = (player.tickCount + partialTick - s.rollStart) / ROLL_TICKS;
        if (t >= 0f && t <= 1f) {
            roll += s.rollDir * 25f * Mth.sin(t * Mth.PI);
        }
        return roll;
    }

    /** 0-1: seberapa kencang pemain sedang terbang (buat melebarkan pandangan). */
    public static float flightSpeedFactor(AbstractClientPlayer player, float partialTick) {
        State s = STATES.get(player.getId());
        if (s == null) {
            return 0f;
        }
        return Mth.lerp(partialTick, s.flightO, s.flight) * Mth.clamp(s.speed / 5f, 0f, 1f);
    }

    // --------------------------------------------------- pergantian kostum

    /** Tick sejak kostum mulai terbentuk/luruh, atau -1 kalau sedang tidak berganti kostum. */
    public static float suitTicks(AbstractClientPlayer player, float partialTick) {
        State s = STATES.get(player.getId());
        if (s == null) {
            return -1f;
        }
        float t = player.tickCount + partialTick - s.suitAge;
        return t >= 0f && t < SUIT_TICKS ? t : -1f;
    }

    /** true = kostum sedang terbentuk, false = sedang luruh. */
    public static boolean suitIn(AbstractClientPlayer player) {
        State s = STATES.get(player.getId());
        return s != null && s.suitIn;
    }

    public static boolean isSuitRevealing(AbstractClientPlayer player) {
        return suitIn(player) && suitTicks(player, 0f) >= 0f;
    }

    public static boolean isSuitChanging(AbstractClientPlayer player) {
        return suitTicks(player, 0f) >= 0f;
    }

    // --------------------------------------------------- aura & bayangan

    /** 0-1: seberapa terang aura emas Kulit Achilles saat ini. */
    public static float auraStrength(AbstractClientPlayer player, float partialTick) {
        State s = STATES.get(player.getId());
        if (s == null || s.auraEnd < 0) {
            return 0f;
        }
        float now = player.tickCount + partialTick;
        if (now < s.auraStart || now > s.auraEnd) {
            return 0f;
        }
        return Math.min(1f, (now - s.auraStart) / 4f) * Math.min(1f, (s.auraEnd - now) / 10f);
    }

    /**
     * Bayangan berjejak di sepanjang jalur lari super cepat / terjangan Kilat Mercury (dipanggil dari
     * RenderPlayerEvent.Post, sesudah jubah). Tiap bayangan dibekukan persis seperti frame saat dibuat: pose badan,
     * jubah, mantel, dan hood yang sedang berkibar. Digambar empat lapis:
     * 1. badan: skin diwarnai cahaya, tembus pandang, terang sendiri;
     * 2. kain: jubah, mantel, hood (dua sisi);
     * 3. list emas di tepi kain;
     * 4. pendar listrik (aditif) yang paling terang di tepi siluet, plus lambang dada yang menyala.
     * Bayangan terbaru paling pekat dan putih kebiruan; makin tua makin tipis dan makin biru listrik.
     * Nggak menulis kedalaman, jadi petir dan efek lain di belakangnya tetap kelihatan.
     */
    public static void renderGhosts(AbstractClientPlayer player, PlayerRenderer renderer, PoseStack poseStack,
                                    MultiBufferSource buffers, float partialTick) {
        State s = STATES.get(player.getId());
        if (s == null || player.isInvisible() || !ShazamCape.isWorldRender(player, partialTick)) {
            return;   // pratinjau inventory nggak membuat/menggambar bayangan
        }
        double px = Mth.lerp(partialTick, player.xo, player.getX());
        double py = Mth.lerp(partialTick, player.yo, player.getY());
        double pz = Mth.lerp(partialTick, player.zo, player.getZ());
        float now = player.tickCount + partialTick;
        captureGhost(player, s, now, partialTick, px, py, pz);
        if (s.ghosts.isEmpty()) {
            return;
        }
        // bayangan yang digambar frame ini: masih hidup dan nggak menumpuk di badan asli
        Ghost[] list = new Ghost[s.ghosts.size()];
        float[] ages = new float[list.length];
        int n = 0;
        for (Ghost g : s.ghosts) {
            float age = (now - g.born()) / g.life();
            if (age < 0f || age >= 1f) {
                continue;
            }
            double dx = g.x() - px, dy = g.y() - py, dz = g.z() - pz;
            if (dx * dx + dy * dy + dz * dz < 0.3) {
                continue;
            }
            list[n] = g;
            ages[n] = age;
            n++;
        }
        if (n == 0) {
            return;
        }
        // kamera relatif titik asal render pemain (buat memudarkan bayangan yang terlalu dekat kamera)
        Vector3f eye = new Matrix4f(poseStack.last().pose()).invert().transformPosition(new Vector3f());
        int[] tint = new int[n], gold = new int[n], rim = new int[n], alpha = new int[n];
        boolean adam = ShazamClientState.isAdam(player.getId());
        FormLook look = FormLook.of(player.getId());
        float[] glow = new float[n];
        for (int k = 0; k < n; k++) {
            Ghost g = list[k];
            float age = ages[k];
            float f = (float) Math.pow(1f - age, 1.6);
            float fresh = Math.max(0f, 1f - age / 0.2f);   // kilatan sesaat saat bayangan baru lahir
            double cx = g.x() - px - eye.x, cy = g.y() + 1.0 - py - eye.y, cz = g.z() - pz - eye.z;
            double dist = Math.sqrt(cx * cx + cy * cy + cz * cz);
            double t = Mth.clamp((dist - GHOST_NEAR) / (GHOST_CLEAR - GHOST_NEAR), 0.0, 1.0);
            f *= (float) (t * t * (3.0 - 2.0 * t));
            // bayangan yang persis di antara kamera dan pelari (kamera F5 di belakang) dibuat tipis supaya pelarinya
            // tetap kelihatan; dari samping, jejaknya tetap utuh
            double bx = -eye.x, by = 1.0 - eye.y, bz = -eye.z;
            double bl = Math.sqrt(bx * bx + by * by + bz * bz);
            if (dist < bl && dist > 1.0E-4 && bl > 1.0E-4) {
                double cos = (cx * bx + cy * by + cz * bz) / (dist * bl);
                double angle = Math.toDegrees(Math.acos(Mth.clamp(cos, -1.0, 1.0)));
                double u = Mth.clamp((angle - 5.0) / 12.0, 0.0, 1.0);
                f *= (float) (0.25 + 0.75 * u * u * (3.0 - 2.0 * u));
            }
            if (g.mercury()) {
                tint[k] = Draw.mix(MERCURY_GHOST, MERCURY_GHOST_OLD, Math.pow(age, 0.7));
                rim[k] = Draw.mix(MERCURY_RIM_FRESH, MERCURY_RIM, Math.min(1.0, age * 2.5));
            } else if (adam) {
                tint[k] = HERU_GHOST;
                rim[k] = HERU_RIM;
            } else {
                tint[k] = BLITZ_GHOST;
                rim[k] = BLITZ_RIM;
            }
            gold[k] = Draw.mix(GHOST_GOLD, tint[k], 0.25);
            alpha[k] = Mth.clamp((int) (255f * GHOST_ALPHA * f * (1f + 0.25f * fresh)), 0, 255);
            glow[k] = GHOST_RIM * f * (1f + 0.5f * fresh);
        }

        PlayerModel<AbstractClientPlayer> model = renderer.getModel();
        ResourceLocation skin = renderer.getTextureLocation(player);
        float[] current = new float[PART_VALUES];
        savePose(model, current);
        boolean[] layers = saveLayers(model);
        try {
            // 1) badan
            VertexConsumer vc = buffers.getBuffer(RenderType.entityTranslucentEmissive(skin));
            for (int k = 0; k < n; k++) {
                Ghost g = list[k];
                poseStack.pushPose();
                poseStack.translate(g.x() - px, g.y() - py, g.z() - pz);
                ghostBody(poseStack, g);
                loadPose(model, g.pose() != null ? g.pose() : current);
                model.renderToBuffer(poseStack, vc, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, (alpha[k] << 24) | tint[k]);
                poseStack.popPose();
            }
            // 2) jubah, mantel, hood
            vc = buffers.getBuffer(RenderType.entityTranslucentEmissive(ShazamCape.TEXTURE));
            for (int k = 0; k < n; k++) {
                Ghost g = list[k];
                if (g.cloth() != null) {
                    poseStack.pushPose();
                    poseStack.translate(g.x() - px, g.y() - py, g.z() - pz);
                    ShazamCape.ghostFill(vc, poseStack.last(), g.cloth(), tint[k], alpha[k]);
                    poseStack.popPose();
                }
            }
            // 3) list emas
            vc = buffers.getBuffer(RenderType.entityTranslucentEmissive(CapeDecor.WHITE));
            for (int k = 0; k < n; k++) {
                Ghost g = list[k];
                if (g.cloth() != null) {
                    poseStack.pushPose();
                    poseStack.translate(g.x() - px, g.y() - py, g.z() - pz);
                    ShazamCape.ghostTrim(vc, poseStack.last(), g.cloth(), gold[k], Math.min(255, alpha[k] * 5 / 4));
                    poseStack.popPose();
                }
            }
            // 4) pendar listrik di tepi siluet + lambang dada (lapisan luar skin nggak ikut: kotaknya penuh)
            setLayers(model, false);
            VertexConsumer add = buffers.getBuffer(Draw.additiveType());
            RimGlow rimGlow = new RimGlow(add);
            Vector3f cam = new Vector3f();
            for (int k = 0; k < n; k++) {
                Ghost g = list[k];
                if (glow[k] <= 0.02f) {
                    continue;
                }
                poseStack.pushPose();
                poseStack.translate(g.x() - px, g.y() - py, g.z() - pz);
                if (g.cloth() != null) {
                    new Matrix4f(poseStack.last().pose()).invert().transformPosition(cam.set(0f, 0f, 0f));
                    ShazamCape.ghostGlow(add, poseStack.last(), g.cloth(), cam.x, cam.y, cam.z, rim[k], glow[k] * GHOST_CLOTH_GLOW);
                }
                ghostBody(poseStack, g);
                loadPose(model, g.pose() != null ? g.pose() : current);
                rimGlow.set(rim[k], glow[k]);
                model.renderToBuffer(poseStack, rimGlow, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, -1);
                if (glow[k] > 0.3f) {
                    ShazamEmblemLayer.ghostGlow(poseStack, model, add, glow[k] * 0.8f, look);
                }
                poseStack.popPose();
            }
        } finally {
            restoreLayers(model, layers);
            loadPose(model, current);
        }
    }

    /** Buat bayangan baru di posisi & pose frame ini kalau sudah cukup jauh dari bayangan terakhir. */
    private static void captureGhost(AbstractClientPlayer player, State s, float now, float partialTick,
                                     double px, double py, double pz) {
        if (s.ghostUntil < player.tickCount) {
            return;
        }
        boolean mercury = ShazamClientState.isMercury(player.getId());
        double spacing = mercury ? MERCURY_GHOST_SPACING : GHOST_SPACING;
        double dx = px - s.ghostX, dy = py - s.ghostY, dz = pz - s.ghostZ;
        float since = now - s.ghostTime;
        if (since < 0f) {
            since = GHOST_MAX_GAP;   // jam pemain mundur (ganti dunia): mulai lagi
        }
        if (since < 0.25f || (dx * dx + dy * dy + dz * dz < spacing * spacing && since < GHOST_MAX_GAP)) {
            return;
        }
        float[] pose = PARTS.get(player.getId());
        float yaw = Mth.rotLerp(partialTick, player.yBodyRotO, player.yBodyRot);
        s.ghosts.addLast(new Ghost(px, py, pz, yaw, player.getScale(), s.lastBody.clone(), pose == null ? null : pose.clone(),
                ShazamCape.ghostCloth(player), now, mercury ? MERCURY_GHOST_LIFE : GHOST_LIFE, mercury));
        while (s.ghosts.size() > MAX_GHOSTS) {
            s.ghosts.removeFirst();
        }
        s.ghostX = px;
        s.ghostY = py;
        s.ghostZ = pz;
        s.ghostTime = now;
    }

    /** Pose seluruh badan bayangan, sama dengan yang dipakai renderer (arah, condong, lalu skala model pemain). */
    private static void ghostBody(PoseStack poseStack, Ghost g) {
        poseStack.scale(g.scale(), g.scale(), g.scale());
        poseStack.mulPose(Axis.YP.rotationDegrees(180f - g.yaw()));
        float[] b = g.body();
        transformBody(poseStack, b[0], b[1], b[2], b[3], b[4]);
        poseStack.scale(-1f, -1f, 1f);
        poseStack.scale(0.9375f, 0.9375f, 0.9375f);
        poseStack.translate(0f, -1.501f, 0f);
    }

    /**
     * Titik dada bayangan yang masih hidup, dari yang terbaru (buat listrik yang melompat antar-bayangan):
     * xyz[3k..3k+2] = posisi dunia, life[k] = sisa kekuatan 0-1. Mengembalikan jumlahnya (paling banyak max).
     */
    public static int ghostPoints(AbstractClientPlayer player, float partialTick, double[] xyz, float[] life, int max) {
        State s = STATES.get(player.getId());
        if (s == null || s.ghosts.isEmpty()) {
            return 0;
        }
        float now = player.tickCount + partialTick;
        int n = 0;
        Iterator<Ghost> it = s.ghosts.descendingIterator();
        while (it.hasNext() && n < max) {
            Ghost g = it.next();
            float age = (now - g.born()) / g.life();
            if (age < 0f || age >= 1f) {
                continue;
            }
            xyz[n * 3] = g.x();
            xyz[n * 3 + 1] = g.y() + 1.05 * g.scale();
            xyz[n * 3 + 2] = g.z();
            life[n] = 1f - age;
            n++;
        }
        return n;
    }

    /** Lapisan luar skin (topi, jaket, lengan baju, celana): nyala/mati. */
    private static boolean[] saveLayers(PlayerModel<?> model) {
        return new boolean[] {model.hat.visible, model.jacket.visible, model.rightSleeve.visible, model.leftSleeve.visible,
                model.rightPants.visible, model.leftPants.visible};
    }

    private static void setLayers(PlayerModel<?> model, boolean visible) {
        model.hat.visible = visible;
        model.jacket.visible = visible;
        model.rightSleeve.visible = visible;
        model.leftSleeve.visible = visible;
        model.rightPants.visible = visible;
        model.leftPants.visible = visible;
    }

    private static void restoreLayers(PlayerModel<?> model, boolean[] v) {
        model.hat.visible = v[0];
        model.jacket.visible = v[1];
        model.rightSleeve.visible = v[2];
        model.leftSleeve.visible = v[3];
        model.rightPants.visible = v[4];
        model.leftPants.visible = v[5];
    }

    /**
     * Pendar tepi buat model pemain (render aditif): titik dari ModelPart sudah di ruang kamera (kamera di titik 0),
     * jadi makin miring permukaannya terhadap arah pandang (tepi siluet), makin terang. Seperti energi yang
     * membentuk badan, bukan cuma bayangan rata.
     */
    private static final class RimGlow implements VertexConsumer {
        private final VertexConsumer out;
        private int rgb;
        private float strength;

        RimGlow(VertexConsumer out) {
            this.out = out;
        }

        void set(int rgb, float strength) {
            this.rgb = rgb;
            this.strength = strength;
        }

        @Override
        public void addVertex(float x, float y, float z, int color, float u, float v, int packedOverlay, int packedLight,
                              float normalX, float normalY, float normalZ) {
            float len = (float) Math.sqrt(x * x + y * y + z * z);
            float facing = len < 1.0E-4f ? 1f : Math.abs(normalX * x + normalY * y + normalZ * z) / len;
            float edge = 1f - facing;
            float k = strength * (0.16f + 0.84f * edge * edge * edge);
            out.addVertex(x, y, z, 0xFF000000 | scaleColor(rgb, k), 0.5f, 0.5f, packedOverlay, LightTexture.FULL_BRIGHT,
                    normalX, normalY, normalZ);
        }

        @Override
        public VertexConsumer addVertex(float x, float y, float z) {
            out.addVertex(x, y, z);
            return this;
        }

        @Override
        public VertexConsumer setColor(int red, int green, int blue, int alpha) {
            out.setColor(red, green, blue, alpha);
            return this;
        }

        @Override
        public VertexConsumer setUv(float u, float v) {
            out.setUv(u, v);
            return this;
        }

        @Override
        public VertexConsumer setUv1(int u, int v) {
            out.setUv1(u, v);
            return this;
        }

        @Override
        public VertexConsumer setUv2(int u, int v) {
            out.setUv2(u, v);
            return this;
        }

        @Override
        public VertexConsumer setNormal(float normalX, float normalY, float normalZ) {
            out.setNormal(normalX, normalY, normalZ);
            return this;
        }
    }

    /** Warna × k (lebih dari 1 = makin putih menyilaukan). */
    private static int scaleColor(int c, float k) {
        int r = Math.min(255, Math.max(0, (int) (((c >> 16) & 0xFF) * k)));
        int g = Math.min(255, Math.max(0, (int) (((c >> 8) & 0xFF) * k)));
        int b = Math.min(255, Math.max(0, (int) ((c & 0xFF) * k)));
        return (r << 16) | (g << 8) | b;
    }

    private static void savePose(PlayerModel<?> model, float[] out) {
        ModelPart[] parts = {model.head, model.body, model.rightArm, model.leftArm, model.rightLeg, model.leftLeg};
        for (int k = 0; k < parts.length; k++) {
            int o = k * 6;
            out[o] = parts[k].x;
            out[o + 1] = parts[k].y;
            out[o + 2] = parts[k].z;
            out[o + 3] = parts[k].xRot;
            out[o + 4] = parts[k].yRot;
            out[o + 5] = parts[k].zRot;
        }
    }

    /** Pasang pose (urutan sama dengan PARTS) ke model, termasuk lapisan luar skin. */
    private static void loadPose(PlayerModel<?> model, float[] p) {
        ModelPart[] parts = {model.head, model.body, model.rightArm, model.leftArm, model.rightLeg, model.leftLeg};
        for (int k = 0; k < parts.length; k++) {
            int o = k * 6;
            parts[k].x = p[o];
            parts[k].y = p[o + 1];
            parts[k].z = p[o + 2];
            parts[k].xRot = p[o + 3];
            parts[k].yRot = p[o + 4];
            parts[k].zRot = p[o + 5];
        }
        model.hat.copyFrom(model.head);
        model.jacket.copyFrom(model.body);
        model.rightSleeve.copyFrom(model.rightArm);
        model.leftSleeve.copyFrom(model.leftArm);
        model.rightPants.copyFrom(model.rightLeg);
        model.leftPants.copyFrom(model.leftLeg);
    }
}
