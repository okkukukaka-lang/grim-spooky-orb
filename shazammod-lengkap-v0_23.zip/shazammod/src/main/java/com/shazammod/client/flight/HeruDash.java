package com.shazammod.client.flight;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;

/**
 * Sambaran Heru (Black Adam) di client pemain sendiri: sesudah merunduk (HERU_WINDUP), badan digerakkan lurus ke
 * titik akhir yang sudah dihitung server dalam HERU_TICKS tick. Geraknya lewat kecepatan biasa (bukan teleport),
 * jadi tetap halus di layar, tetap bertabrakan dengan blok, dan tetap terkirim ke server seperti gerak biasa.
 * Kecepatannya cepat di awal lalu mengerem di akhir, seperti elang yang menyambar mangsanya.
 */
public final class HeruDash {
    private HeruDash() {}

    private static Vec3 start;
    private static Vec3 end;
    private static int wait = -1;
    private static int step;

    public static void start(LocalPlayer player, Vec3 target) {
        end = target;
        start = null;
        wait = ShazamAnim.HERU_WINDUP;
        step = 0;
    }

    public static void reset() {
        end = null;
        start = null;
        wait = -1;
    }

    public static boolean active() {
        return end != null;
    }

    /** Sebelum gerak pemain dihitung (sesudah kendali terbang & Mode Kilat, jadi kecepatannya menang). */
    public static void preTick(LocalPlayer player) {
        if (end == null) {
            return;
        }
        if (!ShazamClientState.isTransformed(player.getId()) || player.isPassenger()) {
            reset();
            return;
        }
        if (wait > 0) {   // merunduk: badan tertahan, siap melesat
            wait--;
            Vec3 v = player.getDeltaMovement();
            player.setDeltaMovement(v.x * 0.2, Math.min(v.y, 0.0) * 0.3, v.z * 0.2);
            if (wait == 0) {
                start = player.position();
            }
            return;
        }
        if (start == null) {
            start = player.position();
        }
        step++;
        double u = step / (double) ShazamAnim.HERU_TICKS;
        double e = 1.0 - Math.pow(1.0 - Math.min(1.0, u), 2.2);   // cepat di awal, mengerem di ujung
        Vec3 want = start.lerp(end, e);
        Vec3 move = want.subtract(player.position());
        if (step >= ShazamAnim.HERU_TICKS) {
            // sampai: sisa laju sedikit ke depan, lalu kendali kembali normal
            Vec3 dir = end.subtract(start);
            Vec3 carry = dir.lengthSqr() < 1.0E-6 ? Vec3.ZERO : dir.normalize().scale(0.25);
            player.setDeltaMovement(move.add(carry));
            player.fallDistance = 0f;
            reset();
            return;
        }
        player.setDeltaMovement(move);
        player.fallDistance = 0f;
    }
}
