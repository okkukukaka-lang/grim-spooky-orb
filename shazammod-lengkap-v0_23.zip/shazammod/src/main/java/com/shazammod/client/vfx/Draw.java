package com.shazammod.client.vfx;

import java.util.Arrays;

import org.joml.Matrix4f;
import org.joml.Vector3f;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.ShazamMod;

import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;

/**
 * Alat gambar efek di dunia: semua bentuk dibuat dari geometri dengan gradasi warna per titik (bukan partikel
 * Minecraft), jadi cahayanya halus di jarak berapa pun. Koordinat masukan = posisi dunia; kamera diurus di sini.
 *
 * Efek skill digambar tiga lapis (urutan gambar):
 * 1. badan: bentuk cahaya yang sama, tapi tembus pandang biasa dengan warna yang lebih pekat. Inilah yang bikin
 *    efek terlihat TEBAL dan tetap kelihatan di siang hari atau di depan langit terang (cahaya aditif saja
 *    hampir hilang kalau latarnya sudah terang, makanya dulu efeknya terasa tipis);
 * 2. soft: debu, asap, bekas hangus, retakan gelap (tembus pandang biasa);
 * 3. cahaya: ditambahkan ke layar (aditif), nggak menulis kedalaman, jadi nggak menutupi apa pun di belakangnya.
 *
 * Bentuknya dicatat dulu ke {@link Batch}, lalu dikirim ke lapisan-lapisan itu sekaligus, jadi geometri tiap efek
 * cuma dihitung sekali per frame. Tiap segi empat cuma dikirim dengan sisi yang menghadap kamera (dulu dua sisi
 * dan separuhnya dibuang GPU), jadi titik yang dikirim tinggal separuh: efek bisa jauh lebih tebal tanpa bikin
 * FPS turun.
 */
public final class Draw {
    public static final ResourceLocation WHITE = ShazamMod.id("textures/entity/shazam_white.png");

    // ======= Angka yang gampang diutak-atik =======
    /** Kepekatan badan efek cahaya: 0 = cahaya tipis murni (seperti versi 0.15), 1 = pekat sekali. */
    public static final float BODY = 0.55f;
    /** Pengali terang lapisan cahaya efek skill (1 = seperti versi 0.15). */
    public static final float GLOW = 1.15f;
    /** Seberapa jenuh warna badan dibanding warna cahayanya (1 = sama persis). */
    private static final float BODY_SATURATION = 1.45f;

    public static RenderType additiveType() {
        return RenderType.eyes(WHITE);
    }

    public static RenderType softType() {
        return RenderType.entityShadow(WHITE);
    }

    // ------------------------------------------------------------------ catatan titik

    /**
     * Titik-titik yang dicatat sekali lalu dikirim ke satu atau beberapa lapisan. Satu segi empat = 4 titik
     * berurutan, posisinya sudah di ruang pandang.
     */
    public static final class Batch {
        private static final int MAX_VERTS = 1 << 21;   // pengaman memori (±2 juta titik per frame)
        private float[] xyz = new float[8192 * 3];
        private int[] rgb = new int[8192];
        private float[] alpha = new float[8192];
        private float[] body = new float[8192];
        private int count;

        public void clear() {
            count = 0;
        }

        public boolean isEmpty() {
            return count == 0;
        }

        /** Ada ruang untuk satu segi empat lagi? */
        boolean reserve() {
            if (count + 4 <= rgb.length) {
                return true;
            }
            if (rgb.length >= MAX_VERTS) {
                return false;
            }
            int cap = Math.min(MAX_VERTS, rgb.length * 2);
            xyz = Arrays.copyOf(xyz, cap * 3);
            rgb = Arrays.copyOf(rgb, cap);
            alpha = Arrays.copyOf(alpha, cap);
            body = Arrays.copyOf(body, cap);
            return true;
        }

        void put(float x, float y, float z, int color, float a, float b) {
            int o = count * 3;
            xyz[o] = x;
            xyz[o + 1] = y;
            xyz[o + 2] = z;
            rgb[count] = color;
            alpha[count] = a;
            body[count] = b;
            count++;
        }

        /** Tembus pandang biasa: alpha = kekuatan. */
        public void emitSoft(VertexConsumer vc) {
            for (int i = 0; i < count; i++) {
                int o = i * 3;
                vc.addVertex(xyz[o], xyz[o + 1], xyz[o + 2], (to255(alpha[i]) << 24) | rgb[i], 0.5f, 0.5f,
                        OverlayTexture.NO_OVERLAY, LightTexture.FULL_BRIGHT, 0f, 1f, 0f);
            }
        }

        /** Badan efek cahaya: warna dipekatkan, alpha = kekuatan × kepekatan bentuk × gain. */
        public void emitBody(VertexConsumer vc, float gain) {
            if (gain <= 0f) {
                return;
            }
            for (int q = 0; q + 3 < count; q += 4) {
                float b0 = alpha[q] * body[q] * gain, b1 = alpha[q + 1] * body[q + 1] * gain;
                float b2 = alpha[q + 2] * body[q + 2] * gain, b3 = alpha[q + 3] * body[q + 3] * gain;
                if (b0 <= 0.004f && b1 <= 0.004f && b2 <= 0.004f && b3 <= 0.004f) {
                    continue;
                }
                bodyVertex(vc, q, b0);
                bodyVertex(vc, q + 1, b1);
                bodyVertex(vc, q + 2, b2);
                bodyVertex(vc, q + 3, b3);
            }
        }

        private void bodyVertex(VertexConsumer vc, int i, float b) {
            int o = i * 3;
            vc.addVertex(xyz[o], xyz[o + 1], xyz[o + 2], (to255(b) << 24) | deep(rgb[i]), 0.5f, 0.5f,
                    OverlayTexture.NO_OVERLAY, LightTexture.FULL_BRIGHT, 0f, 1f, 0f);
        }

        /** Cahaya aditif: warna × kekuatan × gain. */
        public void emitGlow(VertexConsumer vc, float gain) {
            for (int i = 0; i < count; i++) {
                int o = i * 3;
                vc.addVertex(xyz[o], xyz[o + 1], xyz[o + 2], 0xFF000000 | scale(rgb[i], alpha[i] * gain), 0.5f, 0.5f,
                        OverlayTexture.NO_OVERLAY, LightTexture.FULL_BRIGHT, 0f, 1f, 0f);
            }
        }
    }

    static int to255(float a) {
        int v = (int) (a * 255f + 0.5f);
        return v < 0 ? 0 : (v > 255 ? 255 : v);
    }

    /** Warna × k (boleh lebih dari 1: warna terang jadi makin putih, seperti cahaya yang menyilaukan). */
    static int scale(int c, float k) {
        if (k <= 0f) {
            return 0;
        }
        int r = (int) (((c >> 16) & 0xFF) * k), g = (int) (((c >> 8) & 0xFF) * k), b = (int) ((c & 0xFF) * k);
        if (r > 255) {
            r = 255;
        }
        if (g > 255) {
            g = 255;
        }
        if (b > 255) {
            b = 255;
        }
        return (r << 16) | (g << 8) | b;
    }

    private static int deepIn = -1, deepOut;

    /** Warna badan: lebih jenuh dari warna cahayanya (putih tetap putih). */
    static int deep(int c) {
        if (c == deepIn) {
            return deepOut;
        }
        int r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
        int max = Math.max(r, Math.max(g, b));
        r = Math.max(0, (int) (max - (max - r) * BODY_SATURATION));
        g = Math.max(0, (int) (max - (max - g) * BODY_SATURATION));
        b = Math.max(0, (int) (max - (max - b) * BODY_SATURATION));
        deepIn = c;
        deepOut = (r << 16) | (g << 8) | b;
        return deepOut;
    }

    /** Campur dua warna (t = 0 -> a, 1 -> b). */
    public static int mix(int a, int b, double t) {
        t = t < 0 ? 0 : (t > 1 ? 1 : t);
        int r = (int) (((a >> 16) & 0xFF) + ((((b >> 16) & 0xFF) - ((a >> 16) & 0xFF)) * t));
        int g = (int) (((a >> 8) & 0xFF) + ((((b >> 8) & 0xFF) - ((a >> 8) & 0xFF)) * t));
        int bl = (int) ((a & 0xFF) + (((b & 0xFF) - (a & 0xFF)) * t));
        return (r << 16) | (g << 8) | bl;
    }

    // ------------------------------------------------------------------ keadaan

    public final double camX, camY, camZ;
    public final float partialTick;
    private final Matrix4f mat;
    private final Vector3f tmp = new Vector3f();
    private VertexConsumer vc;
    private Batch batch;
    private boolean additive;
    private float bodyW = 1f;
    // basis menghadap kamera (diisi basis()): kanan, atas, arah pandang, jarak
    private double rx, ry, rz, ux, uy, uz, fx, fy, fz, fd;
    // tempat kerja (supaya nggak bikin sampah memori tiap frame: GC bikin gerak patah-patah)
    private final double[] plane = new double[6];
    private double[] sx = new double[64], sy = new double[64], sz = new double[64];
    private double[] gx = new double[0], gy = new double[0], gz = new double[0];
    private float[] gk = new float[0];

    public Draw(PoseStack.Pose pose, Vec3 camera, float partialTick) {
        this.mat = new Matrix4f(pose.pose());
        this.camX = camera.x;
        this.camY = camera.y;
        this.camZ = camera.z;
        this.partialTick = partialTick;
    }

    /** Gambar langsung ke satu lapisan (dipakai pernik cahaya roh dewa). */
    public void begin(VertexConsumer consumer, boolean additive) {
        this.vc = consumer;
        this.batch = null;
        this.additive = additive;
    }

    /** Catat ke batch (mesin efek: dihitung sekali, lalu dikirim ke lapisan badan + cahaya). */
    public void record(Batch target, boolean additive) {
        this.vc = null;
        this.batch = target;
        this.additive = additive;
    }

    public boolean additive() {
        return additive;
    }

    /** Atur kepekatan badan bentuk-bentuk berikutnya (1 = biasa, 0 = cahaya murni). Mengembalikan nilai lama. */
    public float body(float weight) {
        float old = bodyW;
        bodyW = weight;
        return old;
    }

    /** Jarak ke kamera (buat mengurangi detail efek yang jauh). */
    public double distance(double x, double y, double z) {
        double dx = x - camX, dy = y - camY, dz = z - camZ;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    // ------------------------------------------------------------------ titik & segi empat

    /** Satu titik (posisi relatif kamera). */
    private void emit(double x, double y, double z, int rgb, float a) {
        float k = a < 0f ? 0f : (a > 1f ? 1f : a);
        mat.transformPosition((float) x, (float) y, (float) z, tmp);
        if (batch != null) {
            batch.put(tmp.x, tmp.y, tmp.z, rgb & 0xFFFFFF, k, bodyW);
            return;
        }
        int color = additive ? 0xFF000000 | scale(rgb, k) : (to255(k) << 24) | (rgb & 0xFFFFFF);
        vc.addVertex(tmp.x, tmp.y, tmp.z, color, 0.5f, 0.5f, OverlayTexture.NO_OVERLAY, LightTexture.FULL_BRIGHT,
                0f, 1f, 0f);
    }

    /**
     * Segi empat a-b-c-d (posisi dunia), warna & kekuatan per titik. Cuma sisi yang menghadap kamera yang dikirim:
     * kalau kedua segitiganya (a-b-c dan c-d-a) membelakangi kamera, urutan titiknya dibalik. Hasilnya sama dengan
     * menggambar dua sisi, tapi titiknya separuh. Segi empat yang terpelintir (satu segitiga menghadap, satunya
     * membelakangi, misalnya pita petir di tikungan tajam) dikirim dua sisi supaya nggak ada yang bolong.
     */
    private void face(double ax, double ay, double az, double bx, double by, double bz,
                      double cx, double cy, double cz, double dx, double dy, double dz,
                      int ca, int cb, int cc, int cd, float aa, float ab, float ac, float ad) {
        if (aa <= 0.002f && ab <= 0.002f && ac <= 0.002f && ad <= 0.002f) {
            return;
        }
        ax -= camX; ay -= camY; az -= camZ;
        bx -= camX; by -= camY; bz -= camZ;
        cx -= camX; cy -= camY; cz -= camZ;
        dx -= camX; dy -= camY; dz -= camZ;
        // GPU membelah a-b-c-d jadi a-b-c + c-d-a, dan urutan baliknya (d-c-b-a) jadi d-c-b + b-a-d.
        // Segitiga p-q-r menghadap kamera (kamera di titik 0) kalau ((q-p) x (r-p)) · p < 0.
        boolean front = orient(ax, ay, az, bx, by, bz, cx, cy, cz) < 0.0 || orient(cx, cy, cz, dx, dy, dz, ax, ay, az) < 0.0;
        boolean back = orient(bx, by, bz, cx, cy, cz, dx, dy, dz) > 0.0 || orient(dx, dy, dz, ax, ay, az, bx, by, bz) > 0.0;
        if (front) {   // urutan ini yang terlihat
            if (batch != null && !batch.reserve()) {
                return;
            }
            emit(ax, ay, az, ca, aa);
            emit(bx, by, bz, cb, ab);
            emit(cx, cy, cz, cc, ac);
            emit(dx, dy, dz, cd, ad);
        }
        if (back) {   // sisi baliknya yang terlihat
            if (batch != null && !batch.reserve()) {
                return;
            }
            emit(dx, dy, dz, cd, ad);
            emit(cx, cy, cz, cc, ac);
            emit(bx, by, bz, cb, ab);
            emit(ax, ay, az, ca, aa);
        }
    }

    /** ((q-p) x (r-p)) · p: negatif = segitiga p-q-r menghadap kamera (posisi relatif kamera), 0 = gepeng. */
    private static double orient(double px, double py, double pz, double qx, double qy, double qz,
                                 double rx, double ry, double rz) {
        double ux = qx - px, uy = qy - py, uz = qz - pz, vx = rx - px, vy = ry - py, vz = rz - pz;
        return (uy * vz - uz * vy) * px + (uz * vx - ux * vz) * py + (ux * vy - uy * vx) * pz;
    }

    /** Segi empat a-b-c-d dengan alpha per titik. */
    public void quad(double ax, double ay, double az, double bx, double by, double bz,
                     double cx, double cy, double cz, double dx, double dy, double dz,
                     int rgb, float aa, float ab, float ac, float ad) {
        face(ax, ay, az, bx, by, bz, cx, cy, cz, dx, dy, dz, rgb, rgb, rgb, rgb, aa, ab, ac, ad);
    }

    /** Segi empat dengan dua warna (a,b memakai c1; c,d memakai c2) - buat gradasi warna. */
    public void quad2(double ax, double ay, double az, double bx, double by, double bz,
                      double cx, double cy, double cz, double dx, double dy, double dz,
                      int c1, int c2, float aa, float ab, float ac, float ad) {
        face(ax, ay, az, bx, by, bz, cx, cy, cz, dx, dy, dz, c1, c1, c2, c2, aa, ab, ac, ad);
    }

    // ------------------------------------------------------------------ menghadap kamera

    /** Isi basis kanan/atas yang menghadap kamera di titik ini. */
    private void basis(double x, double y, double z) {
        double dx = x - camX, dy = y - camY, dz = z - camZ;
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1.0E-6) {
            dx = 0; dy = 0; dz = 1; len = 1;
        }
        fd = len;
        fx = dx / len; fy = dy / len; fz = dz / len;
        // kanan = arah pandang x atas dunia
        rx = -fz; ry = 0; rz = fx;
        double rl = Math.sqrt(rx * rx + rz * rz);
        if (rl < 1.0E-4) {   // melihat lurus ke atas/bawah
            rx = 1; ry = 0; rz = 0;
        } else {
            rx /= rl; rz /= rl;
        }
        // atas = kanan x arah pandang
        ux = ry * fz - rz * fy;
        uy = rz * fx - rx * fz;
        uz = rx * fy - ry * fx;
    }

    // Profil cahaya bulat {jari-jari relatif} -> {kekuatan relatif}: penuh di tengah lalu turun halus seperti pendar
    // sungguhan (mendekati kurva lonceng). Versi sederhana dipakai kalau kecil di layar; kekuatannya disetarakan
    // supaya terangnya nggak meloncat saat tingkat detailnya berganti.
    private static final double[] G3_R = {0.0, 0.24, 0.55, 1.0};
    private static final float[] G3_A = {1f, 0.84f, 0.36f, 0f};
    private static final double[] G2_R = {0.0, 0.4, 1.0};
    private static final float[] G2_A = {1.06f, 0.53f, 0f};
    private static final double[] G1_R = {0.0, 1.0};
    private static final float[] G1_A = {0.91f, 0f};
    // kepulan asap/debu: isinya lebih pekat, tepinya lembut
    private static final double[] P_R = {0.0, 0.38, 0.72, 1.0};
    private static final float[] P_A = {1f, 0.86f, 0.4f, 0f};

    private static final int MAX_SEG = 64;
    private static final double[][] TRIG = new double[MAX_SEG + 1][];

    /** cos/sin sudut 2πk/seg (k = 0..seg), disimpan supaya nggak dihitung ulang tiap frame. */
    private static double[] trig(int seg) {
        double[] t = TRIG[seg];
        if (t == null) {
            t = new double[(seg + 1) * 2];
            for (int k = 0; k <= seg; k++) {
                double a = Math.PI * 2.0 * k / seg;
                t[k * 2] = Math.cos(a);
                t[k * 2 + 1] = Math.sin(a);
            }
            TRIG[seg] = t;
        }
        return t;
    }

    /** Cakram berlapis cincin menghadap kamera (basis sudah diisi). lit/shade = warna sisi atas/bawah. */
    private void fan(double x, double y, double z, double radius, int lit, int shade, float a, double[] rr, float[] ra,
                     int seg) {
        boolean shaded = lit != shade;
        double[] t = trig(seg);
        for (int k = 0; k < seg; k++) {
            double c0 = t[k * 2], s0 = t[k * 2 + 1], c1 = t[k * 2 + 2], s1 = t[k * 2 + 3];
            double dx0 = rx * c0 + ux * s0, dy0 = ry * c0 + uy * s0, dz0 = rz * c0 + uz * s0;
            double dx1 = rx * c1 + ux * s1, dy1 = ry * c1 + uy * s1, dz1 = rz * c1 + uz * s1;
            for (int j = 0; j + 1 < rr.length; j++) {
                double f0 = rr[j], f1 = rr[j + 1];
                double r0 = f0 * radius, r1 = f1 * radius;
                float a0 = ra[j] * a, a1 = ra[j + 1] * a;
                if (a0 <= 0.002f && a1 <= 0.002f) {
                    continue;
                }
                int c00 = lit, c10 = lit, c11 = lit, c01 = lit;
                if (shaded) {   // atas kena cahaya, bawah berbayang
                    c00 = mix(shade, lit, 0.5 + 0.5 * s0 * f0);
                    c10 = mix(shade, lit, 0.5 + 0.5 * s0 * f1);
                    c11 = mix(shade, lit, 0.5 + 0.5 * s1 * f1);
                    c01 = mix(shade, lit, 0.5 + 0.5 * s1 * f0);
                }
                face(x + dx0 * r0, y + dy0 * r0, z + dz0 * r0, x + dx0 * r1, y + dy0 * r1, z + dz0 * r1,
                        x + dx1 * r1, y + dy1 * r1, z + dz1 * r1, x + dx1 * r0, y + dy1 * r0, z + dz1 * r0,
                        c00, c10, c11, c01, a0, a1, a1, a0);
            }
        }
    }

    /** Cahaya bulat lembut menghadap kamera: terang dan penuh di tengah, memudar halus ke tepi. */
    public void glow(double x, double y, double z, float radius, int rgb, float a) {
        if (a <= 0.003f || radius <= 0f) {
            return;
        }
        basis(x, y, z);
        double size = radius / Math.max(0.05, fd);   // kira-kira besar di layar
        if (size < 0.006) {
            fan(x, y, z, radius, rgb, rgb, a, G1_R, G1_A, 5);
        } else if (size < 0.025) {
            fan(x, y, z, radius, rgb, rgb, a, G2_R, G2_A, 7);
        } else if (size < 0.09) {
            fan(x, y, z, radius, rgb, rgb, a, G3_R, G3_A, 10);
        } else {
            fan(x, y, z, radius, rgb, rgb, a, G3_R, G3_A, size < 0.3 ? 14 : 20);
        }
    }

    /**
     * Kepulan asap/debu bervolume menghadap kamera: bagian atas kena cahaya (lit), bawah berbayang (shade), isinya
     * pekat dan menipis halus ke tepi. Dipakai di lapisan soft.
     */
    public void puff(double x, double y, double z, float radius, int lit, int shade, float a) {
        if (a <= 0.003f || radius <= 0f) {
            return;
        }
        basis(x, y, z);
        double size = radius / Math.max(0.05, fd);
        fan(x, y, z, radius, lit, shade, a, P_R, P_A, size < 0.02 ? 6 : size < 0.08 ? 9 : 12);
    }

    /** Cahaya berlapis: pendar berwarna + inti panas yang besar (khas petir/energi). */
    public void flare(double x, double y, double z, float radius, int rgb, float a) {
        glow(x, y, z, radius, rgb, a * 0.8f);
        glow(x, y, z, radius * 0.42f, mix(rgb, 0xFFFFFF, 0.7), a);
    }

    /** Bintang kilau empat sudut menghadap kamera. */
    public void glint(double x, double y, double z, float size, float rot, int rgb, float a) {
        if (a <= 0.003f) {
            return;
        }
        basis(x, y, z);
        double c = Math.cos(rot), s = Math.sin(rot);
        // dua sumbu bintang (diputar)
        double ax = rx * c + ux * s, ay = ry * c + uy * s, az = rz * c + uz * s;
        double bx = -rx * s + ux * c, by = -ry * s + uy * c, bz = -rz * s + uz * c;
        double w = size * 0.15;
        for (int k = 0; k < 2; k++) {
            double px = k == 0 ? ax : bx, py = k == 0 ? ay : by, pz = k == 0 ? az : bz;   // panjang
            double qx = k == 0 ? bx : ax, qy = k == 0 ? by : ay, qz = k == 0 ? bz : az;   // lebar
            for (int sgn = -1; sgn <= 1; sgn += 2) {
                double tx = x + px * size * sgn, ty = y + py * size * sgn, tz = z + pz * size * sgn;
                quad(x + qx * w, y + qy * w, z + qz * w, tx, ty, tz, tx, ty, tz, x - qx * w, y - qy * w, z - qz * w,
                        rgb, a, 0f, 0f, a);
            }
        }
        glow(x, y, z, size * 0.5f, rgb, a * 0.65f);
    }

    /**
     * Garis menghadap kamera dari a ke b dengan tepi lembut (dua pita: tepi 0, tengah penuh).
     * wa/wb = lebar di a/b, aa/ab = kekuatan di a/b.
     */
    public void line(double ax, double ay, double az, double bx, double by, double bz,
                     float wa, float wb, int rgb, float aa, float ab) {
        if (aa <= 0.003f && ab <= 0.003f) {
            return;
        }
        double sx = bx - ax, sy = by - ay, sz = bz - az;
        double mx = (ax + bx) * 0.5 - camX, my = (ay + by) * 0.5 - camY, mz = (az + bz) * 0.5 - camZ;
        // samping = arah garis x arah pandang
        double px = sy * mz - sz * my, py = sz * mx - sx * mz, pz = sx * my - sy * mx;
        double pl = Math.sqrt(px * px + py * py + pz * pz);
        if (pl < 1.0E-9) {
            return;
        }
        px /= pl; py /= pl; pz /= pl;
        double ha = wa * 0.5, hb = wb * 0.5;
        quad(ax + px * ha, ay + py * ha, az + pz * ha, ax, ay, az, bx, by, bz, bx + px * hb, by + py * hb, bz + pz * hb,
                rgb, 0f, aa, ab, 0f);
        quad(ax, ay, az, ax - px * ha, ay - py * ha, az - pz * ha, bx - px * hb, by - py * hb, bz - pz * hb, bx, by, bz,
                rgb, aa, 0f, 0f, ab);
    }

    /**
     * Garis berlapis: pendar luar yang lebar, badan berwarna, dan inti panas (buat petir dan berkas cahaya).
     * Lebih tebal dari versi lama yang cuma pendar + inti tipis.
     */
    public void beam(double ax, double ay, double az, double bx, double by, double bz,
                     float width, int rgb, int core, float aa, float ab) {
        float old = bodyW;
        bodyW = old * 0.55f;
        line(ax, ay, az, bx, by, bz, width * 1.25f, width * 1.25f, rgb, aa * 0.5f, ab * 0.5f);
        bodyW = old;
        line(ax, ay, az, bx, by, bz, width * 0.55f, width * 0.55f, rgb, aa * 0.85f, ab * 0.85f);
        bodyW = old * 0.9f;
        line(ax, ay, az, bx, by, bz, width * 0.24f, width * 0.24f, core, aa, ab);
        bodyW = old;
    }

    /** Hitung arah samping (menghadap kamera) di tiap titik polyline, buat pita yang menyambung mulus. */
    private boolean sides(float[] pts, int count) {
        if (sx.length < count) {
            int cap = Math.max(count, sx.length * 2);
            sx = new double[cap];
            sy = new double[cap];
            sz = new double[cap];
        }
        boolean any = false;
        double lx = 0, ly = 0, lz = 0;
        for (int i = 0; i < count; i++) {
            int a = Math.max(0, i - 1) * 3, b = Math.min(count - 1, i + 1) * 3, o = i * 3;
            double tx = pts[b] - pts[a], ty = pts[b + 1] - pts[a + 1], tz = pts[b + 2] - pts[a + 2];
            if (tx * tx + ty * ty + tz * tz < 1.0E-12 && i + 1 < count) {   // lancip balik: pakai segmen depannya
                tx = pts[o + 3] - pts[o]; ty = pts[o + 4] - pts[o + 1]; tz = pts[o + 5] - pts[o + 2];
            }
            double vx = pts[o] - camX, vy = pts[o + 1] - camY, vz = pts[o + 2] - camZ;
            double px = ty * vz - tz * vy, py = tz * vx - tx * vz, pz = tx * vy - ty * vx;
            double pl = Math.sqrt(px * px + py * py + pz * pz);
            if (pl < 1.0E-9) {   // melihat searah garis: pakai arah samping titik sebelumnya
                px = lx; py = ly; pz = lz;
            } else {
                px /= pl; py /= pl; pz /= pl;
                any = true;
            }
            sx[i] = px; sy[i] = py; sz[i] = pz;
            lx = px; ly = py; lz = pz;
        }
        return any;
    }

    /** Satu lapis pita dari arah samping yang sudah dihitung sides(). */
    private void ribbon(float[] pts, int count, float w0, float w1, int rgb, float a0, float a1) {
        for (int i = 0; i + 1 < count; i++) {
            float f0 = i / (float) (count - 1), f1 = (i + 1) / (float) (count - 1);
            double h0 = (w0 + (w1 - w0) * f0) * 0.5, h1 = (w0 + (w1 - w0) * f1) * 0.5;
            float k0 = a0 + (a1 - a0) * f0, k1 = a0 + (a1 - a0) * f1;
            if (k0 <= 0.003f && k1 <= 0.003f) {
                continue;
            }
            int o = i * 3, p = o + 3;
            double x0 = pts[o], y0 = pts[o + 1], z0 = pts[o + 2], x1 = pts[p], y1 = pts[p + 1], z1 = pts[p + 2];
            double ex0 = sx[i] * h0, ey0 = sy[i] * h0, ez0 = sz[i] * h0;
            double ex1 = sx[i + 1] * h1, ey1 = sy[i + 1] * h1, ez1 = sz[i + 1] * h1;
            quad(x0 + ex0, y0 + ey0, z0 + ez0, x0, y0, z0, x1, y1, z1, x1 + ex1, y1 + ey1, z1 + ez1, rgb, 0f, k0, k1, 0f);
            quad(x0, y0, z0, x0 - ex0, y0 - ey0, z0 - ez0, x1 - ex1, y1 - ey1, z1 - ez1, x1, y1, z1, rgb, k0, 0f, 0f, k1);
        }
    }

    /**
     * Pita menghadap kamera yang menyambung mulus di sepanjang titik-titik (tanpa celah di tikungan), satu lapis,
     * tepi lembut. w0/w1 = lebar di ujung awal/akhir, a0/a1 = kekuatan.
     */
    public void strip(float[] pts, int count, float w0, float w1, int rgb, float a0, float a1) {
        if (count < 2 || (a0 <= 0.003f && a1 <= 0.003f) || !sides(pts, count)) {
            return;
        }
        ribbon(pts, count, w0, w1, rgb, a0, a1);
    }

    /** Polyline xyz (titik berurutan) sebagai berkas berlapis yang menyambung: lebar/kekuatan di ujung awal dan akhir. */
    public void polyline(float[] pts, int count, float w0, float w1, int rgb, int core, float a0, float a1) {
        if (count < 2 || (a0 <= 0.003f && a1 <= 0.003f) || !sides(pts, count)) {
            return;
        }
        float old = bodyW;
        bodyW = old * 0.55f;   // pendar luar
        ribbon(pts, count, w0 * 1.25f, w1 * 1.25f, rgb, a0 * 0.5f, a1 * 0.5f);
        bodyW = old;           // badan berwarna
        ribbon(pts, count, w0 * 0.55f, w1 * 0.55f, rgb, a0 * 0.85f, a1 * 0.85f);
        bodyW = old * 0.9f;    // inti panas
        ribbon(pts, count, w0 * 0.24f, w1 * 0.24f, core, a0, a1);
        bodyW = old;
    }

    /**
     * Seperti polyline, tapi lebar (w) dan kekuatan (a) ditentukan per titik, misalnya petir yang menebal lalu
     * menipis, atau yang memudar di dekat kamera supaya nggak menutupi layar.
     */
    public void polyline(float[] pts, int count, float[] w, float[] a, int rgb, int core) {
        if (count < 2 || !sides(pts, count)) {
            return;
        }
        float old = bodyW;
        bodyW = old * 0.55f;   // pendar luar
        ribbon(pts, count, w, 1.25f, a, 0.5f, rgb);
        bodyW = old;           // badan berwarna
        ribbon(pts, count, w, 0.55f, a, 0.85f, rgb);
        bodyW = old * 0.9f;    // inti panas
        ribbon(pts, count, w, 0.24f, a, 1f, core);
        bodyW = old;
    }

    /** Pita satu lapis dengan lebar w[i] × ws dan kekuatan a[i] × as per titik. */
    public void strip(float[] pts, int count, float[] w, float ws, float[] a, float as, int rgb) {
        if (count < 2 || !sides(pts, count)) {
            return;
        }
        ribbon(pts, count, w, ws, a, as, rgb);
    }

    private void ribbon(float[] pts, int count, float[] w, float ws, float[] a, float as, int rgb) {
        for (int i = 0; i + 1 < count; i++) {
            float k0 = a[i] * as, k1 = a[i + 1] * as;
            if (k0 <= 0.003f && k1 <= 0.003f) {
                continue;
            }
            double h0 = w[i] * ws * 0.5, h1 = w[i + 1] * ws * 0.5;
            int o = i * 3, p = o + 3;
            double x0 = pts[o], y0 = pts[o + 1], z0 = pts[o + 2], x1 = pts[p], y1 = pts[p + 1], z1 = pts[p + 2];
            double ex0 = sx[i] * h0, ey0 = sy[i] * h0, ez0 = sz[i] * h0;
            double ex1 = sx[i + 1] * h1, ey1 = sy[i + 1] * h1, ez1 = sz[i + 1] * h1;
            quad(x0 + ex0, y0 + ey0, z0 + ez0, x0, y0, z0, x1, y1, z1, x1 + ex1, y1 + ey1, z1 + ez1, rgb, 0f, k0, k1, 0f);
            quad(x0, y0, z0, x0 - ex0, y0 - ey0, z0 - ez0, x1 - ex1, y1 - ey1, z1 - ez1, x1, y1, z1, rgb, k0, 0f, 0f, k1);
        }
    }

    /** 0-1: makin dekat kamera makin kecil (0 di bawah near, 1 di atas clear), buat efek yang lewat dekat kamera. */
    public float nearFade(double x, double y, double z, double near, double clear) {
        double t = (distance(x, y, z) - near) / (clear - near);
        if (t <= 0.0) {
            return 0f;
        }
        if (t >= 1.0) {
            return 1f;
        }
        return (float) (t * t * (3.0 - 2.0 * t));
    }

    // ------------------------------------------------------------------ bentuk di bidang tertentu

    /** Dua vektor satuan tegak lurus normal (bidang lingkaran). out = {e1x, e1y, e1z, e2x, e2y, e2z}. */
    public static void plane(double nx, double ny, double nz, double[] out) {
        double ax = Math.abs(ny) < 0.9 ? 0 : 1, ay = Math.abs(ny) < 0.9 ? 1 : 0, az = 0;
        double e1x = ay * nz - az * ny, e1y = az * nx - ax * nz, e1z = ax * ny - ay * nx;
        double l = Math.sqrt(e1x * e1x + e1y * e1y + e1z * e1z);
        e1x /= l; e1y /= l; e1z /= l;
        out[0] = e1x; out[1] = e1y; out[2] = e1z;
        out[3] = ny * e1z - nz * e1y;
        out[4] = nz * e1x - nx * e1z;
        out[5] = nx * e1y - ny * e1x;
    }

    /** Tinggi tanah per sudut & jarak (buat cincin/retakan yang menempel di tanah), atau null = rata. */
    public interface Height {
        double at(double angle, double radius);
    }

    /**
     * Cincin lembut di bidang (normal n): tepi dalam dan luar memudar, paling terang di jari-jari r.
     * @param fill kekuatan isian samar di dalam cincin (0 = cuma cincin)
     */
    public void ring(double cx, double cy, double cz, double nx, double ny, double nz, double radius, double width,
                     int rgb, float a, float fill, Height ground) {
        if (a <= 0.003f || radius <= 0.0) {
            return;
        }
        double[] e = plane;
        plane(nx, ny, nz, e);
        double e0 = e[0], e1 = e[1], e2 = e[2], e3 = e[3], e4 = e[4], e5 = e[5];
        int seg = Math.max(16, Math.min(MAX_SEG, (int) (radius * 10)));
        double[] t = trig(seg);
        double r0 = Math.max(0.0, radius - width * 0.5), r1 = radius + width * 0.5;
        double hc = ground == null ? 0 : ground.at(0, 0);
        for (int k = 0; k < seg; k++) {
            double t0 = Math.PI * 2.0 * k / seg, t1 = Math.PI * 2.0 * (k + 1) / seg;
            double c0 = t[k * 2], s0 = t[k * 2 + 1], c1 = t[k * 2 + 2], s1 = t[k * 2 + 3];
            double dx0 = e0 * c0 + e3 * s0, dy0 = e1 * c0 + e4 * s0, dz0 = e2 * c0 + e5 * s0;
            double dx1 = e0 * c1 + e3 * s1, dy1 = e1 * c1 + e4 * s1, dz1 = e2 * c1 + e5 * s1;
            double h0i = ground == null ? 0 : ground.at(t0, r0), h1i = ground == null ? 0 : ground.at(t1, r0);
            double h0m = ground == null ? 0 : ground.at(t0, radius), h1m = ground == null ? 0 : ground.at(t1, radius);
            double h0o = ground == null ? 0 : ground.at(t0, r1), h1o = ground == null ? 0 : ground.at(t1, r1);
            quad(cx + dx0 * r0, cy + dy0 * r0 + h0i, cz + dz0 * r0, cx + dx0 * radius, cy + dy0 * radius + h0m, cz + dz0 * radius,
                    cx + dx1 * radius, cy + dy1 * radius + h1m, cz + dz1 * radius, cx + dx1 * r0, cy + dy1 * r0 + h1i, cz + dz1 * r0,
                    rgb, a * fill, a, a, a * fill);
            quad(cx + dx0 * radius, cy + dy0 * radius + h0m, cz + dz0 * radius, cx + dx0 * r1, cy + dy0 * r1 + h0o, cz + dz0 * r1,
                    cx + dx1 * r1, cy + dy1 * r1 + h1o, cz + dz1 * r1, cx + dx1 * radius, cy + dy1 * radius + h1m, cz + dz1 * radius,
                    rgb, a, 0f, 0f, a);
            if (fill > 0f && r0 > 0.05) {
                quad(cx, cy + hc, cz, cx, cy + hc, cz, cx + dx1 * r0, cy + dy1 * r0 + h1i, cz + dz1 * r0,
                        cx + dx0 * r0, cy + dy0 * r0 + h0i, cz + dz0 * r0, rgb, 0f, 0f, a * fill, a * fill);
            }
        }
    }

    /** Cakram di bidang: kekuatan aCenter di tengah ke aEdge di tepi. */
    public void disc(double cx, double cy, double cz, double nx, double ny, double nz, double radius,
                     int rgb, float aCenter, float aEdge, Height ground) {
        if ((aCenter <= 0.003f && aEdge <= 0.003f) || radius <= 0.0) {
            return;
        }
        double[] e = plane;
        plane(nx, ny, nz, e);
        double e0 = e[0], e1 = e[1], e2 = e[2], e3 = e[3], e4 = e[4], e5 = e[5];
        int seg = Math.max(12, Math.min(40, (int) (radius * 8)));
        double[] t = trig(seg);
        double hc = ground == null ? 0 : ground.at(0, 0);
        double rm = radius * 0.5;
        float am = (aCenter + aEdge) * 0.5f;
        for (int k = 0; k < seg; k++) {
            double t0 = Math.PI * 2.0 * k / seg, t1 = Math.PI * 2.0 * (k + 1) / seg;
            double c0 = t[k * 2], s0 = t[k * 2 + 1], c1 = t[k * 2 + 2], s1 = t[k * 2 + 3];
            double dx0 = e0 * c0 + e3 * s0, dy0 = e1 * c0 + e4 * s0, dz0 = e2 * c0 + e5 * s0;
            double dx1 = e0 * c1 + e3 * s1, dy1 = e1 * c1 + e4 * s1, dz1 = e2 * c1 + e5 * s1;
            double hm0 = ground == null ? 0 : ground.at(t0, rm), hm1 = ground == null ? 0 : ground.at(t1, rm);
            double he0 = ground == null ? 0 : ground.at(t0, radius), he1 = ground == null ? 0 : ground.at(t1, radius);
            quad(cx, cy + hc, cz, cx, cy + hc, cz, cx + dx1 * rm, cy + dy1 * rm + hm1, cz + dz1 * rm,
                    cx + dx0 * rm, cy + dy0 * rm + hm0, cz + dz0 * rm, rgb, aCenter, aCenter, am, am);
            quad(cx + dx0 * rm, cy + dy0 * rm + hm0, cz + dz0 * rm, cx + dx1 * rm, cy + dy1 * rm + hm1, cz + dz1 * rm,
                    cx + dx1 * radius, cy + dy1 * radius + he1, cz + dz1 * radius, cx + dx0 * radius, cy + dy0 * radius + he0,
                    cz + dz0 * radius, rgb, am, am, aEdge, aEdge);
        }
    }

    /** Garis datar di bidang (normal n), tepi lembut. */
    public void flatLine(double ax, double ay, double az, double bx, double by, double bz,
                         double nx, double ny, double nz, float width, int rgb, float aa, float ab) {
        double sx = bx - ax, sy = by - ay, sz = bz - az;
        double px = sy * nz - sz * ny, py = sz * nx - sx * nz, pz = sx * ny - sy * nx;
        double pl = Math.sqrt(px * px + py * py + pz * pz);
        if (pl < 1.0E-9) {
            return;
        }
        double h = width * 0.5 / pl;
        px *= h; py *= h; pz *= h;
        quad(ax + px, ay + py, az + pz, ax, ay, az, bx, by, bz, bx + px, by + py, bz + pz, rgb, 0f, aa, ab, 0f);
        quad(ax, ay, az, ax - px, ay - py, az - pz, bx - px, by - py, bz - pz, bx, by, bz, rgb, aa, 0f, 0f, ab);
    }

    private void grid(int n) {
        if (gx.length < n) {
            gx = new double[n];
            gy = new double[n];
            gz = new double[n];
            gk = new float[n];
        }
    }

    /**
     * Cangkang bola (atau kubah) yang tepinya paling terang, seperti gelembung energi:
     * kekuatan tiap titik = (1 - |normal · arah ke kamera|)^power.
     * @param upper 1 = bola penuh, 0.5 = kubah setengah bola di atas tanah
     */
    public void shell(double cx, double cy, double cz, double radius, int rgb, float a, double power, double upper) {
        if (a <= 0.003f || radius <= 0.0) {
            return;
        }
        int lon = radius > 6 ? 28 : 18, lat = radius > 6 ? 14 : 10;
        int w = lon + 1;
        grid((lat + 1) * w);
        double[] t = trig(lon);
        double latMax = Math.PI * upper;
        for (int i = 0; i <= lat; i++) {
            double th = latMax * i / lat;   // 0 = puncak
            double st = Math.sin(th), ct = Math.cos(th);
            for (int j = 0; j <= lon; j++) {
                double nx = st * t[j * 2], ny = ct, nz = st * t[j * 2 + 1];
                double x = cx + nx * radius, y = cy + ny * radius, z = cz + nz * radius;
                int o = i * w + j;
                gx[o] = x; gy[o] = y; gz[o] = z;
                double vx = camX - x, vy = camY - y, vz = camZ - z;
                double vl = Math.sqrt(vx * vx + vy * vy + vz * vz);
                double f = vl < 1.0E-6 ? 1.0 : 1.0 - Math.abs((nx * vx + ny * vy + nz * vz) / vl);
                gk[o] = (float) (a * Math.pow(Math.max(0.0, f), power));
            }
        }
        for (int i = 0; i < lat; i++) {
            for (int j = 0; j < lon; j++) {
                int p = i * w + j, q = p + 1, r = p + w + 1, s = p + w;
                quad(gx[p], gy[p], gz[p], gx[q], gy[q], gz[q], gx[r], gy[r], gz[r], gx[s], gy[s], gz[s],
                        rgb, gk[p], gk[q], gk[r], gk[s]);
            }
        }
    }

    /**
     * Kerucut terbuka dari puncak a ke arah d (sudah satuan), panjang len, setengah sudut atan(spread).
     * Kekuatan naik dari puncak ke mulut kerucut, tepi paling terang (khas gelombang udara / uap sonic boom).
     */
    public void cone(double ax, double ay, double az, double dx, double dy, double dz, double len, double spread,
                     int rgb, float a, double power) {
        if (a <= 0.003f || len <= 0.0) {
            return;
        }
        double[] e = plane;
        plane(dx, dy, dz, e);
        double e0 = e[0], e1 = e[1], e2 = e[2], e3 = e[3], e4 = e[4], e5 = e[5];
        int seg = 24, rings = 6;
        int w = seg + 1;
        grid((rings + 1) * w);
        double[] t = trig(seg);
        for (int i = 0; i <= rings; i++) {
            double f = i / (double) rings;
            double dist = len * f, r = dist * spread;
            for (int j = 0; j <= seg; j++) {
                double cs = t[j * 2], sn = t[j * 2 + 1];
                double ox = e0 * cs + e3 * sn, oy = e1 * cs + e4 * sn, oz = e2 * cs + e5 * sn;
                double x = ax + dx * dist + ox * r, y = ay + dy * dist + oy * r, z = az + dz * dist + oz * r;
                int o = i * w + j;
                gx[o] = x; gy[o] = y; gz[o] = z;
                // normal kerucut (kira-kira) = arah keluar dikurangi sedikit arah sumbu
                double nx = ox - dx * spread, ny = oy - dy * spread, nz = oz - dz * spread;
                double nl = Math.sqrt(nx * nx + ny * ny + nz * nz);
                double vx = camX - x, vy = camY - y, vz = camZ - z;
                double vl = Math.sqrt(vx * vx + vy * vy + vz * vz);
                double rim = vl < 1.0E-6 || nl < 1.0E-9 ? 1.0 : 1.0 - Math.abs((nx * vx + ny * vy + nz * vz) / (vl * nl));
                gk[o] = (float) (a * Math.pow(Math.max(0.0, rim), power) * f * f);
            }
        }
        for (int i = 0; i < rings; i++) {
            for (int j = 0; j < seg; j++) {
                int p = i * w + j, q = p + 1, r = p + w + 1, s = p + w;
                quad(gx[p], gy[p], gz[p], gx[q], gy[q], gz[q], gx[r], gy[r], gz[r], gx[s], gy[s], gz[s],
                        rgb, gk[p], gk[q], gk[r], gk[s]);
            }
        }
    }

    /** Pilar cahaya tegak menghadap kamera (lebar w, dari y0 ke y1), tepi lembut, ujung atas memudar. */
    public void pillar(double x, double y0, double z, double y1, float width, int rgb, int core, float a) {
        int steps = 6;
        for (int i = 0; i < steps; i++) {
            double ya = y0 + (y1 - y0) * i / steps, yb = y0 + (y1 - y0) * (i + 1) / steps;
            float fa = 1f - i / (float) steps, fb = 1f - (i + 1) / (float) steps;
            beam(x, ya, z, x, yb, z, width, rgb, core, a * (0.35f + 0.65f * fa), a * (0.35f + 0.65f * fb) * (i == steps - 1 ? 0f : 1f));
        }
    }
}
