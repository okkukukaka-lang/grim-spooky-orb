package com.shazammod.client.vfx;

import java.util.ArrayList;
import java.util.List;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Mesin efek visual Shazam: semua efek skill digambar sendiri di dunia (cahaya lembut, gelombang kejut,
 * petir bercabang, retakan tanah, pecahan blok, lingkaran rune, asap, dan lain-lain), bukan partikel Minecraft.
 * Efek berumur pendek, dihitung tiap tick, digambar tiap frame dengan interpolasi supaya halus.
 *
 * Efek yang baru dibuat mulai dari umur 0 di frame berikutnya (dulu langsung dimajukan satu tick saat dibuat,
 * jadi detik pertamanya hilang: kilatan kehilangan puncak terangnya dan busur petir yang umurnya 1-2 tick
 * hampir nggak kelihatan).
 */
public final class Vfx {
    private Vfx() {}

    // ======= Angka yang gampang diutak-atik =======
    /** Kepadatan butiran (percikan, bara, debu, asap, ...) semua skill. 1 = seperti versi 0.15. */
    public static final float DENSITY = 1.6f;
    /** Batas jumlah efek sekaligus. Kalau penuh, yang paling dekat habis yang dibuang (bukan efek baru). */
    private static final int MAX_EFFECTS = 1024;

    private static final List<Effect> EFFECTS = new ArrayList<>();
    private static final List<Effect> PENDING = new ArrayList<>();
    private static final Particles PARTICLES = new Particles();
    private static final RandomSource RANDOM = RandomSource.create();
    private static final Draw.Batch SOFT = new Draw.Batch();
    private static final Draw.Batch GLOW = new Draw.Batch();

    public static RandomSource random() {
        return RANDOM;
    }

    /** Jumlah butiran dikali kepadatan efek. */
    public static int count(double base) {
        return (int) Math.max(0L, Math.round(base * DENSITY));
    }

    public static void add(Effect effect) {
        if (PENDING.size() < MAX_EFFECTS) {
            PENDING.add(effect);
        }
    }

    public static void clear() {
        EFFECTS.clear();
        PENDING.clear();
        PARTICLES.clear();
    }

    public static void tick(ClientLevel level) {
        PARTICLES.tick();                                     // butiran lama maju selangkah
        EFFECTS.removeIf(effect -> !effect.tick(level));      // efek lama maju selangkah
        for (Effect effect : PENDING) {                       // efek baru: mulai umur 0, digambar mulai frame ini
            if (EFFECTS.size() >= MAX_EFFECTS) {
                evictOldest();
            }
            EFFECTS.add(effect);
        }
        PENDING.clear();
        PARTICLES.endTick();
    }

    /** Buang efek yang paling dekat habis (efek yang baru dipicu pemain selalu dapat tempat). */
    private static void evictOldest() {
        int worst = -1;
        float most = -1f;
        for (int i = 0; i < EFFECTS.size(); i++) {
            Effect e = EFFECTS.get(i);
            float p = e.age / (float) e.life;
            if (p > most) {
                most = p;
                worst = i;
            }
        }
        if (worst >= 0) {
            EFFECTS.remove(worst);
        }
    }

    // ------------------------------------------------------------------ butiran

    /** Butiran cahaya lembut yang melayang. */
    public static void mote(double x, double y, double z, double vx, double vy, double vz, int rgb, float size, int life) {
        PARTICLES.spawn(Particles.MOTE, x, y, z, vx, vy, vz, rgb, size, life, 0f, 0.04f, Double.NaN, RANDOM.nextFloat());
    }

    /** Percikan memanjang searah gerak; jatuh dan memantul di tanah (floorY, atau NaN = tanpa tanah). */
    public static void spark(double x, double y, double z, double vx, double vy, double vz, int rgb, float size, int life,
                             double floorY) {
        PARTICLES.spawn(Particles.SPARK, x, y, z, vx, vy, vz, rgb, size, life, 0.035f, 0.05f, floorY, RANDOM.nextFloat());
    }

    /** Bara yang naik sambil mendingin. */
    public static void ember(double x, double y, double z, double vx, double vy, double vz, float size, int life) {
        PARTICLES.spawn(Particles.EMBER, x, y, z, vx, vy, vz, 0xFFE0A0, size, life, -0.002f, 0.06f, Double.NaN, RANDOM.nextFloat());
    }

    /** Bintang kilau empat sudut. */
    public static void glint(double x, double y, double z, int rgb, float size, int life) {
        PARTICLES.spawn(Particles.GLINT, x, y, z, 0, 0, 0, rgb, size, life, 0f, 0f, Double.NaN, RANDOM.nextFloat());
    }

    /** Kepulan debu lembut (warna tanah), bervolume: atas terang, bawah berbayang. */
    public static void dust(double x, double y, double z, double vx, double vy, double vz, int rgb, float size, int life) {
        PARTICLES.spawn(Particles.DUST, x, y, z, vx, vy, vz, rgb, size, life, -0.001f, 0.12f, Double.NaN, RANDOM.nextFloat());
    }

    /**
     * Asap tebal: naik pelan karena lebih hangat dari udara, melambat karena hambatan udara, mengembang, berkelok
     * terbawa udara, lalu menipis. Tembus pandang biasa (bukan cahaya), bervolume.
     */
    public static void smoke(double x, double y, double z, double vx, double vy, double vz, int rgb, float size, int life) {
        PARTICLES.spawn(Particles.SMOKE, x, y, z, vx, vy, vz, rgb, size, life, -0.0035f, 0.075f, Double.NaN, RANDOM.nextFloat());
    }

    // ------------------------------------------------------------------ gambar

    /** Dipanggil dari RenderLevelStageEvent. */
    public static void render(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES || (EFFECTS.isEmpty() && PARTICLES.isEmpty())) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            return;
        }
        float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        Vec3 cam = event.getCamera().getPosition();
        PoseStack poseStack = event.getPoseStack();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        poseStack.pushPose();
        // 1) benda padat (pecahan blok)
        for (Effect effect : EFFECTS) {
            effect.renderSolid(poseStack, buffers, cam.x, cam.y, cam.z, partialTick);
        }
        buffers.endBatch();
        // 2) catat semua bentuk (geometrinya dihitung sekali)
        Draw draw = new Draw(poseStack.last(), cam, partialTick);
        SOFT.clear();
        GLOW.clear();
        draw.record(SOFT, false);
        PARTICLES.renderSoft(draw);
        for (Effect effect : EFFECTS) {
            effect.renderSoft(draw);
        }
        draw.record(GLOW, true);
        PARTICLES.renderGlow(draw);
        for (Effect effect : EFFECTS) {
            effect.renderGlow(draw);
        }
        // 3) badan efek cahaya + debu/asap (tembus pandang biasa), lalu cahayanya (aditif) di atas semuanya
        if (!SOFT.isEmpty() || !GLOW.isEmpty()) {
            VertexConsumer soft = buffers.getBuffer(Draw.softType());
            GLOW.emitBody(soft, Draw.BODY);
            SOFT.emitSoft(soft);
        }
        if (!GLOW.isEmpty()) {
            GLOW.emitGlow(buffers.getBuffer(Draw.additiveType()), Draw.GLOW);
        }
        buffers.endBatch();
        poseStack.popPose();
    }
}
