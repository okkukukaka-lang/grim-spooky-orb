package com.shazammod.client.fx;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.joml.Quaternionf;

import com.mojang.blaze3d.vertex.PoseStack;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamPowers;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Runes;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Efek Black Adam di client, gaya film: petir emas-jingga membara yang tebal dan bercabang, listrik yang merayap di
 * kulit, gelombang kejut berlapis, kubah petir, batu & pasir beterbangan, tanah terbelah membara, dan kamera yang ikut
 * terguncang. Semuanya buatan sendiri di atas mesin efek (client.vfx), dipicu animasi dari server (ShazamAnim.ADAM_*,
 * plus SUMMON/TRANSFORM/REVERT/KNOCKOUT dan gerak terbang kalau pemainnya Black Adam).
 *
 * S Badai Shu       : badai pasir berpilin setinggi 7 blok, petir menyambar di dalamnya, batu mengorbit, lalu meledak.
 * H Sambaran Heru   : kerucut sonic, sayap elang dari cahaya, petir yang tertinggal di lintasan, hantaman di ujung.
 * A Tinju Amon      : kubah kejut raksasa, tanah terbelah membara dengan petir merambat dan tiang-tiang batu mencuat.
 * Z Segel Zehuti    : gelombang hieroglif, rantai huruf cahaya ke tiap musuh, tiga cincin hieroglif yang mengunci.
 * A Sinar Aton      : cakram matahari bermahkota petir, sinar tebal berpilin petir, ledakan api di sasaran.
 * M Lilitan Mehen   : ular cahaya tebal bergelang emas-merah berlistrik yang menyeruak dari pasir.
 * R Murka Kahndaq   : petir dari langit menghujani sekeliling, lalu meraung: kubah petir, guncangan besar.
 * M Panggil Petir   : kepalan ke langit, awan berputar, petir sihir menyambar badan sendiri.
 * Selalu            : listrik samar merayap di kulit dan bara naik pelan selama berwujud Black Adam.
 */
public final class AdamFx {
    private AdamFx() {}

    // ======= Warna (RGB) =======
    public static final int AMBER = 0xFF8A24;        // petir & aura Black Adam: emas-jingga membara
    public static final int AMBER_LIGHT = 0xFFC46A;
    public static final int GOLD_HOT = 0xFFE2A8;
    public static final int WHITE_HOT = 0xFFF4E0;
    public static final int EMBER_RED = 0xFF5A1E;    // bara & celah membara
    public static final int TURQUOISE = 0x48E2CE;    // Zehuti
    public static final int TURQUOISE_LIGHT = 0xC8FFF0;
    public static final int SUN = 0xFFD54A;          // Aton
    public static final int SERPENT = 0xFFC860;      // Mehen
    public static final int SERPENT_RED = 0xE8502E;
    public static final int SAND = 0xD9C08A;
    public static final int SAND_DARK = 0xA8875A;
    public static final int SMOKE = 0x17120E;        // asap hitam Black Adam
    private static final Vec3 UP = new Vec3(0, 1, 0);

    // ======= Angka yang gampang diutak-atik =======
    /** Listrik samar di kulit selama berwujud Black Adam (busur per tick). 0 = mati. */
    private static final float AURA_RATE = 0.4f;

    private static final Map<Integer, Long> SIGHT = new HashMap<>();                   // mata pirus Zehuti: kapan mulai
    private static final Map<Integer, Serpent> SERPENTS = new HashMap<>();             // ular Mehen yang sedang melilit
    private static final Map<Integer, SunDisk> SUNS = new HashMap<>();                 // cakram Aton yang sedang menyala
    private static final Map<Integer, Lightning.Crackle> AURA = new HashMap<>();       // listrik samar di kulit

    public static void clear() {
        SIGHT.clear();
        SERPENTS.clear();
        SUNS.clear();
        for (Lightning.Crackle crackle : AURA.values()) {
            crackle.stop();
        }
        AURA.clear();
    }

    public static void tick(ClientLevel level) {
        long now = level.getGameTime();
        SIGHT.values().removeIf(start -> now - start > 80);
        SERPENTS.values().removeIf(s -> s.done);
        SUNS.values().removeIf(s -> s.done);
        aura(level);
    }

    /** Listrik samar merayap di kulit dan bara naik pelan: tanda Black Adam bahkan saat diam. */
    private static void aura(ClientLevel level) {
        Minecraft mc = Minecraft.getInstance();
        Iterator<Map.Entry<Integer, Lightning.Crackle>> it = AURA.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Lightning.Crackle> e = it.next();
            Entity entity = level.getEntity(e.getKey());
            if (!(entity instanceof AbstractClientPlayer p) || !ShazamClientState.isTransformed(p.getId())
                    || !ShazamClientState.isAdam(p.getId()) || !e.getValue().active()) {
                e.getValue().stop();
                it.remove();
            }
        }
        if (AURA_RATE <= 0f) {
            return;
        }
        for (AbstractClientPlayer player : level.players()) {
            if (!ShazamClientState.isTransformed(player.getId()) || !ShazamClientState.isAdam(player.getId())
                    || player.isInvisible()) {
                continue;
            }
            Lightning.Crackle crackle = AURA.get(player.getId());
            if (crackle == null) {
                crackle = new Lightning.Crackle(player, AMBER_LIGHT, AURA_RATE, 0.03f, 20 * 60 * 30).reach(0.6);
                AURA.put(player.getId(), crackle);
                Vfx.add(crackle);
            }
            boolean firstPerson = player == mc.player && mc.options.getCameraType().isFirstPerson();
            float speed = (float) player.getDeltaMovement().length();
            crackle.strength(firstPerson ? 0f : Mth.clamp(0.55f + speed * 0.6f, 0f, 1.4f));
            if (!firstPerson && player.tickCount % 7 == 0) {   // bara naik pelan dari badan
                double a = level.random.nextDouble() * Math.PI * 2.0, r = 0.3 + level.random.nextDouble() * 0.2;
                Vfx.ember(player.getX() + Math.cos(a) * r, player.getY() + 0.2 + level.random.nextDouble() * 1.6,
                        player.getZ() + Math.sin(a) * r, 0, 0.02 + level.random.nextDouble() * 0.02, 0, 0.05f,
                        14 + level.random.nextInt(10));
            }
        }
    }

    /** Animasi ini diurus AdamFx (ShazamFx melewatinya). */
    public static boolean handles(AbstractClientPlayer caster, ShazamAnim anim) {
        return switch (anim) {
            case SUMMON, TRANSFORM, REVERT, KNOCKOUT, LAUNCH, LAND_HERO, CRASH, SONIC_BOOM, ROLL_LEFT, ROLL_RIGHT ->
                    ShazamClientState.isAdam(caster.getId());
            default -> anim.name().startsWith("ADAM_");
        };
    }

    /** 0-1: mata pirus menyala sesudah Segel Zehuti. */
    public static float sightGlow(AbstractClientPlayer player, float partialTick) {
        Long start = SIGHT.get(player.getId());
        if (start == null) {
            return 0f;
        }
        float t = player.level().getGameTime() - start + partialTick - 2f;
        if (t < 0f) {
            return 0f;
        }
        return Math.min(1f, t / 3f) * Mth.clamp((70f - t) / 25f, 0f, 1f);
    }

    /** 0-1: ular Mehen sedang melilit pemain ini (HUD). */
    public static float mehenStrength(AbstractClientPlayer player, float partialTick) {
        Serpent s = SERPENTS.get(player.getId());
        return s == null || s.done ? 0f : s.strength(partialTick);
    }

    public static void onAnim(AbstractClientPlayer caster, ShazamAnim anim, Vec3 pos) {
        if (!handles(caster, anim)) {
            return;
        }
        boolean self = caster == Minecraft.getInstance().player;
        switch (anim) {
            case SUMMON -> summon(caster, self);
            case TRANSFORM -> transform(caster, self);
            case REVERT -> revert(caster, self);
            case KNOCKOUT -> knockout(caster, self);
            case LAUNCH -> launch(caster);
            case LAND_HERO -> landing(caster, self);
            case CRASH -> crash(caster);
            case SONIC_BOOM -> sonicBoom(caster, self);
            case ROLL_LEFT, ROLL_RIGHT -> sidestep(caster, anim == ShazamAnim.ROLL_RIGHT, self);
            case ADAM_SHU -> shu(caster, self);
            case ADAM_HERU -> heru(caster, pos, self);
            case ADAM_AMON -> amon(caster, pos, self);
            case ADAM_ZEHUTI -> zehuti(caster, self);
            case ADAM_ZEHUTI_MARK -> seal(caster, pos);
            case ADAM_ATON -> aton(caster, self);
            case ADAM_ATON_RAY -> ray(caster, pos);
            case ADAM_MEHEN -> mehen(caster, self);
            case ADAM_MEHEN_BITE -> bite(caster, pos);
            case ADAM_RAGE -> rage(caster, self);
            case ADAM_CALL -> call(caster, self);
            case ADAM_DEFLECT -> deflect(caster, pos);
            case ADAM_PUNCH -> punch(caster, pos, self);
            default -> { }
        }
    }

    // ------------------------------------------------------------------ alat bantu

    private static void schedule(int delay, int duration, ShazamFx.Step step) {
        ShazamFx.schedule(delay, duration, step);
    }

    private static void sound(ClientLevel level, Vec3 at, net.minecraft.sounds.SoundEvent sound, float volume, float pitch) {
        level.playLocalSound(at.x, at.y, at.z, sound, SoundSource.PLAYERS, volume, ShazamFx.slowPitch(level, pitch), false);
    }

    private static boolean firstPerson(AbstractClientPlayer player) {
        Minecraft mc = Minecraft.getInstance();
        return player == mc.player && mc.options.getCameraType().isFirstPerson();
    }

    /** Listrik tebal merayap di kulit selama beberapa tick (sesudah petir menyambar badan). */
    private static void surge(AbstractClientPlayer caster, int ticks, float perTick, float width) {
        Lightning.Crackle crackle = new Lightning.Crackle(caster, AMBER_LIGHT, perTick, width, ticks).reach(1.1);
        crackle.strength(firstPerson(caster) ? 0.25f : 1f);
        Vfx.add(crackle);
    }

    /** Busur petir dari titik ke luar ke segala arah (di udara). */
    private static void arcsOut(ClientLevel level, Vec3 from, int count, double reach, int rgb, float width, int life) {
        for (int k = 0; k < count; k++) {
            Vec3 d = ShazamFx.randomDir(level.random);
            d = new Vec3(d.x, Math.abs(d.y) * 0.7 - 0.1, d.z).normalize();
            Vec3 end = from.add(d.scale(reach * (0.6 + level.random.nextDouble() * 0.5)));
            Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(from), Lightning.Anchor.fixed(end), rgb, width,
                    life + level.random.nextInt(3), 1, 2, 0.3));
        }
    }

    /** Kubah petir: cangkang cahaya yang mengembang dan busur-busur dari pusat ke kulit kubah. */
    private static void dome(ClientLevel level, Vec3 c, double radius, int life) {
        Vfx.add(new Fx.Bubble(c, radius, AMBER, life, 0.95f, 1.0, 1.7, true));
        Vfx.add(new Fx.Bubble(c, radius * 0.7, GOLD_HOT, life - 2, 0.6f, 1.0, 2.4, true));
        arcsOut(level, c, 10, radius, AMBER_LIGHT, 0.1f, 4);
    }

    /** Petir dari langit ke titik ini (hiasan; damage diurus server). */
    private static void skyBolt(Vec3 at, float size, int life) {
        Vfx.add(new SkyBolt(at, size, life));
    }

    /** Tanah di bawah titik ini (atau null kalau nggak ketemu). */
    private static Ground.Map groundAt(ClientLevel level, Vec3 p, double radius) {
        Ground.Map map = ShazamFx.ground(level, p, radius);
        return map != null && map.found ? map : null;
    }

    /** Hantaman tanah ala Black Adam: hantaman ShazamFx + gelombang putih cepat, debu tebal, dan petir di tanah. */
    private static void slam(ClientLevel level, AbstractClientPlayer caster, Vec3 at, float size, boolean self) {
        ShazamFx.impact(level, caster, at, size, AMBER, GOLD_HOT, true, 1.4f);
        Ground.Map map = groundAt(level, at, 3.0 + size * 2.5);
        if (map != null) {
            Vec3 g = map.center(at);
            Vfx.add(new Fx.Wave(g, UP, 3.4 + size * 3.2, 0.25, WHITE_HOT, 9, 0.9f, 0f, map));
            Vfx.add(new Fx.Wave(g.add(0, 0.05, 0), UP, 2.6 + size * 2.6, 1.3 + size * 0.5, map.dustColor(level, at), 34, 0.65f, 0f,
                    map, true));
            Vfx.add(new Fx.Scorch(g, 0.9 + size * 0.6, 160, 40, map));
            ShazamFx.groundArcs(level, at, 5 + (int) (size * 2f), 2.4 + size * 1.6, AMBER, 6);
            ShazamFx.dustPuffs(level, g, map.dustColor(level, at), (int) (14 + size * 10), 1.0 + size * 0.6, 0.16 + size * 0.05);
        }
        ShazamFx.ringOfSparks(level, at.add(0, 0.4, 0), (int) (20 + size * 14), AMBER_LIGHT, 0.4 + size * 0.08);
        ShazamFx.shakeAround(at, 0.5f + size * 0.25f, 22 + size * 6);
        if (self) {
            ScreenFlash.flash(0.2f + size * 0.08f, 0xFFE2B8);
        }
    }

    // ------------------------------------------------------------------ berubah wujud

    /**
     * Memanggil dewa-dewa Mesir: lingkaran hieroglif emas membara di tanah, pasir berputar di tepinya, asap hitam
     * merayap di kaki, cahaya mengalir dari lingkaran ke dada, dan percikan listrik kecil di tanah. Dewa-dewanya:
     * ShazamSpirits.
     */
    private static void summon(AbstractClientPlayer caster, boolean self) {
        ShazamSpirits.start(caster);
        if (self) {
            ShazamCinematic.start();
        }
        int total = ShazamAnim.SUMMON_TICKS + ShazamAnim.TRANSFORM_STRIKE;
        schedule(0, 1, (level, t) -> {
            Vec3 c = caster.position();
            Ground.Map map = ShazamFx.ground(level, c, 3.2);
            double groundY = (map == null ? c.y : map.centerY) + 0.03;
            Vfx.add(new Runes.Circle(pt -> new Vec3(caster.getPosition(pt).x, groundY, caster.getPosition(pt).z), UP,
                    2.6 * caster.getScale(), AMBER, total + 8, -0.03f, 1f, null));
            Vfx.add(new Runes.Circle(pt -> new Vec3(caster.getPosition(pt).x, groundY + 0.01, caster.getPosition(pt).z), UP,
                    1.5 * caster.getScale(), GOLD_HOT, total + 8, 0.045f, 0.7f, null));
            Vfx.add(new Runes.Circle(pt -> new Vec3(caster.getPosition(pt).x, groundY + 0.02, caster.getPosition(pt).z), UP,
                    3.6 * caster.getScale(), EMBER_RED, total + 8, 0.018f, 0.45f, null));
            sound(level, c, SoundEvents.AMETHYST_BLOCK_RESONATE, 1.2f, 0.45f);
            sound(level, c, SoundEvents.SAND_BREAK, 1.0f, 0.6f);
        });
        schedule(0, total, (level, t) -> {
            RandomSource r = level.random;
            double radius = 2.6 * caster.getScale();
            for (int i = 0, n = Vfx.count(3); i < n; i++) {   // cahaya mengalir dari lingkaran ke dada, berpilin
                double a = r.nextDouble() * Math.PI * 2.0;
                double x = caster.getX() + Math.cos(a) * radius, z = caster.getZ() + Math.sin(a) * radius;
                double tx = caster.getX() - x, tz = caster.getZ() - z;
                Vfx.mote(x, caster.getY() + 0.05, z, tx * 0.045 + tz * 0.03, 0.05 + r.nextDouble() * 0.03, tz * 0.045 - tx * 0.03,
                        i % 3 == 0 ? GOLD_HOT : AMBER_LIGHT, 0.1f, 22 + r.nextInt(8));
            }
            if (t % 2 == 0) {   // pasir berputar di tepi lingkaran
                for (int k = 0; k < 2; k++) {
                    double a = t * 0.21 + r.nextDouble() + k * Math.PI;
                    double x = caster.getX() + Math.cos(a) * (radius + 0.5), z = caster.getZ() + Math.sin(a) * (radius + 0.5);
                    Vfx.dust(x, caster.getY() + 0.1, z, -Math.sin(a) * 0.14, 0.02, Math.cos(a) * 0.14, k == 0 ? SAND : SAND_DARK,
                            0.55f, 20);
                }
            }
            if (t % 4 == 0) {   // asap hitam merayap di kaki
                double a = r.nextDouble() * Math.PI * 2.0, d = 0.6 + r.nextDouble() * 1.2;
                Vfx.smoke(caster.getX() + Math.cos(a) * d, caster.getY() + 0.1, caster.getZ() + Math.sin(a) * d,
                        Math.cos(a) * 0.012, 0.014, Math.sin(a) * 0.012, SMOKE, 0.45f + r.nextFloat() * 0.25f, 38);
            }
            if (t % 9 == 4) {   // percikan listrik kecil merayap di lingkaran
                double a = r.nextDouble() * Math.PI * 2.0;
                Vec3 from = caster.position().add(Math.cos(a) * radius, 0.06, Math.sin(a) * radius);
                Vec3 to = caster.position().add(Math.cos(a + 0.6) * radius * 0.7, 0.06, Math.sin(a + 0.6) * radius * 0.7);
                Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(from), Lightning.Anchor.fixed(to), AMBER, 0.05f, 3, 1, 1, 0.25));
            }
            if (t % 3 == 0) {
                double a = -t * 0.4;
                Vfx.glint(caster.getX() + Math.cos(a) * radius, caster.getY() + 0.1, caster.getZ() + Math.sin(a) * radius,
                        WHITE_HOT, 0.32f, 10);
            }
        });
    }

    private static void transform(AbstractClientPlayer caster, boolean self) {
        schedule(0, 1, (level, t) -> {
            sound(level, caster.position(), SoundEvents.LIGHTNING_BOLT_THUNDER, 0.8f, 0.42f);
            level.playLocalSound(caster.getX(), caster.getY(), caster.getZ(), SoundEvents.LIGHTNING_BOLT_THUNDER,
                    SoundSource.WEATHER, 0.5f, ShazamFx.slowPitch(level, 0.35f), false);
        });
        // 0-18: tenaga terkumpul: listrik membara dari tanah merambat ke kepalan, asap hitam terhisap
        schedule(0, ShazamAnim.TRANSFORM_STRIKE, (level, t) -> {
            RandomSource r = level.random;
            for (int k = 0; k < (t > ShazamAnim.TRANSFORM_WINDUP ? 2 : 1); k++) {
                double a = r.nextDouble() * Math.PI * 2.0, d = 1.4 + r.nextDouble() * 1.4;
                Vec3 from = caster.position().add(Math.cos(a) * d, 0.05, Math.sin(a) * d);
                Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(from), pt -> ShazamPoses.handPos(caster, true, pt),
                        AMBER, 0.095f, 3, 1, 1, 0.26));
            }
            if (t % 2 == 1) {
                double a = r.nextDouble() * Math.PI * 2.0, d = 2.0 + r.nextDouble() * 1.2;
                Vfx.smoke(caster.getX() + Math.cos(a) * d, caster.getY() + 0.2, caster.getZ() + Math.sin(a) * d,
                        -Math.cos(a) * 0.07, 0.035, -Math.sin(a) * 0.07, SMOKE, 0.5f, 22);
            }
            if (t == ShazamAnim.TRANSFORM_WINDUP - 2) {
                Vfx.add(new Fx.Glow(caster, pt -> ShazamPoses.handPos(caster, true, pt), 1.25f, AMBER_LIGHT,
                        ShazamAnim.BOLT_DESCENT + 4, ShazamAnim.BOLT_DESCENT + 2));
            }
            if (self && t % 2 == 0) {
                CameraShake.add(0.05f);
            }
            ShazamFx.swirlDust(level, caster, t);
        });
        // 8-18: petir turun pelan; kepalan memanggilnya dengan busur listrik membara ke atas
        schedule(ShazamAnim.TRANSFORM_WINDUP, ShazamAnim.BOLT_DESCENT, (level, t) -> {
            Vec3 fist = caster.position().add(0, ShazamPowers.FIST_HEIGHT * caster.getScale(), 0);
            double remaining = 88.0 * (1.0 - Math.pow((t + 1) / (double) ShazamAnim.BOLT_DESCENT, 1.35));
            if (remaining < 30.0) {
                for (int k = 0; k < 2; k++) {
                    Vec3 tip = fist.add((level.random.nextDouble() - 0.5) * 1.2, Math.min(remaining, 10.0) * (0.6 + 0.4 * k),
                            (level.random.nextDouble() - 0.5) * 1.2);
                    Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(fist), Lightning.Anchor.fixed(tip), AMBER_LIGHT, 0.085f, 2,
                            1, 1, 0.28));
                }
            }
            if (self) {
                ScreenFx.vignette(0.32f + t * 0.035f, 0x1E0800, 2);
            }
        });
        // 18: petir membara mengenai kepalan: ledakan cahaya, kubah petir, cincin asap hitam, listrik membelit badan
        schedule(ShazamAnim.TRANSFORM_STRIKE, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vec3 fist = c.add(0, ShazamPowers.FIST_HEIGHT * caster.getScale(), 0);
            Vfx.add(new Fx.Flash(fist, 4.2f, WHITE_HOT, 13, 1f));
            Vfx.add(new Fx.Flash(c.add(0, 1.0, 0), 3.2f, AMBER, 15, 1f));
            Vfx.add(new Fx.Pillar(c, 70.0, 2.2f, AMBER, 18));
            dome(level, c.add(0, 1.0, 0), 3.6, 12);
            slam(level, caster, c, 2.8f, false);
            Ground.Map map = ShazamFx.ground(level, c, 4.5);
            if (map != null) {
                Vfx.add(new Fx.Wave(map.center(c), UP, 5.2, 1.5, SMOKE, 30, 0.6f, 0f, map, true));
            }
            ShazamFx.ringOfSparks(level, fist, 80, AMBER_LIGHT, 0.6);
            ShazamFx.groundArcs(level, c, 10, 5.4, AMBER, 8);
            surge(caster, 44, 2.6f, 0.07f);
            ShazamFx.shakeAround(c, 1.2f, 36);
            if (self) {
                ScreenFlash.flash(1.0f, 0xFFE8C8);
                FovKick.punch(-0.08f);
            }
        });
        // listrik membelit badan dari kaki ke kepala selagi kostum terbentuk
        schedule(ShazamAnim.TRANSFORM_STRIKE, 22, (level, t) -> wrap(caster, t, 22));
        schedule(ShazamAnim.TRANSFORM_STRIKE + 25, 1, (level, t) -> {
            Vec3 c = caster.position();
            Ground.Map map = ShazamFx.ground(level, c, 2.0);
            if (map != null) {
                Vfx.add(new Fx.Wave(map.center(c), UP, 2.4, 0.8, map.dustColor(level, c), 18, 0.45f, 0f, map, true));
            }
            ShazamFx.dustPuffs(level, c, SAND, 10, 1.0, 0.08);
        });
    }

    /** Satu langkah petir yang membelit badan (spiral dari kaki ke kepala dalam total tick). */
    private static void wrap(AbstractClientPlayer caster, int t, int total) {
        double h = caster.getBbHeight();
        for (int k = 0; k < 2; k++) {
            double u0 = Mth.clamp((t + k * 0.5) / (double) total, 0.0, 1.0), u1 = Mth.clamp(u0 + 0.12, 0.0, 1.0);
            double a0 = u0 * Math.PI * 6.0 + k * Math.PI, a1 = u1 * Math.PI * 6.0 + k * Math.PI;
            double r = 0.55 * caster.getScale();
            double x0 = Math.cos(a0) * r, z0 = Math.sin(a0) * r, x1 = Math.cos(a1) * r, z1 = Math.sin(a1) * r;
            Vfx.add(new Lightning.Arc(Lightning.Anchor.on(caster, x0, u0 * h, z0), Lightning.Anchor.on(caster, x1, u1 * h, z1),
                    AMBER_LIGHT, 0.07f, 3, 1, 0, 0.3));
        }
    }

    private static void revert(AbstractClientPlayer caster, boolean self) {
        schedule(0, ShazamAnim.REVERT_WINDUP, (level, t) -> {
            Vec3 chest = caster.position().add(0, 1.2 * caster.getScale(), 0);
            for (int i = 0, n = Vfx.count(5); i < n; i++) {
                Vec3 off = ShazamFx.randomDir(level.random).scale(1.4 + level.random.nextDouble() * 0.6);
                Vfx.mote(chest.x + off.x, chest.y + off.y, chest.z + off.z, -off.x * 0.16, -off.y * 0.16, -off.z * 0.16,
                        AMBER_LIGHT, 0.09f, 7);
            }
        });
        schedule(ShazamAnim.REVERT_WINDUP, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vec3 chest = c.add(0, 1.2, 0);
            Vfx.add(new Fx.Flash(chest, 2.2f, AMBER_LIGHT, 10, 1f));
            Vfx.add(new Fx.Bubble(chest, 1.9, AMBER, 9, 0.75f, 1.0, 2.0, true));
            Ground.Map map = ShazamFx.ground(level, c, 3.0);
            if (map != null) {
                Vfx.add(new Fx.Wave(map.center(c), UP, 3.4, 0.35, AMBER, 13, 0.75f, 0.1f, map));
                ShazamFx.dustPuffs(level, map.center(c), map.dustColor(level, c), 12, 0.8, 0.1);
            }
            ShazamFx.smokeCloud(level, c, SMOKE, 5, 0.9);
            ShazamFx.ringOfSparks(level, chest, 30, AMBER_LIGHT, 0.38);
            ShazamFx.groundArcs(level, c, 5, 2.6, AMBER, 5);   // sisa petir lepas ke tanah
            ShazamFx.shakeAround(c, 0.4f, 16);
            if (self) {
                ScreenFlash.flash(0.55f, 0xFFEAD0);
            }
        });
    }

    private static void knockout(AbstractClientPlayer caster, boolean self) {
        schedule(0, 1, (level, t) -> {
            Vec3 chest = caster.position().add(0, 1.2 * caster.getScale(), 0);
            Vfx.add(new Fx.Flash(chest, 1.7f, 0xFFC8B0, 6, 1f));
            ShazamFx.shakeAround(caster.position(), 0.6f, 20);
            if (self) {
                ScreenFx.vignette(0.7f, 0x3A0000, 14);
                CameraShake.add(0.45f);
            }
        });
        schedule(ShazamAnim.KNOCKOUT_BURST, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vec3 chest = c.add(0, 1.2 * caster.getScale(), 0);
            Vfx.add(new Fx.Flash(chest, 2.8f, AMBER_LIGHT, 11, 1f));
            Vfx.add(new Fx.Bubble(chest, 2.5, AMBER, 11, 0.8f, 1.0, 2.0, true));
            for (int k = 0; k < 5; k++) {   // petir membara lepas dari badan, kembali ke langit
                double a = Math.PI * 2.0 * (k + level.random.nextDouble() * 0.6) / 5.0;
                double r = 1.5 + level.random.nextDouble() * 2.0;
                Vec3 sky = c.add(Math.cos(a) * r, 8.0 + level.random.nextDouble() * 3.0, Math.sin(a) * r);
                Vfx.add(new Lightning.Arc(Lightning.Anchor.on(caster, 0, 1.2, 0), Lightning.Anchor.fixed(sky), AMBER,
                        0.09f, 5 + k, 1, 1, 0.3));
            }
            Ground.Map map = ShazamFx.ground(level, c, 3.5);
            if (map != null) {
                Vfx.add(new Fx.Wave(map.center(c), UP, 3.8, 0.35, AMBER, 14, 0.8f, 0.1f, map));
                Vfx.add(new Fx.Wave(map.center(c), UP, 3.0, 0.9, map.dustColor(level, c), 20, 0.5f, 0f, map, true));
                ShazamFx.dustPuffs(level, map.center(c), map.dustColor(level, c), 14, 0.8, 0.12);
            }
            ShazamFx.smokeCloud(level, c, SMOKE, 6, 1.0);
            ShazamFx.ringOfSparks(level, chest, 40, AMBER_LIGHT, 0.5);
            sound(level, c, SoundEvents.BEACON_DEACTIVATE, 1.2f, 0.5f);
            ShazamFx.shakeAround(c, 0.5f, 18);
            if (self) {
                ScreenFlash.flash(0.6f, 0xFFE0C0);
            }
        });
        schedule(ShazamAnim.KNOCKOUT_BURST + 1, 16, (level, t) -> {
            if (t % 2 != 0) {
                return;
            }
            Vec3 c = caster.position();
            for (int i = 0, n = Vfx.count(3); i < n; i++) {
                double a = level.random.nextDouble() * Math.PI * 2.0, r = 0.25 + level.random.nextDouble() * 0.3;
                Vfx.mote(c.x + Math.cos(a) * r, c.y + 0.3 + level.random.nextDouble() * 1.5, c.z + Math.sin(a) * r,
                        Math.cos(a) * 0.02, 0.05 + level.random.nextDouble() * 0.04, Math.sin(a) * 0.02, AMBER_LIGHT, 0.07f, 12);
            }
        });
    }

    // ------------------------------------------------------------------ terbang Black Adam

    /** Lepas landas: tanah retak membara di bawah kaki, listrik meledak dari badan. */
    private static void launch(AbstractClientPlayer caster) {
        schedule(0, 1, (level, t) -> {
            Vec3 c = caster.position();
            Ground.Map map = groundAt(level, c, 3.0);
            if (map != null && c.y - map.centerY < 1.5) {
                Vec3 g = map.center(c);
                Vfx.add(new Fx.Wave(g, UP, 3.6, 0.3, AMBER_LIGHT, 12, 0.85f, 0.1f, map));
                Vfx.add(new Fx.Wave(g, UP, 3.0, 1.0, map.dustColor(level, c), 22, 0.55f, 0f, map, true));
                Vfx.add(new Ground.Cracks(g, map, 7, 1.5f, 110, 28, AMBER, level.random.nextLong()));
                Vfx.add(new Ground.Debris(g, map, 9, 0.14, 0.42, 0.5, 42));
                Vfx.add(new Fx.Scorch(g, 0.8, 120, 24, map));
                ShazamFx.dustPuffs(level, g, map.dustColor(level, c), 16, 0.9, 0.14);
                ShazamFx.smokeCloud(level, g, map.dustColor(level, c), 4, 1.3);
                ShazamFx.groundArcs(level, c, 5, 2.4, AMBER, 5);
            }
            Vfx.add(new Fx.Ripple(c.add(0, 0.2, 0), UP, 3.0, 0.5, 1.9, 0.3, AMBER_LIGHT, 10, 0.75f, false));
            arcsOut(level, c.add(0, 1.0, 0), 4, 1.6, AMBER_LIGHT, 0.06f, 3);
            surge(caster, 12, 2.0f, 0.05f);
            ShazamFx.shakeAround(c, 0.4f, 16);
        });
    }

    /** Pendaratan Black Adam: hantaman berat, tanah retak lebar, petir merambat di tanah. */
    private static void landing(AbstractClientPlayer caster, boolean self) {
        schedule(0, 1, (level, t) -> {
            Vec3 c = caster.position();
            slam(level, caster, c, 2.3f, self);
            Vfx.add(new Fx.Flash(c.add(0, 0.6, 0), 2.8f, AMBER_LIGHT, 10, 0.9f));
            Vfx.add(new Fx.Bubble(c, 3.2, AMBER, 12, 0.7f, 0.5, 2.2, true));
            ShazamFx.shakeAround(c, 1.1f, 32);
            if (self) {
                FovKick.punch(-0.05f);
            }
        });
    }

    private static void crash(AbstractClientPlayer caster) {
        schedule(0, 1, (level, t) -> {
            Vec3 dir = caster.getViewVector(1f);
            Vec3 c = caster.position().add(0, 1.0, 0).add(dir.scale(0.8));
            Vfx.add(new Fx.Flash(c, 2.2f, AMBER_LIGHT, 9, 1f));
            Vfx.add(new Fx.Ripple(c, dir.scale(-1), 1.4, 0.4, 3.0, 0.4, WHITE_HOT, 11, 0.85f, false));
            for (int i = 0, n = Vfx.count(32); i < n; i++) {
                Vec3 v = ShazamFx.randomDir(level.random).add(dir.scale(-1.2)).normalize().scale(0.25 + level.random.nextDouble() * 0.4);
                Vfx.spark(c.x, c.y, c.z, v.x, v.y, v.z, i % 3 == 0 ? WHITE_HOT : AMBER_LIGHT, 0.065f, 10 + level.random.nextInt(8),
                        caster.getY());
            }
            arcsOut(level, c, 5, 2.0, AMBER_LIGHT, 0.07f, 3);
            Ground.Map map = ShazamFx.ground(level, caster.position(), 2.5);
            if (map != null) {
                Vfx.add(new Ground.Debris(map.center(caster.position()), map, 14, 0.22, 0.32, 0.6, 45));
                ShazamFx.dustPuffs(level, c, map.dustColor(level, c), 16, 1.0, 0.16);
                ShazamFx.smokeCloud(level, map.center(caster.position()), map.dustColor(level, c), 4, 0.8);
            }
            ShazamFx.shakeAround(c, 0.9f, 26);
        });
    }

    /** Sonic boom membara: kerucut uap, cincin api, dan petir yang memancar ke belakang. */
    private static void sonicBoom(AbstractClientPlayer caster, boolean self) {
        schedule(0, 1, (level, t) -> {
            Vec3 motion = new Vec3(caster.getX() - caster.xo, caster.getY() - caster.yo, caster.getZ() - caster.zo);
            Vec3 dir = motion.lengthSqr() < 1.0E-4 ? caster.getViewVector(1f) : motion.normalize();
            Vec3 c = caster.position().add(0, 0.9, 0);
            Vfx.add(new Fx.Flash(c, 2.6f, WHITE_HOT, 8, 0.95f));
            Vfx.add(new Fx.Cone(c.add(dir.scale(1.2)), dir.scale(-1), 5.5, 0.8, 0xF4E8D8, 13, 0.6f, 2.0, true));
            Vfx.add(new Fx.Ripple(c, dir.scale(-1), 3.0, 0.6, 4.8, 0.7, 0xF8F0E6, 15, 0.7f, true));
            Vfx.add(new Fx.Ripple(c, dir.scale(-1), 2.0, 0.4, 3.6, 0.3, AMBER_LIGHT, 11, 0.9f, false));
            Vfx.add(new Fx.Ripple(c, dir.scale(-1), 1.2, 0.3, 2.4, 0.18, EMBER_RED, 9, 0.8f, false));
            for (int k = 0; k < 5; k++) {   // petir memancar ke belakang
                Vec3 side = ShazamFx.randomDir(level.random).scale(1.6);
                Vec3 end = c.add(dir.scale(-3.5 - level.random.nextDouble() * 2.0)).add(side);
                Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(c), Lightning.Anchor.fixed(end), AMBER_LIGHT, 0.08f, 4, 1, 1,
                        0.3));
            }
            ShazamFx.shakeAround(caster.position(), 0.6f, 40);
            if (self) {
                ScreenFx.speedLines(1f);
                ScreenFlash.flash(0.2f, 0xFFF0E0);
            }
        });
    }

    /** Black Adam nggak berguling: melesat menyamping tegak, meninggalkan petir & bayangan membara. */
    private static void sidestep(AbstractClientPlayer caster, boolean right, boolean self) {
        schedule(0, 1, (level, t) -> {
            Vec3 c = caster.position().add(0, 1.0, 0);
            Vfx.add(new Fx.Flash(c, 1.4f, AMBER_LIGHT, 6, 0.8f));
            Vfx.add(new Fx.Trail(caster, pt -> caster.getPosition(pt).add(0, 1.0, 0), AMBER, 0.9f, 8, 7, true));
            arcsOut(level, c, 3, 1.4, AMBER_LIGHT, 0.06f, 3);
            if (self) {
                ScreenFx.speedLines(0.4f);
            }
        });
    }

    // ------------------------------------------------------------------ S - Badai Shu

    private static void shu(AbstractClientPlayer caster, boolean self) {
        // napas dewa udara terkumpul: debu & angin terhisap ke badan, listrik kecil dari tanah ke tangan
        schedule(0, ShazamAnim.CAST_WINDUP, (level, t) -> {
            Vec3 chest = caster.position().add(0, 1.1, 0);
            for (int i = 0, n = Vfx.count(8); i < n; i++) {
                Vec3 off = ShazamFx.randomDir(level.random).scale(2.4 + level.random.nextDouble() * 1.2);
                Vfx.dust(chest.x + off.x, chest.y + off.y * 0.5, chest.z + off.z, -off.x * 0.17, -off.y * 0.06, -off.z * 0.17,
                        i % 2 == 0 ? SAND : SAND_DARK, 0.4f, 7);
            }
            boolean right = t % 2 == 0;
            double a = level.random.nextDouble() * Math.PI * 2.0;
            Vec3 from = caster.position().add(Math.cos(a) * 1.8, 0.05, Math.sin(a) * 1.8);
            Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(from), pt -> ShazamPoses.handPos(caster, right, pt), AMBER_LIGHT,
                    0.06f, 2, 1, 0, 0.3));
        });
        schedule(ShazamAnim.CAST_WINDUP, 1, (level, t) -> {
            Vortex vortex = new Vortex(caster, ShazamAnim.SHU_TICKS);
            Vfx.add(vortex);
            BlockState below = level.getBlockState(caster.blockPosition().below());
            Vfx.add(new Ground.Orbit(caster, below.isAir() ? Blocks.SANDSTONE.defaultBlockState() : below, 12,
                    ShazamAnim.SHU_TICKS + 12, () -> vortex.strength(1f)));
            Vec3 c = caster.position();
            Ground.Map map = ShazamFx.ground(level, c, 4.0);
            Vfx.add(new Fx.Wave(c.add(0, 0.05, 0), UP, 4.2, 0.5, 0xF2EEE6, 13, 0.8f, 0.05f, map));
            Vfx.add(new Fx.Wave(c.add(0, 0.1, 0), UP, 3.6, 1.4, SAND, 22, 0.55f, 0f, map, true));
            Vfx.add(new Fx.Flash(c.add(0, 1.2, 0), 2.0f, 0xFFF2DC, 9, 0.8f));
            ShazamFx.dustPuffs(level, c, SAND, 18, 1.4, 0.2);
            if (self) {
                ScreenFx.speedLines(0.5f);
            }
        });
        // tiap tick: pasir & angin berputar mengelilingi, makin tinggi; petir menyambar di dalam badai
        schedule(ShazamAnim.CAST_WINDUP, ShazamAnim.SHU_TICKS, (level, t) -> {
            if (!ShazamClientState.isTransformed(caster.getId())) {
                return;
            }
            RandomSource r = level.random;
            Vec3 c = caster.position();
            for (int i = 0, n = Vfx.count(9); i < n; i++) {
                double a = r.nextDouble() * Math.PI * 2.0, y = r.nextDouble() * 6.0, rr = 1.8 + y * 0.4 + r.nextDouble() * 1.2;
                double tx = -Math.sin(a), tz = Math.cos(a);
                Vfx.dust(c.x + Math.cos(a) * rr, c.y + 0.1 + y, c.z + Math.sin(a) * rr,
                        tx * 0.5 - Math.cos(a) * 0.05, 0.04 + r.nextDouble() * 0.05, tz * 0.5 - Math.sin(a) * 0.05,
                        r.nextInt(3) == 0 ? SAND_DARK : SAND, 0.55f + r.nextFloat() * 0.55f, 12 + r.nextInt(8));
            }
            if (t % 2 == 0) {   // percikan angin bercahaya
                double a = r.nextDouble() * Math.PI * 2.0, rr = 1.6 + r.nextDouble() * 1.6;
                Vfx.spark(c.x + Math.cos(a) * rr, c.y + 0.4 + r.nextDouble() * 4.0, c.z + Math.sin(a) * rr,
                        -Math.sin(a) * 0.5, 0.06, Math.cos(a) * 0.5, 0xFFF6E8, 0.055f, 9, Double.NaN);
            }
            if (t % 3 == 1) {   // petir menyambar di dalam badai pasir
                double a0 = r.nextDouble() * Math.PI * 2.0, a1 = a0 + 0.8 + r.nextDouble() * 1.4;
                double y0 = 0.6 + r.nextDouble() * 4.5, y1 = y0 + (r.nextDouble() - 0.4) * 2.5;
                double r0 = 1.8 + y0 * 0.38, r1 = 1.8 + y1 * 0.38;
                Vfx.add(new Lightning.Arc(Lightning.Anchor.on(caster, Math.cos(a0) * r0, y0, Math.sin(a0) * r0),
                        Lightning.Anchor.on(caster, Math.cos(a1) * r1, y1, Math.sin(a1) * r1), AMBER_LIGHT, 0.085f, 3, 1, 1, 0.3));
            }
            if (self && t % 4 == 0) {
                CameraShake.add(0.04f);
            }
        });
        // akhir: badai meledak ke luar
        schedule(ShazamAnim.CAST_WINDUP + ShazamAnim.SHU_TICKS, 1, (level, t) -> {
            if (!ShazamClientState.isTransformed(caster.getId())) {
                return;
            }
            Vec3 c = caster.position();
            Ground.Map map = ShazamFx.ground(level, c, 6.0);
            Vfx.add(new Fx.Flash(c.add(0, 1.4, 0), 3.8f, 0xFFF4E2, 11, 1f));
            Vfx.add(new Fx.Wave(c.add(0, 0.05, 0), UP, 12.0, 0.7, 0xFFF4E8, 16, 0.9f, 0.04f, map));
            Vfx.add(new Fx.Wave(c.add(0, 0.05, 0), UP, 9.0, 0.35, AMBER_LIGHT, 12, 0.9f, 0f, map));
            Vfx.add(new Fx.Wave(c.add(0, 0.1, 0), UP, 10.0, 2.6, SAND, 36, 0.7f, 0f, map, true));
            Vfx.add(new Fx.Bubble(c.add(0, 0.2, 0), 6.0, 0xFFE0B0, 12, 0.55f, 0.6, 2.2, true));
            Vfx.add(new Fx.Ripple(c.add(0, 1.0, 0), UP, 0.1, 1.5, 11.0, 0.6, 0xFFF6EC, 13, 0.6f, false));
            ShazamFx.groundArcs(level, c, 12, 7.0, AMBER, 7);
            arcsOut(level, c.add(0, 2.0, 0), 6, 4.5, AMBER_LIGHT, 0.09f, 4);
            if (map != null && map.found) {
                Vfx.add(new Ground.Debris(map.center(c), map, 18, 0.32, 0.4, 1.4, 50));
            }
            ShazamFx.dustPuffs(level, c, SAND, 44, 3.6, 0.42);
            ShazamFx.smokeCloud(level, c, 0xB89C6A, 12, 4.0);
            sound(level, c, SoundEvents.LIGHTNING_BOLT_IMPACT, 1.4f, 0.7f);
            ShazamFx.shakeAround(c, 1.0f, 30);
            if (self) {
                ScreenFx.speedLines(1f);
                ScreenFlash.flash(0.35f, 0xFFF0D8);
                FovKick.punch(-0.08f);
            }
        });
    }

    /** Badai pasir Shu yang mengikuti pemain: dinding pasir tebal berpilin + garis angin bercahaya, setinggi 7 blok. */
    static final class Vortex extends Effect {
        private final AbstractClientPlayer owner;
        private final int active;
        private float fade, fadeO;
        private boolean ending;

        Vortex(AbstractClientPlayer owner, int active) {
            super(active + 16);
            this.owner = owner;
            this.active = active;
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (!owner.isAlive() || !ShazamClientState.isTransformed(owner.getId())) {
                ending = true;
            }
            fadeO = fade;
            boolean on = !ending && age < active;
            fade = Mth.approach(fade, on ? 1f : 0f, on ? 0.18f : 0.12f);
            return super.tick(level) && !(ending && fade <= 0f);
        }

        float strength(float pt) {
            return Mth.lerp(pt, fadeO, fade);
        }

        private void bands(Draw d, int layer) {
            float f = strength(d.partialTick);
            if (f <= 0.01f) {
                return;
            }
            Vec3 c = owner.getPosition(d.partialTick);
            float time = time(d.partialTick);
            int n = 30;
            float[] pts = new float[n * 3], w = new float[n], a = new float[n];
            int bands = layer == 0 ? 11 : layer == 1 ? 6 : 7;
            for (int b = 0; b < bands; b++) {
                double phase = b * Math.PI * 2.0 / bands + layer * 0.37;
                double spin = time * (layer == 0 ? 0.3 : layer == 1 ? 0.22 : 0.46);
                for (int i = 0; i < n; i++) {
                    double u = i / (double) (n - 1);
                    double ang = spin + phase + u * Math.PI * (layer == 2 ? 3.0 : 2.4);
                    double rad = (layer == 1 ? 0.7 + 1.2 * u : 1.1 + 2.9 * Math.pow(u, 0.8)) * (0.55 + 0.45 * f);
                    double y = 0.05 + u * (layer == 1 ? 5.0 : 6.8);
                    pts[i * 3] = (float) (c.x + Math.cos(ang) * rad);
                    pts[i * 3 + 1] = (float) (c.y + y);
                    pts[i * 3 + 2] = (float) (c.z + Math.sin(ang) * rad);
                    float env = (float) Math.sin(Math.PI * Math.min(1.0, u * 1.08));
                    float near = d.nearFade(pts[i * 3], pts[i * 3 + 1], pts[i * 3 + 2], 0.9, 2.8);
                    w[i] = layer == 0 ? (float) (1.4 + 2.0 * u) : layer == 1 ? (float) (1.0 + 1.0 * u) : (float) (0.14 + 0.1 * u);
                    a[i] = env * f * near * (layer == 0 ? 0.62f : layer == 1 ? 0.5f : 0.3f);
                }
                if (layer == 0) {
                    d.strip(pts, n, w, 1f, a, 1f, b % 3 == 0 ? SAND_DARK : b % 3 == 1 ? SAND : 0xC9AE7A);
                } else if (layer == 1) {
                    d.strip(pts, n, w, 1f, a, 1f, 0x6E5638);   // inti debu gelap: badai terasa bervolume
                } else {
                    d.strip(pts, n, w, 1f, a, 1f, b % 3 == 0 ? GOLD_HOT : 0xFFF2DE);   // angin hangat berkilau
                }
            }
        }

        @Override
        public void renderSoft(Draw d) {
            bands(d, 1);
            bands(d, 0);
        }

        @Override
        public void renderGlow(Draw d) {
            bands(d, 2);
        }
    }

    // ------------------------------------------------------------------ H - Sambaran Heru

    private static void heru(AbstractClientPlayer caster, Vec3 end, boolean self) {
        Vec3 start = caster.position();
        // merunduk: cahaya terkumpul di bahu (pangkal sayap), listrik menyambar di punggung
        schedule(0, ShazamAnim.HERU_WINDUP, (level, t) -> {
            Vec3 chest = caster.position().add(0, 1.2, 0);
            for (int i = 0, n = Vfx.count(6); i < n; i++) {
                Vec3 off = ShazamFx.randomDir(level.random).scale(1.6 + level.random.nextDouble() * 0.6);
                Vfx.mote(chest.x + off.x, chest.y + off.y * 0.6, chest.z + off.z, -off.x * 0.27, -off.y * 0.16, -off.z * 0.27,
                        AMBER_LIGHT, 0.09f, 5);
            }
            arcsOut(level, chest, 2, 1.2, AMBER_LIGHT, 0.06f, 2);
            ShazamFx.swirlDust(level, caster, t * 2);
        });
        schedule(ShazamAnim.HERU_WINDUP, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vec3 dir = end.subtract(start);
            dir = dir.lengthSqr() < 1.0E-4 ? caster.getViewVector(1f) : dir.normalize();
            Vfx.add(new FalconWings(caster, dir, ShazamAnim.HERU_TICKS + 8));
            Vfx.add(new Fx.Trail(caster, pt -> caster.getPosition(pt).add(0, 1.0, 0), AMBER, 1.6f, 10, ShazamAnim.HERU_TICKS + 2,
                    true));
            Vfx.add(new PathBolt(start.add(0, 1.0, 0), end.add(0, 1.0, 0), ShazamAnim.HERU_TICKS, 22));
            Vfx.add(new Fx.Flash(c.add(0, 1.0, 0), 2.6f, GOLD_HOT, 8, 1f));
            Vfx.add(new Fx.Cone(c.add(0, 1.0, 0).add(dir.scale(0.6)), dir.scale(-1), 4.0, 0.7, 0xF6EAD8, 12, 0.55f, 2.0, true));
            Vfx.add(new Fx.Ripple(c.add(0, 1.0, 0), dir.scale(-1), 1.8, 0.4, 3.2, 0.45, AMBER_LIGHT, 11, 0.85f, false));
            Vfx.add(new Fx.Ripple(c.add(0, 1.0, 0), dir.scale(-1), 2.6, 0.6, 3.8, 0.7, 0xF8F0E6, 14, 0.6f, true));
            Ground.Map map = groundAt(level, c, 2.5);
            if (map != null && c.y - map.centerY < 1.5) {
                Vec3 g = map.center(c);
                Vfx.add(new Fx.Wave(g, UP, 2.8, 0.9, map.dustColor(level, c), 18, 0.55f, 0f, map, true));
                Vfx.add(new Ground.Cracks(g, map, 5, 1.2f, 90, 20, AMBER, level.random.nextLong()));
                Vfx.add(new Ground.Debris(g, map, 7, 0.16, 0.3, 0.4, 36));
                ShazamFx.dustPuffs(level, g, map.dustColor(level, c), 14, 0.8, 0.2);
            }
            ShazamFx.shakeAround(c, 0.4f, 18);
            if (self) {
                ScreenFx.speedLines(1f);
                FovKick.punch(0.14f);
            }
        });
        // di lintasan: bulu cahaya & percikan berhamburan
        schedule(ShazamAnim.HERU_WINDUP, ShazamAnim.HERU_TICKS, (level, t) -> {
            Vec3 c = caster.position().add(0, 1.0, 0);
            for (int i = 0, n = Vfx.count(6); i < n; i++) {
                Vfx.mote(c.x + (level.random.nextDouble() - 0.5) * 1.4, c.y + (level.random.nextDouble() - 0.5) * 1.4,
                        c.z + (level.random.nextDouble() - 0.5) * 1.4, 0, -0.01, 0, i % 2 == 0 ? GOLD_HOT : AMBER, 0.12f,
                        18 + level.random.nextInt(8));
            }
            for (int i = 0, n = Vfx.count(3); i < n; i++) {
                Vec3 v = ShazamFx.randomDir(level.random).scale(0.2);
                Vfx.spark(c.x, c.y, c.z, v.x, v.y, v.z, AMBER_LIGHT, 0.05f, 8, caster.getY() - 1.0);
            }
        });
        // sampai: hempasan di titik akhir, musuh di lintasan tersambar
        schedule(ShazamAnim.HERU_WINDUP + ShazamAnim.HERU_TICKS, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vfx.add(new Fx.Flash(c.add(0, 1.0, 0), 2.4f, AMBER_LIGHT, 9, 0.95f));
            Vfx.add(new Fx.Bubble(c.add(0, 0.8, 0), 2.4, AMBER, 9, 0.7f, 1.0, 2.0, true));
            Ground.Map map = groundAt(level, c, 3.5);
            if (map != null && c.y - map.centerY < 1.5) {
                slam(level, caster, c, 1.3f, false);
            } else {
                Vfx.add(new Fx.Wave(c.add(0, 1.0, 0), dirOf(start, end), 3.4, 0.35, AMBER, 12, 0.85f, 0.06f, null));
            }
            ShazamFx.ringOfSparks(level, c.add(0, 1.0, 0), 28, AMBER_LIGHT, 0.45);
            for (LivingEntity e : near(level, start, end, 2.4)) {   // yang tertabrak di lintasan
                Vec3 p = e.position().add(0, e.getBbHeight() * 0.6, 0);
                Vfx.add(new Fx.Flash(p, 1.4f, AMBER_LIGHT, 7, 0.9f));
                ShazamFx.ringOfSparks(level, p, 12, AMBER_LIGHT, 0.35);
                arcsOut(level, p, 2, 1.2, AMBER_LIGHT, 0.06f, 3);
            }
            ShazamFx.shakeAround(c, 0.55f, 22);
        });
    }

    private static Vec3 dirOf(Vec3 a, Vec3 b) {
        Vec3 d = b.subtract(a);
        return d.lengthSqr() < 1.0E-4 ? UP : d.normalize();
    }

    /** Makhluk (bukan pemain) di dekat garis a-b. */
    private static List<LivingEntity> near(ClientLevel level, Vec3 a, Vec3 b, double radius) {
        AABB box = new AABB(a, b).inflate(radius + 1.0);
        return level.getEntitiesOfClass(LivingEntity.class, box, e -> {
            if (!e.isAlive() || e instanceof AbstractClientPlayer) {
                return false;
            }
            Vec3 p = e.position().add(0, e.getBbHeight() * 0.5, 0);
            Vec3 ab = b.subtract(a);
            double len2 = ab.lengthSqr();
            double u = len2 < 1.0E-6 ? 0.0 : Mth.clamp(p.subtract(a).dot(ab) / len2, 0.0, 1.0);
            return p.distanceTo(a.add(ab.scale(u))) <= radius + e.getBbWidth() * 0.5;
        });
    }

    /** Sayap elang dari cahaya di punggung selama Sambaran Heru: bulu-bulu tebal menyapu ke belakang, tepinya berlistrik. */
    static final class FalconWings extends Effect {
        private final AbstractClientPlayer owner;
        private final Vec3 dir;
        private final long seed = Vfx.random().nextLong();

        FalconWings(AbstractClientPlayer owner, Vec3 dir, int life) {
            super(life);
            this.owner = owner;
            this.dir = dir;
        }

        @Override
        public void renderGlow(Draw d) {
            float p = progress(d.partialTick);
            float open = Math.min(1f, time(d.partialTick) / 2f);
            float a = (1f - p * p) * open;
            if (a <= 0.01f) {
                return;
            }
            Vec3 c = owner.getPosition(d.partialTick).add(0, 1.35 * owner.getScale(), 0);
            Vec3 f = dir;
            Vec3 right = new Vec3(-f.z, 0, f.x);
            right = right.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : right.normalize();
            Vec3 up = right.cross(f).normalize();
            if (up.y < 0) {
                up = up.scale(-1);
            }
            Random random = new Random(seed + age / 2);
            for (int side = -1; side <= 1; side += 2) {
                Vec3 root = c.add(right.scale(side * 0.25));
                float[] edge = new float[12 * 3];
                for (int k = 0; k < 12; k++) {
                    double u = k / 11.0;
                    double spread = Math.toRadians(6 + 80 * u);
                    double len = (1.3 + 2.0 * Math.sin(Math.PI * (0.22 + 0.62 * u))) * owner.getScale();
                    Vec3 dd = f.scale(-Math.cos(spread)).add(right.scale(side * Math.sin(spread))).add(up.scale(0.3 - 0.36 * u))
                            .normalize();
                    Vec3 tip = root.add(dd.scale(len));
                    float near = d.nearFade(tip.x, tip.y, tip.z, 0.8, 2.6);
                    d.beam(root.x, root.y, root.z, tip.x, tip.y, tip.z, 0.26f, k % 3 == 0 ? GOLD_HOT : AMBER_LIGHT,
                            WHITE_HOT, 0.8f * a * near, 0.08f * a * near);
                    edge[k * 3] = (float) tip.x;
                    edge[k * 3 + 1] = (float) tip.y;
                    edge[k * 3 + 2] = (float) tip.z;
                }
                // tepi sayap berlistrik: busur bergerigi menyambung ujung-ujung bulu
                for (int k = 0; k + 1 < 12; k += 2) {
                    float[] arc = Lightning.path(edge[k * 3], edge[k * 3 + 1], edge[k * 3 + 2], edge[k * 3 + 3], edge[k * 3 + 4],
                            edge[k * 3 + 5], 3, 0.35, random);
                    d.polyline(arc, arc.length / 3, 0.07f, 0.05f, AMBER_LIGHT, 0xFFFFFF, 0.8f * a, 0.8f * a);
                }
                d.glow(root.x, root.y, root.z, 0.7f, AMBER, 0.45f * a);
            }
        }
    }

    /** Petir yang tertinggal di lintasan terjangan Heru: menyambar dari titik awal ke titik akhir, lalu padam. */
    static final class PathBolt extends Effect {
        private final Vec3 a, b;
        private final int grow;
        private final long seed = Vfx.random().nextLong();

        PathBolt(Vec3 a, Vec3 b, int grow, int life) {
            super(life);
            this.a = a;
            this.b = b;
            this.grow = Math.max(1, grow);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            float shown = Math.min(1f, time / grow);
            float p = progress(d.partialTick);
            float alpha = (float) Math.pow(1f - p, 1.3) * (age % 3 == 1 ? 0.7f : 1f);
            if (alpha <= 0.01f || a.distanceToSqr(b) < 0.25) {
                return;
            }
            Vec3 e = a.lerp(b, shown);
            Random random = new Random(seed + age / 2);
            for (int k = 0; k < 2; k++) {
                float[] path = Lightning.path(a.x, a.y - 0.2 * k, a.z, e.x, e.y + 0.15 * k, e.z, 5, 0.09, random);
                int n = path.length / 3;
                d.polyline(path, n, k == 0 ? 0.26f : 0.13f, k == 0 ? 0.18f : 0.08f, AMBER, 0xFFFFFF, alpha, alpha);
                if (k == 0) {
                    float old = d.body(0.3f);
                    d.strip(path, n, 1.0f, 0.7f, AMBER, alpha * 0.2f, alpha * 0.18f);
                    d.body(old);
                }
            }
        }
    }

    // ------------------------------------------------------------------ A - Tinju Amon

    private static void amon(AbstractClientPlayer caster, Vec3 end, boolean self) {
        Vec3 origin0 = caster.position();
        schedule(0, 1, (level, t) -> {
            for (boolean right : new boolean[] {true, false}) {
                Vfx.add(new Fx.Glow(caster, pt -> ShazamPoses.handPos(caster, right, pt), 1.0f, AMBER,
                        ShazamAnim.AMON_WINDUP + 4, ShazamAnim.AMON_WINDUP));
            }
        });
        // kepalan berlistrik: busur-busur kecil melingkari kedua kepalan
        schedule(0, ShazamAnim.AMON_WINDUP, (level, t) -> {
            ShazamFx.swirlDust(level, caster, t);
            for (boolean right : new boolean[] {true, false}) {
                Vec3 off = ShazamFx.randomDir(level.random).scale(0.5);
                Vfx.add(new Lightning.Arc(pt -> ShazamPoses.handPos(caster, right, pt),
                        pt -> ShazamPoses.handPos(caster, right, pt).add(off), AMBER_LIGHT, 0.06f, 2, 1, 0, 0.35));
            }
        });
        schedule(ShazamAnim.AMON_WINDUP, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vec3 origin = new Vec3(c.x, Math.min(c.y, origin0.y + 0.5), c.z);
            slam(level, caster, origin, 3.0f, false);
            Vfx.add(new Fx.Flash(origin.add(0, 0.8, 0), 3.4f, WHITE_HOT, 10, 1f));
            Vfx.add(new Fx.Bubble(origin, 5.2, AMBER, 14, 0.9f, 0.5, 2.0, true));
            Vfx.add(new Fx.Bubble(origin, 3.4, GOLD_HOT, 10, 0.6f, 0.5, 2.6, true));
            ShazamFx.groundArcs(level, origin, 10, 6.0, AMBER, 7);
            ShazamFx.ringOfSparks(level, origin.add(0, 0.3, 0), 60, AMBER_LIGHT, 0.55);
            Vec3 flat = new Vec3(end.x - origin.x, 0, end.z - origin.z);
            double range = flat.length();
            if (range > 0.5) {
                Vfx.add(new Fissure(level, caster, origin, flat.scale(1.0 / range), range, ShazamAnim.AMON_SPREAD, 90));
            }
            sound(level, origin, SoundEvents.DEEPSLATE_BREAK, 1.5f, 0.5f);
            ShazamFx.shakeAround(c, 1.3f, 34);
            if (self) {
                ScreenFlash.flash(0.45f, 0xFFD8A0);
                ScreenFx.vignette(0.5f, 0x2A1000, 7);
                ScreenFx.speedLines(0.6f);
                FovKick.punch(-0.09f);
            }
        });
        // tanah terbelah merambat: tiap tick batu mencuat, debu & bara menyembur, petir melompat di celahnya
        schedule(ShazamAnim.AMON_WINDUP + 1, ShazamAnim.AMON_SPREAD, (level, t) -> {
            Vec3 o = origin0;
            Vec3 flat = new Vec3(end.x - o.x, 0, end.z - o.z);
            double range = flat.length();
            if (range < 0.5) {
                return;
            }
            Vec3 dir = flat.scale(1.0 / range);
            Vec3 front = o.add(dir.scale(range * (t + 1) / ShazamAnim.AMON_SPREAD));
            Ground.Map map = groundAt(level, front.add(0, 1.0, 0), 2.2);
            if (map == null) {
                return;
            }
            Vec3 g = map.center(front);
            Vfx.add(new Ground.Cracks(g, map, 6, 1.4f, 130, 45, AMBER_LIGHT, level.random.nextLong()));
            Vfx.add(new Ground.Debris(g, map, Vfx.count(7), 0.12, 0.7, 0.7, 48));
            Vfx.add(new Fx.Flash(g.add(0, 0.5, 0), 1.7f, AMBER, 7, 0.9f));
            Vfx.add(new Fx.Wave(g, UP, 2.2, 0.3, AMBER_LIGHT, 9, 0.75f, 0f, map));
            Vfx.add(new Fx.Scorch(g, 0.9, 130, 34, map));
            BlockState rock = map.surface.getRenderShape() == RenderShape.MODEL ? map.surface : Blocks.STONE.defaultBlockState();
            double side = (t % 2 == 0 ? 1 : -1) * (0.9 + level.random.nextDouble() * 0.5);
            Vec3 spikeAt = g.add(-dir.z * side, 0, dir.x * side);
            float yaw = (float) Math.atan2(dir.x, dir.z);
            Vfx.add(new RockSpike(rock, spikeAt, yaw, (float) side * 0.32f, 1.3f + level.random.nextFloat() * 1.1f,
                    0.55f + level.random.nextFloat() * 0.25f, 60 - t * 3));
            for (int i = 0, n = Vfx.count(6); i < n; i++) {   // debu menyembur ke atas seperti geiser
                Vfx.dust(g.x + (level.random.nextDouble() - 0.5) * 0.8, g.y + 0.1, g.z + (level.random.nextDouble() - 0.5) * 0.8,
                        (level.random.nextDouble() - 0.5) * 0.05, 0.12 + level.random.nextDouble() * 0.1,
                        (level.random.nextDouble() - 0.5) * 0.05, map.dustColor(level, g), 0.6f, 26);
            }
            for (int i = 0, n = Vfx.count(5); i < n; i++) {
                Vfx.ember(g.x + (level.random.nextDouble() - 0.5), g.y + 0.1, g.z + (level.random.nextDouble() - 0.5), 0,
                        0.07 + level.random.nextDouble() * 0.07, 0, 0.1f, 18 + level.random.nextInt(10));
            }
            Vec3 back = g.subtract(dir.scale(1.6));
            Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(back.add(0, 0.1, 0)), Lightning.Anchor.fixed(g.add(0, 0.1, 0)),
                    AMBER_LIGHT, 0.08f, 3, 1, 1, 0.3));
            ShazamFx.shakeAround(g, 0.45f, 20);
        });
    }

    /** Celah membara Amon: garis berkelok di tanah dari titik hantaman, merambat sampai ujung, petir melompat di dalamnya. */
    static final class Fissure extends Effect {
        private final float[] pts;
        private final int n;
        private final int spread;
        private final Random random = new Random(Vfx.random().nextLong());

        Fissure(ClientLevel level, Entity viewer, Vec3 origin, Vec3 dir, double range, int spread, int life) {
            super(life);
            this.spread = spread;
            this.n = Math.max(4, (int) (range * 2.0));
            this.pts = new float[n * 3];
            double nx = -dir.z, nz = dir.x;
            Random r = new Random(Double.doubleToLongBits(origin.x * 31 + origin.z));
            double side = 0;
            double lastY = origin.y;
            for (int i = 0; i < n; i++) {
                double u = i / (double) (n - 1);
                side = Mth.clamp(side + (r.nextDouble() - 0.5) * 0.4, -0.5, 0.5);
                double x = origin.x + dir.x * range * u + nx * side * Math.min(1.0, u * 6);
                double z = origin.z + dir.z * range * u + nz * side * Math.min(1.0, u * 6);
                BlockHitResult hit = level.clip(new ClipContext(new Vec3(x, lastY + 2.0, z), new Vec3(x, lastY - 3.0, z),
                        ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, viewer));
                double y = hit.getType() == HitResult.Type.MISS ? lastY : hit.getLocation().y;
                lastY = y;
                pts[i * 3] = (float) x;
                pts[i * 3 + 1] = (float) (y + 0.035);
                pts[i * 3 + 2] = (float) z;
            }
        }

        private int shown(float pt) {
            float k = Math.min(1f, time(pt) / spread);
            return Math.max(2, Math.min(n, (int) Math.ceil(k * (n - 1)) + 1));
        }

        @Override
        public boolean tick(ClientLevel level) {
            int m = shown(0f);
            if (age < spread + 40 && age % 2 == 0 && m > 3) {   // petir melompat-lompat di sepanjang celah
                int i = random.nextInt(m - 2);
                Vec3 from = new Vec3(pts[i * 3], pts[i * 3 + 1] + 0.08, pts[i * 3 + 2]);
                int j = Math.min(m - 1, i + 2 + random.nextInt(3));
                Vec3 to = new Vec3(pts[j * 3], pts[j * 3 + 1] + 0.08, pts[j * 3 + 2]);
                Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(from), Lightning.Anchor.fixed(to), AMBER_LIGHT, 0.065f, 3, 1,
                        1, 0.3));
            }
            if (age < spread + 50 && age % 3 == 0) {   // asap tipis & bara dari celah
                int i = random.nextInt(m);
                Vfx.ember(pts[i * 3] + (random.nextDouble() - 0.5) * 0.3, pts[i * 3 + 1] + 0.05, pts[i * 3 + 2]
                        + (random.nextDouble() - 0.5) * 0.3, 0, 0.05 + random.nextDouble() * 0.04, 0, 0.08f, 20);
            }
            return super.tick(level);
        }

        @Override
        public void renderSoft(Draw d) {
            float f = 1f - progress(d.partialTick);
            int m = shown(d.partialTick);
            for (int i = 0; i + 1 < m; i++) {   // bekas hangus gelap lebar di kiri-kanan celah
                int o = i * 3;
                d.flatLine(pts[o], pts[o + 1], pts[o + 2], pts[o + 3], pts[o + 4], pts[o + 5], 0, 1, 0, 1.5f, 0x140E0A,
                        0.6f * Math.min(1f, f * 2f), 0.6f * Math.min(1f, f * 2f));
            }
        }

        @Override
        public void renderGlow(Draw d) {
            float p = progress(d.partialTick);
            float heat = (float) Math.pow(1f - p, 1.2);
            int m = shown(d.partialTick);
            float pulse = 0.85f + 0.15f * (float) Math.sin(time(d.partialTick) * 0.7f);
            for (int i = 0; i + 1 < m; i++) {
                int o = i * 3;
                float edge = i >= m - 3 ? 1.7f : 1f;   // ujung yang sedang merambat paling terang
                d.flatLine(pts[o], pts[o + 1], pts[o + 2], pts[o + 3], pts[o + 4], pts[o + 5], 0, 1, 0, 0.75f, EMBER_RED,
                        0.7f * heat * pulse * edge, 0.7f * heat * pulse * edge);
                d.flatLine(pts[o], pts[o + 1] + 0.004f, pts[o + 2], pts[o + 3], pts[o + 4] + 0.004f, pts[o + 5], 0, 1, 0, 0.38f,
                        AMBER, 0.9f * heat * pulse * edge, 0.9f * heat * pulse * edge);
                d.flatLine(pts[o], pts[o + 1] + 0.008f, pts[o + 2], pts[o + 3], pts[o + 4] + 0.008f, pts[o + 5], 0, 1, 0, 0.12f,
                        GOLD_HOT, heat * edge, heat * edge);
            }
            int tip = (m - 1) * 3;
            d.flare(pts[tip], pts[tip + 1] + 0.35, pts[tip + 2], 1.4f, AMBER, 0.55f * heat);
        }
    }

    /**
     * Tiang batu yang mencuat dari tanah di sepanjang celah Amon (tekstur blok tanahnya sendiri): melesat naik miring
     * ke luar, bergetar sebentar, lalu tenggelam lagi.
     */
    static final class RockSpike extends Effect {
        private final BlockState state;
        private final double x, y, z;
        private final float yaw, lean, height, width;

        RockSpike(BlockState state, Vec3 base, float yaw, float lean, float height, float width, int life) {
            super(Math.max(20, life));
            this.state = state;
            this.x = base.x;
            this.y = base.y;
            this.z = base.z;
            this.yaw = yaw;
            this.lean = lean;
            this.height = height;
            this.width = width;
        }

        @Override
        public void renderSolid(PoseStack poseStack, MultiBufferSource buffers, double camX, double camY, double camZ,
                                float partialTick) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.level == null) {
                return;
            }
            float t = age + partialTick;
            float rise = t < 3f ? (float) GodFigures.outBack(t / 3f) : 1f;
            float sink = Math.min(1f, (life - t) / 10f);
            float k = Math.max(0f, Math.min(rise, sink));
            if (k <= 0.01f) {
                return;
            }
            float shake = t < 8f ? (float) Math.sin(t * 3.1f) * 0.04f * (1f - t / 8f) : 0f;
            int light = LevelRenderer.getLightColor(mc.level, BlockPos.containing(x, y + 0.5, z));
            poseStack.pushPose();
            poseStack.translate(x - camX + shake, y - camY - 0.35, z - camZ);
            poseStack.mulPose(new Quaternionf().rotationY(yaw));
            poseStack.mulPose(new Quaternionf().rotationZ(lean));
            float h = height * k;
            // tiga balok bertumpuk yang makin kecil: tiang meruncing
            float[][] seg = {{width, h * 0.55f, 0f}, {width * 0.72f, h * 0.35f, h * 0.5f}, {width * 0.42f, h * 0.3f, h * 0.8f}};
            for (int i = 0; i < seg.length; i++) {
                float w = seg[i][0], sh = seg[i][1], base = seg[i][2];
                if (sh <= 0.005f) {
                    continue;
                }
                poseStack.pushPose();
                poseStack.translate(0f, base, 0f);
                poseStack.mulPose(new Quaternionf().rotationY(0.4f * i));
                poseStack.scale(w, sh, w);
                poseStack.translate(-0.5f, 0f, -0.5f);
                mc.getBlockRenderer().renderSingleBlock(state, poseStack, buffers, light, OverlayTexture.NO_OVERLAY);
                poseStack.popPose();
            }
            poseStack.popPose();
        }

        @Override
        public void renderGlow(Draw d) {
            float t = time(d.partialTick);
            float heat = Math.max(0f, 1f - t / 25f);
            if (heat > 0.01f) {   // kaki tiang membara sesaat
                d.glow(x, y + 0.1, z, width * 1.4f, EMBER_RED, 0.5f * heat);
            }
        }
    }

    // ------------------------------------------------------------------ Z - Segel Zehuti

    private static void zehuti(AbstractClientPlayer caster, boolean self) {
        SIGHT.put(caster.getId(), caster.level().getGameTime());
        // huruf-huruf cahaya pirus berputar lalu terhisap ke kepala; lingkaran hieroglif kecil mengelilingi kepala
        schedule(0, 1, (level, t) -> Vfx.add(new Runes.Circle(pt -> caster.getEyePosition(pt).add(0, 0.15, 0), UP, 0.75,
                TURQUOISE, ShazamAnim.CAST_WINDUP + 6, 0.12f, 0.9f, null)));
        schedule(0, ShazamAnim.CAST_WINDUP, (level, t) -> {
            Vec3 head = caster.getEyePosition();
            for (int i = 0, n = Vfx.count(5); i < n; i++) {
                Vec3 off = ShazamFx.randomDir(level.random).scale(1.6 + level.random.nextDouble() * 0.7);
                Vfx.mote(head.x + off.x, head.y + off.y, head.z + off.z, -off.x * 0.2, -off.y * 0.2, -off.z * 0.2,
                        i % 3 == 0 ? GOLD_HOT : TURQUOISE, 0.08f, 6);
            }
        });
        // jari menunjuk: gelombang hieroglif melesat ke depan
        schedule(ShazamAnim.CAST_WINDUP, 1, (level, t) -> {
            Vec3 look = caster.getViewVector(1f);
            Vec3 hand = ShazamPoses.handPos(caster, true, 1f);
            long t0 = level.getGameTime();
            Vfx.add(new Runes.Circle(Lightning.Anchor.fixed(hand.add(look.scale(0.4))), look, 0.9, TURQUOISE, 16, 0.1f, 1f, null));
            Vfx.add(new Runes.Circle(pt -> hand.add(look.scale(Math.min(10.0, (level.getGameTime() - t0 + pt) * 1.1))), look,
                    1.6, TURQUOISE_LIGHT, 12, -0.08f, 0.85f, null));
            Vfx.add(new Fx.Ripple(hand, look, 12.0, 0.5, 6.0, 0.4, TURQUOISE, 15, 0.8f, false));
            Vfx.add(new Fx.Ripple(hand, look, 8.0, 0.3, 3.5, 0.2, GOLD_HOT, 11, 0.6f, false));
            Vfx.add(new Fx.Flash(hand, 1.6f, TURQUOISE_LIGHT, 8, 1f));
            arcsOut(level, hand, 3, 1.2, TURQUOISE, 0.05f, 3);
            if (self) {
                ScreenFx.vignette(0.38f, 0x002A24, 10);
            }
        });
    }

    /** Segel hieroglif di satu musuh: tiga cincin huruf berputar + pilar cahaya, plus rantai huruf cahaya dari jari. */
    private static void seal(AbstractClientPlayer caster, Vec3 pos) {
        ClientLevel level = (ClientLevel) caster.level();
        LivingEntity target = nearest(level, pos, 1.6);
        Lightning.Anchor hand = pt -> ShazamPoses.handPos(caster, true, pt);
        if (target != null) {
            Vfx.add(new Seal(target, 160));
            Vfx.add(new GlyphChain(hand, pt -> target.getPosition(pt).add(0, target.getBbHeight() * 0.55, 0), 12));
            Vfx.add(new Lightning.Arc(hand, pt -> target.getPosition(pt).add(0, target.getBbHeight() * 0.55, 0), TURQUOISE,
                    0.05f, 5, 1, 1, 0.2));
        } else {
            Vfx.add(new GlyphChain(hand, Lightning.Anchor.fixed(pos.add(0, 0.8, 0)), 12));
        }
        Vec3 c = pos.add(0, 0.9, 0);
        Vfx.add(new Fx.Flash(c, 1.7f, TURQUOISE_LIGHT, 9, 0.9f));
        Vfx.add(new Fx.Pillar(pos, 4.0, 0.7f, TURQUOISE, 12));
        for (int i = 0, n = Vfx.count(12); i < n; i++) {
            Vec3 v = ShazamFx.randomDir(level.random).scale(0.15);
            Vfx.glint(c.x + v.x * 5, c.y + v.y * 5, c.z + v.z * 5, i % 2 == 0 ? TURQUOISE : GOLD_HOT, 0.24f, 12);
        }
    }

    private static LivingEntity nearest(ClientLevel level, Vec3 pos, double radius) {
        List<LivingEntity> list = level.getEntitiesOfClass(LivingEntity.class, new AABB(pos, pos).inflate(radius),
                e -> e.isAlive() && !(e instanceof AbstractClientPlayer));
        LivingEntity best = null;
        double bestD = Double.MAX_VALUE;
        for (LivingEntity e : list) {
            double dd = e.position().distanceToSqr(pos);
            if (dd < bestD) {
                bestD = dd;
                best = e;
            }
        }
        return best;
    }

    /** Gambar satu hieroglif (EgyptLook.GLYPHS) menghadap kamera di titik p, sebesar size. */
    private static void glyph(Draw d, double px, double py, double pz, double size, int index, int rgb, float a) {
        double vx = px - d.camX, vy = py - d.camY, vz = pz - d.camZ;
        double rx = -vz, rz = vx;
        double rl = Math.sqrt(rx * rx + rz * rz);
        if (rl < 1.0E-6) {
            rx = 1;
            rz = 0;
            rl = 1;
        }
        rx /= rl;
        rz /= rl;
        double vl = Math.sqrt(vx * vx + vy * vy + vz * vz) + 1.0E-9;
        double fx = vx / vl, fy = vy / vl, fz = vz / vl;
        double ux = 0 * fz - rz * fy, uy = rz * fx - rx * fz, uz = rx * fy - 0 * fx;
        double[] gl = EgyptLook.GLYPHS[Math.floorMod(index, EgyptLook.GLYPHS.length)];
        for (int s = 0; s + 3 < gl.length; s += 4) {
            d.line(px + (rx * gl[s] + ux * gl[s + 1]) * size, py + uy * gl[s + 1] * size, pz + (rz * gl[s] + uz * gl[s + 1]) * size,
                    px + (rx * gl[s + 2] + ux * gl[s + 3]) * size, py + uy * gl[s + 3] * size,
                    pz + (rz * gl[s + 2] + uz * gl[s + 3]) * size, (float) (size * 0.35), (float) (size * 0.35), rgb, a, a);
        }
    }

    /** Tiga cincin hieroglif berputar mengikat badan musuh, pilar cahaya di antaranya, dan lingkaran huruf di tanah. */
    static final class Seal extends Effect {
        private final LivingEntity target;

        Seal(LivingEntity target, int life) {
            super(life);
            this.target = target;
        }

        @Override
        public boolean tick(ClientLevel level) {
            return target.isAlive() && super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            float in = Math.min(1f, time / 4f);
            float out = Math.min(1f, (life - time) / 12f);
            float a = Math.max(0f, Math.min(in, out));
            if (a <= 0.01f) {
                return;
            }
            Vec3 p = target.getPosition(d.partialTick);
            double h = target.getBbHeight(), w = Math.max(0.65, target.getBbWidth() * 0.9 + 0.4);
            double[] heights = {h * 0.15, h * 0.5, h * 0.85};
            float lock = time < 6f ? 1f + 1.2f * (1f - time / 6f) : 1f;   // saat mengunci: cincin menyempit memantul
            for (int k = 0; k < 3; k++) {
                double y = p.y + heights[k];
                double spin = (k % 2 == 0 ? 1 : -1) * time * (0.05 + 0.02 * k);
                double rr = w * (1.0 + 0.35 * (lock - 1f)) * (k == 1 ? 1.12 : 1.0);
                d.ring(p.x, y, p.z, 0, 1, 0, rr, 0.08, TURQUOISE, 0.8f * a, 0f, null);
                d.ring(p.x, y, p.z, 0, 1, 0, rr * 1.2, 0.03, GOLD_HOT, 0.55f * a, 0f, null);
                int count = 12;
                for (int i = 0; i < count; i++) {
                    double ang = spin + Math.PI * 2.0 * i / count;
                    double gx = p.x + Math.cos(ang) * rr * 1.1, gz = p.z + Math.sin(ang) * rr * 1.1;
                    double ux = -Math.sin(ang), uz = Math.cos(ang);
                    double[] gl = EgyptLook.GLYPHS[(i + k * 3) % EgyptLook.GLYPHS.length];
                    double size = 0.1;
                    for (int s = 0; s + 3 < gl.length; s += 4) {
                        d.line(gx + ux * gl[s] * size, y + gl[s + 1] * size, gz + uz * gl[s] * size,
                                gx + ux * gl[s + 2] * size, y + gl[s + 3] * size, gz + uz * gl[s + 2] * size,
                                0.04f, 0.04f, TURQUOISE_LIGHT, 0.9f * a, 0.9f * a);
                    }
                }
            }
            for (int i = 0; i < 6; i++) {   // pilar cahaya mengunci ketiga cincin
                double ang = time * 0.02 + Math.PI / 3.0 * i;
                double x = p.x + Math.cos(ang) * w, z = p.z + Math.sin(ang) * w;
                d.line(x, p.y + heights[0], z, x, p.y + heights[2], z, 0.07f, 0.07f, TURQUOISE, 0.4f * a, 0.4f * a);
            }
            d.ring(p.x, p.y + 0.03, p.z, 0, 1, 0, w * 1.7, 0.06, TURQUOISE, 0.5f * a, 0.12f, null);   // lingkaran di tanah
            d.glow(p.x, p.y + h * 0.5, p.z, (float) (w * 1.6), TURQUOISE, 0.16f * a);
        }
    }

    /** Rantai huruf cahaya dari jari ke sasaran: berkas pirus dengan hieroglif berjajar yang mengalir ke sasaran. */
    static final class GlyphChain extends Effect {
        private final Lightning.Anchor from, to;

        GlyphChain(Lightning.Anchor from, Lightning.Anchor to, int life) {
            super(life);
            this.from = from;
            this.to = to;
        }

        @Override
        public void renderGlow(Draw d) {
            float p = progress(d.partialTick);
            float a = (1f - p) * Math.min(1f, time(d.partialTick) / 2f);
            if (a <= 0.01f) {
                return;
            }
            Vec3 x = from.at(d.partialTick), y = to.at(d.partialTick);
            d.beam(x.x, x.y, x.z, y.x, y.y, y.z, 0.16f * (1f - 0.4f * p), TURQUOISE, 0xFFFFFF, a * 0.85f, a);
            double len = x.distanceTo(y);
            int count = (int) Math.min(24, len / 0.55);
            float flow = time(d.partialTick) * 0.35f;
            for (int i = 0; i < count; i++) {
                double u = ((i + flow) % count) / (double) count;
                Vec3 q = x.lerp(y, u);
                glyph(d, q.x, q.y, q.z, 0.13, i, TURQUOISE_LIGHT, 0.85f * a);
            }
        }
    }

    // ------------------------------------------------------------------ A - Sinar Aton

    private static void aton(AbstractClientPlayer caster, boolean self) {
        SunDisk disk = new SunDisk(caster, ShazamAnim.ATON_WINDUP + ShazamAnim.ATON_GAP * 6 + 14);
        SUNS.put(caster.getId(), disk);
        Vfx.add(disk);
        // cahaya matahari terhisap ke telapak, udara panas bergetar di sekeliling
        schedule(0, ShazamAnim.ATON_WINDUP, (level, t) -> {
            Vec3 c = disk.center(1f);
            for (int i = 0, n = Vfx.count(6); i < n; i++) {
                Vec3 off = ShazamFx.randomDir(level.random).scale(2.0 + level.random.nextDouble() * 1.2);
                Vfx.mote(c.x + off.x, c.y + off.y, c.z + off.z, -off.x * 0.22, -off.y * 0.22, -off.z * 0.22,
                        i % 2 == 0 ? SUN : GOLD_HOT, 0.1f, 5);
            }
            if (t == 2) {
                Ground.Map map = ShazamFx.ground(level, caster.position(), 3.0);
                Vfx.add(new Fx.Wave(caster.position().add(0, 0.05, 0), UP, 3.0, 0.5, SUN, 16, 0.5f, 0.15f, map));
            }
            if (self && t == ShazamAnim.ATON_WINDUP - 1) {
                ScreenFlash.flash(0.25f, 0xFFF0C8);
            }
        });
    }

    /** Satu sinar Aton dari cakram ke sasaran: berkas tebal berpilin petir, berujung tangan terbuka, lalu ledakan api. */
    private static void ray(AbstractClientPlayer caster, Vec3 target) {
        SunDisk disk = SUNS.get(caster.getId());
        Lightning.Anchor from = disk != null && !disk.done ? disk::center
                : pt -> ShazamPoses.handPos(caster, true, pt).add(0, 0.9, 0);
        Vfx.add(new SunRay(from, target, 10));
        ClientLevel level = (ClientLevel) caster.level();
        Vfx.add(new Fx.Flash(target, 2.4f, 0xFFF2C8, 9, 1f));
        Vfx.add(new Fx.Bubble(target, 1.5, SUN, 8, 0.8f, 1.0, 2.0, true));
        Vfx.add(new Lightning.Arc(from, Lightning.Anchor.fixed(target), AMBER_LIGHT, 0.07f, 4, 1, 1, 0.22));
        ShazamFx.ringOfSparks(level, target, 26, SUN, 0.42);
        Ground.Map map = groundAt(level, target, 2.0);
        if (map != null && target.y - map.centerY < 2.5) {
            Vec3 g = map.center(target);
            Vfx.add(new Fx.Wave(g, UP, 2.4, 0.4, EMBER_RED, 12, 0.8f, 0.15f, map));
            Vfx.add(new Fx.Scorch(g, 0.9, 130, 40, map));
            Vfx.add(new Ground.Cracks(g, map, 4, 0.9f, 100, 30, SUN, level.random.nextLong()));
            ShazamFx.dustPuffs(level, g, map.dustColor(level, g), 8, 0.6, 0.12);
        }
        for (int i = 0, n = Vfx.count(10); i < n; i++) {
            Vfx.ember(target.x + (level.random.nextDouble() - 0.5) * 0.8, target.y + (level.random.nextDouble() - 0.5) * 0.8,
                    target.z + (level.random.nextDouble() - 0.5) * 0.8, 0, 0.05, 0, 0.09f, 18 + level.random.nextInt(10));
        }
        ShazamFx.shakeAround(target, 0.35f, 16);
    }

    /** Cakram matahari di atas telapak kanan: terbit memantul, mahkota sinar berputar, petir kecil berkejaran. */
    static final class SunDisk extends Effect {
        private final AbstractClientPlayer owner;
        boolean done;

        SunDisk(AbstractClientPlayer owner, int life) {
            super(life);
            this.owner = owner;
        }

        @Override
        public boolean tick(ClientLevel level) {
            boolean alive = owner.isAlive() && ShazamClientState.isTransformed(owner.getId()) && super.tick(level);
            done = !alive;
            if (alive && age > 3 && age % 2 == 0) {   // petir kecil berkejaran di tepi cakram
                Vec3 c = center(1f);
                Vec3 off = ShazamFx.randomDir(level.random).scale(1.3 + level.random.nextDouble() * 0.8);
                Vfx.add(new Lightning.Arc(pt -> center(pt), Lightning.Anchor.fixed(c.add(off)), AMBER_LIGHT, 0.05f, 2, 1, 0, 0.35));
            }
            return alive;
        }

        Vec3 center(float pt) {
            return ShazamPoses.handPos(owner, true, pt).add(0, 1.0 * owner.getScale(), 0);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            float grow = time < ShazamAnim.ATON_WINDUP ? (float) GodFigures.outBack(time / ShazamAnim.ATON_WINDUP) : 1f;
            float fade = Math.min(1f, (life - time) / 6f);
            float k = Math.max(0f, grow) * Math.max(0f, fade);
            if (k <= 0.01f) {
                return;
            }
            Vec3 c = center(d.partialTick);
            double tx = d.camX - c.x, ty = d.camY - c.y, tz = d.camZ - c.z;
            double tl = Math.sqrt(tx * tx + ty * ty + tz * tz) + 1.0E-9;
            tx /= tl;
            ty /= tl;
            tz /= tl;
            float near = d.nearFade(c.x, c.y, c.z, 0.7, 2.2);
            float r = 0.8f * k;
            d.disc(c.x, c.y, c.z, tx, ty, tz, r, SUN, 0.95f * near, 0.6f * near, null);
            d.ring(c.x, c.y, c.z, tx, ty, tz, r * 1.04, r * 0.14, 0xFFB838, 0.95f * near, 0f, null);
            d.ring(c.x, c.y, c.z, tx, ty, tz, r * 1.45, r * 0.06, AMBER, 0.6f * near, 0f, null);
            d.flare(c.x, c.y, c.z, r * 1.8f, GOLD_HOT, 0.8f * near);
            d.glow(c.x, c.y, c.z, r * 6f, SUN, 0.3f * near);
            double[] e = new double[6];
            Draw.plane(tx, ty, tz, e);
            int rays = 28;   // mahkota: sinar-sinar berputar, panjangnya berdenyut
            for (int i = 0; i < rays; i++) {
                double a = time * 0.05 + Math.PI * 2.0 * i / rays;
                double cs = Math.cos(a), sn = Math.sin(a);
                double dx = e[0] * cs + e[3] * sn, dy = e[1] * cs + e[4] * sn, dz = e[2] * cs + e[5] * sn;
                double pulse = 0.85 + 0.15 * Math.sin(time * 0.6 + i * 1.7);
                double r0 = r * 1.1, r1 = r * (i % 2 == 0 ? 2.4 : 1.7) * pulse;
                d.line(c.x + dx * r0, c.y + dy * r0, c.z + dz * r0, c.x + dx * r1, c.y + dy * r1, c.z + dz * r1,
                        0.1f * k, 0.01f, 0xFFE7A0, 0.8f * near, 0f);
            }
            // garis silau kamera mendatar & tegak
            double hx = e[0], hy = e[1], hz = e[2], vx = e[3], vy = e[4], vz = e[5];
            d.line(c.x - hx * r * 5, c.y - hy * r * 5, c.z - hz * r * 5, c.x + hx * r * 5, c.y + hy * r * 5, c.z + hz * r * 5,
                    0.06f, 0.06f, GOLD_HOT, 0.35f * near, 0.35f * near);
            d.line(c.x - vx * r * 3, c.y - vy * r * 3, c.z - vz * r * 3, c.x + vx * r * 3, c.y + vy * r * 3, c.z + vz * r * 3,
                    0.05f, 0.05f, GOLD_HOT, 0.25f * near, 0.25f * near);
        }
    }

    /** Berkas sinar Aton: tebal berlapis, dua pilinan petir mengelilinginya, cincin panas, dan tangan terbuka di ujung. */
    static final class SunRay extends Effect {
        private final Lightning.Anchor from;
        private final Vec3 to;

        SunRay(Lightning.Anchor from, Vec3 to, int life) {
            super(life);
            this.from = from;
            this.to = to;
        }

        @Override
        public void renderGlow(Draw d) {
            float p = progress(d.partialTick);
            float a = p < 0.15f ? p / 0.15f : (float) Math.pow(1f - (p - 0.15f) / 0.85f, 1.4);
            if (a <= 0.01f) {
                return;
            }
            Vec3 s = from.at(d.partialTick);
            Vec3 dir = to.subtract(s);
            double len = dir.length();
            if (len < 0.3) {
                return;
            }
            dir = dir.scale(1.0 / len);
            float width = 0.78f * (0.6f + 0.4f * a);
            d.beam(s.x, s.y, s.z, to.x, to.y, to.z, width, SUN, 0xFFFFFF, a * 0.95f, a);
            float old = d.body(0.25f);
            d.line(s.x, s.y, s.z, to.x, to.y, to.z, width * 2.8f, width * 2.8f, AMBER, a * 0.2f, a * 0.22f);
            d.body(old);
            // dua pilinan petir berputar mengelilingi berkas
            Vec3 side = dir.cross(UP);
            side = side.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : side.normalize();
            Vec3 up = side.cross(dir).normalize();
            float time = time(d.partialTick);
            int steps = Math.max(8, (int) (len * 4));
            for (int strand = 0; strand < 2; strand++) {
                float[] pts = new float[(steps + 1) * 3];
                for (int i = 0; i <= steps; i++) {
                    double u = i / (double) steps;
                    double ang = u * len * 2.2 + time * 0.9 + strand * Math.PI;
                    double rad = width * 0.55 * (0.7 + 0.3 * Math.sin(u * 9.0 + time));
                    Vec3 q = s.add(dir.scale(len * u)).add(side.scale(Math.cos(ang) * rad)).add(up.scale(Math.sin(ang) * rad));
                    pts[i * 3] = (float) q.x;
                    pts[i * 3 + 1] = (float) q.y;
                    pts[i * 3 + 2] = (float) q.z;
                }
                d.polyline(pts, steps + 1, 0.07f, 0.07f, AMBER_LIGHT, 0xFFFFFF, a * 0.9f, a * 0.9f);
            }
            for (int i = 1; i < (int) len; i += 2) {   // cincin panas di sepanjang berkas
                Vec3 q = s.add(dir.scale(i + (time * 0.3) % 2.0));
                if (q.distanceToSqr(s) > len * len) {
                    continue;
                }
                d.ring(q.x, q.y, q.z, dir.x, dir.y, dir.z, width * 0.9, 0.05, GOLD_HOT, 0.4f * a, 0f, null);
            }
            // tangan terbuka di ujung sinar (lambang Aton): empat jari + ibu jari
            Vec3 palm = to.subtract(dir.scale(0.4));
            for (int f = -2; f <= 2; f++) {
                Vec3 base = palm.add(side.scale(f * 0.1));
                Vec3 tip = base.add(dir.scale(f == -2 ? 0.22 : 0.4)).add(side.scale(f == -2 ? -0.16 : f * 0.03));
                d.line(base.x, base.y, base.z, tip.x, tip.y, tip.z, 0.1f, 0.06f, 0xFFF4D0, a, a * 0.7f);
            }
            d.glow(palm.x, palm.y, palm.z, 0.5f, SUN, 0.7f * a);
        }
    }

    // ------------------------------------------------------------------ M - Lilitan Mehen

    private static void mehen(AbstractClientPlayer caster, boolean self) {
        // ular menyeruak dari pasir: asap hitam & pasir menyembur dari tanah, listrik merambat naik
        schedule(0, ShazamAnim.MEHEN_WINDUP, (level, t) -> {
            RandomSource r = level.random;
            Vec3 c = caster.position();
            for (int i = 0, n = Vfx.count(5); i < n; i++) {
                double a = r.nextDouble() * Math.PI * 2.0, d = 0.7 + r.nextDouble() * 0.9;
                Vfx.smoke(c.x + Math.cos(a) * d, c.y + 0.1, c.z + Math.sin(a) * d, -Math.sin(a) * 0.06, 0.05,
                        Math.cos(a) * 0.06, SMOKE, 0.5f, 22);
                Vfx.dust(c.x + Math.cos(a) * d, c.y + 0.1, c.z + Math.sin(a) * d, -Math.sin(a) * 0.12, 0.08,
                        Math.cos(a) * 0.12, SAND, 0.45f, 16);
            }
            double a = r.nextDouble() * Math.PI * 2.0;
            Vfx.add(new Lightning.Arc(Lightning.Anchor.on(caster, Math.cos(a) * 0.8, 0.05, Math.sin(a) * 0.8),
                    Lightning.Anchor.on(caster, Math.cos(a + 1.2) * 0.7, 1.2 + r.nextDouble() * 0.6, Math.sin(a + 1.2) * 0.7),
                    SERPENT, 0.06f, 2, 1, 0, 0.3));
        });
        schedule(ShazamAnim.MEHEN_WINDUP, 1, (level, t) -> {
            Serpent old = SERPENTS.get(caster.getId());
            if (old != null) {
                old.done = true;
            }
            Serpent serpent = new Serpent(caster, ShazamAnim.MEHEN_TICKS);
            SERPENTS.put(caster.getId(), serpent);
            Vfx.add(serpent);
            Vec3 c = caster.position();
            Vfx.add(new Fx.Flash(c.add(0, 1.2, 0), 2.6f, SERPENT, 10, 0.9f));
            Ground.Map map = ShazamFx.ground(level, c, 3.5);
            Vfx.add(new Fx.Wave(c.add(0, 0.05, 0), UP, 3.4, 0.45, SERPENT_RED, 15, 0.85f, 0.1f, map));
            Vfx.add(new Fx.Wave(c.add(0, 0.08, 0), UP, 2.8, 1.2, SAND, 22, 0.55f, 0f, map, true));
            if (map != null && map.found) {
                Vfx.add(new Ground.Cracks(map.center(c), map, 6, 1.2f, 100, 30, SERPENT_RED, level.random.nextLong()));
                Vfx.add(new Ground.Debris(map.center(c), map, 8, 0.1, 0.45, 0.5, 40));
            }
            ShazamFx.ringOfSparks(level, c.add(0, 1.0, 0), 28, SERPENT, 0.4);
            ShazamFx.dustPuffs(level, c, SAND, 14, 0.8, 0.16);
            sound(level, c, SoundEvents.CAT_HISS, 1.0f, 0.5f);
            if (self) {
                ScreenFx.vignette(0.32f, 0x2A0A00, 9);
            }
        });
    }

    private static void bite(AbstractClientPlayer caster, Vec3 target) {
        Serpent serpent = SERPENTS.get(caster.getId());
        if (serpent != null && !serpent.done) {
            serpent.strike(target);
        }
        schedule(2, 1, (level, t) -> {
            Vfx.add(new Fx.Flash(target, 1.8f, SERPENT, 7, 0.95f));
            Vfx.add(new Fx.Bubble(target, 1.0, SERPENT_RED, 6, 0.6f, 1.0, 2.0, true));
            ShazamFx.ringOfSparks(level, target, 16, SERPENT_RED, 0.34);
            arcsOut(level, target, 2, 1.0, SERPENT, 0.05f, 3);
            for (int i = 0, n = Vfx.count(6); i < n; i++) {   // tetes bisa
                Vfx.mote(target.x + (level.random.nextDouble() - 0.5) * 0.6, target.y, target.z + (level.random.nextDouble() - 0.5) * 0.6,
                        0, -0.03, 0, 0x9CFF7A, 0.08f, 16);
            }
            ShazamFx.shakeAround(target, 0.25f, 12);
        });
    }

    /**
     * Ular Mehen dari cahaya yang membelit badan pemain: gulungan tebal berpilin dari kaki ke bahu (bergelang emas-merah,
     * bersisik terang, berlistrik), leher naik di belakang bahu kanan, kepala kobra bertudung lebar dengan mata merah,
     * dan bisa mematuk sasaran.
     */
    static final class Serpent extends Effect {
        private static final int COIL = 44, NECK = 14;
        private final AbstractClientPlayer owner;
        private final int active;
        private float fade, fadeO;
        private boolean ending;
        boolean done;
        private Vec3 strikeAt;
        private float strikeTime = -100f;
        private final long seed = Vfx.random().nextLong();

        Serpent(AbstractClientPlayer owner, int active) {
            super(active + 14);
            this.owner = owner;
            this.active = active;
        }

        void strike(Vec3 target) {
            strikeAt = target;
            strikeTime = age;
        }

        float strength(float pt) {
            return Mth.lerp(pt, fadeO, fade);
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (!owner.isAlive() || !ShazamClientState.isTransformed(owner.getId())) {
                ending = true;
            }
            fadeO = fade;
            boolean on = !ending && !done && age < active;
            fade = Mth.approach(fade, on ? 1f : 0f, on ? 0.12f : 0.1f);
            boolean alive = super.tick(level) && !((ending || done) && fade <= 0f);
            if (!alive) {
                done = true;
            }
            if (alive && fade > 0.5f && age % 5 == 0) {   // sisik berkilat
                Vec3 c = owner.position();
                double a = level.random.nextDouble() * Math.PI * 2, y = 0.2 + level.random.nextDouble() * 1.7;
                Vfx.glint(c.x + Math.cos(a) * 0.9, c.y + y, c.z + Math.sin(a) * 0.9, GOLD_HOT, 0.2f, 8);
            }
            return alive;
        }

        @Override
        public void renderGlow(Draw d) {
            float f = strength(d.partialTick);
            if (f <= 0.01f) {
                return;
            }
            float pt = d.partialTick;
            float time = time(pt);
            float sc = owner.getScale();
            Vec3 base = owner.getPosition(pt);
            float yaw = Mth.rotLerp(pt, owner.yBodyRotO, owner.yBodyRot) * Mth.DEG_TO_RAD;
            double fx = -Math.sin(yaw), fz = Math.cos(yaw);      // depan badan
            double rx = -fz, rz = fx;                           // kanan badan
            int n = COIL + NECK;
            float[] pts = new float[n * 3], w = new float[n], a = new float[n];
            double rise = Math.min(1.0, f * 1.2);
            for (int i = 0; i < COIL; i++) {   // gulungan berpilin naik dari kaki ke bahu
                double u = i / (double) (COIL - 1);
                double ang = -time * 0.045 + u * Math.PI * 2.0 * 2.7;
                double rad = (1.0 - 0.3 * u) * sc;
                double y = (0.1 + 1.66 * u * rise) * sc;
                pts[i * 3] = (float) (base.x + Math.cos(ang) * rad);
                pts[i * 3 + 1] = (float) (base.y + y);
                pts[i * 3 + 2] = (float) (base.z + Math.sin(ang) * rad);
                w[i] = (float) ((0.14 + 0.46 * Math.pow(u, 0.6)) * sc);
            }
            // kepala: melayang di atas bahu kanan, bergoyang; mematuk sasaran lalu kembali
            double sway = Math.sin(time * 0.09) * 0.12, bob = Math.sin(time * 0.13) * 0.06;
            Vec3 idle = base.add(rx * (0.6 + sway) * sc + fx * 0.45 * sc, (2.55 + bob) * sc * rise, rz * (0.6 + sway) * sc
                    + fz * 0.45 * sc);
            Vec3 head = idle;
            double lunge = 0.0;
            float since = time - strikeTime;
            if (strikeAt != null && since >= 0f && since < 8f) {
                lunge = since < 2.5f ? GodFigures.outCubic(since / 2.5f) : 1.0 - GodFigures.smooth((since - 2.5f) / 5.5f);
                Vec3 aim = strikeAt.subtract(idle);
                double reach = Math.min(aim.length(), 6.5);
                head = idle.add(aim.normalize().scale(reach * lunge));
            }
            int last = (COIL - 1) * 3;
            double ex = pts[last], ey = pts[last + 1], ez = pts[last + 2];
            double cx = ex + rx * 0.25 * sc - fx * 0.35 * sc, cy = ey + 0.9 * sc, cz = ez + rz * 0.25 * sc - fz * 0.35 * sc;
            for (int k = 0; k < NECK; k++) {   // leher: dari ujung gulungan naik melengkung (Bezier) ke kepala
                double u = (k + 1) / (double) NECK, v = 1 - u;
                int i = COIL + k;
                pts[i * 3] = (float) (v * v * ex + 2 * v * u * cx + u * u * head.x);
                pts[i * 3 + 1] = (float) (v * v * ey + 2 * v * u * cy + u * u * head.y);
                pts[i * 3 + 2] = (float) (v * v * ez + 2 * v * u * cz + u * u * head.z);
                w[i] = (float) ((0.58 - 0.16 * u) * sc);
            }
            for (int i = 0; i < n; i++) {
                a[i] = f * d.nearFade(pts[i * 3], pts[i * 3 + 1], pts[i * 3 + 2], 0.7, 1.9);
            }
            d.polyline(pts, n, w, a, SERPENT, GOLD_HOT);
            float[] seg = new float[3 * 3], sw = new float[3], sa = new float[3];
            for (int s = 2; s + 2 < n; s += 4) {   // gelang merah berselang
                for (int j = 0; j < 3; j++) {
                    int src = s + j - 1;
                    seg[j * 3] = pts[src * 3];
                    seg[j * 3 + 1] = pts[src * 3 + 1];
                    seg[j * 3 + 2] = pts[src * 3 + 2];
                    sw[j] = w[src] * 1.05f;
                    sa[j] = a[src] * 0.9f;
                }
                d.strip(seg, 3, sw, 0.85f, sa, 1f, SERPENT_RED);
            }
            for (int i = 1; i < n; i += 2) {   // sisik terang di punggung ular
                d.glow(pts[i * 3], pts[i * 3 + 1] + w[i] * 0.22f, pts[i * 3 + 2], w[i] * 0.24f, GOLD_HOT, 0.6f * a[i]);
            }
            Random random = new Random(seed + age / 2);
            for (int k = 0; k < 3; k++) {   // listrik merambat di kulit ular
                int i = random.nextInt(n - 4);
                int j = i + 3;
                float[] arc = Lightning.path(pts[i * 3], pts[i * 3 + 1] + w[i] * 0.45f, pts[i * 3 + 2], pts[j * 3],
                        pts[j * 3 + 1] + w[j] * 0.45f, pts[j * 3 + 2], 3, 0.35, random);
                d.polyline(arc, arc.length / 3, 0.06f, 0.04f, AMBER_LIGHT, 0xFFFFFF, 0.8f * a[i], 0.8f * a[j]);
            }
            // kepala kobra: tudung lebar (kipas cahaya), kepala, mata merah, taring saat mematuk
            int hk = (n - 1) * 3, nk = (n - 3) * 3;
            Vec3 tip = new Vec3(pts[hk], pts[hk + 1], pts[hk + 2]);
            Vec3 neck = new Vec3(pts[nk], pts[nk + 1], pts[nk + 2]);
            Vec3 along = tip.subtract(neck);
            along = along.lengthSqr() < 1.0E-6 ? UP : along.normalize();
            Vec3 face = lunge > 0.05 && strikeAt != null ? strikeAt.subtract(tip).normalize() : new Vec3(fx, -0.35, fz).normalize();
            Vec3 side = along.cross(face);
            side = side.lengthSqr() < 1.0E-6 ? new Vec3(rx, 0, rz) : side.normalize();
            float near = d.nearFade(tip.x, tip.y, tip.z, 0.7, 1.9);
            float hood = (float) (0.5 + 0.5 * Math.min(1.0, f * 1.4));
            for (int k = -5; k <= 5; k++) {
                double spread = k * 0.15;
                Vec3 dir = along.scale(Math.cos(spread)).add(side.scale(Math.sin(spread) * 1.7)).normalize();
                Vec3 end = neck.add(dir.scale((0.66 - Math.abs(k) * 0.035) * sc * hood));
                d.line(neck.x, neck.y, neck.z, end.x, end.y, end.z, 0.3f * sc, 0.12f * sc, Math.abs(k) % 2 == 0 ? SERPENT_RED : SERPENT,
                        0.9f * f * near, 0.4f * f * near);
            }
            Vec3 snout = tip.add(face.scale(0.32 * sc));
            d.line(tip.x, tip.y, tip.z, snout.x, snout.y, snout.z, 0.4f * sc, 0.17f * sc, SERPENT, f * near, f * near);
            d.line(tip.x, tip.y, tip.z, snout.x, snout.y, snout.z, 0.15f * sc, 0.06f * sc, GOLD_HOT, f * near, f * near);
            d.glow(tip.x, tip.y, tip.z, 0.6f * sc, SERPENT, 0.4f * f * near);
            for (int s = -1; s <= 1; s += 2) {
                Vec3 eye = tip.add(face.scale(0.12 * sc)).add(side.scale(s * 0.1 * sc)).add(along.scale(0.05 * sc));
                d.glow(eye.x, eye.y, eye.z, 0.09f * sc, 0xFF3A20, 0.95f * f * near);
                d.glow(eye.x, eye.y, eye.z, 0.03f * sc, 0xFFFFFF, f * near);
            }
            if (lunge > 0.2) {
                for (int s = -1; s <= 1; s += 2) {
                    Vec3 fang = snout.add(side.scale(s * 0.06 * sc));
                    Vec3 fangTip = fang.add(face.scale(0.07 * sc)).add(along.scale(-0.1 * sc));
                    d.line(fang.x, fang.y, fang.z, fangTip.x, fangTip.y, fangTip.z, 0.035f, 0.006f, 0xFFFFFF,
                            (float) lunge * f, (float) lunge * f);
                }
            }
        }
    }

    // ------------------------------------------------------------------ Murka Kahndaq

    private static void rage(AbstractClientPlayer caster, boolean self) {
        // petir dari langit menghujani sekeliling, petir dari segala arah terhisap ke badan, tanah retak membara
        schedule(0, ShazamAnim.ADAM_RAGE_WINDUP, (level, t) -> {
            for (int i = 0; i < 3; i++) {
                Vec3 off = ShazamFx.randomDir(level.random).scale(2.8 + level.random.nextDouble() * 1.4);
                Vec3 from = caster.position().add(off.x, 1.1 + Math.abs(off.y) * 0.6, off.z);
                Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(from), Lightning.Anchor.on(caster, 0, 1.1, 0), AMBER,
                        0.085f, 2, 1, 1, 0.27));
            }
            if (t % 2 == 0) {
                double a = level.random.nextDouble() * Math.PI * 2.0, d = 3.5 + level.random.nextDouble() * 4.0;
                skyBolt(caster.position().add(Math.cos(a) * d, 0, Math.sin(a) * d), 0.55f, 7);
                double b = level.random.nextDouble() * Math.PI * 2.0, e = 1.0 + level.random.nextDouble() * 1.2;
                Vfx.smoke(caster.getX() + Math.cos(b) * e, caster.getY() + 0.1, caster.getZ() + Math.sin(b) * e,
                        -Math.sin(b) * 0.04, 0.06, Math.cos(b) * 0.04, SMOKE, 0.6f, 28);
            }
            if (t == 2) {
                Ground.Map map = groundAt(level, caster.position(), 3.0);
                if (map != null) {
                    Vfx.add(new Ground.Cracks(map.center(caster.position()), map, 9, 2.6f, 160, 60, AMBER, level.random.nextLong()));
                }
            }
            ShazamFx.swirlDust(level, caster, t);
            if (self) {
                ScreenFx.vignette(0.35f + t * 0.035f, 0x2A0800, 3);
                CameraShake.add(0.045f);
            }
        });
        // meraung: kubah petir, guncangan besar, petir menyambar di empat penjuru
        schedule(ShazamAnim.ADAM_RAGE_WINDUP, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vfx.add(new Fx.Flash(c.add(0, 1.3, 0), 4.2f, 0xFFE8C8, 12, 1f));
            dome(level, c.add(0, 1.2, 0), 6.0, 14);
            slam(level, caster, c, 2.6f, false);
            Ground.Map map = ShazamFx.ground(level, c, 5.0);
            if (map != null) {
                Vfx.add(new Fx.Wave(map.center(c), UP, 12.0, 0.5, WHITE_HOT, 14, 0.9f, 0f, map));
                Vfx.add(new Fx.Wave(map.center(c), UP, 7.0, 1.8, SMOKE, 32, 0.65f, 0f, map, true));
            }
            for (int k = 0; k < 4; k++) {
                double a = Math.PI * 0.5 * k + level.random.nextDouble() * 0.6;
                skyBolt(c.add(Math.cos(a) * 4.5, 0, Math.sin(a) * 4.5), 1.0f, 9);
            }
            ShazamFx.ringOfSparks(level, c.add(0, 1.2, 0), 70, AMBER_LIGHT, 0.6);
            ShazamFx.groundArcs(level, c, 12, 7.0, AMBER, 8);
            surge(caster, 30, 3.0f, 0.075f);
            sound(level, c, SoundEvents.WARDEN_ROAR, 1.0f, 0.7f);
            if (self) {
                ScreenFlash.flash(0.65f, 0xFFE2C0);
                ScreenFx.speedLines(0.7f);
                CameraShake.add(0.55f);
                FovKick.punch(-0.1f);
            }
        });
        schedule(ShazamAnim.ADAM_RAGE_WINDUP + 1, 30, (level, t) -> {   // bara & abu naik sesudahnya
            if (t % 2 != 0) {
                return;
            }
            Vec3 c = caster.position();
            for (int i = 0, n = Vfx.count(3); i < n; i++) {
                double a = level.random.nextDouble() * Math.PI * 2.0, r = 0.6 + level.random.nextDouble() * 2.5;
                Vfx.ember(c.x + Math.cos(a) * r, c.y + 0.1, c.z + Math.sin(a) * r, 0, 0.06 + level.random.nextDouble() * 0.05, 0,
                        0.09f, 22);
            }
        });
    }

    // ------------------------------------------------------------------ M - Panggil Petir Kahndaq

    private static void call(AbstractClientPlayer caster, boolean self) {
        // kepalan ke langit: awan gelap berputar di atas kepala, busur listrik naik dari kepalan ke langit
        schedule(0, ShazamAnim.ADAM_CALL_WINDUP, (level, t) -> {
            Vec3 c = caster.position();
            double top = c.y + 7.0;
            for (int k = 0; k < 3; k++) {
                double a = t * 0.35 + k * Math.PI * 2.0 / 3.0, r = 2.5 + level.random.nextDouble() * 2.5;
                Vfx.smoke(c.x + Math.cos(a) * r, top + level.random.nextDouble(), c.z + Math.sin(a) * r, -Math.sin(a) * 0.1, 0,
                        Math.cos(a) * 0.1, 0x231A16, 1.1f + level.random.nextFloat() * 0.6f, 30);
            }
            if (t > 4) {
                Vec3 fist = ShazamPoses.handPos(caster, true, 1f);
                Vec3 tip = fist.add((level.random.nextDouble() - 0.5) * 1.5, 2.0 + level.random.nextDouble() * 4.0,
                        (level.random.nextDouble() - 0.5) * 1.5);
                Vfx.add(new Lightning.Arc(pt -> ShazamPoses.handPos(caster, true, pt), Lightning.Anchor.fixed(tip), AMBER_LIGHT,
                        0.08f, 2, 1, 1, 0.3));
            }
            if (t == 4) {
                Vfx.add(new Fx.Glow(caster, pt -> ShazamPoses.handPos(caster, true, pt), 1.0f, AMBER_LIGHT,
                        ShazamAnim.ADAM_CALL_WINDUP - 2, ShazamAnim.ADAM_CALL_WINDUP - 4));
            }
            if (self) {
                ScreenFx.vignette(0.3f + t * 0.03f, 0x1E0C04, 2);
                CameraShake.add(0.03f);
            }
        });
        // petir menyambar badan sendiri (petirnya digambar MagicBolt dari server): kubah, guncangan, listrik membelit
        schedule(ShazamAnim.ADAM_CALL_WINDUP, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vfx.add(new Fx.Flash(c.add(0, 2.2, 0), 4.0f, WHITE_HOT, 12, 1f));
            Vfx.add(new Fx.Pillar(c, 60.0, 1.8f, AMBER, 16));
            dome(level, c.add(0, 1.2, 0), 5.0, 12);
            slam(level, caster, c, 2.2f, false);
            ShazamFx.groundArcs(level, c, 10, 6.5, AMBER, 7);
            ShazamFx.ringOfSparks(level, c.add(0, 2.0, 0), 60, AMBER_LIGHT, 0.55);
            surge(caster, 50, 2.6f, 0.07f);
            if (self) {
                ScreenFlash.flash(0.75f, 0xFFE8C8);
                CameraShake.add(0.6f);
                FovKick.punch(-0.08f);
            }
        });
        schedule(ShazamAnim.ADAM_CALL_WINDUP, 20, (level, t) -> wrap(caster, t, 20));
    }

    // ------------------------------------------------------------------ pasif

    /** Proyektil memantul dari kulit Black Adam: percikan logam & listrik kecil. */
    private static void deflect(AbstractClientPlayer caster, Vec3 pos) {
        ClientLevel level = (ClientLevel) caster.level();
        Vfx.add(new Fx.Flash(pos, 0.9f, GOLD_HOT, 5, 0.95f));
        for (int i = 0, n = Vfx.count(12); i < n; i++) {
            Vec3 v = ShazamFx.randomDir(level.random).scale(0.18 + level.random.nextDouble() * 0.2);
            Vfx.spark(pos.x, pos.y, pos.z, v.x, Math.abs(v.y) + 0.05, v.z, i % 3 == 0 ? WHITE_HOT : AMBER_LIGHT, 0.045f,
                    8 + level.random.nextInt(6), caster.getY());
        }
        Vec3 body = caster.position().add(0, caster.getBbHeight() * 0.6, 0);
        Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(body), Lightning.Anchor.fixed(pos), AMBER_LIGHT, 0.045f, 2, 1, 0, 0.3));
        Vfx.glint(pos.x, pos.y, pos.z, WHITE_HOT, 0.3f, 6);
    }

    /** Tinju Black Adam mengenai: kilatan, cincin hempasan, dan percikan petir dari titik kena. */
    private static void punch(AbstractClientPlayer caster, Vec3 pos, boolean self) {
        ClientLevel level = (ClientLevel) caster.level();
        Vec3 dir = pos.subtract(caster.getEyePosition());
        dir = dir.lengthSqr() < 1.0E-4 ? caster.getViewVector(1f) : dir.normalize();
        Vfx.add(new Fx.Flash(pos, 1.3f, AMBER_LIGHT, 6, 0.9f));
        Vfx.add(new Fx.Ripple(pos, dir, 1.2, 0.2, 1.4, 0.18, GOLD_HOT, 7, 0.75f, false));
        for (int i = 0, n = Vfx.count(9); i < n; i++) {
            Vec3 v = ShazamFx.randomDir(level.random).add(dir.scale(0.9)).normalize().scale(0.2 + level.random.nextDouble() * 0.25);
            Vfx.spark(pos.x, pos.y, pos.z, v.x, v.y, v.z, i % 3 == 0 ? WHITE_HOT : AMBER_LIGHT, 0.05f, 8 + level.random.nextInt(6),
                    pos.y - 1.5);
        }
        arcsOut(level, pos, 2, 0.9, AMBER_LIGHT, 0.05f, 2);
        if (self) {
            CameraShake.add(0.08f);
        }
    }

    // ------------------------------------------------------------------ petir dari langit

    /** Petir tebal dari langit ke satu titik (hiasan): bercabang, berkedip, pendar lebar, kilatan di tanah. */
    static final class SkyBolt extends Effect {
        private final Vec3 at, top;
        private final float size;
        private final long seed = Vfx.random().nextLong();

        SkyBolt(Vec3 at, float size, int life) {
            super(life);
            this.at = at;
            this.size = size;
            RandomSource r = Vfx.random();
            this.top = at.add((r.nextDouble() - 0.5) * 6.0, 26.0 + r.nextDouble() * 10.0, (r.nextDouble() - 0.5) * 6.0);
        }

        @Override
        public void renderGlow(Draw d) {
            float t = progress(d.partialTick);
            float a = (age % 3 == 2 ? 0.45f : 1f) * (1f - t * t);
            if (a <= 0.01f) {
                return;
            }
            Random random = new Random(seed + age / 2 * 31L);
            float[] main = Lightning.path(top.x, top.y, top.z, at.x, at.y, at.z, 6, 0.12, random);
            int n = main.length / 3;
            d.polyline(main, n, 0.7f * size, 0.5f * size, AMBER, 0xFFFFFF, a, a);
            float old = d.body(0.3f);
            d.strip(main, n, 2.6f * size, 2.0f * size, AMBER, a * 0.2f, a * 0.24f);
            d.body(old);
            for (int b = 0; b < 3; b++) {
                int i = 4 + random.nextInt(Math.max(1, n - 10));
                double sx = main[i * 3], sy = main[i * 3 + 1], sz = main[i * 3 + 2];
                double len = (2.5 + random.nextDouble() * 4.0) * size;
                float[] br = Lightning.path(sx, sy, sz, sx + (random.nextDouble() - 0.5) * len, sy - len * 0.8,
                        sz + (random.nextDouble() - 0.5) * len, 3, 0.2, random);
                d.polyline(br, br.length / 3, 0.35f * size, 0.06f * size, AMBER, AMBER_LIGHT, a * 0.85f, 0f);
            }
            d.flare(at.x, at.y + 0.3, at.z, 1.6f * size, AMBER_LIGHT, a * 0.9f);
        }
    }

}
