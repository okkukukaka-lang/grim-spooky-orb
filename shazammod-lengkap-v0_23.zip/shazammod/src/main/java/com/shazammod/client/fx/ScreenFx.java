package com.shazammod.client.fx;

import java.util.Random;

import com.mojang.math.Axis;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

/**
 * Efek layar untuk pemain sendiri:
 * - garis kecepatan ala anime yang memusat ke tengah layar (terjangan, tepukan, sonic boom),
 * - vinyet berwarna di tepi layar (mengumpulkan tenaga, amarah, sihir).
 */
public final class ScreenFx {
    private ScreenFx() {}

    private static float lines, linesO;
    private static float vignette, vignetteO;
    private static float vignetteHold;
    private static int vignetteColor = 0x000000;
    private static int ticks;

    /** Garis kecepatan, 0-1. */
    public static void speedLines(float strength) {
        lines = Math.max(lines, strength);
    }

    /** Vinyet berwarna, 0-1, bertahan hold tick sebelum memudar. */
    public static void vignette(float strength, int rgb, int hold) {
        if (strength >= vignette) {
            vignetteColor = rgb;
        }
        vignette = Math.max(vignette, strength);
        vignetteHold = Math.max(vignetteHold, hold);
    }

    public static void clear() {
        lines = linesO = 0f;
        vignette = vignetteO = 0f;
        vignetteHold = 0;
    }

    public static void tick() {
        ticks++;
        linesO = lines;
        lines = Math.max(0f, lines - 0.07f);
        vignetteO = vignette;
        if (vignetteHold > 0) {
            vignetteHold--;
        } else {
            vignette = Math.max(0f, vignette - 0.05f);
        }
    }

    public static void render(GuiGraphics graphics, DeltaTracker deltaTracker) {
        float pt = deltaTracker.getGameTimeDeltaPartialTick(false);
        float v = Mth.lerp(pt, vignetteO, vignette);
        if (v > 0.01f) {
            drawVignette(graphics, v);
        }
        float s = Mth.lerp(pt, linesO, lines);
        if (s > 0.01f) {
            drawLines(graphics, s);
        }
    }

    private static void drawVignette(GuiGraphics g, float v) {
        int w = g.guiWidth(), h = g.guiHeight();
        int solid = ((int) (Mth.clamp(v, 0f, 1f) * 170f) << 24) | (vignetteColor & 0xFFFFFF);
        int clear = vignetteColor & 0xFFFFFF;
        int bandY = (int) (h * 0.28f), bandX = (int) (w * 0.22f);
        g.fillGradient(0, 0, w, bandY, solid, clear);           // atas
        g.fillGradient(0, h - bandY, w, h, clear, solid);       // bawah
        g.pose().pushPose();                                    // kiri (diputar supaya gradasinya mendatar)
        g.pose().translate(0f, h, 0f);
        g.pose().mulPose(Axis.ZP.rotationDegrees(-90f));
        g.fillGradient(0, 0, h, bandX, solid, clear);
        g.pose().popPose();
        g.pose().pushPose();                                    // kanan
        g.pose().translate(w, 0f, 0f);
        g.pose().mulPose(Axis.ZP.rotationDegrees(90f));
        g.fillGradient(0, 0, h, bandX, solid, clear);
        g.pose().popPose();
    }

    private static void drawLines(GuiGraphics g, float s) {
        int w = g.guiWidth(), h = g.guiHeight();
        float cx = w / 2f, cy = h / 2f;
        float outer = (float) Math.sqrt(cx * cx + cy * cy) + 4f;
        Random random = new Random(ticks / 2 * 1013L);   // pola berganti tiap 2 tick: garis berkedip
        int count = 54;
        for (int i = 0; i < count; i++) {
            float angle = random.nextFloat() * (float) (Math.PI * 2.0);
            float inner = outer * (0.38f + random.nextFloat() * 0.3f) * (1.15f - 0.25f * s);
            int thick = 1 + random.nextInt(3);
            int alpha = (int) (Mth.clamp(s, 0f, 1f) * (120 + random.nextInt(110)));
            g.pose().pushPose();
            g.pose().translate(cx, cy, 0f);
            g.pose().mulPose(Axis.ZP.rotation(angle));
            g.fillGradient(-thick, (int) inner, thick, (int) outer, 0x00FFFFFF, (alpha << 24) | 0xFFFFFF);
            g.pose().popPose();
        }
    }
}
