package com.shazammod.client.flight;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamFlightPayload;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.fx.CameraShake;
import com.shazammod.client.fx.AdamFx;
import com.shazammod.client.fx.ShazamFx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.Input;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.player.Abilities;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Terbang Shazam berbasis momentum (dihitung di client pemain sendiri). Geraknya mengikuti FlightModel:
 * dorongan melawan hambatan udara, belokan yang makin lebar saat kencang, menukik menambah kecepatan.
 * - double-tap spasi: lepas landas (melesat ke atas) / berhenti terbang,
 * - W: terbang ke arah pandangan; tahan sprint makin lama makin ngebut sampai sonic boom,
 * - S: mengerem, spasi/shift: naik-turun, A/D: geser di kecepatan rendah,
 * - double-tap A/D: barrel roll menghindar,
 * - menabrak dinding atau mendarat kencang memicu gelombang kejut.
 */
public final class ShazamFlight {
    private ShazamFlight() {}

    // ======= Angka-angka yang gampang diutak-atik (satuan blok per tick; x20 = blok per detik) =======
    // Kecepatan, dorongan, belokan, rem, dan hambatan udara ada di FlightModel
    private static final double SOUND_BARRIER = 3.4;     // tembus ini: sonic boom
    private static final double LAUNCH_UP = 1.15;        // dorongan saat lepas landas dari tanah
    private static final double ROLL_PUSH = 0.9;
    private static final int ROLL_TICKS = 10;
    private static final int ROLL_COOLDOWN = 16;
    private static final int DOUBLE_TAP = 7;
    private static final double HERO_LANDING_SPEED = 1.0;
    private static final double HERO_FALL_SPEED = 1.0;
    private static final double CRASH_SPEED = 2.2;
    private static final double DASH_SPEED = 1.9;
    // ==================================================================================================

    private static boolean active;
    private static boolean wasFlying;
    private static boolean wasOnGround = true;
    private static Vec3 velocity = Vec3.ZERO;
    private static final FlightModel MODEL = new FlightModel();
    private static boolean supersonic;
    private static int ticks;
    private static int lastGroundTick = -100;
    private static int rollTicks;
    private static int rollCooldown;
    private static int rollDir;
    private static int lastLeftTap = -100;
    private static int lastRightTap = -100;
    private static boolean leftDown;
    private static boolean rightDown;
    private static int dashTicks;
    private static Vec3 dashDir = Vec3.ZERO;
    private static double airFallSpeed;
    private static WindSound wind;

    public static boolean isFlying() {
        return active && wasFlying;
    }

    public static double speed() {
        return velocity.length();
    }

    /** Sebelum gerak pemain dihitung: atur kecepatan terbang. */
    public static void preTick(LocalPlayer player) {
        ticks++;
        if (!ShazamClientState.isTransformed(player.getId())) {
            if (active) {
                reset(player);
            }
            return;
        }
        active = true;
        Abilities abilities = player.getAbilities();
        if (abilities.getFlyingSpeed() != 0f) {
            abilities.setFlyingSpeed(0f); // fisika terbang bawaan dimatikan; geraknya diatur di sini
        }
        if (player.onGround()) {
            lastGroundTick = ticks;
            airFallSpeed = 0;
        }
        if (!abilities.flying) {
            if (!player.onGround()) {
                airFallSpeed = Math.min(airFallSpeed, player.getDeltaMovement().y);
            }
            return;
        }
        if (rollCooldown > 0) {
            rollCooldown--;
        }
        checkRollTaps(player);

        // Tabrakan dari gerak tick sebelumnya (sumbu yang menabrak sudah dinolkan oleh game)
        Vec3 moved = player.getDeltaMovement();
        double horizontal = Math.sqrt(velocity.x * velocity.x + velocity.z * velocity.z);
        if (player.horizontalCollision) {
            if (horizontal >= CRASH_SPEED) {
                crash(player, horizontal);
            } else {
                velocity = new Vec3(moved.x == 0.0 ? 0.0 : velocity.x, velocity.y, moved.z == 0.0 ? 0.0 : velocity.z);
            }
        }
        if (player.verticalCollision && moved.y == 0.0 && velocity.y > 0.0) {
            velocity = new Vec3(velocity.x, 0.0, velocity.z);
        }

        velocity = step(player);
        player.setDeltaMovement(velocity);
        player.fallDistance = 0f;

        double speed = velocity.length();
        if (!supersonic && speed >= SOUND_BARRIER) {
            supersonic = true;
            sonicBoom(player);
        } else if (supersonic && speed < SOUND_BARRIER * 0.85) {
            supersonic = false;
        }
        if (supersonic) {
            CameraShake.add(0.012f);
        }
        if (speed > 0.5 && (wind == null || wind.isStopped())) {
            wind = new WindSound(player);
            Minecraft.getInstance().getSoundManager().play(wind);
        }
    }

    /** Setelah gerak dihitung: deteksi lepas landas dan mendarat. */
    public static void postTick(LocalPlayer player) {
        if (!active) {
            wasOnGround = player.onGround();
            return;
        }
        boolean flying = player.getAbilities().flying;
        if (flying && !wasFlying) {
            takeOff(player);
        } else if (!flying && wasFlying) {
            land(player);
        } else if (!flying && player.onGround() && !wasOnGround && -airFallSpeed >= HERO_FALL_SPEED) {
            heroLanding(player, -airFallSpeed); // jatuh dari tinggi tanpa terbang
        }
        if (player.onGround()) {
            airFallSpeed = 0;
        }
        wasFlying = flying;
        wasOnGround = player.onGround();
    }

    private static Vec3 step(LocalPlayer player) {
        if (dashTicks > 0) {
            dashTicks--;
            return dashDir.scale(DASH_SPEED); // Kilat Mercury saat terbang
        }
        Input input = player.input;
        int vertical = (input.jumping ? 1 : 0) - (input.shiftKeyDown ? 1 : 0);
        boolean sprint = Minecraft.getInstance().options.keySprint.isDown() || player.isSprinting();
        Vec3 look = player.getViewVector(1f);
        MODEL.heavy = ShazamClientState.isAdam(player.getId());   // Black Adam: terbang lebih berat & lugas
        MODEL.set(velocity.x, velocity.y, velocity.z);
        MODEL.step(input.forwardImpulse, input.leftImpulse, vertical, sprint, look.x, look.y, look.z);
        Vec3 v = new Vec3(MODEL.vx, MODEL.vy, MODEL.vz);
        if (rollTicks > 0) {
            Vec3 flat = new Vec3(look.x, 0, look.z);
            flat = flat.lengthSqr() < 1.0E-6 ? Vec3.ZERO : flat.normalize();
            Vec3 right = new Vec3(-flat.z, 0, flat.x);
            v = v.add(right.scale(rollDir * ROLL_PUSH * rollTicks / (double) ROLL_TICKS));
            rollTicks--;
        }
        double max = FlightModel.MAX_SPEED;
        return v.lengthSqr() > max * max ? v.normalize().scale(max) : v;
    }

    private static void checkRollTaps(LocalPlayer player) {
        Minecraft mc = Minecraft.getInstance();
        boolean left = mc.options.keyLeft.isDown();
        boolean right = mc.options.keyRight.isDown();
        if (left && !leftDown) {
            if (ticks - lastLeftTap <= DOUBLE_TAP) {
                roll(player, -1);
            }
            lastLeftTap = ticks;
        }
        if (right && !rightDown) {
            if (ticks - lastRightTap <= DOUBLE_TAP) {
                roll(player, 1);
            }
            lastRightTap = ticks;
        }
        leftDown = left;
        rightDown = right;
    }

    private static void roll(LocalPlayer player, int dir) {
        if (rollCooldown > 0) {
            return;
        }
        rollDir = dir;
        rollTicks = ROLL_TICKS;
        rollCooldown = ROLL_COOLDOWN;
        lastLeftTap = -100;
        lastRightTap = -100;
        ShazamAnim anim = dir > 0 ? ShazamAnim.ROLL_RIGHT : ShazamAnim.ROLL_LEFT;
        play(player, anim);
        send(dir > 0 ? ShazamFlightPayload.ROLL_RIGHT : ShazamFlightPayload.ROLL_LEFT, 0f);
    }

    private static void takeOff(LocalPlayer player) {
        MODEL.boost = 0.0;
        supersonic = false;
        if (ticks - lastGroundTick <= 8) {
            // Lepas landas dari tanah: jongkok sebentar lalu melesat ke atas
            Vec3 look = player.getViewVector(1f);
            velocity = new Vec3(look.x * 0.3, LAUNCH_UP, look.z * 0.3);
            play(player, ShazamAnim.LAUNCH);
            send(ShazamFlightPayload.LAUNCH, 0f);
        } else {
            velocity = player.getDeltaMovement();
        }
    }

    private static void land(LocalPlayer player) {
        double speed = velocity.length();
        if (player.onGround()) {
            if (speed >= HERO_LANDING_SPEED && velocity.y < -0.3) {
                heroLanding(player, speed);
            } else {
                play(player, ShazamAnim.LAND_SOFT);
                send(ShazamFlightPayload.LAND_SOFT, (float) speed);
            }
        }
        velocity = Vec3.ZERO;
        MODEL.boost = 0.0;
        supersonic = false;
        dashTicks = 0;
    }

    private static void heroLanding(LocalPlayer player, double speed) {
        play(player, ShazamAnim.LAND_HERO);
        send(ShazamFlightPayload.LAND_HERO, (float) speed);
        airFallSpeed = 0;
    }

    private static void crash(LocalPlayer player, double speed) {
        play(player, ShazamAnim.CRASH);
        send(ShazamFlightPayload.CRASH, (float) speed);
        velocity = Vec3.ZERO;
        MODEL.boost = 0.0;
    }

    private static void sonicBoom(LocalPlayer player) {
        play(player, ShazamAnim.SONIC_BOOM);
        send(ShazamFlightPayload.SONIC_BOOM, (float) velocity.length());
    }

    /** Kecepatan diatur pihak lain (Mode Kilat Mercury menerjang musuh sambil terbang): terbang lanjut dari situ. */
    public static void override(Vec3 v) {
        velocity = v;
        dashTicks = 0;
    }

    /** Kilat Mercury saat sedang terbang: menerjang ke arah pandangan. */
    public static void dash(LocalPlayer player) {
        if (active && player.getAbilities().flying) {
            dashDir = player.getViewVector(1f).normalize();
            dashTicks = ShazamAnim.BLITZ_TICKS;
        }
    }

    private static void play(LocalPlayer player, ShazamAnim anim) {
        ShazamPoses.start(player, anim);
        ShazamFx.onAnim(player, anim, player.position());
        AdamFx.onAnim(player, anim, player.position());   // Black Adam: lepas landas, mendarat, & sonic boom versi membara
    }

    private static void send(int action, float speed) {
        PacketDistributor.sendToServer(new ShazamFlightPayload(action, speed));
    }

    public static void reset(LocalPlayer player) {
        if (player != null && player.getAbilities().getFlyingSpeed() == 0f) {
            player.getAbilities().setFlyingSpeed(0.05f); // kembalikan terbang kreatif biasa
        }
        active = false;
        wasFlying = false;
        velocity = Vec3.ZERO;
        MODEL.boost = 0.0;
        supersonic = false;
        rollTicks = 0;
        dashTicks = 0;
        airFallSpeed = 0;
    }
}
