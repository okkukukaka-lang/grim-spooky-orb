package com.shazammod.client.fx;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.ShazamClientState;
import com.shazammod.client.vfx.Draw;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Avatar Dewa (Shazam 0.23): identitas yang cuma dimiliki Shazam. Tiap skill memanggil dewanya sebagai raksasa cahaya
 * tembus pandang (±4 blok) yang berdiri di belakang Shazam dan ikut bergerak: Solomon membuka kitab dan mengangkat segel,
 * Hercules melompat lalu menghantamkan gada tepat saat tepukan, Atlas mengangkat bola langit, Zeus mengarahkan petirnya ke
 * sasaran, Achilles menusukkan tombak. Saat Badai Para Dewa (R), keenam dewa berdiri melingkar mengelilingi Shazam, berputar
 * pelan, dan menerjang tiap kali giliran serangannya tiba.
 *
 * Bentuk & cahaya dewanya sama dengan roh dewa saat transformasi (GodFigures, GodLook), digambar lewat ShazamSpirits.
 * Gerakannya memakai pose yang sama: tau (gerak masuk tiap dewa), converge (pusaka diarahkan ke sasaran), dan aim.
 * Dari sudut pandang orang pertama, avatar skill pindah ke samping-depan supaya tetap kelihatan.
 */
public final class GodAvatars {
    private GodAvatars() {}

    // ======= Angka yang gampang diutak-atik =======
    /** false = avatar dewa saat skill dimatikan (roh dewa saat transformasi tetap ada). */
    public static final boolean ENABLED = true;
    /** Lebih jauh dari ini (blok) avatar nggak digambar. */
    private static final double DRAW_DISTANCE = 80.0;
    /** Kepekatan avatar skill, lingkaran Badai Para Dewa, dan pengali dari sudut pandang orang pertama. */
    private static final float SKILL_ALPHA = 0.92f;
    private static final float RING_ALPHA = 0.6f;
    private static final float FIRST_PERSON_ALPHA = 0.7f;
    /** Jari-jari lingkaran enam dewa (blok, dikali ukuran pemain) dan kecepatan putarnya (radian/tick). */
    private static final double RING_RADIUS = 3.8;
    private static final double RING_SPIN = 0.013;
    private static final int MAX = 16;

    /** Satu avatar. Angka posisi dalam blok (dikali ukuran pemain); waktu dalam tick sejak avatar dipanggil. */
    static final class Avatar {
        final int owner;
        final int god;
        final long start;
        final int life;
        final boolean ring;
        /** Posisi relatif pemain: ke kanan (+), ke belakang (+), ke atas. */
        double side;
        double back = 1.6;
        double lift;
        /** Melompat masuk: mulai setinggi hop, mendarat di tick hopUntil. */
        double hop;
        int hopUntil;
        float scaleMul = 1.3f;
        /** Pose masuk dewa (lihat GodFigures): tau = tau0 + umur x tauRate, paling banyak tauMax. */
        float tau0 = 40f;
        float tauRate;
        float tauMax = 60f;
        /** Pusaka diarahkan ke sasaran: naik dari convergeAt selama convergeLen, turun lagi sesudah convergeEnd. */
        float convergeTo;
        int convergeAt;
        int convergeLen = 4;
        int convergeEnd = Integer.MAX_VALUE;
        /** Sasaran di dunia (null = titik aimAhead blok di depan pemain). */
        Vec3 aim;
        double aimAhead = 6.0;
        long strikeTime = -1000L;
        Vec3 strikeAim;
        boolean released;
        long releaseTime;
        long dismissAt = Long.MAX_VALUE / 4;
        final GodShow.State state = new GodShow.State();
        final GodMesh mesh = new GodMesh();
        double ox, oy, oz;
        float vis;

        Avatar(int owner, int god, long start, int life, boolean ring) {
            this.owner = owner;
            this.god = god;
            this.start = start;
            this.life = life;
            this.ring = ring;
        }
    }

    private static final List<Avatar> AVATARS = new ArrayList<>();

    /** Panggil avatar satu dewa (0-5, lihat GodFigures) untuk skill; pengaturan posisi & pose diisi pemanggil. */
    static Avatar summon(AbstractClientPlayer owner, int god, int life) {
        long now = owner.level().getGameTime();
        AVATARS.removeIf(a -> a.owner == owner.getId() && a.god == god && !a.ring);
        while (AVATARS.size() >= MAX) {
            AVATARS.remove(0);
        }
        Avatar a = new Avatar(owner.getId(), god, now, life, false);
        AVATARS.add(a);
        return a;
    }

    /** Badai Para Dewa: keenam dewa berdiri melingkar mengelilingi pemain, datang berurutan S-H-A-Z-A-M. */
    static void ring(AbstractClientPlayer owner) {
        long now = owner.level().getGameTime();
        AVATARS.removeIf(a -> a.owner == owner.getId() && a.ring);
        for (int i = 0; i < GodFigures.COUNT; i++) {
            Avatar a = new Avatar(owner.getId(), i, now + i * 2L, 20 * 60, true);
            a.scaleMul = 1.0f;
            a.tau0 = 40f;
            AVATARS.add(a);
        }
    }

    /** Dewa di lingkaran menerjang ke sasaran (giliran serangannya di Badai Para Dewa). */
    static void strike(AbstractClientPlayer owner, int god, Vec3 target) {
        long now = owner.level().getGameTime();
        for (Avatar a : AVATARS) {
            if (a.ring && a.owner == owner.getId() && a.god == god) {
                a.strikeTime = now;
                a.strikeAim = target;
            }
        }
    }

    /** Dada dewa di lingkaran (asal serangannya), atau dada pemain kalau dewanya nggak tampak. */
    static Vec3 focus(AbstractClientPlayer owner, int god) {
        for (Avatar a : AVATARS) {
            if (a.ring && a.owner == owner.getId() && a.god == god && a.vis > 0.05f) {
                return new Vec3(a.ox, a.oy + a.state.scale * 1.35, a.oz);
            }
        }
        return owner.position().add(0, 1.3 * owner.getScale(), 0);
    }

    /** Balik jadi manusia: semua avatar pemain ini memudar. */
    static void dismiss(AbstractClientPlayer owner) {
        long now = owner.level().getGameTime();
        for (Avatar a : AVATARS) {
            if (a.owner == owner.getId()) {
                a.dismissAt = Math.min(a.dismissAt, now);
                if (a.ring && !a.released) {
                    a.released = true;
                    a.releaseTime = now;
                }
            }
        }
    }

    public static void clear() {
        AVATARS.clear();
    }

    public static void tick(ClientLevel level) {
        long now = level.getGameTime();
        Iterator<Avatar> it = AVATARS.iterator();
        while (it.hasNext()) {
            Avatar a = it.next();
            if (!(level.getEntity(a.owner) instanceof AbstractClientPlayer) || !ShazamClientState.isTransformed(a.owner)) {
                it.remove();
                continue;
            }
            // lingkaran dewa pergi saat amarahnya habis (beri jeda: status amarah bisa tiba sedikit sesudah animasinya)
            if (a.ring && !a.released && now - a.start > 20 && !ShazamClientState.isRaging(a.owner)) {
                a.released = true;
                a.releaseTime = now;
            }
            boolean expired = a.ring ? a.released && now - a.releaseTime > 14
                    : now - a.start > a.life + 2 || now > a.dismissAt + 8;
            if (expired) {
                it.remove();
            }
        }
    }

    // ------------------------------------------------------------------ gambar

    static void render(RenderLevelStageEvent event) {
        if (!ENABLED || AVATARS.isEmpty()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) {
            return;
        }
        float pt = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        Vec3 cam = event.getCamera().getPosition();
        PoseStack.Pose pose = event.getPoseStack().last();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        double time = level.getGameTime() + pt;
        List<Avatar> shown = new ArrayList<>();
        for (Avatar a : AVATARS) {
            if (level.getEntity(a.owner) instanceof AbstractClientPlayer owner && !owner.isInvisible() && place(a, owner, time, pt)) {
                double dx = a.ox - cam.x, dy = a.oy - cam.y, dz = a.oz - cam.z;
                if (dx * dx + dy * dy + dz * dz < DRAW_DISTANCE * DRAW_DISTANCE) {
                    shown.add(a);
                }
            }
        }
        if (shown.isEmpty()) {
            return;
        }
        // dari yang terjauh (tembus pandang)
        shown.sort((x, y) -> Double.compare(distanceSqr(y, cam), distanceSqr(x, cam)));
        for (Avatar a : shown) {
            GodFigures.build(a.god, a.state.pose, a.mesh);
            ShazamSpirits.avatarBody(a.mesh, a.state, a.ox, a.oy, a.oz, a.god, cam, pose, buffers);
        }
        RenderType additive = Draw.additiveType();
        VertexConsumer add = buffers.getBuffer(additive);
        Draw draw = new Draw(pose, cam, pt);
        draw.begin(add, true);
        for (Avatar a : shown) {
            ShazamSpirits.avatarExtras(a.god, a.mesh, a.state, a.ox, a.oy, a.oz, cam, draw);
        }
        buffers.endBatch(additive);
    }

    private static double distanceSqr(Avatar a, Vec3 cam) {
        double dx = a.ox - cam.x, dy = a.oy + 1.5 - cam.y, dz = a.oz - cam.z;
        return dx * dx + dy * dy + dz * dz;
    }

    private static float smooth(double v) {
        float f = (float) Mth.clamp(v, 0.0, 1.0);
        return f * f * (3f - 2f * f);
    }

    /** Hitung posisi, arah, dan pose avatar saat ini. false = nggak tampak. */
    private static boolean place(Avatar a, AbstractClientPlayer owner, double time, float pt) {
        double age = time - a.start;
        if (age < 0) {
            return false;
        }
        float in = smooth(age / 5.0);
        float out = a.ring
                ? (a.released ? smooth(1.0 - (time - a.releaseTime) / 12.0) : 1f)
                : Math.min(smooth((a.life - age) / 9.0), smooth((a.dismissAt + 6 - time) / 6.0));
        float vis = in * out;
        a.vis = vis;
        if (vis <= 0.01f) {
            return false;
        }
        Minecraft mc = Minecraft.getInstance();
        boolean firstPerson = owner == mc.player && mc.options.getCameraType().isFirstPerson();
        double sc = owner.getScale();
        Vec3 p = owner.getPosition(pt);
        Vec3 look = owner.getViewVector(pt);
        double fx = look.x, fz = look.z;
        double fl = Math.sqrt(fx * fx + fz * fz);
        if (fl < 1.0E-4) {
            double yaw = Math.toRadians(owner.getYRot());
            fx = -Math.sin(yaw);
            fz = Math.cos(yaw);
        } else {
            fx /= fl;
            fz /= fl;
        }
        double rx = -fz, rz = fx;   // kanan pemain
        double faceX, faceZ;
        float strike = 0f;
        Vec3 aim = a.aim;
        if (a.ring) {
            double angle = a.god * Math.PI * 2.0 / GodFigures.COUNT + (time - a.start) * RING_SPIN;
            double radius = RING_RADIUS * sc;
            a.ox = p.x + Math.cos(angle) * radius;
            a.oz = p.z + Math.sin(angle) * radius;
            a.oy = p.y + 0.2 * sc + Math.sin(time * 0.07 + a.god) * 0.12;
            faceX = Math.cos(angle);   // menghadap keluar: menjaga Shazam dari segala arah
            faceZ = Math.sin(angle);
            double since = time - a.strikeTime;
            if (since >= 0 && since < 14 && a.strikeAim != null) {
                strike = (float) Math.sin(Math.PI * since / 14.0);
                aim = a.strikeAim;
                double tx = aim.x - a.ox, tz = aim.z - a.oz;
                double tl = Math.sqrt(tx * tx + tz * tz) + 1.0E-6;
                a.ox += tx / tl * strike * 0.9;   // menerjang sedikit ke arah sasaran
                a.oz += tz / tl * strike * 0.9;
                faceX = Mth.lerp(strike, faceX, tx / tl);
                faceZ = Mth.lerp(strike, faceZ, tz / tl);
            }
            if (aim == null) {
                aim = new Vec3(a.ox + faceX * 4.0, a.oy + 1.5 * sc, a.oz + faceZ * 4.0);
            }
        } else {
            double side = a.side, back = a.back;
            if (firstPerson) {   // dari mata sendiri: avatar di samping-depan supaya tetap kelihatan
                side = (a.side >= 0 ? 1.0 : -1.0) * Math.max(2.4, Math.abs(a.side) + 0.8);
                back = -1.2;
            }
            double hop = 0.0;
            if (a.hop > 0 && age < a.hopUntil) {
                double u = age / Math.max(1, a.hopUntil);
                hop = a.hop * (1.0 - u * u);
            }
            a.ox = p.x - fx * back * sc + rx * side * sc;
            a.oz = p.z - fz * back * sc + rz * side * sc;
            a.oy = p.y + (a.lift + hop) * sc;
            if (aim == null) {
                aim = p.add(fx * a.aimAhead, 1.2 * sc, fz * a.aimAhead);
            }
            faceX = aim.x - a.ox;
            faceZ = aim.z - a.oz;
            if (faceX * faceX + faceZ * faceZ < 1.0E-4) {
                faceX = fx;
                faceZ = fz;
            }
        }
        GodShow.State s = a.state;
        s.visible = true;
        s.x = 0;
        s.y = 0;
        s.z = 0;
        s.yaw = Math.atan2(faceX, faceZ);
        s.scale = GodFigures.SCALE[a.god] * a.scaleMul * sc;
        s.appear = 1f;
        s.halo = vis;
        s.mist = 0f;
        s.beam = 0f;
        s.trail = 0f;
        GodLook.Mask k = s.mask.reset();
        k.alpha = vis * (a.ring ? RING_ALPHA : SKILL_ALPHA) * (firstPerson && !a.ring ? FIRST_PERSON_ALPHA : 1f);
        float arrive = (float) Math.max(0.0, 1.0 - age / 6.0);
        k.flash = Math.min(1f, arrive * 0.75f + strike * 0.7f);
        k.boost = 1.15f + strike * 0.8f;
        GodFigures.Pose pose = s.pose;
        pose.time = (float) time;
        pose.tau = Math.min(a.tauMax, a.tau0 + (float) age * a.tauRate);
        float converge = 0f;
        if (a.convergeTo > 0f) {
            converge = a.convergeTo * smooth((age - a.convergeAt) / Math.max(1, a.convergeLen));
            if (age > a.convergeEnd) {
                converge *= 1f - smooth((age - a.convergeEnd) / 5.0);
            }
        }
        pose.converge = Math.max(converge, strike);
        double[] local = new double[3];
        GodLook.toLocal(s, a.ox, a.oy, a.oz, aim.x, aim.y, aim.z, local);
        pose.aimX = (float) local[0];
        pose.aimY = (float) local[1];
        pose.aimZ = (float) local[2];
        return true;
    }
}
