package com.shazammod.client.render;

import com.shazammod.ShazamClientState;
import com.shazammod.ShazamForm;
import com.shazammod.ShazamMod;

import net.minecraft.resources.ResourceLocation;

/**
 * Warna & gambar kostum tiap juara. Bentuk jubah, mantel, hood, list, pelat bahu, dan bros sama; yang beda bahannya:
 *
 * Shazam     : kain putih, lapisan dalam biru tua, emas cerah, permata putih, lambang kilat bintang.
 * Black Adam : kain hitam legam (hood & jubah juara Kahndaq), lapisan dalam merah marun tua, emas antik yang lebih
 *              jingga, permata pirus seperti perhiasan firaun, lambang petir emas tajam.
 */
public final class FormLook {
    /** Warna kain luar (dikali tekstur kain). */
    public final int cloth;
    /** Lapisan dalam jubah & hood. */
    public final int lining;
    /** Emas list & aksesoris: utama, tepi luar berkilau, tepi dalam berbayang, celah gelap. */
    public final int[] gold, goldEdge, goldShade, goldDark;
    /** Permata & paku keling (terang sendiri). */
    public final int[] gem;
    /** Butiran cahaya saat kain lenyap, dan kilau putihnya. */
    public final int dissolve, dissolveHot;
    /** Kilau aditif saat kain terbentuk/lenyap (RGB 0-255). */
    public final int[] weave;
    /** Kilau lambang: kilatan menyapu & pendar di sekitarnya (RGB 0-255). */
    public final int[] emblemSweep, emblemHalo;
    /** Percikan kecil dari lambang dada. */
    public final int sparkle;
    /** Kilau kostum saat terbentuk (SuitRevealLayer), RGB 0-255. */
    public final int[] suitShimmer;
    /** Lambang dada & lambang punggung jubah. */
    public final ResourceLocation emblem, backEmblem;
    /** 0 = Shazam, 1 = Black Adam (indeks cache gambar). */
    public final int index;

    private FormLook(int index, int cloth, int lining, int[] gold, int[] goldEdge, int[] goldShade, int[] goldDark, int[] gem,
                     int dissolve, int dissolveHot, int[] weave, int[] emblemSweep, int[] emblemHalo, int sparkle,
                     int[] suitShimmer, ResourceLocation emblem, ResourceLocation backEmblem) {
        this.index = index;
        this.cloth = cloth;
        this.lining = lining;
        this.gold = gold;
        this.goldEdge = goldEdge;
        this.goldShade = goldShade;
        this.goldDark = goldDark;
        this.gem = gem;
        this.dissolve = dissolve;
        this.dissolveHot = dissolveHot;
        this.weave = weave;
        this.emblemSweep = emblemSweep;
        this.emblemHalo = emblemHalo;
        this.sparkle = sparkle;
        this.suitShimmer = suitShimmer;
        this.emblem = emblem;
        this.backEmblem = backEmblem;
    }

    public static final FormLook SHAZAM = new FormLook(0,
            0xFFFFFF, 0x2E3458,
            new int[] {242, 194, 66}, new int[] {255, 228, 128}, new int[] {184, 134, 36}, new int[] {150, 105, 30},
            new int[] {255, 248, 222},
            0xFFD978, 0xFFF4D0,
            new int[] {255, 205, 110}, new int[] {255, 250, 225}, new int[] {255, 205, 90}, 0xFFF0C0,
            new int[] {255, 215, 90},
            ShazamMod.id("textures/entity/shazam_emblem.png"), ShazamMod.id("textures/entity/shazam_cape_emblem.png"));

    public static final FormLook BLACK_ADAM = new FormLook(1,
            0x2B272C, 0x3A1216,
            new int[] {222, 160, 44}, new int[] {255, 206, 104}, new int[] {150, 98, 24}, new int[] {92, 58, 14},
            new int[] {72, 226, 206},
            0xFFB347, 0xFFE2A8,
            new int[] {255, 168, 60}, new int[] {255, 236, 190}, new int[] {255, 160, 40}, 0xFFD27A,
            new int[] {255, 165, 50},
            ShazamMod.id("textures/entity/adam_emblem.png"), ShazamMod.id("textures/entity/adam_cape_emblem.png"));

    public static FormLook of(ShazamForm form) {
        return form == ShazamForm.BLACK_ADAM ? BLACK_ADAM : SHAZAM;
    }

    /** Kostum pemain ini (dari status juara yang dikirim server). */
    public static FormLook of(int entityId) {
        return of(ShazamClientState.form(entityId));
    }
}
