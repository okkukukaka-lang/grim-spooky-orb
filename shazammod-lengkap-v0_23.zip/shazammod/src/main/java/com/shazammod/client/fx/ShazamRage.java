package com.shazammod.client.fx;

import java.util.HashMap;
import java.util.Map;

import com.shazammod.ShazamClientState;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * Zeus Rage (dan Murka Kahndaq milik Black Adam, dengan warna emas membara) di sisi client: terang-redupnya mata putih, busur listrik kecil dari mata, listrik yang merayap
 * di seluruh badan, dan batu-batu kecil yang terangkat mengorbit di sekeliling selama amarah menyala.
 * Semuanya mengikuti status amarah, jadi pemain lain yang baru melihat juga mendapat efeknya.
 */
public final class ShazamRage {
    private ShazamRage() {}

    private static final Map<Integer, float[]> GLOW = new HashMap<>();   // {tick lalu, sekarang}
    private static final Map<Integer, Lightning.Crackle> CRACKLE = new HashMap<>();
    private static final Map<Integer, Ground.Orbit> ROCKS = new HashMap<>();

    public static void clear() {
        GLOW.clear();
        CRACKLE.clear();
        ROCKS.clear();
    }

    /** 0 = mata normal, 1 = putih menyala penuh. */
    public static float glow(AbstractClientPlayer player, float partialTick) {
        float[] g = GLOW.get(player.getId());
        return g == null ? 0f : Mth.lerp(partialTick, g[0], g[1]);
    }

    public static void tick(ClientLevel level) {
        Minecraft mc = Minecraft.getInstance();
        GLOW.keySet().removeIf(id -> !(level.getEntity(id) instanceof AbstractClientPlayer));
        for (AbstractClientPlayer player : level.players()) {
            boolean raging = ShazamClientState.isRaging(player.getId()) && ShazamClientState.isTransformed(player.getId());
            float[] g = GLOW.get(player.getId());
            if (g == null) {
                if (!raging) {
                    continue;
                }
                g = new float[2];
                GLOW.put(player.getId(), g);
            }
            g[0] = g[1];
            g[1] = Mth.approach(g[1], raging ? 1f : 0f, raging ? 0.25f : 0.08f);   // menyala cepat, padam pelan
            if (!raging && g[1] <= 0f) {
                GLOW.remove(player.getId());
                stop(player.getId());
                continue;
            }
            float strength = g[1];
            // listrik di badan dan batu yang mengorbit (dibuat sekali, kekuatannya mengikuti amarah)
            Lightning.Crackle crackle = CRACKLE.get(player.getId());
            int color = color(player);
            boolean adam = ShazamClientState.isAdam(player.getId());
            if (raging && (crackle == null || !crackle.active())) {
                // Murka Kahndaq: listrik lebih tebal & rapat, busurnya lebih panjang (Black Adam lebih buas)
                crackle = new Lightning.Crackle(player, color, adam ? 2.6f : 1.2f, adam ? 0.07f : 0.045f, 20 * 60);
                if (adam) {
                    crackle.reach(1.25);
                }
                CRACKLE.put(player.getId(), crackle);
                Vfx.add(crackle);
            }
            if (crackle != null) {
                crackle.strength(strength);
            }
            Ground.Orbit rocks = ROCKS.get(player.getId());
            if (raging && (rocks == null || !rocks.active()) && !player.isInvisible()) {
                BlockState below = level.getBlockState(player.blockPosition().below());
                int id = player.getId();
                rocks = new Ground.Orbit(player, below, adam ? 12 : 7, 20 * 60, () -> {
                    float[] gg = GLOW.get(id);
                    return gg == null ? 0f : gg[1];
                });
                ROCKS.put(player.getId(), rocks);
                Vfx.add(rocks);
            }
            if (strength < 0.5f || player.isInvisible()) {
                continue;
            }
            boolean firstPerson = player == mc.player && mc.options.getCameraType().isFirstPerson();
            if (!firstPerson && level.random.nextInt(2) == 0) {
                // busur listrik kecil dari mata
                Vec3 eye = player.getEyePosition().add(player.getViewVector(1f).scale(0.3));
                Vec3 end = eye.add((level.random.nextDouble() - 0.5) * 0.7, (level.random.nextDouble() - 0.2) * 0.5,
                        (level.random.nextDouble() - 0.5) * 0.7);
                Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(eye), Lightning.Anchor.fixed(end), color,
                        0.025f, 2, 1, 0, 0.35));
            }
        }
        // bersihkan efek pemain yang sudah nggak terlihat
        CRACKLE.keySet().removeIf(id -> {
            if (!GLOW.containsKey(id)) {
                CRACKLE.get(id).stop();
                return true;
            }
            return false;
        });
        ROCKS.keySet().removeIf(id -> {
            if (!GLOW.containsKey(id)) {
                ROCKS.get(id).stop();
                return true;
            }
            return false;
        });
    }

    /** Warna listrik amarah: putih kebiruan (Zeus Rage) atau emas membara (Murka Kahndaq, Black Adam). */
    private static int color(AbstractClientPlayer player) {
        return ShazamClientState.isAdam(player.getId()) ? AdamFx.AMBER_LIGHT : ShazamFx.STORM;
    }

    private static void stop(int id) {
        Lightning.Crackle crackle = CRACKLE.remove(id);
        if (crackle != null) {
            crackle.stop();
        }
        Ground.Orbit rocks = ROCKS.remove(id);
        if (rocks != null) {
            rocks.stop();
        }
    }
}
