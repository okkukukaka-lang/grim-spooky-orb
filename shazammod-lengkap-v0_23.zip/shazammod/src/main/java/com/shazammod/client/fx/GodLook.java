package com.shazammod.client.fx;

/**
 * Warna roh dewa per titik (murni Java). Tiap dewa digambar tiga lapis:
 * 1) kedalaman saja (supaya cuma permukaan terdepan yang kelihatan, nggak tembus ke dalam badan sendiri),
 * 2) isi tembus pandang: warna bahan dengan cahaya lembut dari atas, makin pekat di tepi (seperti patung kaca),
 * 3) cahaya aditif: tepi bersinar warna dewanya (fresnel), bagian yang menyala sendiri (mahkota, petir, halaman
 *    kitab), dan aliran energi yang bergerak naik pelan.
 * Plus pernik cahaya (mata, lingkaran suci di belakang kepala, kabut di kaki, segel, bintang, sinar ke kepalan).
 */
public final class GodLook {
    private GodLook() {}

    // ======= Angka yang gampang diutak-atik =======
    private static final double TINT = 0.16;          // seberapa kuat warna dewa mewarnai badan
    private static final double CORE_ALPHA = 0.6;    // kepekatan bagian tengah (menghadap kamera)
    private static final double RIM_ALPHA = 0.4;     // tambahan kepekatan di tepi
    private static final double RIM_GLOW = 0.95;      // terang cahaya tepi
    private static final double INNER_GLOW = 0.07;    // cahaya samar di seluruh badan
    private static final double LX = 0.32, LY = 0.85, LZ = 0.42;   // arah cahaya kunci (ruang dewa)

    /** Cara roh muncul/hilang. */
    public static final class Mask {
        /** Kepekatan keseluruhan 0..1. */
        public float alpha = 1f;
        /** Muncul dari bawah ke atas: terlihat di bawah ketinggian ini (ruang dewa). NaN = mati. */
        public float scanY = Float.NaN;
        /** Muncul dari atas ke bawah: terlihat di atas ketinggian ini (ruang dewa). NaN = mati. */
        public float scanTop = Float.NaN;
        public float scanBand = 0.14f;
        /** Terbakar muncul (bercak dari kaki ke kepala), 0..1. NaN = mati. */
        public float burn = Float.NaN;
        /** Yang di bawah tanah (ruang dewa) tidak terlihat. NaN = mati. */
        public float groundY = Float.NaN;
        /** 0..1: putih menyilaukan (baru disambar petir). */
        public float flash;
        /** Pengali cahaya. */
        public float boost = 1f;
        /** Warna tepi yang sedang muncul. */
        public int edge = 0xFFFFFF;

        public Mask reset() {
            alpha = 1f;
            scanY = Float.NaN;
            scanTop = Float.NaN;
            scanBand = 0.14f;
            burn = Float.NaN;
            groundY = Float.NaN;
            flash = 0f;
            boost = 1f;
            edge = 0xFFFFFF;
            return this;
        }

        public Mask set(Mask o) {
            alpha = o.alpha;
            scanY = o.scanY;
            scanTop = o.scanTop;
            scanBand = o.scanBand;
            burn = o.burn;
            groundY = o.groundY;
            flash = o.flash;
            boost = o.boost;
            edge = o.edge;
            return this;
        }
    }

    /**
     * Hitung warna tiap titik.
     * @param cx,cy,cz posisi kamera di ruang dewa
     * @param fill     keluaran isi: ARGB (alpha biasa)
     * @param glow     keluaran cahaya: RGB (sudah dikali kekuatan, buat digambar aditif)
     */
    public static void shade(GodMesh m, double cx, double cy, double cz, int aura, Mask k, float time, int[] fill, int[] glow) {
        double ll = Math.sqrt(LX * LX + LY * LY + LZ * LZ);
        double lx = LX / ll, ly = LY / ll, lz = LZ / ll;
        double ar = ((aura >> 16) & 0xFF) / 255.0, ag = ((aura >> 8) & 0xFF) / 255.0, ab = (aura & 0xFF) / 255.0;
        double er = ((k.edge >> 16) & 0xFF) / 255.0, eg = ((k.edge >> 8) & 0xFF) / 255.0, eb = (k.edge & 0xFF) / 255.0;
        boolean scan = !Float.isNaN(k.scanY), burn = !Float.isNaN(k.burn), clip = !Float.isNaN(k.groundY);
        boolean scanTop = !Float.isNaN(k.scanTop);
        double flash = k.flash;
        for (int i = 0; i < m.verts; i++) {
            double px = m.x[i], py = m.y[i], pz = m.z[i];
            double vx = cx - px, vy = cy - py, vz = cz - pz;
            double vl = Math.sqrt(vx * vx + vy * vy + vz * vz);
            if (vl > 1.0E-9) {
                vx /= vl; vy /= vl; vz /= vl;
            }
            double ndv = m.nx[i] * vx + m.ny[i] * vy + m.nz[i] * vz;
            ndv = ndv < 0 ? 0 : (ndv > 1 ? 1 : ndv);
            double rim = 1.0 - ndv, rim2 = rim * rim, rim3 = rim2 * rim;
            double key = m.nx[i] * lx + m.ny[i] * ly + m.nz[i] * lz;
            double shade = 0.56 + 0.44 * (key < 0 ? 0.0 : key) + 0.08 * m.ny[i];
            int c = m.rgb[i];
            double br = ((c >> 16) & 0xFF) / 255.0, bg = ((c >> 8) & 0xFF) / 255.0, bb = (c & 0xFF) / 255.0;
            double em = m.glow[i];

            // tampak (muncul/hilang) dan tepi yang sedang terbentuk
            double vis = k.alpha, edgeGlow = 0.0;
            if (scan) {
                double d = (k.scanY - py) / k.scanBand;
                vis *= smooth(d);
                edgeGlow = Math.max(edgeGlow, Math.exp(-d * d * 2.2));
            }
            if (scanTop) {
                double d = (py - k.scanTop) / k.scanBand;
                vis *= smooth(d);
                edgeGlow = Math.max(edgeGlow, Math.exp(-d * d * 2.2));
            }
            if (burn) {
                double n = noise(px, py, pz);
                double th = k.burn * 1.35 - 0.2;
                double d = (th - (0.55 * n + 0.45 * Math.min(1.0, py / 2.0))) / 0.07;
                vis *= smooth(d);
                edgeGlow = Math.max(edgeGlow, Math.exp(-d * d * 0.9));
            }
            if (clip) {
                double d = (py - k.groundY) / 0.06;
                vis *= smooth(d);
                edgeGlow *= smooth(d + 1.0);
            }

            // isi
            double fr = br * shade * (1 - TINT) + ar * TINT + ar * rim2 * 0.3 + em * 0.22;
            double fg = bg * shade * (1 - TINT) + ag * TINT + ag * rim2 * 0.3 + em * 0.22;
            double fb = bb * shade * (1 - TINT) + ab * TINT + ab * rim2 * 0.3 + em * 0.22;
            if (flash > 0) {
                fr += (1 - fr) * flash;
                fg += (1 - fg) * flash;
                fb += (1 - fb) * flash;
            }
            double alpha = m.opacity[i] * (CORE_ALPHA + RIM_ALPHA * rim2) * vis;
            fill[i] = argb(alpha, fr, fg, fb);

            // cahaya
            double flow = 0.8 + 0.2 * Math.sin(py * 10.0 - time * 0.32 + (px + pz) * 3.0);
            double edgeLight = (INNER_GLOW + RIM_GLOW * rim3 * m.opacity[i]) * flow;   // bahan bening bersinar lebih lemah
            double gr = (ar * edgeLight + br * em * 0.6) * vis * k.boost;
            double gg = (ag * edgeLight + bg * em * 0.6) * vis * k.boost;
            double gb = (ab * edgeLight + bb * em * 0.6) * vis * k.boost;
            double eAmt = edgeGlow * 1.25 * Math.min(1.0, k.alpha * 1.5);
            gr += er * eAmt + flash * 0.55 * vis;
            gg += eg * eAmt + flash * 0.55 * vis;
            gb += eb * eAmt + flash * 0.55 * vis;
            glow[i] = rgb(gr, gg, gb);
        }
    }

    static double smooth(double v) {
        v = v < 0 ? 0 : (v > 1 ? 1 : v);
        return v * v * (3 - 2 * v);
    }

    /** Bercak acak halus 0..1 (tetap untuk titik yang sama). */
    static double noise(double x, double y, double z) {
        double a = Math.sin(x * 23.1 + y * 7.3 + 1.7) * Math.sin(z * 19.7 - y * 11.9 + 0.3);
        double b = Math.sin((x + z) * 41.0 + y * 29.0 + 2.2) * 0.5;
        double c = Math.sin(y * 53.0 - x * 17.0 + z * 37.0) * 0.25;
        double v = 0.5 + 0.3 * a + 0.2 * b + 0.1 * c;
        return v < 0 ? 0 : (v > 1 ? 1 : v);
    }

    static int argb(double a, double r, double g, double b) {
        return (to255(a) << 24) | (to255(r) << 16) | (to255(g) << 8) | to255(b);
    }

    static int rgb(double r, double g, double b) {
        return (to255(r) << 16) | (to255(g) << 8) | to255(b);
    }

    static int to255(double v) {
        int i = (int) (v * 255.0 + 0.5);
        return i < 0 ? 0 : (i > 255 ? 255 : i);
    }

    /** Campur warna ke putih (0..1). */
    public static int lighten(int rgbValue, double amount) {
        int r = (rgbValue >> 16) & 0xFF, g = (rgbValue >> 8) & 0xFF, b = rgbValue & 0xFF;
        r += (int) ((255 - r) * amount);
        g += (int) ((255 - g) * amount);
        b += (int) ((255 - b) * amount);
        return (r << 16) | (g << 8) | b;
    }

    // ------------------------------------------------------------------ pernik cahaya

    /** Tempat menggambar cahaya (di game: vfx.Draw; di luar game: penggambar uji). Koordinat dunia. */
    public interface Glows {
        void glow(double x, double y, double z, float radius, int rgbValue, float a);

        void line(double ax, double ay, double az, double bx, double by, double bz, float width, int rgbValue, float a);

        void ring(double cx, double cy, double cz, double nx, double ny, double nz, double radius, double width, int rgbValue,
                  float a);

        void disc(double cx, double cy, double cz, double radius, int rgbValue, float aCenter);
    }

    /** Ubah titik ruang dewa ke dunia: hasil di out[0..2]. */
    public static void toWorld(GodShow.State s, double ox, double oy, double oz, double lx, double ly, double lz, double[] out) {
        double c = Math.cos(s.yaw), sn = Math.sin(s.yaw);
        out[0] = ox + s.x + s.scale * (lx * c + lz * sn);
        out[1] = oy + s.y + s.scale * ly;
        out[2] = oz + s.z + s.scale * (-lx * sn + lz * c);
    }

    public static void dirToWorld(GodShow.State s, double lx, double ly, double lz, double[] out) {
        double c = Math.cos(s.yaw), sn = Math.sin(s.yaw);
        out[0] = lx * c + lz * sn;
        out[1] = ly;
        out[2] = -lx * sn + lz * c;
    }

    /** Kamera (dunia) ke ruang dewa. */
    public static void toLocal(GodShow.State s, double ox, double oy, double oz, double wx, double wy, double wz, double[] out) {
        double c = Math.cos(s.yaw), sn = Math.sin(s.yaw);
        double dx = wx - ox - s.x, dy = wy - oy - s.y, dz = wz - oz - s.z;
        out[0] = (dx * c - dz * sn) / s.scale;
        out[1] = dy / s.scale;
        out[2] = (dx * sn + dz * c) / s.scale;
    }

    /** Bintang di bola langit Atlas: 8 rasi tersebar rata (spiral Fibonacci), tiap rasi 5 bintang bersambung. */
    private static final int CONSTELLATIONS = 8, PER = 5;
    private static final double[] STARS = stars(5821L);
    /** Bintang kecil yang tersebar rata di seluruh bola. */
    private static final double[] DUST = dust(56);

    private static double[] dust(int n) {
        double[] out = new double[n * 3];
        double golden = Math.PI * (3.0 - Math.sqrt(5.0));
        for (int i = 0; i < n; i++) {
            double y = 1.0 - 2.0 * (i + 0.5) / n, q = Math.sqrt(1.0 - y * y), a = golden * i * 1.618 + 0.7;
            out[i * 3] = Math.cos(a) * q;
            out[i * 3 + 1] = y;
            out[i * 3 + 2] = Math.sin(a) * q;
        }
        return out;
    }

    private static double[] stars(long seed) {
        java.util.Random r = new java.util.Random(seed);
        double[] out = new double[CONSTELLATIONS * PER * 3];
        double golden = Math.PI * (3.0 - Math.sqrt(5.0));
        for (int c = 0; c < CONSTELLATIONS; c++) {
            double y = 1.0 - 2.0 * (c + 0.5) / CONSTELLATIONS, q = Math.sqrt(1.0 - y * y), a = golden * c;
            double cx = Math.cos(a) * q, cy = y * 0.85, cz = Math.sin(a) * q;
            double px = cx, py = cy, pz = cz;
            for (int k = 0; k < PER; k++) {
                px += (r.nextDouble() - 0.5) * 0.42;
                py += (r.nextDouble() - 0.5) * 0.42;
                pz += (r.nextDouble() - 0.5) * 0.42;
                double l = Math.sqrt(px * px + py * py + pz * pz);
                px /= l; py /= l; pz /= l;
                int i = (c * PER + k) * 3;
                out[i] = px; out[i + 1] = py; out[i + 2] = pz;
            }
        }
        return out;
    }

    /**
     * Pernik cahaya satu dewa. ox/oy/oz = asal ruang ritual di dunia; cam = posisi kamera (dunia).
     * vis = kepekatan dewa saat ini (0..1).
     */
    public static void extras(int god, GodMesh m, GodShow.State s, double ox, double oy, double oz, double camX, double camY,
                              double camZ, float time, Glows g) {
        float vis = s.mask.alpha * s.appear;
        if (vis <= 0.01f) {
            return;
        }
        int aura = GodFigures.AURA[god];
        int light = lighten(aura, 0.55);
        double sc = s.scale;
        double[] p = new double[3], q = new double[3], d = new double[3];
        float boost = Math.min(2.5f, s.mask.boost);

        // mata menyala
        for (int e = GodMesh.EYE_L; e <= GodMesh.EYE_R; e++) {
            anchorWorld(m, s, ox, oy, oz, e, p);
            g.glow(p[0], p[1], p[2], (float) (0.06 * sc), light, 0.75f * vis * boost);
            g.glow(p[0], p[1], p[2], (float) (0.022 * sc), 0xFFFFFF, 0.95f * vis);
        }
        // lingkaran suci di belakang kepala (cakram Aton & ular Mehen punya cahayanya sendiri)
        if (god != GodFigures.ATON && god != GodFigures.MEHEN) {
            anchorWorld(m, s, ox, oy, oz, GodMesh.HEAD, p);
            anchorDirWorld(m, s, GodMesh.HEAD, d);
            double hx = p[0] - d[0] * 0.13 * sc, hy = p[1] + 0.03 * sc - d[1] * 0.13 * sc, hz = p[2] - d[2] * 0.13 * sc;
            double tx = camX - hx, ty = camY - hy, tz = camZ - hz;
            double tl = Math.sqrt(tx * tx + ty * ty + tz * tz);
            if (tl > 1.0E-6) {
                g.ring(hx, hy, hz, tx / tl, ty / tl, tz / tl, 0.3 * sc, 0.035 * sc, light, 0.5f * s.halo * vis);
                g.ring(hx, hy, hz, tx / tl, ty / tl, tz / tl, 0.36 * sc, 0.012 * sc, aura, 0.35f * s.halo * vis);
            }
            g.glow(hx, hy, hz, (float) (0.62 * sc), aura, 0.16f * s.halo * vis * boost);
        }
        // kabut cahaya di kaki
        if (s.mist > 0.01f) {
            g.disc(ox + s.x, oy + s.y + 0.04, oz + s.z, 0.85 * sc, aura, 0.22f * s.mist * vis);
        }
        if (god >= GodFigures.EGYPT) {   // dewa-dewa Mesir Black Adam
            EgyptLook.extras(god, m, s, ox, oy, oz, camX, camY, camZ, time, g, vis, boost);
            return;
        }

        switch (god) {
            case GodFigures.SOLOMON -> {
                // segel (bintang segi enam) di depan telapak kanan + cahaya kitab + huruf rune melayang
                float seal = m.extraSize * vis;
                if (seal > 0.01f) {
                    anchorWorld(m, s, ox, oy, oz, GodMesh.EXTRA, p);
                    anchorDirWorld(m, s, GodMesh.EXTRA, d);
                    double cx = p[0] + d[0] * 0.08 * sc, cy = p[1] + d[1] * 0.08 * sc, cz = p[2] + d[2] * 0.08 * sc;
                    hexagram(g, cx, cy, cz, d, 0.13 * sc * (0.6 + 0.4 * seal), time * 0.03, light, seal);
                    g.glow(cx, cy, cz, (float) (0.22 * sc), aura, 0.35f * seal);
                }
                anchorWorld(m, s, ox, oy, oz, GodMesh.FOCUS, p);
                g.glow(p[0], p[1], p[2], (float) (0.32 * sc), 0xFFF0C8, 0.3f * vis);
                for (int k = 0; k < 3; k++) {
                    double a = time * 0.09 + k * Math.PI * 2 / 3;
                    double up = ((time * 0.02 + k / 3.0) % 1.0);
                    g.glow(p[0] + Math.cos(a) * 0.14 * sc, p[1] + up * 0.45 * sc, p[2] + Math.sin(a) * 0.14 * sc,
                            (float) (0.05 * sc), light, (float) (0.8 * vis * Math.sin(Math.PI * up)));
                }
            }
            case GodFigures.HERCULES -> {
                anchorWorld(m, s, ox, oy, oz, GodMesh.FOCUS, p);
                g.glow(p[0], p[1], p[2], (float) (0.28 * sc), aura, 0.22f * vis);
                anchorWorld(m, s, ox, oy, oz, GodMesh.EXTRA2, p);
                g.glow(p[0], p[1], p[2], (float) (0.05 * sc), 0xFFE9A0, 0.6f * vis);
            }
            case GodFigures.ATLAS -> {
                // bintang & rasi di bola langit
                anchorWorld(m, s, ox, oy, oz, GodMesh.FOCUS, p);
                double r = m.extraSize * sc * 1.004;
                double[] ay = new double[3], ax = new double[3];
                anchorDirWorld(m, s, GodMesh.EXTRA, ay);
                anchorDirWorld(m, s, GodMesh.EXTRA2, ax);
                double azx = ax[1] * ay[2] - ax[2] * ay[1], azy = ax[2] * ay[0] - ax[0] * ay[2], azz = ax[0] * ay[1] - ax[1] * ay[0];
                int n = STARS.length / 3;
                double[] sp = new double[n * 3];
                for (int i = 0; i < n; i++) {
                    double sx = STARS[i * 3], sy = STARS[i * 3 + 1], sz = STARS[i * 3 + 2];
                    sp[i * 3] = p[0] + (ax[0] * sx + ay[0] * sy + azx * sz) * r;
                    sp[i * 3 + 1] = p[1] + (ax[1] * sx + ay[1] * sy + azy * sz) * r;
                    sp[i * 3 + 2] = p[2] + (ax[2] * sx + ay[2] * sy + azz * sz) * r;
                    float tw = (float) (0.65 + 0.35 * Math.sin(time * 0.3 + i * 1.7));
                    g.glow(sp[i * 3], sp[i * 3 + 1], sp[i * 3 + 2], (float) (0.075 * sc), 0xFFF4D8, 0.95f * vis * tw);
                    g.glow(sp[i * 3], sp[i * 3 + 1], sp[i * 3 + 2], (float) (0.025 * sc), 0xFFFFFF, vis * tw);
                }
                for (int i = 0; i + 1 < n; i++) {
                    if ((i + 1) % PER == 0) {
                        continue;   // rasi berikutnya tidak disambung
                    }
                    int a = i * 3, b = (i + 1) * 3;
                    g.line(sp[a], sp[a + 1], sp[a + 2], sp[b], sp[b + 1], sp[b + 2], (float) (0.026 * sc), 0xFFE7B0, 0.7f * vis);
                }
                for (int i = 0; i < DUST.length / 3; i++) {
                    double sx = DUST[i * 3], sy = DUST[i * 3 + 1], sz = DUST[i * 3 + 2];
                    float tw = (float) (0.5 + 0.5 * Math.sin(time * 0.45 + i * 2.3));
                    g.glow(p[0] + (ax[0] * sx + ay[0] * sy + azx * sz) * r, p[1] + (ax[1] * sx + ay[1] * sy + azy * sz) * r,
                            p[2] + (ax[2] * sx + ay[2] * sy + azz * sz) * r, (float) (0.035 * sc), 0xFFFFFF, 0.75f * vis * tw);
                }
                g.glow(p[0], p[1], p[2], (float) (r * 1.25), aura, 0.2f * vis);
            }
            case GodFigures.ZEUS -> {
                anchorWorld(m, s, ox, oy, oz, GodMesh.FOCUS, p);
                float flick = (float) (0.75 + 0.25 * Math.sin(time * 2.3));
                g.glow(p[0], p[1], p[2], (float) (0.32 * sc), 0xFFE680, 0.4f * vis * flick);
                g.glow(p[0], p[1], p[2], (float) (0.1 * sc), 0xFFFFFF, 0.8f * vis);
                for (int e = GodMesh.EXTRA; e <= GodMesh.EXTRA2; e++) {
                    anchorWorld(m, s, ox, oy, oz, e, q);
                    g.glow(q[0], q[1], q[2], (float) (0.16 * sc), 0xCFEBFF, 0.7f * vis * flick);
                    zigzag(g, p, q, time, e, 0.012 * sc, 0xE8F4FF, 0.7f * vis);
                }
            }
            case GodFigures.ACHILLES -> {
                // lambang matahari di perisai + kilau ujung tombak
                anchorWorld(m, s, ox, oy, oz, GodMesh.EXTRA, p);
                anchorDirWorld(m, s, GodMesh.EXTRA, d);
                double[] e1 = new double[3], e2 = new double[3];
                basis(d, e1, e2);
                double rr = m.extraSize * sc;
                for (int k = 0; k < 8; k++) {
                    double a = k * Math.PI / 4 + time * 0.01;
                    double c0 = Math.cos(a), s0 = Math.sin(a);
                    double r0 = rr * 0.12, r1 = rr * (k % 2 == 0 ? 0.5 : 0.36);
                    g.line(p[0] + (e1[0] * c0 + e2[0] * s0) * r0, p[1] + (e1[1] * c0 + e2[1] * s0) * r0,
                            p[2] + (e1[2] * c0 + e2[2] * s0) * r0, p[0] + (e1[0] * c0 + e2[0] * s0) * r1,
                            p[1] + (e1[1] * c0 + e2[1] * s0) * r1, p[2] + (e1[2] * c0 + e2[2] * s0) * r1,
                            (float) (0.03 * sc), 0xFFF2C0, 0.5f * vis);
                }
                g.glow(p[0], p[1], p[2], (float) (rr * 0.4), 0xFFF2C0, 0.3f * vis);
                anchorWorld(m, s, ox, oy, oz, GodMesh.EXTRA2, p);
                float tw = (float) (0.6 + 0.4 * Math.sin(time * 0.5));
                g.glow(p[0], p[1], p[2], (float) (0.16 * sc), 0xFFFFFF, 0.6f * vis * tw);
            }
            default -> {
                // pusaran angin di bawah jinjit + cahaya caduceus
                float idle = (float) (1.0 - m.extraSize) * vis;
                anchorWorld(m, s, ox, oy, oz, GodMesh.EXTRA2, p);
                for (int k = 0; k < 3; k++) {
                    double base = time * 0.35 + k * Math.PI * 2 / 3;
                    double prevX = 0, prevY = 0, prevZ = 0;
                    for (int j = 0; j <= 8; j++) {
                        double u = j / 8.0;
                        double a = base + u * 2.2;
                        double rr = (0.08 + 0.18 * u) * sc;
                        double x = p[0] + Math.cos(a) * rr, y = p[1] - 0.12 * sc * u, z = p[2] + Math.sin(a) * rr;
                        if (j > 0) {
                            g.line(prevX, prevY, prevZ, x, y, z, (float) (0.025 * sc), 0xE8FCFF,
                                    0.45f * idle * (float) Math.sin(Math.PI * u));
                        }
                        prevX = x; prevY = y; prevZ = z;
                    }
                }
                anchorWorld(m, s, ox, oy, oz, GodMesh.FOCUS, p);
                g.glow(p[0], p[1], p[2], (float) (0.2 * sc), aura, 0.4f * vis);
            }
        }
    }

    /** Sinar energi dari pusaka ke kepalan (saat menyatu): berkas + gumpalan cahaya yang mengalir. */
    public static void beam(int god, GodMesh m, GodShow.State s, double ox, double oy, double oz, double fx, double fy,
                            double fz, float time, Glows g) {
        if (s.beam <= 0.01f) {
            return;
        }
        int aura = GodFigures.AURA[god];
        double[] p = new double[3];
        anchorWorld(m, s, ox, oy, oz, GodMesh.FOCUS, p);
        float a = s.beam;
        g.line(p[0], p[1], p[2], fx, fy, fz, 0.34f * a, aura, 0.5f * a);
        g.line(p[0], p[1], p[2], fx, fy, fz, 0.1f * a, 0xFFFFFF, 0.85f * a);
        g.glow(p[0], p[1], p[2], 0.55f * a, aura, 0.7f * a);
        for (int k = 0; k < 4; k++) {
            double u = (time * 0.11 + k * 0.25 + god * 0.13) % 1.0;
            g.glow(p[0] + (fx - p[0]) * u, p[1] + (fy - p[1]) * u, p[2] + (fz - p[2]) * u, 0.22f * a, lighten(aura, 0.4),
                    0.8f * a * (float) Math.sin(Math.PI * u));
        }
    }

    /** Jejak gerak (Hercules melompat, Mercury berlari): titik-titik xyz berurutan, terbaru di akhir. */
    public static void trail(double[] pts, int n, float width, int rgbValue, float a, Glows g) {
        for (int i = 0; i + 1 < n; i++) {
            float f0 = i / (float) (n - 1), f1 = (i + 1) / (float) (n - 1);
            int o = i * 3;
            g.line(pts[o], pts[o + 1], pts[o + 2], pts[o + 3], pts[o + 4], pts[o + 5], width * (0.3f + 0.7f * f1), rgbValue,
                    a * 0.5f * (f0 + f1));
        }
    }

    // ------------------------------------------------------------------ alat bantu

    static void anchorWorld(GodMesh m, GodShow.State s, double ox, double oy, double oz, int k, double[] out) {
        toWorld(s, ox, oy, oz, m.anchor[k * 3], m.anchor[k * 3 + 1], m.anchor[k * 3 + 2], out);
    }

    static void anchorDirWorld(GodMesh m, GodShow.State s, int k, double[] out) {
        dirToWorld(s, m.anchorDir[k * 3], m.anchorDir[k * 3 + 1], m.anchorDir[k * 3 + 2], out);
    }

    /** Dua arah satuan tegak lurus n. */
    static void basis(double[] n, double[] e1, double[] e2) {
        double ax = Math.abs(n[1]) < 0.9 ? 0 : 1, ay = Math.abs(n[1]) < 0.9 ? 1 : 0;
        double x = ay * n[2], y = -ax * n[2], z = ax * n[1] - ay * n[0];
        double l = Math.sqrt(x * x + y * y + z * z);
        e1[0] = x / l; e1[1] = y / l; e1[2] = z / l;
        e2[0] = n[1] * e1[2] - n[2] * e1[1];
        e2[1] = n[2] * e1[0] - n[0] * e1[2];
        e2[2] = n[0] * e1[1] - n[1] * e1[0];
    }

    /** Bintang segi enam (segel Solomon) di bidang dengan normal n. */
    static void hexagram(Glows g, double cx, double cy, double cz, double[] n, double r, double spin, int color, float a) {
        double[] e1 = new double[3], e2 = new double[3];
        basis(n, e1, e2);
        for (int tri = 0; tri < 2; tri++) {
            for (int k = 0; k < 3; k++) {
                double a0 = spin + tri * Math.PI / 3 + k * Math.PI * 2 / 3, a1 = a0 + Math.PI * 2 / 3;
                double c0 = Math.cos(a0) * r, s0 = Math.sin(a0) * r, c1 = Math.cos(a1) * r, s1 = Math.sin(a1) * r;
                g.line(cx + e1[0] * c0 + e2[0] * s0, cy + e1[1] * c0 + e2[1] * s0, cz + e1[2] * c0 + e2[2] * s0,
                        cx + e1[0] * c1 + e2[0] * s1, cy + e1[1] * c1 + e2[1] * s1, cz + e1[2] * c1 + e2[2] * s1,
                        (float) (r * 0.12), color, a);
            }
        }
        g.ring(cx, cy, cz, n[0], n[1], n[2], r * 1.12, r * 0.08, color, a * 0.8f);
    }

    /** Percikan listrik kecil zig-zag di antara dua titik (berganti bentuk tiap 2 tick). */
    static void zigzag(Glows g, double[] a, double[] b, float time, int salt, double width, int color, float alpha) {
        java.util.Random r = new java.util.Random(((long) (time / 2.0f)) * 31L + salt * 977L);
        double px = a[0], py = a[1], pz = a[2];
        int segs = 5;
        double len = Math.sqrt((b[0] - a[0]) * (b[0] - a[0]) + (b[1] - a[1]) * (b[1] - a[1]) + (b[2] - a[2]) * (b[2] - a[2]));
        for (int i = 1; i <= segs; i++) {
            double u = i / (double) segs;
            double j = i == segs ? 0 : len * 0.12;
            double x = a[0] + (b[0] - a[0]) * u + (r.nextDouble() - 0.5) * j;
            double y = a[1] + (b[1] - a[1]) * u + (r.nextDouble() - 0.5) * j;
            double z = a[2] + (b[2] - a[2]) * u + (r.nextDouble() - 0.5) * j;
            g.line(px, py, pz, x, y, z, (float) width, color, alpha);
            px = x; py = y; pz = z;
        }
    }
}
