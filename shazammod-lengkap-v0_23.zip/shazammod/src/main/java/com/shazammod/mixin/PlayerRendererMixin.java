package com.shazammod.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.mojang.blaze3d.vertex.PoseStack;
import com.shazammod.client.anim.ShazamPoses;

import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;

@Mixin(PlayerRenderer.class)
public abstract class PlayerRendererMixin {
    /** Kemiringan seluruh badan (terbang rebah, membungkuk, berlutut). */
    @Inject(method = "setupRotations(Lnet/minecraft/client/player/AbstractClientPlayer;Lcom/mojang/blaze3d/vertex/PoseStack;FFFF)V",
            at = @At("TAIL"))
    private void shazammod$bodyTilt(AbstractClientPlayer player, PoseStack poseStack, float bob, float yBodyRot,
                                    float partialTick, float scale, CallbackInfo ci) {
        ShazamPoses.applyBodyTransform(player, poseStack, partialTick, scale);
        // jubah, mantel, dan hood memakai matriks badan yang sama persis dengan model (termasuk berenang, merangkak)
        ShazamPoses.endBodyCapture(player, poseStack);
    }
}
