package com.shazammod;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import net.minecraft.util.Mth;

/**
 * unlocked      = layak jadi Shazam: enam totem penjaga kuil sudah menyatu (ucapkan SHAZAM sambil membawa keenamnya),
 *                 atau lewat /shazam unlock
 * transformed   = sedang dalam wujud juara (Shazam atau Black Adam)
 * energy        = Energi Petir, 0 sampai MAX_ENERGY
 * hoodUp        = hood jubah sedang dipakai di kepala
 * knockoutUntil = game time sampai kapan belum bisa SHAZAM lagi, sesudah terlempar balik jadi manusia
 *                 karena serangan mematikan (0 = nggak sedang pulih)
 * form          = juara yang dipilih (lihat ShazamForm): 0 = Shazam, 1 = Black Adam
 * adamUnlocked  = layak jadi Black Adam: lulus Ujian Kahndaq dengan Skarabe Teth-Adam (lihat KahndaqTrial), atau lewat
 *                 /shazam unlock black_adam. Jalan yang beda total dari Shazam.
 */
public record ShazamData(boolean unlocked, boolean transformed, float energy, boolean hoodUp, long knockoutUntil, int form,
                         boolean adamUnlocked) {
    public static final ShazamData DEFAULT = new ShazamData(false, false, ShazamPowers.MAX_ENERGY, true, 0L, 0, false);

    public static final Codec<ShazamData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.BOOL.optionalFieldOf("unlocked", false).forGetter(ShazamData::unlocked),
            Codec.BOOL.optionalFieldOf("transformed", false).forGetter(ShazamData::transformed),
            Codec.FLOAT.optionalFieldOf("energy", ShazamPowers.MAX_ENERGY).forGetter(ShazamData::energy),
            Codec.BOOL.optionalFieldOf("hood_up", true).forGetter(ShazamData::hoodUp),
            Codec.LONG.optionalFieldOf("knockout_until", 0L).forGetter(ShazamData::knockoutUntil),
            Codec.INT.optionalFieldOf("form", 0).forGetter(ShazamData::form),
            Codec.BOOL.optionalFieldOf("adam_unlocked", false).forGetter(ShazamData::adamUnlocked)
    ).apply(instance, ShazamData::new));

    public ShazamData withUnlocked(boolean value) {
        return new ShazamData(value, transformed, energy, hoodUp, knockoutUntil, form, adamUnlocked);
    }

    public ShazamData withAdamUnlocked(boolean value) {
        return new ShazamData(unlocked, transformed, energy, hoodUp, knockoutUntil, form, value);
    }

    public ShazamData withTransformed(boolean value) {
        return new ShazamData(unlocked, value, energy, hoodUp, knockoutUntil, form, adamUnlocked);
    }

    public ShazamData withEnergy(float value) {
        return new ShazamData(unlocked, transformed, Mth.clamp(value, 0f, ShazamPowers.MAX_ENERGY), hoodUp, knockoutUntil, form,
                adamUnlocked);
    }

    public ShazamData withHoodUp(boolean value) {
        return new ShazamData(unlocked, transformed, energy, value, knockoutUntil, form, adamUnlocked);
    }

    public ShazamData withKnockoutUntil(long value) {
        return new ShazamData(unlocked, transformed, energy, hoodUp, value, form, adamUnlocked);
    }

    public ShazamData withForm(ShazamForm value) {
        return new ShazamData(unlocked, transformed, energy, hoodUp, knockoutUntil, value.ordinal(), adamUnlocked);
    }

    /** Juara ini sudah didapat (Shazam lewat enam totem, Black Adam lewat Skarabe Teth-Adam). */
    public boolean has(ShazamForm champion) {
        return champion == ShazamForm.BLACK_ADAM ? adamUnlocked : unlocked;
    }

    /** Sudah punya paling nggak satu juara. */
    public boolean anyUnlocked() {
        return unlocked || adamUnlocked;
    }

    /** Punya dua-duanya (baru boleh ganti juara dengan tombol K). */
    public boolean hasBoth() {
        return unlocked && adamUnlocked;
    }

    /**
     * Juara yang dipakai saat berubah. Pilihan yang belum didapat (misalnya save lama yang memilih Black Adam sebelum
     * ada Ujian Kahndaq) jatuh ke juara yang memang sudah dimiliki. Nilai tak dikenal dianggap Shazam.
     */
    public ShazamForm champion() {
        ShazamForm chosen = ShazamForm.byId(form);
        if (!has(chosen)) {
            for (ShazamForm other : ShazamForm.values()) {
                if (has(other)) {
                    return other;
                }
            }
        }
        return chosen;
    }

    public boolean isBlackAdam() {
        return champion() == ShazamForm.BLACK_ADAM;
    }
}
