package com.shazammod;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.shazammod.guardian.GuardianKind;
import com.shazammod.guardian.ShazamGuardian;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.phys.Vec3;

/** Perintah buat ngetes (butuh cheat). Jalan sungguhannya: enam totem penjaga (Shazam) dan Ujian Kahndaq (Black Adam). */
public final class ShazamCommands {
    private ShazamCommands() {}

    private static final List<String> FORM_IDS = Arrays.stream(ShazamForm.values()).map(form -> form.id).toList();

    private static final List<String> GUARDIAN_IDS =
            Arrays.stream(GuardianKind.values()).map(kind -> kind.id).toList();

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("shazam")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("unlock")
                        .executes(ctx -> unlock(ctx.getSource(), ShazamForm.SHAZAM, self(ctx.getSource())))
                        .then(champion("shazam", true, ShazamForm.SHAZAM))
                        .then(champion("black_adam", true, ShazamForm.BLACK_ADAM))
                        .then(champion("all", true, null))
                        .then(Commands.argument("targets", EntityArgument.players())
                                .executes(ctx -> unlock(ctx.getSource(), ShazamForm.SHAZAM,
                                        EntityArgument.getPlayers(ctx, "targets")))))
                .then(Commands.literal("lock")
                        .executes(ctx -> lock(ctx.getSource(), null, self(ctx.getSource())))
                        .then(champion("shazam", false, ShazamForm.SHAZAM))
                        .then(champion("black_adam", false, ShazamForm.BLACK_ADAM))
                        .then(champion("all", false, null))
                        .then(Commands.argument("targets", EntityArgument.players())
                                .executes(ctx -> lock(ctx.getSource(), null, EntityArgument.getPlayers(ctx, "targets")))))
                .then(Commands.literal("trial")
                        .executes(ctx -> trial(ctx.getSource(), self(ctx.getSource())))
                        .then(Commands.argument("targets", EntityArgument.players())
                                .executes(ctx -> trial(ctx.getSource(), EntityArgument.getPlayers(ctx, "targets")))))
                .then(Commands.literal("energy")
                        .then(Commands.argument("amount", FloatArgumentType.floatArg(0f, ShazamPowers.MAX_ENERGY))
                                .executes(ctx -> setEnergy(ctx.getSource(), FloatArgumentType.getFloat(ctx, "amount")))))
                .then(Commands.literal("form")
                        .then(Commands.argument("champion", StringArgumentType.word())
                                .suggests((ctx, builder) -> SharedSuggestionProvider.suggest(FORM_IDS, builder))
                                .executes(ctx -> setForm(ctx.getSource(), StringArgumentType.getString(ctx, "champion"),
                                        List.of(ctx.getSource().getPlayerOrException())))
                                .then(Commands.argument("targets", EntityArgument.players())
                                        .executes(ctx -> setForm(ctx.getSource(), StringArgumentType.getString(ctx, "champion"),
                                                EntityArgument.getPlayers(ctx, "targets"))))))
                .then(Commands.literal("summon")
                        .then(Commands.argument("guardian", StringArgumentType.word())
                                .suggests((ctx, builder) -> SharedSuggestionProvider.suggest(GUARDIAN_IDS, builder))
                                .executes(ctx -> summon(ctx.getSource(), StringArgumentType.getString(ctx, "guardian"))))));
    }

    private static List<ServerPlayer> self(CommandSourceStack source) throws CommandSyntaxException {
        return List.of(source.getPlayerOrException());
    }

    /** Cabang "shazam" / "black_adam" / "all" (null) di bawah unlock/lock, dengan [pemain] opsional. */
    private static com.mojang.brigadier.builder.LiteralArgumentBuilder<CommandSourceStack> champion(String name, boolean opening,
                                                                                                     ShazamForm form) {
        return Commands.literal(name)
                .executes(ctx -> opening ? unlock(ctx.getSource(), form, self(ctx.getSource()))
                        : lock(ctx.getSource(), form, self(ctx.getSource())))
                .then(Commands.argument("targets", EntityArgument.players())
                        .executes(ctx -> opening ? unlock(ctx.getSource(), form, EntityArgument.getPlayers(ctx, "targets"))
                                : lock(ctx.getSource(), form, EntityArgument.getPlayers(ctx, "targets"))));
    }

    /** form = null: dua-duanya. */
    private static int unlock(CommandSourceStack source, ShazamForm form, Collection<ServerPlayer> targets) {
        for (ServerPlayer player : targets) {
            if (form == null || form == ShazamForm.BLACK_ADAM) {
                ShazamPowers.unlockAdam(player);
            }
            if (form == null || form == ShazamForm.SHAZAM) {
                ShazamPowers.unlock(player);
            }
        }
        Component which = form == null ? Component.translatable("champion.shazammod.all")
                : Component.translatable("champion.shazammod." + form.id);
        source.sendSuccess(() -> Component.translatable("commands.shazammod.unlock", which, targets.size()), true);
        return targets.size();
    }

    private static int lock(CommandSourceStack source, ShazamForm form, Collection<ServerPlayer> targets) {
        for (ServerPlayer player : targets) {
            ShazamPowers.lock(player, form);
        }
        Component which = form == null ? Component.translatable("champion.shazammod.all")
                : Component.translatable("champion.shazammod." + form.id);
        source.sendSuccess(() -> Component.translatable("commands.shazammod.lock", which, targets.size()), true);
        return targets.size();
    }

    /** /shazam trial [pemain]: mulai Ujian Kahndaq di tempat (tanpa syarat gurun & langit terbuka), buat dites. */
    private static int trial(CommandSourceStack source, Collection<ServerPlayer> targets) {
        for (ServerPlayer player : targets) {
            KahndaqTrial.begin(player);
        }
        source.sendSuccess(() -> Component.translatable("commands.shazammod.trial", targets.size()), true);
        return targets.size();
    }

    /** /shazam form shazam|black_adam [pemain]: pilih juara (yang sedang berubah wujud balik jadi manusia dulu). */
    private static int setForm(CommandSourceStack source, String id, Collection<ServerPlayer> targets) {
        ShazamForm form = ShazamForm.byName(id);
        if (form == null) {
            source.sendFailure(Component.translatable("commands.shazammod.unknown_form", id));
            return 0;
        }
        int changed = 0;
        for (ServerPlayer player : targets) {
            if (!ShazamPowers.data(player).has(form)) {   // juara harus didapat lewat jalannya dulu
                source.sendFailure(Component.translatable("commands.shazammod.form_not_owned", player.getDisplayName(),
                        Component.translatable("champion.shazammod." + form.id)));
                continue;
            }
            ShazamPowers.setForm(player, form, true);
            changed++;
        }
        int count = changed;
        if (count > 0) {
            source.sendSuccess(() -> Component.translatable("commands.shazammod.form",
                    Component.translatable("champion.shazammod." + form.id), count), true);
        }
        return count;
    }

    private static int setEnergy(CommandSourceStack source, float amount) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        ShazamPowers.setData(player, ShazamPowers.data(player).withEnergy(amount));
        source.sendSuccess(() -> Component.translatable("commands.shazammod.energy", Math.round(amount)), true);
        return 1;
    }

    /** Munculkan penjaga 5 blok di depan pemain, langsung bangun. */
    private static int summon(CommandSourceStack source, String id) throws CommandSyntaxException {
        GuardianKind kind = GuardianKind.byId(id);
        if (kind == null) {
            source.sendFailure(Component.translatable("commands.shazammod.unknown_guardian", id));
            return 0;
        }
        ServerPlayer player = source.getPlayerOrException();
        ServerLevel level = player.serverLevel();
        Mob mob = kind.entityType().create(level);
        if (mob == null) {
            return 0;
        }
        Vec3 look = player.getLookAngle();
        mob.moveTo(player.getX() + look.x * 5.0, player.getY(), player.getZ() + look.z * 5.0,
                player.getYRot() + 180f, 0f);
        level.addFreshEntity(mob);
        if (mob instanceof ShazamGuardian guardian) {
            guardian.core().wake();
        }
        source.sendSuccess(() -> Component.translatable("commands.shazammod.summon", mob.getDisplayName()), true);
        return 1;
    }
}
