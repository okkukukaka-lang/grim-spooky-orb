package com.shazammod;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;

import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.living.LivingExperienceDropEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/**
 * Logika inti Shazam: transformasi, enam kekuatan S-H-A-Z-A-M, dan Energi Petir.
 * Juara kedua, Black Adam (ShazamForm.BLACK_ADAM), memakai alur berubah yang sama dengan dewa-dewa Mesir; skill-nya
 * di AdamSkills. Semua angka penyeimbang dikumpulkan di bagian paling atas.
 */
public final class ShazamPowers {
    private ShazamPowers() {}

    // ================= Angka-angka yang gampang diutak-atik =================
    // Energi Petir
    public static final float MAX_ENERGY = 1000f;
    public static final float MIN_ENERGY_TO_TRANSFORM = 50f;
    public static final float TRANSFORM_COST = 20f;
    public static final float DRAIN_PER_SECOND = 1f;                 // energi penuh habis dalam ±16 menit
    public static final float RECHARGE_PER_SECOND = 5f;              // wujud manusia: penuh lagi dalam ±3 menit 20 detik
    public static final float STORM_RECHARGE_MULTIPLIER = 4f;        // saat badai petir & di bawah langit terbuka
    public static final float STORM_CHARGE_WHILE_TRANSFORMED = 2f;   // saat badai, energi tetap naik walau jadi Shazam
    // Kekuatan dan ketahanan (seperti di komik: jauh di atas Warden, mob terkuat di game)
    public static final double BONUS_HEALTH = 280.0;                 // darah 20 -> 300 (150 hati)
    public static final float REGEN_PER_SECOND = 3f;                 // A - Atlas: pulih terus
    public static final boolean FULL_HEAL_ON_TRANSFORM = true;       // jadi Shazam: darah langsung penuh, berapa pun sisanya
    public static final boolean FULL_HEAL_ON_REVERT = true;          // balik jadi manusia: darah langsung penuh (seperti di komik)
    public static final boolean SAFE_DURING_RITUAL = true;           // kebal selama ritual berubah & balik, jadi nggak mati di tengahnya
    public static final boolean REVERT_INSTEAD_OF_DEATH = true;      // kena serangan mematikan saat jadi Shazam: nggak mati, tapi terlempar balik jadi manusia
    public static final int KNOCKOUT_COOLDOWN_TICKS = 600;           // habis itu belum bisa SHAZAM lagi selama 30 detik (0 = langsung bisa)
    public static final float PUNCH_MULTIPLIER = 40f;                // tangan kosong: 1 -> 40 damage (critical 60)
    public static final float WEAPON_MULTIPLIER = 2f;                // pakai senjata: damage senjatanya x2
    public static final double BONUS_ATTACK_SPEED = 1.0;             // pukulan penuh tiap 0,2 detik (manusia 0,25 detik)
    public static final float DAMAGE_TAKEN_MULTIPLIER = 0.4f;        // damage yang diterima tinggal 40% (lalu dikurangi armor)
    public static final double BONUS_ARMOR = 20.0;                   // armor penuh, setara full netherite
    public static final double BONUS_TOUGHNESS = 12.0;               // pukulan keras nggak menembus armor
    public static final double BONUS_KNOCKBACK = 2.5;                // musuh terpental jauh
    public static final double STEP_UP = 0.6;                        // langkah raksasa: naik blok tanpa lompat
    public static final double JUMP_BOOST = 0.25;
    public static final double REACH_BOOST = 1.0;
    public static final double BREAK_SPEED_BOOST = 3.0;              // menghancurkan blok 4x lebih cepat
    public static final float MAGIC_DAMAGE_MULTIPLIER = 1.5f;        // kelemahan Shazam: sihir
    public static final float EXPOSED_MULTIPLIER = 1.25f;            // musuh yang "dibaca" Mata Solomon
    public static final float XP_MULTIPLIER = 1.5f;
    public static final double GROWTH = 0.1;                         // wujud dewasa Shazam 10% lebih besar
    public static final double GLOW_RADIUS = 20.0;
    public static final float TRANSFORM_STRIKE_DAMAGE = 12f;
    public static final double TRANSFORM_STRIKE_RADIUS = 5.0;
    public static final int TOGGLE_COOLDOWN_TICKS = 40;              // 2 detik
    // Black Adam: juara yang beda jelas dari Shazam. Lebih tebal & buas, kulitnya memantulkan proyektil, kekuatannya
    // dari matahari & gurun Kahndaq (Shazam dari badai petir), bisa memanggil petir sendiri di tengah pertarungan.
    public static final float ADAM_PUNCH_MULTIPLIER = 44f;           // A - Amon: tangan kosong 1 -> 44 (critical 66)
    public static final double ADAM_EXTRA_KNOCKBACK = 0.8;           // hempasan +0,8 di atas Shazam
    public static final float ADAM_TRANSFORM_STRIKE_DAMAGE = 18f;    // A - Aton: petir berubahnya lebih ganas
    public static final double ADAM_BONUS_HEALTH = 330.0;            // darah 20 -> 350 (Shazam 300)
    public static final float ADAM_DAMAGE_TAKEN_MULTIPLIER = 0.35f;  // kulit Kahndaq: damage tinggal 35% (Shazam 40%)
    public static final boolean ADAM_PROJECTILE_IMMUNE = true;       // panah, trisula, bola api, peluru mod lain: memantul
    public static final float ADAM_REGEN_PER_SECOND = 2f;            // malam / di dalam ruangan (Shazam 3)
    public static final float ADAM_SUN_REGEN_MULTIPLIER = 3f;        // Berkah Aton: di bawah matahari pulih 6 per detik
    public static final float ADAM_DRAIN_PER_SECOND = 1.5f;          // malam / di dalam ruangan (Shazam 1)
    public static final float ADAM_SUN_CHARGE_PER_SECOND = 1f;       // di bawah matahari: energi malah terisi
    public static final float ADAM_RECHARGE_PER_SECOND = 4f;         // wujud manusia (Shazam 5, tapi matahari x3)
    public static final float ADAM_SUN_RECHARGE_MULTIPLIER = 3f;
    public static final double ADAM_LANDING_RADIUS_MULTIPLIER = 1.35; // pendaratan Black Adam lebih lebar & sakit
    public static final float ADAM_LANDING_DAMAGE_MULTIPLIER = 1.3f;
    public static final int FORM_SWITCH_COOLDOWN_TICKS = 60;         // ganti juara: 3 detik sesudah berubah/balik
    // =========================================================================

    private static final ResourceLocation SHAZAM_HEALTH = ShazamMod.id("shazam_health");

    private record Boost(Holder<Attribute> attribute, ResourceLocation id, double amount, AttributeModifier.Operation operation) {}

    private static final List<Boost> BOOSTS = List.of(
            new Boost(Attributes.SCALE, ShazamMod.id("shazam_growth"), GROWTH, AttributeModifier.Operation.ADD_VALUE),
            new Boost(Attributes.MOVEMENT_SPEED, ShazamMod.id("mercury_speed"), 0.4, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL),
            new Boost(Attributes.JUMP_STRENGTH, ShazamMod.id("mercury_leap"), JUMP_BOOST, AttributeModifier.Operation.ADD_VALUE),
            new Boost(Attributes.KNOCKBACK_RESISTANCE, ShazamMod.id("achilles_steadfast"), 1.0, AttributeModifier.Operation.ADD_VALUE),
            new Boost(Attributes.ARMOR, ShazamMod.id("atlas_armor"), BONUS_ARMOR, AttributeModifier.Operation.ADD_VALUE),
            new Boost(Attributes.ARMOR_TOUGHNESS, ShazamMod.id("atlas_toughness"), BONUS_TOUGHNESS, AttributeModifier.Operation.ADD_VALUE),
            new Boost(Attributes.ATTACK_KNOCKBACK, ShazamMod.id("hercules_knockback"), BONUS_KNOCKBACK, AttributeModifier.Operation.ADD_VALUE),
            new Boost(Attributes.ATTACK_SPEED, ShazamMod.id("hercules_fury"), BONUS_ATTACK_SPEED, AttributeModifier.Operation.ADD_VALUE),
            new Boost(Attributes.STEP_HEIGHT, ShazamMod.id("hercules_stride"), STEP_UP, AttributeModifier.Operation.ADD_VALUE),
            new Boost(Attributes.ENTITY_INTERACTION_RANGE, ShazamMod.id("hercules_reach"), REACH_BOOST, AttributeModifier.Operation.ADD_VALUE),
            new Boost(Attributes.BLOCK_BREAK_SPEED, ShazamMod.id("hercules_smash"), BREAK_SPEED_BOOST, AttributeModifier.Operation.ADD_MULTIPLIED_BASE));

    // Tambahan khusus Black Adam (dipasang di atas BOOSTS)
    private static final List<Boost> ADAM_BOOSTS = List.of(
            new Boost(Attributes.ATTACK_KNOCKBACK, ShazamMod.id("amon_knockback"), ADAM_EXTRA_KNOCKBACK,
                    AttributeModifier.Operation.ADD_VALUE));

    // Efek penghambat yang langsung dibuang oleh keberanian Achilles
    private static final List<Holder<MobEffect>> DEBUFFS = List.of(
            MobEffects.MOVEMENT_SLOWDOWN, MobEffects.WEAKNESS, MobEffects.BLINDNESS,
            MobEffects.DARKNESS, MobEffects.DIG_SLOWDOWN, MobEffects.CONFUSION,
            MobEffects.POISON, MobEffects.WITHER, MobEffects.HUNGER);

    private static final Map<UUID, Long> LAST_TOGGLE = new HashMap<>();
    private static final Map<UUID, Long> LAST_HOOD = new HashMap<>();
    private static final Set<UUID> FALL_GRACE = new HashSet<>();
    private static final Set<UUID> TOGGLING = new HashSet<>();
    private static final Map<UUID, Boolean> LAST_FLYING = new HashMap<>();
    private static final Map<UUID, List<Delayed>> DELAYED = new HashMap<>();

    private static final class Delayed {
        int ticksLeft;
        final Consumer<ServerPlayer> action;

        Delayed(int ticksLeft, Consumer<ServerPlayer> action) {
            this.ticksLeft = ticksLeft;
            this.action = action;
        }
    }

    // ------------------------------------------------------------------ Data

    public static ShazamData data(Player player) {
        return player.getData(ShazamMod.SHAZAM_DATA);
    }

    public static void setData(Player player, ShazamData data) {
        player.setData(ShazamMod.SHAZAM_DATA, data);
    }

    public static boolean isTransformed(Player player) {
        return data(player).transformed();
    }

    /** Sedang berwujud Black Adam. */
    public static boolean isAdam(Player player) {
        ShazamData data = data(player);
        return data.transformed() && data.isBlackAdam();
    }

    // ---------------------------------------------------- Aksi tertunda

    /** Jalankan aksi beberapa tick lagi, supaya efeknya pas dengan gerakan animasi. */
    public static void schedule(ServerPlayer player, int delayTicks, Consumer<ServerPlayer> action) {
        DELAYED.computeIfAbsent(player.getUUID(), id -> new ArrayList<>()).add(new Delayed(delayTicks, action));
    }

    private static void cancelScheduled(ServerPlayer player) {
        DELAYED.remove(player.getUUID());
        TOGGLING.remove(player.getUUID());
    }

    private static void runScheduled(ServerPlayer player) {
        List<Delayed> list = DELAYED.get(player.getUUID());
        if (list == null) {
            return;
        }
        List<Delayed> due = new ArrayList<>();
        Iterator<Delayed> iterator = list.iterator();
        while (iterator.hasNext()) {
            Delayed delayed = iterator.next();
            if (--delayed.ticksLeft <= 0) {
                due.add(delayed);
                iterator.remove();
            }
        }
        if (list.isEmpty()) {
            DELAYED.remove(player.getUUID());
        }
        for (Delayed delayed : due) {
            delayed.action.accept(player);
        }
    }

    // ------------------------------------------- Membuka / mencabut kekuatan

    /** Penyihir memilihmu (enam totem menyatu, atau /shazam unlock): kekuatan Shazam terbuka. */
    public static void unlock(ServerPlayer player) {
        setData(player, data(player).withUnlocked(true).withForm(ShazamForm.SHAZAM).withEnergy(MAX_ENERGY)
                .withKnockoutUntil(0L));
        player.sendSystemMessage(Component.translatable("message.shazammod.unlocked")
                .withStyle(ChatFormatting.GOLD, ChatFormatting.ITALIC));
        ShazamNetwork.broadcastState(player);
        ShazamNetwork.sync(player);
    }

    /** Skarabe Teth-Adam bangkit (lulus Ujian Kahndaq, atau /shazam unlock black_adam): kekuatan Black Adam terbuka. */
    public static void unlockAdam(ServerPlayer player) {
        setData(player, data(player).withAdamUnlocked(true).withForm(ShazamForm.BLACK_ADAM).withEnergy(MAX_ENERGY)
                .withKnockoutUntil(0L));
        player.sendSystemMessage(Component.translatable("message.shazammod.adam_unlocked")
                .withStyle(ChatFormatting.GOLD, ChatFormatting.ITALIC));
        ShazamNetwork.broadcastState(player);
        ShazamNetwork.sync(player);
    }

    public static void lock(ServerPlayer player) {
        lock(player, null);
    }

    /** Cabut satu juara (atau dua-duanya kalau champion = null). Yang sedang memakainya balik jadi manusia. */
    public static void lock(ServerPlayer player, ShazamForm champion) {
        ShazamData data = data(player);
        if (isTransformed(player) && (champion == null || data.champion() == champion)) {
            revert(player, false);
        }
        data = data(player);
        if (champion == null || champion == ShazamForm.SHAZAM) {
            data = data.withUnlocked(false);
        }
        if (champion == null || champion == ShazamForm.BLACK_ADAM) {
            data = data.withAdamUnlocked(false);
        }
        setData(player, data);
        ShazamNetwork.broadcastState(player);
        ShazamNetwork.sync(player);
    }

    /** Hood naik/turun (tombol H). Bisa saat jadi Shazam atau saat memakai Kostum Shazam. */
    public static void toggleHood(ServerPlayer player) {
        boolean wearingSuit = player.getItemBySlot(EquipmentSlot.CHEST).is(ShazamItems.SHAZAM_SUIT.get());
        if (!isTransformed(player) && !wearingSuit) {
            return;
        }
        long now = player.level().getGameTime();
        Long last = LAST_HOOD.get(player.getUUID());
        if (last != null && now - last < ShazamAnim.HOOD_TICKS) {
            return;   // tangan masih memakai/melepas hood
        }
        LAST_HOOD.put(player.getUUID(), now);
        ShazamData data = data(player);
        boolean up = !data.hoodUp();
        // Animasi tangan dulu, baru status: di client, hood baru bergerak saat tangan memegangnya
        ShazamNetwork.playAnim(player, up ? ShazamAnim.HOOD_UP : ShazamAnim.HOOD_DOWN);
        setData(player, data.withHoodUp(up));
        ShazamNetwork.broadcastState(player);
    }

    // ------------------------------------------- Ganti juara (tombol K atau /shazam form)

    /**
     * Tombol K: Shazam <-> Black Adam. Cuma kalau dua-duanya sudah didapat (lewat jalannya masing-masing), dan cuma dalam
     * wujud manusia (petir memilih juaranya sebelum menyambar).
     */
    public static void switchForm(ServerPlayer player) {
        ShazamData data = data(player);
        if (!data.anyUnlocked() || player.isSpectator()) {
            return;
        }
        if (!data.hasBoth()) {
            player.displayClientMessage(Component.translatable(data.unlocked() ? "message.shazammod.form_need_adam"
                    : "message.shazammod.form_need_shazam").withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC), true);
            return;
        }
        if (data.transformed()) {
            player.displayClientMessage(Component.translatable("message.shazammod.form_locked")
                    .withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC), true);
            return;
        }
        UUID id = player.getUUID();
        Long last = LAST_TOGGLE.get(id);
        if (TOGGLING.contains(id) || (last != null && player.level().getGameTime() - last < FORM_SWITCH_COOLDOWN_TICKS)) {
            return;   // ritual berubah/balik masih berjalan
        }
        setForm(player, data.champion().next(), true);
    }

    /** Pilih juara. Kalau sedang berubah wujud, balik jadi manusia dulu (tanpa petir). */
    public static void setForm(ServerPlayer player, ShazamForm form, boolean announce) {
        if (isTransformed(player)) {
            revert(player, false);
        }
        setData(player, data(player).withForm(form));
        ShazamNetwork.broadcastState(player);   // pemain lain perlu tahu dewa mana yang akan datang
        ShazamNetwork.sync(player);
        if (!announce) {
            return;
        }
        boolean adam = form == ShazamForm.BLACK_ADAM;
        player.displayClientMessage(Component.translatable("message.shazammod.form." + form.id)
                .withStyle(adam ? ChatFormatting.GOLD : ChatFormatting.YELLOW, ChatFormatting.BOLD), true);
        ServerLevel level = player.serverLevel();
        if (adam) {   // gema berat dari Kahndaq
            level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.RESPAWN_ANCHOR_SET_SPAWN,
                    SoundSource.PLAYERS, 0.9f, 0.6f);
            level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.SAND_BREAK,
                    SoundSource.PLAYERS, 1.0f, 0.7f);
        } else {
            level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.AMETHYST_BLOCK_CHIME,
                    SoundSource.PLAYERS, 1.2f, 1.2f);
            level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.BEACON_POWER_SELECT,
                    SoundSource.PLAYERS, 0.6f, 1.5f);
        }
    }

    // ------------------------------------------- Ucapan "SHAZAM" atau tombol G

    public static void onSayShazam(ServerPlayer player) {
        if (player.isSpectator()) {
            return;
        }
        ShazamData data = data(player);
        UUID id = player.getUUID();
        if (TOGGLING.contains(id) || ShazamTotems.isAwakening(player)) {
            return;
        }
        // Jalan Shazam: enam totem dewa dari enam penjaga kuil menyatu saat namanya diucapkan
        if (!data.unlocked() && !data.transformed() && ShazamTotems.hasAll(player)) {
            ShazamTotems.awaken(player);
            return;
        }
        if (!data.anyUnlocked()) {
            player.displayClientMessage(Component.translatable("message.shazammod.not_worthy")
                    .withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC), true);
            return;
        }
        long now = player.level().getGameTime();
        Long last = LAST_TOGGLE.get(id);
        if (last != null && now - last < TOGGLE_COOLDOWN_TICKS) {
            return;
        }

        if (data.transformed()) {
            LAST_TOGGLE.put(id, now);
            TOGGLING.add(id);
            ShazamNetwork.playAnim(player, ShazamAnim.REVERT);
            schedule(player, ShazamAnim.REVERT_WINDUP, p -> {
                TOGGLING.remove(p.getUUID());
                if (isTransformed(p)) {
                    revert(p, true);
                }
            });
        } else if (recoveryTicks(player) > 0) {
            // baru terlempar balik jadi manusia karena serangan mematikan: tubuh belum pulih
            player.displayClientMessage(Component.translatable("message.shazammod.recovering",
                    (recoveryTicks(player) + 19) / 20).withStyle(ChatFormatting.RED), true);
        } else if (data.energy() < MIN_ENERGY_TO_TRANSFORM) {
            player.displayClientMessage(Component.translatable("message.shazammod.no_energy",
                    Math.round(data.energy())).withStyle(ChatFormatting.RED), true);
        } else {
            LAST_TOGGLE.put(id, now);
            TOGGLING.add(id);
            // Roh enam dewa datang mengelilingi, lalu kepalan diangkat ke langit, lalu petir menyambar.
            // Dewa yang datang (Yunani/Ibrani atau Mesir) dipilih client dari juara di status pemain.
            ShazamNetwork.playAnim(player, ShazamAnim.SUMMON);
            player.serverLevel().playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.CONDUIT_ACTIVATE, SoundSource.PLAYERS, 1.4f, data.isBlackAdam() ? 0.55f : 0.8f);
            schedule(player, ShazamAnim.SUMMON_TICKS, p -> {
                ShazamNetwork.playAnim(p, ShazamAnim.TRANSFORM);
                schedule(p, ShazamAnim.TRANSFORM_WINDUP, q -> {
                    // Kepalan sudah di langit: dunia melambat, petir sihir turun pelan dari langit ke kepalan
                    ShazamSlowMo.begin(q);
                    spawnDescendingBolt(q);
                    schedule(q, ShazamAnim.BOLT_DESCENT, r -> {
                        TOGGLING.remove(r.getUUID());
                        ShazamData current = data(r);
                        if (current.anyUnlocked() && !current.transformed() && current.energy() >= MIN_ENERGY_TO_TRANSFORM) {
                            transform(r, true);
                            ShazamSlowMo.strike(r);   // tetap lambat sampai kostum selesai terbentuk
                        } else {
                            ShazamSlowMo.end(r.server);
                        }
                    });
                });
            });
        }
    }

    public static void transform(ServerPlayer player) {
        transform(player, false);
    }

    /** @param boltArrived petir yang turun pelan sudah sampai, jadi nggak perlu petir baru */
    public static void transform(ServerPlayer player, boolean boltArrived) {
        ShazamData data = data(player);
        setData(player, data.withTransformed(true).withEnergy(data.energy() - TRANSFORM_COST));
        FALL_GRACE.remove(player.getUUID());
        Vec3 pos = player.position();
        boolean adam = data.isBlackAdam();
        strikeLightning(player, pos, adam ? ADAM_TRANSFORM_STRIKE_DAMAGE : TRANSFORM_STRIKE_DAMAGE, TRANSFORM_STRIKE_RADIUS,
                2.4f, !boltArrived);
        ServerLevel level = player.serverLevel();
        int variant = data.champion().boltVariant();
        for (int i = 0; i < (adam ? 4 : 3); i++) { // petir-petir kecil menyambar di sekeliling
            double angle = level.random.nextDouble() * Math.PI * 2.0;
            double distance = 2.0 + level.random.nextDouble() * 2.0;
            spawnBolt(level, pos.add(Math.cos(angle) * distance, 0, Math.sin(angle) * distance), 0.7f, variant);
        }
        applyPowers(player);
        if (FULL_HEAL_ON_TRANSFORM) {
            player.setHealth(player.getMaxHealth());   // kekuatan petir sihir: darah langsung penuh, berapa pun sisanya
        }
        LAST_FLYING.remove(player.getUUID());
        ShazamNetwork.broadcastState(player);
        ShazamNetwork.sync(player);
    }

    public static void revert(ServerPlayer player, boolean withLightning) {
        setData(player, data(player).withTransformed(false));
        ShazamSkills.cancelActive(player);
        AdamSkills.cancelActive(player);
        cancelScheduled(player);
        if (withLightning) {
            strikeLightning(player, player.position(), 0f, 0.0, 1.2f);
        }
        removePowers(player);
        if (FULL_HEAL_ON_REVERT && !player.isDeadOrDying()) {
            player.setHealth(player.getMaxHealth());   // seperti di komik: balik jadi manusia langsung pulih, walau tadi sekarat
        }
        if (!player.onGround()) {
            FALL_GRACE.add(player.getUUID()); // balik jadi manusia di udara: pendaratan pertama nggak sakit
        }
        LAST_FLYING.remove(player.getUUID());
        ShazamNetwork.broadcastState(player);
        ShazamNetwork.sync(player);
    }

    /**
     * Serangan yang mestinya mematikan saat jadi Shazam: kekuatan sihir tercabut dari tubuh dan kamu terlempar
     * balik jadi manusia, tapi tetap hidup. Darahnya ikut aturan balik biasa (FULL_HEAL_ON_REVERT), dan selama
     * KNOCKOUT_COOLDOWN_TICKS belum bisa SHAZAM lagi (tanpa jeda ini Shazam praktis nggak bisa mati: tinggal berubah
     * lagi, kebal selama ritual, lalu darah langsung penuh).
     */
    public static void knockOut(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        // Animasi dulu, baru status: di client badan terhentak tepat saat kostum mulai luruh
        ShazamNetwork.playAnim(player, ShazamAnim.KNOCKOUT);
        level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.LIGHTNING_BOLT_IMPACT,
                SoundSource.PLAYERS, 1.6f, 0.6f);
        revert(player, false);   // tanpa petir dari langit: kekuatannya keluar dari dada (lihat client.fx.ShazamFx)
        long now = level.getGameTime();
        LAST_TOGGLE.put(player.getUUID(), now);   // jeda biasa 2 detik tetap berlaku kalau waktu pulihnya 0
        if (KNOCKOUT_COOLDOWN_TICKS > 0) {
            setData(player, data(player).withKnockoutUntil(now + KNOCKOUT_COOLDOWN_TICKS));
        }
        player.displayClientMessage(Component.translatable("message.shazammod.knocked_out")
                .withStyle(ChatFormatting.RED), true);
        ShazamNetwork.sync(player);
    }

    /** Sisa tick sampai bisa SHAZAM lagi sesudah terlempar balik jadi manusia (0 = sudah bisa). */
    public static int recoveryTicks(Player player) {
        long left = data(player).knockoutUntil() - player.level().getGameTime();
        return left > 0 ? (int) Math.min(left, KNOCKOUT_COOLDOWN_TICKS) : 0;
    }

    // ------------------------------------------ Kekuatan yang dipasang/dicabut

    private static void applyPowers(ServerPlayer player) {
        setHealthBonus(player, true);
        for (Boost boost : BOOSTS) {
            addBoost(player, boost);
        }
        for (Boost boost : ADAM_BOOSTS) {
            AttributeInstance instance = player.getAttribute(boost.attribute());
            if (instance != null) {
                instance.removeModifier(boost.id());
            }
            if (data(player).isBlackAdam()) {
                addBoost(player, boost);
            }
        }
        // M - Mercury: terbang (double-tap spasi)
        if (!player.isCreative() && !player.isSpectator()) {
            player.getAbilities().mayfly = true;
            player.onUpdateAbilities();
        }
    }

    private static void addBoost(ServerPlayer player, Boost boost) {
        AttributeInstance instance = player.getAttribute(boost.attribute());
        if (instance != null) {
            instance.removeModifier(boost.id());
            instance.addTransientModifier(new AttributeModifier(boost.id(), boost.amount(), boost.operation()));
        }
    }

    private static void removePowers(ServerPlayer player) {
        for (List<Boost> list : List.of(BOOSTS, ADAM_BOOSTS)) {
            for (Boost boost : list) {
                AttributeInstance instance = player.getAttribute(boost.attribute());
                if (instance != null) {
                    instance.removeModifier(boost.id());
                }
            }
        }
        setHealthBonus(player, false);
        if (!player.isCreative() && !player.isSpectator()) {
            player.getAbilities().mayfly = false;
            player.getAbilities().flying = false;
            player.onUpdateAbilities();
        }
    }

    /**
     * Darah tambahan. Disimpan permanen supaya tetap ada setelah keluar-masuk world,
     * dan darah saat ini ikut diskalakan (20/20 jadi 300/300, 10/20 jadi 150/300).
     * Darah tambahan dari versi lama (angkanya beda) diganti dengan angka yang sekarang.
     */
    private static void setHealthBonus(ServerPlayer player, boolean on) {
        AttributeInstance instance = player.getAttribute(Attributes.MAX_HEALTH);
        if (instance == null) {
            return;
        }
        double bonus = data(player).isBlackAdam() ? ADAM_BONUS_HEALTH : BONUS_HEALTH;
        AttributeModifier existing = instance.getModifier(SHAZAM_HEALTH);
        if (on ? existing != null && existing.amount() == bonus : existing == null) {
            return;   // sudah sesuai
        }
        float ratio = player.getHealth() / Math.max(1f, player.getMaxHealth());
        instance.removeModifier(SHAZAM_HEALTH);
        if (on) {
            instance.addPermanentModifier(new AttributeModifier(SHAZAM_HEALTH, bonus, AttributeModifier.Operation.ADD_VALUE));
        }
        if (!player.isDeadOrDying()) {
            player.setHealth(Math.max(1f, ratio * player.getMaxHealth()));
        }
    }

    // ---------------------------------------------------- Tiap tick (server)

    public static boolean isInStorm(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        return level.isThundering() && level.canSeeSky(player.blockPosition());
    }

    /** Berkah Aton: siang, nggak hujan, dan langit terbuka di atas kepala (kekuatan Black Adam dari matahari Kahndaq). */
    public static boolean isInSun(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        return level.isDay() && !level.isRaining() && level.canSeeSky(player.blockPosition().above());
    }

    public static void tick(ServerPlayer player) {
        runScheduled(player);
        if (FALL_GRACE.contains(player.getUUID()) && player.onGround()) {
            FALL_GRACE.remove(player.getUUID());
        }
        ShazamData data = data(player);
        if (!data.anyUnlocked()) {
            return;
        }
        // Waktu pulih sesudah serangan mematikan habis: kabari kalau petir sudah mau menjawab lagi
        if (data.knockoutUntil() != 0L && recoveryTicks(player) <= 0) {
            data = data.withKnockoutUntil(0L);
            setData(player, data);
            player.displayClientMessage(Component.translatable("message.shazammod.recovered")
                    .withStyle(ChatFormatting.GOLD), true);
        }

        float perSecond;
        if (data.isBlackAdam()) {   // Black Adam: matahari Kahndaq (badai petir nggak membantu)
            boolean sun = isInSun(player);
            perSecond = data.transformed()
                    ? (sun ? ADAM_SUN_CHARGE_PER_SECOND : -ADAM_DRAIN_PER_SECOND)
                    : ADAM_RECHARGE_PER_SECOND * (sun ? ADAM_SUN_RECHARGE_MULTIPLIER : 1f);
        } else {
            boolean storm = isInStorm(player);
            perSecond = data.transformed()
                    ? (storm ? STORM_CHARGE_WHILE_TRANSFORMED : -DRAIN_PER_SECOND)
                    : RECHARGE_PER_SECOND * (storm ? STORM_RECHARGE_MULTIPLIER : 1f);
        }
        float energy = Mth.clamp(data.energy() + perSecond / 20f, 0f, MAX_ENERGY);
        if (energy != data.energy()) {
            setData(player, data.withEnergy(energy));
        }

        if (data.transformed()) {
            if (energy <= 0f) {
                revert(player, true);
                player.displayClientMessage(Component.translatable("message.shazammod.energy_empty")
                        .withStyle(ChatFormatting.RED), true);
                return;
            }
            tickPowers(player, player.serverLevel());
            if (data.isBlackAdam()) {
                AdamSkills.tick(player);
            } else {
                ShazamSkills.tick(player);
            }

            // Kabari pemain lain kalau dia mulai/berhenti terbang (buat pose terbang)
            boolean flying = player.getAbilities().flying;
            Boolean lastFlying = LAST_FLYING.get(player.getUUID());
            if (lastFlying == null || lastFlying != flying) {
                LAST_FLYING.put(player.getUUID(), flying);
                ShazamNetwork.broadcastState(player);
            }
        }

        if (player.tickCount % 5 == 0) {
            ShazamNetwork.sync(player); // data buat HUD
        }
    }

    private static void tickPowers(ServerPlayer player, ServerLevel level) {
        // S - Solomon: bisa melihat dalam gelap
        MobEffectInstance nightVision = player.getEffect(MobEffects.NIGHT_VISION);
        if (nightVision == null || (!nightVision.isInfiniteDuration() && nightVision.getDuration() < 220)) {
            player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 300, 0, true, false, false));
        }
        // S - Solomon: monster di sekitar kelihatan tembus dinding
        if (player.tickCount % 20 == 0) {
            AABB area = player.getBoundingBox().inflate(GLOW_RADIUS);
            for (Mob mob : level.getEntitiesOfClass(Mob.class, area, m -> m instanceof Enemy && m.isAlive())) {
                mob.addEffect(new MobEffectInstance(MobEffects.GLOWING, 30, 0, false, false));
            }
        }
        // A - Atlas: bar lapar nggak pernah turun, nggak perlu napas, dan pulih terus
        if (player.getFoodData().getFoodLevel() < 20) {
            player.getFoodData().eat(1, 0f);
        }
        if (player.getAirSupply() < player.getMaxAirSupply()) {
            player.setAirSupply(player.getMaxAirSupply());
        }
        if (player.tickCount % 10 == 0 && player.getHealth() < player.getMaxHealth()) {
            float regen = REGEN_PER_SECOND;
            if (data(player).isBlackAdam()) {   // Shu & Aton: pulih pelan di malam hari, cepat sekali di bawah matahari
                regen = ADAM_REGEN_PER_SECOND * (isInSun(player) ? ADAM_SUN_REGEN_MULTIPLIER : 1f);
            }
            player.heal(regen / 2f);
        }
        // Z - Zeus: api langsung padam
        if (player.isOnFire()) {
            player.clearFire();
        }
        // A - Achilles: efek penghambat langsung hilang
        for (Holder<MobEffect> debuff : DEBUFFS) {
            if (player.hasEffect(debuff)) {
                player.removeEffect(debuff);
            }
        }
        // M - Mercury: pasang lagi kemampuan terbang kalau sempat hilang (misalnya habis ganti gamemode)
        if (!player.isCreative() && !player.isSpectator() && !player.getAbilities().mayfly) {
            player.getAbilities().mayfly = true;
            player.onUpdateAbilities();
        }
    }

    // ------------------------------------------------------------------ Damage & petir

    private static DamageSource source(ServerPlayer caster, ResourceKey<DamageType> type) {
        return new DamageSource(caster.serverLevel().registryAccess()
                .registryOrThrow(Registries.DAMAGE_TYPE)
                .getHolderOrThrow(type), caster);
    }

    public static DamageSource lightningSource(ServerPlayer caster) {
        return source(caster, ShazamMod.SHAZAM_LIGHTNING);
    }

    public static DamageSource forceSource(ServerPlayer caster) {
        return source(caster, ShazamMod.SHAZAM_FORCE);
    }

    /** Petir sihir dengan ukuran normal. */
    public static void strikeLightning(ServerPlayer caster, Vec3 pos, float damage, double radius) {
        strikeLightning(caster, pos, damage, radius, 1.0f);
    }

    /** Petir sihir emas (cuma tampilan, nggak bikin api atau mengubah mob); damage-nya dihitung sendiri. */
    public static void strikeLightning(ServerPlayer caster, Vec3 pos, float damage, double radius, float size) {
        strikeLightning(caster, pos, damage, radius, size, true);
    }

    public static void strikeLightning(ServerPlayer caster, Vec3 pos, float damage, double radius, float size,
                                       boolean withBolt) {
        ServerLevel level = caster.serverLevel();
        if (withBolt) {
            spawnBolt(level, pos, size, boltVariant(caster));
        }
        level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.WEATHER,
                3.0f + size * 2.0f, ShazamSlowMo.pitch(level.getServer(), 0.8f + level.random.nextFloat() * 0.2f));
        level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.WEATHER,
                2.0f, ShazamSlowMo.pitch(level.getServer(), 0.5f + level.random.nextFloat() * 0.2f));
        if (damage <= 0f) {
            return;
        }
        DamageSource source = lightningSource(caster);
        AABB area = new AABB(pos, pos).inflate(radius);
        // Cuma kena monster: pemain lain, hewan peliharaan, dan villager aman
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, area,
                m -> m.isAlive() && m instanceof Enemy)) {
            target.hurt(source, damage);
        }
    }

    /** Titik kepalan yang terangkat (di atas kepala) - sasaran petir transformasi. */
    public static final double FIST_HEIGHT = 2.3;

    /** Petir transformasi: turun pelan dari langit sampai ke kepalan dalam BOLT_DESCENT tick. */
    private static void spawnDescendingBolt(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        MagicBolt bolt = ShazamEntities.MAGIC_BOLT.get().create(level);
        Vec3 fist = player.position().add(0, FIST_HEIGHT * player.getScale(), 0);
        if (bolt != null) {
            bolt.moveTo(fist.x, fist.y, fist.z);
            bolt.setBoltSize(2.4f);
            bolt.setDescent(ShazamAnim.BOLT_DESCENT);
            bolt.setVariant(boltVariant(player));
            level.addFreshEntity(bolt);
        }
        level.playSound(null, fist.x, fist.y, fist.z, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.WEATHER,
                4.0f, ShazamSlowMo.pitch(level.getServer(), 0.6f));
    }

    public static void spawnBolt(ServerLevel level, Vec3 pos, float size) {
        spawnBolt(level, pos, size, 0);
    }

    /** variant: warna petir (0 = emas Shazam, 1 = emas-jingga Black Adam). */
    public static void spawnBolt(ServerLevel level, Vec3 pos, float size, int variant) {
        MagicBolt bolt = ShazamEntities.MAGIC_BOLT.get().create(level);
        if (bolt != null) {
            bolt.moveTo(pos.x, pos.y, pos.z);
            bolt.setBoltSize(size);
            bolt.setVariant(variant);
            level.addFreshEntity(bolt);
        }
    }

    /** Warna petir juara pemain ini. */
    public static int boltVariant(ServerPlayer player) {
        return data(player).champion().boltVariant();
    }

    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        DamageSource source = event.getSource();
        ShazamPassives.onInnocentHurt(event.getEntity(), source);   // Hati Pahlawan: makhluk tak berdosa diserang monster

        if (event.getEntity() instanceof ServerPlayer victim) {
            if (SAFE_DURING_RITUAL && (TOGGLING.contains(victim.getUUID()) || ShazamTotems.isAwakening(victim)
                    || KahndaqTrial.isAwakening(victim)) && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
                event.setCanceled(true);   // ritual berubah/balik dilindungi petir sihir: nggak mati di tengah ritual
                return;
            }
            if (source.is(DamageTypeTags.IS_FALL) && FALL_GRACE.remove(victim.getUUID())) {
                event.setCanceled(true);
                return;
            }
            if (isTransformed(victim)) {
                if (ShazamSkills.isHeldBy(victim, source.getEntity())) {
                    event.setCanceled(true);   // musuh yang sedang diangkat Hercules nggak bisa melukai yang mengangkatnya
                    return;
                }
                if (source.is(DamageTypeTags.IS_LIGHTNING) && !source.is(ShazamMod.SHAZAM_LIGHTNING)
                        && !data(victim).isBlackAdam()) {
                    ShazamPassives.absorbLightning(victim);   // Penangkal Petir Hidup: petir alam diserap jadi kekuatan
                }
                // A - Atlas & Z - Zeus: kebal jatuh, petir, api, tenggelam, beku, lapar, dan duri
                if (source.is(DamageTypeTags.IS_FALL) || source.is(DamageTypeTags.IS_LIGHTNING)
                        || source.is(DamageTypeTags.IS_FIRE) || source.is(DamageTypeTags.IS_DROWNING)
                        || source.is(DamageTypeTags.IS_FREEZING) || source.is(DamageTypes.STARVE)
                        || source.is(DamageTypes.CACTUS) || source.is(DamageTypes.SWEET_BERRY_BUSH)
                        || source.is(ShazamMod.SHAZAM_LIGHTNING) || source.is(ShazamMod.SHAZAM_FORCE)) {
                    event.setCanceled(true);
                    return;
                }
                boolean adam = data(victim).isBlackAdam();
                if (adam && ADAM_PROJECTILE_IMMUNE && source.is(DamageTypeTags.IS_PROJECTILE)) {
                    // Kulit Kahndaq: proyektil memantul tanpa melukai (panah vanilla otomatis terpental balik)
                    event.setCanceled(true);
                    deflect(victim, source);
                    return;
                }
                if (!adam && ShazamPassives.tryDodge(victim, source)) {
                    event.setCanceled(true);   // Refleks Mercury: serangan ini dihindari secepat kilat
                    return;
                }
                if (!adam && source.getEntity() instanceof LivingEntity foe && ShazamSkills.isExposed(foe)) {
                    // Kebijaksanaan Solomon: gerakan musuh yang sudah "terbaca" bisa diantisipasi
                    event.setAmount(event.getAmount() * ShazamSkills.SOLOMON_FORESIGHT);
                }
                if (source.is(DamageTypes.MAGIC) || source.is(DamageTypes.INDIRECT_MAGIC)) {
                    event.setAmount(event.getAmount() * MAGIC_DAMAGE_MULTIPLIER); // kelemahan: sihir
                } else if (!source.is(DamageTypeTags.BYPASSES_RESISTANCE)) {
                    // A - Atlas: tahan banting (Black Adam: kulit Kahndaq lebih keras lagi)
                    event.setAmount(event.getAmount() * (adam ? ADAM_DAMAGE_TAKEN_MULTIPLIER : DAMAGE_TAKEN_MULTIPLIER));
                }
                if (ShazamSkills.isAchillesActive(victim) && !source.is(DamageTypeTags.BYPASSES_RESISTANCE)) {
                    float before = event.getAmount();
                    event.setAmount(before * ShazamSkills.ACHILLES_DAMAGE_MULTIPLIER); // perisai Achilles
                    ShazamSkills.storeCourage(victim, before - event.getAmount());   // disimpan buat Ledakan Keberanian
                }
                if (!adam) {
                    ShazamPassives.onHurt(victim);   // Muatan Petir: dipukul pun menambah muatan
                }
                if (AdamSkills.isMehenActive(victim) && !source.is(DamageTypeTags.BYPASSES_RESISTANCE)) {
                    event.setAmount(event.getAmount() * AdamSkills.MEHEN_DAMAGE_MULTIPLIER);   // lilitan ular Mehen
                    AdamSkills.mehenRetaliate(victim, source);
                }
            }
        }

        // H - Hercules: pukulan tangan kosong super kuat; pakai senjata pun damage-nya berlipat
        if (source.getEntity() instanceof ServerPlayer attacker
                && source.getDirectEntity() == attacker
                && source.is(DamageTypes.PLAYER_ATTACK)
                && isTransformed(attacker)) {
            if (attacker.getMainHandItem().isEmpty()) {
                boolean adam = data(attacker).isBlackAdam();
                event.setAmount(event.getAmount() * (adam ? ADAM_PUNCH_MULTIPLIER : PUNCH_MULTIPLIER));
                if (adam) {   // tinju Black Adam: percikan petir membara di titik kena
                    LivingEntity hit = event.getEntity();
                    ShazamNetwork.playAnim(attacker, ShazamAnim.ADAM_PUNCH, hit.position().add(0, hit.getBbHeight() * 0.6, 0));
                } else if (event.getEntity() instanceof Enemy) {
                    // Shazam 0.23: Amarah Pahlawan, lalu Muatan Petir (penuh = Pukulan Guntur)
                    event.setAmount(event.getAmount() * ShazamPassives.heroMultiplier(attacker));
                    if (ShazamPassives.consumeCharge(attacker)) {
                        event.setAmount(event.getAmount() * ShazamPassives.THUNDER_PUNCH_MULTIPLIER);
                        ShazamPassives.thunderPunch(attacker, event.getEntity());
                    } else {
                        ShazamPassives.addCharge(attacker, ShazamPassives.CHARGE_PER_HIT);
                    }
                }
                if (ShazamSkills.isRageActive(attacker)) {
                    // Zeus Rage: tinju berpetir yang merambat ke musuh di dekatnya
                    event.setAmount(event.getAmount() * ShazamSkills.RAGE_PUNCH_MULTIPLIER);
                    ShazamSkills.ragePunch(attacker, event.getEntity());
                } else if (AdamSkills.isRageActive(attacker)) {
                    // Murka Kahndaq: tinju membara yang meledak dan menyambar musuh lain
                    event.setAmount(event.getAmount() * AdamSkills.RAGE_PUNCH_MULTIPLIER);
                    AdamSkills.ragePunch(attacker, event.getEntity());
                }
            } else {
                event.setAmount(event.getAmount() * WEAPON_MULTIPLIER);
            }
        }

        // S - Solomon: musuh yang sudah "dibaca" menerima damage lebih besar dari Shazam
        if (source.getEntity() instanceof ServerPlayer attacker && isTransformed(attacker)
                && ShazamSkills.isExposed(event.getEntity())) {
            event.setAmount(event.getAmount() * EXPOSED_MULTIPLIER);
        }
        // Z - Zehuti: musuh yang tersegel hieroglif menerima damage lebih besar dari Black Adam
        if (source.getEntity() instanceof ServerPlayer attacker && isTransformed(attacker)
                && AdamSkills.isSealed(event.getEntity())) {
            event.setAmount(event.getAmount() * AdamSkills.SEAL_MULTIPLIER);
        }
    }

    /** Proyektil memantul dari kulit Black Adam: percikan & denting di titik kena. */
    private static void deflect(ServerPlayer victim, DamageSource source) {
        Entity projectile = source.getDirectEntity();
        Vec3 at = projectile != null ? projectile.position() : victim.getEyePosition();
        ServerLevel level = victim.serverLevel();
        level.playSound(null, at.x, at.y, at.z, SoundEvents.SHIELD_BLOCK, SoundSource.PLAYERS, 1.0f,
                1.5f + level.random.nextFloat() * 0.3f);
        level.playSound(null, at.x, at.y, at.z, SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 0.25f,
                1.9f + level.random.nextFloat() * 0.1f);
        ShazamNetwork.playAnim(victim, ShazamAnim.ADAM_DEFLECT, at);
    }

    /**
     * Damage final (sesudah armor, enchantment, efek, dan semua mod lain) yang bakal menghabisi Shazam: damage-nya
     * dibatalkan dan Shazam terlempar balik jadi manusia. Dicek sebelum darah dikurangi, jadi totem of undying nggak
     * ikut kepakai dan suara mati nggak terdengar. Absorption (hati emas) ikut dihitung.
     */
    public static void onDamagePre(LivingDamageEvent.Pre event) {
        if (!REVERT_INSTEAD_OF_DEATH || !(event.getEntity() instanceof ServerPlayer player) || !isTransformed(player)) {
            return;
        }
        var container = event.getContainer();
        if (container.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return;   // jatuh ke void dan /kill tetap mematikan, sama seperti saat ritual
        }
        // Damage yang tersisa sesudah ditahan hati emas (kalau di titik ini hati emasnya sudah terpakai, sisanya 0)
        float toHealth = container.getNewDamage() - player.getAbsorptionAmount();
        if (toHealth >= player.getHealth()) {
            container.setNewDamage(0f);
            knockOut(player);
        }
    }

    /** Jaga-jaga kalau masih ada jalan mati lain saat jadi Shazam (misalnya dari mod lain): tetap terlempar balik. */
    public static void onDeath(LivingDeathEvent event) {
        if (REVERT_INSTEAD_OF_DEATH && event.getEntity() instanceof ServerPlayer player && isTransformed(player)
                && !event.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            event.setCanceled(true);
            player.setHealth(1f);   // keluar dari keadaan sekarat dulu, supaya darahnya bisa dipulihkan saat balik
            knockOut(player);
        }
    }

    /** S - Solomon: XP dari mob yang dikalahkan +50%. */
    public static void onExperienceDrop(LivingExperienceDropEvent event) {
        Player attacker = event.getAttackingPlayer();
        if (attacker != null && isTransformed(attacker)) {
            event.setDroppedExperience(Math.round(event.getDroppedExperience() * XP_MULTIPLIER));
        }
    }

    // ---------------------------------------------- Login / respawn / logout

    public static void onLogin(ServerPlayer player) {
        if (isTransformed(player)) {
            applyPowers(player); // modifier atribut nggak ikut tersimpan, jadi dipasang ulang
        } else {
            setHealthBonus(player, false); // bersihkan sisa darah tambahan kalau ada
        }
        ShazamNetwork.broadcastState(player);
        if (data(player).anyUnlocked()) {
            ShazamNetwork.sync(player);
        }
    }

    public static void onRespawn(ServerPlayer player) {
        ShazamSkills.cancelActive(player);
        AdamSkills.cancelActive(player);
        cancelScheduled(player);
        removePowers(player);
        if (isTransformed(player)) {
            setData(player, data(player).withTransformed(false)); // hidup lagi sebagai manusia biasa
        }
        if (data(player).knockoutUntil() != 0L) {
            setData(player, data(player).withKnockoutUntil(0L)); // mati beneran: waktu pulihnya ikut hilang
        }
        FALL_GRACE.remove(player.getUUID());
        LAST_FLYING.remove(player.getUUID());
        ShazamNetwork.broadcastState(player);
        if (data(player).anyUnlocked()) {
            ShazamNetwork.sync(player);
        }
    }

    public static void onLogout(ServerPlayer player) {
        UUID id = player.getUUID();
        LAST_TOGGLE.remove(id);
        LAST_HOOD.remove(id);
        FALL_GRACE.remove(id);
        TOGGLING.remove(id);
        LAST_FLYING.remove(id);
        DELAYED.remove(id);
        ShazamSkills.forget(id);
        AdamSkills.forget(id);
        ShazamFlightServer.forget(id);
        ShazamTotems.forget(id);
    }
}
