package com.shazammod;

/**
 * Juara yang dipilih pemain. Dua-duanya berubah dengan kata yang sama ("SHAZAM"), tapi kekuatannya dari dewa yang beda:
 *
 * SHAZAM     : Solomon, Hercules, Atlas, Zeus, Achilles, Mercury (jubah putih, petir emas).
 * BLACK_ADAM : Shu, Heru, Amon, Zehuti, Aton, Mehen - dewa-dewa Mesir, juara Kahndaq (jubah hitam, petir emas-jingga).
 *
 * Urutannya dipakai sebagai id di save dan di jaringan, jadi tambah yang baru di paling bawah.
 */
public enum ShazamForm {
    SHAZAM("shazam"),
    BLACK_ADAM("black_adam");

    public final String id;

    ShazamForm(String id) {
        this.id = id;
    }

    public static ShazamForm byId(int id) {
        ShazamForm[] values = values();
        return id >= 0 && id < values.length ? values[id] : SHAZAM;
    }

    public static ShazamForm byName(String name) {
        for (ShazamForm form : values()) {
            if (form.id.equals(name)) {
                return form;
            }
        }
        return null;
    }

    /** Juara berikutnya (tombol ganti juara). */
    public ShazamForm next() {
        ShazamForm[] values = values();
        return values[(ordinal() + 1) % values.length];
    }

    /** Jenis petir sihir (lihat MagicBolt): 0 = emas Shazam, 1 = emas-jingga Black Adam. */
    public int boltVariant() {
        return this == BLACK_ADAM ? 1 : 0;
    }
}
