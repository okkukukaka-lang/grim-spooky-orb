package com.shazammod;

import java.util.function.Supplier;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

@Mod(ShazamMod.MODID)
public class ShazamMod {
    public static final String MODID = "shazammod";

    private static final DeferredRegister<AttachmentType<?>> ATTACHMENT_TYPES =
            DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, MODID);

    // Data Shazam milik tiap pemain: ikut tersimpan di save world dan tetap ada setelah mati
    public static final Supplier<AttachmentType<ShazamData>> SHAZAM_DATA = ATTACHMENT_TYPES.register(
            "shazam_data",
            () -> AttachmentType.builder(() -> ShazamData.DEFAULT)
                    .serialize(ShazamData.CODEC)
                    .copyOnDeath()
                    .build());

    // Jenis damage khusus petir Shazam (JSON-nya di data/shazammod/damage_type/)
    public static final ResourceKey<DamageType> SHAZAM_LIGHTNING =
            ResourceKey.create(Registries.DAMAGE_TYPE, id("shazam_lightning"));

    // Jenis damage untuk skill fisik (tepukan, hantaman, terjangan)
    public static final ResourceKey<DamageType> SHAZAM_FORCE =
            ResourceKey.create(Registries.DAMAGE_TYPE, id("shazam_force"));

    public ShazamMod(IEventBus modEventBus, ModContainer modContainer) {
        ATTACHMENT_TYPES.register(modEventBus);
        ShazamEntities.ENTITY_TYPES.register(modEventBus);
        ShazamArmor.ARMOR_MATERIALS.register(modEventBus);
        ShazamItems.ITEMS.register(modEventBus);
        AdamItems.ITEMS.register(modEventBus);
    }

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MODID, path);
    }
}
