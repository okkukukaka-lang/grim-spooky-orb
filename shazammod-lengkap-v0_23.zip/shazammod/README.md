# Mod Shazam untuk Minecraft 1.21.1 (NeoForge)

Versi 0.23.0. Isinya:
- **Shazam juara para dewa (0.23):** tiap skill memanggil dewanya sebagai raksasa cahaya yang ikut bertarung (Avatar Dewa), lima pasif baru yang cuma dimiliki Shazam, dan skill yang dirombak supaya punya mekanik sendiri, beda total dari Black Adam. Lihat *Yang baru di 0.23*.
- Dua juara yang beda total: **Shazam** (enam dewa Yunani & Ibrani) dan **Black Adam** (juara Kahndaq, enam dewa Mesir). Jalan mendapatkannya beda (enam totem penjaga vs Skarabe Teth-Adam & Ujian Kahndaq di gurun), badan & kekuatannya beda, dan efek skill Black Adam bergaya film. Punya dua-duanya? Tombol K buat ganti.
- Transformasi SHAZAM beranimasi: enam dewa datang satu per satu dengan cara masuk masing-masing, enam kekuatan S-H-A-Z-A-M, dan Energi Petir.
- Enam skill (plus Zeus Rage) yang masing-masing punya gerakan sendiri (ancang-ancang, gemetar mengumpulkan tenaga, gerakan utama yang menghentak) dan efek visual buatan sendiri yang tebal, bukan partikel Minecraft.
- Terbang berbasis momentum dengan fisika dunia nyata (hambatan udara, belokan menikung, gravitasi saat menukik) ala Create: Lanterns: sonic boom, barrel roll, hero landing, dan kamera menikung.
- Kekuatan seperti di komik: darah 300, armor penuh, tahan banting, pukulan 40, darah langsung penuh tiap berubah wujud, dan Energi Petir 1000. Serangan mematikan nggak langsung membunuh: kamu terlempar balik jadi manusia.
- Jubah 3D dengan fisika kain dunia nyata yang utuh jadi satu pakaian: hood yang pas dengan kepala kotak Minecraft, mantel bahu dengan pelat emas, bros pengait dan rantai, dan jubah panjang. Plus lambang 3D yang berkilau saat berubah (skin tetap skin aslimu), dan kostum armor 4 bagian yang bisa di-craft.

## Yang baru di 0.23: Shazam, juara para dewa

Di 0.22 Black Adam dapat jalan, badan, dan efek sendiri. Sekarang giliran Shazam. Black Adam itu tank yang buas: kulitnya memantulkan proyektil, kekuatannya dari matahari, gerakannya berat. Shazam dibuat jadi kebalikannya: **pahlawan yang lincah, dilindungi para dewa, dan kekuatannya dari badai**. Tiap skill punya mekanik yang nggak dimiliki Black Adam, ada lima pasif baru, dan satu identitas visual yang cuma dia punya: **para dewa ikut bertarung**.

### Avatar Dewa

Tiap skill Shazam memanggil dewanya sebagai raksasa cahaya tembus pandang (±4 blok) yang berdiri di belakang Shazam dan bergerak bersamanya. Bentuknya sama dengan roh dewa saat transformasi.

| Skill | Yang dilakukan dewanya |
|---|---|
| Z Solomon | Membuka kitab dan mengangkat tangan memberkati, lalu segel bintang segi enam raksasa terproyeksi ke depan |
| X Hercules | Melompat dari belakang lalu menghantamkan gada tepat saat tepukan. Saat Lemparan Hercules, gadanya diayunkan ke arah lemparan |
| C Atlas | Mengangkat bola langit tinggi-tinggi selama bola langit jatuh |
| V Zeus | Melayang di atas bahu dan membidikkan petir di tangannya ke sasaran |
| B Achilles | Merunduk lalu menusukkan tombak tepat saat raungan, dan sekali lagi saat Ledakan Keberanian |
| R Badai Para Dewa | Keenam dewa berdiri melingkar, berputar pelan, dan menerjang tiap kali giliran serangannya tiba |

Dari sudut pandang orang pertama, avatar pindah ke samping-depan supaya tetap kelihatan. Avatar bisa dimatikan lewat `ENABLED` di `client/fx/GodAvatars.java` (roh dewa saat transformasi tetap ada).

### Pasif baru (khusus Shazam)

| Pasif | Cara kerja |
|---|---|
| **Muatan Petir** | Memukul musuh (+9), kena serangan (+4), terbang kencang, berlari dengan Mode Kilat, dan berdiri di bawah badai mengisi muatan listrik di badan. Saat kehujanan semuanya masuk 2x. Penuh (100) = kepalan berlistrik dan pukulan tangan kosong berikutnya jadi **Pukulan Guntur**: petir dari langit, damage x1,75, hempasan jauh, dan petir merambat ke 3 musuh lain (14 damage). |
| **Refleks Mercury** | Sekali tiap 8 detik, satu serangan (pukulan, panah, bola api, sonic boom) dihindari: Shazam melesat ke samping secepat kilat meninggalkan bayangan. Ledakan, jatuh, dan api nggak dihindari. Black Adam menahan serangan, Shazam menghindarinya. |
| **Hati Pahlawan** | Villager, hewan peliharaan, atau pemain lain diserang monster dalam 24 blok: tautan cahaya emas mengarah ke penyerangnya, penyerang itu bersinar dan terbaca (+25% damage dari Shazam), dan Shazam dapat **Amarah Pahlawan** (pukulan +25% selama 8 detik). |
| **Keluarga Shazam** | Pemain lain, villager, dan hewan peliharaan dalam 10 blok dapat Resistance I. |
| **Penangkal Petir Hidup** | Petir alam atau trisula Channeling yang menyambar Shazam diserap: +150 energi, +40 darah, dan Muatan Petir langsung penuh. Di bawah badai petir, sesekali (rata-rata tiap 25 detik) petir datang sendiri menyambar Shazam. |

### Skill dirombak

| Tombol | Skill | Mekanik baru | Biaya / cooldown |
|---|---|---|---|
| Z | **S - Kebijaksanaan Solomon** | Pindaian 48 blok seperti dulu (bersinar, +25% damage dari Shazam), ditambah: damage dari musuh yang terbaca tinggal **60%** (gerakannya sudah terbaca), dan **sihir pelindung mereka terhapus** (tak terlihat, kekuatan, kecepatan, pulih, dan efek baik lain). | 40 / 30 detik |
| X | **H - Tepukan Guntur Hercules** | Kerucut 9 blok, 20 damage dan terhempas, musuh **limbung** 2,5 detik (Slowness III + Weakness), dan **panah, bola api, serta proyektil lain di dalam kerucut hancur**. Petir menjalar di sepanjang kerucut. | 25 / 4 detik |
| Shift + X | **H - Lemparan Hercules** | Musuh di depan (sampai 5,5 blok, darah maksimal 200) diangkat ke atas kepala lalu **dilempar** ke arah pandangan. Begitu menabrak tanah, dinding, atau musuh lain: yang dilempar kena 26 damage dan musuh dalam 3,8 blok kena 18 dan terhempas. Tanpa musuh di depan: jadi Tepukan Guntur biasa. | sama dengan X |
| C | **A - Beban Langit Atlas** | Di tanah: kepalan diangkat menyangga langit, **bola langit berbintang raksasa jatuh**, musuh dalam 10 blok **tersedot ke pusat**, lalu kepalan menghantam: yang di tengah (6,5 blok) kena 30 damage dan **tertekan ke tanah** (terkunci 3 detik), yang di pinggir kena 10 dan terhempas keluar. Dari udara: menukik seperti meteor, hantaman yang sama saat mendarat. | 40 / 8 detik |
| V | **Z - Petir Berantai Zeus** | Petir keluar dari ujung jari (seperti di film) ke musuh yang dibidik lalu **melompat ke sampai 5 musuh lain** (7 blok tiap lompatan, damage turun 15% tiap lompatan). **Musuh basah** (di air atau kehujanan) kena 2x dan lompatannya lebih jauh. Ditutup sambaran dari langit di sasaran pertama. | 30 / 3 detik |
| B | **A - Perisai Achilles** | Hampir kebal 6 detik seperti dulu, ditambah: musuh dalam 14 blok **dipancing menyerang Shazam** (melindungi sekutu), perisai matahari emas di depan dada, dan semua damage yang ditahan perisai **dilepas di akhir sebagai Ledakan Keberanian** (12 + damage tertahan x2,5, maksimal 90, dalam 7,5 blok). | 80 / 45 detik |
| N | **M - Mode Kilat Mercury** | Tetap (sudah unik). | - |
| R | **Badai Para Dewa** | Pengganti Zeus Rage (yang dulu hampir kembar dengan Murka Kahndaq). Enam petir menyambar di enam penjuru, awan badai berputar di atas kepala, dan **keenam dewa mengelilingi Shazam selama 12 detik**. Tiap detik dua dewa bergiliran S-H-A-Z-A-M menyerang musuh terdekat dalam 14 blok dengan gayanya sendiri: Solomon menyegel (8 damage, terbaca), Hercules menghantamkan gada (16, terhempas), Atlas menjatuhkan bola langit kecil (14, terkunci), Zeus menyambar (14), Achilles menusukkan tombak cahaya (18, lemah), Mercury menerjang dua kali (9 + 9). Pukulan tetap +50% dan berpetir, lari lebih cepat. | 150 / 60 detik |

### Black Adam vs Shazam sekarang

| | Shazam | Black Adam |
|---|---|---|
| Gaya | Pahlawan lincah, para dewa ikut bertarung | Tank buas, berat, lugas |
| Bertahan | Menghindar (Refleks Mercury), membaca musuh (Solomon), menahan lalu membalas (Achilles) | Kulit memantulkan proyektil, damage diterima 35%, lilitan Mehen |
| Sumber kekuatan | Badai, hujan, dan petir alam | Matahari Kahndaq |
| Pasif unik | Muatan Petir, Pukulan Guntur, Hati Pahlawan, Keluarga Shazam, Penangkal Petir Hidup | Proyektil memantul, Berkah Aton, listrik membara di kulit |
| Kendali massa | Menyedot ke tengah (Atlas), melempar musuh (Hercules), memancing (Achilles) | Pusaran (Shu), segel (Zehuti), tanah terbelah (Amon) |
| Ultimate (R) | Badai Para Dewa: enam dewa bergiliran menyerang | Murka Kahndaq: petir membara memburu musuh |

### HUD

Di samping kotak S-H-A-Z-A-M ada dua kotak baru (khusus Shazam): **⚡ Muatan Petir** yang terisi dari bawah dan berkedip *SIAP* saat penuh, dan **» Refleks Mercury** yang biru saat siap mengelak (abu-abu dengan sisa detik saat belum siap).

### Cara ngetes cepat

- **Pukulan Guntur:** pukul monster 11 kali dengan tangan kosong, atau berdiri di bawah badai/hujan. Saat penuh ada pesan di atas hotbar.
- **Refleks Mercury:** biarkan skeleton menembakmu.
- **Hati Pahlawan:** `/summon zombie` di dekat villager atau serigala peliharaan.
- **Penangkal Petir Hidup:** `/weather thunder`, atau minta teman melempar trisula Channeling ke arahmu saat badai.
- **Lemparan Hercules:** tahan Shift lalu tekan X sambil menghadap monster dalam 5 blok.

Angka-angkanya ada di bagian atas `ShazamPassives.java` (pasif), `ShazamSkills.java` (skill), dan `client/fx/GodAvatars.java` (ukuran, kepekatan, dan lingkaran avatar). Efek baru di `client/fx/ChampionFx.java`.

## Yang baru di 0.22: Black Adam beda total dari Shazam

Black Adam sekarang bukan sekadar "Shazam warna hitam". Cara mendapatkannya beda, badannya beda, kekuatannya beda, dan semua efek & animasi skill-nya ditulis ulang supaya tebal dan sinematik seperti di film.

### Dua jalan, dua juara

| | Shazam | Black Adam |
|---|---|---|
| Dipilih oleh | Penyihir di Batu Keabadian | Dewan Kahndaq (enam dewa Mesir) |
| Syarat | Kalahkan enam penjaga kuil, kumpulkan keenam totemnya | Temukan Skarabe Teth-Adam, lulus Ujian Kahndaq |
| Cara membuka | Ucapkan SHAZAM sambil membawa keenam totem | Klik kanan skarabe di gurun/badlands (wujud manusia, langit terbuka) |
| Tempat | Di mana saja | Tanah Kahndaq: gurun atau badlands |

- Dua juara terpisah: punya yang satu belum tentu punya yang lain. Tombol **K** (ganti juara) baru berfungsi kalau kamu sudah punya dua-duanya.
- Save dari 0.21 yang memilih Black Adam tanpa ujian otomatis memakai Shazam sampai Black Adam didapat lewat jalannya (buat ngetes: `/shazam unlock black_adam`).

#### Jalan Shazam: enam totem

1. Kalahkan enam penjaga kuil (Solomon, Hercules, Atlas, Zeus, Achilles, Mercury). Untuk sekarang penjaganya dimunculkan dengan telur spawn (tab Creative) atau `/shazam summon <nama>`.
2. Tiap penjaga menjatuhkan totemnya. Kumpulkan keenamnya di inventory.
3. Ucapkan **SHAZAM** (ketik di chat atau tombol G). Keenam totem terangkat dan berputar mengelilingimu sebagai enam cahaya berwarna (ungu Solomon, hijau pucat Hercules, jingga Atlas, emas Zeus, emas pucat Achilles, biru muda Mercury), menyatu jadi bintang emas di atas kepala, lalu petir Penyihir menyambar. Totemnya habis terpakai, dan kekuatan Shazam terbuka.

#### Jalan Black Adam: Skarabe Teth-Adam & Ujian Kahndaq

1. **Temukan Skarabe Teth-Adam** (jimat kumbang emas berpermata pirus). Ada di peti **Piramida Gurun** (Desert Temple), peluang 30% tiap peti (satu piramida punya 4 peti), atau sesekali (2%) dijatuhkan Husk yang kamu kalahkan di gurun.
2. Bawa ke **gurun atau badlands**, berdiri di bawah **langit terbuka**, dalam **wujud manusia**, lalu **klik kanan** skarabenya. (Nggak bisa di Peaceful.)
3. **Ujian Kahndaq** dimulai: skarabe diangkat ke langit, lingkaran hieroglif menyala di tanah, badai pasir raksasa melingkari tanah ujian, dan **Bayangan Teth-Adam** (siluet bertudung dari asap setinggi ±12 blok, mata membara, lambang petir samar di dada) menjulang di dalam badai sambil bersuara di chat. Tiga gelombang makhluk makam menyeruak dari pasir:
   - Gelombang 1: 5 Prajurit Makam Kahndaq (Husk berhelm emas).
   - Gelombang 2: 3 Prajurit Makam berpedang emas + 6 Kumbang Skarabe.
   - Gelombang 3: **Penjaga Makam Teth-Adam**, Husk raksasa setinggi ±4,5 blok (darah 220, berzirah & berpedang emas), ditemani 2 prajurit.

   Bar di atas layar menunjukkan gelombang dan sisa musuh (di gelombang 3: darah sang penjaga).
4. **Lulus:** badai runtuh ke dalam, enam cahaya dewa Mesir mengorbit, skarabe naik ke atas kepala lalu menyatu ke dadamu, dan petir Kahndaq menyambar. Kekuatan Black Adam jadi milikmu (langsung terpilih sebagai juara).
5. **Gagal** kalau kamu mati, keluar dari game, pergi lebih dari 40 blok dari titik mulai, berubah wujud, atau lewat 5 menit. Makhluk makam runtuh jadi pasir dan skarabe tertidur lagi. Skarabenya tetap ada, jadi bisa dicoba lagi.

Ujian ini untuk manusianya, bukan juaranya: pakai zirah & senjata terbaik dan bawa makanan.

### Black Adam vs Shazam: badan & kekuatan

| | Shazam | Black Adam |
|---|---|---|
| Darah | 300 | **350** |
| Damage yang diterima | 40% | **35%** |
| Panah, trisula, bola api, peluru mod lain | kena (40%) | **memantul** (kebal; percikan & denting di titik kena) |
| Pulih darah | 3/detik | 2/detik, **6/detik di bawah matahari** |
| Energi Petir saat berwujud juara | -1/detik, +2/detik saat badai petir | -1,5/detik, **+1/detik di bawah matahari** |
| Energi Petir sebagai manusia | +5/detik, x4 saat badai petir | +4/detik, **x3 di bawah matahari** |
| Sumber kekuatan (HUD) | Badai petir ("Badai!") | Matahari Kahndaq ("☀ Berkah Aton") |
| Tombol M | Auto-hit Mode Kilat | **Panggil Petir Kahndaq** |
| Tinju | 40 | 44, hempasan lebih jauh, percikan petir di tiap pukulan |
| Pendaratan keras | gelombang kejut | radius x1,35, damage x1,3, tanah retak membara & kubah petir |
| Terbang | lincah: barrel roll, kepalan di depan seperti Superman | berat & lugas: dorongan menghentak, berhenti mendadak lalu melayang tegak; lengan lurus di sisi badan; nggak berguling, tapi melesat menyamping meninggalkan bayangan membara |
| Berdiri diam | kepalan di pinggang | lengan bersilang di dada seperti firaun, dagu terangkat |
| Mata | menyala saat skill/amarah | selalu membara samar emas |
| Kulit | - | listrik membara samar merayap di kulit, bara naik pelan |

"Di bawah matahari" = siang hari, nggak hujan, dan langit terbuka di atas kepala.

### Kostum Black Adam

- **Kalung lebar Mesir (usekh)** di atas mantel: pita emas, deretan manik pirus, pita emas lebar beralur, dan rumbai liontin tetes emas & pirus. Menggantikan pelat bahu, bros, dan rantai Shazam.
- **Gelang lengan (bracer) emas tebal** di kedua lengan bawah, dengan permata pirus dan alur petir.
- **Sabuk emas lebar** dengan gesper berpermata pirus.
- Tetap: hood, jubah, dan mantel hitam legam berlapis merah marun, lambang petir emas di dada & punggung.

### M: Panggil Petir Kahndaq (khusus Black Adam)

Kepalan kanan diangkat ke langit, awan gelap berputar di atas kepala, busur listrik naik dari kepalan, lalu petir sihir menyambar badan sendiri: kubah petir, tiang cahaya, tanah retak, dan listrik membelit badan dari kaki ke kepala.

- Energi Petir +220, darah +120, api padam, efek penghambat hilang.
- Musuh dalam 6,5 blok kena 20 damage petir dan terhempas.
- Gratis (tanpa energi), cooldown 25 detik. Kotak ke-8 di HUD (ϟ).

### Efek & animasi skill Black Adam ditulis ulang (gaya film)

Semua efek lebih tebal: petir emas-jingga bercabang dengan inti putih panas, listrik merayap di kulit sesudah tiap skill besar, gelombang kejut berlapis, kubah petir, batu & pasir beterbangan, dan kamera ikut terguncang. Gerakannya juga baru: ancang-ancang lebih dalam, hantaman lebih keras, dan tahanan sesudahnya.

- **Z Badai Shu:** badai pasir tebal setinggi 7 blok dengan inti debu gelap, petir menyambar di dalamnya, batu-batu mengorbit; badan berayun dihantam badai. Lalu badai meledak: gelombang pasir 10 blok, kubah, dan petir merambat di tanah.
- **X Sambaran Heru:** kerucut sonic & cincin uap saat melesat, sayap elang dari berkas cahaya bertepi listrik, petir yang tertinggal di sepanjang lintasan, dan musuh yang ditabrak tersambar; badan nyaris mendatar, lalu mengerem dengan sayap terbentang dan mendarat merunduk.
- **C Tinju Amon:** melonjak tinggi lalu menghantam: kubah kejut 5 blok, gelombang putih, petir merayap di tanah. Celah membaranya lebih lebar dengan petir melompat-lompat di dalamnya, **tiang-tiang batu (bertekstur tanahnya) mencuat** di kiri-kanan celah, dan debu menyembur seperti geiser. Badan berlutut gemetar menahan getaran.
- **V Segel Zehuti:** lingkaran hieroglif di kepala, gelombang hieroglif melesat ke depan, **rantai huruf cahaya** ke tiap musuh, dan **tiga cincin hieroglif** + pilar cahaya + lingkaran di tanah yang mengunci.
- **B Sinar Aton:** cakram matahari lebih besar bermahkota sinar berdenyut, garis silau, dan petir kecil berkejaran di tepinya. Sinarnya 2x lebih tebal dengan **dua pilinan petir** dan cincin panas; di sasaran ada ledakan api, bekas hangus, dan retakan. Badan tersentak tiap sinar melesat.
- **N Lilitan Mehen:** ular menyeruak dari pasir (tanah retak merah), badan ular lebih tebal, sisik lebih terang, **listrik merambat di kulit ular**, tudung kobra lebih lebar.
- **R Murka Kahndaq:** saat menahan amarah, **petir dari langit menghujani sekeliling** dan tanah retak membara. Saat meraung: kubah petir 6 blok, empat petir menyambar di empat penjuru, guncangan besar. Listrik di badan lebih tebal dan batu yang mengorbit lebih banyak.
- **Berubah wujud:** petir yang mengenai kepalan sekarang memunculkan kubah petir, hantaman tanah, dan listrik membelit badan dari kaki ke kepala selagi kostum terbentuk. Ritualnya punya lingkaran hieroglif ketiga (merah membara).
- **Terbang:** lepas landas meretakkan tanah, pendaratan menghantam dengan kubah & petir, sonic boom membara dengan petir memancar ke belakang, dan petir memercik di belakang lintasan saat ngebut.

### Perintah tes baru

- `/shazam unlock black_adam [pemain]`, `/shazam unlock shazam [pemain]`, `/shazam unlock all [pemain]` (`/shazam unlock` saja = Shazam).
- `/shazam lock black_adam|shazam|all [pemain]` (`/shazam lock` saja = dua-duanya).
- `/shazam trial [pemain]`: mulai Ujian Kahndaq di tempat, tanpa syarat gurun & langit terbuka.
- `/shazam form <juara>` sekarang cuma bisa ke juara yang sudah didapat.
- `/give @s shazammod:scarab_of_teth_adam` (skarabe juga ada di tab Creative Ingredients).

Angka-angkanya: `KahndaqTrial.java` (ujian), `ShazamPowers.java` bagian `ADAM_*` (badan & kekuatan), `AdamSkills.java` bagian `CALL_*` (Panggil Petir).

## Yang baru di 0.21: Black Adam

Sekarang ada juara kedua: **Black Adam**, juara Kahndaq. Kata ajaibnya sama (**SHAZAM**), alur berubahnya sama (dewa datang satu per satu, kepalan ke langit, petir turun pelan dalam slow motion), tapi dewanya, warnanya, skill-nya, dan pakaiannya beda total, seperti di komik: kekuatannya datang dari enam dewa Mesir.

| Huruf | Dewa Black Adam | Kekuatan |
|---|---|---|
| S | **Shu** | Stamina |
| H | **Heru** (Horus) | Kecepatan |
| A | **Amon** (Amun) | Kekuatan |
| Z | **Zehuti** (Thoth) | Kebijaksanaan |
| A | **Aton** (Aten) | Kekuasaan |
| M | **Mehen** | Keberanian |

### Cara memilih

- Tekan **K** (bisa diganti di Controls) untuk ganti juara: Shazam ⇄ Black Adam. Mulai 0.22, cuma bisa kalau kamu sudah mendapatkan dua-duanya lewat jalannya masing-masing (lihat *Yang baru di 0.22*), dan cuma dalam wujud manusia, karena petir memilih juaranya sebelum menyambar. Habis berubah/balik ada jeda 3 detik.
- Atau pakai perintah `/shazam form black_adam` (dan `/shazam form shazam` untuk balik), untuk juara yang sudah didapat. Bisa untuk pemain lain juga: `/shazam form black_adam @a`.
- Pilihannya tersimpan di save, ikut terkirim ke pemain lain (mereka lihat dewa Mesir saat kamu berubah), dan di HUD kiri atas ada tulisan juara yang dipilih.

### Ritual berubah: dewa-dewa Mesir

Black Adam berdiri tegak seperti patung firaun dengan **kedua lengan menyilang di dada (pose Osiris)**, lalu lengan pelan-pelan terbuka menerima kekuatan. Di tanah menyala **lingkaran hieroglif emas membara** dengan pasir berputar di tepinya dan asap hitam tipis merayap di kaki. Dewa-dewanya datang satu per satu, masing-masing dengan cara masuknya sendiri:

- **Shu** (dewa udara): pusaran angin bercampur pasir berputar naik, tubuhnya terbentuk dari kaki ke kepala sambil berputar melambat. Bulu burung unta tegak di kepalanya, dan kedua tangannya **menyangga langit berbintang** (tubuh dewi Nut) di atas kepala.
- **Heru** (dewa elang): **menukik dari langit seperti elang** dengan sayap terbentang, bulu-bulu cahaya gugur di belakangnya, lalu mendarat menghantam tanah. Berkepala elang dengan garis mata Wedjat, **mahkota ganda merah-putih**, sayap lebar, tongkat was dan ankh.
- **Amon** ("Yang Tersembunyi"): asap bayangan pekat menggumpal, lalu tubuhnya **tersingkap dari mahkota ke kaki**. Kulit biru, **mahkota dua bulu tinggi bergaris**, janggut dewa, tongkat was dan ankh.
- **Zehuti** (dewa kebijaksanaan): lingkaran hieroglif di tanah, tubuhnya **"dituliskan" huruf-huruf cahaya** dari bawah ke atas. Berkepala ibis berparuh panjang melengkung, **cakram bulan di atas bulan sabit**, palet juru tulis & pena buluh, dan **cincin hieroglif yang berputar** mengelilingi badannya.
- **Aton** (cakram matahari): tanah retak membara keemasan, lalu **matahari terbit dari balik tanah** sampai menyilaukan. Wujudnya cakram matahari dengan kobra uraeus, dan **sinar-sinarnya berujung tangan terbuka**, satu menyodorkan ankh (tanda kehidupan). Korona di sekelilingnya berputar pelan.
- **Mehen** (ular pelindung): tanah merekah, pasir & batu menyembur, lalu **ular raksasa bergelang emas-merah menyeruak** dari pasir, melingkar berlapis-lapis, dan menegakkan leher serta **tudung kobra**-nya sambil mendesis.

Lalu kepalan kanan diangkat ke langit (tangan kiri tetap di dada), tiap dewa mengalirkan sinar energinya lewat pusakanya (telapak Shu, tongkat Heru & Amon, pena Zehuti, ankh Aton, taring Mehen), dan **petir emas-jingga membara** turun. Saat menyambar: ledakan cahaya, pilar petir, dan **cincin asap hitam** menyapu tanah. Black Adam terangkat dengan lengan terentang, lalu turun dan berdiri buas: kepalan mengepal di samping, kepala sedikit tertunduk menatap tajam.

### Tampilan Black Adam

- **Hood, jubah, dan mantel hitam legam** (bentuk & fisika kainnya sama dengan Shazam), lapisan dalam **merah marun tua**, list & pelat bahu **emas antik** yang lebih jingga, permata **pirus** seperti perhiasan firaun.
- **Lambang petir emas** tajam di dada (3D, berkilau) dan di punggung jubah, dengan kilau emas membara.
- Kilau kostum saat terbentuk, butiran saat kostum luruh, dan semua petirnya berwarna **emas-jingga membara** (petir Shazam tetap emas cerah). Jejak terbang, lepas landas, dan hero landing juga ikut warna Black Adam.
- Mata menyala **emas membara** saat Murka Kahndaq, dan **hijau pirus** sesaat sesudah Segel Zehuti.
- HUD: bar energi & kotak skill berwarna emas membara di atas kotak gelap, huruf S-H-A-Z-A-M yang sama, dan kotak terakhir bertanda ☥ (ankh). Kotak M menyala pirus selama ular Mehen melilit.

### Skill Black Adam

Tombolnya sama dengan skill Shazam; yang keluar dewa juara yang sedang dipilih.

| Tombol | Skill | Gerakan & efek | Biaya / cooldown |
|---|---|---|---|
| Z | **S - Pusaran Shu** | Lengan terentang lalu terangkat menyangga langit. Badai pasir & angin berpilin mengelilingi badan 2,5 detik: musuh dalam 9 blok tersedot ke cincin pusaran, berputar, dan terangkat (3 damage tiap 0,5 detik), lalu pusaran **meledak ke luar** (16 damage, terhempas jauh). Stamina Shu: darah langsung pulih 30 dan dapat hati emas 16 darah (absorption) selama 30 detik. | 40 / 15 detik |
| X | **H - Sambaran Heru** | Merunduk, lalu **menerjang lurus secepat elang** sampai 18 blok ke arah pandangan (di tanah: mendatar; di udara: boleh menukik), dengan **sayap elang dari cahaya** di punggung, jejak & bayangan emas membara. Musuh di lintasan kena 24 damage dan tersibak; di titik akhir hempasan 10 damage. Berhenti sendiri sebelum menabrak tembok. | 25 / 4 detik |
| C | **A - Tinju Amon** | Melonjak dengan kedua kepalan di atas kepala, lalu **menghantam tanah**. **Tanah terbelah lurus ke depan** sampai 15 blok: celah membara merambat, batu & debu menyembur di sepanjangnya. Musuh di titik hantaman kena 14, musuh di atas celah kena **30 damage** dan terlempar ke atas. | 40 / 8 detik |
| V | **Z - Segel Zehuti** | Dua jari ke pelipis, mata menyala pirus, lalu menunjuk: gelombang hieroglif melesat. Sampai 12 musuh dalam 16 blok yang terlihat **terikat dua cincin hieroglif berputar** selama 8 detik: nyaris nggak bisa bergerak (Slowness V), lemah, lambat menambang, bersinar, dan **menerima +25% damage dari Black Adam**. | 30 / 15 detik |
| B | **A - Sinar Aton** | Telapak kanan ke langit, **cakram matahari** terbentuk di atasnya, lalu menembakkan **sinar membara (berujung tangan terbuka)** ke 6 musuh terdekat dalam 22 blok satu per satu: 20 damage petir dan terbakar 4 detik. Tanpa musuh: satu sinar ke titik yang dibidik. | 35 / 6 detik |
| N | **M - Lilitan Mehen** | Lengan menyilang di dada, lalu **ular cahaya emas-merah membelit badan** selama 8 detik: damage yang diterima tinggal 30%, debuff langsung hilang, dan tiap detik kepala ular **mematuk** 2 musuh terdekat dalam 7 blok (14 damage + racun). Siapa pun yang menyerangmu langsung dipatuk balik. | 70 / 40 detik |
| R | **Murka Kahndaq** | Badan terangkat, kepalan gemetar sementara petir membara terhisap ke badan, lalu meraung: ledakan petir (14 damage dalam 6 blok), mata emas menyala, listrik membara merayap di badan, batu terangkat mengorbit. Selama 12 detik pukulan +60% dan **tiap pukulan meledak** (musuh dekat sasaran kena 8 dan terhempas) lalu petirnya merambat ke 2 musuh lain; tiap detik petir membara memburu 3 musuh dalam 14 blok; lari lebih cepat. | 150 / 60 detik |

### Kekuatan dasar Black Adam

Sama dengan Shazam (darah 300, armor & tahan banting, kebal jatuh/api/petir, terbang, Energi Petir, terlempar balik jadi manusia kalau kena serangan mematikan), dengan sedikit beda khas Black Adam yang lebih buas:

- Pukulan tangan kosong **44** (critical 66), Shazam 40.
- Hempasan pukulan **+0,8** lebih jauh dari Shazam.
- Petir saat berubah wujud **18** damage (Shazam 12), dan menyambar 4 petir kecil di sekeliling.
- Black Adam **nggak punya Mode Kilat Mercury** (tombol M diabaikan); kecepatan Heru-nya ada di Sambaran Heru.

Angka-angkanya ada di bagian atas `AdamSkills.java` (skill) dan `ShazamPowers.java` (`ADAM_*`).

## Yang baru di 0.20: kena serangan mematikan, balik jadi manusia (nggak langsung mati)

Kalau Shazam kena serangan yang mestinya mematikan, kamu **nggak mati**: kekuatan sihirnya tercabut dari tubuh dan kamu terlempar balik jadi manusia biasa.

- **Yang dihitung damage terakhir**, sesudah dikurangi tahan banting, armor, enchantment, dan hati emas (absorption). Kalau sisanya masih menghabisi darah Shazam, damage serangan itu dibatalkan dan kamu balik jadi manusia. Serangan yang nggak mematikan tetap masuk seperti biasa.
- **Darah manusia langsung penuh 20/20**, sama seperti tiap balik jadi manusia. Ini ikut `FULL_HEAL_ON_REVERT`: kalau itu dimatikan, kamu balik dengan darah tinggal sedikit.
- **Belum bisa SHAZAM lagi selama 30 detik.** Tanpa jeda ini Shazam praktis nggak bisa mati: tinggal ucapkan SHAZAM lagi (kebal selama ritual), darah langsung penuh 300 lagi. Sisa waktunya kelihatan di HUD kiri atas (*Belum bisa SHAZAM: 23 detik*), mengucapkan SHAZAM sebelum waktunya cuma memunculkan pesan sisa detiknya, dan ada pesan begitu tubuhmu pulih. Waktu pulih ikut tersimpan, jadi keluar-masuk world nggak mempercepatnya. Kalau kamu mati beneran sebagai manusia, waktu pulihnya hilang saat respawn.
- Kalau sedang terbang, pendaratan pertama nggak sakit, sama seperti balik jadi manusia di udara.
- Totem of Undying yang kamu pegang nggak ikut kepakai (Shazam yang terlempar balik duluan), jadi totemnya tetap ada buat menyelamatkan wujud manusiamu nanti.
- Jatuh ke void dan `/kill` tetap mematikan, sama seperti saat ritual.

**Gerakan & efek:** badan terhentak ke belakang dengan lengan terlempar ke depan, lalu kekuatan tercabut dari dada: lengan terentang, kepala mendongak, gemetar hebat, semburan cahaya emas, empat busur petir lepas dari badan kembali ke langit, gelombang emas dan debu di tanah, percikan, dan kostum luruh jadi butiran cahaya emas. Lalu badan lunglai membungkuk, oleng sebentar, dan pelan-pelan tegak lagi (kaki cuma sedikit melangkah, jadi tetap wajar kalau kamu langsung kabur). Dari matamu sendiri: pandangan menggelap kemerahan, layar berguncang, lalu kilatan emas.

**Cara ngetes:** jadi Shazam, lalu ketik `/damage @s 10000` (butuh cheat). `/shazam unlock` sekalian menghapus waktu pulih, jadi bisa langsung dites ulang.

Pengaturannya ada di bagian atas `ShazamPowers.java`: `REVERT_INSTEAD_OF_DEATH` (`false` = Shazam mati seperti biasa) dan `KNOCKOUT_COOLDOWN_TICKS` (600 = 30 detik, 0 = langsung bisa SHAZAM lagi; 20 tick = 1 detik).

## Yang baru di 0.19: kekuatan mentah Shazam jauh lebih kuat

**Stat Shazam dinaikkan** supaya adu kekuatan mentah dengan Warden (mob terkuat di game) menang telak:

| | Sebelumnya | Sekarang |
|---|---|---|
| Darah | 100 | **300** (150 hati) |
| Pulih | 2 per detik | **3 per detik** |
| Armor & toughness | +10 & +6 | **+20 & +12** (setara full netherite) |
| Pukulan tangan kosong | 20 (critical 30) | **40 (critical 60)** |
| Kecepatan pukulan | penuh tiap 0,25 detik | **penuh tiap 0,2 detik** |
| Pakai senjata | biasa | **damage senjata x2** |
| Terpental | +1,5 | **+2,5** |
| Mode Kilat Mercury ke bos | 40 per pukulan | **60 per pukulan** |

Damage yang diterima tetap tinggal 40% (lalu dikurangi armor). Hitungannya lawan Warden: pukulan Warden (30 di Normal, 45 di Hard) dulu masuk ±9 / ±15 ke darah 100, jadi Shazam tumbang dalam ±11 / ±7 pukulan. Sekarang cuma masuk ±3,5 / ±6 ke darah 300 (butuh ±85 / ±48 pukulan, belum dihitung darah yang pulih), sedangkan Warden (darah 500) tumbang dalam 13 pukulan Shazam. Sonic boom Warden menembus armor, jadi tetap masuk 4 / 6.

**Darah langsung penuh tiap berubah wujud, seperti di komik:**
- Berubah jadi Shazam dengan darah berapa pun: begitu petir menyambar, darah langsung penuh 300/300.
- Balik jadi manusia (termasuk saat sekarat sebagai Shazam, atau saat energi habis): darah langsung penuh 20/20.
- Selama ritual berubah (±5 detik dewa-dewa datang) dan saat ritual balik jadi manusia, badan dilindungi petir sihir: kebal damage, jadi nggak mati di tengah ritual walau mulainya dalam keadaan sekarat. Cuma jatuh ke void dan `/kill` yang tetap kena.

Semua angkanya ada di bagian atas `ShazamPowers.java` (`BONUS_HEALTH`, `PUNCH_MULTIPLIER`, `BONUS_ARMOR`, dan seterusnya). Pulih penuh saat berubah, saat balik, dan kebal selama ritual bisa dimatikan satu per satu (`FULL_HEAL_ON_TRANSFORM`, `FULL_HEAL_ON_REVERT`, `SAFE_DURING_RITUAL`).

## Yang baru di 0.18: Mode Kilat Mercury makin sinematik

**Auto-hit bisa dimatikan (tombol M).** Selama Mode Kilat nyala, tekan **M** untuk mematikan auto-hit: Shazam tetap lari super cepat (dan tetap bisa lari di atas air), tapi monster nggak diserang otomatis lagi. Tekan **M** lagi untuk menyalakannya. Pilihannya diingat sampai game ditutup, termasuk saat Mode Kilat dimatikan lalu dinyalakan lagi. Di HUD, kotak **M** bertuliskan **AUTO** (auto-hit nyala) atau **LARI** (cuma lari). Tombolnya bisa diganti di Controls ("Mode Kilat: auto-hit nyala/mati").

**Bayangan berjejak sekarang pakai jubah.** Tiap bayangan dibekukan persis seperti frame saat dibuat: pose badan, plus jubah, mantel, dan hood yang sedang berkibar saat itu, lengkap dengan list emasnya. Digambar empat lapis: badan tembus pandang yang terang sendiri, kain, list emas, lalu pendar listrik yang paling terang di tepi siluet (seperti energi yang membentuk badan) plus lambang dada yang menyala. Bayangan terbaru biru muda terang, makin tua makin biru listrik pekat lalu memudar. Jaraknya ±1 blok (seperti foto strobo), jadi tiap bayangan terbaca jelas, bukan gumpalan. Bayangan yang terlalu dekat kamera atau yang persis menutupi pelari dari kamera F5 dibuat tipis, jadi pelarinya tetap kelihatan.

**Petir speed force yang tebal.** Empat sambaran petir tebal terseret di belakang pelari, mengikuti lintasan larinya yang sesungguhnya (ikut melengkung saat berbelok). Pangkalnya keluar dari badan, paling tebal sedikit di belakang badan, lalu menipis di ujung ekor. Zig-zag-nya dibentuk ulang tiap tick (berkedip seperti petir sungguhan) sementara liukannya bergerak halus tiap frame, dengan inti putih panas, badan biru, pendar udara terionisasi yang lebar, cabang-cabang, dan sesekali sambaran yang lebih terang. Ditambah busur listrik yang melompat di antara bayangan-bayangan, listrik kecil di badan bayangan terbaru, listrik yang lebih tebal di badan, busur yang lebih tebal saat memukul, jejak listrik di kaki, dan percikan di tiap langkah. Bagian petir yang lewat dekat kamera memudar, jadi kamera F5 nggak tertutup cahaya putih.

**Animasi lari ala sprinter.** Lutut didorong tinggi ke depan dan kaki belakang menolak jauh, lengan memompa kuat (sedikit menyilang di depan badan), bahu ikut berputar mengikuti ayunan lengan, badan naik-turun tiap langkah dan bergoyang sedikit ke kaki tumpuan. Saat menikung, badan condong ke dalam tikungan sesuai kecepatan dan tajamnya belokan, seperti pelari di lintasan melengkung. Saat mengerem dari lari kencang: kaki depan menancap, badan condong ke belakang dan merendah, tangan terentang mengimbangi, sambil tergelincir.

Angka-angka tampilannya ada di bagian atas `client/anim/ShazamPoses.java` (jarak, umur, kepekatan, dan warna bayangan; condong saat menikung) dan `client/fx/SpeedForce.java` (jumlah, tebal, dan panjang petir).

## Yang baru di 0.17: Mode Kilat Mercury

Skill Mercury (tombol **N**) sekarang jadi mode yang bisa dinyalakan terus, bukan terjangan sekali pakai.

**Cara pakai:** tekan **N** sekali untuk menyalakan, tekan lagi untuk mematikan. Nggak ada cooldown. Menyalakannya butuh 15 energi, lalu energi berkurang 3 per detik selama nyala dan 1 per pukulan (energi penuh cukup untuk beberapa menit). Kalau energi menipis, mode mati sendiri. Di HUD, kotak **M** jadi biru selama mode nyala (sejak 0.18 bertuliskan **AUTO** atau **LARI**, lihat di atas).

**Kalau ada musuh di sekitar (auto-hit):**
- Monster dalam 20 blok yang kelihatan (nggak terhalang tembok) otomatis diserang: Shazam melesat ±64 blok/detik ke depan musuh terdekat, memukulnya, tertahan sekejap seperti pukulan yang benar-benar kena, lalu langsung ke musuh terdekat berikutnya. Kerumunan rapat bisa dihajar sampai 10 pukulan per detik.
- Monster biasa langsung mati sekali pukul dan badannya terpental searah pukulan (tendangan paling jauh, hook melambung). Bos (Wither, Ender Dragon, atau monster berdarah 150 ke atas) dipukul bertubi-tubi 40 damage per pukulan (60 sejak 0.19), bukan langsung mati. Kalau mau bos juga langsung mati, ubah `INSTAKILL_BOSSES` di `ShazamMercury.java`.
- Cuma monster yang diserang. Pemain lain, hewan peliharaan, villager, dan hewan biasa aman. Makhluk netral (enderman, zombified piglin) cuma diserang kalau sedang menyerang.
- Musuh yang tiba-tiba muncul atau mendekat langsung ikut diserang. Monster terbang (phantom, ghast, blaze) juga dikejar ke udara.
- Pukulannya bergantian: jab kanan, cross kiri, hook, lalu tendangan, dengan putaran pinggang dan langkah kaki. Rangkaian pukulan menyambung seperti satu kombo.

**Kalau nggak ada musuh (super speed):**
- Lari super cepat sampai ±52 blok/detik dengan fisika yang masuk akal: kecepatan naik dalam ±0,65 detik, belokan makin lebar saat makin kencang (ada inersia), dan saat W dilepas badan tergelincir ±10 blok sebelum berhenti. Melompat sambil lari menjaga momentum, jadi lompatannya jauh melengkung.
- Bisa lari di atas air selama cukup kencang. Begitu melambat, tenggelam dan berenang biasa.
- Tahan **Shift**: semuanya ditahan, jalan biasa (misalnya mau lewat tanpa menyerang atau berjalan pelan).
- Saat sedang terbang, terbangnya tetap terbang Shazam biasa, tapi auto-hit tetap jalan.

**Efek dan animasi:**
- Listrik biru merayap di badan, makin deras saat makin kencang. Petir zig-zag menyambar-nyambar di belakang badan saat lari. Ada juga bayangan berjejak yang tiap bayangannya membeku di pose langkahnya sendiri, seperti foto strobo.
- Pose lari ala speedster: badan condong ke depan (lebih condong saat mempercepat, menegak saat mengerem), langkah makin rapat saat makin kencang, lengan mengayun berlawanan dengan kaki, badan naik-turun tiap langkah, dan kepala tetap menatap ke depan.
- Debu tersibak dan terseret udara di belakang kaki, bongkahan tanah sungguhan terlempar saat sangat kencang, dan percikan listrik di tiap langkah. Di atas air ada cipratan dan riak.
- Mulai melesat dari diam: hentakan udara, debu tersembur ke belakang, dan tanah retak. Mengerem atau berbelok tajam: kaki menggerus tanah dengan percikan dan debu.
- Tiap pukulan: kilatan, gelombang kejut searah pukulan, udara terdorong ke belakang musuh, hujan percikan, dan busur listrik dari kepalan.
- Saat menyala: kuda-kuda rendah sambil gemetar mengumpulkan tenaga, lalu badan menghentak tegak dan listrik meledak dari badan.
- Dari sudut pandang orang pertama, efek yang menempel di badan nggak digambar (supaya layar nggak tertutup). Gantinya garis kecepatan, pandangan yang melebar, suara angin, dan tangan yang ikut memukul.

Angka-angkanya bisa diatur di bagian atas `ShazamMercury.java` (energi, damage, bos) dan `client/flight/MercuryMode.java` (jangkauan, kecepatan menerjang dan lari, percepatan, rem, belokan, lari di atas air).

## Yang baru di 0.16: efek tebal & gerak halus

Efek skill sekarang tebal dan pekat (tetap kelihatan di siang hari dan di depan langit terang), dan semua gerakan lebih halus seperti di dunia nyata.

**Kenapa dulu efeknya terasa tipis:**
- Tiap efek baru langsung dimajukan satu tick saat dibuat, jadi frame pertamanya (yang paling terang) nggak pernah digambar. Busur petir yang umurnya 2 tick cuma kelihatan 1 tick dan sudah setengah pudar; kilatan kehilangan puncak terangnya dan muncul sudah setengah mengembang.
- Semua efek cuma cahaya aditif (ditambahkan ke warna latar), jadi di depan langit terang hampir hilang.
- Garis petir sempit, dan pendarnya cuma titik terang kecil di tengah.
- Kalau jumlah efek penuh, yang dibuang malah efek yang baru dipakai.

**Yang berubah di efek:**
- **Lapisan badan:** tiap efek cahaya punya badan tembus pandang berwarna pekat di bawah cahayanya, jadi tetap tebal di siang hari. Kepekatannya diatur `BODY` di `client/vfx/Draw.java` (0 = seperti 0.15), terangnya `GLOW`.
- Pendar bulat lebih penuh (seperti kurva lonceng). Petir 1,45× lebih tebal dengan pendar udara di sekelilingnya (`THICK` di `client/vfx/Lightning.java`). Petir, berkas, dan jejak digambar sebagai pita tiga lapis (pendar, badan berwarna, inti panas) yang menyambung tanpa celah di tikungan.
- Butiran 1,6× lebih banyak (`DENSITY` di `client/vfx/Vfx.java`, 1 = seperti 0.15). Percikan punya ekor gerak dan kepala yang membara, debu bervolume (atas kena cahaya, bawah berbayang), dan tiap hantaman sekarang mengepulkan **asap tebal** yang menyebar rendah, mengembang, naik pelan, lalu menipis. Gelombang kejut menyapu asap ke luar, jadi tempat pemain berdiri tetap bersih; saat petir transformasi asapnya tipis supaya kostum yang terbentuk tetap kelihatan. Hantaman Atlas dari udara meninggalkan asap seperti meteor, dan petir meninggalkan jelaga.
- Kilatan punya pendar luas, gelombang kejut punya muka gelombang yang terang, dan retakan tanah, lingkaran rune, tanda sasaran, serta aura Achilles lebih tebal.
- **Halus sejak frame pertama:** efek baru mulai dari umur 0, butiran dan pecahan blok langsung bergerak. Jejak cahaya (terjangan Mercury, menukik Atlas, tangan saat terbang) melengkung mulus (kurva Catmull-Rom), tumbuh mulus dari awal, ekornya bergeser halus (dulu meloncat tiap tick), dan ujungnya nggak melipat balik lagi.
- Batas efek 1024 dan butiran 6000. Kalau penuh, yang dibuang yang paling dekat habis, bukan efek baru.
- **Tetap ringan:** tiap bentuk cuma dikirim sisi yang menghadap kamera (dulu dua sisi, separuhnya dibuang GPU), geometrinya dihitung sekali untuk dua lapisan, dan titiknya ditulis lewat jalur cepat. Biaya per titik turun ±36%, jadi walau titiknya ±1,75× lebih banyak, adegan berat (tiga hantaman sekaligus) cuma butuh ±0,15 ms CPU lebih banyak per frame.

**Yang berubah di gerak badan:**
- Pose antar-keyframe dihaluskan seperti otot sungguhan (`SMOOTH` di `client/anim/Clip.java`, 0 = persis keyframe seperti 0.15). Sentakan terbesar per frame (60 FPS) turun dari 120° ke 46° (lengan saat Tepukan Hercules), dari 91° ke 37° (kepala saat Zeus Rage), dan dari 74° ke 30° (kepala saat Kulit Achilles). Waktu kena damage tetap sama.
- Masuk dan keluarnya animasi, serta perpindahan pose terbang (melayang, meluncur, ngebut, mengerem) dan berdiri gagah, sekarang melengkung: mulai dan berhenti pelan, bukan mendadak.
- Ganti gerakan di tengah animasi (misalnya menukik Atlas lalu mendarat) sekarang memudar selama 4 tick (`XFADE` di `client/anim/ShazamPoses.java`), nggak meloncat dari satu pose ke pose lain.

## Yang baru di 0.15: enam dewa datang satu per satu

Begitu SHAZAM diucapkan, enam dewa datang **bergantian** (tiap ±0,65 detik), masing-masing dengan cara masuknya sendiri, lalu berdiri melengkung di seberang kamera dengan urutan S-H-A-Z-A-M dari kiri ke kanan. Rohnya sekarang berwujud dewa sungguhan, bukan model pemain yang diwarnai: tinggi ±3 blok, tembus pandang seperti patung cahaya, tepinya bersinar warna dewanya, mata menyala, dan ada lingkaran suci di belakang kepala.

| Dewa | Wujud | Cara muncul |
|---|---|---|
| **S** Solomon | Raja bijak berjubah ungu panjang, mahkota emas bergerigi, janggut putih panjang, kitab terbuka di tangan kiri | Lingkaran rune ungu menyala di tanah, tubuhnya terbentuk dari kaki ke kepala (garis cahaya naik), kitab terbuka, lalu segel bintang segi enam menyala di telapak kanannya |
| **H** Hercules | Berotot besar, kerudung kepala singa (moncong, taring, surai), cakar singa terikat di dada, kulit singa di punggung, gada kayu berbonggol di bahu | Melompat dari kejauhan seperti bintang jatuh, mendarat bertumpu satu kepalan sambil menghantamkan gada: tanah retak, gelombang kejut, pecahan blok, kamera bergetar |
| **A** Atlas | Raksasa berlutut memanggul bola langit bercincin emas berisi rasi bintang | Tanah retak membara dan batu-batu terlempar, lalu dia bangkit dari dalam bumi bersama bola langitnya |
| **Z** Zeus | Raja dewa berjanggut & berambut putih, mahkota daun salam emas, jubah putih, petir zig-zag di tangan kanan siap dilempar | Badai berkumpul di langit, petir menyambar, dan Zeus berdiri di tempat petir jatuh (silau putih, listrik merayap di badannya) |
| **A** Achilles | Helm Yunani berjambul merah, zirah emas, perisai bundar berlambang matahari, tombak, jubah merah | Cincin api di tanah dan pusaran bara emas berpilin naik; tubuhnya "terbakar muncul" dari kaki ke kepala, lalu perisainya dihentakkan dengan kilatan |
| **M** Mercury | Ramping, topi & sandal bersayap, tongkat caduceus (dua ular, sepasang sayap), jubah pendek berkibar | Melesat secepat kilat mengitari dewa-dewa lain dengan bayangan yang tertinggal, berhenti mendadak (hembusan angin), lalu berjinjit di satu kaki menunjuk langit |

- Tiap dewa tiba disambut denting yang makin tinggi, dan nama + kekuatannya muncul di atas hotbar (misalnya *ZEUS — Kekuasaan*).
- Badanmu ikut bereaksi: tiap kali dewa datang badan sedikit tersentak, lengan makin terbuka, dan kepala makin terangkat menatap mereka.
- Setelah keenamnya hadir, mereka bersinar bersamaan. Saat kepalan diangkat, tiap dewa mengarahkan pusakanya ke kepalanmu (Zeus mengayunkan petirnya, Achilles menodongkan tombak, Mercury menunjuk, ...) dan mengalirkan sinar energinya bergantian. Mereka memudar selama petir turun dan lenyap tepat saat petir menyambar.
- Panggilan dewa sekarang ±4,4 detik (dulu 1,4 detik), jadi sampai petir menyambar total ±7 detik termasuk slow motion. Jadwalnya bisa diubah di `client/fx/GodShow.java` (`ARRIVE`, jarak 13 tick) bersama `SUMMON_TICKS` di `ShazamAnim.java`.
- Dewa-dewa berdiri di seberang kamera: kalau kamera di depanmu (orang pertama otomatis pindah ke kamera sinematik), mereka di belakangmu; kalau kamera di belakang (F5), mereka di depanmu. Pemain lain yang menonton melihat mereka di seberang kameranya sendiri. Dewa berdiri di permukaan tanah masing-masing.
- Bentuk dewa dibangun dari geometri halus di `client/fx/GodFigures.java`, warna & cahayanya di `GodLook.java`, jadwal & gerak masuknya di `GodShow.java`, efek & suara tiap kedatangan di `ShazamSpirits.java`. Nama dewa di file bahasa (`spirit.shazammod.*`); kalau nggak mau namanya muncul, ubah `SHOW_NAMES` di `ShazamSpirits.java`.

## Yang baru di 0.14: fisika kain ditulis ulang

Jubah, mantel, dan hood sekarang memakai mesin kain baru yang cara kerjanya sama dengan cloth di engine game sungguhan. Ini memperbaiki bug hood yang terbuka di belakang (belakang kepala kelihatan, "sayap" di samping, ujung runcing ke atas), mantel yang melorot dari bahu, dan kain yang nyangkut atau molor.

- **Penyebab bug lama:** tabrakan "dorong ke sisi terdekat" mendorong kain yang sudah masuk agak dalam ke kepala atau lengan keluar lewat sisi yang salah, lalu gaya "kembali ke bentuk" menariknya lurus menembus kepala, jadi kainnya nyangkut di posisi salah. Fisikanya juga dihitung di ruang dunia dengan pose kepala dan lengan yang cuma di-update sekali per frame, jadi tiap menoleh cepat kain tertinggal jauh.
- **Fisika di ruang badan + gaya semu yang benar:** tiap kain dihitung di ruang tempat ia dipasang (jubah dan mantel di badan atas, hood di kepala). Gerak badan di dunia (jalan, lompat, terbang 100 blok/detik, berbalik, menoleh) masuk sebagai percepatan bingkai, gaya sentrifugal, Coriolis, dan Euler, persis seperti hukum Newton di kerangka yang bergerak. Kain tetap punya kelembaman, tapi nggak pernah tertinggal, meledak, atau lepas dari badan, dan selalu menempel persis saat digambar.
- **Satuan dunia nyata:** 1 blok = 1 meter, gravitasi 9,81 m/s², udara 1,225 kg/m³, air 1000 kg/m³, kain wol 0,45-0,7 kg/m². Hambatan udara dihitung dari sudut kain terhadap angin.
- **XPBD:** kain nggak bisa molor (tali panjang ke titik paku), tapi gampang melipat saat tertekan, seperti kain sungguhan.
- **Wake di belakang badan:** udara tepat di belakang badan ikut terseret badan, jadi jubah di situ menerima angin yang lebih pelan. Dihitung dengan menelusuri arah datangnya angin dari tiap titik kain.
- **Turbulensi:** pusaran udara yang terbawa aliran (lebih kuat di dalam wake) bikin jubah berkibar alami, bukan gelombang buatan.
- **Tabrakan menerus:** kotak badan, kepala, lengan, dan kaki punya sudut membulat, dan kain selalu didorong ke sisi tempat ia datang. Jubah juga menabrak blok dunia (lantai, dinding, langit-langit).
- **Bentuk pakai:** hood yang dipakai ditahan dekat bentuknya (paling jauh 1,2-4,8 cm), jadi menoleh secepat apa pun tetap membungkus kepala. Mantel ditarik pelan ke bentuknya, dan bagian bahunya ikut terangkat bersama lengan.
- **Hood diturunkan** sekarang benar-benar kain lemas yang tergeletak di atas mantel, dan saat dipakai/dilepas dituntun lewat atas kepala.
- **Jubah menempel di badan atas**, jadi tetap di bahu saat jongkok atau membungkuk (dulu melayang di atas bahu). Pose bawaan Minecraft seperti berenang, merangkak, dan terbang elytra juga diikuti.
- Lebih ringan dari versi lama (±1,8% satu inti CPU per pemain Shazam yang kelihatan).

## Yang baru di 0.13

- **Hood, mantel, dan jubah menyatu.** Hood baru berbentuk kotak dengan sudut membulat (mengikuti kepala Minecraft), bingkai wajah yang menaungi dahi, panel belakang dengan jahitan, dan ujung runcing kecil di ubun-ubun. Mantel bahu baru (kain berfisika) menyambungkan hood dan jubah: tepi bawah hood masuk ke kerah mantel, list emas bingkai wajah bersambung ke tepi depan mantel, dan bagian atas jubah tersembunyi di bawah mantel.
- **Aksesoris bahu:** pelat emas tiga lapis bertumpuk di tiap bahu (dengan paku keling), bros berpermata di kedua tepi depan, dan rantai emas di dada atas. Semuanya menempel di kain dan ikut bergerak.
- **Kain dua lapis:** sisi luar putih, lapisan dalam biru tua keunguan, jadi bagian dalam hood terlihat dalam.
- **Efek skill buatan sendiri:** cahaya lembut, gelombang kejut yang menempel di tanah, cangkang energi, petir bercabang, retakan tanah yang membara, pecahan blok sungguhan, lingkaran rune, tanda sasaran, jejak cahaya, aura api, dan efek layar (garis kecepatan, vinyet). Lihat bagian *Efek visual*.
- **Animasi skill baru** dengan putaran pinggang, condong badan, dan gemetar. Lihat bagian *Animasi skill*.
- Enam penjaga kuil beserta totemnya.

## Yang dibutuhkan

- **JDK 21**, misalnya Eclipse Temurin 21 atau Microsoft Build of OpenJDK 21.
- **Internet** untuk build pertama. Gradle, NeoForge, dan Minecraft diunduh otomatis, totalnya beberapa ratus MB.

## Bikin file .jar

**Windows:** buka folder ini, ketik `cmd` di address bar File Explorer, tekan Enter, lalu jalankan:

    gradlew build

**Mac/Linux:**

    chmod +x gradlew
    ./gradlew build

Hasilnya ada di `build/libs/shazammod-0.23.0.jar`. Taruh di folder `.minecraft/mods`, dengan NeoForge 21.1.228 atau yang lebih baru untuk Minecraft 1.21.1.

Mau ngetes tanpa install? Jalankan `gradlew runClient`.

## Kontrol

Semua tombol bisa diganti di pengaturan Controls, kategori Shazam & Black Adam. Tabel ini untuk Shazam; tombol yang sama memanggil skill Black Adam kalau juara itu yang dipilih (lihat *Yang baru di 0.21*).

| Tombol | Skill | Gerakan & efek |
|---|---|---|
| G (atau ketik `shazam`) | Transformasi | Lingkaran rune emas menyala di tanah dan enam dewa datang satu per satu (Solomon, Hercules, Atlas, Zeus, Achilles, Mercury), masing-masing dengan cara masuknya sendiri. Lalu kepalan diangkat ke langit sementara listrik dari tanah merambat ke kepalan. Dunia melambat (slow motion) dan petir sihir turun pelan dari langit selama 2 detik, sementara tiap dewa mengalirkan sinar energinya ke kepalan. Petir mengenai kepalan, layar berkilat, dan kostum terbentuk masih dalam slow motion; begitu selesai, dunia kembali normal. Badan jadi 10% lebih besar. |
| Z | S - Kebijaksanaan Solomon | Tangan menyapu di depan mata, dua jari ke pelipis, avatar Solomon membuka kitab, lalu segel segi enam raksasa terproyeksi dan bola pemindai melebar sampai 48 blok. Musuh yang terbaca bersinar, menerima +25% damage, damage dari mereka tinggal 60%, dan sihir pelindung mereka terhapus. |
| X | H - Tepukan Guntur Hercules (Shift: Lemparan Hercules) | Avatar Hercules melompat lalu menghantamkan gada saat kedua tangan ditepuk: gelombang guntur berbentuk kerucut menghempas musuh, membuat mereka limbung, dan menghancurkan proyektil. Sambil Shift: musuh di depan diangkat ke atas kepala lalu dilempar, meledak saat menghantam. |
| C | A - Beban Langit Atlas | Kepalan diangkat menyangga langit bersama avatar Atlas, bola langit berbintang jatuh, musuh tersedot ke tengah, lalu kepalan menghantam: yang di tengah tertekan ke tanah, yang di pinggir terhempas. Dari udara: menukik seperti meteor. |
| V | Z - Petir Berantai Zeus | Avatar Zeus membidikkan petirnya, lalu petir dari ujung jari melompat dari musuh ke musuh (sampai 6), 2x ke musuh basah, ditutup sambaran dari langit. |
| B | A - Perisai Achilles | Membungkuk gemetar lalu meraung bersama avatar Achilles: hampir kebal 6 detik, perisai matahari di depan dada, musuh dipancing menyerang Shazam, lalu damage yang tertahan meledak keluar sebagai Ledakan Keberanian. |
| N | M - Mode Kilat Mercury | Tekan sekali nyala, tekan lagi mati (tanpa cooldown). Selama nyala: kalau ada monster dalam 20 blok yang kelihatan, Shazam otomatis melesat ke tiap musuh dan memukulnya sampai mati satu per satu (jab, cross, hook, tendangan); kalau nggak ada musuh, lari super cepat ±52 blok/detik dan bisa lari di atas air. Musuh yang baru muncul langsung ikut diserang. Tahan Shift untuk jalan biasa tanpa menyerang. Lihat *Yang baru di 0.17*. |
| M | Mode Kilat: auto-hit nyala/mati | Selama Mode Kilat nyala, matikan auto-hit supaya cuma lari super cepat tanpa menyerang otomatis; tekan lagi untuk menyalakan. Lihat *Yang baru di 0.18*. **Black Adam:** Panggil Petir Kahndaq (lihat *Yang baru di 0.22*). |
| R | Badai Para Dewa | Membungkuk mengepalkan tinju sementara listrik tertarik ke badan, lalu meraung: enam petir di enam penjuru, awan badai di atas kepala, dan keenam dewa mengelilingi Shazam selama 12 detik, bergiliran menyerang musuh dengan gayanya sendiri. Pukulan +50% dan berpetir. Biaya 150 energi, cooldown 60 detik. |
| H | Hood naik/turun | Kedua tangan meraih ke belakang kepala lalu menarik hood ke depan sampai dahi, atau memegang tepi hood di dahi lalu mendorongnya ke belakang. Statusnya tersimpan dan terlihat oleh pemain lain. |
| K | Ganti juara | Shazam ⇄ Black Adam (cuma kalau sudah punya dua-duanya, dalam wujud manusia). |

## Terbang

| Kontrol | Gerakan |
|---|---|
| Spasi 2x | Lepas landas: jongkok sebentar, lalu melesat ke atas. Di udara, tekan lagi 2x untuk berhenti terbang. |
| W | Terbang ke arah pandangan (±28 blok/detik). |
| W + sprint (ditahan) | Makin lama makin ngebut sampai ±100 blok/detik. Saat menembus kecepatan tertentu muncul sonic boom: cincin uap, dentuman, dan musuh di sekitar terhempas. |
| S | Mengerem dengan hambatan udara besar (dari 100 blok/detik ±0,8 detik). Badan menegak, tangan dan kaki terayun ke depan. |
| Spasi / Shift | Naik / turun. |
| A / D | Geser ke samping (hanya di kecepatan rendah). |
| A 2x / D 2x | Barrel roll menghindar ke kiri/kanan. |

### Fisika terbang

Geraknya mengikuti fisika dunia nyata:

- **Dorongan melawan hambatan udara:** makin kencang, makin berat menambah kecepatan. Dari melayang ke 28 blok/detik butuh ±0,5 detik; dengan sprint, sonic boom di ±1,5 detik dan kecepatan puncak di ±3 detik.
- **Belokan dibatasi gaya menyamping:** makin kencang, makin lebar belokannya, dan kecepatan nggak hilang saat berbelok. Putar balik di 28 blok/detik selebar ±10 blok (±0,5 detik); di 100 blok/detik selebar ±125 blok (±2 detik), seperti pesawat jet.
- **Gravitasi:** menukik menambah kecepatan (W sambil menukik lurus sampai ±49 blok/detik), menanjak menguranginya (±23 blok/detik).
- **Meluncur:** lepas W saat kencang, Shazam meluncur dan melambat karena hambatan udara (kecepatan tinggi cepat berkurang, kecepatan rendah meluncur jauh), lalu berhenti dan melayang.

### Pose terbang

Pose badan juga dihitung dari gaya yang bekerja, lalu dihaluskan dengan pegas teredam (ada sedikit ayunan alami):

- **Melayang:** badan condong searah gaya yang dibutuhkan, seperti helikopter. Mulai maju berarti condong ke depan, bergeser berarti miring ke samping, mundur berarti condong ke belakang. Naik-turun pelan tetap tegak.
- **Meluncur:** badan sejajar lintasan dengan "hidung" sedikit naik (sudut serang), yang makin kecil saat makin kencang. Satu kepalan di depan; saat super cepat kedua kepalan di depan seperti peluru. Badan tegak saat menanjak dan kepala di bawah saat menukik.
- **Menikung:** badan miring ke dalam belokan seperti pesawat, dengan sudut sebesar arctan(percepatan menyamping ÷ gravitasi), sampai ±70° di belokan tajam. Kamera ikut miring setengahnya.
- **Arah badan:** badan menghadap arah lintasan, bukan arah kamera, jadi saat berbelok kencang badan menyusul pelan-pelan. Kepala tetap memandang ke arah kamera.
- **Tangan dan kaki:** lembam. Saat dipercepat kaki tertinggal ke belakang, saat mengerem terayun ke depan, dan makin kencang makin bergetar diterpa angin.
- **Menjelang tanah:** sekitar 0,8 detik sebelum menyentuh tanah sambil turun, badan menegak dan kaki maju untuk mendarat.

Pandangan juga melebar sesuai kecepatan. Angka-angka fisika gerak ada di bagian atas `FlightModel.java`, dan angka pose di `FlightPose.java`.

Mendarat atau jatuh dengan kencang memicu hero landing: satu lutut turun, kepalan menghantam tanah, dan gelombang kejut melukai musuh di sekitar. Menabrak dinding dengan kencang juga menimbulkan gelombang kejut.

## Kekuatan saat jadi Shazam

| Bagian | Nilai |
|---|---|
| Darah | 300 (bar darah sendiri menggantikan baris hati), pulih 3 per detik, langsung penuh tiap berubah jadi Shazam dan tiap balik jadi manusia |
| Ketahanan | damage yang diterima tinggal 40%, ditambah armor +20 dan toughness +12 (setara full netherite); kebal selama ritual berubah/balik |
| Serangan mematikan | nggak mati, tapi terlempar balik jadi manusia (darah 20/20); setelah itu 30 detik belum bisa SHAZAM lagi |
| Kebal | jatuh, petir, api, lava, tenggelam (nggak perlu napas), beku, lapar, kaktus, racun, wither |
| Kelemahan | sihir (+50% damage) |
| Pukulan tangan kosong | 40 (critical 60), pukulan penuh tiap 0,2 detik, musuh terpental jauh; pakai senjata: damage x2 |
| Lain-lain | badan 10% lebih besar, naik blok tanpa melompat, jangkauan +1, menghancurkan blok 4x lebih cepat |
| Energi Petir | 1000, berkurang 1 per detik saat jadi Shazam (±16 menit) dan terisi 5 per detik sebagai manusia; badai petir mempercepat |

## Tampilan saat jadi Shazam

Skin kamu tetap skin aslinya. Yang muncul saat berubah adalah hood, jubah, dan lambang 3D.

- **Enam dewa:** begitu SHAZAM diucapkan, Solomon, Hercules, Atlas, Zeus, Achilles, dan Mercury datang satu per satu dengan cara masuknya sendiri dan berdiri melengkung di seberang kamera, lalu mengalirkan sinar energinya ke kepalan yang terangkat dan lenyap jadi semburan cahaya enam warna tepat saat petir menyambar. Lihat *Yang baru di 0.15*. Mereka digambar di dunia, jadi tetap kelihatan dari sudut pandang orang pertama.
- **Saat berubah:** kepalan menembus langit, lalu petir sihir menyambar dan Shazam terangkat melayang. Kilau emas menyapu badan dari dada, lengan, kepala, sampai kaki. Di tengah kilau itu lambang muncul memantul di dada dengan kilatan terang. Jubah terbentang ke belakang lalu jatuh ke punggung, dan hood muncul di belakang leher lalu tertarik menutupi kepala.
- **Saat kembali jadi manusia:** lambang mengecil hilang, dan jubah, mantel, serta hood memudar jadi butiran cahaya emas.

### Slow motion saat berubah

Begitu kepalan terangkat ke langit, dunia melambat 4× dan petir sihir turun dari langit dengan ujung yang bercahaya dan memercik, tepat 2 detik sampai mengenai kepalan. Selama petir turun, enam dewa mengalirkan sinar energinya ke kepalan sambil memudar. Setelah petir mengenai, dunia tetap 2× lebih lambat selama kostum terbentuk (kilau emas, lambang, jubah, sampai hood tertarik ke kepala), lalu kembali normal pelan-pelan. Semuanya ikut melambat: gerakan, partikel, jubah, dan nada suara.

- Slow motion memperlambat seluruh dunia (sama seperti `/tick rate`), jadi hanya jalan kalau kamu sendirian di server. Di server dengan pemain lain, transformasinya tetap jalan dengan kecepatan normal.
- Kalau sebelumnya kamu memakai `/tick rate` sendiri, nilai itu yang dikembalikan. Kalau transformasi batal atau kamu keluar di tengah jalan, kecepatan langsung kembali normal.
- Kalau sedang di sudut pandang orang pertama, kamera pindah ke depan (orang ketiga, menghadap wajah) selama transformasi supaya semuanya terlihat jelas, lalu kembali seperti semula.
- Kecepatan dan lamanya bisa diatur di bagian atas `ShazamSlowMo.java`. Slow motion bisa dimatikan lewat `ENABLED` di file itu, dan kamera sinematik lewat `ENABLED` di `ShazamCinematic.java`.

### Jubah, mantel, dan hood (satu pakaian, 3D, berfisika)

Ketiganya kain 3D dengan fisika dunia nyata (XPBD, satuan meter, detik, dan kilogram) yang dihitung dengan langkah kecil tetap (160 kali per detik), jadi gerakannya halus dan sama di FPS berapa pun. Tiap kain dihitung di ruang tempat ia dipasang (jubah dan mantel di badan atas, hood di kepala), dan gerak badan di dunia masuk sebagai gaya semu yang benar secara fisika. Saat digambar, permukaan kain dihaluskan dengan kurva sehingga lipatannya melengkung, bukan bersudut. Urutan hitungnya tiap langkah: jubah, lalu mantel (yang selalu di luar bagian atas jubah), lalu hood (yang saat diturunkan tergeletak di atas mantel).

- **Hood:** bentuknya mengikuti kepala Minecraft yang kotak: penampang kotak dengan sudut atas membulat, sekitar 0,03 blok lebih besar dari kepala plus lapisan topi skin. Bingkai wajahnya lurus di samping pipi dan atas dahi, bagian atasnya sedikit maju menaungi dahi. Panel samping lurus sampai belakang kepala, lalu panel belakang yang rata dengan jahitan di tengah dan ujung runcing kecil di ubun-ubun. Pinggirannya menempel di wajah, sisanya kain yang ditahan dekat bentuknya (paling jauh 1,2-4,8 cm) dan sedikit berayun saat menoleh, menunduk, atau terbang. Hood tetap menjaga bentuknya, nggak pernah menutupi wajah, dan nggak pernah nyangkut di sisi kepala yang salah, secepat apa pun menolehnya.
- **Mantel bahu:** kain pendek yang melingkari pangkal kepala, jatuh menutupi kedua bahu, dada atas, dan punggung atas, dengan ujung lancip di tengah punggung. Mantel inilah yang menyatukan semuanya: tepi bawah hood masuk ke kerah mantel (seperti dijahit), list emas bingkai wajah bersambung ke list tepi depan mantel, dan bagian atas jubah tersembunyi di bawahnya. Mantel ditarik pelan ke bentuk pakainya, bagian di atas bahu ikut terangkat bersama lengan, dan kainnya menabrak badan serta kedua lengan (kotak bersudut bulat yang ikut berputar bersama lengan), jadi saat lengan diangkat atau diayun kainnya meluncur di atas lengan, nggak melorot dan nggak menembus.
- **Jubah:** bagian atasnya dipaku di bahu (di bawah mantel, ikut badan atas saat jongkok atau membungkuk) dan sisanya kain sungguhan: nggak pernah molor, nggak menembus badan, kaki, atau lengan, dan nggak menembus blok (lantai, dinding, langit-langit). Yang menggerakkannya:
  - Gravitasi 9,81 m/s² dan berat kain wol tebal (0,7 kg/m²).
  - Kelembaman: saat badan berbelok, berhenti, atau mendarat, jubah ikut terayun (gaya semu kerangka yang bergerak).
  - Hambatan udara sesuai sudut kain terhadap angin. Tepat di belakang badan udaranya ikut terseret badan (wake), jadi bagian itu menerima angin yang lebih pelan.
  - Turbulensi: pusaran udara yang terbawa aliran, lebih kuat di dalam wake, yang bikin jubah berkibar seperti bendera.

  Hasilnya, saat diam jubah menggantung sampai dekat tanah. Saat jalan terangkat sekitar 33°, saat sprint sekitar 43°, dan saat terbang memanjang di sepanjang badan sambil berkibar. Kalau terlempar ke atas, jubah jatuh lagi dalam ±0,5 detik lalu tenang. Di dalam air (air 800 kali lebih padat dari udara, dan kain hampir melayang) jubah mengambang pelan mengikuti arus gerak.
- **Angin sekitar:** di luar ruangan, jubah, mantel, dan hood bergoyang pelan tertiup angin yang arahnya berubah-ubah dan berembus. Angin lebih kencang saat hujan dan badai, dan tidak ada di dalam ruangan, gua, atau air.
- Tekan **H** untuk memakai atau melepas hood dengan tangan. Saat memakai, kedua tangan meraih ke belakang kepala, memegang tepi hood, lalu menariknya ke depan lewat atas kepala sampai dahi. Saat melepas, tangan memegang tepi hood di dahi lalu mendorongnya ke belakang sampai hood tergeletak di atas mantel di belakang leher. Hood baru bergerak saat tangan sudah memegangnya, dan terdengar gesekan kain. Statusnya tersimpan dan terlihat oleh pemain lain.
- **Saat terbentuk** (berubah jadi Shazam), tiap potong kain muncul bergantian (mantel, jubah, lalu hood) dan disapu pita cahaya emas dari atas ke bawah. **Saat lenyap**, kain memudar tembus pandang sambil melepas butiran cahaya emas.

**Kain dua lapis:** sisi luar putih, lapisan dalam berwarna gelap (biru tua keunguan), jadi bagian dalam hood terlihat dalam dan jubah yang berkibar memperlihatkan lapisan dalamnya. Warnanya diatur di `LINING` di bagian atas `ShazamCape.java` (angka RGB, misalnya `0x2E3458`).

**Hiasan emas:** list emas timbul di semua tepi: bingkai wajah dan tepi bawah hood, kerah, tepi depan, dan ujung bawah mantel, serta tepi kiri, kanan, dan bawah jubah. List itu timbul dari kain di kedua sisi, dengan tepi luar yang berkilau dan tepi dalam yang berbayang, dan sedikit menyala di tempat gelap. Karena menempel di titik-titik kain, list emas ikut berkibar.

**Aksesoris bahu:** di tiap bahu ada pelat emas tiga lapis yang bertumpuk seperti genteng, melengkung mengikuti mantel, dengan paku keling bercahaya di kedua ujungnya. Di kedua tepi depan mantel, tepat di bawah rahang hood, ada bros pengait berpermata, disambung rantai emas yang menjuntai di dada atas (di atas lambang dada). Semuanya menempel di kain mantel, jadi ikut bergerak saat mantel terdorong lengan atau tertiup angin. Letak dan ukurannya ada di `PLATE_COLS`, `PLATE_ROWS`, `CLASP_COL`, dan `CLASP_ROW` di `MantleShape.java`, serta bagian atas `CloakDecor.java`.

**Lambang punggung:** di tengah punggung jubah ada lambang 3D yang timbul dari kain dan ikut melengkung saat jubah berkibar. Lambang ini terang sendiri, dengan cahaya berdenyut, kilatan putih yang menyapu, dan pendar emas di kain sekitarnya. Gambarnya sama dengan lambang dada, kecuali kamu menaruh gambar khusus di `.../textures/entity/shazam_cape_emblem.png` (aturannya sama dengan lambang dada).

Lebar dan ketebalan list emas, serta ukuran, posisi, dan ketebalan lambang punggung, bisa diatur di bagian atas `CapeDecor.java`.

Jubah, mantel, dan hood juga muncul saat memakai Kostum Shazam (armor dada), walaupun tidak sedang jadi Shazam.

Warna dan motif kain ada di `.../textures/entity/shazam_cape_cloth.png`. Gambar itu dibentangkan ke seluruh jubah (kiri-kanan gambar = tepi kiri-kanan jubah, atas = bahu, bawah = ujung), dan bagian atasnya juga dipakai untuk hood dan mantel. Angka-angkanya bisa diatur di bagian atas file masing-masing: fisika umum (langkah per detik, gravitasi, hambatan udara, batas gaya semu, tabrakan) di `Cloak.java`; ukuran, berat, dan kelenturan jubah di `CapeShape.java`; bentuk dan kelenturan mantel di `MantleShape.java`; bentuk hood dan seberapa kuat bentuknya dijaga di `HoodShape.java`; angin sekitar, wake, dan turbulensi di `CapeAir.java`; kehalusan gambar dan warna di `ShazamCape.java`.

### Lambang 3D di dada

Bentuk dan warna lambang diambil dari `.../textures/entity/shazam_emblem.png`. Setiap piksel yang tidak transparan jadi balok kecil yang timbul dari dada, dengan warna piksel itu. Lambang menyala sendiri walaupun di tempat gelap, dan berkilau:

- cahaya emas berdenyut di sekelilingnya,
- kilatan putih yang menyapu permukaannya setiap ±2,5 detik,
- kilat terang saat lambang pertama muncul,
- percikan cahaya kecil yang sesekali keluar.

Lambang bawaannya bintang kilau empat sudut. Untuk memakai desain sendiri, timpa file itu dengan PNG berlatar transparan, maksimal 64×64 piksel (16×16 sampai 32×32 sudah cukup). Lebarnya otomatis disesuaikan ke dada, jadi gambar yang lebih tinggi daripada lebarnya akan memanjang ke bawah. Ukuran, posisi, dan ketebalannya bisa diatur di bagian atas `ShazamEmblemLayer.java`. Setelah mengganti gambar, build ulang (atau tekan F3+T saat `runClient`).

### Mata menyala: Zeus Rage dan Mata Solomon

Saat Zeus Rage menyala, matamu jadi putih terang dengan pendar biru-putih, kilau mendatar, dan kilatan listrik kecil di sekitarnya, lalu padam pelan saat amarahnya habis. Selama Zeus Rage aktif, listrik merayap di seluruh badan, busur listrik kecil keluar dari mata, dan batu-batu kecil (dari jenis tanah di bawahmu) terangkat dan mengorbit pelan di sekeliling badan. Pemain lain yang baru melihatmu di tengah amarah juga melihat semua efek ini.

Sesudah Mata Solomon, matamu menyala ungu selama ±3 detik.

Letak mata diatur untuk skin standar: baris ke-4 wajah, kolom 1-2 dan 5-6 (wajah 8×8 dihitung dari kiri-atas seperti terlihat dari depan). Kalau mata di skin-mu ada di baris atau kolom lain, ubah `EYE_ROW`, `EYE_HEIGHT`, dan `EYES` di bagian atas `ShazamEyesLayer.java`.

## Efek visual (buatan sendiri, bukan partikel Minecraft)

Semua efek skill, terbang, transformasi, dan petir digambar sendiri oleh mesin efek di `client/vfx`. Bentuknya dibuat dari geometri dengan gradasi warna per titik, jadi cahayanya halus di jarak berapa pun (nggak kotak-kotak seperti partikel bawaan). Tiap efek cahaya digambar dua lapis: badan tembus pandang berwarna pekat (supaya tetap tebal di siang hari), lalu cahayanya di lapisan aditif. Keduanya nggak menulis kedalaman, jadi pendar yang besar nggak pernah "memotong" benda di belakangnya.

| Efek | Isinya |
|---|---|
| Cahaya & kilatan | Pendar bulat lembut dengan inti putih, bintang kilau empat sudut |
| Gelombang kejut | Cincin yang melebar dan menempel di tanah yang tidak rata (tinggi tanah di sekitarnya diukur dulu), cincin debu, cincin yang melesat ke depan |
| Cangkang energi | Bola atau kubah yang tepinya paling terang (seperti gelembung energi), kerucut udara/uap |
| Petir | Jalur zig-zag bercabang yang berganti bentuk tiap 1-2 tick, busur listrik yang mengikuti tangan, listrik yang merayap di badan |
| Tanah | Retakan yang menjalar dari titik hantaman, membara emas-jingga lalu mendingin jadi celah gelap; bekas hangus; pecahan blok sungguhan (tekstur tanahnya) yang terlempar, berputar, jatuh, dan memantul |
| Butiran | Butiran cahaya, percikan berbentuk garis yang jatuh dan memantul, bara yang naik sambil mendingin, kepulan debu berwarna tanah yang bervolume, asap tebal yang naik dan mengembang |
| Sihir | Lingkaran rune berputar (cincin, sisir, busur putus-putus, huruf rune, bintang segi enam), tanda sasaran berputar di musuh |
| Lain-lain | Jejak cahaya (terjangan, menukik, tangan saat terbang), lidah api emas di sekeliling badan, tiang cahaya dari langit |
| Layar (pemain sendiri) | Garis kecepatan ala anime, vinyet berwarna di tepi layar, kilatan layar berwarna, sentakan pandangan |

Setiap skill memakai warna dewanya: ungu untuk Solomon, putih kehijauan untuk Hercules, jingga tanah untuk Atlas, emas untuk petir Zeus, emas untuk Achilles, biru muda untuk Mercury, dan putih kebiruan untuk Zeus Rage. Warna-warna ini ada di bagian atas `client/fx/ShazamFx.java`, dan urutan efek tiap skill ada di file yang sama. Kepekatan dan terangnya diatur `BODY` dan `GLOW` di `Draw.java`, kepadatan butiran `DENSITY` di `Vfx.java`, dan ketebalan petir `THICK` di `Lightning.java`. Jumlah efek dibatasi (`MAX_EFFECTS` di `Vfx.java`, butiran `MAX` di `Particles.java`) supaya tetap ringan; kalau penuh, yang paling dekat habis yang dibuang.

Tekstur khusus efek ada di `.../textures/entity/fx/`: `aegis.png` (perisai sisik Achilles) dan `weave.png` (kilau saat kostum terbentuk). `spirit.png` sudah nggak dipakai sejak 0.15 (dewa sekarang digambar dari geometri). Teksturnya bisa diganti dengan gambar sendiri ukuran 64×64 yang bisa diulang (latar hitam = tembus pandang, karena digambar sebagai cahaya).

## Animasi skill

Gerakan ada di `client/anim/Clips.java` sebagai keyframe. Selain putaran tiap bagian tubuh, condong badan (`tilt`), dan turunnya badan (`drop`), sekarang ada:

- `twist`: pinggang berputar (badan atas dan bahu ikut, kaki tetap), buat ancang-ancang memukul atau mencambuk;
- `lean`: seluruh badan condong ke samping;
- `spin`: seluruh badan berputar;
- `shake`: gemetar (derajat), buat mengumpulkan tenaga atau menahan amarah.

Tiap skill punya ancang-ancang, gerakan utama yang cepat dengan sedikit kebablasan, lalu kembali pelan. Waktu tiap gerakan pas dengan saat damage di server (`ShazamAnim.java`).

Gerak antar-keyframe dihaluskan otomatis (`SMOOTH` di `Clip.java`, dalam tick): kecepatan tangan, kepala, dan badan naik-turun mulus seperti otot sungguhan, tanpa sentakan satu frame, tapi waktunya tetap sama. Masuk/keluar animasi melengkung, dan kalau animasi baru mulai saat animasi lama masih jalan, yang lama memudar selama `XFADE` tick (`ShazamPoses.java`).

## Kostum armor (bisa di-craft)

Empat bagian, pertahanannya setara netherite, dan diperbaiki pakai emas. Teksturnya ada di `.../textures/models/armor/shazam_suit_layer_1.png` dan `_layer_2.png`.

| Bagian | Resep (G = emas batangan, R = wol merah) |
|---|---|
| Kepala Kostum Shazam | `KKK / BHB / _L_`: K = wol hitam, B = pewarna cokelat, H = helm berlian, L = penangkal petir |
| Kostum Shazam | `RLR / GCG / R_R`: L = penangkal petir, C = baju zirah berlian |
| Celana Kostum Shazam | `GYG / RLR / R_R`: Y = balok emas, L = celana berlian |
| Sepatu Kostum Shazam | `G_G / RDR / G_G`: D = sepatu berlian |

(`_` = kotak kosong.) Kostum ini nggak memberi kekuatan; kekuatan Shazam tetap datang dari mengucapkan SHAZAM.

## Perintah tes

Perintah ini butuh cheat aktif.

- `/shazam unlock [shazam|black_adam|all] [pemain]` dan `/shazam lock [shazam|black_adam|all] [pemain]`: membuka atau mencabut juara (tanpa pilihan: `unlock` = Shazam, `lock` = dua-duanya). `unlock` sekalian mengisi penuh Energi Petir dan menghapus waktu pulih sesudah serangan mematikan.
- `/shazam trial [pemain]`: mulai Ujian Kahndaq di tempat (tanpa syarat gurun & langit terbuka).
- `/shazam energy <0-1000>`: mengatur Energi Petir.
- `/shazam form <shazam|black_adam> [pemain]`: memilih juara yang sudah didapat. Yang sedang berubah wujud balik jadi manusia dulu.
- `/shazam summon <solomon|hercules|atlas|zeus|achilles|mercury>`: memunculkan penjaga.

## Kalau build gagal

- **`Plugin [id: 'net.neoforged.moddev', version: '2.0.+'] was not found`:** ganti `2.0.+` di `build.gradle` dengan versi ModDevGradle yang tertulis di MDK NeoForge 1.21.1 resmi.
- **Error soal versi Java:** pastikan `JAVA_HOME` mengarah ke JDK 21.
- **Crash saat game dibuka dengan pesan `Mixin`:** salin pesan error-nya dari `logs/latest.log` untuk diperbaiki.
- **Error kompilasi di `client/vfx`, `ShazamCape.java`, `ShazamFx.java`, `AdamFx.java`, `TrialFx.java`, `AdamGearLayer.java`, `AdamSkills.java`, `KahndaqTrial.java`, `ScarabItem.java`, `EgyptFigures.java`, `ShazamSkills.java`, `ShazamPassives.java`, `ChampionFx.java`, atau `GodAvatars.java`:** salin pesan error-nya (nama file, nomor baris, dan pesannya) untuk diperbaiki.

## Soal gradle-wrapper.jar

`gradle/wrapper/gradle-wrapper.jar` adalah pengganti ringkas untuk wrapper resmi Gradle. Sumbernya ada di `gradle/wrapper/GradleWrapperMain.java`. Cara kerjanya: mengunduh Gradle 8.14.3 sekali ke `~/.gradle/wrapper/dists`, lalu menjalankannya.

Kalau mau memakai wrapper resmi, ada dua cara:
- Kalau Gradle sudah terpasang, jalankan `gradle wrapper --gradle-version 8.14.3` di folder ini.
- Salin folder `gradle/` dan file `gradlew*` dari MDK resmi.
