package com.shazammod.client.render;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.joml.Matrix4f;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamItems;
import com.shazammod.ShazamMod;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.PlayerSkin;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Jubah Shazam 3D berfisika, satu pakaian utuh: jubah panjang di punggung, mantel bahu yang menyatukan
 * semuanya, dan hood. Muncul saat jadi Shazam (dan saat memakai Kostum Shazam).
 *
 * Fisikanya ada di Cloak (murni Java, satuan dunia nyata): kain XPBD yang dihitung di ruang badan dengan gaya
 * semu yang benar, hambatan udara + wake di belakang badan + turbulensi, tabrakan dengan badan, lengan, kaki,
 * kepala, dan blok dunia. Kelas ini cuma penghubung ke Minecraft: membaca keadaan pemain, mengumpulkan blok di
 * sekitar, mengatur hood naik/turun, lalu menggambar kainnya.
 *
 * Tampilan: kain putih dengan lapisan dalam berwarna gelap, list emas timbul di semua tepi, pelat emas bahu,
 * bros pengait dengan rantai di dada, dan lambang di punggung. Saat terbentuk, kain berkilau emas; saat
 * lenyap, kain memudar jadi butiran cahaya.
 *
 * Tekstur kain: assets/shazammod/textures/entity/shazam_cape_cloth.png
 */
public final class ShazamCape {
    private ShazamCape() {}

    public static final ResourceLocation TEXTURE = ShazamMod.id("textures/entity/shazam_cape_cloth.png");
    /** 0.38 kain jubah Lintang: merah tua kepar dengan jahitan tepi & kelim (warnanya sudah di tekstur). */
    public static final ResourceLocation LINTANG_TEXTURE = ShazamMod.id("textures/entity/lintang/cape_cloth.png");
    /** 0.42 jubah cahaya Lintang: berkas cahaya keemasan tegak yang bisa diulang ke bawah (digeser pelan = mengalir). */
    public static final ResourceLocation LINTANG_LIGHT = ShazamMod.id("textures/entity/lintang/cape_light.png");
    /** 0.44 kain jubah surya Lintang: emas pekat bergaris cahaya tegak (video), dinding kainnya tebal. */
    public static final ResourceLocation LINTANG_SUN = ShazamMod.id("textures/entity/lintang/cape_sun.png");
    private static final float SUN_OUT = 0.034f;   // tebal kain jubah surya: sisi luar ke arah luar ...
    private static final float SUN_IN = 0.022f;    // ... dan lapisan dalam ke arah badan (total ±0,9 piksel)
    /** 0.43 kain jubah Helion-6: hitam arang bertekstur sarang lebah, jahitan & garis tepi hijau radiasi. */
    public static final ResourceLocation HELION_TEXTURE = ShazamMod.id("textures/entity/helion/cape_cloth.png");
    /** 0.38 jubah Lintang lebih tebal: kain luar digeser keluar sejauh ini (blok), tepinya ditutup dinding kain. */
    private static final float PLAIN_OUT = 0.016f;

    // ======= Urutan muncul saat berubah (tick sejak kilau kostum mulai) =======
    public static final int EMBLEM_APPEAR = 3;
    private static final int MANTLE_APPEAR = 4;
    private static final int CAPE_APPEAR = 5;
    private static final int HOOD_APPEAR = 8;
    private static final int HOOD_PULL = 12;
    private static final float WEAVE_TICKS = 14f;      // kilau emas saat kain terbentuk
    private static final int FADE_TICKS = 12;          // kain memudar saat lenyap
    private static final float HOOD_SPEED = 0.08f;     // hood naik/turun sendiri selesai dalam ±12 tick

    // ======= Blok dunia yang ditabrak jubah =======
    private static final int WORLD_REACH = 2;          // blok di sekitar badan yang dicek (tiap arah)
    private static final double SIMULATE_RANGE = 64.0; // pemain lain sejauh ini atau lebih: fisika kainnya istirahat
    private static final int MAX_WORLD_BOXES = 160;

    // ======= Tampilan =======
    /** Warna lapisan dalam jubah, mantel, dan hood (RGB). Gelap supaya bagian dalam hood terlihat dalam. */
    // Warna kain luar & lapisan dalam (biru tua Shazam, merah marun Black Adam) ada di FormLook.
    private static final float LINING_GAP = 0.012f;       // jarak lapisan dalam dari kain luar (blok)
    private static final int CAPE_SMOOTH = 2;   // tiap sel jubah dipecah 2x2 saat digambar
    private static final int HOOD_SMOOTH = 2;
    private static final int MANTLE_SMOOTH = 3;
    private static final float MANTLE_TRIM_WIDTH = 0.05f;
    private static final float COLLAR_TRIM_WIDTH = 0.042f;
    private static final double CHEST_Z = -0.152;          // rantai menjuntai di depan dada (ruang leher)
    private static final int CAPE_DRAW_COLS = (CapeShape.COLS - 1) * CAPE_SMOOTH + 1;
    private static final int CAPE_DRAW_ROWS = (CapeShape.ROWS - 1) * CAPE_SMOOTH + 1;
    private static final int HOOD_DRAW_COLS = (HoodShape.COLS - 1) * HOOD_SMOOTH + 1;
    private static final int HOOD_DRAW_ROWS = (HoodShape.ROWS - 1) * HOOD_SMOOTH + 1;
    private static final int MANTLE_DRAW_COLS = (MantleShape.COLS - 1) * MANTLE_SMOOTH + 1;
    private static final int MANTLE_DRAW_ROWS = (MantleShape.ROWS - 1) * MANTLE_SMOOTH + 1;
    private static final int[] CAPE_EDGE = ClothDecor.capeChain(CAPE_DRAW_COLS, CAPE_DRAW_ROWS);
    private static final int[] HOOD_EDGE = ClothDecor.hoodChain(HOOD_DRAW_COLS, HOOD_DRAW_ROWS);
    private static final int[] MANTLE_EDGE = MantleShape.edgeChain(MANTLE_DRAW_COLS, MANTLE_DRAW_ROWS);
    private static final int[] MANTLE_COLLAR = MantleShape.collarChain(MANTLE_DRAW_COLS);

    private static final class Gear {
        final CloakDriver driver = new CloakDriver();
        int capeFade = -1;             // -1 = utuh; 0.. = sedang memudar (tick)
        int mantleFade = -1;
        int hoodFade = -1;
        float hoodDown;                // 0 = dipakai, 1 = diturunkan
        boolean hoodTarget;            // tujuan hood terakhir (true = dipakai)
        double hoodTargetSince;        // kapan tujuan itu berubah (buat menunggu animasi tangan)
        float frameYaw;                // arah badan asli di frame ini (buat membedakan pratinjau inventory)
        /** Pose badan bawaan Minecraft di luar bodyMatrix (berenang, merangkak, elytra, mati), dari render terakhir. */
        final Xform vanillaPose = new Xform();
        double wind;                   // kekuatan angin sekitar
        double[] boxes = new double[MAX_WORLD_BOXES * 6];
        int boxCount;
        final CloakDecor.Quads decor = new CloakDecor.Quads();
        /** Bentuk kain dari render dunia barusan (ruang render), buat dibekukan jadi bayangan Mercury. */
        float[][] lastCape, lastMantle, lastHood;
    }

    private static final Map<Integer, Gear> GEAR = new HashMap<>();
    private static long clientTicks;

    public static void clear() {
        GEAR.clear();
    }

    // ------------------------------------------------------------------ kapan dipakai

    /** Tick sejak kilau kostum mulai, 1000 kalau sudah lama jadi Shazam, atau -1 kalau bukan Shazam. */
    public static float revealTime(AbstractClientPlayer player, float partialTick) {
        if (!ShazamClientState.isTransformed(player.getId())) {
            return -1f;
        }
        if (ShazamPoses.suitIn(player)) {
            float t = ShazamPoses.suitTicks(player, partialTick);
            if (t >= 0f) {
                return t;
            }
        }
        return 1000f;
    }

    private static boolean wearsSuit(AbstractClientPlayer player) {
        return player.getItemBySlot(EquipmentSlot.CHEST).is(ShazamItems.SHAZAM_SUIT.get());
    }

    /**
     * 0.35 Lintang (ala Superman, beda dari tiga juara lain): cuma jubah tunggal yang terpasang di bahu, tanpa hood,
     * mantel bahu, list emas, lambang punggung, bros & rantai. Kainnya juga nggak terbentuk dari kilau cahaya atau lenyap
     * jadi butiran cahaya: muncul di tengah putaran ganti kostum dan hilang secepat kilat.
     */
    public static boolean plainCape(AbstractClientPlayer player) {
        FormLook look = FormLook.of(player.getId());   // 0.43: Helion-6 juga jubah tunggal tanpa hood & mantel
        return (look == FormLook.LINTANG || look == FormLook.HELION) && !wearsSuit(player);
    }

    public static boolean hasCape(AbstractClientPlayer player) {
        ItemStack chest = player.getItemBySlot(EquipmentSlot.CHEST);
        if (player.isInvisible() || chest.is(Items.ELYTRA)) {
            return false;
        }
        return revealTime(player, 0f) >= (plainCape(player) ? 0 : CAPE_APPEAR) || wearsSuit(player);
    }

    public static boolean hasMantle(AbstractClientPlayer player) {
        if (plainCape(player)) {
            return false;
        }
        return !player.isInvisible() && (revealTime(player, 0f) >= MANTLE_APPEAR || wearsSuit(player));
    }

    public static boolean hasHood(AbstractClientPlayer player) {
        if (ShazamClientState.isTransformed(player.getId()) && ShazamClientState.isSabbac(player.getId())) {
            return false;   // 0.30 Sabbac: tanduknya nggak muat di dalam hood
        }
        if (plainCape(player)) {
            return false;   // 0.35 Lintang: tanpa hood
        }
        return !player.isInvisible() && (revealTime(player, 0f) >= HOOD_APPEAR || wearsSuit(player));
    }

    private static double crouchOffset(AbstractClientPlayer player) {
        return player.isCrouching() ? -0.125 * player.getScale() : 0.0;
    }

    private static float smooth(float k) {
        k = Mth.clamp(k, 0f, 1f);
        return k * k * (3f - 2f * k);
    }

    /** Matrix4f JOML (ruang badan) -> Xform, digeser ke (ox, oy, oz). */
    private static Xform toXform(Matrix4f m, double ox, double oy, double oz, Xform out) {
        return out.setColumns(m.m00(), m.m01(), m.m02(), m.m10(), m.m11(), m.m12(), m.m20(), m.m21(), m.m22(),
                ox + m.m30(), oy + m.m31(), oz + m.m32());
    }

    // ------------------------------------------------------------------ keadaan pemain -> fisika

    /** Isi keadaan tubuh di posisi p (0..1) di antara tick lalu dan tick sekarang. Hood tidak diubah di sini. */
    private static void fill(AbstractClientPlayer player, Gear gear, float p, double tickTime, Cloak.Input in) {
        float yaw = Mth.rotLerp(p, player.yBodyRotO, player.yBodyRot);
        Matrix4f body = ShazamPoses.bodyMatrix(player, p, yaw);
        toXform(body, 0.0, 0.0, 0.0, in.body);
        in.body.mul(gear.vanillaPose, in.body);
        in.body.tx += Mth.lerp(p, player.xo, player.getX());
        in.body.ty += Mth.lerp(p, player.yo, player.getY()) + crouchOffset(player);
        in.body.tz += Mth.lerp(p, player.zo, player.getZ());
        in.slim = player.getSkin().model() == PlayerSkin.Model.SLIM;
        CapeAir.ambient(tickTime * Cloak.TICK, gear.wind, in.wind);
        in.water = player.isInWater();
        in.boxes = gear.boxes;
        in.boxCount = gear.boxCount;
        in.hoodDown = smooth(gear.hoodDown);
    }

    /** Hood naik/turun satu langkah kecil: dipakai/dilepas dengan tangan, jadi hood baru bergerak setelah dipegang. */
    private static void advanceHood(AbstractClientPlayer player, Gear gear, float p, double tickTime) {
        float reveal = revealTime(player, p);
        boolean pulling = reveal >= 0f && reveal < HOOD_PULL;   // saat berubah: hood di belakang leher dulu
        boolean up = ShazamClientState.isHoodUp(player.getId()) && !pulling;
        if (up != gear.hoodTarget) {
            gear.hoodTarget = up;
            gear.hoodTargetSince = tickTime;
        }
        float speed = HOOD_SPEED;
        ShazamAnim anim = ShazamPoses.currentAnim(player);
        if (anim == ShazamAnim.HOOD_UP || anim == ShazamAnim.HOOD_DOWN) {
            speed = ShazamPoses.animTime(player, p) < ShazamAnim.HOOD_GRAB ? 0f : 1f / ShazamAnim.HOOD_MOVE;
        } else if (tickTime - gear.hoodTargetSince < 2.0 && !pulling) {
            speed = 0f;   // tunggu sebentar: animasi tangannya mungkin baru sampai
        }
        gear.hoodDown = Mth.approach(gear.hoodDown, up ? 0f : 1f, speed / Cloak.SUBSTEPS);
    }

    /** Blok dunia di sekitar pemain yang bisa ditabrak jubah (lantai, dinding, langit-langit). */
    private static void gatherBlocks(ClientLevel level, AbstractClientPlayer player, Gear gear) {
        gear.boxCount = 0;
        if (player.isSpectator() || player.noPhysics) {
            return;
        }
        double scale = player.getScale();
        int reach = scale > 1.6 ? WORLD_REACH + 1 : WORLD_REACH;
        BlockPos base = BlockPos.containing(player.getX(), player.getY() + 0.9 * scale, player.getZ());
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        AABB self = player.getBoundingBox().deflate(0.05);
        for (int dy = -reach; dy <= reach; dy++) {
            for (int dx = -reach; dx <= reach; dx++) {
                for (int dz = -reach; dz <= reach; dz++) {
                    pos.set(base.getX() + dx, base.getY() + dy, base.getZ() + dz);
                    BlockState state = level.getBlockState(pos);
                    if (state.isAir()) {
                        continue;
                    }
                    VoxelShape shape = state.getCollisionShape(level, pos);
                    if (shape.isEmpty()) {
                        continue;
                    }
                    List<AABB> parts = shape.toAabbs();
                    for (AABB box : parts) {
                        AABB world = box.move(pos.getX(), pos.getY(), pos.getZ());
                        if (world.intersects(self)) {
                            continue;   // blok yang menembus badan sendiri (misalnya terjepit): abaikan
                        }
                        if (gear.boxCount >= MAX_WORLD_BOXES) {
                            return;
                        }
                        int o = gear.boxCount * 6;
                        gear.boxes[o] = world.minX; gear.boxes[o + 1] = world.minY; gear.boxes[o + 2] = world.minZ;
                        gear.boxes[o + 3] = world.maxX; gear.boxes[o + 4] = world.maxY; gear.boxes[o + 5] = world.maxZ;
                        gear.boxCount++;
                    }
                }
            }
        }
    }

    /** Angin sekitar: nggak ada di dalam ruangan atau di air, lebih kencang saat hujan dan badai. */
    private static double windStrength(ClientLevel level, AbstractClientPlayer player) {
        if (player.isInWater()) {
            return 0.0;
        }
        BlockPos pos = BlockPos.containing(player.getEyePosition());
        if (!level.canSeeSky(pos)) {
            return 0.0;
        }
        if (level.isThundering()) {
            return CapeAir.THUNDER;
        }
        return level.isRainingAt(pos) ? CapeAir.RAIN : 1.0;
    }

    // ------------------------------------------------------------------ tick client: muncul & lenyap

    public static void tick(ClientLevel level) {
        clientTicks++;
        Iterator<Map.Entry<Integer, Gear>> it = GEAR.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Gear> entry = it.next();
            Gear gear = entry.getValue();
            if (!(level.getEntity(entry.getKey()) instanceof AbstractClientPlayer player)) {
                it.remove();
                continue;
            }
            Cloak cloak = gear.driver.cloak;
            // kain yang nggak dipakai lagi memudar jadi butiran cahaya, lalu dibuang
            // (0.35 Lintang: hilang secepat kilat saat ganti baju, tanpa butiran cahaya)
            if (cloak.cape != null) {
                boolean plain = plainCape(player);
                gear.capeFade = hasCape(player) ? -1 : gear.capeFade + (plain ? 4 : 1);
                if (gear.capeFade == 0 && !plain) {
                    dissolve(level, cloak, cloak.cape, FormLook.of(player.getId()));
                }
                if (gear.capeFade >= FADE_TICKS) {
                    cloak.removeCape();
                    gear.capeFade = -1;
                }
            }
            if (cloak.mantle != null) {
                gear.mantleFade = hasMantle(player) ? -1 : gear.mantleFade + 1;
                if (gear.mantleFade == 0) {
                    dissolve(level, cloak, cloak.mantle, FormLook.of(player.getId()));
                }
                if (gear.mantleFade >= FADE_TICKS) {
                    cloak.removeMantle();
                    gear.mantleFade = -1;
                }
            }
            if (cloak.hood != null) {
                gear.hoodFade = hasHood(player) ? -1 : gear.hoodFade + 1;
                if (gear.hoodFade == 0) {
                    dissolve(level, cloak, cloak.hood, FormLook.of(player.getId()));
                }
                if (gear.hoodFade >= FADE_TICKS) {
                    cloak.removeHood();
                    gear.hoodFade = -1;
                }
            }
            if (cloak.cape == null && cloak.hood == null && cloak.mantle == null) {
                it.remove();
            }
        }
        for (AbstractClientPlayer player : level.players()) {
            boolean cape = hasCape(player);
            boolean mantle = hasMantle(player);
            boolean hood = hasHood(player);
            if (!cape && !hood && !mantle) {
                continue;
            }
            Gear gear = GEAR.computeIfAbsent(player.getId(), id -> new Gear());
            gear.wind = windStrength(level, player);
            gatherBlocks(level, player, gear);
            Cloak cloak = gear.driver.cloak;
            if ((cape && cloak.cape == null) || (mantle && cloak.mantle == null) || (hood && cloak.hood == null)) {
                // kain baru dipasang di pose tubuh sekarang
                float[] parts = ShazamPoses.parts(player);
                if (parts != null) {
                    gear.driver.capture(parts);
                }
                Cloak.Input in = gear.driver.in;
                fill(player, gear, 1f, clientTicks, in);
                gear.driver.currentPose(in.parts);
                in.time = clientTicks * Cloak.TICK;
                float reveal = revealTime(player, 1f);
                if (mantle && cloak.mantle == null) {
                    cloak.addMantle(in);
                }
                if (cape && cloak.cape == null) {
                    cloak.addCape(in, reveal >= 0f && reveal < 20f);
                }
                if (hood && cloak.hood == null) {
                    boolean pulling = reveal >= 0f && reveal < HOOD_PULL;
                    boolean down = pulling || !ShazamClientState.isHoodUp(player.getId());
                    gear.hoodDown = down ? 1f : 0f;
                    gear.hoodTarget = !down;
                    gear.hoodTargetSince = clientTicks;
                    in.hoodDown = gear.hoodDown;
                    cloak.addHood(in, down);
                }
            }
        }
    }

    /** Kain lenyap: butiran cahaya emas naik dari permukaannya (kainnya sendiri memudar). */
    private static void dissolve(ClientLevel level, Cloak cloak, ClothSim sim, FormLook look) {
        if (!sim.isReady()) {
            return;
        }
        Xform frame = cloak.worldFrame(sim);
        RandomSource random = level.random;
        double[] p = new double[3];
        for (int i = 0; i < sim.count; i += 2) {
            p[0] = sim.x[i]; p[1] = sim.y[i]; p[2] = sim.z[i];
            frame.toWorld(p);
            Vfx.mote(p[0], p[1], p[2], (random.nextDouble() - 0.5) * 0.04,
                    0.015 + random.nextDouble() * 0.035, (random.nextDouble() - 0.5) * 0.04,
                    look.dissolve, 0.05f + random.nextFloat() * 0.05f, 14 + random.nextInt(14));
            if (random.nextInt(6) == 0) {
                Vfx.glint(p[0], p[1], p[2], look.dissolveHot, 0.16f + random.nextFloat() * 0.1f, 8 + random.nextInt(6));
            }
        }
    }

    // ------------------------------------------------------------------ tiap frame: fisika dengan langkah kecil tetap

    /** Dipanggil sekali tiap frame sebelum dunia digambar. */
    public static void frame(ClientLevel level, float partialTick) {
        if (GEAR.isEmpty()) {
            return;
        }
        double now = clientTicks - 1 + partialTick;
        Minecraft mc = Minecraft.getInstance();
        for (Map.Entry<Integer, Gear> entry : GEAR.entrySet()) {
            if (!(level.getEntity(entry.getKey()) instanceof AbstractClientPlayer player)) {
                continue;
            }
            if (mc.player != null && player != mc.player
                    && player.distanceToSqr(mc.player) > SIMULATE_RANGE * SIMULATE_RANGE) {
                continue;   // terlalu jauh untuk terlihat detailnya; saat mendekat, kain lanjut dari keadaannya sekarang
            }
            Gear gear = entry.getValue();
            gear.frameYaw = Mth.rotLerp(partialTick, player.yBodyRotO, player.yBodyRot);
            gear.driver.frame(now, clientTicks - 1, (p, time, in) -> {
                advanceHood(player, gear, (float) p, time);
                fill(player, gear, (float) p, time, in);
            });
        }
    }

    // ------------------------------------------------------------------ render

    /** Satu potong kain yang siap digambar. */
    private record Piece(float[][] grid, int cols, int rows, float v0, float v1, float weave, int fade) {
        boolean solid() {
            return fade < 0;
        }

        float alpha() {
            return fade < 0 ? 1f : 1f - fade / (float) FADE_TICKS;
        }
    }

    /** Dipanggil dari RenderPlayerEvent.Post (titik asal = posisi render pemain). */
    public static void render(AbstractClientPlayer player, PlayerRenderer renderer, PoseStack poseStack,
                              MultiBufferSource buffers, float partialTick, int packedLight) {
        Gear gear = GEAR.get(player.getId());
        if (gear == null) {
            return;
        }
        gear.lastCape = null;
        gear.lastMantle = null;
        gear.lastHood = null;
        if (player.isInvisible() || Double.isNaN(gear.driver.simTime)) {
            return;
        }
        Cloak cloak = gear.driver.cloak;
        FormLook look = FormLook.of(player.getId());
        // Kain disimpan di ruang badan, jadi cukup dipasang di pose badan yang sedang digambar
        // (termasuk pratinjau inventory yang memutar badan sementara)
        float renderYaw = Mth.rotLerp(partialTick, player.yBodyRotO, player.yBodyRot);
        Xform standard = toXform(ShazamPoses.bodyMatrix(player, partialTick, renderYaw), 0.0, 0.0, 0.0, new Xform());
        Matrix4f rendered = ShazamPoses.renderedBody(player);
        Xform body = rendered == null ? new Xform(standard) : toXform(rendered, 0.0, 0.0, 0.0, new Xform());
        boolean world = Math.abs(Mth.wrapDegrees(renderYaw - gear.frameYaw)) < 0.5f;
        float[] parts = ShazamPoses.parts(player);
        if (parts == null) {
            parts = BodyRig.DEFAULT;
        } else if (world) {
            gear.driver.capture(parts);   // render dunia: pose ini dipakai fisika di frame berikutnya
        }
        if (world && rendered != null) {
            // selisih pose model sungguhan dengan bodyMatrix (biasanya nol; berenang/merangkak/elytra/mati)
            gear.vanillaPose.mul(body, new Xform().invert(standard));
        }
        double now = clientTicks - 1 + partialTick;
        double alpha = gear.driver.alpha(now);
        Xform neckR = new Xform().mul(body, Cloak.neckFrame(parts, new Xform()));

        PoseStack.Pose pose = poseStack.last();
        float reveal = revealTime(player, partialTick);
        boolean plain = plainCape(player);   // 0.35 Lintang: kain polos, tanpa emas & kilau
        Piece cape = null, mantle = null, hood = null;
        if (cloak.cape != null && cloak.cape.isReady()) {
            cape = new Piece(geometry(cloak.cape, neckR, alpha, CAPE_SMOOTH), CAPE_DRAW_COLS, CAPE_DRAW_ROWS, 0f, 1f,
                    plain ? 0f : weave(reveal, CAPE_APPEAR), gear.capeFade);
        }
        if (cloak.mantle != null && cloak.mantle.isReady()) {
            mantle = new Piece(geometry(cloak.mantle, neckR, alpha, MANTLE_SMOOTH), MANTLE_DRAW_COLS, MANTLE_DRAW_ROWS,
                    0f, 0.3f, weave(reveal, MANTLE_APPEAR), gear.mantleFade);
        }
        if (cloak.hood != null && cloak.hood.isReady()) {
            Xform hoodR = new Xform().mul(body, cloak.hoodFrame(parts, new Xform()));
            hood = new Piece(geometry(cloak.hood, hoodR, alpha, HOOD_SMOOTH), HOOD_DRAW_COLS, HOOD_DRAW_ROWS,
                    0f, 0.25f, weave(reveal, HOOD_APPEAR), gear.hoodFade);
        }
        Piece[] pieces = {cape, mantle, hood};
        if (world) {   // bentuk kain frame ini: bayangan Mercury yang dibuat sesudah ini memakai bentuk yang sama persis
            gear.lastCape = cape == null ? null : cape.grid();
            gear.lastMantle = mantle == null ? null : mantle.grid();
            gear.lastHood = hood == null ? null : hood.grid();
        }
        if (plain && look == FormLook.LINTANG) {   // 0.44 Lintang Mode Surya: jubah emas pekat & tebal yang menyala (video)
            if (cape != null) {
                sunCape(buffers, pose, cape, player.tickCount + partialTick);
            }
            return;
        }

        // Urutan buffer penting: tiap jenis render digambar sampai selesai sebelum ganti jenis lain
        // (buffer lama nggak boleh dipakai lagi setelah ganti).
        // 1) Kain utuh: sisi luar putih + lapisan dalam gelap
        ResourceLocation clothTex = plain ? (look == FormLook.HELION ? HELION_TEXTURE : LINTANG_TEXTURE) : TEXTURE;
        VertexConsumer cloth = buffers.getBuffer(RenderType.entityCutoutNoCull(clothTex));
        for (Piece piece : pieces) {
            if (piece != null && piece.solid()) {
                clothLayers(cloth, pose, piece, packedLight, 255, look, plain);
            }
        }
        // 2) Emas: list di semua tepi, pelat bahu, bros, rantai (0.35 Lintang: jubah polos tanpa emas)
        if (!plain) {
            VertexConsumer gold = buffers.getBuffer(RenderType.entityCutoutNoCull(CapeDecor.WHITE));
            golds(gold, pose, cape, mantle, hood, neckR, gear.decor, packedLight, true, 255, look);
        }
        // 3) Lambang punggung (memakai jenis render sendiri; 0.35 Lintang: tanpa lambang punggung)
        if (cape != null && cape.solid() && !plain) {
            float[][] g = cape.grid();
            float flash = reveal >= 0f ? Mth.clamp(1f - (reveal - CAPE_APPEAR) / 12f, 0f, 1f) : 0f;
            CapeDecor.backEmblem(buffers, pose, g[0], g[1], g[2], g[3], g[4], g[5],
                    CAPE_DRAW_COLS, CAPE_DRAW_ROWS, (float) CapeShape.TOP_WIDTH, (float) CapeShape.BOTTOM_WIDTH,
                    (float) CapeShape.LENGTH, player.tickCount + partialTick, flash, look);
        }
        // 4) Kain yang sedang memudar: tembus pandang
        boolean fading = false;
        for (Piece piece : pieces) {
            fading |= piece != null && !piece.solid();
        }
        if (fading) {
            VertexConsumer ghost = buffers.getBuffer(RenderType.entityTranslucent(plain
                    ? (look == FormLook.HELION ? HELION_TEXTURE : LINTANG_TEXTURE) : TEXTURE));
            for (Piece piece : pieces) {
                if (piece != null && !piece.solid()) {
                    clothLayers(ghost, pose, piece, packedLight, (int) (piece.alpha() * 255f), look, plain);
                }
            }
            if (!plain) {
                VertexConsumer ghostGold = buffers.getBuffer(RenderType.entityTranslucent(CapeDecor.WHITE));
                golds(ghostGold, pose, cape, mantle, hood, neckR, gear.decor, packedLight, false,
                        (int) (fadeAlpha(cape, mantle, hood) * 255f), look);
            }
        }
        // 5) Kilau emas aditif: kain yang baru terbentuk (cahaya menyapu dari atas ke bawah) atau sedang lenyap
        //    (0.35 Lintang: kain biasa, nggak bercahaya)
        boolean glowing = false;
        for (Piece piece : pieces) {
            glowing |= !plain && piece != null && (piece.weave() > 0f || !piece.solid());
        }
        if (glowing) {
            VertexConsumer glow = buffers.getBuffer(RenderType.eyes(CapeDecor.WHITE));
            for (Piece piece : pieces) {
                if (piece == null) {
                    continue;
                }
                if (piece.weave() > 0f) {
                    glowGrid(glow, pose, piece, 1f - piece.weave(), piece.weave(), true, look);
                } else if (!piece.solid()) {
                    float f = 1f - piece.alpha();
                    glowGrid(glow, pose, piece, 1f - f, (1f - f) * 0.9f, false, look);
                }
            }
        }
    }

    // ------------------------------------------------------------------ 0.44 jubah surya Lintang (pekat, 3D)

    /**
     * 0.44 Jubah surya: kain emas PEKAT (nggak tembus pandang) dengan tebal kain yang terlihat di tepinya, selalu terang
     * karena terbuat dari cahaya matahari (lipatannya tetap berbayang lewat arah normal), sisi dalam jingga keemasan.
     * Di atasnya cahaya keemasan mengalir pelan ke bawah, tepi kain bersinar tipis, dan kelim bawahnya meneteskan
     * sinar-sinar pendek. Saat lenyap kainnya memudar.
     */
    private static void sunCape(MultiBufferSource buffers, PoseStack.Pose pose, Piece piece, float time) {
        float fade = piece.solid() ? 1f : piece.alpha();
        if (fade <= 0.01f) {
            return;
        }
        float[][] g = piece.grid();
        int cols = piece.cols(), rows = piece.rows();
        int alpha = (int) (fade * 255f);
        int light = LightTexture.FULL_BRIGHT;
        VertexConsumer cloth = buffers.getBuffer(piece.solid() ? RenderType.entityCutoutNoCull(LINTANG_SUN)
                : RenderType.entityTranslucent(LINTANG_SUN));
        grid(cloth, pose, g, cols, rows, 0f, 1f, light, -SUN_OUT, -1f, 255, 255, 255, alpha);    // sisi luar emas
        grid(cloth, pose, g, cols, rows, 0f, 1f, light, SUN_IN, 1f, 238, 166, 82, alpha);        // sisi dalam jingga emas
        clothEdges(cloth, pose, piece, light, alpha, -SUN_OUT, SUN_IN, 255, 238, 196);            // tebal kain di tepi
        // cahaya yang mengalir pelan ke bawah di permukaan luar (dan lebih redup di dalam)
        float scroll = -time * 0.018f;
        VertexConsumer flow = buffers.getBuffer(RenderType.eyes(LINTANG_LIGHT));
        flowGrid(flow, pose, g, cols, rows, scroll, -SUN_OUT - 0.004f, 0.34f * fade, 0.1f * fade, 255, 206, 120);
        flowGrid(flow, pose, g, cols, rows, scroll * 1.3f, SUN_IN + 0.004f, 0.16f * fade, 0.05f * fade, 255, 170, 80);
        // tepi kain bersinar & sinar pendek yang menetes dari kelim
        VertexConsumer rays = buffers.getBuffer(RenderType.eyes(CapeDecor.WHITE));
        rimGlow(rays, pose, piece, 0.045f, 0.75f * fade);
        int last = (rows - 1) * cols;
        for (int c = 1; c < cols - 1; c += 2) {
            float len = (0.07f + 0.09f * hash01(c * 7 + 3)) * (0.6f + 0.4f * Mth.sin(time * 0.3f + c * 1.9f));
            lightRay(rays, pose, g, last + c, last + c - cols, len, 0.022f, 0.55f * fade);
        }
    }

    /** Cahaya aditif yang mengalir di permukaan kain (digeser inset ke arah normal kain), dua sisi. */
    private static void flowGrid(VertexConsumer vc, PoseStack.Pose pose, float[][] g, int cols, int rows, float scroll, float inset,
                                 float aTop, float aBottom, int r, int gr, int b) {
        for (int row = 0; row < rows - 1; row++) {
            for (int c = 0; c < cols - 1; c++) {
                int i = row * cols + c;
                int[] q = {i, i + cols, i + cols + 1, i + 1};
                for (int k = 0; k < 4; k++) {
                    flowVertex(vc, pose, g, q[k], cols, rows, scroll, inset, aTop, aBottom, r, gr, b);
                }
                for (int k = 3; k >= 0; k--) {
                    flowVertex(vc, pose, g, q[k], cols, rows, scroll, inset, aTop, aBottom, r, gr, b);
                }
            }
        }
    }

    private static void flowVertex(VertexConsumer vc, PoseStack.Pose pose, float[][] g, int i, int cols, int rows, float scroll,
                                   float inset, float aTop, float aBottom, int r, int gr, int b) {
        float u = (i % cols) / (float) (cols - 1);
        float v = (i / cols) / (float) (rows - 1);
        float a = Mth.clamp(aTop + (aBottom - aTop) * (float) Math.pow(v, 1.1), 0f, 1f);
        float edge = Math.min(u, 1f - u);
        a *= Mth.clamp(edge / 0.06f, 0.35f, 1f);   // tepi kiri-kanan sedikit lebih redup (list kain lebih tebal)
        int ai = (int) (a * 255f);
        vc.addVertex(pose, g[0][i] + g[3][i] * inset, g[1][i] + g[4][i] * inset, g[2][i] + g[5][i] * inset)
                .setColor(r * ai / 255, gr * ai / 255, b * ai / 255, 255)
                .setUv(u, v + scroll).setOverlay(OverlayTexture.NO_OVERLAY).setLight(LightTexture.FULL_BRIGHT)
                .setNormal(pose, g[3][i], g[4][i], g[5][i]);
    }

    /** Pinggiran kain bersinar: pita cahaya tipis di tepi kiri, kelim bawah, dan tepi kanan, memudar ke luar (dua sisi). */
    private static void rimGlow(VertexConsumer vc, PoseStack.Pose pose, Piece piece, float width, float a) {
        float[][] g = piece.grid();
        int cols = piece.cols(), rows = piece.rows();
        int n = rows + cols - 1 + rows - 1;
        int[] loop = new int[n];
        int k = 0;
        for (int r = 0; r < rows; r++) {
            loop[k++] = r * cols;
        }
        for (int c = 1; c < cols; c++) {
            loop[k++] = (rows - 1) * cols + c;
        }
        for (int r = rows - 2; r >= 0; r--) {
            loop[k++] = r * cols + cols - 1;
        }
        int ab = (int) (Mth.clamp(a, 0f, 1f) * 255f);
        int cr = 255 * ab / 255, cg = 228 * ab / 255, cb = 150 * ab / 255;
        for (int e = 0; e < k - 1; e++) {
            int i = loop[e], j = loop[e + 1];
            if (i / cols == 0 && j / cols == 0) {
                continue;   // leher nggak bersinar
            }
            float[] oi = outward(g, i, cols, rows), oj = outward(g, j, cols, rows);
            float[][] pts = {
                    {g[0][i], g[1][i], g[2][i]}, {g[0][j], g[1][j], g[2][j]},
                    {g[0][j] + oj[0] * width, g[1][j] + oj[1] * width, g[2][j] + oj[2] * width},
                    {g[0][i] + oi[0] * width, g[1][i] + oi[1] * width, g[2][i] + oi[2] * width}};
            int[] order = {0, 1, 2, 3, 3, 2, 1, 0};
            for (int o : order) {
                boolean tip = o >= 2;
                vc.addVertex(pose, pts[o][0], pts[o][1], pts[o][2]).setColor(tip ? 0 : cr, tip ? 0 : cg, tip ? 0 : cb, 255)
                        .setUv(0.5f, 0.5f).setOverlay(OverlayTexture.NO_OVERLAY).setLight(LightTexture.FULL_BRIGHT)
                        .setNormal(pose, 0f, 1f, 0f);
            }
        }
    }

    /** Arah keluar dari tepi kain di titik i (menjauh dari tetangga di dalam kain), satuan. */
    private static float[] outward(float[][] g, int i, int cols, int rows) {
        int c = i % cols, r = i / cols;
        int inner = c == 0 ? i + 1 : c == cols - 1 ? i - 1 : i - cols;
        if (r == rows - 1 && (c == 0 || c == cols - 1)) {
            inner = i - cols - (c == 0 ? -1 : 1);
        }
        float ox = g[0][i] - g[0][inner], oy = g[1][i] - g[1][inner], oz = g[2][i] - g[2][inner];
        float len = (float) Math.sqrt(ox * ox + oy * oy + oz * oz);
        return len < 1.0E-5f ? new float[] {0f, -1f, 0f} : new float[] {ox / len, oy / len, oz / len};
    }

    private static float hash01(int i) {
        int h = i * 0x9E3779B1;
        h ^= h >>> 15;
        h *= 0x85EBCA6B;
        h ^= h >>> 13;
        return (h & 0xFFFF) / 65535f;
    }

    /** Satu sinar cahaya dari titik kain i, searah (i - j), meruncing & memudar ke ujungnya (aditif, dua sisi). */
    private static void lightRay(VertexConsumer vc, PoseStack.Pose pose, float[][] g, int i, int j, float len, float width,
                                 float a) {
        float dx = g[0][i] - g[0][j], dy = g[1][i] - g[1][j], dz = g[2][i] - g[2][j];
        float l = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (l < 1.0E-5f || a <= 0.01f) {
            return;
        }
        dx /= l;
        dy /= l;
        dz /= l;
        float nx = g[3][i], ny = g[4][i], nz = g[5][i];
        float sx = dy * nz - dz * ny, sy = dz * nx - dx * nz, sz = dx * ny - dy * nx;   // samping = arah x normal kain
        float sl = (float) Math.sqrt(sx * sx + sy * sy + sz * sz);
        if (sl < 1.0E-5f) {
            return;
        }
        sx = sx / sl * width;
        sy = sy / sl * width;
        sz = sz / sl * width;
        float x = g[0][i], y = g[1][i], z = g[2][i], ex = x + dx * len, ey = y + dy * len, ez = z + dz * len;
        int k = (int) (Mth.clamp(a, 0f, 1f) * 220f);
        int r = 255 * k / 255, gg = 226 * k / 255, b = 160 * k / 255;
        float[][] pts = {{x - sx, y - sy, z - sz}, {x + sx, y + sy, z + sz}, {ex + sx * 0.1f, ey + sy * 0.1f, ez + sz * 0.1f},
                {ex - sx * 0.1f, ey - sy * 0.1f, ez - sz * 0.1f}};
        int[] order = {0, 1, 2, 3, 3, 2, 1, 0};
        for (int o : order) {
            boolean tip = o >= 2;
            vc.addVertex(pose, pts[o][0], pts[o][1], pts[o][2]).setColor(tip ? 0 : r, tip ? 0 : gg, tip ? 0 : b, 255)
                    .setUv(0.5f, 0.5f).setOverlay(OverlayTexture.NO_OVERLAY).setLight(LightTexture.FULL_BRIGHT)
                    .setNormal(pose, 0f, 1f, 0f);
        }
    }

    /** Posisi gambar kain (ruang render), dihaluskan, lengkap dengan normalnya: {x, y, z, nx, ny, nz}. */
    private static float[][] geometry(ClothSim sim, Xform frame, double alpha, int factor) {
        float[] vx = new float[sim.count], vy = new float[sim.count], vz = new float[sim.count];
        Cloak.pose(sim, frame, alpha, vx, vy, vz);
        return smoothed(vx, vy, vz, sim.cols, sim.rows, factor);
    }

    /** 0-1: seberapa kuat kilau terbentuk (1 = baru muncul, 0 = selesai atau bukan saat berubah). */
    private static float weave(float reveal, int appear) {
        if (reveal < 0f || reveal >= 999f) {
            return 0f;
        }
        float t = (reveal - appear) / WEAVE_TICKS;
        return t < 0f || t >= 1f ? 0f : 1f - t;
    }

    private static float fadeAlpha(Piece... pieces) {
        float a = 0f;
        for (Piece piece : pieces) {
            if (piece != null && !piece.solid()) {
                a = Math.max(a, piece.alpha());
            }
        }
        return a;
    }

    /** List emas, pelat bahu, bros, dan rantai untuk potongan yang utuh (solid) atau yang sedang memudar. */
    private static void golds(VertexConsumer gold, PoseStack.Pose pose, Piece cape, Piece mantle, Piece hood,
                              Xform neckR, CloakDecor.Quads decor, int light, boolean solid, int alpha, FormLook look) {
        if (cape != null && cape.solid() == solid) {
            float[][] g = cape.grid();
            CapeDecor.trim(gold, pose, g[0], g[1], g[2], g[3], g[4], g[5],
                    CAPE_DRAW_COLS, CAPE_DRAW_ROWS, CAPE_EDGE, CapeDecor.CAPE_TRIM_WIDTH, light, alpha, look);
        }
        if (hood != null && hood.solid() == solid) {
            float[][] g = hood.grid();
            CapeDecor.trim(gold, pose, g[0], g[1], g[2], g[3], g[4], g[5],
                    HOOD_DRAW_COLS, HOOD_DRAW_ROWS, HOOD_EDGE, CapeDecor.HOOD_TRIM_WIDTH, light, alpha, look);
        }
        if (mantle != null && mantle.solid() == solid) {
            float[][] g = mantle.grid();
            CapeDecor.trim(gold, pose, g[0], g[1], g[2], g[3], g[4], g[5],
                    MANTLE_DRAW_COLS, MANTLE_DRAW_ROWS, MANTLE_EDGE, MANTLE_TRIM_WIDTH, light, alpha, look);
            CapeDecor.trim(gold, pose, g[0], g[1], g[2], g[3], g[4], g[5],
                    MANTLE_DRAW_COLS, MANTLE_DRAW_ROWS, MANTLE_COLLAR, COLLAR_TRIM_WIDTH, light, alpha, look);
            decor.clear();
            if (look == FormLook.BLACK_ADAM) {
                // Black Adam: kalung lebar Mesir (usekh) emas & pirus, tanpa pelat bahu, bros, dan rantai Shazam
                CloakDecor.usekh(decor, g, MANTLE_DRAW_COLS, MANTLE_DRAW_ROWS, MANTLE_SMOOTH);
            } else if (look == FormLook.SABBAC) {
                // 0.30 Sabbac: pelat bahu besi hitam bertepi bara, tanpa bros & rantai Shazam
                CloakDecor.shoulderPlates(decor, g, MANTLE_DRAW_COLS, MANTLE_DRAW_ROWS, MANTLE_SMOOTH);
            } else {
                CloakDecor.shoulderPlates(decor, g, MANTLE_DRAW_COLS, MANTLE_DRAW_ROWS, MANTLE_SMOOTH);
                CloakDecor.clasps(decor, g, MANTLE_DRAW_COLS, MANTLE_DRAW_ROWS, MANTLE_SMOOTH, neckR, CHEST_Z);
            }
            CapeDecor.decor(gold, pose, decor, light, alpha, look);
        }
    }

    /** Haluskan permukaan kain lalu hitung normalnya: {x, y, z, nx, ny, nz} (normal menghadap badan). */
    private static float[][] smoothed(float[] vx, float[] vy, float[] vz, int cols, int rows, int factor) {
        float[][] g = ClothDecor.refine(vx, vy, vz, cols, rows, factor);
        int nc = (cols - 1) * factor + 1, nr = (rows - 1) * factor + 1;
        float[] nx = new float[g[0].length], ny = new float[g[0].length], nz = new float[g[0].length];
        ClothDecor.normals(g[0], g[1], g[2], nc, nr, nx, ny, nz);
        return new float[][] {g[0], g[1], g[2], nx, ny, nz};
    }

    /**
     * Kain dua lapis: sisi luar (putih Shazam / hitam Black Adam, normal ke luar) dan lapisan dalam (gelap, sedikit
     * ke arah badan). Warnanya dari FormLook, dikali tekstur kain.
     */
    private static void clothLayers(VertexConsumer vc, PoseStack.Pose pose, Piece piece, int light, int alpha, FormLook look,
                                    boolean plain) {
        if (plain) {   // 0.38 Lintang: kain tebal - warna dari tekstur, lapisan dalam lebih gelap, tepi bertembok kain
            grid(vc, pose, piece.grid(), piece.cols(), piece.rows(), piece.v0(), piece.v1(), light, -PLAIN_OUT, -1f,
                    255, 255, 255, alpha);
            grid(vc, pose, piece.grid(), piece.cols(), piece.rows(), piece.v0(), piece.v1(), light, LINING_GAP, 1f,
                    look == FormLook.HELION ? 96 : 150, look == FormLook.HELION ? 150 : 118, 118, alpha);   // 0.43 dalam: hijau tua
            clothEdges(vc, pose, piece, light, alpha, -PLAIN_OUT, LINING_GAP, 225, 210, 210);
            return;
        }
        int lr = (look.lining >> 16) & 0xFF, lg = (look.lining >> 8) & 0xFF, lb = look.lining & 0xFF;
        int cr = (look.cloth >> 16) & 0xFF, cg = (look.cloth >> 8) & 0xFF, cb = look.cloth & 0xFF;
        grid(vc, pose, piece.grid(), piece.cols(), piece.rows(), piece.v0(), piece.v1(), light, 0f, -1f, cr, cg, cb, alpha);
        grid(vc, pose, piece.grid(), piece.cols(), piece.rows(), piece.v0(), piece.v1(), light, LINING_GAP, 1f, lr, lg, lb, alpha);
    }

    /**
     * 0.38 tebal kain jubah Lintang: dinding tipis yang menutup celah antara kain luar & lapisan dalam di tepi kiri,
     * kanan, dan kelim bawah (terlihat saat jubah berkibar menyamping). Warnanya dari pita tepi tekstur.
     */
    private static void clothEdges(VertexConsumer vc, PoseStack.Pose pose, Piece piece, int light, int alpha, float out, float in,
                                   int er, int eg, int eb) {
        float[][] g = piece.grid();
        int cols = piece.cols(), rows = piece.rows();
        int n = rows + cols - 1 + rows - 1;
        int[] loop = new int[n];
        int k = 0;
        for (int r = 0; r < rows; r++) {
            loop[k++] = r * cols;                         // tepi kiri, dari leher ke bawah
        }
        for (int c = 1; c < cols; c++) {
            loop[k++] = (rows - 1) * cols + c;            // kelim bawah
        }
        for (int r = rows - 2; r >= 0; r--) {
            loop[k++] = r * cols + cols - 1;              // tepi kanan, naik ke leher
        }
        for (int e = 0; e < k - 1; e++) {
            int i = loop[e], j = loop[e + 1];
            edgeVertex(vc, pose, g, i, cols, rows, piece, light, alpha, out, er, eg, eb);
            edgeVertex(vc, pose, g, j, cols, rows, piece, light, alpha, out, er, eg, eb);
            edgeVertex(vc, pose, g, j, cols, rows, piece, light, alpha, in, er, eg, eb);
            edgeVertex(vc, pose, g, i, cols, rows, piece, light, alpha, in, er, eg, eb);
        }
    }

    private static void edgeVertex(VertexConsumer vc, PoseStack.Pose pose, float[][] g, int i, int cols, int rows, Piece piece,
                                   int light, int alpha, float inset, int cr, int cgr, int cb) {
        int c = i % cols, r = i / cols;
        // arah keluar dari tepi: menjauh dari tetangga di dalam kain
        int inner = c == 0 ? i + 1 : c == cols - 1 ? i - 1 : i - cols;
        if (r == rows - 1 && (c == 0 || c == cols - 1)) {
            inner = i - cols - (c == 0 ? -1 : 1);       // sudut bawah: menyerong keluar
        }
        float ox = g[0][i] - g[0][inner], oy = g[1][i] - g[1][inner], oz = g[2][i] - g[2][inner];
        float len = (float) Math.sqrt(ox * ox + oy * oy + oz * oz);
        if (len < 1.0E-5f) {
            ox = g[3][i];
            oy = g[4][i];
            oz = g[5][i];
            len = 1f;
        }
        float u = c / (float) (cols - 1);
        float v = piece.v0() + (piece.v1() - piece.v0()) * (r / (float) (rows - 1));
        float nx = g[3][i], ny = g[4][i], nz = g[5][i];
        vc.addVertex(pose, g[0][i] + nx * inset, g[1][i] + ny * inset, g[2][i] + nz * inset).setColor(cr, cgr, cb, alpha)
                .setUv(Math.min(Math.max(u, 0.004f), 0.996f), v).setOverlay(OverlayTexture.NO_OVERLAY).setLight(light)
                .setNormal(pose, ox / len, oy / len, oz / len);
    }

    /**
     * Gambar kain sebagai grid segi empat. g = {x, y, z, nx, ny, nz}.
     * @param inset  geser sejauh ini ke arah badan (lapisan dalam)
     * @param normal +1 = normal menghadap badan, -1 = menghadap luar
     */
    private static void grid(VertexConsumer vc, PoseStack.Pose pose, float[][] g, int cols, int rows,
                             float v0, float v1, int light, float inset, float normal, int r, int gr, int b, int a) {
        for (int row = 0; row < rows - 1; row++) {
            for (int c = 0; c < cols - 1; c++) {
                int i = row * cols + c;
                gridVertex(vc, pose, g, i, cols, rows, v0, v1, light, inset, normal, r, gr, b, a);
                gridVertex(vc, pose, g, i + cols, cols, rows, v0, v1, light, inset, normal, r, gr, b, a);
                gridVertex(vc, pose, g, i + cols + 1, cols, rows, v0, v1, light, inset, normal, r, gr, b, a);
                gridVertex(vc, pose, g, i + 1, cols, rows, v0, v1, light, inset, normal, r, gr, b, a);
            }
        }
    }

    private static void gridVertex(VertexConsumer vc, PoseStack.Pose pose, float[][] g, int i, int cols, int rows,
                                   float v0, float v1, int light, float inset, float normal, int r, int gr, int b, int a) {
        float u = (i % cols) / (float) (cols - 1);
        float v = v0 + (v1 - v0) * ((i / cols) / (float) (rows - 1));
        float nx = g[3][i], ny = g[4][i], nz = g[5][i];
        vc.addVertex(pose, g[0][i] + nx * inset, g[1][i] + ny * inset, g[2][i] + nz * inset).setColor(r, gr, b, a).setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(pose, nx * normal, ny * normal, nz * normal);
    }

    /**
     * Kilau emas aditif di permukaan kain: pita cahaya menyapu sepanjang kain (ke bawah saat terbentuk,
     * ke atas saat lenyap) ditambah pendar merata. Digambar dua sisi (jenis render ini membuang sisi belakang).
     */
    private static void glowGrid(VertexConsumer vc, PoseStack.Pose pose, Piece piece, float sweep, float strength, boolean down,
                                 FormLook look) {
        float[][] g = piece.grid();
        int cols = piece.cols(), rows = piece.rows();
        float band = down ? sweep * 1.4f - 0.2f : 1.2f - sweep * 1.4f;
        float[] k = new float[cols * rows];
        for (int i = 0; i < k.length; i++) {
            float v = (i / cols) / (float) (rows - 1);
            k[i] = strength * (0.28f + 0.95f * Math.max(0f, 1f - Math.abs(v - band) / 0.2f));
        }
        for (int row = 0; row < rows - 1; row++) {
            for (int c = 0; c < cols - 1; c++) {
                int a = row * cols + c, b = a + cols, cc = a + cols + 1, d = a + 1;
                glowVertex(vc, pose, g, a, k[a], look.weave);
                glowVertex(vc, pose, g, b, k[b], look.weave);
                glowVertex(vc, pose, g, cc, k[cc], look.weave);
                glowVertex(vc, pose, g, d, k[d], look.weave);
                glowVertex(vc, pose, g, d, k[d], look.weave);
                glowVertex(vc, pose, g, cc, k[cc], look.weave);
                glowVertex(vc, pose, g, b, k[b], look.weave);
                glowVertex(vc, pose, g, a, k[a], look.weave);
            }
        }
    }

    // ------------------------------------------------------------------ bayangan berjejak (Mercury)

    /**
     * Kain yang dibekukan untuk satu bayangan: jubah, mantel, hood (boleh null) dengan resolusi kasar
     * (titik-titik asli simulasinya), posisi relatif titik asal render pemain saat bayangan dibuat.
     */
    public static final class GhostCloth {
        final float[][] cape, mantle, hood;

        GhostCloth(float[][] cape, float[][] mantle, float[][] hood) {
            this.cape = cape;
            this.mantle = mantle;
            this.hood = hood;
        }
    }

    private static final int[] GHOST_CAPE_EDGE = ClothDecor.capeChain(CapeShape.COLS, CapeShape.ROWS);
    private static final int[] GHOST_HOOD_EDGE = ClothDecor.hoodChain(HoodShape.COLS, HoodShape.ROWS);
    private static final int[] GHOST_MANTLE_EDGE = MantleShape.edgeChain(MantleShape.COLS, MantleShape.ROWS);
    private static final float GHOST_TRIM_RAISE = 0.012f;

    /** true = render dunia biasa (bukan pratinjau inventory yang memutar badan sementara). */
    public static boolean isWorldRender(AbstractClientPlayer player, float partialTick) {
        Gear gear = GEAR.get(player.getId());
        if (gear == null) {
            return true;
        }
        float yaw = Mth.rotLerp(partialTick, player.yBodyRotO, player.yBodyRot);
        return Math.abs(Mth.wrapDegrees(yaw - gear.frameYaw)) < 0.5f;
    }

    /** Bentuk kain dari render dunia barusan (dipanggil tepat sesudah render), atau null kalau nggak pakai kain. */
    public static GhostCloth ghostCloth(AbstractClientPlayer player) {
        Gear gear = GEAR.get(player.getId());
        if (gear == null || (gear.lastCape == null && gear.lastMantle == null && gear.lastHood == null)) {
            return null;
        }
        return new GhostCloth(coarse(gear.lastCape, CAPE_DRAW_COLS, CAPE_DRAW_ROWS, CAPE_SMOOTH),
                coarse(gear.lastMantle, MANTLE_DRAW_COLS, MANTLE_DRAW_ROWS, MANTLE_SMOOTH),
                coarse(gear.lastHood, HOOD_DRAW_COLS, HOOD_DRAW_ROWS, HOOD_SMOOTH));
    }

    /** Ambil tiap titik ke-step dari grid halus (= titik asli simulasi): bayangan cukup segini detailnya. */
    private static float[][] coarse(float[][] g, int cols, int rows, int step) {
        if (g == null) {
            return null;
        }
        int nc = (cols - 1) / step + 1, nr = (rows - 1) / step + 1;
        float[][] out = new float[6][nc * nr];
        for (int r = 0; r < nr; r++) {
            for (int c = 0; c < nc; c++) {
                int src = r * step * cols + c * step, dst = r * nc + c;
                for (int k = 0; k < 6; k++) {
                    out[k][dst] = g[k][src];
                }
            }
        }
        return out;
    }

    /**
     * Isi kain bayangan: sisi luar diwarnai rgb, tembus pandang (render-nya tanpa cull, jadi dua sisi sekaligus).
     * pose = titik asal render saat bayangan dibuat.
     */
    public static void ghostFill(VertexConsumer vc, PoseStack.Pose pose, GhostCloth cloth, int rgb, int alpha) {
        int r = (rgb >> 16) & 0xFF, g = (rgb >> 8) & 0xFF, b = rgb & 0xFF;
        int light = LightTexture.FULL_BRIGHT;
        if (cloth.cape != null) {
            grid(vc, pose, cloth.cape, CapeShape.COLS, CapeShape.ROWS, 0f, 1f, light, 0f, -1f, r, g, b, alpha);
        }
        if (cloth.mantle != null) {
            grid(vc, pose, cloth.mantle, MantleShape.COLS, MantleShape.ROWS, 0f, 0.3f, light, 0f, -1f, r, g, b, alpha);
        }
        if (cloth.hood != null) {
            grid(vc, pose, cloth.hood, HoodShape.COLS, HoodShape.ROWS, 0f, 0.25f, light, 0f, -1f, r, g, b, alpha);
        }
    }

    /** List emas bayangan: cuma permukaannya (satu segi empat per ruas), tembus pandang. */
    public static void ghostTrim(VertexConsumer vc, PoseStack.Pose pose, GhostCloth cloth, int rgb, int alpha) {
        ghostTrim(vc, pose, cloth.cape, CapeShape.COLS, CapeShape.ROWS, GHOST_CAPE_EDGE, CapeDecor.CAPE_TRIM_WIDTH, rgb, alpha);
        ghostTrim(vc, pose, cloth.hood, HoodShape.COLS, HoodShape.ROWS, GHOST_HOOD_EDGE, CapeDecor.HOOD_TRIM_WIDTH, rgb, alpha);
        ghostTrim(vc, pose, cloth.mantle, MantleShape.COLS, MantleShape.ROWS, GHOST_MANTLE_EDGE, MANTLE_TRIM_WIDTH, rgb, alpha);
    }

    private static void ghostTrim(VertexConsumer vc, PoseStack.Pose pose, float[][] g, int cols, int rows, int[] chain,
                                  float width, int rgb, int alpha) {
        if (g == null) {
            return;
        }
        float[] quads = new float[chain.length * 4 * ClothDecor.STRIDE];
        int count = ClothDecor.trim(g[0], g[1], g[2], g[3], g[4], g[5], cols, rows, chain, width, GHOST_TRIM_RAISE, quads);
        int r = (rgb >> 16) & 0xFF, gr = (rgb >> 8) & 0xFF, b = rgb & 0xFF;
        for (int q = 0; q < count; q += 4) {   // tiap ruas: 4 segi empat, yang pertama = permukaan list
            int o = q * ClothDecor.STRIDE;
            for (int v = 0; v < 4; v++) {
                vc.addVertex(pose, quads[o + v * 3], quads[o + v * 3 + 1], quads[o + v * 3 + 2])
                        .setColor(r, gr, b, alpha).setUv(0.5f, 0.5f).setOverlay(OverlayTexture.NO_OVERLAY)
                        .setLight(LightTexture.FULL_BRIGHT).setNormal(pose, quads[o + 12], quads[o + 13], quads[o + 14]);
            }
        }
    }

    /**
     * Pendar listrik di permukaan kain bayangan (aditif): makin miring permukaannya terhadap pandangan (tepi siluet),
     * makin terang, seperti energi yang membentuk kain. cam = posisi kamera relatif titik asal bayangan.
     */
    public static void ghostGlow(VertexConsumer vc, PoseStack.Pose pose, GhostCloth cloth, float camX, float camY, float camZ,
                                 int rgb, float strength) {
        if (strength <= 0.01f) {
            return;
        }
        ghostGlow(vc, pose, cloth.cape, CapeShape.COLS, CapeShape.ROWS, camX, camY, camZ, rgb, strength);
        ghostGlow(vc, pose, cloth.mantle, MantleShape.COLS, MantleShape.ROWS, camX, camY, camZ, rgb, strength);
        ghostGlow(vc, pose, cloth.hood, HoodShape.COLS, HoodShape.ROWS, camX, camY, camZ, rgb, strength);
    }

    private static void ghostGlow(VertexConsumer vc, PoseStack.Pose pose, float[][] g, int cols, int rows,
                                  float camX, float camY, float camZ, int rgb, float strength) {
        if (g == null) {
            return;
        }
        int n = cols * rows;
        float[] k = new float[n];
        for (int i = 0; i < n; i++) {
            float vx = camX - g[0][i], vy = camY - g[1][i], vz = camZ - g[2][i];
            float len = (float) Math.sqrt(vx * vx + vy * vy + vz * vz);
            float facing = len < 1.0E-4f ? 1f : Math.abs(vx * g[3][i] + vy * g[4][i] + vz * g[5][i]) / len;
            float rim = 1f - facing;
            k[i] = strength * (0.06f + 0.94f * rim * rim * rim);
        }
        for (int row = 0; row < rows - 1; row++) {
            for (int c = 0; c < cols - 1; c++) {
                int a = row * cols + c, b = a + cols, cc = a + cols + 1, d = a + 1;
                // cuma urutan yang menghadap kamera (jenis render aditif ini membuang sisi belakang)
                float ux = g[0][b] - g[0][a], uy = g[1][b] - g[1][a], uz = g[2][b] - g[2][a];
                float wx = g[0][cc] - g[0][a], wy = g[1][cc] - g[1][a], wz = g[2][cc] - g[2][a];
                float nx = uy * wz - uz * wy, ny = uz * wx - ux * wz, nz = ux * wy - uy * wx;
                float side = nx * (camX - g[0][a]) + ny * (camY - g[1][a]) + nz * (camZ - g[2][a]);
                if (side >= 0f) {
                    ghostGlowVertex(vc, pose, g, a, k[a], rgb);
                    ghostGlowVertex(vc, pose, g, b, k[b], rgb);
                    ghostGlowVertex(vc, pose, g, cc, k[cc], rgb);
                    ghostGlowVertex(vc, pose, g, d, k[d], rgb);
                } else {
                    ghostGlowVertex(vc, pose, g, d, k[d], rgb);
                    ghostGlowVertex(vc, pose, g, cc, k[cc], rgb);
                    ghostGlowVertex(vc, pose, g, b, k[b], rgb);
                    ghostGlowVertex(vc, pose, g, a, k[a], rgb);
                }
            }
        }
    }

    private static void ghostGlowVertex(VertexConsumer vc, PoseStack.Pose pose, float[][] g, int i, float k, int rgb) {
        float s = Mth.clamp(k, 0f, 1.6f);
        int r = Math.min(255, (int) (((rgb >> 16) & 0xFF) * s)), gr = Math.min(255, (int) (((rgb >> 8) & 0xFF) * s));
        int b = Math.min(255, (int) ((rgb & 0xFF) * s));
        vc.addVertex(pose, g[0][i], g[1][i], g[2][i]).setColor(r, gr, b, 255).setUv(0.5f, 0.5f)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(LightTexture.FULL_BRIGHT).setNormal(pose, 0f, 1f, 0f);
    }

    private static void glowVertex(VertexConsumer vc, PoseStack.Pose pose, float[][] g, int i, float k, int[] rgb) {
        float s = Mth.clamp(k, 0f, 1f);
        float out = -0.004f;   // sedikit di luar kain
        vc.addVertex(pose, g[0][i] + g[3][i] * out, g[1][i] + g[4][i] * out, g[2][i] + g[5][i] * out)
                .setColor((int) (rgb[0] * s), (int) (rgb[1] * s), (int) (rgb[2] * s), 255).setUv(0.5f, 0.5f)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(LightTexture.FULL_BRIGHT).setNormal(pose, 0f, 1f, 0f);
    }
}
