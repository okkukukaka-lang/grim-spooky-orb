package com.shazammod.client.render;

import org.joml.Vector3f;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamMod;

import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.PlayerSkin;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * 0.44 Matahari bahu Lintang (Mode Surya), dibuat ulang: 3D & PEKAT (nggak tembus pandang lagi). Di atas kedua bahu duduk
 * matahari kecil padat - inti bulat putih keemasan dengan duri-duri sinar runcing berbentuk limas yang memancar ke atas
 * & ke samping seperti bintang di video (panjang-pendek berselang), berputar pelan & berdenyut. Warnanya menyala sendiri
 * (nggak ikut gelap di tempat gelap) tapi tetap berbayang lembut dari atas supaya bentuk 3D-nya jelas, ditambah pendar
 * cahaya tipis di sekelilingnya. Menempel di badan (bukan di lengan), jadi tetap di bahu walau lengan diayun.
 * Jubahnya digambar ShazamCape, lambang matahari di dada oleh ShazamEmblemLayer.
 */
public class LintangLightLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation WHITE = ShazamMod.id("textures/entity/shazam_white.png");
    private static final float PI = (float) Math.PI, HALF_PI = PI * 0.5f, TWO_PI = PI * 2f;

    // ======= Angka yang gampang diutak-atik (satuan piksel model) =======
    private static final int SPIKES = 16;
    private static final float CORE = 2.1f;         // jari-jari inti
    private static final float LONG = 4.0f;         // panjang duri panjang (dari permukaan inti)
    private static final float SHORT = 2.5f;        // panjang duri pendek
    private static final float BASE = 0.75f;        // setengah lebar pangkal duri
    private static final float CAP = 78f;           // sebaran duri (derajat dari arah atas-luar)

    // warna: inti putih panas -> emas pucat -> ujung duri keemasan (video: matahari bahu putih menyilaukan)
    private static final int CORE_HOT = 0xFFFDF2, CORE_RIM = 0xFFE7A8, SPIKE_BASE = 0xFFF4D6, SPIKE_TIP = 0xFFC45A;

    public LintangLightLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    public static boolean active(AbstractClientPlayer player) {
        return !player.isInvisible() && ShazamClientState.isTransformed(player.getId()) && ShazamClientState.isLintang(player.getId());
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buffers, int light, AbstractClientPlayer player, float limbSwing,
                       float limbAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        try {
            if (!active(player)) {
                return;
            }
            PlayerModel<AbstractClientPlayer> m = getParentModel();
            if (!m.body.visible) {
                return;
            }
            // saat berubah wujud (Mode Surya) matahari bahunya menyala & membesar dengan hentakan kecil
            float reveal = ShazamCape.revealTime(player, partialTick);
            float pop = reveal < 0f || reveal >= 999f ? 1f : Mth.clamp((reveal - 4f) / 8f, 0f, 1f);
            if (pop <= 0.01f) {
                return;
            }
            float size = pop >= 1f ? 1f : 1f + 2.70158f * (float) Math.pow(pop - 1f, 3) + 1.70158f * (float) Math.pow(pop - 1f, 2);
            boolean slim = player.getSkin().model() == PlayerSkin.Model.SLIM;
            float sx = slim ? 5.5f : 6f;   // tengah atas lengan (ruang badan)
            ps.pushPose();
            m.body.translateAndRotate(ps);
            ps.scale(1f / 16f, 1f / 16f, 1f / 16f);
            PoseStack.Pose pose = ps.last();
            int seed = player.getId();
            VertexConsumer solid = buffers.getBuffer(RenderType.entityCutoutNoCull(WHITE));
            if (m.rightArm.visible) {
                sun(solid, pose, -sx, -0.7f, 0f, -1f, ageInTicks, seed, size);
            }
            if (m.leftArm.visible) {
                sun(solid, pose, sx, -0.7f, 0f, 1f, ageInTicks, seed + 7, size);
            }
            // pendar menghadap kamera: posisi kamera di ruang model (pose ini cuma berisi geseran relatif kamera)
            Vector3f cam = new org.joml.Matrix4f(pose.pose()).invert().transformPosition(new Vector3f());
            if (Float.isFinite(cam.x) && Float.isFinite(cam.y) && Float.isFinite(cam.z)) {
                VertexConsumer glow = buffers.getBuffer(RenderType.eyes(WHITE));
                if (m.rightArm.visible) {
                    halo(glow, pose, -sx, -0.7f, 0f, -1f, ageInTicks, seed, cam, size);
                }
                if (m.leftArm.visible) {
                    halo(glow, pose, sx, -0.7f, 0f, 1f, ageInTicks, seed + 7, cam, size);
                }
            }
            ps.popPose();
        } catch (Throwable ignored) {
            // lapisan kostum nggak boleh bikin game crash
        }
    }

    // ------------------------------------------------------------------ bentuk

    /** Arah duri ke-i: tersebar rata (spiral emas) di tudung bola yang menghadap atas-luar, diputar pelan. side -1 = kanan. */
    private static Vector3f spikeDir(int i, float side, float spin) {
        // sumbu tudung: ke luar & ke atas (ruang model: -y = atas, kanan = -x)
        Vector3f axis = new Vector3f(side * 0.72f, -0.7f, 0f).normalize();
        float cap = CAP * Mth.DEG_TO_RAD;
        float h = (i + 0.5f) / SPIKES;
        float theta = cap * (float) Math.sqrt(h);   // rata di permukaan tudung
        float phi = i * 2.39996f + spin;
        Vector3f u = new Vector3f(axis).cross(0f, 0f, 1f).normalize();
        Vector3f w = new Vector3f(axis).cross(u).normalize();
        float st = Mth.sin(theta), ct = Mth.cos(theta);
        return new Vector3f(axis).mul(ct).add(new Vector3f(u).mul(st * Mth.cos(phi))).add(new Vector3f(w).mul(st * Mth.sin(phi))).normalize();
    }

    private static void sun(VertexConsumer vc, PoseStack.Pose pose, float cx, float cy, float cz, float side, float t, int seed,
                            float size) {
        float spin = t * 0.012f * side + seed;
        float breathe = (1f + 0.05f * Mth.sin(t * 0.18f + seed)) * size;
        // inti: bola padat (gradasi putih panas di tengah ke emas di tepinya, terang dari atas)
        int lat = 6, lon = 10;
        float r = CORE * breathe;
        for (int i = 0; i < lat; i++) {
            float t0 = PI * i / lat, t1 = PI * (i + 1) / lat;
            for (int j = 0; j < lon; j++) {
                float p0 = TWO_PI * j / lon, p1 = TWO_PI * (j + 1) / lon;
                float[][] n = {sph(t0, p0), sph(t0, p1), sph(t1, p1), sph(t1, p0)};
                for (float[] q : n) {
                    int col = tone(Draw2.mix(CORE_HOT, CORE_RIM, 0.35f + 0.35f * (1f - Math.abs(q[2]))), q[0], q[1], q[2]);
                    put(vc, pose, cx + q[0] * r, cy + q[1] * r, cz + q[2] * r, col, q[0], q[1], q[2]);
                }
            }
        }
        // duri sinar: limas segi empat runcing dari permukaan inti
        for (int i = 0; i < SPIKES; i++) {
            Vector3f d = spikeDir(i, side, spin);
            boolean lng = i % 2 == 0;
            float pulse = 0.88f + 0.12f * Mth.sin(t * 0.22f + i * 1.7f + seed);
            float len = (lng ? LONG : SHORT) * pulse * breathe;
            float bw = BASE * (lng ? 1f : 0.82f) * size;
            Vector3f a = Math.abs(d.z) < 0.9f ? new Vector3f(d).cross(0f, 0f, 1f).normalize() : new Vector3f(d).cross(1f, 0f, 0f).normalize();
            Vector3f b = new Vector3f(d).cross(a).normalize();
            float bx = cx + d.x * r * 0.85f, by = cy + d.y * r * 0.85f, bz = cz + d.z * r * 0.85f;
            float tx = cx + d.x * (r + len), ty = cy + d.y * (r + len), tz = cz + d.z * (r + len);
            float[][] base = new float[4][];
            for (int k = 0; k < 4; k++) {
                float ang = HALF_PI * k + PI * 0.25f;
                float ca = Mth.cos(ang) * bw, sa = Mth.sin(ang) * bw;
                base[k] = new float[] {bx + a.x * ca + b.x * sa, by + a.y * ca + b.y * sa, bz + a.z * ca + b.z * sa};
            }
            for (int k = 0; k < 4; k++) {   // empat sisi limas: pangkal emas terang -> ujung jingga keemasan
                float[] p = base[k], q = base[(k + 1) % 4];
                // normal sisi: (q - p) x (ujung - p)
                float ux = q[0] - p[0], uy = q[1] - p[1], uz = q[2] - p[2];
                float vx = tx - p[0], vy = ty - p[1], vz = tz - p[2];
                float nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
                float nl = Mth.sqrt(nx * nx + ny * ny + nz * nz);
                if (nl < 1.0E-6f) {
                    continue;
                }
                nx /= nl;
                ny /= nl;
                nz /= nl;
                int cb = tone(SPIKE_BASE, nx, ny, nz), ct = tone(SPIKE_TIP, nx, ny, nz);
                put(vc, pose, p[0], p[1], p[2], cb, nx, ny, nz);
                put(vc, pose, q[0], q[1], q[2], cb, nx, ny, nz);
                put(vc, pose, tx, ty, tz, ct, nx, ny, nz);
                put(vc, pose, tx, ty, tz, ct, nx, ny, nz);
            }
        }
    }

    /** Pendar cahaya tipis di sekeliling matahari bahu (aditif, cakram yang selalu menghadap kamera). */
    private static void halo(VertexConsumer vc, PoseStack.Pose pose, float cx, float cy, float cz, float side, float t, int seed,
                             Vector3f cam, float size) {
        float k = (0.85f + 0.15f * Mth.sin(t * 0.25f + seed)) * size;
        float ox = cx + side * 1.4f, oy = cy - 1.4f;   // pusat pendar sedikit ke arah duri
        billboard(vc, pose, ox, oy, cz, 6.4f * k, 0.3f, cam, 255, 206, 120);
        billboard(vc, pose, cx, cy, cz, 3.0f * k, 0.6f, cam, 255, 240, 200);
    }

    /** Cakram cahaya aditif yang menghadap titik cam (ruang model), terang di tengah memudar ke tepi. */
    private static void billboard(VertexConsumer vc, PoseStack.Pose pose, float x, float y, float z, float r, float a, Vector3f cam,
                                  int cr, int cg, int cb) {
        Vector3f n = new Vector3f(cam.x - x, cam.y - y, cam.z - z);
        if (n.lengthSquared() < 1.0E-6f) {
            return;
        }
        n.normalize();
        Vector3f u = Math.abs(n.y) < 0.95f ? new Vector3f(n).cross(0f, 1f, 0f).normalize() : new Vector3f(n).cross(1f, 0f, 0f).normalize();
        Vector3f v = new Vector3f(n).cross(u).normalize();
        int ab = (int) (Mth.clamp(a, 0f, 1f) * 255f);
        int rr = cr * ab / 255, gg = cg * ab / 255, bb = cb * ab / 255;
        int seg = 18;
        for (int i = 0; i < seg; i++) {
            float a0 = TWO_PI * i / seg, a1 = TWO_PI * (i + 1) / seg;
            float c0 = Mth.cos(a0) * r, s0 = Mth.sin(a0) * r, c1 = Mth.cos(a1) * r, s1 = Mth.sin(a1) * r;
            float px0 = x + u.x * c0 + v.x * s0, py0 = y + u.y * c0 + v.y * s0, pz0 = z + u.z * c0 + v.z * s0;
            float px1 = x + u.x * c1 + v.x * s1, py1 = y + u.y * c1 + v.y * s1, pz1 = z + u.z * c1 + v.z * s1;
            glowVertex(vc, pose, x, y, z, rr, gg, bb);
            glowVertex(vc, pose, x, y, z, rr, gg, bb);
            glowVertex(vc, pose, px1, py1, pz1, 0, 0, 0);
            glowVertex(vc, pose, px0, py0, pz0, 0, 0, 0);
            glowVertex(vc, pose, px0, py0, pz0, 0, 0, 0);
            glowVertex(vc, pose, px1, py1, pz1, 0, 0, 0);
            glowVertex(vc, pose, x, y, z, rr, gg, bb);
            glowVertex(vc, pose, x, y, z, rr, gg, bb);
        }
    }

    // ------------------------------------------------------------------ titik

    private static float[] sph(float theta, float phi) {
        float st = Mth.sin(theta);
        return new float[] {st * Mth.cos(phi), -Mth.cos(theta), st * Mth.sin(phi)};
    }

    /**
     * Warna menyala yang tetap berbayang lembut: terang dari atas (ruang model -y = atas), sedikit redup di bawah. Normal
     * yang dikirim ke shader juga dicondongkan ke atas (put), jadi cahaya dunia nggak bikin sisi bawahnya gelap pekat.
     */
    private static int tone(int rgb, float nx, float ny, float nz) {
        float l = Mth.clamp(0.78f + 0.3f * (-ny) + 0.08f * (-nz), 0.62f, 1.12f);
        int r = Math.min(255, (int) (((rgb >> 16) & 0xFF) * l)), g = Math.min(255, (int) (((rgb >> 8) & 0xFF) * l));
        int b = Math.min(255, (int) ((rgb & 0xFF) * l));
        return (r << 16) | (g << 8) | b;
    }

    private static void put(VertexConsumer vc, PoseStack.Pose pose, float x, float y, float z, int rgb, float nx, float ny, float nz) {
        float ux = nx * 0.45f, uy = ny * 0.45f - 0.9f, uz = nz * 0.45f;   // normal condong ke atas: shading lembut
        float l = Mth.sqrt(ux * ux + uy * uy + uz * uz);
        vc.addVertex(pose, x, y, z).setColor((rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF, 255).setUv(0.5f, 0.5f)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(LightTexture.FULL_BRIGHT).setNormal(pose, ux / l, uy / l, uz / l);
    }

    private static void glowVertex(VertexConsumer vc, PoseStack.Pose pose, float x, float y, float z, int r, int g, int b) {
        vc.addVertex(pose, x, y, z).setColor(r, g, b, 255).setUv(0.5f, 0.5f).setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(LightTexture.FULL_BRIGHT).setNormal(pose, 0f, 1f, 0f);
    }

    /** Campur warna kecil (tanpa ketergantungan ke mesin efek). */
    private static final class Draw2 {
        static int mix(int a, int b, float t) {
            t = Mth.clamp(t, 0f, 1f);
            int r = (int) (((a >> 16) & 0xFF) + ((((b >> 16) & 0xFF) - ((a >> 16) & 0xFF)) * t));
            int g = (int) (((a >> 8) & 0xFF) + ((((b >> 8) & 0xFF) - ((a >> 8) & 0xFF)) * t));
            int bl = (int) ((a & 0xFF) + (((b & 0xFF) - (a & 0xFF)) * t));
            return (r << 16) | (g << 8) | bl;
        }
    }
}
