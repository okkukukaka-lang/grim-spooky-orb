package com.shazammod;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

/**
 * 0.32 Penyatuan Bintang: jalan menjadi LINTANG, beda dari tiga juara lain.
 *
 * 1. Kalahkan Wither, tempa Kristal Bintang: Nether Star di tengah, glowstone di empat sisi, balok emas di empat sudut.
 * 2. Klik kanan kristalnya dalam wujud MANUSIA, di bawah MATAHARI (siang, langit terbuka, nggak hujan).
 * 3. Kristal terangkat ke langit, cahaya matahari mengumpul di sekelilingmu, lalu tiang cahaya menghunjam dari langit
 *    (RITE_STRIKE). Kristalnya menyatu dengan tubuhmu dan Lintang langsung terpilih. Ucapkan LINTANG untuk berubah.
 * Selama upacara badan dilindungi cahaya (nggak bisa dilukai), sama seperti ritual berubah.
 */
public final class LintangRite {
    private LintangRite() {}

    private static final Map<UUID, Long> RITES = new HashMap<>();
    /** Upacara dari perintah /shazam rite: boleh tanpa kristal & tanpa matahari (buat dites). */
    private static final Set<UUID> FORCED = new HashSet<>();

    public static boolean isAwakening(ServerPlayer player) {
        Long start = RITES.get(player.getUUID());
        return start != null && player.level().getGameTime() - start <= ShazamAnim.RITE_TICKS + 5;
    }

    public static void tryBegin(ServerPlayer player) {
        ShazamData data = ShazamPowers.data(player);
        String refusal = null;
        if (isAwakening(player)) {
            refusal = "message.shazammod.rite.already";
        } else if (data.lintangUnlocked()) {
            refusal = "message.shazammod.rite.already_yours";
        } else if (data.transformed()) {
            refusal = "message.shazammod.rite.human_only";
        } else if (KahndaqTrial.isRunning(player) || ShazamTotems.isAwakening(player) || SabbacPact.isAwakening(player)) {
            refusal = "message.shazammod.rite.busy";
        } else if (!PassiveConditions.underSun(player.level(), player.blockPosition())) {
            refusal = "message.shazammod.rite.need_sun";
        }
        if (refusal != null) {
            player.displayClientMessage(Component.translatable(refusal).withStyle(ChatFormatting.GOLD, ChatFormatting.ITALIC),
                    true);
            return;
        }
        begin(player, false);
    }

    public static void begin(ServerPlayer player, boolean forced) {
        if (isAwakening(player)) {
            return;
        }
        if (forced) {
            FORCED.add(player.getUUID());
        } else {
            FORCED.remove(player.getUUID());
        }
        if (ShazamPowers.isTransformed(player)) {
            ShazamPowers.revert(player, false);
        }
        ServerLevel level = player.serverLevel();
        RITES.put(player.getUUID(), level.getGameTime());
        ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_RITE);
        // paduan suara & lonceng yang naik, memuncak tepat saat tiang cahaya menghunjam (RITE_STRIKE)
        level.playSound(null, player.getX(), player.getY(), player.getZ(), ShazamSounds.LINTANG_RITE.get(), SoundSource.PLAYERS,
                1.6f, 1f);
        speak(player, "message.shazammod.rite.start");
        ShazamPowers.schedule(player, ShazamAnim.RITE_STRIKE / 2, p -> {
            if (RITES.containsKey(p.getUUID())) {
                speak(p, "message.shazammod.rite.voice");
            }
        });
        ShazamPowers.schedule(player, ShazamAnim.RITE_STRIKE, LintangRite::strike);
    }

    private static void speak(ServerPlayer player, String key) {
        player.sendSystemMessage(Component.translatable("speaker.shazammod.star").withStyle(ChatFormatting.GOLD,
                ChatFormatting.BOLD).append(Component.literal(" ")).append(Component.translatable(key)
                .withStyle(ChatFormatting.YELLOW, ChatFormatting.ITALIC)));
    }

    /** Tiang cahaya menghunjam: kristal menyatu, Lintang terbuka. Kristal baru dipakai di sini (dibuang di tengah: batal). */
    private static void strike(ServerPlayer player) {
        RITES.remove(player.getUUID());
        boolean forced = FORCED.remove(player.getUUID());
        if (ShazamPowers.data(player).lintangUnlocked()) {
            return;
        }
        Inventory inventory = player.getInventory();
        boolean consumed = forced;
        for (int i = 0; i < inventory.getContainerSize() && !consumed; i++) {
            ItemStack stack = inventory.getItem(i);
            if (!stack.isEmpty() && stack.is(LintangItems.STAR_CRYSTAL.get())) {
                stack.shrink(1);
                consumed = true;
            }
        }
        if (!consumed) {
            player.displayClientMessage(Component.translatable("message.shazammod.rite.no_crystal").withStyle(ChatFormatting.GRAY),
                    true);
            return;
        }
        ServerLevel level = player.serverLevel();
        Vec3 pos = player.position();
        ShazamPowers.spawnBolt(level, pos, 2.8f, ShazamForm.LINTANG.boltVariant());
        level.playSound(null, pos.x, pos.y, pos.z, ShazamSounds.SUN_STRIKE.get(), SoundSource.PLAYERS, 3.0f, 1f);
        speak(player, "message.shazammod.rite.sealed");
        ShazamPowers.unlockLintang(player);
    }

    public static void forget(UUID id) {
        RITES.remove(id);
        FORCED.remove(id);
    }

    public static void clear() {
        RITES.clear();
        FORCED.clear();
    }
}
