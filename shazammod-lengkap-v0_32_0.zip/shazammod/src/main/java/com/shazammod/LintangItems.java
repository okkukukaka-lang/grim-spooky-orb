package com.shazammod;

import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * 0.32 Barang-barang Lintang:
 * - Bijih Kelam & Pecahan Kelam: mineral ungu kehitaman yang menghisap cahaya, jauh di bawah tanah (lapisan deepslate).
 *   Kelemahan Lintang: di dekatnya cahayanya terkuras (lihat LintangSkills), dipukul yang memegangnya sakit sekali.
 * - Kristal Bintang: ditempa dari Nether Star, dipakai di bawah langit terbuka pada siang hari untuk Penyatuan Bintang
 *   (lihat LintangRite).
 * Resep di data/shazammod/recipe/, sebaran bijih di data/shazammod/worldgen/ & neoforge/biome_modifier/.
 */
@EventBusSubscriber(modid = ShazamMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public final class LintangItems {
    private LintangItems() {}

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(ShazamMod.MODID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(ShazamMod.MODID);

    /** Bijih Kelam: kristal ungu kehitaman di dalam deepslate. Nggak bercahaya: justru menghisap cahaya. */
    public static final DeferredBlock<Block> KELAM_ORE = BLOCKS.register("kelam_ore",
            () -> new DropExperienceBlock(UniformInt.of(3, 7), BlockBehaviour.Properties.of()
                    .mapColor(MapColor.DEEPSLATE)
                    .requiresCorrectToolForDrops()
                    .strength(4.5f, 3f)
                    .sound(SoundType.DEEPSLATE)));

    public static final DeferredItem<BlockItem> KELAM_ORE_ITEM = ITEMS.register("kelam_ore",
            () -> new BlockItem(KELAM_ORE.get(), new Item.Properties().rarity(Rarity.UNCOMMON)));

    public static final DeferredItem<LoreItem> KELAM_SHARD = ITEMS.register("kelam_shard",
            () -> new LoreItem(new Item.Properties().rarity(Rarity.UNCOMMON), "item.shazammod.kelam_shard",
                    ChatFormatting.DARK_PURPLE, false));

    public static final DeferredItem<StarCrystalItem> STAR_CRYSTAL = ITEMS.register("star_crystal",
            () -> new StarCrystalItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));

    @SubscribeEvent
    public static void addToCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
            event.accept(KELAM_ORE_ITEM.get());
        }
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            event.accept(KELAM_SHARD.get());
            event.accept(STAR_CRYSTAL.get());
        }
    }

    /** Barang biasa dengan keterangan (lore & petunjuk) di tooltip. */
    public static class LoreItem extends Item {
        private final String key;
        private final ChatFormatting color;
        private final boolean foil;

        public LoreItem(Properties properties, String key, ChatFormatting color, boolean foil) {
            super(properties);
            this.key = key;
            this.color = color;
            this.foil = foil;
        }

        @Override
        public boolean isFoil(ItemStack stack) {
            return foil;
        }

        @Override
        public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
            tooltip.add(Component.translatable(key + ".lore").withStyle(color, ChatFormatting.ITALIC));
            tooltip.add(Component.translatable(key + ".hint").withStyle(ChatFormatting.GRAY));
        }
    }

    /** Kristal Bintang: klik kanan dalam wujud manusia, di bawah matahari, untuk Penyatuan Bintang. */
    public static class StarCrystalItem extends LoreItem {
        public StarCrystalItem(Properties properties) {
            super(properties, "item.shazammod.star_crystal", ChatFormatting.GOLD, true);
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            if (player instanceof ServerPlayer serverPlayer) {
                LintangRite.tryBegin(serverPlayer);
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
        }
    }
}
