package com.shazammod.client.fx;

import com.shazammod.ShazamSounds;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.shazammod.MagicBolt;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamPowers;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Runes;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Efek tiap skill, dipicu oleh animasi yang dikirim server. Semuanya efek buatan sendiri (lihat client.vfx):
 * kilatan cahaya, gelombang kejut yang menempel di tanah, cangkang energi, petir bercabang, retakan tanah yang
 * membara, pecahan blok sungguhan, lingkaran rune, jejak cahaya, asap tebal, dan efek layar (garis kecepatan,
 * vinyet). Ditambah guncangan kamera dan kilatan layar. Jumlah butiran tiap skill dikali Vfx.DENSITY.
 */
public final class ShazamFx {
    private ShazamFx() {}

    // ======= Warna (RGB) =======
    public static final int GOLD = 0xFFC94A;
    public static final int GOLD_LIGHT = 0xFFE39C;
    public static final int WHITE_HOT = 0xFFF6E2;
    public static final int SOLOMON = 0xB48CFF;     // ungu (warna totem Solomon)
    public static final int HERCULES = 0xD8F7A8;    // putih kehijauan (Hercules)
    public static final int ATLAS = 0xFFA45C;       // jingga tanah (Atlas)
    public static final int ZEUS = 0xFFD45A;        // petir sihir emas
    public static final int STORM = 0xAEDCFF;       // putih kebiruan (Zeus Rage)
    public static final int ACHILLES = 0xFFD45E;
    public static final int MERCURY = 0x86F0FF;     // biru muda (Mercury)
    private static final Vec3 UP = new Vec3(0, 1, 0);

    @FunctionalInterface
    interface Step {
        void tick(ClientLevel level, int t);
    }

    private static final class Running {
        final int delay;
        final int duration;
        final Step step;
        int age;

        Running(int delay, int duration, Step step) {
            this.delay = delay;
            this.duration = duration;
            this.step = step;
        }
    }

    private static final List<Running> RUNNING = new ArrayList<>();
    private static final Map<Integer, Long> SIGHT = new HashMap<>();          // mata ungu Solomon: kapan mulai
    private static final Map<Integer, Fx.Trail[]> FLIGHT = new HashMap<>();   // jejak tangan saat terbang

    /** Jalankan step tiap tick selama duration tick, mulai delay tick lagi (t = 0, 1, 2, ...). Dipakai juga AdamFx. */
    static void schedule(int delay, int duration, Step step) {
        RUNNING.add(new Running(delay, duration, step));
    }

    public static void clear() {
        RUNNING.clear();
        SIGHT.clear();
        FLIGHT.clear();
        Vfx.clear();
        ScreenFx.clear();
    }

    public static void tick(ClientLevel level) {
        for (Running running : new ArrayList<>(RUNNING)) {
            int t = running.age - running.delay;
            if (t >= 0) {
                running.step.tick(level, t);
            }
            running.age++;
        }
        RUNNING.removeIf(running -> running.age - running.delay >= running.duration);
        long now = level.getGameTime();
        SIGHT.values().removeIf(start -> now - start > 80);
        Iterator<Map.Entry<Integer, Fx.Trail[]>> it = FLIGHT.entrySet().iterator();
        while (it.hasNext()) {
            Fx.Trail[] trails = it.next().getValue();
            boolean any = false;
            for (Fx.Trail trail : trails) {
                any |= trail.following();
            }
            if (!any) {
                it.remove();
            }
        }
        Vfx.tick(level);
    }

    /** 0-1: mata ungu menyala sesudah Mata Solomon. */
    public static float sightGlow(AbstractClientPlayer player, float partialTick) {
        Long start = SIGHT.get(player.getId());
        if (start == null) {
            return 0f;
        }
        float t = player.level().getGameTime() - start + partialTick - ShazamAnim.CAST_WINDUP;
        if (t < 0f) {
            return 0f;
        }
        return Math.min(1f, t / 3f) * Mth.clamp((70f - t) / 25f, 0f, 1f);
    }

    // ------------------------------------------------------------------ tiap animasi

    public static void onAnim(AbstractClientPlayer caster, ShazamAnim anim, Vec3 pos) {
        boolean self = caster == Minecraft.getInstance().player;
        if (LintangFx.handles(caster, anim)) {
            return;   // 0.32 Lintang: cahaya matahari & bintang, dan skill-nya diurus LintangFx
        }
        if (SabbacFx.handles(caster, anim)) {
            return;   // 0.30 Sabbac & Rival Juara: enam iblis, api & petir neraka, dan skill-nya diurus SabbacFx
        }
        if (AdamFx.handles(caster, anim)) {
            return;   // Black Adam: pemanggilan dewa Mesir, petir membara, dan skill-nya diurus AdamFx
        }
        ChampionFx.onAnim(caster, anim, pos, self);   // 0.23: avatar dewa, pasif, dan skill baru Shazam
        switch (anim) {
            case SUMMON -> summon(caster, self);
            case TRANSFORM -> transform(caster, self);
            case REVERT -> revert(caster, self);
            case KNOCKOUT -> knockout(caster, self);
            case SOLOMON_SIGHT -> solomon(caster, self);
            case HERCULES_CLAP -> hercules(caster, self);
            case ATLAS_GROUND -> atlasRaise(caster);
            case ATLAS_DIVE -> atlasDive(caster);
            case ATLAS_IMPACT -> schedule(0, 1, (level, t) -> {
                impact(level, caster, caster.position(), 2.3f, ATLAS, 0xFFC060, true);
                ringOfSparks(level, caster.position().add(0, 0.3, 0), 30, ATLAS, 0.45);
                shakeAround(caster.position(), 0.95f, 30);
                if (self) {
                    ScreenFlash.flash(0.35f, 0xFFD9A0);
                    ScreenFx.vignette(0.45f, 0x2A1200, 6);
                }
            });
            case ZEUS_CALL -> zeus(caster, pos, self);
            case ACHILLES_ROAR -> achilles(caster, self);
            case MERCURY_BLITZ -> mercury(caster, self);
            case ZEUS_RAGE -> rage(caster, self);
            case LAUNCH -> schedule(0, 1, (level, t) -> {
                Vec3 c = caster.position();
                Ground.Map map = ground(level, c, 3.0);
                if (map != null && map.found && c.y - map.centerY < 1.5) {
                    Vec3 g = map.center(c);
                    Vfx.add(new Fx.Wave(g, UP, 3.2, 0.3, light(caster), 12, 0.8f, 0.1f, map));
                    Vfx.add(new Fx.Wave(g, UP, 2.6, 0.9, map.dustColor(level, c), 20, 0.5f, 0f, map, true));
                    Vfx.add(new Ground.Cracks(g, map, 5, 1.3f, 90, 18, GOLD_LIGHT, level.random.nextLong()));
                    Vfx.add(new Ground.Debris(g, map, 6, 0.12, 0.35, 0.5, 40));
                    dustPuffs(level, g, map.dustColor(level, c), 12, 0.8, 0.12);
                    smokeCloud(level, g, map.dustColor(level, c), 3, 1.2);
                }
                Vfx.add(new Fx.Ripple(c.add(0, 0.2, 0), UP, 2.5, 0.5, 1.6, 0.25, WHITE_HOT, 9, 0.6f, false));
                shakeAround(c, 0.3f, 14);
            });
            case LAND_SOFT -> schedule(0, 1, (level, t) -> {
                Vec3 c = caster.position();
                Ground.Map map = ground(level, c, 2.0);
                if (map != null) {
                    Vfx.add(new Fx.Wave(map.center(c), UP, 1.8, 0.7, map.dustColor(level, c), 16, 0.45f, 0f, map, true));
                    dustPuffs(level, map.center(c), map.dustColor(level, c), 8, 0.6, 0.08);
                }
            });
            case LAND_HERO -> schedule(0, 1, (level, t) -> {
                impact(level, caster, caster.position(), 1.6f, glow(caster), light(caster), true);
                shakeAround(caster.position(), 0.9f, 30);
                if (self) {
                    ScreenFlash.flash(0.25f, 0xFFF0C8);
                }
            });
            case CRASH -> schedule(0, 1, (level, t) -> {
                Vec3 dir = caster.getViewVector(1f);
                Vec3 c = caster.position().add(0, 1.0, 0).add(dir.scale(0.8));
                Vfx.add(new Fx.Flash(c, 1.8f, GOLD_LIGHT, 8, 1f));
                Vfx.add(new Fx.Ripple(c, dir.scale(-1), 1.2, 0.4, 2.6, 0.35, WHITE_HOT, 10, 0.8f, false));
                for (int i = 0, n = Vfx.count(26); i < n; i++) {
                    Vec3 v = randomDir(level.random).add(dir.scale(-1.2)).normalize().scale(0.25 + level.random.nextDouble() * 0.35);
                    Vfx.spark(c.x, c.y, c.z, v.x, v.y, v.z, GOLD_LIGHT, 0.06f, 10 + level.random.nextInt(8), caster.getY());
                }
                Ground.Map map = ground(level, caster.position(), 2.5);
                if (map != null) {
                    Vfx.add(new Ground.Debris(map.center(caster.position()), map, 10, 0.2, 0.3, 0.6, 45));
                    dustPuffs(level, c, map.dustColor(level, c), 14, 0.9, 0.15);
                    smokeCloud(level, map.center(caster.position()), map.dustColor(level, c), 3, 0.7);
                }
                shakeAround(c, 0.8f, 24);
            });
            case SONIC_BOOM -> schedule(0, 1, (level, t) -> {
                Vec3 motion = new Vec3(caster.getX() - caster.xo, caster.getY() - caster.yo, caster.getZ() - caster.zo);
                Vec3 dir = motion.lengthSqr() < 1.0E-4 ? caster.getViewVector(1f) : motion.normalize();
                Vec3 c = caster.position().add(0, 0.9, 0);
                Vfx.add(new Fx.Flash(c, 2.2f, WHITE_HOT, 7, 0.9f));
                Vfx.add(new Fx.Cone(c.add(dir.scale(1.2)), dir.scale(-1), 4.5, 0.75, 0xEAF4FF, 12, 0.55f, 2.0, true));
                Vfx.add(new Fx.Ripple(c, dir.scale(-1), 2.5, 0.6, 4.2, 0.6, 0xF4FAFF, 14, 0.7f, true));
                Vfx.add(new Fx.Ripple(c, dir.scale(-1), 1.5, 0.4, 3.0, 0.25, GOLD_LIGHT, 10, 0.8f, false));
                shakeAround(caster.position(), 0.5f, 40);
                if (caster == Minecraft.getInstance().player) {
                    ScreenFx.speedLines(1f);
                    ScreenFlash.flash(0.18f, 0xFFFFFF);
                }
            });
            case ROLL_LEFT, ROLL_RIGHT -> schedule(0, 1, (level, t) -> {
                for (boolean right : new boolean[] {true, false}) {
                    Vfx.add(new Fx.Trail(caster, pt -> ShazamPoses.handPos(caster, right, pt), 0xF2F8FF, 0.14f, 8, 10, false));
                }
            });
            case MERCURY_ON -> {   // tenaga terkumpul, lalu (tick 6, saat badan menghentak) listrik meledak
                schedule(0, 6, (level, t) -> MercuryFx.charge(caster, t));
                schedule(6, 1, (level, t) -> MercuryFx.on(caster, self));
            }
            case MERCURY_OFF -> MercuryFx.off(caster);
            case MERCURY_JAB, MERCURY_CROSS, MERCURY_HOOK, MERCURY_KICK -> MercuryFx.strike(caster, pos, self);
            case HOOD_UP, HOOD_DOWN -> {
                // gesekan kain saat tangan memegang hood, lalu desir saat hood terpasang/terlepas
                boolean up = anim == ShazamAnim.HOOD_UP;
                schedule(ShazamAnim.HOOD_GRAB, 1, (level, t) -> level.playLocalSound(caster.getX(), caster.getEyeY(),
                        caster.getZ(), ShazamSounds.CAPE_SNAP.get(), SoundSource.PLAYERS, 0.9f, ShazamSounds.tune(up ? 1.15f : 0.95f), false));
                schedule(ShazamAnim.HOOD_GRAB + ShazamAnim.HOOD_MOVE - 2, 1, (level, t) -> level.playLocalSound(caster.getX(),
                        caster.getEyeY(), caster.getZ(), SoundEvents.WOOL_PLACE, SoundSource.PLAYERS, 0.5f, up ? 1.4f : 1.2f, false));
            }
            default -> { }
        }
    }

    // ------------------------------------------------------------------ transformasi

    /**
     * Memanggil enam dewa: lingkaran rune emas di tanah, cahaya naik dari lingkaran ke dada. Dewa-dewanya
     * sendiri (datang satu per satu) diurus ShazamSpirits.
     */
    private static void summon(AbstractClientPlayer caster, boolean self) {
        ShazamSpirits.start(caster);
        if (self) {
            ShazamCinematic.start();   // dari sudut pandang orang pertama: kamera pindah ke depan
            ScreenFx.cinema(ShazamAnim.SUMMON_TICKS + ShazamAnim.TRANSFORM_STRIKE + 30);   // pita film selama ritual
        }
        int total = ShazamAnim.SUMMON_TICKS + ShazamAnim.TRANSFORM_STRIKE;
        schedule(0, 1, (level, t) -> {
            Vec3 c = caster.position();
            Ground.Map map = ground(level, c, 3.2);
            double groundY = (map == null ? c.y : map.centerY) + 0.03;
            Vfx.add(new Runes.Circle(pt -> new Vec3(caster.getPosition(pt).x, groundY, caster.getPosition(pt).z), UP,
                    2.6 * caster.getScale(), GOLD, total + 8, 0.035f, 0.9f, null));
            level.playLocalSound(c.x, c.y, c.z, ShazamSounds.RESONANCE.get(), SoundSource.PLAYERS, 1.2f, ShazamSounds.tune(0.6f), false);
        });
        schedule(0, total, (level, t) -> {
            RandomSource r = level.random;
            double radius = 2.6 * caster.getScale();
            for (int i = 0, n = Vfx.count(2); i < n; i++) {   // cahaya mengalir dari lingkaran ke dada, berpilin
                double a = r.nextDouble() * Math.PI * 2.0;
                double x = caster.getX() + Math.cos(a) * radius, z = caster.getZ() + Math.sin(a) * radius;
                double tx = caster.getX() - x, tz = caster.getZ() - z;
                Vfx.mote(x, caster.getY() + 0.05, z, tx * 0.045 - tz * 0.03, 0.05 + r.nextDouble() * 0.03, tz * 0.045 + tx * 0.03,
                        GOLD_LIGHT, 0.09f, 22 + r.nextInt(8));
            }
            if (t % 3 == 0) {
                double a = t * 0.4;
                Vfx.glint(caster.getX() + Math.cos(a) * radius, caster.getY() + 0.1, caster.getZ() + Math.sin(a) * radius,
                        WHITE_HOT, 0.3f, 10);
            }
        });
    }

    private static void transform(AbstractClientPlayer caster, boolean self) {
        schedule(0, 1, (level, t) -> level.playLocalSound(caster.getX(), caster.getY(), caster.getZ(),
                ShazamSounds.THUNDER.get(), SoundSource.WEATHER, 0.8f, ShazamSounds.tune(slowPitch(level, 0.5f)), false));
        // 0-18: tenaga terkumpul: listrik dari tanah merambat ke kepalan yang terangkat
        schedule(0, ShazamAnim.TRANSFORM_STRIKE, (level, t) -> {
            if (t % 2 == 0) {
                RandomSource r = level.random;
                double a = r.nextDouble() * Math.PI * 2.0, d = 1.4 + r.nextDouble() * 1.2;
                Vec3 from = caster.position().add(Math.cos(a) * d, 0.05, Math.sin(a) * d);
                Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(from), pt -> ShazamPoses.handPos(caster, true, pt),
                        GOLD, 0.07f, 3, 1, 1, 0.22));
            }
            if (t == ShazamAnim.TRANSFORM_WINDUP - 2) {
                Vfx.add(new Fx.Glow(caster, pt -> ShazamPoses.handPos(caster, true, pt), 0.9f, GOLD_LIGHT,
                        ShazamAnim.BOLT_DESCENT + 4, ShazamAnim.BOLT_DESCENT + 2));
            }
            if (self && t % 2 == 0) {
                CameraShake.add(0.04f);
            }
            swirlDust(level, caster, t);
        });
        // 8-18: petir turun pelan; kepalan memanggilnya dengan busur listrik ke atas
        schedule(ShazamAnim.TRANSFORM_WINDUP, ShazamAnim.BOLT_DESCENT, (level, t) -> {
            Vec3 fist = caster.position().add(0, ShazamPowers.FIST_HEIGHT * caster.getScale(), 0);
            double remaining = 88.0 * (1.0 - Math.pow((t + 1) / (double) ShazamAnim.BOLT_DESCENT, 1.35));
            if (remaining < 26.0) {
                Vec3 tip = fist.add((level.random.nextDouble() - 0.5) * 0.8, Math.min(remaining, 9.0), (level.random.nextDouble() - 0.5) * 0.8);
                Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(fist), Lightning.Anchor.fixed(tip), GOLD_LIGHT, 0.06f, 2, 1, 1, 0.25));
            }
            if (self) {
                ScreenFx.vignette(0.25f + t * 0.03f, 0x1A1000, 2);
            }
        });
        // sinema: berkas cahaya dari langit turun mengiringi petir sihir
        schedule(ShazamAnim.TRANSFORM_WINDUP, 1, (level, t) -> CineFx.godRays(Lightning.Anchor.on(caster, 0, 0, 0), GOLD_LIGHT,
                26.0, 2.0, 9, 0.9f, ShazamAnim.BOLT_DESCENT + 26));
        // 18: petir sihir mengenai kepalan
        schedule(ShazamAnim.TRANSFORM_STRIKE, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vec3 fist = c.add(0, ShazamPowers.FIST_HEIGHT * caster.getScale(), 0);
            Vfx.add(new Fx.Flash(fist, 3.2f, WHITE_HOT, 12, 1f));
            Vfx.add(new Fx.Flash(c.add(0, 1.0, 0), 2.4f, GOLD, 14, 0.9f));
            Vfx.add(new Fx.Pillar(c, 60.0, 1.5f, GOLD, 16));
            Vfx.add(new Fx.Bubble(fist, 2.5, WHITE_HOT, 9, 0.9f, 1.0, 2.0, true));
            impact(level, caster, c, 2.6f, GOLD, GOLD_LIGHT, true, 0.35f);   // asap tipis: kostum yang terbentuk tetap kelihatan
            ringOfSparks(level, fist, 60, GOLD_LIGHT, 0.55);
            groundArcs(level, c, 7, 4.5, GOLD, 6);
            Vfx.add(new Lightning.Crackle(caster, GOLD_LIGHT, 1.6f, 0.05f, 30));
            shakeAround(c, 1.0f, 32);
            CineFx.flare(fist, 0xFFF4C8, 10f, 0.26f, 1f, 18);   // suar lensa anamorfik raksasa di kepalan
            if (self) {
                ScreenFlash.flash(1.0f, 0xFFF8E0);
                ScreenFx.titleKey("title.shazammod.shazam", 0xFFD84A, 60, 0);
            }
        });
        schedule(ShazamAnim.TRANSFORM_STRIKE + 25, 1, (level, t) -> {
            Vec3 c = caster.position();
            Ground.Map map = ground(level, c, 2.0);
            if (map != null) {
                Vfx.add(new Fx.Wave(map.center(c), UP, 2.2, 0.8, map.dustColor(level, c), 18, 0.45f, 0f, map, true));
            }
        });
    }

    private static void revert(AbstractClientPlayer caster, boolean self) {
        // cahaya terhisap ke dada, lalu meletup kecil
        schedule(0, ShazamAnim.REVERT_WINDUP, (level, t) -> {
            Vec3 chest = caster.position().add(0, 1.2 * caster.getScale(), 0);
            for (int i = 0, n = Vfx.count(4); i < n; i++) {
                Vec3 off = randomDir(level.random).scale(1.4 + level.random.nextDouble() * 0.6);
                Vfx.mote(chest.x + off.x, chest.y + off.y, chest.z + off.z, -off.x * 0.16, -off.y * 0.16, -off.z * 0.16,
                        GOLD_LIGHT, 0.08f, 7);
            }
        });
        schedule(ShazamAnim.REVERT_WINDUP, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vec3 chest = c.add(0, 1.2, 0);
            Vfx.add(new Fx.Flash(chest, 1.8f, GOLD_LIGHT, 9, 1f));
            Vfx.add(new Fx.Bubble(chest, 1.6, GOLD, 8, 0.7f, 1.0, 2.0, true));
            Ground.Map map = ground(level, c, 3.0);
            if (map != null) {
                Vfx.add(new Fx.Wave(map.center(c), UP, 3.0, 0.3, GOLD, 12, 0.7f, 0.1f, map));
                dustPuffs(level, map.center(c), map.dustColor(level, c), 10, 0.7, 0.1);
            }
            ringOfSparks(level, chest, 24, GOLD_LIGHT, 0.35);
            shakeAround(c, 0.35f, 16);
            if (self) {
                ScreenFlash.flash(0.55f, 0xFFF4D8);
            }
        });
    }

    /**
     * Terlempar balik jadi manusia karena serangan mematikan: kilatan saat pukulan masuk (pandanganmu menggelap
     * kemerahan), lalu (KNOCKOUT_BURST) kekuatan tercabut dari dada: semburan cahaya emas, busur-busur petir lepas
     * dari badan dan kembali ke langit, gelombang di tanah, dan percikan. Sesudahnya sisa butiran emas menguap.
     */
    private static void knockout(AbstractClientPlayer caster, boolean self) {
        schedule(0, 1, (level, t) -> {
            Vec3 chest = caster.position().add(0, 1.2 * caster.getScale(), 0);
            Vfx.add(new Fx.Flash(chest, 1.5f, 0xFFD8C8, 6, 1f));
            shakeAround(caster.position(), 0.6f, 20);
            if (self) {
                ScreenFx.vignette(0.7f, 0x3A0000, 14);
                CameraShake.add(0.45f);
            }
        });
        schedule(ShazamAnim.KNOCKOUT_BURST, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vec3 chest = c.add(0, 1.2 * caster.getScale(), 0);
            Vfx.add(new Fx.Flash(chest, 2.4f, GOLD_LIGHT, 10, 1f));
            Vfx.add(new Fx.Bubble(chest, 2.2, GOLD, 10, 0.75f, 1.0, 2.0, true));
            for (int k = 0; k < 4; k++) {   // petir lepas dari badan, kembali ke langit
                double a = Math.PI * 2.0 * (k + level.random.nextDouble() * 0.6) / 4.0;
                double r = 1.5 + level.random.nextDouble() * 2.0;
                Vec3 sky = c.add(Math.cos(a) * r, 7.0 + level.random.nextDouble() * 3.0, Math.sin(a) * r);
                Vfx.add(new Lightning.Arc(Lightning.Anchor.on(caster, 0, 1.2, 0), Lightning.Anchor.fixed(sky), ZEUS,
                        0.07f, 5 + k, 1, 1, 0.3));
            }
            Ground.Map map = ground(level, c, 3.5);
            if (map != null) {
                Vfx.add(new Fx.Wave(map.center(c), UP, 3.6, 0.35, GOLD, 14, 0.8f, 0.1f, map));
                Vfx.add(new Fx.Wave(map.center(c), UP, 2.8, 0.9, map.dustColor(level, c), 20, 0.5f, 0f, map, true));
                dustPuffs(level, map.center(c), map.dustColor(level, c), 12, 0.8, 0.12);
            }
            ringOfSparks(level, chest, 36, GOLD_LIGHT, 0.5);
            level.playLocalSound(c.x, c.y, c.z, ShazamSounds.POWER_DOWN.get(), SoundSource.PLAYERS, 1.2f, ShazamSounds.tune(0.6f), false);
            shakeAround(c, 0.45f, 18);
            if (self) {
                ScreenFlash.flash(0.6f, 0xFFF0C8);
            }
        });
        schedule(ShazamAnim.KNOCKOUT_BURST + 1, 16, (level, t) -> {
            if (t % 2 != 0) {
                return;
            }
            Vec3 c = caster.position();
            for (int i = 0, n = Vfx.count(3); i < n; i++) {
                double a = level.random.nextDouble() * Math.PI * 2.0, r = 0.25 + level.random.nextDouble() * 0.3;
                Vfx.mote(c.x + Math.cos(a) * r, c.y + 0.3 + level.random.nextDouble() * 1.5, c.z + Math.sin(a) * r,
                        Math.cos(a) * 0.02, 0.05 + level.random.nextDouble() * 0.04, Math.sin(a) * 0.02, GOLD_LIGHT,
                        0.07f, 12);
            }
        });
    }

    // ------------------------------------------------------------------ S - Mata Solomon

    private static void solomon(AbstractClientPlayer caster, boolean self) {
        SIGHT.put(caster.getId(), caster.level().getGameTime());
        // lingkaran rune kecil di depan wajah; huruf-huruf cahaya terhisap ke kepala
        schedule(0, 1, (level, t) -> {
            Vfx.add(new Runes.Circle(pt -> caster.getEyePosition(pt).add(caster.getViewVector(pt).scale(0.7)),
                    caster.getViewVector(1f), 0.42, SOLOMON, 18, 0.12f, 0.9f, null));
        });
        schedule(0, ShazamAnim.CAST_WINDUP, (level, t) -> {
            Vec3 head = caster.getEyePosition();
            for (int i = 0, n = Vfx.count(6); i < n; i++) {
                Vec3 off = randomDir(level.random).scale(2.0 + level.random.nextDouble());
                Vfx.mote(head.x + off.x, head.y + off.y, head.z + off.z, -off.x * 0.17, -off.y * 0.17, -off.z * 0.17,
                        i % 2 == 0 ? SOLOMON : GOLD_LIGHT, 0.07f, 6);
            }
        });
        // pemindaian: bola cahaya mengembang sampai 48 blok, menandai tiap musuh yang dilewatinya
        schedule(ShazamAnim.CAST_WINDUP, 1, (level, t) -> {
            Vec3 c = caster.position();
            int sweep = 26;
            Vfx.add(new Fx.Flash(caster.getEyePosition(), 1.2f, SOLOMON, 8, 0.9f));
            Vfx.add(new Fx.Bubble(c.add(0, 1.0, 0), 48.0, SOLOMON, sweep, 0.5f, 1.0, 3.5, true));
            Vfx.add(new Fx.Bubble(c.add(0, 1.0, 0), 48.0, SOLOMON, sweep, 0.1f, 1.0, 0.0, true));   // terlihat juga dari dalam
            Vfx.add(new Fx.Bubble(c.add(0, 1.0, 0), 6.0, GOLD_LIGHT, 10, 0.5f, 1.0, 2.5, true));
            Ground.Map map = ground(level, c, 3.5);
            if (map != null) {
                Vfx.add(new Runes.Circle(pt -> map.center(c), UP, 3.2, SOLOMON, 40, 0.05f, 0.85f, map));
                Vfx.add(new Fx.Wave(map.center(c), UP, 48.0, 1.5, SOLOMON, sweep, 0.6f, 0f, null));
            }
            AABB area = caster.getBoundingBox().inflate(48.0);
            for (LivingEntity enemy : level.getEntitiesOfClass(LivingEntity.class, area, m -> m.isAlive() && m instanceof Enemy)) {
                int delay = (int) (enemy.distanceTo(caster) / 48.0 * sweep);
                Vfx.add(new Runes.Reticle(enemy, SOLOMON, ShazamAnim.SOLOMON_TICKS, delay));
            }
            if (self) {
                ScreenFx.vignette(0.4f, 0x1C0A33, 10);
                CameraShake.add(0.12f);
            }
        });
    }

    // ------------------------------------------------------------------ H - Tepukan Hercules

    private static void hercules(AbstractClientPlayer caster, boolean self) {
        schedule(0, 1, (level, t) -> {
            for (boolean right : new boolean[] {true, false}) {
                Vfx.add(new Fx.Glow(caster, pt -> ShazamPoses.handPos(caster, right, pt), 0.55f, HERCULES,
                        ShazamAnim.CAST_WINDUP + 3, ShazamAnim.CAST_WINDUP));
            }
        });
        schedule(ShazamAnim.CAST_WINDUP, 1, (level, t) -> {
            Vec3 look = caster.getViewVector(1f);
            Vec3 flat = new Vec3(look.x, look.y * 0.35, look.z).normalize();
            Vec3 hands = caster.getEyePosition().add(look.scale(0.8)).subtract(0, 0.4, 0);
            Vfx.add(new Fx.Flash(hands, 1.7f, WHITE_HOT, 7, 1f));
            Vfx.add(new Fx.Bubble(hands, 1.1, WHITE_HOT, 5, 0.9f, 1.0, 1.6, true));
            Vfx.add(new Fx.Cone(hands, flat, 8.0, 0.85, 0xF0FFF0, 12, 0.5f, 2.2, false));
            Vfx.add(new Fx.Cone(hands, flat, 7.0, 0.8, 0xE8F2E6, 14, 0.4f, 1.6, true));
            for (int k = 0; k < 3; k++) {
                int delay = k;
                schedule(delay, 1, (lv, tt) -> Vfx.add(new Fx.Ripple(hands, flat, 7.5 - delay, 0.4, 3.4 - delay * 0.5, 0.3,
                        delay == 0 ? WHITE_HOT : HERCULES, 12, 0.85f - delay * 0.15f, false)));
            }
            // debu tersapu searah gelombang
            Ground.Map map = ground(level, caster.position(), 3.0);
            if (map != null) {
                int dust = map.dustColor(level, caster.position());
                for (int i = 0, n = Vfx.count(22); i < n; i++) {
                    double side = (level.random.nextDouble() - 0.5) * 1.4;
                    Vec3 dir = new Vec3(flat.x + flat.z * side, 0, flat.z - flat.x * side).normalize();
                    double d = 0.8 + level.random.nextDouble() * 2.0;
                    Vfx.dust(caster.getX() + dir.x * d, map.centerY + 0.2, caster.getZ() + dir.z * d, dir.x * 0.35, 0.02,
                            dir.z * 0.35, dust, 0.5f + level.random.nextFloat() * 0.4f, 18 + level.random.nextInt(10));
                }
            }
            for (int i = 0, n = Vfx.count(18); i < n; i++) {
                Vec3 v = flat.add(randomDir(level.random).scale(0.45)).normalize().scale(0.5 + level.random.nextDouble() * 0.4);
                Vfx.spark(hands.x, hands.y, hands.z, v.x, v.y, v.z, WHITE_HOT, 0.05f, 8 + level.random.nextInt(6), Double.NaN);
            }
            shakeAround(caster.position(), 0.5f, 18);
            if (self) {
                ScreenFx.speedLines(0.65f);
                FovKick.punch(-0.07f);
            }
        });
    }

    // ------------------------------------------------------------------ A - Hantaman Atlas

    private static void atlasRaise(AbstractClientPlayer caster) {
        schedule(0, 1, (level, t) -> {
            for (boolean right : new boolean[] {true, false}) {
                Vfx.add(new Fx.Glow(caster, pt -> ShazamPoses.handPos(caster, right, pt), 0.7f, ATLAS,
                        ShazamAnim.ATLAS_HOLD + 2, ShazamAnim.ATLAS_HOLD));
            }
        });
        schedule(0, ShazamAnim.ATLAS_HOLD, (level, t) -> swirlDust(level, caster, t));
    }

    private static void atlasDive(AbstractClientPlayer caster) {
        // menukik seperti meteor: jejak cahaya jingga, bara berhamburan, cahaya di kepalan
        Fx.Trail trail = new Fx.Trail(caster, pt -> caster.getPosition(pt).add(0, 1.0, 0), ATLAS, 1.2f, 9, 3, false);
        Vfx.add(trail);
        Vfx.add(new Fx.Glow(caster, pt -> ShazamPoses.handPos(caster, true, pt), 1.0f, GOLD_LIGHT, 60, 4));
        schedule(0, 60, (level, t) -> {
            if (ShazamPoses.currentAnim(caster) != ShazamAnim.ATLAS_DIVE) {
                return;
            }
            trail.sustain(3);
            Vec3 c = caster.position().add(0, 0.9, 0);
            for (int i = 0, n = Vfx.count(3); i < n; i++) {
                Vfx.ember(c.x + (level.random.nextDouble() - 0.5) * 0.6, c.y + (level.random.nextDouble() - 0.5) * 1.2,
                        c.z + (level.random.nextDouble() - 0.5) * 0.6, 0, 0.05, 0, 0.09f, 14 + level.random.nextInt(8));
            }
            // asap meteor yang tertinggal di belakang
            Vfx.smoke(c.x + (level.random.nextDouble() - 0.5) * 0.4, c.y + (level.random.nextDouble() - 0.5) * 0.6,
                    c.z + (level.random.nextDouble() - 0.5) * 0.4, 0, 0.01, 0, 0x5C4838, 0.3f + level.random.nextFloat() * 0.15f,
                    26 + level.random.nextInt(10));
        });
    }

    // ------------------------------------------------------------------ Z - Petir Zeus

    private static void zeus(AbstractClientPlayer caster, Vec3 target, boolean self) {
        // tangan menggapai langit: listrik berkumpul di tangan, busur ke langit
        schedule(0, ShazamAnim.CAST_WINDUP + 1, (level, t) -> {
            Lightning.Anchor hand = pt -> ShazamPoses.handPos(caster, true, pt);
            for (int i = 0; i < 2; i++) {
                Vec3 off = randomDir(level.random).scale(0.5 + level.random.nextDouble() * 0.5);
                Vfx.add(new Lightning.Arc(hand, pt -> hand.at(pt).add(off), ZEUS, 0.045f, 2, 1, 0, 0.3));
            }
            if (t >= 2) {
                Vfx.add(new Lightning.Arc(hand, pt -> hand.at(pt).add(0, 9, 0), GOLD_LIGHT, 0.07f, 2, 1, 1, 0.2));
            }
            if (t == 0) {
                Vfx.add(new Fx.Glow(caster, hand, 0.8f, GOLD_LIGHT, ShazamAnim.CAST_WINDUP + 8, ShazamAnim.CAST_WINDUP));
            }
        });
        // langit di atas sasaran berkilat sesaat sebelum petir
        schedule(ShazamAnim.CAST_WINDUP - 1, 1, (level, t) ->
                Vfx.add(new Fx.Flash(target.add(0, 22, 0), 9f, GOLD_LIGHT, 8, 0.35f)));
        // menunjuk sasaran: busur tipis dari tangan ke sasaran, sisa listrik di tangan
        schedule(ShazamAnim.CAST_WINDUP, 1, (level, t) -> Vfx.add(new Lightning.Arc(
                pt -> ShazamPoses.handPos(caster, true, pt), Lightning.Anchor.fixed(target.add(0, 0.5, 0)),
                GOLD_LIGHT, 0.05f, 4, 1, 2, 0.12)));
        schedule(ShazamAnim.CAST_WINDUP, 8, (level, t) -> {
            if (t % 2 == 0) {
                Lightning.Anchor hand = pt -> ShazamPoses.handPos(caster, true, pt);
                Vec3 off = randomDir(level.random).scale(0.4);
                Vfx.add(new Lightning.Arc(hand, pt -> hand.at(pt).add(off), ZEUS, 0.035f, 2, 1, 0, 0.3));
            }
            if (t == 0) {
                shakeAround(target, 0.35f, 14);
            }
        });
    }

    /** Petir sihir menyambar tanah (dipanggil sekali per petir di client). Petir transformasi diurus sendiri. */
    public static void boltStrike(MagicBolt bolt) {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null || bolt.descent() > 0) {
            return;
        }
        float size = bolt.boltSize();
        Vec3 p = bolt.position();
        Ground.Map map = ground(level, p, 1.5 + size * 2.0);
        if (map == null) {
            return;
        }
        Vec3 g = map.center(p);
        if (bolt.variant() == 2) {   // 0.30 petir neraka Sabbac: menyembur dari tanah, api & magma
            SabbacFx.hellStrike(level, g, map, size);
            return;
        }
        if (bolt.variant() == 3) {   // 0.32 tiang cahaya Lintang
            LintangFx.sunStrike(level, g, map, size);
            return;
        }
        boolean adam = bolt.variant() == 1;   // petir Black Adam: emas-jingga membara, jelaga hitam lebih pekat
        int glow = adam ? AdamFx.AMBER : ZEUS, light = adam ? AdamFx.AMBER_LIGHT : GOLD_LIGHT;
        Vfx.add(new Fx.Flash(g.add(0, 0.8, 0), 1.0f + size * 1.5f, WHITE_HOT, 8, 1f));
        Vfx.add(new Fx.Wave(g, UP, 1.4 + size * 2.0, 0.3, glow, 12, 0.85f, 0.15f, map));
        Vfx.add(new Fx.Bubble(g, 0.9 + size, light, 7, 0.6f, 0.5, 2.0, true));
        Vfx.add(new Fx.Scorch(g, 0.35 + size * 0.4, 110, 16, map));
        if (size >= 0.75f) {
            Vfx.add(new Ground.Cracks(g, map, 4 + (int) (size * 2.5f), 0.8f + size, 110, 26, light, level.random.nextLong()));
        }
        groundArcs(level, g, 2 + (int) (size * 2f), 1.2 + size * 1.2, glow, 5);
        ringOfSparks(level, g.add(0, 0.3, 0), (int) (8 + 14 * size), light, 0.3 + size * 0.1);
        if (adam) {
            smokeCloud(level, g, 0x1E1A18, 2 + (int) (size * 2), 0.4 + size * 0.3);
        }
        for (int i = 0, n = Vfx.count(4 + size * 5); i < n; i++) {
            Vfx.ember(g.x + (level.random.nextDouble() - 0.5) * size, g.y + 0.1, g.z + (level.random.nextDouble() - 0.5) * size,
                    0, 0.04, 0, 0.07f, 20 + level.random.nextInt(14));
        }
        smokeCloud(level, g, 0x4A443E, 2 + (int) (size * 2), 0.35 + size * 0.3);   // jelaga dari tanah yang hangus
        shakeAround(g, 0.25f * size, 26);
    }

    // ------------------------------------------------------------------ A - Kulit Achilles

    private static void achilles(AbstractClientPlayer caster, boolean self) {
        // membungkuk mengumpulkan tenaga: cahaya emas terhisap ke badan
        schedule(0, ShazamAnim.ROAR_WINDUP, (level, t) -> {
            Vec3 chest = caster.position().add(0, 1.1, 0);
            for (int i = 0, n = Vfx.count(7); i < n; i++) {
                Vec3 off = randomDir(level.random).scale(1.8 + level.random.nextDouble() * 0.8);
                Vfx.mote(chest.x + off.x, chest.y + off.y * 0.7, chest.z + off.z, -off.x * 0.2, -off.y * 0.14, -off.z * 0.2,
                        ACHILLES, 0.08f, 5);
            }
            swirlDust(level, caster, t);
        });
        schedule(ShazamAnim.ROAR_WINDUP, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vec3 chest = c.add(0, 1.2, 0);
            Vfx.add(new Fx.Flash(chest, 2.6f, GOLD_LIGHT, 10, 1f));
            Vfx.add(new Fx.Bubble(c, 6.2, ACHILLES, 14, 0.8f, 0.5, 2.4, true));
            Ground.Map map = ground(level, c, 3.0);
            if (map != null) {
                Vfx.add(new Fx.Wave(map.center(c), UP, 6.5, 0.4, ACHILLES, 14, 0.9f, 0.1f, map));
                Vfx.add(new Fx.Wave(map.center(c), UP, 5.0, 1.0, map.dustColor(level, c), 20, 0.5f, 0f, map, true));
            }
            // raungan: gelombang suara keluar dari mulut
            Vec3 look = caster.getViewVector(1f);
            for (int k = 0; k < 3; k++) {
                int delay = k * 2;
                schedule(delay, 1, (lv, tt) -> Vfx.add(new Fx.Ripple(caster.getEyePosition().add(look.scale(0.4)), look,
                        4.0, 0.3, 1.8, 0.18, GOLD_LIGHT, 12, 0.7f, false)));
            }
            ringOfSparks(level, chest, 30, ACHILLES, 0.45);
            Vfx.add(new Fx.Aura(caster, ACHILLES, ShazamAnim.ACHILLES_TICKS + 12,
                    () -> ShazamPoses.auraStrength(caster, 0f)));
            shakeAround(c, 0.4f, 18);
            if (self) {
                ScreenFx.vignette(0.5f, 0x2E1C00, 8);
                ScreenFlash.flash(0.22f, 0xFFE6A0);
            }
        });
    }

    // ------------------------------------------------------------------ M - Kilat Mercury

    private static void mercury(AbstractClientPlayer caster, boolean self) {
        if (self) {
            FovKick.kick(0.22f);
            ScreenFx.speedLines(1f);
        }
        Vec3 start = caster.position().add(0, 1.0, 0);
        Vec3 look = caster.getViewVector(1f);
        Vfx.add(new Fx.Flash(start, 1.3f, MERCURY, 6, 0.9f));
        Vfx.add(new Fx.Ripple(start, look, 0.8, 0.5, 2.2, 0.2, MERCURY, 9, 0.8f, false));
        Vfx.add(new Fx.Trail(caster, pt -> caster.getPosition(pt).add(0, 1.0, 0), MERCURY, 1.1f, 8,
                ShazamAnim.BLITZ_TICKS + 1, true));
        for (boolean right : new boolean[] {true, false}) {
            Vfx.add(new Fx.Trail(caster, pt -> ShazamPoses.handPos(caster, right, pt), 0xE8FCFF, 0.16f, 7,
                    ShazamAnim.BLITZ_TICKS + 1, false));
        }
        schedule(0, ShazamAnim.BLITZ_TICKS + 2, (level, t) -> {
            Vec3 motion = new Vec3(caster.getX() - caster.xo, caster.getY() - caster.yo, caster.getZ() - caster.zo);
            Vec3 c = caster.position().add(0, 1.0, 0);
            for (int i = 0, n = Vfx.count(4); i < n; i++) {
                Vec3 v = motion.scale(-0.15).add(randomDir(level.random).scale(0.08));
                Vfx.spark(c.x + (level.random.nextDouble() - 0.5) * 0.5, c.y + (level.random.nextDouble() - 0.5) * 1.2,
                        c.z + (level.random.nextDouble() - 0.5) * 0.5, v.x, v.y, v.z, i % 2 == 0 ? MERCURY : GOLD_LIGHT,
                        0.05f, 7 + level.random.nextInt(5), caster.getY());
            }
            if (t == ShazamAnim.BLITZ_TICKS && caster.onGround()) {   // berhenti: tergelincir, debu & percikan
                Ground.Map map = ground(level, caster.position(), 2.0);
                if (map != null) {
                    dustPuffs(level, map.center(caster.position()), map.dustColor(level, caster.position()), 12, 0.6, 0.12);
                }
            }
        });
    }

    // ------------------------------------------------------------------ Zeus Rage

    private static void rage(AbstractClientPlayer caster, boolean self) {
        // listrik dari segala arah tertarik ke badan
        schedule(0, ShazamAnim.RAGE_WINDUP, (level, t) -> {
            for (int i = 0; i < 2; i++) {
                Vec3 off = randomDir(level.random).scale(2.4 + level.random.nextDouble() * 1.2);
                Vec3 from = caster.position().add(off.x, 1.1 + Math.abs(off.y) * 0.5, off.z);
                Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(from), Lightning.Anchor.on(caster, 0, 1.1, 0), STORM,
                        0.06f, 2, 1, 1, 0.25));
            }
            swirlDust(level, caster, t);
            if (self) {
                ScreenFx.vignette(0.3f + t * 0.03f, 0x06142A, 3);
                CameraShake.add(0.03f);
            }
        });
        schedule(ShazamAnim.RAGE_WINDUP, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vfx.add(new Fx.Flash(c.add(0, 1.3, 0), 3.0f, 0xF2FAFF, 10, 1f));
            impact(level, caster, c, 2.0f, STORM, 0xCFEFFF, true);
            ringOfSparks(level, c.add(0, 1.2, 0), 40, STORM, 0.5);
            groundArcs(level, c, 6, 4.0, STORM, 6);
            if (self) {
                ScreenFlash.flash(0.55f, 0xE8F4FF);
                ScreenFx.speedLines(0.5f);
                CameraShake.add(0.35f);
            }
        });
    }

    // ------------------------------------------------------------------ jejak terbang

    /** Jejak terbang (dipanggil tiap tick saat meluncur): uap tipis dari kedua tangan, pita emas saat super cepat. */
    public static void flightTrail(AbstractClientPlayer player, float speed, float boost) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null || speed < 0.8f) {
            return;
        }
        Fx.Trail[] trails = FLIGHT.get(player.getId());
        boolean sabbac = ShazamClientState.isSabbac(player.getId());
        int vapor = sabbac ? 0xFF9A60 : 0xF4F8FF;   // 0.30 Sabbac: jejak bara, bukan uap
        if (trails == null || !trails[0].following()) {
            trails = new Fx.Trail[] {
                    new Fx.Trail(player, pt -> ShazamPoses.handPos(player, true, pt), vapor, 0.1f, 12, 4, false),
                    new Fx.Trail(player, pt -> ShazamPoses.handPos(player, false, pt), vapor, 0.1f, 12, 4, false),
                    new Fx.Trail(player, pt -> player.getPosition(pt).add(0, 0.9, 0), glow(player), 0.8f, 10, 4, true)};
            Vfx.add(trails[0]);
            Vfx.add(trails[1]);
            FLIGHT.put(player.getId(), trails);
        }
        trails[0].sustain(3);
        trails[1].sustain(3);
        if (sabbac) {   // 0.30 Sabbac: bara & asap hitam berhamburan di belakang lintasan
            SabbacFx.flightEmbers(level, player, speed);
        }
        if (ShazamClientState.isLintang(player.getId())) {   // 0.32 Lintang: kilau bintang tertinggal di belakang
            LintangFx.flightGlints(level, player, speed);
        }
        if (ShazamClientState.isAdam(player.getId()) && speed > 1.2f && level.random.nextInt(3) == 0) {
            // Black Adam: petir membara memercik ke belakang lintasan
            Vec3 motion = new Vec3(player.getX() - player.xo, player.getY() - player.yo, player.getZ() - player.zo);
            if (motion.lengthSqr() > 1.0E-4) {
                Vec3 c = player.position().add(0, 0.9, 0);
                Vec3 back = c.subtract(motion.normalize().scale(1.8 + level.random.nextDouble() * 1.5))
                        .add(randomDir(level.random).scale(0.8));
                Vfx.add(new Lightning.Arc(Lightning.Anchor.on(player, 0, 0.9, 0), Lightning.Anchor.fixed(back), AdamFx.AMBER_LIGHT,
                        0.06f, 3, 1, 1, 0.3));
            }
        }
        if (boost > 0.3f) {
            if (!trails[2].following()) {
                trails[2] = new Fx.Trail(player, pt -> player.getPosition(pt).add(0, 0.9, 0), glow(player), 0.8f, 10, 4, true);
                Vfx.add(trails[2]);
            }
            trails[2].sustain(3);
            if (level.random.nextInt(2) == 0) {
                Vec3 c = player.position().add(0, 0.9, 0);
                Vfx.glint(c.x + (level.random.nextDouble() - 0.5) * 0.8, c.y + (level.random.nextDouble() - 0.5) * 0.8,
                        c.z + (level.random.nextDouble() - 0.5) * 0.8, GOLD_LIGHT, 0.25f, 8);
            }
        }
    }

    // ------------------------------------------------------------------ alat bantu

    /** Warna energi juara: emas Shazam atau emas-jingga membara Black Adam (terbang, mendarat, lepas landas). */
    static int glow(AbstractClientPlayer player) {
        if (ShazamClientState.isLintang(player.getId())) {
            return LintangFx.SUN;
        }
        if (ShazamClientState.isSabbac(player.getId())) {
            return SabbacFx.HELL;
        }
        return ShazamClientState.isAdam(player.getId()) ? AdamFx.AMBER : GOLD;
    }

    static int light(AbstractClientPlayer player) {
        if (ShazamClientState.isLintang(player.getId())) {
            return LintangFx.SUN_HOT;
        }
        if (ShazamClientState.isSabbac(player.getId())) {
            return SabbacFx.HELL_LIGHT;
        }
        return ShazamClientState.isAdam(player.getId()) ? AdamFx.AMBER_LIGHT : GOLD_LIGHT;
    }

    /** Nada suara ikut turun saat dunia diperlambat (slow motion transformasi). */
    static float slowPitch(ClientLevel level, float pitch) {
        float rate = level.tickRateManager().tickrate();
        return pitch * Mth.clamp((float) Math.sqrt(rate / 20f), 0.5f, 1f);
    }

    static Ground.Map ground(ClientLevel level, Vec3 p, double radius) {
        LocalPlayer viewer = Minecraft.getInstance().player;
        if (viewer == null) {
            return null;
        }
        return Ground.Map.sample(level, viewer, p, radius, 24, 6);
    }

    static Vec3 randomDir(RandomSource random) {
        double a = random.nextDouble() * Math.PI * 2.0, z = random.nextDouble() * 2.0 - 1.0;
        double r = Math.sqrt(1.0 - z * z);
        return new Vec3(Math.cos(a) * r, z, Math.sin(a) * r);
    }

    /**
     * Hantaman besar ke tanah: kilatan, kubah energi, cincin gelombang di tanah, cincin debu, retakan membara,
     * bekas hangus, pecahan blok yang terlempar, debu, dan bara. size kira-kira 0,5 (kecil) - 3 (besar).
     */
    static void impact(ClientLevel level, AbstractClientPlayer caster, Vec3 at, float size, int glow, int hot,
                               boolean debris) {
        impact(level, caster, at, size, glow, hot, debris, 1f);
    }

    /** Sama, dengan banyaknya asap (1 = biasa, 0 = tanpa asap). */
    static void impact(ClientLevel level, AbstractClientPlayer caster, Vec3 at, float size, int glow, int hot,
                       boolean debris, float smoke) {
        Ground.Map map = ground(level, at, 2.5 + size * 2.2);
        if (map == null) {
            return;
        }
        Vec3 g = map.center(at);
        int dust = map.dustColor(level, at);
        Vfx.add(new Fx.Flash(g.add(0, 0.6, 0), 1.3f + size, glow, 9, 1f));
        Vfx.add(new Fx.Bubble(g, 1.8 + size * 1.8, glow, 12, 0.85f, 0.5, 2.2, true));
        Vfx.add(new Fx.Wave(g, UP, 2.4 + size * 2.4, 0.35 + size * 0.12, glow, 14, 0.9f, 0.12f, map));
        Vfx.add(new Fx.Wave(g, UP, 1.6 + size * 1.6, 0.25, WHITE_HOT, 10, 0.7f, 0f, map));
        Vfx.add(new Fx.Wave(g, UP, 2.0 + size * 2.0, 0.9 + size * 0.3, dust, 24, 0.55f, 0f, map, true));
        if (map.found) {
            Vfx.add(new Ground.Cracks(g, map, 6 + (int) (size * 3f), 1.2f + size * 1.2f, 150, 30 + (int) (size * 15f), hot,
                    level.random.nextLong()));
            Vfx.add(new Fx.Scorch(g, 0.5 + size * 0.45, 140, 18, map));
            if (debris) {
                Vfx.add(new Ground.Debris(g, map, 6 + (int) (size * 6f), 0.12 + size * 0.08, 0.3 + size * 0.12,
                        0.5 + size * 0.3, 50));
            }
        }
        dustPuffs(level, g, dust, (int) (8 + size * 8), 0.6 + size * 0.5, 0.1 + size * 0.05);
        smokeCloud(level, g, dust, Math.round((4 + size * 4) * smoke), 0.7 + size * 0.7);
        for (int i = 0, n = Vfx.count(6 + size * 6); i < n; i++) {
            double a = level.random.nextDouble() * Math.PI * 2.0, r = level.random.nextDouble() * (1.0 + size);
            Vfx.ember(g.x + Math.cos(a) * r, g.y + 0.1, g.z + Math.sin(a) * r, 0, 0.03 + level.random.nextDouble() * 0.04, 0,
                    0.08f, 20 + level.random.nextInt(16));
        }
    }

    /** Debu yang mengepul melingkar dari titik (warna tanah). */
    static void dustPuffs(ClientLevel level, Vec3 c, int rgb, int count, double radius, double speed) {
        for (int i = 0, n = Vfx.count(count); i < n; i++) {
            double a = level.random.nextDouble() * Math.PI * 2.0;
            double r = radius * (0.5 + level.random.nextDouble() * 0.6);
            double v = speed * (0.6 + level.random.nextDouble() * 0.7);
            Vfx.dust(c.x + Math.cos(a) * r, c.y + 0.15 + level.random.nextDouble() * 0.3, c.z + Math.sin(a) * r,
                    Math.cos(a) * v, 0.02 + level.random.nextDouble() * 0.03, Math.sin(a) * v, rgb,
                    0.45f + level.random.nextFloat() * 0.5f, 22 + level.random.nextInt(14));
        }
    }

    /**
     * Asap tebal yang mengepul dari titik hantaman: menyebar rendah, mengembang, naik pelan, lalu menipis seperti
     * debu dan asap sungguhan. Gelombang kejut menyapu debu ke luar, jadi bagian tengah (tempat pemain berdiri)
     * tetap bersih. rgb = warna tanah (asapnya dibuat sedikit lebih gelap).
     */
    static void smokeCloud(ClientLevel level, Vec3 c, int rgb, int count, double radius) {
        int smoke = Draw.mix(rgb, 0x4A4540, 0.3);
        RandomSource r = level.random;
        for (int i = 0, n = Vfx.count(count); i < n; i++) {
            double a = r.nextDouble() * Math.PI * 2.0, d = radius * (0.45 + r.nextDouble() * 0.55);
            double out = 0.035 + r.nextDouble() * 0.05;
            Vfx.smoke(c.x + Math.cos(a) * d, c.y + 0.25 + r.nextDouble() * 0.5, c.z + Math.sin(a) * d,
                    Math.cos(a) * out, 0.015 + r.nextDouble() * 0.03, Math.sin(a) * out, smoke,
                    0.55f + r.nextFloat() * 0.5f, 45 + r.nextInt(35));
        }
    }

    /** Percikan memancar ke segala arah, jatuh dan memantul di tanah. */
    static void ringOfSparks(ClientLevel level, Vec3 c, int count, int rgb, double speed) {
        double floor = c.y - 3.0;
        for (int i = 0, n = Vfx.count(count); i < n; i++) {
            Vec3 v = randomDir(level.random);
            v = new Vec3(v.x, Math.abs(v.y) * 0.8 + 0.1, v.z).normalize().scale(speed * (0.5 + level.random.nextDouble() * 0.8));
            Vfx.spark(c.x, c.y, c.z, v.x, v.y, v.z, i % 3 == 0 ? WHITE_HOT : rgb, 0.05f + level.random.nextFloat() * 0.03f,
                    10 + level.random.nextInt(12), floor);
        }
    }

    /** Busur listrik yang merayap di tanah dari pusat ke luar. */
    static void groundArcs(ClientLevel level, Vec3 c, int count, double reach, int rgb, int life) {
        Ground.Map map = ground(level, c, reach);
        if (map == null) {
            return;
        }
        Vec3 g = map.center(c);
        for (int k = 0; k < count; k++) {
            double a = Math.PI * 2.0 * (k + level.random.nextDouble() * 0.7) / count;
            double r = reach * (0.6 + level.random.nextDouble() * 0.4);
            Vec3 end = new Vec3(g.x + Math.cos(a) * r, map.centerY + map.at(a, r) + 0.05, g.z + Math.sin(a) * r);
            Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(g.add(0, 0.08, 0)), Lightning.Anchor.fixed(end), rgb, 0.06f,
                    life, 1, 1, 0.22));
        }
    }

    /** Debu berpusar di kaki saat mengumpulkan tenaga. */
    static void swirlDust(ClientLevel level, AbstractClientPlayer p, int t) {
        if (t % 2 != 0 || !p.onGround()) {
            return;
        }
        double a = level.random.nextDouble() * Math.PI * 2.0, r = 1.4 + level.random.nextDouble() * 0.6;
        Vfx.dust(p.getX() + Math.cos(a) * r, p.getY() + 0.1, p.getZ() + Math.sin(a) * r,
                -Math.sin(a) * 0.12 - Math.cos(a) * 0.03, 0.01, Math.cos(a) * 0.12 - Math.sin(a) * 0.03, 0xA89A86,
                0.5f, 16);
    }

    static void shakeAround(Vec3 c, float amount, double radius) {
        LocalPlayer me = Minecraft.getInstance().player;
        if (me == null) {
            return;
        }
        double distance = me.position().distanceTo(c);
        if (distance < radius) {
            CameraShake.add(amount * (float) (1.0 - distance / radius));
        }
    }
}
