package com.shazammod.client.fx;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.shazammod.LintangSkills;
import com.shazammod.PassiveConditions;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamSounds;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * 0.32 Efek Lintang, juara bintang: cahaya matahari putih-keemasan yang kontras dengan biru toska tua kostumnya, cahaya
 * bintang biru pucat di malam hari, embun beku untuk napas salju, dan ungu kehitaman saat Batu Kelam menghisap cahayanya.
 * Pemanggilan bukan dewa: cahaya langit turun bergelombang dan terhisap ke dada, lalu tiang cahaya menghunjam
 * (MagicBolt varian 3, lihat BoltVisual). Semua dipicu animasi dari server (ShazamAnim.LINTANG_*).
 */
public final class LintangFx {
    private LintangFx() {}

    // ======= Warna (RGB) =======
    public static final int SUN = 0xFFD878;          // cahaya matahari keemasan
    public static final int SUN_HOT = 0xFFF6DC;      // inti putih menyilaukan
    public static final int AMBER = 0xFFA640;        // pinggir sinar panas
    public static final int STAR = 0xBFE4FF;         // cahaya bintang (malam)
    public static final int FROST = 0xCFF4FF;        // embun beku
    public static final int FROST_DEEP = 0x7FD0FF;
    public static final int KELAM = 0x8A3CC8;        // Batu Kelam: ungu
    public static final int KELAM_DARK = 0x1C0A2A;
    private static final Vec3 UP = new Vec3(0, 1, 0);

    private static final Map<Integer, long[]> EYES = new HashMap<>();        // Iris Surya: {mulai, selesai}
    private static final Map<Integer, Boolean> KELAM_SEEN = new HashMap<>(); // Batu Kelam dekat pemain lain (perkiraan)

    public static void clear() {
        EYES.clear();
        KELAM_SEEN.clear();
    }

    /** Animasi ini diurus LintangFx (ShazamFx & ChampionFx melewatinya). */
    public static boolean handles(AbstractClientPlayer caster, ShazamAnim anim) {
        return switch (anim) {
            case SUMMON, TRANSFORM, REVERT, KNOCKOUT, LAUNCH, LAND_HERO, CRASH, SONIC_BOOM, HERO_CALL ->
                    ShazamClientState.isLintang(caster.getId());
            default -> anim.name().startsWith("LINTANG_");
        };
    }

    public static void onAnim(AbstractClientPlayer caster, ShazamAnim anim, Vec3 pos) {
        if (!handles(caster, anim)) {
            return;
        }
        boolean self = caster == Minecraft.getInstance().player;
        switch (anim) {
            case SUMMON -> summon(caster, self);
            case TRANSFORM -> transform(caster, self);
            case REVERT -> revert(caster, self, false);
            case KNOCKOUT -> revert(caster, self, true);
            case LAUNCH -> launch(caster);
            case LAND_HERO -> landing(caster, self, false);
            case CRASH -> landing(caster, self, true);
            case SONIC_BOOM -> sonicBoom(caster, self);
            case HERO_CALL -> lance(caster, pos);
            case LINTANG_DASH -> dash(caster, pos, self);
            case LINTANG_EYES -> eyes(caster, self);
            case LINTANG_BREATH -> breath(caster, self);
            case LINTANG_CLAP -> clap(caster, self);
            case LINTANG_BARRAGE -> barrage(caster, self);
            case LINTANG_HIT -> hit(caster, pos);
            case LINTANG_LEAP -> leap(caster);
            case LINTANG_SLAM -> slam(caster, pos, self);
            case LINTANG_FLARE -> flare(caster, self);
            case LINTANG_CALL -> call(caster, self);
            case LINTANG_RESCUE -> rescue(caster, self);
            case LINTANG_SAVE -> save(caster, pos);
            case LINTANG_LANCE -> lance(caster, pos);
            case LINTANG_PULSE -> pulse(caster);
            case LINTANG_DAWNPUNCH -> dawnPunch(caster, pos, self);
            case LINTANG_PARRY -> parry(pos);
            case LINTANG_BOUNCE -> bounce(pos);
            case LINTANG_PUNCH -> punch(pos);
            case LINTANG_FADE -> fade(caster);
            case LINTANG_RETURN -> glowReturn(caster);
            case LINTANG_KELAM -> kelam(caster, self);
            case LINTANG_RITE -> rite(caster, self);
            default -> { }
        }
    }

    // ------------------------------------------------------------------ dibaca lapisan lain

    /** 0-1: mata memanas & menyala selama Iris Surya (ShazamEyesLayer). */
    public static float eyeGlow(AbstractClientPlayer player, float partialTick) {
        long[] e = EYES.get(player.getId());
        if (e == null) {
            return 0f;
        }
        float now = player.level().getGameTime() + partialTick;
        if (now < e[0]) {
            return 0f;
        }
        return Mth.clamp((now - e[0]) / 4f, 0f, 1f) * Mth.clamp((e[1] - now) / 6f, 0f, 1f);
    }

    // ------------------------------------------------------------------ tiap tick

    public static void tick(ClientLevel level) {
        long now = level.getGameTime();
        EYES.entrySet().removeIf(e -> now > e.getValue()[1] + 2);
        KELAM_SEEN.keySet().removeIf(id -> !(level.getEntity(id) instanceof AbstractClientPlayer));
        Minecraft mc = Minecraft.getInstance();
        for (AbstractClientPlayer player : level.players()) {
            int id = player.getId();
            if (!ShazamClientState.isTransformed(id) || !ShazamClientState.isLintang(id) || player.isInvisible()) {
                continue;
            }
            boolean firstPerson = player == mc.player && mc.options.getCameraType().isFirstPerson();
            aura(level, player, firstPerson);
        }
    }

    /** Batu Kelam dekat pemain ini? Pemain sendiri: dari server (tepat). Pemain lain: perkiraan client tiap 10 tick. */
    private static boolean kelamNear(ClientLevel level, AbstractClientPlayer player) {
        if (player == Minecraft.getInstance().player) {
            return ShazamClientState.kelam;
        }
        if (player.tickCount % 10 == 0 || !KELAM_SEEN.containsKey(player.getId())) {
            KELAM_SEEN.put(player.getId(), LintangSkills.kelamAround(level, player, false));
        }
        return KELAM_SEEN.getOrDefault(player.getId(), false);
    }

    /** Cahaya samar di sekeliling badan (keemasan siang, biru pucat malam), korona saat Mode Surya, ungu saat Kelam. */
    private static void aura(ClientLevel level, AbstractClientPlayer player, boolean firstPerson) {
        RandomSource r = level.random;
        double sc = player.getScale();
        if (kelamNear(level, player)) {   // cahaya terhisap keluar: asap ungu gelap mengalir masuk, urat ungu merayap
            if (player.tickCount % 2 == 0) {
                Vec3 c = player.position().add(0, 1.0 * sc, 0);
                Vec3 off = ShazamFx.randomDir(r).scale(1.6 + r.nextDouble());
                Vfx.smoke(c.x + off.x, c.y + off.y * 0.6, c.z + off.z, -off.x * 0.06, -off.y * 0.04, -off.z * 0.06, KELAM_DARK,
                        0.35f, 18);
            }
            if (!firstPerson && player.tickCount % 9 == 0) {
                Vfx.add(new Lightning.Crackle(player, KELAM, 0.6f, 0.03f, 8).reach(1.0));
            }
            return;
        }
        if (firstPerson) {
            return;
        }
        boolean sun = PassiveConditions.underSun(level, player.blockPosition());
        boolean sky = PassiveConditions.skyLight(level, player.blockPosition());
        if (!sky) {   // di bawah tanah: cuma kilau samar yang tersisa
            if (player.tickCount % 14 == 0) {
                Vfx.glint(player.getX() + (r.nextDouble() - 0.5) * 0.6, player.getY() + (0.4 + r.nextDouble()) * sc,
                        player.getZ() + (r.nextDouble() - 0.5) * 0.6, STAR, 0.12f, 6);
            }
            return;
        }
        int rgb = sun ? SUN : STAR;
        if (player.tickCount % (sun ? 3 : 5) == 0) {
            double a = r.nextDouble() * Math.PI * 2.0, rr = (0.3 + r.nextDouble() * 0.25) * sc;
            Vfx.mote(player.getX() + Math.cos(a) * rr, player.getY() + (0.1 + r.nextDouble() * 1.7) * sc,
                    player.getZ() + Math.sin(a) * rr, 0, 0.02 + r.nextDouble() * 0.02, 0, rgb, 0.05f, 16 + r.nextInt(10));
        }
        if (player.tickCount % (sun ? 11 : 17) == 0) {
            Vec3 off = ShazamFx.randomDir(r).scale(0.4 * sc);
            Vfx.glint(player.getX() + off.x, player.getY() + (0.5 + r.nextDouble() * 1.3) * sc + off.y, player.getZ() + off.z,
                    sun ? SUN_HOT : STAR, 0.18f, 8);
        }
        if (ShazamClientState.isRaging(player.getId()) && player.tickCount % 2 == 0) {   // Mode Surya: korona menyala
            Vec3 c = player.position().add(0, 1.0 * sc, 0);
            Vec3 d = ShazamFx.randomDir(r);
            Vfx.mote(c.x + d.x * 0.5, c.y + d.y * 0.8, c.z + d.z * 0.5, d.x * 0.08, 0.04 + Math.abs(d.y) * 0.04, d.z * 0.08,
                    r.nextInt(3) == 0 ? SUN_HOT : SUN, 0.09f, 12);
        }
    }

    /** Muatan Cahaya penuh: kepalan menyala putih keemasan (dari ChampionFx). */
    static void chargedFists(ClientLevel level, AbstractClientPlayer p) {
        if (p.tickCount % 2 == 0) {
            for (boolean right : new boolean[] {true, false}) {
                Vec3 h = ShazamPoses.handPos(p, right, 1f);
                Vfx.mote(h.x, h.y, h.z, (level.random.nextDouble() - 0.5) * 0.02, 0.02, (level.random.nextDouble() - 0.5) * 0.02,
                        SUN_HOT, 0.07f, 6);
            }
        }
        if (p.tickCount % 6 == 0) {
            Vec3 h = ShazamPoses.handPos(p, level.random.nextBoolean(), 1f);
            Vfx.glint(h.x, h.y, h.z, SUN, 0.24f, 6);
        }
    }

    /** Jejak terbang (dari ShazamFx.flightTrail): kilau bintang tertinggal di belakang lintasan. */
    static void flightGlints(ClientLevel level, AbstractClientPlayer player, float speed) {
        if (speed < 1.0f || level.random.nextInt(2) != 0) {
            return;
        }
        Vec3 motion = new Vec3(player.getX() - player.xo, player.getY() - player.yo, player.getZ() - player.zo);
        if (motion.lengthSqr() < 1.0E-4) {
            return;
        }
        Vec3 back = player.position().add(0, 0.9, 0).subtract(motion.normalize().scale(1.2 + level.random.nextDouble() * 1.4))
                .add(ShazamFx.randomDir(level.random).scale(0.5));
        boolean sun = PassiveConditions.underSun(level, player.blockPosition());
        Vfx.glint(back.x, back.y, back.z, sun ? SUN_HOT : STAR, 0.22f, 9);
    }

    // ------------------------------------------------------------------ alat bantu

    private static void schedule(int delay, int duration, ShazamFx.Step step) {
        ShazamFx.schedule(delay, duration, step);
    }

    private static void sound(ClientLevel level, Vec3 at, SoundEvent sound, float volume, float pitch) {
        level.playLocalSound(at.x, at.y, at.z, sound, SoundSource.PLAYERS, volume, ShazamFx.slowPitch(level, pitch), false);
    }

    private static boolean firstPerson(AbstractClientPlayer player) {
        Minecraft mc = Minecraft.getInstance();
        return player == mc.player && mc.options.getCameraType().isFirstPerson();
    }

    private static Vec3 chest(AbstractClientPlayer player) {
        return player.position().add(0, 1.2 * player.getScale(), 0);
    }

    private static Lightning.Anchor chestAnchor(AbstractClientPlayer player) {
        return pt -> player.getPosition(pt).add(0, 1.2 * player.getScale(), 0);
    }

    private static Vec3 mouth(AbstractClientPlayer p, float pt) {
        return p.getEyePosition(pt).add(0, -0.15 * p.getScale(), 0).add(p.getViewVector(pt).scale(firstPerson(p) ? 0.8 : 0.3));
    }

    /** Kilau & butiran cahaya memancar ke segala arah. */
    private static void starBurst(ClientLevel level, Vec3 c, int count, double speed) {
        RandomSource r = level.random;
        for (int i = 0, n = Vfx.count(count); i < n; i++) {
            Vec3 d = ShazamFx.randomDir(r).scale(speed * (0.4 + r.nextDouble() * 0.8));
            if (i % 3 == 0) {
                Vfx.glint(c.x + d.x * 2, c.y + d.y * 2, c.z + d.z * 2, SUN_HOT, 0.22f + r.nextFloat() * 0.1f, 8 + r.nextInt(6));
            } else {
                Vfx.mote(c.x, c.y, c.z, d.x * 0.3, d.y * 0.3, d.z * 0.3, i % 2 == 0 ? SUN : SUN_HOT, 0.08f, 14 + r.nextInt(10));
            }
        }
    }

    /** Kilatan layar untuk penonton di dekat titik ini (makin dekat makin terang). */
    private static void flashNear(Vec3 c, float strength, int rgb, double radius) {
        var me = Minecraft.getInstance().player;
        if (me == null) {
            return;
        }
        double d = me.position().distanceTo(c);
        if (d < radius) {
            ScreenFlash.flash(strength * (float) (1.0 - d / radius), rgb);
        }
    }

    // ------------------------------------------------------------------ efek khusus

    /** Garis cahaya lurus dari a ke b yang menipis lalu padam (lesatan, tombak cahaya, jejak penyelamatan). */
    static final class Streak extends Effect {
        private final Vec3 a, b;
        private final int rgb;
        private final float width;

        Streak(Vec3 a, Vec3 b, int rgb, float width, int life) {
            super(life);
            this.a = a;
            this.b = b;
            this.rgb = rgb;
            this.width = width;
        }

        @Override
        public void renderGlow(Draw d) {
            float t = progress(d.partialTick);
            float k = (1f - t) * (1f - t);
            d.beam(a.x, a.y, a.z, b.x, b.y, b.z, width * (0.4f + 0.6f * k), rgb, SUN_HOT, k * 0.6f, k);
        }
    }

    /** Iris Surya: sinar panas dari kedua mata, mengikuti arah pandang, berhenti di blok atau makhluk pertama. */
    static final class EyeBeams extends Effect {
        private final AbstractClientPlayer owner;
        private Vec3 end;
        private boolean blockHit;

        EyeBeams(AbstractClientPlayer owner) {
            super(ShazamAnim.IRIS_WINDUP + ShazamAnim.IRIS_TICKS + 3);
            this.owner = owner;
        }

        private boolean firing() {
            return age >= ShazamAnim.IRIS_WINDUP && age < ShazamAnim.IRIS_WINDUP + ShazamAnim.IRIS_TICKS;
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (!owner.isAlive() || !ShazamClientState.isTransformed(owner.getId())) {
                return false;
            }
            if (firing()) {
                aim(level);
                RandomSource r = level.random;
                for (int i = 0, n = Vfx.count(3); i < n; i++) {
                    Vec3 v = ShazamFx.randomDir(r).scale(0.12 + r.nextDouble() * 0.12);
                    Vfx.spark(end.x, end.y, end.z, v.x, Math.abs(v.y) + 0.05, v.z, i % 2 == 0 ? SUN_HOT : AMBER, 0.05f,
                            8 + r.nextInt(6), end.y - 2.0);
                }
                if (age % 3 == 0) {
                    Vfx.smoke(end.x, end.y, end.z, 0, 0.03, 0, 0x2A2420, 0.35f, 26);
                }
                if (blockHit && age % 8 == 0) {   // bekas hangus di tempat sinar menyentuh
                    Ground.Map map = ShazamFx.ground(level, end, 1.2);
                    if (map != null && map.found && Math.abs(map.centerY - end.y) < 1.0) {
                        Vfx.add(new Fx.Scorch(map.center(end), 0.45, 120, 40, map));
                    }
                }
            }
            return super.tick(level);
        }

        private void aim(ClientLevel level) {
            Vec3 eye = owner.getEyePosition(1f);
            Vec3 look = owner.getViewVector(1f);
            BlockHitResult hit = level.clip(new ClipContext(eye, eye.add(look.scale(LintangSkills.IRIS_RANGE)),
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, owner));
            blockHit = hit.getType() != HitResult.Type.MISS;
            double reach = blockHit ? hit.getLocation().distanceTo(eye) : LintangSkills.IRIS_RANGE;
            double best = reach;
            List<LivingEntity> near = level.getEntitiesOfClass(LivingEntity.class,
                    new AABB(eye, eye.add(look.scale(reach))).inflate(1.0), e -> e != owner && e.isAlive());
            for (LivingEntity e : near) {
                AABB box = e.getBoundingBox().inflate(0.2);
                for (double s = 0.5; s < best; s += 0.5) {
                    if (box.contains(eye.add(look.scale(s)))) {
                        best = s;
                        break;
                    }
                }
            }
            if (best < reach) {
                blockHit = false;
            }
            end = eye.add(look.scale(best));
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float time = age + pt;
            float w = ShazamAnim.IRIS_WINDUP;
            boolean fp = firstPerson(owner);
            Vec3 eye = owner.getEyePosition(pt);
            Vec3 look = owner.getViewVector(pt);
            float yaw = owner.getViewYRot(pt) * Mth.DEG_TO_RAD;
            double sc = owner.getScale();
            Vec3 right = new Vec3(-Math.cos(yaw), 0, -Math.sin(yaw)).scale(0.11 * sc);
            Vec3 forward = look.scale(fp ? 0.9 : 0.22 * sc);
            Vec3 eyeR = eye.add(right).add(forward);
            Vec3 eyeL = eye.subtract(right).add(forward);
            if (time < w) {   // mata memanas dulu
                float charge = Mth.clamp(time / w, 0f, 1f);
                if (!fp) {
                    d.flare(eyeR.x, eyeR.y, eyeR.z, 0.1f + 0.12f * charge, SUN, charge);
                    d.flare(eyeL.x, eyeL.y, eyeL.z, 0.1f + 0.12f * charge, SUN, charge);
                }
                return;
            }
            float left = w + ShazamAnim.IRIS_TICKS - time;
            float a = Mth.clamp(left / 3f, 0f, 1f) * (0.85f + 0.15f * Mth.sin(time * 2.7f));
            if (end == null || a <= 0.01f) {
                return;
            }
            float width = (fp ? 0.07f : 0.11f) * (float) sc;
            d.beam(eyeR.x, eyeR.y, eyeR.z, end.x, end.y, end.z, width, AMBER, SUN_HOT, a * 0.9f, a);
            d.beam(eyeL.x, eyeL.y, eyeL.z, end.x, end.y, end.z, width, AMBER, SUN_HOT, a * 0.9f, a);
            if (!fp) {
                d.flare(eyeR.x, eyeR.y, eyeR.z, 0.2f, SUN, a);
                d.flare(eyeL.x, eyeL.y, eyeL.z, 0.2f, SUN, a);
            }
            float flick = 0.8f + 0.2f * Mth.sin(time * 3.1f);
            d.flare(end.x, end.y, end.z, 0.55f * flick, SUN, a);
            float old = d.body(0.4f);
            d.glow(end.x, end.y, end.z, 1.4f, AMBER, a * 0.35f);
            d.body(old);
        }
    }

    // ------------------------------------------------------------------ berubah wujud

    /** Bukan dewa: cahaya langit turun bergelombang enam kali dan terhisap ke dada, lingkaran cahaya di tanah. */
    private static void summon(AbstractClientPlayer caster, boolean self) {
        if (self) {
            ShazamCinematic.start();
            ScreenFx.cinema(ShazamAnim.SUMMON_TICKS + ShazamAnim.TRANSFORM_STRIKE + 30);
        }
        int total = ShazamAnim.SUMMON_TICKS;
        schedule(0, 1, (level, t) -> {
            Ground.Map map = ShazamFx.ground(level, caster.position(), 5.0);
            if (map != null && map.found) {
                Vec3 g = map.center(caster.position());
                Vfx.add(new Fx.Wave(g, UP, 4.2, 0.12, SUN, total, 0.55f, 0.06f, map));
                Vfx.add(new Fx.Wave(g, UP, 2.6, 0.08, SUN_HOT, total, 0.4f, 0f, map));
            }
        });
        for (int i = 0; i < GodShow.ARRIVE.length; i++) {   // jadwalnya sama dengan kedatangan dewa (gerakan badan pas)
            int k = i;
            float u = i / (float) (GodShow.ARRIVE.length - 1);
            schedule(GodShow.ARRIVE[i], 1, (level, t) -> {
                Vec3 c = chest(caster);
                CineFx.godRays(chestAnchor(caster), SUN, 30.0, 1.4 + 1.2 * u, 4, 0.5f + 0.4f * u, 26);
                Vfx.add(new Fx.Flash(c, 1.2f + u, SUN_HOT, 10, 0.7f));
                Ground.Map map = ShazamFx.ground(level, caster.position(), 3.0 + u * 2.0);
                if (map != null && map.found) {
                    Vfx.add(new Fx.Wave(map.center(caster.position()), UP, 2.0 + u * 2.4, 0.16, SUN, 16, 0.7f, 0.04f, map));
                }
                sound(level, c, ShazamSounds.SHIMMER.get(), 0.9f, 1.0f + 0.12f * k);
            });
        }
        schedule(4, total - 4, (level, t) -> {   // butiran cahaya terhisap ke dada, makin deras
            float k = t / (float) total;
            Vec3 c = chest(caster);
            RandomSource r = level.random;
            for (int i = 0, n = Vfx.count(2 + 4 * k); i < n; i++) {
                double a = r.nextDouble() * Math.PI * 2.0, rr = 2.2 + r.nextDouble() * 1.6;
                Vec3 from = c.add(Math.cos(a) * rr, (r.nextDouble() - 0.3) * 2.4, Math.sin(a) * rr);
                Vec3 v = c.subtract(from).scale(0.12);
                Vfx.mote(from.x, from.y, from.z, v.x, v.y, v.z, r.nextInt(3) == 0 ? SUN_HOT : SUN, 0.07f + 0.05f * k, 8);
            }
        });
    }

    private static void transform(AbstractClientPlayer caster, boolean self) {
        int strike = ShazamAnim.TRANSFORM_STRIKE;
        CineFx.gather(caster, 0, strike, pt -> caster.getPosition(pt).add(0, 2.3 * caster.getScale(), 0), SUN_HOT, 1.4, 4f,
                false);
        schedule(strike, 1, (level, t) -> {
            Vec3 c = chest(caster);
            CineFx.impact(level, c, 2.6f, SUN, SUN_HOT, self, true);
            CineFx.godRays(chestAnchor(caster), SUN, 40.0, 3.2, 8, 1f, 40);
            CineFx.flare(c, SUN_HOT, 9f, 0.22f, 1f, 18);
            Vfx.add(new Fx.Glow(caster, chestAnchor(caster), 2.6f, SUN, 34, 4));
            Vfx.add(new Fx.Bubble(c, 3.2, SUN_HOT, 14, 0.8f, 1.0, 2.4, true));
            starBurst(level, c, 40, 0.5);
            if (self) {
                ScreenFlash.flash(0.85f, 0xFFF2D0);
                CameraShake.add(0.8f);
                FovKick.punch(0.5f);
            } else {
                flashNear(c, 0.5f, 0xFFF2D0, 24);
            }
        });
        schedule(strike + 2, 16, (level, t) -> {   // kostum terbentuk dari cahaya: kilau naik dari kaki ke kepala
            double y = caster.getY() + (t / 16.0) * 2.0 * caster.getScale();
            for (int i = 0; i < 3; i++) {
                double a = level.random.nextDouble() * Math.PI * 2.0;
                Vfx.glint(caster.getX() + Math.cos(a) * 0.35, y, caster.getZ() + Math.sin(a) * 0.35, SUN_HOT, 0.22f, 7);
            }
        });
    }

    private static void revert(AbstractClientPlayer caster, boolean self, boolean knockout) {
        schedule(knockout ? 0 : ShazamAnim.REVERT_WINDUP, 1, (level, t) -> {
            Vec3 c = caster.position().add(0, 1.1 * caster.getScale(), 0);
            Vfx.add(new Fx.Flash(c, knockout ? 2.6f : 1.6f, SUN_HOT, 10, 1f));
            CineFx.flare(c, SUN, knockout ? 6f : 3.5f, 0.12f, 0.9f, 12);
            for (int i = 0, n = Vfx.count(knockout ? 40 : 22); i < n; i++) {
                Vec3 d = ShazamFx.randomDir(level.random);
                Vfx.mote(c.x, c.y, c.z, d.x * 0.18, Math.abs(d.y) * 0.16 + 0.06, d.z * 0.18, i % 3 == 0 ? SUN_HOT : SUN, 0.08f,
                        22 + level.random.nextInt(14));
            }
            if (knockout) {
                Vfx.add(new Fx.Bubble(c, 3.0, SUN, 10, 0.7f, 1.0, 2.0, true));
                if (self) {
                    ScreenFlash.flash(0.5f, 0xFFE8C0);
                    CameraShake.add(0.6f);
                }
            }
        });
    }

    // ------------------------------------------------------------------ terbang

    private static void launch(AbstractClientPlayer caster) {
        schedule(0, 1, (level, t) -> {
            Vec3 c = caster.position();
            Ground.Map map = ShazamFx.ground(level, c, 3.0);
            if (map != null && map.found) {
                Vec3 g = map.center(c);
                Vfx.add(new Fx.Wave(g, UP, 2.6, 0.22, SUN, 12, 0.8f, 0.06f, map));
                ShazamFx.dustPuffs(level, g, map.dustColor(level, c), 10, 0.8, 0.12);
            }
            Vfx.add(new Fx.Flash(c.add(0, 0.6, 0), 1.2f, SUN_HOT, 7, 0.7f));
        });
    }

    private static void landing(AbstractClientPlayer caster, boolean self, boolean crash) {
        schedule(0, 1, (level, t) -> {
            ShazamFx.impact(level, caster, caster.position(), crash ? 1.8f : 1.2f, SUN, SUN_HOT, true, 0.6f);
            Vfx.add(new Fx.Flash(caster.position().add(0, 0.5, 0), crash ? 2.2f : 1.5f, SUN_HOT, 8, 0.9f));
            if (self) {
                CameraShake.add(crash ? 0.6f : 0.35f);
            }
        });
    }

    private static void sonicBoom(AbstractClientPlayer caster, boolean self) {
        schedule(0, 1, (level, t) -> {
            Vec3 motion = new Vec3(caster.getX() - caster.xo, caster.getY() - caster.yo, caster.getZ() - caster.zo);
            Vec3 dir = motion.lengthSqr() > 1.0E-4 ? motion.normalize() : caster.getViewVector(1f);
            Vec3 c = caster.position().add(0, 0.9, 0);
            Vfx.add(new Fx.Ripple(c, dir.scale(-1), 6.0, 0.6, 3.2, 0.25, SUN_HOT, 14, 0.8f, false));
            Vfx.add(new Fx.Ripple(c, dir.scale(-1), 4.0, 0.4, 2.2, 0.18, STAR, 10, 0.6f, false));
            Vfx.add(new Fx.Flash(c, 1.6f, SUN_HOT, 6, 0.8f));
            if (self) {
                CameraShake.add(0.35f);
                FovKick.kick(0.25f);
            }
        });
    }

    // ------------------------------------------------------------------ pasif

    /** Serapan Cahaya tiap 2 detik: sinar matahari (siang) atau cahaya bintang (malam) turun menyentuh dada. */
    private static void pulse(AbstractClientPlayer caster) {
        boolean sun = PassiveConditions.underSun(caster.level(), caster.blockPosition());
        int rgb = sun ? SUN : STAR;
        CineFx.godRays(chestAnchor(caster), rgb, sun ? 34.0 : 26.0, sun ? 1.3 : 0.9, sun ? 5 : 3, sun ? 0.75f : 0.5f, 14);
        schedule(ShazamAnim.ROD_DESCENT, 1, (level, t) -> {
            Vec3 c = chest(caster);
            boolean fp = firstPerson(caster);
            Vfx.add(new Fx.Flash(c, fp ? 0.6f : 1.5f, sun ? SUN_HOT : 0xEAF4FF, 8, fp ? 0.35f : 0.9f));
            Vfx.add(new Fx.Wave(c, UP, 1.6, 0.14, rgb, 10, fp ? 0.3f : 0.8f, 0f, null));
            Vfx.add(new Fx.Glow(caster, chestAnchor(caster), 1.2f, rgb, 14, 2));
            for (int i = 0, n = Vfx.count(fp ? 4 : 12); i < n; i++) {
                Vec3 d = ShazamFx.randomDir(level.random);
                Vfx.mote(c.x + d.x * 0.3, c.y + d.y * 0.5, c.z + d.z * 0.3, d.x * 0.06, 0.03, d.z * 0.06, rgb, 0.06f, 14);
            }
            ShazamPoses.surge(caster);
        });
    }

    private static void fade(AbstractClientPlayer caster) {
        schedule(0, ShazamAnim.DIM_TICKS, (level, t) -> {
            if (t % 3 != 0) {
                return;
            }
            Vec3 c = chest(caster);
            Vec3 d = ShazamFx.randomDir(level.random).scale(0.35);
            Vfx.mote(c.x + d.x, c.y + d.y, c.z + d.z, 0, 0.03, 0, Draw.mix(SUN, 0x6A6A70, t / (double) ShazamAnim.DIM_TICKS),
                    0.07f * (1f - t / (float) ShazamAnim.DIM_TICKS), 18);
            if (t % 6 == 0) {
                Vfx.smoke(c.x, c.y - 0.4, c.z, 0, 0.02, 0, 0x55555A, 0.3f, 24);
            }
        });
    }

    private static void glowReturn(AbstractClientPlayer caster) {
        schedule(0, 1, (level, t) -> {
            Vec3 c = chest(caster);
            Vfx.add(new Fx.Flash(c, 1.8f, SUN_HOT, 10, 0.9f));
            CineFx.godRays(chestAnchor(caster), SUN, 30.0, 1.2, 4, 0.7f, 18);
            starBurst(level, c, 16, 0.3);
        });
    }

    private static void kelam(AbstractClientPlayer caster, boolean self) {
        schedule(0, 16, (level, t) -> {   // cahaya terhisap keluar dari badan ke arah Batu Kelam
            Vec3 c = chest(caster);
            for (int i = 0; i < 3; i++) {
                Vec3 d = ShazamFx.randomDir(level.random);
                Vfx.smoke(c.x + d.x * 0.3, c.y + d.y * 0.4, c.z + d.z * 0.3, d.x * 0.1, d.y * 0.05, d.z * 0.1, KELAM_DARK, 0.4f, 20);
            }
        });
        schedule(0, 1, (level, t) -> {
            Vfx.add(new Lightning.Crackle(caster, KELAM, 1.4f, 0.04f, 20).reach(1.1));
            if (self) {
                ScreenFx.vignette(0.6f, 0x3A1060, 20);
                CameraShake.add(0.2f);
            }
        });
    }

    private static void dawnPunch(AbstractClientPlayer caster, Vec3 pos, boolean self) {
        schedule(0, 1, (level, t) -> {
            CineFx.impact(level, pos, 1.7f, SUN, SUN_HOT, self, true);
            Vfx.add(new Fx.Pillar(pos.subtract(0, 0.8, 0), 8.0, 0.9f, SUN, 10));
            starBurst(level, pos, 24, 0.5);
        });
    }

    private static void parry(Vec3 pos) {
        schedule(0, 1, (level, t) -> {
            Vfx.add(new Fx.Flash(pos, 1.3f, FROST, 7, 1f));
            Vfx.add(new Fx.Bubble(pos, 0.9, FROST_DEEP, 8, 0.7f, 1.0, 2.0, true));
            RandomSource r = level.random;
            for (int i = 0, n = Vfx.count(14); i < n; i++) {
                Vec3 v = ShazamFx.randomDir(r).scale(0.2 + r.nextDouble() * 0.2);
                Vfx.spark(pos.x, pos.y, pos.z, v.x, v.y + 0.08, v.z, i % 2 == 0 ? 0xFFFFFF : FROST, 0.05f, 10 + r.nextInt(8),
                        pos.y - 2.0);
            }
            for (int i = 0; i < 5; i++) {
                Vec3 d = ShazamFx.randomDir(r).scale(0.5);
                Vfx.glint(pos.x + d.x, pos.y + d.y, pos.z + d.z, 0xFFFFFF, 0.2f, 8);
            }
        });
    }

    private static void bounce(Vec3 pos) {
        schedule(0, 1, (level, t) -> {
            Vfx.add(new Fx.Flash(pos, 0.5f, SUN_HOT, 4, 0.9f));
            for (int i = 0; i < 4; i++) {
                Vec3 v = ShazamFx.randomDir(level.random).scale(0.25);
                Vfx.spark(pos.x, pos.y, pos.z, v.x, v.y + 0.1, v.z, SUN_HOT, 0.04f, 8, pos.y - 2.0);
            }
        });
    }

    private static void punch(Vec3 pos) {
        schedule(0, 1, (level, t) -> {
            Vfx.add(new Fx.Flash(pos, 0.7f, SUN_HOT, 5, 0.9f));
            ShazamFx.ringOfSparks(level, pos, 5, SUN, 0.25);
        });
    }

    private static void lance(AbstractClientPlayer caster, Vec3 pos) {
        schedule(0, 1, (level, t) -> {
            Vfx.add(new Streak(chest(caster), pos, SUN, 0.16f, 9));
            Vfx.add(new Fx.Flash(pos, 1.0f, SUN_HOT, 7, 0.9f));
            ShazamFx.ringOfSparks(level, pos, 8, SUN, 0.3);
        });
    }

    // ------------------------------------------------------------------ L - Lesatan Bintang

    private static void dash(AbstractClientPlayer caster, Vec3 end, boolean self) {
        int w = ShazamAnim.LESAT_WINDUP;
        CineFx.gather(caster, 0, w, chestAnchor(caster), SUN, 1.2, 3f, false);
        schedule(w, 1, (level, t) -> {
            double up = 0.9 * caster.getScale();
            Vec3 start = caster.position().add(0, up, 0);
            Vec3 stop = end.add(0, up, 0);
            Vfx.add(new Streak(start, stop, SUN, 1.1f, 14));
            Vfx.add(new Streak(start, stop, SUN_HOT, 0.45f, 10));
            Vec3 dir = stop.subtract(start);
            if (dir.lengthSqr() > 1.0E-4) {
                Vfx.add(new Fx.Ripple(start, dir.normalize(), dir.length(), 0.5, 1.8, 0.15, STAR, 10, 0.6f, false));
            }
            Vfx.add(new Fx.Flash(start, 1.4f, SUN_HOT, 6, 0.9f));
            ShazamPoses.ghostBurst(caster, ShazamAnim.LESAT_TICKS + 4);
            if (self) {
                FovKick.kick(0.4f);
                ScreenFx.speedLines(0.8f);
            }
        });
        schedule(w + ShazamAnim.LESAT_TICKS, 1, (level, t) -> {
            Vec3 c = caster.position().add(0, 0.9, 0);
            Vfx.add(new Fx.Flash(c, 2.0f, SUN_HOT, 8, 1f));
            Vfx.add(new Fx.Bubble(c, 3.0, SUN, 9, 0.7f, 1.0, 2.0, true));
            ShazamFx.ringOfSparks(level, c, 18, SUN, 0.35);
            ShazamFx.shakeAround(c, 0.4f, 14);
        });
    }

    // ------------------------------------------------------------------ I - Iris Surya

    private static void eyes(AbstractClientPlayer caster, boolean self) {
        long now = caster.level().getGameTime();
        EYES.put(caster.getId(), new long[] {now, now + ShazamAnim.IRIS_WINDUP + ShazamAnim.IRIS_TICKS});
        Vfx.add(new EyeBeams(caster));
        if (self) {
            CameraShake.add(0.15f);
        }
    }

    // ------------------------------------------------------------------ N - Napas Salju

    private static void breath(AbstractClientPlayer caster, boolean self) {
        int w = ShazamAnim.FROST_WINDUP;
        schedule(0, w, (level, t) -> {   // menarik napas: udara dingin terhisap ke mulut
            Vec3 m = mouth(caster, 1f);
            for (int i = 0, n = Vfx.count(3); i < n; i++) {
                Vec3 off = ShazamFx.randomDir(level.random).scale(1.4 + level.random.nextDouble() * 0.6);
                Vfx.mote(m.x + off.x, m.y + off.y * 0.6, m.z + off.z, -off.x * 0.16, -off.y * 0.1, -off.z * 0.16, FROST, 0.05f, 6);
            }
        });
        schedule(w, ShazamAnim.FROST_TICKS, (level, t) -> {
            Vec3 m = mouth(caster, 1f);
            Vec3 look = caster.getViewVector(1f);
            RandomSource r = level.random;
            for (int i = 0, n = Vfx.count(6); i < n; i++) {
                Vec3 v = look.add(ShazamFx.randomDir(r).scale(0.28)).normalize().scale(0.55 + r.nextDouble() * 0.45);
                Vfx.mote(m.x, m.y, m.z, v.x, v.y, v.z, i % 3 == 0 ? 0xFFFFFF : FROST, 0.09f + r.nextFloat() * 0.06f,
                        14 + r.nextInt(6));
            }
            for (int i = 0, n = Vfx.count(2); i < n; i++) {
                Vec3 v = look.add(ShazamFx.randomDir(r).scale(0.22)).normalize().scale(0.35 + r.nextDouble() * 0.3);
                Vfx.dust(m.x, m.y, m.z, v.x, v.y, v.z, 0xE8F6FF, 0.35f + r.nextFloat() * 0.3f, 18 + r.nextInt(8));
            }
            if (t % 4 == 0) {
                Vfx.add(new Fx.Cone(m, look, 11.0, 0.55, FROST_DEEP, 8, 0.32f, 2.0, false));
            }
            if (t % 3 == 0) {
                Vec3 p = m.add(look.scale(2 + r.nextDouble() * 8)).add(ShazamFx.randomDir(r).scale(1.2));
                Vfx.glint(p.x, p.y, p.z, 0xFFFFFF, 0.2f, 8);
            }
            if (self && t % 10 == 0) {
                CameraShake.add(0.08f);
            }
        });
    }

    // ------------------------------------------------------------------ T - Tepukan Guruh

    private static void clap(AbstractClientPlayer caster, boolean self) {
        schedule(ShazamAnim.SONIC_WINDUP, 1, (level, t) -> {
            Vec3 hands = ShazamPoses.handPos(caster, true, 1f).add(ShazamPoses.handPos(caster, false, 1f)).scale(0.5);
            Vec3 look = caster.getViewVector(1f);
            Vfx.add(new Fx.Flash(hands, 1.8f, 0xFFFFFF, 6, 1f));
            CineFx.flare(hands, SUN_HOT, 5f, 0.14f, 1f, 10);
            for (int k = 0; k < 3; k++) {   // gelombang suara berlapis melesat ke depan
                Vfx.add(new Fx.Ripple(hands, look, 14.0 - k * 2.5, 0.4 + k * 0.2, 6.0 - k, 0.3, k == 0 ? 0xFFFFFF : STAR,
                        12 + k * 3, 0.75f - k * 0.15f, false));
            }
            Vfx.add(new Fx.Ripple(hands, look, 12.0, 0.6, 5.0, 0.9, 0xD8D0C4, 18, 0.45f, true));
            Vfx.add(new Fx.Wave(hands, look, 2.4, 0.25, 0xFFFFFF, 8, 0.9f, 0.1f, null));
            Vec3 flat = new Vec3(look.x, 0, look.z);
            flat = flat.lengthSqr() < 1.0E-4 ? new Vec3(0, 0, 1) : flat.normalize();
            for (int i = 0, n = Vfx.count(16); i < n; i++) {   // dinding debu tersapu ke depan
                double d0 = 2 + level.random.nextDouble() * 9, side = (level.random.nextDouble() - 0.5) * d0 * 1.2;
                Vec3 p = caster.position().add(flat.scale(d0)).add(-flat.z * side, 0.2, flat.x * side);
                Vfx.dust(p.x, p.y, p.z, flat.x * 0.25, 0.04, flat.z * 0.25, 0xC8BBA8, 0.6f, 24);
            }
            ShazamFx.shakeAround(hands, 0.9f, 24);
            if (self) {
                ScreenFlash.flash(0.25f, 0xFFFFFF);
                FovKick.punch(0.5f);
            }
        });
    }

    // ------------------------------------------------------------------ A - Amukan Kilat

    private static void barrage(AbstractClientPlayer caster, boolean self) {
        int w = ShazamAnim.BARRAGE_WINDUP;
        ShazamPoses.ghostBurst(caster, w + ShazamAnim.BARRAGE_TICKS + 4);
        schedule(w, ShazamAnim.BARRAGE_TICKS, (level, t) -> {   // kepalan secepat kilat meninggalkan bayangan cahaya
            if (t % 2 != 0) {
                return;
            }
            Vec3 hand = ShazamPoses.handPos(caster, (t / 2) % 2 == 0, 1f);
            Vec3 tip = hand.add(caster.getViewVector(1f).scale(0.6)).add(ShazamFx.randomDir(level.random).scale(0.25));
            Vfx.add(new Streak(hand, tip, SUN_HOT, 0.16f, 3));
            Vfx.add(new Fx.Flash(tip, 0.5f, SUN, 3, 0.8f));
            if (self && t % 4 == 0) {
                CameraShake.add(0.06f);
            }
        });
    }

    private static void hit(AbstractClientPlayer caster, Vec3 pos) {
        schedule(0, 1, (level, t) -> {
            Vfx.add(new Fx.Flash(pos, 1.0f, SUN_HOT, 5, 1f));
            Vec3 n = pos.subtract(caster.getEyePosition());
            Vfx.add(new Fx.Wave(pos, n.lengthSqr() > 1.0E-4 ? n.normalize() : UP, 1.1, 0.12, SUN, 6, 0.8f, 0f, null));
            ShazamFx.ringOfSparks(level, pos, 8, SUN, 0.3);
            ShazamFx.shakeAround(pos, 0.15f, 10);
        });
    }

    // ------------------------------------------------------------------ N - Napak Langit

    private static void leap(AbstractClientPlayer caster) {
        launch(caster);
        schedule(ShazamAnim.LEAP_WINDUP, 14, (level, t) -> {   // jejak cahaya saat melambung & menukik
            Vec3 c = caster.position().add(0, 0.9, 0);
            Vfx.mote(c.x, c.y, c.z, 0, 0, 0, t % 2 == 0 ? SUN : SUN_HOT, 0.12f, 10);
        });
    }

    private static void slam(AbstractClientPlayer caster, Vec3 pos, boolean self) {
        schedule(0, 1, (level, t) -> {
            ShazamFx.impact(level, caster, pos, 2.8f, SUN, SUN_HOT, true);
            CineFx.impact(level, pos.add(0, 0.6, 0), 2.2f, SUN, SUN_HOT, self, false);
            Vfx.add(new Fx.Pillar(pos, 14.0, 1.6f, SUN, 14));
            Ground.Map map = ShazamFx.ground(level, pos, 8.0);
            if (map != null && map.found) {
                Vec3 g = map.center(pos);
                Vfx.add(new Fx.Wave(g, UP, 7.5, 0.5, SUN, 16, 0.85f, 0.1f, map));
                Vfx.add(new Fx.Wave(g, UP, 6.5, 1.2, map.dustColor(level, pos), 28, 0.5f, 0f, map, true));
            }
            if (self) {
                CameraShake.add(0.9f);
                ScreenFlash.flash(0.35f, 0xFFF2D0);
            }
        });
    }

    // ------------------------------------------------------------------ G - Gelegar Surya

    private static void flare(AbstractClientPlayer caster, boolean self) {
        int w = ShazamAnim.FLARE_WINDUP;
        CineFx.gather(caster, 0, w, chestAnchor(caster), SUN, 3.8, 7f, false);
        Vfx.add(new Fx.Glow(caster, chestAnchor(caster), 2.4f, SUN_HOT, w + 4, w));
        if (self) {
            ScreenFx.vignette(0.5f, 0xFFF0C0, w);
        }
        schedule(w, 1, (level, t) -> {
            Vec3 c = chest(caster);
            Vfx.add(new Fx.Flash(c, 7.5f, 0xFFFFFF, 12, 1f));
            Vfx.add(new Fx.Flash(c, 11f, SUN, 18, 0.8f));
            CineFx.flare(c, SUN_HOT, 18f, 0.4f, 1f, 22);
            Vfx.add(new Fx.Bubble(c, 16.0, SUN_HOT, 14, 0.75f, 1.0, 2.6, true));
            Vfx.add(new Fx.Bubble(c, 12.0, SUN, 22, 0.6f, 1.0, 1.8, true));
            CineFx.godRays(chestAnchor(caster), SUN, 50.0, 6.0, 10, 1f, 50);
            Ground.Map map = ShazamFx.ground(level, c, 16.0);
            if (map != null && map.found) {
                Vec3 g = map.center(c);
                Vfx.add(new Fx.Wave(g, UP, 16.0, 0.8, SUN, 22, 0.9f, 0.12f, map));
                Vfx.add(new Fx.Wave(g, UP, 13.0, 0.4, 0xFFFFFF, 14, 0.8f, 0f, map));
                Vfx.add(new Fx.Wave(g, UP, 14.0, 2.0, map.dustColor(level, c), 34, 0.55f, 0f, map, true));
                Vfx.add(new Fx.Scorch(g, 4.5, 200, 60, map));
                Vfx.add(new Ground.Cracks(g, map, 12, 6.0f, 200, 70, SUN, level.random.nextLong()));
            }
            for (int k = 0; k < 16; k++) {   // tombak cahaya memancar ke segala arah
                double a = Math.PI * 2.0 * k / 16.0;
                Vec3 e = c.add(Math.cos(a) * 14.0, (level.random.nextDouble() - 0.3) * 3.0, Math.sin(a) * 14.0);
                Vfx.add(new Streak(c, e, k % 2 == 0 ? SUN_HOT : SUN, 0.35f, 12));
            }
            starBurst(level, c, 80, 0.9);
            ShazamFx.shakeAround(c, 1.4f, 40);
            if (self) {
                ScreenFlash.flash(1f, 0xFFF6E0);
                FovKick.punch(0.9f);
            } else {
                flashNear(c, 0.8f, 0xFFF6E0, 40);
            }
        });
    }

    // ------------------------------------------------------------------ M - Serap Surya

    private static void call(AbstractClientPlayer caster, boolean self) {
        int w = ShazamAnim.SUNCALL_WINDUP;
        Lightning.Anchor hands = pt -> ShazamPoses.handPos(caster, true, pt).add(ShazamPoses.handPos(caster, false, pt)).scale(0.5);
        CineFx.gather(caster, 0, w, hands, SUN, 2.0, 5f, false);
        schedule(w, 1, (level, t) -> {
            Vec3 c = chest(caster);
            Vfx.add(new Fx.Flash(c, 2.6f, SUN_HOT, 10, 1f));
            Vfx.add(new Fx.Glow(caster, chestAnchor(caster), 2.0f, SUN, 30, 3));
            starBurst(level, c, 30, 0.5);
            if (self) {
                ScreenFlash.flash(0.55f, 0xFFF0C8);
                CameraShake.add(0.4f);
            }
        });
    }

    // ------------------------------------------------------------------ J - Selamatkan

    private static void rescue(AbstractClientPlayer caster, boolean self) {
        ShazamPoses.ghostBurst(caster, ShazamAnim.RESCUE_WINDUP + 16);
        schedule(ShazamAnim.RESCUE_WINDUP, 1, (level, t) -> {
            Vfx.add(new Fx.Flash(chest(caster), 1.6f, SUN_HOT, 7, 0.9f));
            if (self) {
                ScreenFx.speedLines(0.6f);
                FovKick.kick(0.3f);
            }
        });
    }

    /** Satu sekutu diselamatkan: jejak cahaya dari Lintang, lalu perisai cahaya menyelubunginya. */
    private static void save(AbstractClientPlayer caster, Vec3 pos) {
        schedule(0, 1, (level, t) -> {
            Vfx.add(new Streak(chest(caster), pos, SUN_HOT, 0.3f, 12));
            Vfx.add(new Fx.Bubble(pos, 1.3, SUN, 16, 0.7f, 1.0, 2.2, true));
            Vfx.add(new Fx.Flash(pos, 1.2f, SUN_HOT, 8, 0.8f));
            for (int i = 0; i < 6; i++) {
                Vec3 d = ShazamFx.randomDir(level.random).scale(0.7);
                Vfx.glint(pos.x + d.x, pos.y + d.y, pos.z + d.z, SUN_HOT, 0.2f, 10);
            }
        });
    }

    // ------------------------------------------------------------------ Penyatuan Bintang (wujud manusia)

    private static void rite(AbstractClientPlayer caster, boolean self) {
        int strike = ShazamAnim.RITE_STRIKE;
        if (self) {
            ScreenFx.cinema(ShazamAnim.RITE_TICKS + 20);
        }
        schedule(0, strike, (level, t) -> {
            float k = t / (float) strike;
            Vec3 crystal = ShazamPoses.handPos(caster, true, 1f).add(ShazamPoses.handPos(caster, false, 1f)).scale(0.5)
                    .add(0, 0.2, 0);
            if (t % 2 == 0) {
                Vfx.glint(crystal.x, crystal.y, crystal.z, SUN_HOT, 0.25f + 0.25f * k, 4);
            }
            RandomSource r = level.random;
            for (int i = 0, n = Vfx.count(1 + 3 * k); i < n; i++) {   // cahaya matahari mengumpul ke kristal
                Vec3 off = ShazamFx.randomDir(r).scale(2.5 + r.nextDouble() * 2.0);
                Vfx.mote(crystal.x + off.x, crystal.y + Math.abs(off.y), crystal.z + off.z, -off.x * 0.12, -Math.abs(off.y) * 0.12,
                        -off.z * 0.12, r.nextInt(3) == 0 ? SUN_HOT : SUN, 0.06f + 0.04f * k, 8);
            }
            if (t % 20 == 0) {
                CineFx.godRays(Lightning.Anchor.fixed(crystal), SUN, 30.0, 1.0 + 1.5 * k, 4, 0.5f + 0.4f * k, 24);
                sound(level, crystal, ShazamSounds.SHIMMER.get(), 0.8f, 1.1f + 0.2f * k);
            }
        });
        schedule(strike, 1, (level, t) -> {
            Vec3 c = chest(caster);
            CineFx.impact(level, c, 2.8f, SUN, SUN_HOT, self, true);
            CineFx.godRays(chestAnchor(caster), SUN, 50.0, 4.0, 10, 1f, 50);
            starBurst(level, c, 60, 0.7);
            if (self) {
                ScreenFlash.flash(0.9f, 0xFFF2D0);
                CameraShake.add(0.8f);
            }
        });
    }

    // ------------------------------------------------------------------ tiang cahaya menghunjam tanah

    /** Tiang cahaya (MagicBolt varian 3) menyentuh tanah: dipanggil ShazamFx.boltStrike. */
    public static void sunStrike(ClientLevel level, Vec3 g, Ground.Map map, float size) {
        Vfx.add(new Fx.Flash(g.add(0, 0.8, 0), 1.2f + size * 1.6f, 0xFFFFFF, 8, 1f));
        Vfx.add(new Fx.Flash(g.add(0, 0.5, 0), 1.8f + size * 1.8f, SUN, 14, 0.8f));
        Vfx.add(new Fx.Wave(g, UP, 1.6 + size * 2.2, 0.3, SUN, 14, 0.85f, 0.15f, map));
        Vfx.add(new Fx.Wave(g, UP, 1.2 + size * 1.6, 0.18, 0xFFFFFF, 9, 0.7f, 0f, map));
        Vfx.add(new Fx.Bubble(g, 1.0 + size, SUN_HOT, 8, 0.6f, 0.5, 2.0, true));
        if (map.found) {
            Vfx.add(new Fx.Scorch(g, 0.35 + size * 0.4, 120, 30, map));
        }
        CineFx.godRays(Lightning.Anchor.fixed(g), SUN, 30.0, 1.0 + size * 0.6, 5, 0.7f, 24);
        ShazamFx.ringOfSparks(level, g.add(0, 0.3, 0), (int) (8 + 12 * size), SUN, 0.3 + size * 0.1);
        starBurst(level, g.add(0, 0.6, 0), (int) (10 + 10 * size), 0.4);
        ShazamFx.shakeAround(g, 0.25f * size, 26);
    }
}
