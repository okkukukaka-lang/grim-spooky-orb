package com.shazammod.client.anim;

import java.util.EnumMap;
import java.util.Map;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamForm;
import com.shazammod.client.fx.GodShow;

/**
 * Semua gerakan Shazam. Tiap skill punya ancang-ancang (badan menegang, gemetar mengumpulkan tenaga),
 * gerakan utama yang cepat dengan sedikit kebablasan (OUT_BACK), lalu kembali pelan.
 * Waktunya pas dengan saat damage di server (ShazamAnim.*_WINDUP).
 *
 * Panduan angka (derajat):
 * - Lengan xRot: 0 = turun, -90 = lurus ke depan, -180 = lurus ke atas, positif = ke belakang.
 * - Lengan zRot (lengan turun): kanan positif / kiri negatif = membuka ke samping.
 *   (lengan ke atas: kanan positif / kiri negatif = ke arah tengah).
 * - Lengan yRot (saat lurus ke depan): kanan negatif / kiri positif = ke arah tengah.
 * - Kaki xRot: negatif = ke depan. Kepala xRot: negatif = mendongak.
 * - tilt: positif = seluruh badan condong ke depan. drop: badan turun (blok), negatif = terangkat.
 * - twist: pinggang berputar, positif = bahu kanan ke belakang. lean: condong ke samping. shake: gemetar.
 */
public final class Clips {
    private Clips() {}

    private static final Map<ShazamAnim, Clip> CLIPS = new EnumMap<>(ShazamAnim.class);
    /** Gerakan khusus Black Adam (pemanggilan dewa & berubah ala firaun); yang nggak ada di sini memakai CLIPS. */
    private static final Map<ShazamAnim, Clip> ADAM = new EnumMap<>(ShazamAnim.class);
    /** 0.30 Gerakan khusus Sabbac (memanggil enam iblis & berubah dari bawah tanah); yang nggak ada memakai CLIPS. */
    private static final Map<ShazamAnim, Clip> SABBAC = new EnumMap<>(ShazamAnim.class);
    /** 0.32 Gerakan khusus Lintang (menerima cahaya langit & berubah); yang nggak ada memakai CLIPS. */
    private static final Map<ShazamAnim, Clip> LINTANG = new EnumMap<>(ShazamAnim.class);

    public static Clip get(ShazamAnim anim) {
        return CLIPS.get(anim);
    }

    public static Clip get(ShazamAnim anim, ShazamForm form) {
        if (form == ShazamForm.LINTANG) {
            Clip clip = LINTANG.get(anim);
            if (clip != null) {
                return clip;
            }
        }
        if (form == ShazamForm.SABBAC) {
            Clip clip = SABBAC.get(anim);
            if (clip != null) {
                return clip;
            }
        }
        if (form == ShazamForm.BLACK_ADAM) {
            Clip clip = ADAM.get(anim);
            if (clip != null) {
                return clip;
            }
        }
        return CLIPS.get(anim);
    }

    static {
        // Transformasi: membungkuk, kepalan ke langit (tick 7), lalu ditahan menegang dan gemetar selama petir turun
        // pelan (tick 8-18, slow motion). Tick 18 petir mengenai: tersentak, terangkat dengan lengan terbuka, berdiri gagah.
        CLIPS.put(ShazamAnim.TRANSFORM, Clip.builder(54)
                .key(0, Ease.LINEAR).rightArm(-20, 0, -4).leftArm(4, 0, -6).head(-5, 0, 0).legs(3).tilt(0)
                .key(3, Ease.OUT_CUBIC).rightArm(18, 0, 14).leftArm(18, 0, -14).head(12, 0, 0).legs(9).tilt(12).drop(0.16f)
                .key(7, Ease.OUT_QUAD).rightArm(-178, 0, -6).leftArm(25, 0, -14).head(-42, 0, 0).legs(6).tilt(-10).drop(-0.06f).shake(0.8f)
                .key(12, Ease.IN_OUT_SINE).rightArm(-183, 0, -4).leftArm(28, 0, -16).head(-48, 0, 0).tilt(-12).drop(-0.08f).shake(1.8f)
                .key(17, Ease.IN_OUT_SINE).rightArm(-177, 0, -7).leftArm(24, 0, -13).head(-44, 0, 0).tilt(-10).drop(-0.05f).shake(2.6f)
                .key(19, Ease.OUT_QUAD).head(-18, 0, 0).tilt(-3).drop(0.12f).shake(0f)
                .key(24, Ease.OUT_CUBIC).rightArm(-152, 0, -34).leftArm(-152, 0, 34).head(-32, 0, 0).legs(10).tilt(-12).drop(-0.35f)
                .key(36, Ease.IN_OUT_SINE).rightArm(-158, 0, -38).leftArm(-158, 0, 38).head(-36, 0, 0).tilt(-8).drop(-0.42f)
                .key(43, Ease.IN_OUT_SINE).rightArm(-20, 0, 30).leftArm(-20, 0, -30).head(6, 0, 0).legs(10).tilt(7).drop(0.14f)
                .key(50, Ease.OUT_CUBIC).rightArm(10, 0, 24).leftArm(10, 0, -24).head(-10, 0, 0).legs(8).tilt(-3).drop(0f)
                .fade(2, 5).build());

        // Memakai hood: kedua tangan meraih ke belakang kepala (tick 5), memegang tepi hood (6),
        // menariknya ke depan lewat atas kepala sampai dahi (16), lalu turun lagi.
        CLIPS.put(ShazamAnim.HOOD_UP, Clip.builder(ShazamAnim.HOOD_TICKS)
                .key(0, Ease.LINEAR).rightArm(-20, 0, 6).leftArm(-20, 0, -6)
                .key(5, Ease.IN_OUT_SINE).rightArm(-196, 0, -12).leftArm(-196, 0, 12).head(12, 0, 0)
                .key(6, Ease.LINEAR)
                .key(16, Ease.IN_OUT_SINE).rightArm(-140, 0, -14).leftArm(-140, 0, 14).head(6, 0, 0)
                .key(18, Ease.LINEAR)
                .key(24, Ease.OUT_CUBIC).rightArm(-5, 0, 4).leftArm(-5, 0, -4).head(0, 0, 0)
                .fade(2, 4).build());

        // Melepas hood: tangan memegang tepi hood di dahi (tick 5-6), mendorongnya ke belakang lewat atas kepala
        // sambil sedikit mendongak (16), lalu turun lagi.
        CLIPS.put(ShazamAnim.HOOD_DOWN, Clip.builder(ShazamAnim.HOOD_TICKS)
                .key(0, Ease.LINEAR).rightArm(-20, 0, 6).leftArm(-20, 0, -6)
                .key(5, Ease.IN_OUT_SINE).rightArm(-145, 0, -14).leftArm(-145, 0, 14).head(8, 0, 0)
                .key(6, Ease.LINEAR)
                .key(16, Ease.IN_OUT_SINE).rightArm(-200, 0, -10).leftArm(-200, 0, 10).head(-14, 0, 0)
                .key(18, Ease.LINEAR)
                .key(24, Ease.OUT_CUBIC).rightArm(-5, 0, 4).leftArm(-5, 0, -4).head(0, 0, 0)
                .fade(2, 4).build());

        // Memanggil enam dewa: kepala tertunduk dan lengan terbuka menerima. Dewa datang satu per satu
        // (GodShow.ARRIVE): tiap kedatangan badan sedikit tersentak, lengan makin terbuka, kepala makin terangkat
        // menatap mereka. Menjelang akhir gemetar menahan kekuatan, lalu dilanjutkan TRANSFORM (kepalan ke langit).
        Clip.Builder summon = Clip.builder(ShazamAnim.SUMMON_TICKS)
                .key(0, Ease.LINEAR).rightArm(-8, 0, 10).leftArm(-8, 0, -10).head(10, 0, 0).tilt(2)
                .key(8, Ease.OUT_CUBIC).rightArm(-22, 0, 40).leftArm(-22, 0, -40).head(18, 0, 0).legs(3).tilt(4).drop(0.04f);
        for (int i = 0; i < GodShow.ARRIVE.length; i++) {
            float u = i / (float) (GodShow.ARRIVE.length - 1);
            float at = GodShow.ARRIVE[i];
            float head = 14f - 40f * u;      // makin mendongak
            float open = 42f + 16f * u;      // lengan makin terbuka
            float fwd = -24f - 10f * u;
            summon.key(at - 1.5f, Ease.IN_OUT_SINE).rightArm(fwd, 0, open).leftArm(fwd, 0, -open).head(head + 3, 0, 0)
                    .legs(3).tilt(3 - 9 * u).drop(0.03f - 0.12f * u).shake(0f)
                    .key(at + 1, Ease.OUT_BACK).rightArm(fwd - 7, 0, open + 6).leftArm(fwd - 7, 0, -open - 6).head(head - 7, 0, 0)
                    .tilt(-2 - 9 * u).drop(-0.03f - 0.12f * u).shake(0.7f)
                    .key(at + 6, Ease.IN_OUT_SINE).rightArm(fwd - 2, 0, open + 2).leftArm(fwd - 2, 0, -open - 2).head(head - 2, 0, 0)
                    .tilt(1 - 9 * u).drop(0.01f - 0.12f * u).shake(0.15f);
        }
        float end = ShazamAnim.SUMMON_TICKS;
        float settled = GodShow.ARRIVE[GodShow.ARRIVE.length - 1] + 6;
        summon.key(Math.min(end - 0.5f, Math.max(settled + 1, end - 4)), Ease.IN_OUT_SINE)
                .rightArm(-36, 0, 60).leftArm(-36, 0, -60).head(-30, 0, 0).legs(2).tilt(-9).drop(-0.15f).shake(0.9f)
                .key(end, Ease.IN_OUT_SINE)
                .rightArm(-36, 0, 58).leftArm(-36, 0, -58).head(-30, 0, 0).tilt(-9).drop(-0.15f).shake(1.3f);
        CLIPS.put(ShazamAnim.SUMMON, summon.fade(4, 3).build());

        // Zeus Rage: membungkuk, kepalan mengepal, badan gemetar makin hebat, lalu meraung ke langit dengan lengan
        // menghentak ke bawah-samping (tick 9: mata menyala, petir menyambar) dan tetap bergetar menahan amarah.
        CLIPS.put(ShazamAnim.ZEUS_RAGE, Clip.builder(26)
                .key(0, Ease.OUT_CUBIC).rightArm(14, 0, 8).leftArm(14, 0, -8).head(20, 0, 0).tilt(8).drop(0.08f).shake(1f)
                .key(6, Ease.IN_QUAD).rightArm(28, 0, 18).leftArm(28, 0, -18).head(28, 0, 0).rightLeg(-18, 0, 6).leftLeg(-18, 0, -6)
                        .tilt(15).drop(0.18f).shake(3.5f)
                .key(8.5f, Ease.IN_QUAD).rightArm(34, 0, 10).leftArm(34, 0, -10).tilt(18).drop(0.22f).shake(4.5f)
                .key(9, Ease.OUT_BACK).rightArm(32, 0, 50).leftArm(32, 0, -50).head(-55, 0, 0).rightLeg(0, 0, 9).leftLeg(0, 0, -9)
                        .tilt(-18).drop(-0.06f).shake(2f)
                .key(19, Ease.LINEAR).shake(1.4f)
                .key(26, Ease.IN_OUT_SINE).rightArm(8, 0, 16).leftArm(8, 0, -16).head(-8, 0, 0).rightLeg(0, 0, 3).leftLeg(0, 0, -3)
                        .tilt(-2).drop(0f).shake(0f)
                .fade(2, 5).build());

        // Kembali jadi manusia: kepalan ke atas lagi (gemetar), petir (tick 6), badan lunglai
        CLIPS.put(ShazamAnim.REVERT, Clip.builder(22)
                .key(0, Ease.LINEAR).rightArm(-20, 0, -4).leftArm(4, 0, -6).head(-5, 0, 0)
                .key(5, Ease.OUT_CUBIC).rightArm(-178, 0, -6).leftArm(10, 0, -8).head(-35, 0, 0).shake(1.5f)
                .key(8, Ease.OUT_QUAD).rightArm(-120, 0, 0).head(-8, 0, 0).drop(0.14f).shake(0f)
                .key(16, Ease.IN_OUT_SINE).rightArm(0, 0, 4).leftArm(0, 0, -4).head(10, 0, 0).drop(0.04f)
                .fade(2, 5).build());

        // Terlempar balik jadi manusia (serangan mematikan saat jadi Shazam): badan terhentak ke belakang dengan lengan
        // terlempar ke depan, lalu (tick 3) kekuatan tercabut dari dada: lengan terentang ke belakang, kepala mendongak,
        // gemetar hebat. Lalu lunglai membungkuk dengan lutut goyah dan badan oleng, dan pelan-pelan tegak lagi.
        // Kaki cuma sedikit melangkah, supaya tetap wajar kalau langsung lari menjauh.
        CLIPS.put(ShazamAnim.KNOCKOUT, Clip.builder(30)
                .key(0, Ease.OUT_QUAD).rightArm(-62, 0, 34).leftArm(-62, 0, -34).head(-30, 0, 0)
                        .rightLeg(-22, 0, 6).leftLeg(12, 0, -6).tilt(-24).drop(0.04f).twist(10).shake(3f)
                .key(ShazamAnim.KNOCKOUT_BURST, Ease.OUT_CUBIC).rightArm(24, 0, 66).leftArm(24, 0, -66).head(-48, 0, 0)
                        .rightLeg(-8, 0, 8).leftLeg(6, 0, -8).tilt(-14).drop(-0.05f).twist(0).shake(5f)
                .key(6, Ease.LINEAR).shake(4f)
                .key(10, Ease.IN_QUAD).rightArm(10, 0, 12).leftArm(12, 0, -10).head(30, 0, 0)
                        .rightLeg(-26, 0, 6).leftLeg(16, 0, -6).tilt(24).drop(0.3f).shake(0.8f)
                .key(15, Ease.OUT_QUAD).head(36, 0, 0).tilt(28).drop(0.36f).lean(4).shake(0.4f)
                .key(20, Ease.IN_OUT_SINE).head(26, 0, 0).tilt(22).drop(0.28f).lean(-2).shake(0.2f)
                .key(30, Ease.IN_OUT_SINE).rightArm(4, 0, 8).leftArm(4, 0, -8).head(0, 0, 0)
                        .rightLeg(0, 0, 4).leftLeg(0, 0, -4).tilt(0).drop(0f).lean(0).shake(0f)
                .fade(1, 6).build());

        // S - Mata Solomon: tangan menyapu di depan mata, dua jari ke pelipis sambil menunduk berkonsentrasi,
        // lalu (tick 5) kepala terangkat dan tangan terbuka saat mata menyala dan gelombang pemindai menyebar.
        CLIPS.put(ShazamAnim.SOLOMON_SIGHT, Clip.builder(18)
                .key(0, Ease.LINEAR).rightArm(-30, -10, 0).leftArm(3, 0, -5).head(3, 0, 0)
                .key(2.5f, Ease.OUT_CUBIC).rightArm(-118, -42, 0).head(10, 0, 0).twist(-8)
                .key(4, Ease.IN_OUT_SINE).rightArm(-145, -34, 0).leftArm(8, 0, -10).head(16, 0, 0).tilt(4).drop(0.04f).shake(0.8f)
                .key(5, Ease.OUT_BACK).rightArm(-132, -10, 18).leftArm(14, 0, -24).head(-12, 0, 0).tilt(-6).drop(-0.03f)
                        .twist(6).shake(0f)
                .key(12, Ease.LINEAR)
                .key(18, Ease.IN_OUT_SINE).rightArm(-10, 0, 6).leftArm(3, 0, -5).head(0, 0, 0).tilt(0).drop(0f).twist(0)
                .fade(3, 5).build());

        // H - Tepukan Hercules: kedua tangan dibentang lebar ke belakang sambil menjinjit dan menegang,
        // lalu (tick 5) ditepuk keras di depan sambil melangkah maju, badan terhentak, lalu kembali.
        CLIPS.put(ShazamAnim.HERCULES_CLAP, Clip.builder(14)
                .key(0, Ease.LINEAR).rightArm(-35, 25, 0).leftArm(-35, -25, 0).head(-2, 0, 0).tilt(-2)
                .key(3, Ease.OUT_CUBIC).rightArm(-82, 95, 8).leftArm(-82, -95, -8).head(-10, 0, 0).tilt(-12).drop(-0.06f)
                        .rightLeg(12, 0, 4).leftLeg(-14, 0, -4).shake(1.5f)
                .key(4.2f, Ease.LINEAR).rightArm(-84, 100, 8).leftArm(-84, -100, -8).shake(2.5f)
                .key(5, Ease.OUT_BACK).rightArm(-92, -20, 0).leftArm(-92, 20, 0).head(4, 0, 0).tilt(14).drop(0.1f)
                        .rightLeg(30, 0, 6).leftLeg(-40, 0, -6).shake(0f)
                .key(8, Ease.OUT_QUAD).rightArm(-84, -12, 0).leftArm(-84, 12, 0).tilt(9).drop(0.08f)
                .key(14, Ease.IN_OUT_SINE).rightArm(-20, 0, 6).leftArm(-20, 0, -6).head(0, 0, 0).tilt(0).drop(0f)
                        .rightLeg(0, 0, 0).leftLeg(0, 0, 0)
                .fade(2, 4).build());

        // A - Beban Langit Atlas di tanah: jongkok (tick 2), kedua kepalan diangkat menyangga langit (5), gemetar menahan beban
        // langit sementara bola langit jatuh dan musuh tersedot (5-12), menghentak ke atas (12), lalu (tick 13) dihantamkan ke
        // tanah (dilanjutkan ATLAS_IMPACT).
        CLIPS.put(ShazamAnim.ATLAS_GROUND, Clip.builder(17)
                .key(0, Ease.LINEAR).rightArm(-30, 0, 6).leftArm(-30, 0, -6).head(-5, 0, 0).tilt(-2)
                .key(2, Ease.OUT_QUAD).rightArm(10, 0, 20).leftArm(10, 0, -20).head(10, 0, 0).rightLeg(-30, 0, 4)
                        .leftLeg(-30, 0, -4).tilt(12).drop(0.18f)
                .key(5, Ease.OUT_CUBIC).rightArm(-170, 0, 16).leftArm(-170, 0, -16).head(-30, 0, 0).rightLeg(8, 0, 7)
                        .leftLeg(-8, 0, -7).tilt(-6).drop(0.04f).shake(1.2f)
                .key(9, Ease.IN_OUT_SINE).rightArm(-164, 0, 20).leftArm(-164, 0, -20).head(-22, 0, 0).tilt(-2).drop(0.17f)
                        .shake(2.8f)
                .key(12, Ease.OUT_QUAD).rightArm(-184, 0, 8).leftArm(-184, 0, -8).head(-34, 0, 0).tilt(-14).drop(-0.2f)
                        .shake(1.6f)
                .key(13.2f, Ease.IN_QUAD).rightArm(-118, 0, 10).leftArm(-118, 0, -10).head(-10, 0, 0).tilt(12).drop(0.12f)
                        .shake(0f)
                .fade(1, 3).build());

        // A - Atlas dari udara: menukik dengan kedua kepalan di atas kepala, makin rebah dan bergetar diterpa angin
        CLIPS.put(ShazamAnim.ATLAS_DIVE, Clip.builder(60)
                .key(0, Ease.OUT_CUBIC).rightArm(-168, 0, 12).leftArm(-168, 0, -12).head(-35, 0, 0)
                        .rightLeg(18, 0, 3).leftLeg(28, 0, -3).tilt(30)
                .key(6, Ease.IN_OUT_SINE).tilt(42).shake(1f)
                .fade(2, 6).build());

        // A - Atlas mendarat: kepalan menghantam tanah, satu lutut turun, badan terbenam lalu bangkit pelan
        CLIPS.put(ShazamAnim.ATLAS_IMPACT, Clip.builder(18)
                .key(0, Ease.OUT_QUAD).rightArm(-40, -14, 0).leftArm(-40, 14, 0).head(-28, 0, 0)
                        .rightLeg(-64, 0, 8).leftLeg(44, 0, -8).tilt(32).drop(0.48f).shake(1.6f)
                .key(2, Ease.OUT_CUBIC).rightArm(-34, -14, 0).leftArm(-34, 14, 0).tilt(36).drop(0.54f).shake(1f)
                .key(9, Ease.LINEAR).shake(0.3f)
                .key(13, Ease.IN_OUT_SINE).rightArm(-10, 0, 18).leftArm(-10, 0, -18).head(-10, 0, 0)
                        .rightLeg(-30, 0, 6).leftLeg(20, 0, -6).tilt(14).drop(0.22f).shake(0f)
                .key(18, Ease.IN_OUT_SINE).rightArm(6, 0, 18).leftArm(6, 0, -18).head(-5, 0, 0)
                        .rightLeg(0, 0, 6).leftLeg(0, 0, -6).tilt(0).drop(0f)
                .fade(1, 5).build());

        // H - Lemparan Hercules (Shift + X): meraih musuh di depan (tick 2), mengangkatnya ke atas kepala (6), menarik ke
        // belakang sambil gemetar menahan beratnya (8), lalu (tick 9) melemparnya sekuat tenaga sambil melangkah.
        CLIPS.put(ShazamAnim.HERCULES_THROW, Clip.builder(20)
                .key(0, Ease.LINEAR).rightArm(-60, -12, 0).leftArm(-60, 12, 0).head(4, 0, 0).tilt(6)
                .key(2, Ease.OUT_QUAD).rightArm(-96, -16, 0).leftArm(-96, 16, 0).head(12, 0, 0).tilt(18).drop(0.16f)
                        .rightLeg(-22, 0, 4).leftLeg(18, 0, -4).shake(1f)
                .key(6, Ease.OUT_CUBIC).rightArm(-176, 0, -14).leftArm(-176, 0, 14).head(-26, 0, 0).tilt(-8).drop(-0.04f)
                        .rightLeg(0, 0, 8).leftLeg(0, 0, -8).shake(2.2f)
                .key(8.2f, Ease.IN_QUAD).rightArm(-198, 0, -8).leftArm(-198, 0, 8).head(-16, 0, 0).tilt(-16).twist(10)
                        .shake(2.8f)
                .key(9.5f, Ease.OUT_BACK).rightArm(-58, 0, 0).leftArm(-58, 0, 0).head(6, 0, 0).tilt(22).drop(0.1f).twist(-12)
                        .rightLeg(-32, 0, 4).leftLeg(30, 0, -4).shake(0f)
                .key(13, Ease.LINEAR)
                .key(20, Ease.IN_OUT_SINE).rightArm(-12, 0, 6).leftArm(-12, 0, -6).head(0, 0, 0).tilt(0).drop(0f).twist(0)
                        .rightLeg(0, 0, 0).leftLeg(0, 0, 0)
                .fade(2, 5).build());

        // Ledakan Keberanian (akhir Perisai Achilles): mengepal menahan (tick 0-2), lalu kedua lengan menghentak ke samping
        // dan dada membusung saat damage yang ditahan perisai dilepas.
        CLIPS.put(ShazamAnim.ACHILLES_NOVA, Clip.builder(16)
                .key(0, Ease.OUT_CUBIC).rightArm(18, 0, 24).leftArm(18, 0, -24).head(16, 0, 0).tilt(10).drop(0.12f)
                        .rightLeg(-16, 0, 5).leftLeg(-16, 0, -5).shake(2.6f)
                .key(2, Ease.OUT_BACK).rightArm(-34, 0, 96).leftArm(-34, 0, -96).head(-30, 0, 0).tilt(-12).drop(-0.04f)
                        .rightLeg(0, 0, 10).leftLeg(0, 0, -10).shake(1f)
                .key(9, Ease.LINEAR).shake(0.4f)
                .key(16, Ease.IN_OUT_SINE).rightArm(4, 0, 12).leftArm(4, 0, -12).head(0, 0, 0).tilt(0).drop(0f)
                        .rightLeg(0, 0, 0).leftLeg(0, 0, 0).shake(0f)
                .fade(1, 5).build());

        // Z - Petir Zeus: tangan menyapu ke atas sambil pinggang berputar, menggapai langit (listrik berkumpul,
        // gemetar), sentakan kecil, lalu (tick 5, tepat saat petir pertama menyambar) mencambuk menunjuk sasaran sambil melangkah.
        CLIPS.put(ShazamAnim.ZEUS_CALL, Clip.builder(16)
                .key(0, Ease.LINEAR).rightArm(-30, 0, -6).leftArm(4, 0, -6).head(-5, 0, 0)
                .key(1.5f, Ease.OUT_QUAD).rightArm(-110, 30, 0).leftArm(15, 0, -14).head(-18, 0, 0).twist(18).tilt(-4)
                .key(3.2f, Ease.OUT_CUBIC).rightArm(-178, 0, -8).leftArm(22, 0, -18).head(-40, 0, 0).twist(10).tilt(-8)
                        .drop(-0.05f).shake(1.5f)
                .key(4.3f, Ease.IN_QUAD).rightArm(-165, 0, -6).shake(2.5f)
                .key(5, Ease.OUT_BACK).rightArm(-90, 0, 0).aim(1f).leftArm(35, 0, -22).head(0, 0, 0).twist(-14).tilt(8)
                        .drop(0.04f).rightLeg(-18, 0, 3).leftLeg(14, 0, -3).shake(0f)
                .key(10, Ease.LINEAR)
                .key(16, Ease.IN_OUT_SINE).rightArm(-60, 0, 0).aim(0.6f).twist(0).tilt(2).drop(0f).rightLeg(0, 0, 0).leftLeg(0, 0, 0)
                .fade(2, 5).build());

        // 0.27 Tangan Kahndaq (Black Adam): telapak kanan terangkat ke depan menahan proyektil (gemetar menahan tenaga).
        // Server mengulang klip ini tiap 15 tick selama masih ada yang tertahan, jadi klipnya MULAI dari pose terangkat
        // (perpindahan dari pose sebelumnya dihaluskan fade-in) dan baru turun kalau nggak diulang lagi.
        CLIPS.put(ShazamAnim.ADAM_HOLD, Clip.builder(22)
                .key(0, Ease.LINEAR).rightArm(-92, 0, 4).aim(1f).leftArm(12, 0, -14).head(6, 0, 0).twist(-10).shake(0.6f)
                .key(9, Ease.IN_OUT_SINE).rightArm(-88, 0, 2).aim(1f).shake(0.9f)
                .key(17, Ease.IN_OUT_SINE).rightArm(-92, 0, 4).aim(1f).shake(0.6f)
                .key(22, Ease.IN_OUT_SINE).rightArm(-30, 0, 0).aim(0f).leftArm(4, 0, -6).head(0, 0, 0).twist(0).shake(0f)
                .fade(3, 5).build());
        // ... lalu (tombol J) ditarik sedikit ke dalam dan dikibaskan keluar: semua proyektil melesat balik
        CLIPS.put(ShazamAnim.ADAM_RELEASE, Clip.builder(14)
                .key(0, Ease.LINEAR).rightArm(-90, 0, 4).aim(1f).leftArm(12, 0, -14).twist(-10)
                .key(1.5f, Ease.IN_QUAD).rightArm(-100, 0, -30).aim(0.6f).twist(-22).head(4, 0, 0)
                .key(3, Ease.OUT_BACK).rightArm(-85, 0, 80).aim(0f).twist(24).head(-6, 0, 0).shake(1.2f)
                .key(8, Ease.LINEAR).rightArm(-70, 0, 70).twist(16).shake(0f)
                .key(14, Ease.IN_OUT_SINE).rightArm(-20, 0, 8).leftArm(4, 0, -6).twist(0).head(0, 0, 0)
                .fade(1, 5).build());

        // 0.26 Kekuatan Keluarga: menghimpun tenaga (tick 3), kepalan kanan ke langit (tick 7) sambil tautan petir menyambung
        // ke keluarga, tick 10 petir menyambar semuanya: tersentak, lalu kedua lengan terbuka lebar menyambut keluarga.
        CLIPS.put(ShazamAnim.FAMILY_CALL, Clip.builder(30)
                .key(0, Ease.LINEAR).rightArm(-20, 0, -4).leftArm(4, 0, -6).head(-5, 0, 0).legs(3).tilt(0)
                .key(3, Ease.OUT_CUBIC).rightArm(18, 0, 14).leftArm(18, 0, -14).head(12, 0, 0).legs(9).tilt(12).drop(0.14f)
                .key(7, Ease.OUT_QUAD).rightArm(-178, 0, -6).leftArm(25, 0, -14).head(-42, 0, 0).legs(6).tilt(-10).drop(-0.06f)
                        .shake(1.2f)
                .key(10, Ease.IN_OUT_SINE).rightArm(-183, 0, -4).leftArm(28, 0, -16).head(-48, 0, 0).tilt(-12).drop(-0.08f)
                        .shake(2.4f)
                .key(12, Ease.OUT_QUAD).head(-20, 0, 0).tilt(-3).drop(0.1f).shake(0f)
                .key(16, Ease.OUT_CUBIC).rightArm(-140, 0, -48).leftArm(-140, 0, 48).head(-28, 0, 0).legs(10).tilt(-10).drop(-0.2f)
                .key(23, Ease.IN_OUT_SINE).rightArm(-145, 0, -50).leftArm(-145, 0, 50).head(-30, 0, 0).tilt(-8).drop(-0.22f)
                .key(29, Ease.IN_OUT_SINE).rightArm(-20, 0, 30).leftArm(-20, 0, -30).head(4, 0, 0).legs(8).tilt(4).drop(0.06f)
                .fade(2, 5).build());

        // A - Kulit Achilles: membungkuk dalam dengan kepalan mengepal, gemetar makin hebat, lalu (tick 4) meraung
        // dengan dada membusung dan lengan menghentak ke samping, tetap bergetar.
        CLIPS.put(ShazamAnim.ACHILLES_ROAR, Clip.builder(22)
                .key(0, Ease.OUT_CUBIC).rightArm(20, 0, 22).leftArm(20, 0, -22).head(22, 0, 0).tilt(14).drop(0.16f)
                        .rightLeg(-24, 0, 6).leftLeg(-24, 0, -6).shake(1.5f)
                .key(3.5f, Ease.IN_QUAD).rightArm(32, 0, 28).leftArm(32, 0, -28).head(26, 0, 0).tilt(18).drop(0.24f).shake(3f)
                .key(4, Ease.OUT_BACK).rightArm(22, 0, 64).leftArm(22, 0, -64).head(-42, 0, 0).tilt(-16).drop(-0.04f)
                        .rightLeg(0, 0, 10).leftLeg(0, 0, -10).shake(1.2f)
                .key(16, Ease.LINEAR).shake(0.8f)
                .key(22, Ease.IN_OUT_SINE).rightArm(4, 0, 14).leftArm(4, 0, -14).head(-5, 0, 0).tilt(-2).drop(0f)
                        .rightLeg(0, 0, 0).leftLeg(0, 0, 0).shake(0f)
                .fade(2, 5).build());

        // M - Kilat Mercury: menerjang dengan tinju di depan, badan rebah rendah, lalu tergelincir berhenti dengan
        // kaki depan menahan dan lengan terbuka menjaga keseimbangan.
        CLIPS.put(ShazamAnim.MERCURY_BLITZ, Clip.builder(12)
                .key(0, Ease.OUT_CUBIC).rightArm(-82, -8, 0).leftArm(62, 0, -14).rightLeg(-40, 0, 0).leftLeg(46, 0, 0)
                        .head(-30, 0, 0).tilt(36).twist(-10).drop(0.08f)
                .key(6, Ease.LINEAR).shake(1f)
                .key(8, Ease.OUT_QUAD).rightArm(-40, 0, 30).leftArm(-30, 0, -36).rightLeg(-34, 0, 6).leftLeg(20, 0, -6)
                        .head(-6, 0, 0).tilt(-12).twist(8).drop(0.12f).shake(0f)
                .key(12, Ease.IN_OUT_SINE).rightArm(-10, 0, 5).leftArm(10, 0, -5).rightLeg(0, 0, 0).leftLeg(0, 0, 0)
                        .head(-5, 0, 0).tilt(2).twist(0).drop(0f)
                .fade(1, 4).build());

        // ---- Mode Kilat Mercury. Pukulan-pukulannya pendek (pukulan berikutnya bisa datang 2-3 tick kemudian):
        // klip lama memudar ke klip baru (ShazamPoses), jadi rangkaian pukulan menyambung seperti satu kombo.

        // Menyala: kuda-kuda rendah, kepalan mengepal dan badan gemetar menahan listrik, lalu (tick 6) menghentak
        // tegak dengan lengan terbuka saat listrik meledak dari badan.
        CLIPS.put(ShazamAnim.MERCURY_ON, Clip.builder(16)
                .key(0, Ease.OUT_CUBIC).rightArm(15, 0, 15).leftArm(15, 0, -15).head(18, 0, 0).tilt(12).drop(0.14f)
                        .rightLeg(-20, 0, 5).leftLeg(-20, 0, -5).shake(1.5f)
                .key(5, Ease.IN_QUAD).rightArm(28, 0, 20).leftArm(28, 0, -20).head(24, 0, 0).tilt(16).drop(0.2f).shake(3.5f)
                .key(6, Ease.OUT_BACK).rightArm(30, 0, 55).leftArm(30, 0, -55).head(-25, 0, 0).tilt(-8).drop(-0.04f)
                        .rightLeg(0, 0, 9).leftLeg(0, 0, -9).shake(1.2f)
                .key(11, Ease.LINEAR).shake(0.6f)
                .key(16, Ease.IN_OUT_SINE).rightArm(-25, 0, 12).leftArm(-25, 0, -12).head(0, 0, 0).tilt(6).drop(0.02f)
                        .rightLeg(0, 0, 4).leftLeg(0, 0, -4).shake(0f)
                .fade(2, 4).build());

        // Mati: lengan dikibaskan melepas sisa listrik.
        CLIPS.put(ShazamAnim.MERCURY_OFF, Clip.builder(10)
                .key(0, Ease.OUT_QUAD).rightArm(-10, 0, 22).leftArm(-10, 0, -22).head(6, 0, 0).shake(2.2f)
                .key(4, Ease.LINEAR).shake(0.6f)
                .key(10, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).shake(0f)
                .fade(1, 4).build());

        // Jab kanan: kepalan ditarik, lalu (tick 1) dilontarkan lurus sambil pinggang berputar dan kaki melangkah.
        CLIPS.put(ShazamAnim.MERCURY_JAB, Clip.builder(9)
                .key(0, Ease.LINEAR).rightArm(-55, 0, 12).leftArm(-50, 15, -10).head(0, 0, 0).twist(10).tilt(12)
                .key(1.2f, Ease.OUT_BACK).rightArm(-93, -6, 0).leftArm(-35, 20, -14).twist(-16).tilt(18).drop(0.04f)
                        .rightLeg(-12, 0, 2).leftLeg(16, 0, -2)
                .key(3, Ease.LINEAR)
                .key(9, Ease.IN_OUT_SINE).rightArm(-35, 0, 8).leftArm(-35, 0, -8).twist(0).tilt(8).drop(0f)
                        .rightLeg(0, 0, 0).leftLeg(0, 0, 0)
                .fade(0.6f, 3).build());

        // Cross kiri: kebalikan jab.
        CLIPS.put(ShazamAnim.MERCURY_CROSS, Clip.builder(9)
                .key(0, Ease.LINEAR).leftArm(-55, 0, -12).rightArm(-50, -15, 10).head(0, 0, 0).twist(-10).tilt(12)
                .key(1.2f, Ease.OUT_BACK).leftArm(-93, 6, 0).rightArm(-35, -20, 14).twist(16).tilt(18).drop(0.04f)
                        .leftLeg(-12, 0, -2).rightLeg(16, 0, 2)
                .key(3, Ease.LINEAR)
                .key(9, Ease.IN_OUT_SINE).rightArm(-35, 0, 8).leftArm(-35, 0, -8).twist(0).tilt(8).drop(0f)
                        .rightLeg(0, 0, 0).leftLeg(0, 0, 0)
                .fade(0.6f, 3).build());

        // Hook kanan: lengan dari samping menyapu mendatar ke depan dengan putaran pinggang yang lebar.
        CLIPS.put(ShazamAnim.MERCURY_HOOK, Clip.builder(9)
                .key(0, Ease.LINEAR).rightArm(-80, 55, 10).leftArm(-45, 15, -10).head(0, 0, 0).twist(22).tilt(10)
                .key(1.3f, Ease.OUT_BACK).rightArm(-88, -35, 0).leftArm(-40, 20, -14).twist(-28).tilt(14).lean(-6)
                        .rightLeg(-8, 0, 4).leftLeg(10, 0, -4)
                .key(3, Ease.LINEAR)
                .key(9, Ease.IN_OUT_SINE).rightArm(-35, 0, 8).leftArm(-35, 0, -8).twist(0).tilt(8).lean(0)
                        .rightLeg(0, 0, 0).leftLeg(0, 0, 0)
                .fade(0.6f, 3).build());

        // Tendangan kanan: kaki diangkat lurus ke depan, badan condong ke belakang, lengan terbuka menjaga keseimbangan.
        CLIPS.put(ShazamAnim.MERCURY_KICK, Clip.builder(10)
                .key(0, Ease.LINEAR).rightLeg(-30, 0, 6).rightArm(-20, 0, 25).leftArm(-50, 0, -20).head(0, 0, 0).tilt(-4)
                .key(1.4f, Ease.OUT_BACK).rightLeg(-100, 0, 10).leftLeg(6, 0, -3).rightArm(25, 0, 35).leftArm(-60, 0, -30)
                        .tilt(-14).lean(-8).drop(0.05f)
                .key(3.2f, Ease.LINEAR)
                .key(10, Ease.IN_OUT_SINE).rightLeg(0, 0, 0).leftLeg(0, 0, 0).rightArm(-30, 0, 8).leftArm(-30, 0, -8)
                        .tilt(6).lean(0).drop(0f)
                .fade(0.6f, 3).build());

        // Lepas landas: jongkok mengumpulkan tenaga, lalu melesat dengan kepalan ke atas
        CLIPS.put(ShazamAnim.LAUNCH, Clip.builder(16)
                .key(0, Ease.OUT_QUAD).rightArm(22, 0, 12).leftArm(22, 0, -12).head(12, 0, 0)
                        .rightLeg(-35, 0, 4).leftLeg(-20, 0, -4).tilt(14).drop(0.28f).shake(1f)
                .key(4, Ease.OUT_QUAD).rightArm(-178, 0, -6).leftArm(15, 0, -12).head(-30, 0, 0)
                        .rightLeg(8, 0, 2).leftLeg(16, 0, -2).tilt(-4).drop(-0.1f).shake(0f)
                .key(10, Ease.LINEAR)
                .key(16, Ease.IN_OUT_SINE).rightArm(-60, 0, 10).leftArm(10, 0, -10).head(-10, 0, 0)
                        .rightLeg(5, 0, 2).leftLeg(10, 0, -2).tilt(0).drop(0f)
                .fade(1, 6).build());

        // Mendarat pelan: lutut menekuk sedikit
        CLIPS.put(ShazamAnim.LAND_SOFT, Clip.builder(10)
                .key(0, Ease.OUT_QUAD).rightArm(-25, 0, 22).leftArm(-25, 0, -22).head(5, 0, 0)
                        .rightLeg(-25, 0, 6).leftLeg(-12, 0, -6).tilt(10).drop(0.2f)
                .key(10, Ease.IN_OUT_SINE).rightArm(0, 0, 8).leftArm(0, 0, -8).head(0, 0, 0)
                        .rightLeg(0, 0, 4).leftLeg(0, 0, -4).tilt(0).drop(0f)
                .fade(1, 4).build());

        // Hero landing: satu lutut turun, kepalan menghantam tanah, lengan lain ke belakang, badan bergetar sesaat
        CLIPS.put(ShazamAnim.LAND_HERO, Clip.builder(28)
                .key(0, Ease.OUT_QUAD).rightArm(-28, -10, 8).leftArm(48, 0, -38).head(-38, 0, 0)
                        .rightLeg(-78, 0, 10).leftLeg(58, 0, -10).tilt(34).drop(0.58f).shake(1.5f)
                .key(6, Ease.LINEAR).shake(0f)
                .key(14, Ease.LINEAR)
                .key(28, Ease.IN_OUT_SINE).rightArm(10, 0, 24).leftArm(10, 0, -24).head(-8, 0, 0)
                        .rightLeg(0, 0, 8).leftLeg(0, 0, -8).tilt(-3).drop(0f)
                .fade(1, 6).build());

        // Menabrak: lengan menahan di depan muka, badan terpental ke belakang dan sedikit terpelintir
        CLIPS.put(ShazamAnim.CRASH, Clip.builder(18)
                .key(0, Ease.OUT_QUAD).rightArm(-115, -28, 0).leftArm(-115, 28, 0).head(18, 0, 0)
                        .rightLeg(-20, 0, 6).leftLeg(10, 0, -6).tilt(-22).drop(0.08f).twist(12).shake(2f)
                .key(6, Ease.OUT_CUBIC).tilt(-12).twist(4).shake(0f)
                .key(18, Ease.IN_OUT_SINE).rightArm(0, 0, 8).leftArm(0, 0, -8).head(0, 0, 0)
                        .rightLeg(0, 0, 4).leftLeg(0, 0, -4).tilt(0).drop(0f).twist(0)
                .fade(1, 5).build());
    }

    // ================================================================== Black Adam

    static {
        // Memanggil dewa-dewa Mesir: berdiri tegak seperti patung firaun, kedua lengan menyilang di dada (pose Osiris),
        // kepala sedikit tertunduk. Tiap dewa yang tiba membuat badan tersentak kecil. Mulai dewa ketiga lengan pelan-pelan
        // terbuka menerima kekuatan, telapak menghadap ke atas, kepala makin terangkat; menjelang akhir gemetar.
        Clip.Builder summon = Clip.builder(ShazamAnim.SUMMON_TICKS)
                .key(0, Ease.LINEAR).rightArm(-10, 0, 8).leftArm(-10, 0, -8).head(6, 0, 0).tilt(0)
                .key(7, Ease.OUT_CUBIC).rightArm(-68, -40, 0).leftArm(-68, 40, 0).head(14, 0, 0).legs(2).tilt(1).drop(0.02f);
        for (int i = 0; i < GodShow.ARRIVE.length; i++) {
            float u = i / (float) (GodShow.ARRIVE.length - 1);
            float at = GodShow.ARRIVE[i];
            if (i < 2) {   // dua dewa pertama: lengan tetap menyilang, cuma tersentak
                summon.key(at - 1.5f, Ease.IN_OUT_SINE).rightArm(-68, -40, 0).leftArm(-68, 40, 0).head(14 - 4 * i, 0, 0).shake(0f)
                        .key(at + 1, Ease.OUT_BACK).rightArm(-74, -42, 0).leftArm(-74, 42, 0).head(8 - 4 * i, 0, 0).tilt(-2)
                        .drop(-0.02f).shake(0.6f)
                        .key(at + 6, Ease.IN_OUT_SINE).rightArm(-70, -40, 0).leftArm(-70, 40, 0).head(11 - 4 * i, 0, 0).tilt(0)
                        .drop(0f).shake(0.12f);
                continue;
            }
            float w = (i - 2) / (float) (GodShow.ARRIVE.length - 3);   // 0..1 dari dewa ketiga sampai keenam
            float head = 4f - 34f * w;
            float open = 30f + 40f * w;
            float fwd = -40f + 14f * w;
            summon.key(at - 1.5f, Ease.IN_OUT_SINE).rightArm(fwd, 0, open).leftArm(fwd, 0, -open).head(head + 3, 0, 0)
                    .legs(3).tilt(2 - 8 * u).drop(0.02f - 0.14f * u).shake(0f)
                    .key(at + 1, Ease.OUT_BACK).rightArm(fwd - 8, 0, open + 8).leftArm(fwd - 8, 0, -open - 8).head(head - 7, 0, 0)
                    .tilt(-3 - 8 * u).drop(-0.04f - 0.14f * u).shake(0.8f)
                    .key(at + 6, Ease.IN_OUT_SINE).rightArm(fwd - 3, 0, open + 3).leftArm(fwd - 3, 0, -open - 3).head(head - 2, 0, 0)
                    .tilt(-8 * u).drop(-0.14f * u).shake(0.15f);
        }
        float end = ShazamAnim.SUMMON_TICKS;
        float settled = GodShow.ARRIVE[GodShow.ARRIVE.length - 1] + 6;
        summon.key(Math.min(end - 0.5f, Math.max(settled + 1, end - 4)), Ease.IN_OUT_SINE)
                .rightArm(-28, 0, 74).leftArm(-28, 0, -74).head(-32, 0, 0).legs(3).tilt(-9).drop(-0.18f).shake(1.0f)
                .key(end, Ease.IN_OUT_SINE)
                .rightArm(-28, 0, 72).leftArm(-28, 0, -72).head(-32, 0, 0).tilt(-9).drop(-0.18f).shake(1.4f);
        ADAM.put(ShazamAnim.SUMMON, summon.fade(4, 3).build());

        // Berubah: lengan kembali menyilang di dada sambil merunduk mengumpulkan tenaga, lalu kepalan kanan ke langit
        // (tick 7) sementara tangan kiri tetap di dada, gemetar menahan petir yang turun (8-18). Petir mengenai:
        // terangkat dengan lengan terentang, lalu turun dan berdiri buas: kepalan mengepal di samping, kepala sedikit
        // tertunduk menatap tajam, kaki terbuka lebar.
        ADAM.put(ShazamAnim.TRANSFORM, Clip.builder(54)
                .key(0, Ease.LINEAR).rightArm(-28, 0, 70).leftArm(-28, 0, -70).head(-30, 0, 0).legs(3).tilt(-8).drop(-0.15f)
                .key(3, Ease.OUT_CUBIC).rightArm(-64, -40, 0).leftArm(-64, 40, 0).head(16, 0, 0).legs(9).tilt(14).drop(0.18f)
                        .shake(0.6f)
                .key(7, Ease.OUT_QUAD).rightArm(-178, 0, -6).leftArm(-72, 36, 0).head(-42, 0, 0).legs(6).tilt(-10).drop(-0.06f)
                        .shake(0.9f)
                .key(12, Ease.IN_OUT_SINE).rightArm(-183, 0, -4).leftArm(-76, 38, 0).head(-48, 0, 0).tilt(-12).drop(-0.08f)
                        .shake(1.9f)
                .key(17, Ease.IN_OUT_SINE).rightArm(-177, 0, -7).leftArm(-72, 36, 0).head(-44, 0, 0).tilt(-10).drop(-0.05f)
                        .shake(2.8f)
                .key(19, Ease.OUT_QUAD).head(-18, 0, 0).tilt(-3).drop(0.12f).shake(0f)
                .key(24, Ease.OUT_CUBIC).rightArm(-100, 0, -78).leftArm(-100, 0, 78).head(-34, 0, 0).legs(10).tilt(-14).drop(-0.38f)
                .key(36, Ease.IN_OUT_SINE).rightArm(-104, 0, -82).leftArm(-104, 0, 82).head(-38, 0, 0).tilt(-9).drop(-0.44f)
                .key(43, Ease.IN_OUT_SINE).rightArm(14, 0, 22).leftArm(14, 0, -22).head(14, 0, 0).legs(12).tilt(9).drop(0.16f)
                        .shake(0.3f)
                .key(50, Ease.OUT_CUBIC).rightArm(6, 0, 16).leftArm(6, 0, -16).head(8, 0, 0).legs(11).tilt(4).drop(0.04f).shake(0f)
                .fade(2, 6).build());

        // ===== Skill Black Adam (0.22: gerakan lebih tebal & sinematik, ancang-ancang besar, hantaman, tahanan) =====

        // S - Badai Shu: menarik napas dewa udara (lengan menyilang rendah, badan merunduk), lalu (tick 5) lengan
        // menghentak terbentang dan terangkat menyangga langit; badan terangkat dan berayun pelan dihantam badai; di akhir
        // kedua lengan menghempas ke bawah-samping saat badai meledak ke luar.
        float shuEnd = ShazamAnim.CAST_WINDUP + ShazamAnim.SHU_TICKS;
        putSkill(ShazamAnim.ADAM_SHU, Clip.builder(shuEnd + 12)
                .key(0, Ease.OUT_CUBIC).rightArm(-10, 0, 14).leftArm(-10, 0, -14).head(8, 0, 0).tilt(4).drop(0.06f)
                .key(3, Ease.IN_QUAD).rightArm(-44, -34, 0).leftArm(-44, 34, 0).head(18, 0, 0).legs(6).tilt(14).drop(0.2f)
                        .shake(1.1f)
                .key(ShazamAnim.CAST_WINDUP, Ease.OUT_BACK).rightArm(-4, 0, 98).leftArm(-4, 0, -98).head(-16, 0, 0).legs(11)
                        .tilt(-8).drop(-0.06f).shake(0.4f)
                .key(13, Ease.IN_OUT_SINE).rightArm(0, 0, 152).leftArm(0, 0, -152).head(-32, 0, 0).legs(9).tilt(-9)
                        .drop(-0.3f).lean(4).spin(14).shake(0.6f)
                .key(26, Ease.IN_OUT_SINE).rightArm(0, 0, 156).leftArm(0, 0, -150).head(-34, 0, 0).lean(-5).spin(-12)
                        .drop(-0.38f).shake(0.9f)
                .key(40, Ease.IN_OUT_SINE).rightArm(0, 0, 150).leftArm(0, 0, -156).head(-30, 0, 0).lean(4).spin(10)
                        .drop(-0.42f).shake(1.3f)
                .key(shuEnd - 3, Ease.IN_QUAD).rightArm(-6, 0, 160).leftArm(-6, 0, -160).head(-38, 0, 0).lean(0).spin(0)
                        .drop(-0.46f).shake(2.2f)
                .key(shuEnd, Ease.OUT_QUAD).rightArm(-24, 0, 58).leftArm(-24, 0, -58).head(14, 0, 0).legs(14).tilt(16)
                        .drop(0.24f).shake(3.0f)
                .key(shuEnd + 5, Ease.LINEAR).shake(0.8f)
                .key(shuEnd + 12, Ease.IN_OUT_SINE).rightArm(0, 0, 8).leftArm(0, 0, -8).head(0, 0, 0).legs(2).tilt(0)
                        .drop(0f).shake(0f)
                .fade(2, 5).build());

        // H - Sambaran Heru: merunduk rendah dengan lengan terlipat ke belakang seperti sayap elang (gemetar menahan
        // tenaga), lalu (tick 3) melesat: badan nyaris mendatar, lengan tersapu ke belakang di sisi badan, kaki lurus
        // ke belakang, kepala menatap ke depan. Di ujung sayap (lengan) terbentang lebar mengerem, badan menegak, lalu
        // mendarat merunduk.
        float heruEnd = ShazamAnim.HERU_WINDUP + ShazamAnim.HERU_TICKS;
        putSkill(ShazamAnim.ADAM_HERU, Clip.builder(heruEnd + 12)
                .key(0, Ease.OUT_CUBIC).rightArm(36, 0, 26).leftArm(36, 0, -26).head(4, 0, 0).legs(10).tilt(28).drop(0.34f)
                        .shake(1.6f)
                .key(ShazamAnim.HERU_WINDUP, Ease.OUT_QUAD).rightArm(72, 0, 16).leftArm(72, 0, -16).head(-62, 0, 0)
                        .rightLeg(14, 0, 3).leftLeg(22, 0, -3).tilt(76).drop(-0.08f).shake(0f)
                .key(heruEnd - 1, Ease.LINEAR).rightArm(76, 0, 14).leftArm(76, 0, -14).head(-64, 0, 0).tilt(78)
                .key(heruEnd + 1, Ease.OUT_BACK).rightArm(-26, 0, 96).leftArm(-26, 0, -96).head(-8, 0, 0)
                        .rightLeg(-34, 0, 8).leftLeg(10, 0, -8).tilt(-20).drop(0.02f).shake(1.2f)
                .key(heruEnd + 4, Ease.OUT_QUAD).rightArm(6, 0, 40).leftArm(6, 0, -40).head(12, 0, 0)
                        .rightLeg(-30, 0, 8).leftLeg(20, 0, -8).tilt(14).drop(0.3f).shake(0.4f)
                .key(heruEnd + 12, Ease.IN_OUT_SINE).rightArm(0, 0, 8).leftArm(0, 0, -8).head(0, 0, 0)
                        .rightLeg(0, 0, 2).leftLeg(0, 0, -2).tilt(0).drop(0f).shake(0f)
                .fade(1, 5).build());

        // A - Tinju Amon: merunduk menarik kedua kepalan ke belakang, melonjak tinggi dengan kepalan menyatu di atas
        // kepala dan badan melengkung ke belakang (tick 3), menukik (tick 6), lalu (tick 7) menghantam tanah: berlutut,
        // badan membungkuk dalam, gemetar hebat menahan getaran; bangkit pelan saat tanah terbelah merambat.
        putSkill(ShazamAnim.ADAM_AMON, Clip.builder(32)
                .key(0, Ease.OUT_CUBIC).rightArm(32, 0, 22).leftArm(32, 0, -22).head(10, 0, 0).legs(8).tilt(14).drop(0.2f)
                        .shake(1.0f)
                .key(3, Ease.OUT_CUBIC).rightArm(-178, 0, -12).leftArm(-178, 0, 12).head(-20, 0, 0)
                        .rightLeg(-34, 0, 4).leftLeg(16, 0, -4).tilt(-16).drop(-0.62f).shake(0.4f)
                .key(6, Ease.IN_QUAD).rightArm(-150, 0, -10).leftArm(-150, 0, 10).head(6, 0, 0).tilt(22).drop(-0.24f)
                        .shake(0.8f)
                .key(ShazamAnim.AMON_WINDUP, Ease.OUT_QUAD).rightArm(-28, 0, -10).leftArm(-28, 0, 10).head(26, 0, 0)
                        .rightLeg(-62, 0, 6).leftLeg(42, 0, -6).tilt(62).drop(0.86f).shake(3.4f)
                .key(10, Ease.LINEAR).shake(1.6f)
                .key(17, Ease.LINEAR).rightArm(-26, 0, -8).leftArm(-26, 0, 8).head(22, 0, 0).tilt(58).drop(0.82f).shake(0.9f)
                .key(26, Ease.IN_OUT_SINE).rightArm(6, 0, 18).leftArm(6, 0, -18).head(4, 0, 0)
                        .rightLeg(0, 0, 4).leftLeg(0, 0, -4).tilt(4).drop(0.04f).shake(0f)
                .key(32, Ease.IN_OUT_SINE).rightArm(0, 0, 8).leftArm(0, 0, -8).head(0, 0, 0).tilt(0).drop(0f)
                .fade(1, 5).build());

        // Z - Segel Zehuti: dua jari ke pelipis sambil menunduk, mata mulai menyala; tangan kiri terangkat setengah
        // dengan telapak terbuka seperti membaca gulungan. Lalu (tick 5) melangkah maju, tangan kanan menunjuk lurus
        // (mengikuti pandangan) dan tangan kiri terlempar ke belakang, pinggang berputar.
        putSkill(ShazamAnim.ADAM_ZEHUTI, Clip.builder(26)
                .key(0, Ease.OUT_CUBIC).rightArm(-142, -46, 0).leftArm(-38, 20, -12).head(12, 0, 0).tilt(4).shake(0.4f)
                .key(4, Ease.IN_OUT_SINE).rightArm(-148, -50, 0).leftArm(-52, 26, -10).head(18, 0, 0).drop(0.06f)
                        .shake(1.2f)
                .key(ShazamAnim.CAST_WINDUP, Ease.OUT_BACK).rightArm(-92, 0, 0).aim(1f).leftArm(26, 0, -52).head(-6, 0, 0)
                        .rightLeg(-24, 0, 4).leftLeg(16, 0, -4).twist(-22).tilt(8).drop(0.08f).shake(0f)
                .key(15, Ease.LINEAR).rightArm(-90, 0, 0).aim(1f).twist(-18)
                .key(26, Ease.IN_OUT_SINE).rightArm(-10, 0, 6).aim(0f).leftArm(-4, 0, -6).head(0, 0, 0)
                        .rightLeg(0, 0, 2).leftLeg(0, 0, -2).twist(0).tilt(0).drop(0f)
                .fade(2, 5).build());

        // A - Sinar Aton: kedua telapak mengumpulkan cahaya di depan dada, lalu telapak kanan menghentak ke langit
        // tempat cakram matahari terbentuk; tangan kiri terbuka ke samping, kepala mendongak menatap cakram, badan
        // berjinjit. Tiap sinar melesat, badan tersentak (gemetar berdenyut).
        float atonEnd = ShazamAnim.ATON_WINDUP + ShazamAnim.ATON_GAP * 6;
        putSkill(ShazamAnim.ADAM_ATON, Clip.builder(atonEnd + 16)
                .key(0, Ease.LINEAR).rightArm(-20, 0, 6).leftArm(-10, 0, -8).head(0, 0, 0)
                .key(4, Ease.OUT_CUBIC).rightArm(-58, -24, 0).leftArm(-58, 24, 0).head(10, 0, 0).tilt(6).drop(0.1f)
                        .shake(1.0f)
                .key(7, Ease.OUT_BACK).rightArm(-182, 0, -6).leftArm(-18, 0, -48).head(-40, 0, 0).legs(8).tilt(-10)
                        .drop(-0.1f).shake(1.4f)
                .key(ShazamAnim.ATON_WINDUP, Ease.LINEAR).shake(2.2f)
                .key(ShazamAnim.ATON_WINDUP + 3, Ease.LINEAR).tilt(-12).shake(1.6f)
                .key(ShazamAnim.ATON_WINDUP + 6, Ease.LINEAR).tilt(-9).shake(2.0f)
                .key(atonEnd, Ease.LINEAR).tilt(-11).shake(1.6f)
                .key(atonEnd + 6, Ease.IN_OUT_SINE).rightArm(-176, 0, -6).head(-34, 0, 0).tilt(-6).shake(0.6f)
                .key(atonEnd + 16, Ease.IN_OUT_SINE).rightArm(-10, 0, 8).leftArm(-6, 0, -8).head(0, 0, 0).legs(2).tilt(0)
                        .drop(0f).shake(0f)
                .fade(2, 5).build());

        // M - Lilitan Mehen: lengan menyilang di dada (pose Osiris), pinggang berpilin dan badan merunduk saat ular
        // naik membelit, lalu (tick 6) kedua lengan menghentak terbuka ke bawah-samping, dada membusung, kepala mendongak.
        putSkill(ShazamAnim.ADAM_MEHEN, Clip.builder(28)
                .key(0, Ease.OUT_CUBIC).rightArm(-66, -40, 0).leftArm(-66, 40, 0).head(14, 0, 0).tilt(4).drop(0.08f)
                .key(5, Ease.IN_OUT_SINE).rightArm(-72, -44, 0).leftArm(-72, 44, 0).head(18, 0, 0).twist(20).drop(0.14f)
                        .shake(1.4f)
                .key(ShazamAnim.MEHEN_WINDUP, Ease.OUT_BACK).rightArm(-8, 0, 74).leftArm(-8, 0, -74).head(-26, 0, 0)
                        .legs(11).twist(0).tilt(-10).drop(-0.08f).shake(0.8f)
                .key(16, Ease.LINEAR).rightArm(-6, 0, 66).leftArm(-6, 0, -66).head(-20, 0, 0).shake(0.2f)
                .key(28, Ease.IN_OUT_SINE).rightArm(2, 0, 12).leftArm(2, 0, -12).head(0, 0, 0).legs(3).tilt(0).drop(0f)
                        .shake(0f)
                .fade(2, 5).build());

        // Murka Kahndaq: membungkuk, kepalan mengepal di samping, gemetar makin hebat sementara petir dari langit
        // terhisap ke badan; lalu (tick 10) meraung: lengan terlempar ke bawah-samping, dada membusung, kepala terlempar
        // ke belakang, badan terangkat dari tanah.
        putSkill(ShazamAnim.ADAM_RAGE, Clip.builder(34)
                .key(0, Ease.OUT_CUBIC).rightArm(12, 0, 16).leftArm(12, 0, -16).head(18, 0, 0).tilt(8).drop(0.06f).shake(1.4f)
                .key(6, Ease.IN_QUAD).rightArm(24, 0, 22).leftArm(24, 0, -22).head(28, 0, 0).legs(8).tilt(16).drop(0.22f)
                        .shake(4.2f)
                .key(9.5f, Ease.IN_QUAD).rightArm(28, 0, 18).leftArm(28, 0, -18).tilt(18).drop(0.26f).shake(5.6f)
                .key(ShazamAnim.ADAM_RAGE_WINDUP, Ease.OUT_BACK).rightArm(30, 0, 64).leftArm(30, 0, -64).head(-58, 0, 0)
                        .legs(12).tilt(-20).drop(-0.34f).shake(2.6f)
                .key(20, Ease.LINEAR).drop(-0.3f).shake(1.6f)
                .key(34, Ease.IN_OUT_SINE).rightArm(8, 0, 16).leftArm(8, 0, -16).head(-6, 0, 0).legs(3).tilt(-2).drop(0f)
                        .shake(0f)
                .fade(2, 5).build());

        // M (Black Adam) - Panggil Petir Kahndaq: menatap langit, kepalan kanan terangkat lurus ke langit sementara
        // kepalan kiri mengepal di samping, gemetar menunggu petir (sampai tick 12). Petir menyambar: badan tersentak
        // terangkat, lalu kedua lengan terbentang menyerap petir, dan kembali berdiri buas.
        putSkill(ShazamAnim.ADAM_CALL, Clip.builder(36)
                .key(0, Ease.OUT_CUBIC).rightArm(-96, 0, 12).leftArm(8, 0, -16).head(-18, 0, 0).tilt(2)
                .key(6, Ease.OUT_BACK).rightArm(-180, 0, -4).leftArm(14, 0, -22).head(-42, 0, 0).legs(7).tilt(-6)
                        .drop(-0.04f).shake(1.0f)
                .key(ShazamAnim.ADAM_CALL_WINDUP - 1, Ease.IN_QUAD).rightArm(-184, 0, -4).head(-46, 0, 0).shake(2.8f)
                .key(ShazamAnim.ADAM_CALL_WINDUP, Ease.OUT_QUAD).rightArm(-178, 0, -2).head(-30, 0, 0).tilt(-14).drop(-0.22f)
                        .shake(3.6f)
                .key(ShazamAnim.ADAM_CALL_WINDUP + 4, Ease.OUT_CUBIC).rightArm(-24, 0, 88).leftArm(-24, 0, -88)
                        .head(-26, 0, 0).legs(12).tilt(-12).drop(-0.3f).shake(1.8f)
                .key(ShazamAnim.ADAM_CALL_WINDUP + 14, Ease.IN_OUT_SINE).rightArm(-18, 0, 80).leftArm(-18, 0, -80)
                        .drop(-0.2f).shake(0.8f)
                .key(36, Ease.IN_OUT_SINE).rightArm(6, 0, 16).leftArm(6, 0, -16).head(4, 0, 0).legs(8).tilt(2).drop(0f)
                        .shake(0f)
                .fade(2, 6).build());

        // Lepas landas Black Adam: merunduk dalam dengan kepalan bergetar di sisi badan, lalu melesat ke atas dengan
        // kedua lengan lurus di sisi badan (bukan kepalan ke langit seperti Shazam), kepala menatap ke atas.
        ADAM.put(ShazamAnim.LAUNCH, Clip.builder(16)
                .key(0, Ease.OUT_QUAD).rightArm(18, 0, 18).leftArm(18, 0, -18).head(16, 0, 0).legs(10)
                        .rightLeg(-30, 0, 6).leftLeg(-30, 0, -6).tilt(16).drop(0.34f).shake(2f)
                .key(4, Ease.OUT_QUAD).rightArm(10, 0, 9).leftArm(10, 0, -9).head(-24, 0, 0)
                        .rightLeg(4, 0, 1).leftLeg(8, 0, -1).tilt(-3).drop(-0.12f).shake(0f)
                .key(10, Ease.LINEAR)
                .key(16, Ease.IN_OUT_SINE).rightArm(6, 0, 12).leftArm(6, 0, -12).head(-8, 0, 0)
                        .rightLeg(4, 0, 2).leftLeg(8, 0, -2).tilt(0).drop(0f)
                .fade(1, 6).build());

        // Pendaratan Black Adam: menghantam tanah dengan dua kaki terbuka lebar, merunduk dalam (lengan terbuka ke
        // bawah-samping menahan keseimbangan, kepala tertunduk), lalu bangkit pelan sampai berdiri tegak dan dagu
        // terangkat: mengancam, bukan pose pahlawan.
        ADAM.put(ShazamAnim.LAND_HERO, Clip.builder(30)
                .key(0, Ease.OUT_QUAD).rightArm(16, 0, 42).leftArm(16, 0, -42).head(24, 0, 0).legs(15)
                        .rightLeg(-34, 0, 15).leftLeg(-34, 0, -15).tilt(22).drop(0.46f).shake(2.4f)
                .key(6, Ease.LINEAR).shake(0.4f)
                .key(16, Ease.IN_OUT_SINE).rightArm(8, 0, 22).leftArm(8, 0, -22).head(6, 0, 0).legs(12)
                        .rightLeg(-6, 0, 12).leftLeg(-6, 0, -12).tilt(4).drop(0.06f).shake(0f)
                .key(23, Ease.IN_OUT_SINE).head(-8, 0, 0).tilt(-2).drop(0f)
                .key(30, Ease.IN_OUT_SINE).rightArm(4, 0, 14).leftArm(4, 0, -14).head(0, 0, 0).legs(5)
                        .rightLeg(0, 0, 5).leftLeg(0, 0, -5).tilt(0)
                .fade(0.6f, 5).build());

        // ===== Jalan mendapatkan juara (wujud manusia) =====

        // Ujian Kahndaq: Skarabe Teth-Adam disodorkan ke depan, lalu diangkat tinggi ke langit sementara badai pasir
        // bangkit; tangan bergetar karena skarabenya berdenyut.
        CLIPS.put(ShazamAnim.KAHNDAQ_TRIAL, Clip.builder(70)
                .key(0, Ease.OUT_CUBIC).rightArm(-84, -6, 0).leftArm(-10, 0, -10).head(14, 0, 0)
                .key(16, Ease.IN_OUT_SINE).rightArm(-96, -4, 0).head(6, 0, 0).shake(0.4f)
                .key(30, Ease.OUT_BACK).rightArm(-176, 0, -4).leftArm(-6, 0, -28).head(-34, 0, 0).legs(6).tilt(-5)
                        .shake(0.8f)
                .key(56, Ease.LINEAR).shake(1.4f)
                .key(70, Ease.IN_OUT_SINE).rightArm(-10, 0, 6).leftArm(-4, 0, -6).head(0, 0, 0).legs(2).tilt(0).shake(0f)
                .fade(4, 8).build());

        // Skarabe bangkit: badan terangkat dari tanah dengan lengan terbentang dan kepala mendongak (diangkat dewa-dewa
        // Mesir), gemetar makin hebat; petir Kahndaq menyambar (tick 52): tersentak, lalu turun pelan.
        CLIPS.put(ShazamAnim.KAHNDAQ_AWAKEN, Clip.builder(ShazamAnim.KAHNDAQ_AWAKEN_TICKS)
                .key(0, Ease.OUT_CUBIC).rightArm(-40, 0, 40).leftArm(-40, 0, -40).head(-10, 0, 0).drop(0f)
                .key(20, Ease.IN_OUT_SINE).rightArm(-14, 0, 82).leftArm(-14, 0, -82).head(-34, 0, 0).legs(5).tilt(-8)
                        .drop(-0.5f).shake(0.6f)
                .key(ShazamAnim.KAHNDAQ_AWAKEN_STRIKE - 1, Ease.IN_QUAD).rightArm(-10, 0, 90).leftArm(-10, 0, -90)
                        .head(-46, 0, 0).tilt(-12).drop(-0.9f).shake(2.6f)
                .key(ShazamAnim.KAHNDAQ_AWAKEN_STRIKE + 1, Ease.OUT_QUAD).rightArm(-30, 0, 70).leftArm(-30, 0, -70)
                        .head(-20, 0, 0).tilt(-18).drop(-1.0f).shake(4f)
                .key(ShazamAnim.KAHNDAQ_AWAKEN_TICKS, Ease.IN_OUT_SINE).rightArm(6, 0, 16).leftArm(6, 0, -16).head(4, 0, 0)
                        .legs(9).tilt(4).drop(0f).shake(0f)
                .fade(4, 6).build());

        // Enam totem menyatu: kedua lengan terbuka menyambut totem-totem yang berputar, kepala mendongak; petir
        // Penyihir menyambar (tick 48): tersentak, lengan terbentang lebar.
        CLIPS.put(ShazamAnim.SHAZAM_CHOSEN, Clip.builder(ShazamAnim.SHAZAM_CHOSEN_TICKS)
                .key(0, Ease.OUT_CUBIC).rightArm(-60, 0, 30).leftArm(-60, 0, -30).head(-6, 0, 0)
                .key(20, Ease.IN_OUT_SINE).rightArm(-40, 0, 60).leftArm(-40, 0, -60).head(-28, 0, 0).legs(5).tilt(-6)
                        .drop(-0.2f).shake(0.4f)
                .key(ShazamAnim.SHAZAM_CHOSEN_STRIKE - 1, Ease.IN_QUAD).rightArm(-30, 0, 76).leftArm(-30, 0, -76)
                        .head(-40, 0, 0).tilt(-10).drop(-0.4f).shake(2f)
                .key(ShazamAnim.SHAZAM_CHOSEN_STRIKE + 1, Ease.OUT_QUAD).rightArm(-24, 0, 92).leftArm(-24, 0, -92)
                        .head(-24, 0, 0).tilt(-16).drop(-0.5f).shake(3.4f)
                .key(ShazamAnim.SHAZAM_CHOSEN_TICKS, Ease.IN_OUT_SINE).rightArm(0, 0, 10).leftArm(0, 0, -10).head(0, 0, 0)
                        .legs(4).tilt(0).drop(0f).shake(0f)
                .fade(4, 6).build());
    }

    // ================================================================== 0.32 Lintang

    static {
        // Menerima cahaya langit: kepala makin mendongak, lengan membuka lalu terangkat membentuk V dengan telapak ke langit,
        // badan pelan-pelan terangkat dari tanah dan bergetar menahan cahaya yang makin deras.
        LINTANG.put(ShazamAnim.SUMMON, Clip.builder(ShazamAnim.SUMMON_TICKS)
                .key(0, Ease.LINEAR).rightArm(-6, 0, 8).leftArm(-6, 0, -8).head(6, 0, 0)
                .key(14, Ease.IN_OUT_SINE).rightArm(-30, 0, 30).leftArm(-30, 0, -30).head(-10, 0, 0).tilt(-2)
                .key(40, Ease.IN_OUT_SINE).rightArm(-120, 0, 40).leftArm(-120, 0, -40).head(-30, 0, 0).tilt(-6).drop(-0.1f)
                .key(70, Ease.IN_OUT_SINE).rightArm(-150, 0, 36).leftArm(-150, 0, -36).head(-42, 0, 0).tilt(-8).drop(-0.3f)
                        .shake(0.6f)
                .key(ShazamAnim.SUMMON_TICKS, Ease.IN_OUT_SINE).rightArm(-158, 0, 30).leftArm(-158, 0, -30).head(-46, 0, 0)
                        .tilt(-9).drop(-0.38f).shake(1.4f)
                .fade(4, 3).build());

        // Berubah: lengan merapat ke langit menyambut tiang cahaya (gemetar), tick 18 cahaya menghunjam: badan terlempar
        // terbuka & melayang, lalu turun pelan dan berdiri tegak.
        LINTANG.put(ShazamAnim.TRANSFORM, Clip.builder(54)
                .key(0, Ease.LINEAR).rightArm(-158, 0, 30).leftArm(-158, 0, -30).head(-46, 0, 0).tilt(-9).drop(-0.38f)
                .key(5, Ease.OUT_CUBIC).rightArm(-170, 0, 12).leftArm(-170, 0, -12).head(-50, 0, 0).tilt(-11).drop(-0.45f)
                        .shake(0.8f)
                .key(17, Ease.IN_OUT_SINE).rightArm(-176, 0, 8).leftArm(-176, 0, -8).head(-54, 0, 0).tilt(-12).drop(-0.5f)
                        .shake(2.6f)
                .key(19, Ease.OUT_QUAD).rightArm(-30, 0, 70).leftArm(-30, 0, -70).head(-24, 0, 0).legs(8).tilt(-14)
                        .drop(-0.62f).shake(1.2f)
                .key(30, Ease.OUT_CUBIC).rightArm(-20, 0, 62).leftArm(-20, 0, -62).head(-18, 0, 0).legs(6).tilt(-8)
                        .drop(-0.55f).shake(0.4f)
                .key(43, Ease.IN_OUT_SINE).rightArm(12, 0, 20).leftArm(12, 0, -20).head(-6, 0, 0).legs(5).tilt(-2)
                        .drop(-0.1f).shake(0f)
                .key(50, Ease.OUT_CUBIC).rightArm(8, 0, 12).leftArm(8, 0, -12).head(-4, 0, 0).legs(4).tilt(0).drop(0f)
                .fade(2, 6).build());

        // ===== Skill Lintang (cuma dikirim untuk Lintang, jadi cukup di daftar biasa) =====

        // L - Lesatan Bintang: merunduk mengumpulkan tenaga, lalu badan nyaris mendatar dengan kepalan kanan di depan.
        float dashEnd = ShazamAnim.LESAT_WINDUP + ShazamAnim.LESAT_TICKS;
        CLIPS.put(ShazamAnim.LINTANG_DASH, Clip.builder(dashEnd + 8)
                .key(0, Ease.OUT_CUBIC).rightArm(20, 0, 10).leftArm(20, 0, -10).head(14, 0, 0).legs(6).tilt(14).drop(0.18f)
                        .shake(0.6f)
                .key(ShazamAnim.LESAT_WINDUP, Ease.OUT_BACK).rightArm(-170, 0, 0).leftArm(30, 0, -10).head(-60, 0, 0)
                        .rightLeg(20, 0, 2).leftLeg(30, 0, -2).tilt(70).drop(-0.1f).shake(0f)
                .key(dashEnd, Ease.LINEAR)
                .key(dashEnd + 8, Ease.OUT_CUBIC).rightArm(-10, 0, 8).leftArm(-10, 0, -8).head(0, 0, 0).legs(4).tilt(0)
                        .drop(0f)
                .fade(1, 4).build());

        // I - Iris Surya: kepalan mengepal di samping, badan sedikit condong & menegang, gemetar menahan panas di mata.
        float eyesEnd = ShazamAnim.IRIS_WINDUP + ShazamAnim.IRIS_TICKS;
        CLIPS.put(ShazamAnim.LINTANG_EYES, Clip.builder(eyesEnd + 8)
                .key(0, Ease.OUT_CUBIC).rightArm(10, 0, 14).leftArm(10, 0, -14).head(10, 0, 0).legs(5).tilt(4).drop(0.04f)
                .key(ShazamAnim.IRIS_WINDUP, Ease.OUT_BACK).rightArm(18, 0, 22).leftArm(18, 0, -22).head(-4, 0, 0).legs(7)
                        .tilt(8).drop(0.08f).shake(1.2f)
                .key(eyesEnd, Ease.LINEAR).shake(1.6f)
                .key(eyesEnd + 8, Ease.OUT_CUBIC).rightArm(0, 0, 6).leftArm(0, 0, -6).head(0, 0, 0).legs(3).tilt(0).drop(0f)
                        .shake(0f)
                .fade(2, 5).build());

        // N - Napas Salju: menarik napas dalam (dada membusung, kepala ke belakang), lalu condong ke depan menghembus
        // dengan lengan tertarik ke belakang dan kaki menahan dorongan.
        float frostEnd = ShazamAnim.FROST_WINDUP + ShazamAnim.FROST_TICKS;
        CLIPS.put(ShazamAnim.LINTANG_BREATH, Clip.builder(frostEnd + 8)
                .key(0, Ease.OUT_CUBIC).rightArm(-10, 0, 12).leftArm(-10, 0, -12).head(4, 0, 0).legs(5)
                .key(ShazamAnim.FROST_WINDUP - 1, Ease.IN_OUT_SINE).rightArm(-24, 0, 26).leftArm(-24, 0, -26).head(-30, 0, 0)
                        .tilt(-8).drop(-0.04f)
                .key(ShazamAnim.FROST_WINDUP + 2, Ease.OUT_BACK).rightArm(32, 0, 18).leftArm(32, 0, -18).head(8, 0, 0)
                        .rightLeg(-12, 0, 6).leftLeg(14, 0, -6).tilt(10).drop(0.1f).shake(0.8f)
                .key(frostEnd, Ease.LINEAR).shake(1.2f)
                .key(frostEnd + 8, Ease.OUT_CUBIC).rightArm(0, 0, 6).leftArm(0, 0, -6).head(0, 0, 0).legs(3).tilt(0).drop(0f)
                        .shake(0f)
                .fade(2, 5).build());

        // T - Tepukan Guruh: kedua lengan terentang lebar ke belakang (gemetar), lalu ditepukkan di depan dada.
        CLIPS.put(ShazamAnim.LINTANG_CLAP, Clip.builder(ShazamAnim.SONIC_WINDUP + 16)
                .key(0, Ease.OUT_CUBIC).rightArm(-70, 60, 0).leftArm(-70, -60, 0).head(-6, 0, 0).legs(6).tilt(-6).drop(0.06f)
                .key(ShazamAnim.SONIC_WINDUP - 1, Ease.IN_QUAD).rightArm(-82, 88, 0).leftArm(-82, -88, 0).head(-10, 0, 0)
                        .legs(8).tilt(-10).drop(0.1f).shake(1.5f)
                .key(ShazamAnim.SONIC_WINDUP, Ease.OUT_BACK).rightArm(-92, -16, 0).leftArm(-92, 16, 0).head(6, 0, 0).legs(10)
                        .tilt(10).drop(0.14f).shake(0.4f)
                .key(ShazamAnim.SONIC_WINDUP + 8, Ease.LINEAR).shake(0f)
                .key(ShazamAnim.SONIC_WINDUP + 16, Ease.OUT_CUBIC).rightArm(-6, 0, 6).leftArm(-6, 0, -6).head(0, 0, 0).legs(4)
                        .tilt(0).drop(0f)
                .fade(1, 4).build());

        // A - Amukan Kilat: kuda-kuda, lalu pukulan kiri-kanan bergantian tiap 2 tick (sedikit menyebar), ditutup uppercut.
        float barrageEnd = ShazamAnim.BARRAGE_WINDUP + ShazamAnim.BARRAGE_TICKS;
        Clip.Builder barrage = Clip.builder(barrageEnd + 8)
                .key(0, Ease.OUT_CUBIC).rightArm(10, 0, 12).leftArm(10, 0, -12).head(6, 0, 0).legs(7).tilt(8).drop(0.08f);
        for (int i = 0; i < ShazamAnim.BARRAGE_TICKS / 2; i++) {
            boolean right = i % 2 == 0;
            float spread = (i % 3 - 1) * 8f;
            barrage.key(ShazamAnim.BARRAGE_WINDUP + i * 2, Ease.OUT_QUAD)
                    .rightArm(right ? -92 : -30, right ? -8 + spread : 10, 0)
                    .leftArm(right ? -30 : -92, right ? -10 : 8 + spread, 0)
                    .twist(right ? 16 : -16).tilt(12).drop(0.1f).shake(0.8f);
        }
        barrage.key(barrageEnd, Ease.OUT_BACK).rightArm(-150, -10, 0).leftArm(20, 0, -20).twist(24).tilt(-6).head(-20, 0, 0)
                        .drop(-0.05f).shake(0f)
                .key(barrageEnd + 8, Ease.OUT_CUBIC).rightArm(-6, 0, 6).leftArm(-6, 0, -6).twist(0).tilt(0).head(0, 0, 0)
                        .drop(0f);
        CLIPS.put(ShazamAnim.LINTANG_BARRAGE, barrage.fade(1, 4).build());

        // N - Napak Langit: merunduk, melompat dengan lengan ke atas, meringkuk di puncak, lalu menukik kepalan duluan.
        CLIPS.put(ShazamAnim.LINTANG_LEAP, Clip.builder(34)
                .key(0, Ease.OUT_CUBIC).rightArm(30, 0, 14).leftArm(30, 0, -14).head(14, 0, 0).legs(8).tilt(20).drop(0.3f)
                .key(ShazamAnim.LEAP_WINDUP, Ease.OUT_BACK).rightArm(-170, 0, -10).leftArm(-170, 0, 10).head(-20, 0, 0)
                        .tilt(-10).drop(-0.2f)
                .key(12, Ease.IN_OUT_SINE).rightArm(-120, 0, 10).leftArm(-120, 0, -10).rightLeg(-60, 0, 4).leftLeg(-60, 0, -4)
                        .head(10, 0, 0).tilt(20)
                .key(18, Ease.OUT_BACK).rightArm(-176, 0, -4).leftArm(-176, 0, 4).rightLeg(0, 0, 2).leftLeg(0, 0, -2)
                        .head(-40, 0, 0).tilt(80).shake(0.6f)
                .key(34, Ease.LINEAR).shake(0.8f)
                .fade(1, 4).build());

        // G - Gelegar Surya: lengan menyilang di dada mengumpulkan cahaya (gemetar makin hebat), lalu terlempar terbuka
        // ke atas membentuk V dengan kepala terdongak saat cahaya meledak.
        CLIPS.put(ShazamAnim.LINTANG_FLARE, Clip.builder(ShazamAnim.FLARE_WINDUP + 26)
                .key(0, Ease.OUT_CUBIC).rightArm(-70, -50, 0).leftArm(-70, 50, 0).head(16, 0, 0).legs(7).tilt(10).drop(0.12f)
                        .shake(0.6f)
                .key(ShazamAnim.FLARE_WINDUP - 1, Ease.IN_QUAD).rightArm(-80, -58, 0).leftArm(-80, 58, 0).head(24, 0, 0).legs(9)
                        .tilt(16).drop(0.22f).shake(3.2f)
                .key(ShazamAnim.FLARE_WINDUP, Ease.OUT_BACK).rightArm(-150, 0, -35).leftArm(-150, 0, 35).head(-40, 0, 0)
                        .legs(12).tilt(-16).drop(-0.3f).shake(2f)
                .key(ShazamAnim.FLARE_WINDUP + 14, Ease.IN_OUT_SINE).rightArm(-146, 0, -32).leftArm(-146, 0, 32).head(-34, 0, 0)
                        .tilt(-12).drop(-0.25f).shake(0.6f)
                .key(ShazamAnim.FLARE_WINDUP + 26, Ease.OUT_CUBIC).rightArm(-6, 0, 8).leftArm(-6, 0, -8).head(0, 0, 0).legs(4)
                        .tilt(0).drop(0f).shake(0f)
                .fade(2, 5).build());

        // M - Serap Surya: kedua lengan terangkat ke langit dengan telapak terbuka, lalu tersentak saat cahaya menghunjam.
        CLIPS.put(ShazamAnim.LINTANG_CALL, Clip.builder(ShazamAnim.SUNCALL_WINDUP + 22)
                .key(0, Ease.OUT_CUBIC).rightArm(-60, 0, 20).leftArm(-60, 0, -20).head(-10, 0, 0).legs(5)
                .key(ShazamAnim.SUNCALL_WINDUP - 1, Ease.IN_OUT_SINE).rightArm(-165, 0, 22).leftArm(-165, 0, -22)
                        .head(-38, 0, 0).tilt(-6).drop(-0.05f).shake(1.0f)
                .key(ShazamAnim.SUNCALL_WINDUP, Ease.OUT_BACK).rightArm(-150, 0, 40).leftArm(-150, 0, -40).head(-30, 0, 0)
                        .tilt(-10).drop(-0.15f).shake(2.2f)
                .key(ShazamAnim.SUNCALL_WINDUP + 22, Ease.OUT_CUBIC).rightArm(-6, 0, 8).leftArm(-6, 0, -8).head(0, 0, 0)
                        .legs(4).tilt(0).drop(0f).shake(0f)
                .fade(2, 5).build());

        // J - Selamatkan: merunduk sesaat lalu condong ke depan secepat kilat (badannya digerakkan oleh jejak cahaya).
        CLIPS.put(ShazamAnim.LINTANG_RESCUE, Clip.builder(ShazamAnim.RESCUE_WINDUP + 18)
                .key(0, Ease.OUT_CUBIC).rightArm(18, 0, 10).leftArm(18, 0, -10).head(12, 0, 0).legs(6).tilt(14).drop(0.16f)
                .key(ShazamAnim.RESCUE_WINDUP, Ease.OUT_BACK).rightArm(-40, 0, 40).leftArm(-40, 0, -40).head(-20, 0, 0)
                        .tilt(30).drop(0.05f).shake(0.5f)
                .key(ShazamAnim.RESCUE_WINDUP + 18, Ease.OUT_CUBIC).rightArm(-6, 0, 8).leftArm(-6, 0, -8).head(0, 0, 0)
                        .legs(4).tilt(0).drop(0f).shake(0f)
                .fade(1, 4).build());

        // Penyatuan Bintang (wujud manusia): Kristal Bintang diangkat tinggi dengan dua tangan ke matahari, gemetar makin
        // hebat, lalu (RITE_STRIKE) badan tersentak terbuka saat tiang cahaya menghunjam.
        CLIPS.put(ShazamAnim.LINTANG_RITE, Clip.builder(ShazamAnim.RITE_TICKS)
                .key(0, Ease.OUT_CUBIC).rightArm(-60, 0, -6).leftArm(-60, 0, 6).head(-4, 0, 0)
                .key(12, Ease.IN_OUT_SINE).rightArm(-172, 0, -8).leftArm(-172, 0, 8).head(-40, 0, 0).tilt(-6)
                .key(ShazamAnim.RITE_STRIKE - 2, Ease.IN_OUT_SINE).rightArm(-178, 0, -6).leftArm(-178, 0, 6).head(-48, 0, 0)
                        .tilt(-10).drop(-0.08f).shake(2.4f)
                .key(ShazamAnim.RITE_STRIKE, Ease.OUT_BACK).rightArm(-30, 0, 68).leftArm(-30, 0, -68).head(-30, 0, 0).legs(8)
                        .tilt(-14).drop(-0.2f).shake(1.6f)
                .key(ShazamAnim.RITE_TICKS, Ease.OUT_CUBIC).rightArm(0, 0, 10).leftArm(0, 0, -10).head(0, 0, 0).legs(4)
                        .tilt(0).drop(0f).shake(0f)
                .fade(3, 6).build());
    }

    // ================================================================== 0.30 Sabbac

    static {
        // Memanggil enam iblis: kebalikan doa Shazam. Kepala tertunduk, lengan terbuka ke bawah dengan telapak menghadap
        // tanah seperti menarik sesuatu dari dalam bumi, badan merunduk. Tiap iblis yang menyeruak membuat badan tersentak
        // dan makin membungkuk; menjelang akhir gemetar hebat dengan cakar mencengkeram udara.
        Clip.Builder summon = Clip.builder(ShazamAnim.SUMMON_TICKS)
                .key(0, Ease.LINEAR).rightArm(-6, 0, 10).leftArm(-6, 0, -10).head(10, 0, 0).tilt(2)
                .key(8, Ease.OUT_CUBIC).rightArm(-14, 0, 34).leftArm(-14, 0, -34).head(26, 0, 0).legs(6).tilt(8).drop(0.08f);
        for (int i = 0; i < GodShow.ARRIVE.length; i++) {
            float u = i / (float) (GodShow.ARRIVE.length - 1);
            float at = GodShow.ARRIVE[i];
            float open = 36f + 22f * u;      // lengan makin terbuka ke bawah-samping
            float fwd = -18f - 16f * u;
            float bow = 8f + 12f * u;        // makin membungkuk
            summon.key(at - 1.5f, Ease.IN_OUT_SINE).rightArm(fwd, 0, open).leftArm(fwd, 0, -open).head(24 + 6 * u, 0, 0)
                    .legs(6 + 4 * u).tilt(bow).drop(0.08f + 0.1f * u).shake(0f)
                    .key(at + 1, Ease.OUT_BACK).rightArm(fwd - 10, 0, open + 8).leftArm(fwd - 10, 0, -open - 8)
                    .head(10 + 4 * u, 0, 0).tilt(bow - 6).drop(0.04f + 0.08f * u).shake(1.0f)
                    .key(at + 6, Ease.IN_OUT_SINE).rightArm(fwd - 4, 0, open + 3).leftArm(fwd - 4, 0, -open - 3)
                    .head(20 + 6 * u, 0, 0).tilt(bow).drop(0.08f + 0.1f * u).shake(0.3f);
        }
        float end = ShazamAnim.SUMMON_TICKS;
        float settled = GodShow.ARRIVE[GodShow.ARRIVE.length - 1] + 6;
        summon.key(Math.min(end - 0.5f, Math.max(settled + 1, end - 4)), Ease.IN_OUT_SINE)
                .rightArm(-40, 0, 62).leftArm(-40, 0, -62).head(30, 0, 0).legs(11).tilt(22).drop(0.22f).shake(1.6f)
                .key(end, Ease.IN_OUT_SINE)
                .rightArm(-42, 0, 60).leftArm(-42, 0, -60).head(32, 0, 0).tilt(24).drop(0.24f).shake(2.2f);
        SABBAC.put(ShazamAnim.SUMMON, summon.fade(4, 3).build());

        // Berubah: berlutut, kedua kepalan menghantam tanah (tick 7) dan ditahan gemetar selama petir neraka merambat naik
        // dari bawah (8-18). Petir menembus badan: terlempar tegak dengan lengan terentang ke bawah-samping & kepala
        // terlempar ke belakang (meraung), lalu turun dan berdiri membungkuk siap menerkam.
        SABBAC.put(ShazamAnim.TRANSFORM, Clip.builder(54)
                .key(0, Ease.LINEAR).rightArm(-42, 0, 60).leftArm(-42, 0, -60).head(32, 0, 0).legs(11).tilt(24).drop(0.24f)
                .key(4, Ease.OUT_CUBIC).rightArm(-150, 0, -8).leftArm(-150, 0, 8).head(-10, 0, 0).legs(8).tilt(-6)
                        .drop(-0.04f).shake(0.6f)
                .key(7, Ease.IN_QUAD).rightArm(-52, 0, 12).leftArm(-52, 0, -12).head(30, 0, 0)
                        .rightLeg(-64, 0, 8).leftLeg(40, 0, -6).tilt(56).drop(0.82f).shake(2.4f)
                .key(12, Ease.IN_OUT_SINE).rightArm(-50, 0, 14).leftArm(-50, 0, -14).head(26, 0, 0).tilt(54).drop(0.8f)
                        .shake(2.8f)
                .key(17, Ease.IN_OUT_SINE).rightArm(-48, 0, 12).leftArm(-48, 0, -12).head(22, 0, 0).tilt(52).drop(0.78f)
                        .shake(3.6f)
                .key(19, Ease.OUT_QUAD).rightArm(-20, 0, 70).leftArm(-20, 0, -70).head(-50, 0, 0)
                        .rightLeg(0, 0, 10).leftLeg(0, 0, -10).tilt(-20).drop(-0.3f).shake(1.2f)
                .key(26, Ease.OUT_CUBIC).rightArm(-14, 0, 82).leftArm(-14, 0, -82).head(-56, 0, 0).tilt(-18).drop(-0.46f)
                        .shake(2.0f)
                .key(36, Ease.IN_OUT_SINE).rightArm(-10, 0, 78).leftArm(-10, 0, -78).head(-50, 0, 0).tilt(-12).drop(-0.4f)
                        .shake(1.2f)
                .key(43, Ease.IN_OUT_SINE).rightArm(-30, 0, 26).leftArm(-30, 0, -26).head(18, 0, 0).legs(13).tilt(14)
                        .drop(0.16f).shake(0.3f)
                .key(50, Ease.OUT_CUBIC).rightArm(-24, 0, 20).leftArm(-24, 0, -20).head(14, 0, 0).legs(12).tilt(9)
                        .drop(0.06f).shake(0f)
                .fade(2, 6).build());

        // Sabbac terbang & mendarat berat seperti Black Adam
        SABBAC.put(ShazamAnim.LAUNCH, ADAM.get(ShazamAnim.LAUNCH));
        SABBAC.put(ShazamAnim.LAND_HERO, ADAM.get(ShazamAnim.LAND_HERO));

        // ===== Skill Sabbac (cuma dikirim untuk Sabbac, jadi cukup di daftar biasa) =====

        // S - Tanduk Setan: menunduk dalam, kaki kanan menggaruk tanah dua kali seperti banteng (0-6), lalu menyeruduk:
        // badan nyaris mendatar, kepala (tanduk) di depan, lengan tersapu ke belakang. Di ujung kepala menghentak naik
        // melempar mangsa, lengan terbuka, lalu berdiri lagi.
        float hornEnd = ShazamAnim.HORN_WINDUP + ShazamAnim.HORN_TICKS;
        putSkill(ShazamAnim.SABBAC_HORNS, Clip.builder(hornEnd + 12)
                .key(0, Ease.OUT_CUBIC).rightArm(30, 0, 22).leftArm(30, 0, -22).head(36, 0, 0).rightLeg(26, 0, 4)
                        .leftLeg(-10, 0, -4).tilt(30).drop(0.26f).shake(0.8f)
                .key(2, Ease.IN_OUT_SINE).rightLeg(-18, 0, 4)
                .key(4, Ease.IN_OUT_SINE).rightLeg(30, 0, 4).shake(1.4f)
                .key(ShazamAnim.HORN_WINDUP, Ease.OUT_QUAD).rightArm(64, 0, 18).leftArm(64, 0, -18).head(58, 0, 0)
                        .rightLeg(28, 0, 3).leftLeg(-30, 0, -3).tilt(62).drop(0.1f).shake(0.4f)
                .key(hornEnd - 1, Ease.LINEAR).rightLeg(-26, 0, 3).leftLeg(30, 0, -3).tilt(64)
                .key(hornEnd + 1, Ease.OUT_BACK).rightArm(-60, 0, 60).leftArm(-60, 0, -60).head(-46, 0, 0)
                        .rightLeg(-20, 0, 8).leftLeg(14, 0, -8).tilt(-14).drop(0.04f).shake(1.6f)
                .key(hornEnd + 5, Ease.OUT_QUAD).rightArm(-20, 0, 30).leftArm(-20, 0, -30).head(8, 0, 0).tilt(10)
                        .drop(0.12f).shake(0.4f)
                .key(hornEnd + 12, Ease.IN_OUT_SINE).rightArm(-24, 0, 20).leftArm(-24, 0, -20).head(12, 0, 0)
                        .rightLeg(0, 0, 10).leftLeg(0, 0, -10).tilt(8).drop(0.04f).shake(0f)
                .fade(1, 5).build());

        // A - Tubuh Aym: lengan menyilang di depan wajah, badan meringkuk dan gemetar selagi kulit membatu (0-5), lalu
        // menghentak terbuka: dada membusung, kedua lengan terentang ke bawah-samping mengepal, kepala mendongak.
        putSkill(ShazamAnim.SABBAC_AYM, Clip.builder(28)
                .key(0, Ease.OUT_CUBIC).rightArm(-110, -40, 0).leftArm(-110, 40, 0).head(20, 0, 0).tilt(14).drop(0.16f)
                        .shake(1.0f)
                .key(4, Ease.IN_QUAD).rightArm(-118, -46, 0).leftArm(-118, 46, 0).head(26, 0, 0).tilt(20).drop(0.24f)
                        .shake(3.0f)
                .key(ShazamAnim.AYM_WINDUP, Ease.OUT_BACK).rightArm(-16, 0, 64).leftArm(-16, 0, -64).head(-30, 0, 0)
                        .legs(12).tilt(-12).drop(-0.04f).shake(1.4f)
                .key(14, Ease.LINEAR).rightArm(-12, 0, 58).leftArm(-12, 0, -58).head(-22, 0, 0).shake(0.4f)
                .key(28, Ease.IN_OUT_SINE).rightArm(-24, 0, 20).leftArm(-24, 0, -20).head(12, 0, 0).legs(11).tilt(8)
                        .drop(0.04f).shake(0f)
                .fade(2, 5).build());

        // Letusan Aym: cangkang magma pecah - lengan menghentak ke luar, badan tersentak.
        putSkill(ShazamAnim.SABBAC_AYM_BURST, Clip.builder(16)
                .key(0, Ease.OUT_QUAD).rightArm(-70, -30, 0).leftArm(-70, 30, 0).head(16, 0, 0).tilt(12).drop(0.12f)
                        .shake(2.4f)
                .key(ShazamAnim.NOVA_WINDUP, Ease.OUT_BACK).rightArm(-30, 0, 96).leftArm(-30, 0, -96).head(-34, 0, 0)
                        .legs(13).tilt(-14).drop(-0.1f).shake(2.0f)
                .key(9, Ease.LINEAR).shake(0.6f)
                .key(16, Ease.IN_OUT_SINE).rightArm(-24, 0, 20).leftArm(-24, 0, -20).head(12, 0, 0).legs(11).tilt(8)
                        .drop(0.04f).shake(0f)
                .fade(1, 4).build());

        // C - Rantai Belial: berlutut, cakar kanan mencakar tanah (0-6) - rantai menyeruak. Kedua tangan mencengkeram
        // rantai di depan dada selama musuh terikat, lalu (tick 26) menyentaknya ke belakang sambil memutar pinggang.
        float pull = ShazamAnim.CHAIN_WINDUP + ShazamAnim.CHAIN_PULL;
        putSkill(ShazamAnim.SABBAC_CHAINS, Clip.builder(pull + 12)
                .key(0, Ease.OUT_CUBIC).rightArm(-150, 0, -10).leftArm(-20, 0, -30).head(-10, 0, 0).tilt(-4).shake(0.5f)
                .key(ShazamAnim.CHAIN_WINDUP - 1, Ease.IN_QUAD).rightArm(-40, 0, 8).leftArm(-10, 0, -36).head(30, 0, 0)
                        .rightLeg(-58, 0, 8).leftLeg(36, 0, -6).tilt(48).drop(0.7f).shake(1.6f)
                .key(ShazamAnim.CHAIN_WINDUP + 2, Ease.OUT_BACK).rightArm(-96, -18, 0).leftArm(-96, 18, 0).head(-8, 0, 0)
                        .rightLeg(-20, 0, 8).leftLeg(16, 0, -8).tilt(6).drop(0.12f).shake(1.2f)
                .key(pull - 2, Ease.LINEAR).rightArm(-90, -14, 0).leftArm(-90, 14, 0).head(-4, 0, 0).tilt(4).shake(2.2f)
                .key(pull + 1, Ease.OUT_BACK).rightArm(24, 0, 30).leftArm(24, 0, -30).head(-24, 0, 0).twist(18).tilt(-16)
                        .drop(0.06f).shake(1.0f)
                .key(pull + 12, Ease.IN_OUT_SINE).rightArm(-24, 0, 20).leftArm(-24, 0, -20).head(12, 0, 0)
                        .rightLeg(0, 0, 10).leftLeg(0, 0, -10).twist(0).tilt(8).drop(0.04f).shake(0f)
                .fade(2, 5).build());

        // V - Napas Beelzebub: menarik napas dalam (kepala & dada terangkat ke belakang, lengan terbuka), lalu (tick 8)
        // condong ke depan menyemburkan api neraka: cakar terbuka ke depan-samping, gemetar menahan semburan 2 detik.
        float breathEnd = ShazamAnim.BREATH_WINDUP + ShazamAnim.BREATH_TICKS;
        putSkill(ShazamAnim.SABBAC_BREATH, Clip.builder(breathEnd + 10)
                .key(0, Ease.OUT_CUBIC).rightArm(-20, 0, 40).leftArm(-20, 0, -40).head(-30, 0, 0).tilt(-10).drop(-0.02f)
                .key(ShazamAnim.BREATH_WINDUP - 1, Ease.IN_OUT_SINE).rightArm(-10, 0, 56).leftArm(-10, 0, -56).head(-42, 0, 0)
                        .tilt(-14).drop(-0.06f).shake(0.8f)
                .key(ShazamAnim.BREATH_WINDUP + 1, Ease.OUT_BACK).rightArm(-70, -10, 30).leftArm(-70, 10, -30).head(6, 0, 0)
                        .rightLeg(-22, 0, 8).leftLeg(16, 0, -8).tilt(18).drop(0.12f).shake(1.4f)
                .key(breathEnd - 2, Ease.LINEAR).rightArm(-66, -10, 34).leftArm(-66, 10, -34).tilt(16).shake(1.8f)
                .key(breathEnd + 10, Ease.IN_OUT_SINE).rightArm(-24, 0, 20).leftArm(-24, 0, -20).head(12, 0, 0)
                        .rightLeg(0, 0, 10).leftLeg(0, 0, -10).tilt(8).drop(0.04f).shake(0f)
                .fade(2, 6).build());

        // B - Teror Asmodeus: membungkuk mengumpulkan amarah, kepalan bergetar di samping (0-7), lalu meraung: kepala
        // terlempar ke belakang, lengan terlempar ke bawah-samping, dada membusung, badan sedikit terangkat.
        putSkill(ShazamAnim.SABBAC_ROAR, Clip.builder(32)
                .key(0, Ease.OUT_CUBIC).rightArm(16, 0, 18).leftArm(16, 0, -18).head(26, 0, 0).tilt(14).drop(0.12f)
                        .shake(1.6f)
                .key(ShazamAnim.TERROR_WINDUP - 1, Ease.IN_QUAD).rightArm(26, 0, 14).leftArm(26, 0, -14).head(34, 0, 0)
                        .legs(10).tilt(22).drop(0.26f).shake(4.4f)
                .key(ShazamAnim.TERROR_WINDUP, Ease.OUT_BACK).rightArm(24, 0, 70).leftArm(24, 0, -70).head(-62, 0, 0)
                        .legs(13).tilt(-22).drop(-0.2f).shake(3.0f)
                .key(18, Ease.LINEAR).head(-56, 0, 0).drop(-0.16f).shake(1.8f)
                .key(32, Ease.IN_OUT_SINE).rightArm(-24, 0, 20).leftArm(-24, 0, -20).head(12, 0, 0).legs(11).tilt(8)
                        .drop(0.04f).shake(0f)
                .fade(2, 5).build());

        // N - Kepakan Crateis: meringkuk dengan lengan menyilang (sayap terlipat), lalu (tick 6) menghentak tegak dengan
        // lengan terentang lebar ke atas seperti sayap terbuka dan badan terangkat, lalu terbang.
        putSkill(ShazamAnim.SABBAC_WINGS, Clip.builder(26)
                .key(0, Ease.OUT_CUBIC).rightArm(-60, -40, 0).leftArm(-60, 40, 0).head(24, 0, 0).legs(10).tilt(24)
                        .drop(0.34f).shake(1.2f)
                .key(ShazamAnim.WINGS_WINDUP - 1, Ease.IN_QUAD).rightArm(-66, -44, 0).leftArm(-66, 44, 0).head(30, 0, 0)
                        .tilt(30).drop(0.42f).shake(2.6f)
                .key(ShazamAnim.WINGS_WINDUP + 1, Ease.OUT_BACK).rightArm(-140, 0, -40).leftArm(-140, 0, 40).head(-36, 0, 0)
                        .rightLeg(10, 0, 4).leftLeg(16, 0, -4).tilt(-12).drop(-0.3f).shake(1.0f)
                .key(16, Ease.IN_OUT_SINE).rightArm(-110, 0, -60).leftArm(-110, 0, 60).head(-20, 0, 0).tilt(-6).drop(-0.2f)
                        .shake(0.3f)
                .key(26, Ease.IN_OUT_SINE).rightArm(-20, 0, 30).leftArm(-20, 0, -30).head(0, 0, 0)
                        .rightLeg(0, 0, 4).leftLeg(0, 0, -4).tilt(0).drop(0f).shake(0f)
                .fade(1, 5).build());

        // R - Gerbang Neraka: membungkuk dalam, kepalan mengepal di samping, gemetar makin hebat saat tanah membara
        // (0-12), lalu bangkit membesar: lengan terlempar terbuka ke atas, kepala mendongak meraung, badan terangkat.
        putSkill(ShazamAnim.SABBAC_HELLGATE, Clip.builder(38)
                .key(0, Ease.OUT_CUBIC).rightArm(18, 0, 14).leftArm(18, 0, -14).head(24, 0, 0).tilt(12).drop(0.1f).shake(1.4f)
                .key(7, Ease.IN_QUAD).rightArm(26, 0, 20).leftArm(26, 0, -20).head(32, 0, 0).legs(9).tilt(20).drop(0.28f)
                        .shake(4.0f)
                .key(ShazamAnim.HELLGATE_WINDUP - 0.5f, Ease.IN_QUAD).rightArm(30, 0, 16).leftArm(30, 0, -16).tilt(24)
                        .drop(0.32f).shake(5.6f)
                .key(ShazamAnim.HELLGATE_WINDUP, Ease.OUT_BACK).rightArm(-150, 0, -44).leftArm(-150, 0, 44).head(-60, 0, 0)
                        .legs(14).tilt(-18).drop(-0.36f).shake(2.8f)
                .key(24, Ease.LINEAR).drop(-0.3f).shake(1.6f)
                .key(38, Ease.IN_OUT_SINE).rightArm(-24, 0, 20).leftArm(-24, 0, -20).head(12, 0, 0).legs(11).tilt(8)
                        .drop(0.04f).shake(0f)
                .fade(2, 5).build());

        // M - Panggil Petir Neraka: berlutut satu kaki, telapak kanan menekan tanah memanggil dari bawah, gemetar
        // (0-12). Petir neraka menyembur naik menembus badan: tersentak tegak, lengan terentang ke bawah-samping menyerap.
        putSkill(ShazamAnim.SABBAC_CALL, Clip.builder(36)
                .key(0, Ease.OUT_CUBIC).rightArm(-36, 0, 6).leftArm(10, 0, -24).head(26, 0, 0)
                        .rightLeg(-50, 0, 6).leftLeg(30, 0, -6).tilt(40).drop(0.5f).shake(0.6f)
                .key(ShazamAnim.SABBAC_CALL_WINDUP - 1, Ease.IN_QUAD).rightArm(-40, 0, 4).head(30, 0, 0).tilt(44).drop(0.58f)
                        .shake(3.2f)
                .key(ShazamAnim.SABBAC_CALL_WINDUP, Ease.OUT_QUAD).rightArm(-10, 0, 80).leftArm(-10, 0, -80).head(-54, 0, 0)
                        .rightLeg(0, 0, 10).leftLeg(0, 0, -10).tilt(-18).drop(-0.3f).shake(3.6f)
                .key(ShazamAnim.SABBAC_CALL_WINDUP + 12, Ease.IN_OUT_SINE).rightArm(-14, 0, 74).leftArm(-14, 0, -74)
                        .head(-40, 0, 0).tilt(-10).drop(-0.2f).shake(1.0f)
                .key(36, Ease.IN_OUT_SINE).rightArm(-24, 0, 20).leftArm(-24, 0, -20).head(12, 0, 0).legs(11).tilt(8)
                        .drop(0.04f).shake(0f)
                .fade(2, 6).build());

        // J - Pasukan Iblis: kedua lengan diangkat tinggi (0-4), lalu dihantamkan ke bawah memerintah tanah terbuka
        // (tick 10), lalu telapak terbuka ke atas, perlahan diangkat: "bangkitlah".
        putSkill(ShazamAnim.SABBAC_LEGION, Clip.builder(36)
                .key(0, Ease.OUT_CUBIC).rightArm(-60, 0, 10).leftArm(-60, 0, -10).head(-6, 0, 0)
                .key(4, Ease.OUT_BACK).rightArm(-176, 0, -10).leftArm(-176, 0, 10).head(-30, 0, 0).tilt(-8).drop(-0.06f)
                        .shake(0.8f)
                .key(ShazamAnim.LEGION_WINDUP - 1, Ease.IN_QUAD).rightArm(-160, 0, -8).leftArm(-160, 0, 8).shake(1.8f)
                .key(ShazamAnim.LEGION_WINDUP, Ease.OUT_QUAD).rightArm(-20, 0, 24).leftArm(-20, 0, -24).head(30, 0, 0)
                        .legs(12).tilt(34).drop(0.4f).shake(2.6f)
                .key(20, Ease.IN_OUT_SINE).rightArm(-54, 0, 40).leftArm(-54, 0, -40).head(6, 0, 0).tilt(12).drop(0.12f)
                        .shake(0.8f)
                .key(28, Ease.IN_OUT_SINE).rightArm(-74, 0, 46).leftArm(-74, 0, -46).head(-12, 0, 0).tilt(0).drop(0f)
                        .shake(0.4f)
                .key(36, Ease.IN_OUT_SINE).rightArm(-24, 0, 20).leftArm(-24, 0, -20).head(12, 0, 0).legs(11).tilt(8)
                        .drop(0.04f).shake(0f)
                .fade(2, 6).build());

        // Perjanjian Enam Iblis (wujud manusia): Mahkota Sabbac disodorkan, lalu diangkat tinggi dengan dua tangan selagi
        // nama-nama iblis bergema; badan gemetar makin hebat; petir neraka menyembur (tick 60): tersentak, lalu turun.
        putSkill(ShazamAnim.SABBAC_PACT, Clip.builder(ShazamAnim.PACT_TICKS)
                .key(0, Ease.OUT_CUBIC).rightArm(-84, -8, 0).leftArm(-84, 8, 0).head(16, 0, 0)
                .key(18, Ease.IN_OUT_SINE).rightArm(-92, -10, 0).leftArm(-92, 10, 0).head(8, 0, 0).shake(0.4f)
                .key(32, Ease.OUT_BACK).rightArm(-174, 0, 4).leftArm(-174, 0, -4).head(-36, 0, 0).legs(6).tilt(-5)
                        .shake(0.8f)
                .key(ShazamAnim.PACT_STRIKE - 1, Ease.IN_QUAD).rightArm(-178, 0, 6).leftArm(-178, 0, -6).head(-44, 0, 0)
                        .tilt(-8).drop(-0.06f).shake(2.4f)
                .key(ShazamAnim.PACT_STRIKE + 1, Ease.OUT_QUAD).rightArm(-30, 0, 70).leftArm(-30, 0, -70).head(-24, 0, 0)
                        .tilt(-16).drop(-0.3f).shake(3.6f)
                .key(ShazamAnim.PACT_TICKS, Ease.IN_OUT_SINE).rightArm(6, 0, 16).leftArm(6, 0, -16).head(4, 0, 0)
                        .legs(8).tilt(4).drop(0f).shake(0f)
                .fade(4, 8).build());
    }

    private static void putSkill(ShazamAnim anim, Clip clip) {
        CLIPS.put(anim, clip);   // skill khusus Black Adam: cuma dikirim untuk Black Adam, jadi cukup di daftar biasa
    }
}
