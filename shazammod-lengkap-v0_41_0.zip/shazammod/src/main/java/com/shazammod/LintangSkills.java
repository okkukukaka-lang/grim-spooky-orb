package com.shazammod;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.IronBarsBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * 0.32 LINTANG, juara bintang (orisinal). Tubuhnya menyimpan cahaya matahari & bintang (Energi = Cahaya Tersimpan), jadi
 * angka mentahnya paling tinggi di mod ini, tapi kekuatannya IKUT cahaya itu:
 * - Daya Surya: di atas FULL_POWER_ENERGY tinju & ketahanan penuh; di bawahnya menyusut sampai MIN_POWER.
 * - Pasif tiap 2 detik (Serapan Cahaya) jalan selama langit terlihat: siang penuh, malam (cahaya bintang) separuh. Padam di
 *   bawah tanah / di dalam ruangan, di Nether & End, dan dekat Batu Kelam.
 * - Kulit Baja: serangan lemah (di bawah LINTANG_TOUGH_SKIN) memantul. Tepisan Beku (tiap 1,8 detik, ShazamPassives).
 * - Kelemahan: Batu Kelam (mineral ungu kehitaman yang menghisap cahaya) dan sihir.
 *
 * Skill (tombol sama dengan juara lain, huruf L-I-N-T-A-N-G):
 * Z  L - Lesatan Bintang : melesat lurus secepat cahaya sampai 28 blok, menabrak semua musuh di jalurnya.
 * X  I - Iris Surya      : sinar panas dari kedua mata selama 2 detik, mengikuti arah pandang, menembus 8 musuh.
 *                          0.36: membakar & melelehkan penghalang (kaca, es, daun, jaring, jeruji besi; pasir jadi kaca).
 * Shift+X Angkat & Lempar: 0.36 (ala DLC Superman) musuh di depan diangkat ke atas kepala lalu dilempar sekuat tenaga.
 * Shift+Z Kombo Langit  : 0.37 melesat ke musuh, uppercut ke udara, menyusul ke atasnya, menghantamnya ke tanah dengan dua
 *                          kepalan, lalu menyorot kawahnya dengan sinar panas. Biaya & jedanya sendiri.
 * Shift+C Napas Topan    : 0.37 napas super yang menerbangkan musuh, membalikkan anak panah, dan memadamkan api.
 * Shift+R Ledakan Surya  : 0.37 jurus pamungkas: 3 detik meringkuk mengumpulkan panas matahari, lalu meledak seperti bom.
 * C  N - Napas Salju     : hembusan beku berbentuk kerucut: musuh membeku & melambat, air jadi es, api padam.
 *                          0.36: musuh yang membeku penuh jadi patung es (diam total), pukulan memecahkannya (damage x2,5).
 * V  T - Tepukan Guruh   : tepukan tangan menggelegar: gelombang suara menghempas musuh & proyektil di depan.
 * B  A - Amukan Kilat    : rentetan pukulan secepat kilat ke satu musuh, ditutup pukulan yang melambungkannya.
 * N  N - Napak Langit    : melompat tinggi (atau langsung menukik kalau sedang di udara), lalu menghantam tanah.
 * R  G - Gelegar Surya   : menyerap cahaya lalu meledakkan SEMUA cahaya tersimpan: makin penuh makin dahsyat. Sesudahnya
 *                          Mode Surya 12 detik (pukulan x2 + tombak cahaya, damage diterima x0,5).
 * M  Serap Surya         : (gratis) menyerap cahaya langit sekaligus: energi & darah terisi, musuh dekat silau.
 * J  Selamatkan          : melesat ke semua sekutu dalam 24 blok: dipulihkan, dilindungi, dan musuh di dekatnya terhempas.
 */
public final class LintangSkills {
    private LintangSkills() {}

    public enum Skill {
        LESATAN(15f, 50),     // L - Lesatan Bintang (Z)      0.41 super kuat: biaya & jeda dipangkas
        IRIS(20f, 90),        // I - Iris Surya (X)
        NAPAS(20f, 100),      // N - Napas Salju (C)
        TEPUKAN(25f, 120),    // T - Tepukan Guruh (V)
        AMUKAN(20f, 70),      // A - Amukan Kilat (B)
        NAPAK(25f, 140),      // N - Napak Langit (N)
        GELEGAR(100f, 600);   // G - Gelegar Surya (R)

        public final float cost;
        public final int cooldownTicks;

        Skill(float cost, int cooldownTicks) {
            this.cost = cost;
            this.cooldownTicks = cooldownTicks;
        }
    }

    // ================= Angka-angka yang gampang diutak-atik =================
    // Daya Surya (kekuatan ikut cahaya tersimpan)
    public static final float FULL_POWER_ENERGY = 350f;   // energi segini ke atas: kekuatan penuh
    public static final float MIN_POWER = 0.85f;          // energi habis: tinju & ketahanan masih 85%
    public static final float WEAK_TAKEN_BONUS = 0.25f;   // damage diterima naik (1 - daya) x ini (20% -> paling banyak ±24%)
    public static final float STARLIGHT_PULSE = 0.5f;     // Serapan Cahaya malam hari (cahaya bintang): separuh
    // Batu Kelam
    public static final float KELAM_POWER = 0.7f;         // dekat Batu Kelam: daya tinggal 70%
    private static final int KELAM_SCAN_TICKS = 10;
    private static final int KELAM_BLOCK_RADIUS = 4;      // bijihnya di batu sekitar
    private static final double KELAM_ENTITY_RADIUS = 6.0; // dipegang makhluk / tergeletak di tanah
    private static final double KELAM_SLOW = -0.3;        // lari 30% lebih lambat
    private static final float KELAM_HIT_DRAIN = 60f;     // dipukul yang memegang Batu Kelam: cahaya terhisap
    // L - Lesatan Bintang
    private static final double LESAT_RANGE = 28.0;
    private static final double LESAT_HIT_RADIUS = 2.8;
    private static final float LESAT_DAMAGE = 36f;
    private static final float LESAT_END_DAMAGE = 20f;
    private static final double LESAT_END_RADIUS = 5.0;
    // I - Iris Surya
    public static final double IRIS_RANGE = 64.0;
    private static final float IRIS_DAMAGE = 12f;         // tiap 4 tick selama 2 detik (10 kali)
    private static final int IRIS_PIERCE = 8;
    private static final float IRIS_FIRE_SECONDS = 5f;
    private static final boolean IRIS_BURNS_BLOCKS = true; // 0.36: sinar membakar/melelehkan penghalang (false = cuma salju & es)
    // 0.36 Angkat & Lempar (Shift + X): kekuatan super ala DLC Superman
    private static final double LIFT_REACH = 8.0;          // musuh sejauh ini di depan bisa diangkat
    private static final float LIFT_MAX_HEALTH = 1500f;    // 0.41 Warden (500) & semua bos vanilla pun terangkat
    private static final double LIFT_THROW_SPEED = 3.0;    // blok/tick saat dilempar
    private static final float LIFT_HIT_DAMAGE = 28f;      // yang dilempar
    private static final float LIFT_SPLASH_DAMAGE = 36f;  // musuh di sekitar titik jatuhnya
    private static final double LIFT_SPLASH_RADIUS = 6.0;
    private static final int LIFT_MAX_FLIGHT = 40;         // nggak menabrak apa-apa: berhenti dilacak
    // N - Napas Salju
    private static final double FROST_RANGE = 18.0;
    private static final double FROST_CONE_COS = 0.86;    // ±30°
    private static final float FROST_DAMAGE = 8f;         // tiap 4 tick selama 2 detik
    private static final int FROST_FREEZE_PER_STEP = 60;  // beku menumpuk (140 = membeku penuh)
    private static final int FROST_FREEZE_MAX = 260;
    private static final int FROST_SLOW_TICKS = 70;
    // 0.36 patung es: musuh yang membeku penuh terkunci di dalam es (lamanya ShazamAnim.LINTANG_ICE_TICKS)
    private static final float ICE_MAX_HEALTH = 800f;     // yang lebih kuat dari ini (bos) cuma melambat
    public static final float ICE_SHATTER_MULTIPLIER = 2.5f; // pukulan yang memecahkan patung es
    // T - Tepukan Guruh
    private static final double CLAP_RANGE = 22.0;
    private static final double CLAP_CONE_COS = 0.64;     // ±50°
    private static final float CLAP_DAMAGE = 40f;
    private static final double CLAP_KNOCKBACK = 2.6;
    private static final int CLAP_STUN_TICKS = 70;
    // A - Amukan Kilat
    private static final double BARRAGE_REACH = 10.0;
    private static final float BARRAGE_HIT_DAMAGE = 18f;  // 4 pukulan beruntun
    private static final float BARRAGE_FINAL_DAMAGE = 50f;
    // N - Napak Langit
    private static final double NAPAK_LEAP = 1.55;
    private static final int NAPAK_RISE_TICKS = 8;
    private static final double NAPAK_DIVE_SPEED = 2.4;
    private static final double NAPAK_RADIUS = 10.0;
    private static final float NAPAK_DAMAGE = 60f;
    // G - Gelegar Surya & Mode Surya (R)
    private static final float FLARE_KEEP_ENERGY = 250f;  // sisa cahaya sesudah meledak
    private static final float FLARE_MIN_DAMAGE = 50f;    // + 0,08 per cahaya yang dibakar (energi 1000 -> ±102)
    private static final float FLARE_DAMAGE_PER_ENERGY = 0.08f;
    private static final double FLARE_RADIUS = 24.0;
    public static final float RAGE_PUNCH_MULTIPLIER = 2.0f;
    public static final float RAGE_DAMAGE_TAKEN = 0.5f;
    private static final double RAGE_SPEED_BONUS = 0.35;
    private static final double RAGE_LANCE_RADIUS = 22.0;
    private static final float RAGE_LANCE_DAMAGE = 24f;
    private static final float RAGE_PUNCH_LANCE_DAMAGE = 18f;
    private static final ResourceLocation RAGE_SPEED = ShazamMod.id("lintang_rage_speed");
    private static final ResourceLocation KELAM_SLOW_ID = ShazamMod.id("kelam_slow");
    // Tinju Fajar (Muatan Cahaya penuh)
    private static final float DAWN_LANCE_DAMAGE = 30f;
    private static final double DAWN_LANCE_RADIUS = 10.0;
    // M - Serap Surya (gratis)
    public static final int CALL_COOLDOWN_TICKS = 300;
    private static final float CALL_ENERGY_SKY = 500f;
    private static final float CALL_ENERGY_DARK = 220f;
    private static final float CALL_HEAL_SKY = 300f;
    private static final float CALL_HEAL_DARK = 120f;
    private static final double CALL_RADIUS = 9.0;
    private static final float CALL_DAMAGE = 36f;
    // J - Selamatkan
    public static final float RESCUE_COST = 40f;
    public static final int RESCUE_COOLDOWN_TICKS = 400;
    private static final double RESCUE_RADIUS = 24.0;
    private static final int RESCUE_MAX = 8;
    private static final float RESCUE_HEAL = 60f;
    private static final int RESCUE_SHIELD_TICKS = 200;
    private static final double RESCUE_BLAST_RADIUS = 4.0;
    private static final float RESCUE_BLAST_DAMAGE = 24f;
    private static final int CITIZEN_HERO_TICKS = 2400;    // 0.36: warga desa diselamatkan -> Pahlawan Desa 2 menit
    // 0.37 Napas Topan (Shift + C): napas super yang menerbangkan musuh (bukan membekukan)
    private static final double GALE_RANGE = 20.0;
    private static final double GALE_CONE_DOT = 0.82;     // kerucut kira-kira 35 derajat
    private static final double GALE_PUSH = 0.5;          // (0.37, sekarang dipakai buat barang)
    private static final double GALE_IMPULSE = 60.0;      // 0.40 impuls angin per m^2 tiap 2 tick pada jarak <= 3 blok
    private static final float GALE_DAMAGE = 3f;          // tiap 4 tick, cuma ke musuh
    // 0.37 Kombo Langit (Shift + Z): melesat, uppercut, menyusul ke atas, hantam ke bawah, sinar panas
    private static final double COMBO_RANGE = 24.0;
    private static final float COMBO_EXTRA_COST = 25f;    // + biaya Lesatan (15) = 40 energi
    private static final int COMBO_COOLDOWN = 160;        // 8 detik (terpisah dari Lesatan)
    private static final float COMBO_MAX_HEALTH = 1000f;  // musuh yang lebih kuat dari ini nggak bisa dikombo
    private static final float COMBO_UPPERCUT_DAMAGE = 30f;
    private static final float COMBO_SMASH_DAMAGE = 36f;
    private static final float COMBO_IMPACT_DAMAGE = 36f;
    private static final float COMBO_SPLASH_DAMAGE = 20f; // musuh lain di sekitar kawah
    private static final float COMBO_HEAT_DAMAGE = 12f;   // 4 sorotan sinar panas di kawah
    // 0.37 Ledakan Surya (Shift + R): jurus pamungkas
    private static final float NOVA_MIN_ENERGY = 250f;    // butuh energi segini; semuanya dibakar (sisa NOVA_KEEP_ENERGY)
    private static final float NOVA_KEEP_ENERGY = 50f;
    private static final double NOVA_RADIUS = 30.0;
    private static final float NOVA_MIN_DAMAGE = 90f;     // + 0,15 per energi yang dibakar (energi 1000 -> ±232)
    private static final float NOVA_DAMAGE_PER_ENERGY = 0.15f;
    private static final int NOVA_COOLDOWN = 900;       // 45 detik (terpisah dari Gelegar Surya)
    // =========================================================================

    private static final Map<UUID, long[]> READY_AT = new HashMap<>();
    private static final Map<UUID, Long> CALL_READY_AT = new HashMap<>();
    private static final Map<UUID, Long> RESCUE_READY_AT = new HashMap<>();
    private static final Map<UUID, Long> IRIS_UNTIL = new HashMap<>();
    private static final Map<UUID, Long> FROST_UNTIL = new HashMap<>();
    private static final Map<UUID, Barrage> BARRAGES = new HashMap<>();
    private static final Map<UUID, long[]> SLAMS = new HashMap<>();       // {mulai, mulai menukik}
    private static final Map<UUID, Float> FLARE_POWER = new HashMap<>();
    private static final Map<UUID, Long> RAGE_UNTIL = new HashMap<>();
    private static final Map<UUID, Long> KELAM_UNTIL = new HashMap<>();
    private static final Set<UUID> KELAM_ON = new HashSet<>();
    private static final Map<UUID, Long> QUIET_UNTIL = new HashMap<>();   // jeda efek pantulan & kabar Kelam
    private static final Map<UUID, Lift> LIFTS = new HashMap<>();          // 0.36 musuh yang sedang diangkat
    private static final List<Flung> FLUNG = new ArrayList<>();            // 0.36 musuh yang sedang melayang dilempar
    private static final Map<LivingEntity, Ice> ICED = new HashMap<>();    // 0.36 patung es (kunci = makhluknya)
    private static final Map<UUID, Long> GALE_UNTIL = new HashMap<>();      // 0.37 Napas Topan
    private static final Map<UUID, Combo> COMBOS = new HashMap<>();         // 0.37 Kombo Langit yang sedang berjalan
    private static final Map<UUID, Long> COMBO_READY_AT = new HashMap<>();
    private static final Map<UUID, Long> NOVA_READY_AT = new HashMap<>();   // 0.37 Ledakan Surya
    private static final Map<UUID, Float> NOVA_POWER = new HashMap<>();

    private static final List<Holder<MobEffect>> DEBUFFS = List.of(
            MobEffects.MOVEMENT_SLOWDOWN, MobEffects.WEAKNESS, MobEffects.BLINDNESS, MobEffects.DARKNESS,
            MobEffects.DIG_SLOWDOWN, MobEffects.CONFUSION, MobEffects.POISON, MobEffects.WITHER, MobEffects.HUNGER);

    /** Amukan Kilat ke satu sasaran, mulai game time start. */
    private record Barrage(LivingEntity target, long start) {}

    /** 0.36 Angkat & Lempar: musuh yang diangkat (mulai game time start) dan yang sedang melayang dilempar. */
    private record Lift(LivingEntity target, long start) {}

    private record Flung(UUID owner, LivingEntity target, long start) {}

    /** 0.36 Patung es: siapa yang membekukan, sampai kapan, dan arah hadap yang dikunci. */
    private record Ice(UUID owner, long until, float yaw) {}

    /** 0.37 Kombo Langit: sasarannya, mulai, dan tick sasaran menghantam tanah (-1 = belum). */
    private record Combo(LivingEntity target, long start, long impact) {}

    // ----------------------------------------------------------- Pakai skill

    public static void use(ServerPlayer player, Skill skill) {
        if (!ShazamPowers.isLintang(player)) {
            if (ShazamPowers.data(player).anyUnlocked()) {
                player.displayClientMessage(Component.translatable("message.shazammod.not_transformed_lintang")
                        .withStyle(ChatFormatting.GRAY), true);
            }
            return;
        }
        if (skill == Skill.GELEGAR && player.isShiftKeyDown()) {   // 0.37 Shift + R: Ledakan Surya (biaya & jeda sendiri)
            novaUse(player);
            return;
        }
        if (skill == Skill.LESATAN && player.isShiftKeyDown() && comboUse(player)) {   // 0.37 Shift + Z: Kombo Langit
            return;
        }
        if (cooldownTicks(player, skill) > 0) {
            return;
        }
        if (ShazamPowers.data(player).energy() < skill.cost) {
            player.displayClientMessage(Component.translatable("message.shazammod.skill_no_energy",
                    Math.round(skill.cost)).withStyle(ChatFormatting.RED), true);
            return;
        }
        boolean used = switch (skill) {
            case LESATAN -> lesatan(player);
            case IRIS -> iris(player);
            case NAPAS -> napas(player);
            case TEPUKAN -> tepukan(player);
            case AMUKAN -> amukan(player);
            case NAPAK -> napak(player);
            case GELEGAR -> gelegar(player);
        };
        if (!used) {
            player.displayClientMessage(Component.translatable("message.shazammod.no_target")
                    .withStyle(ChatFormatting.GRAY), true);
            return;
        }
        ShazamData data = ShazamPowers.data(player);
        ShazamPowers.setData(player, data.withEnergy(data.energy() - skill.cost));
        READY_AT.computeIfAbsent(player.getUUID(), id -> new long[Skill.values().length])[skill.ordinal()] =
                player.level().getGameTime() + skill.cooldownTicks;
        ShazamNetwork.sync(player);
    }

    public static int cooldownTicks(ServerPlayer player, Skill skill) {
        long[] readyAt = READY_AT.get(player.getUUID());
        if (readyAt == null) {
            return 0;
        }
        long left = readyAt[skill.ordinal()] - player.level().getGameTime();
        return left > 0 ? (int) left : 0;
    }

    private static int left(Map<UUID, Long> map, ServerPlayer player) {
        Long ready = map.get(player.getUUID());
        if (ready == null) {
            return 0;
        }
        long left = ready - player.level().getGameTime();
        return left > 0 ? (int) left : 0;
    }

    public static int callCooldownTicks(ServerPlayer player) {
        return left(CALL_READY_AT, player);
    }

    public static int rescueCooldownTicks(ServerPlayer player) {
        return left(RESCUE_READY_AT, player);
    }

    /** Efek dijalankan beberapa tick lagi, dan dibatalkan kalau pemain keburu balik jadi manusia. */
    private static void later(ServerPlayer player, int delay, Consumer<ServerPlayer> action) {
        ShazamPowers.schedule(player, delay, p -> {
            if (ShazamPowers.isLintang(p)) {
                action.accept(p);
            }
        });
    }

    // ----------------------------------------------------------- Daya Surya

    /** 0..1: kekuatan Lintang dari cahaya tersimpan (energi), dikali KELAM_POWER kalau Batu Kelam dekat. */
    public static float powerAt(float energy, boolean kelam) {
        float k = energy >= FULL_POWER_ENERGY ? 1f : MIN_POWER + (1f - MIN_POWER) * Math.max(0f, energy) / FULL_POWER_ENERGY;
        return kelam ? k * KELAM_POWER : k;
    }

    public static float power(ServerPlayer player) {
        return powerAt(ShazamPowers.data(player).energy(), kelamExposed(player));
    }

    /** Persen Daya Surya buat HUD. */
    public static int powerPercent(ServerPlayer player) {
        return Math.round(power(player) * 100f);
    }

    /** Damage yang diterima pada daya ini (0,32 = 32% saat penuh). */
    public static float takenAt(float power) {
        return ShazamPowers.LINTANG_DAMAGE_TAKEN_MULTIPLIER + (1f - power) * WEAK_TAKEN_BONUS;
    }

    /** Tinju tangan kosong pada daya ini (48 saat penuh). */
    public static float punchAt(float power) {
        return ShazamPowers.LINTANG_PUNCH_MULTIPLIER * power;
    }

    public static float damageTakenMultiplier(ServerPlayer player) {
        return takenAt(power(player));
    }

    public static float punchMultiplier(ServerPlayer player) {
        return punchAt(power(player));
    }

    /** Malam hari di bawah langit terbuka: cahaya bintang. */
    public static boolean starlit(ServerPlayer player) {
        return !ShazamPowers.isInSun(player) && PassiveConditions.skyLight(player.level(), player.blockPosition());
    }

    /** Energi per detik (ShazamPowers.tick): matahari & bintang mengisi, gelap & Batu Kelam menguras. */
    public static float energyPerSecond(ServerPlayer player, boolean transformed) {
        boolean kelam = kelamExposed(player);
        boolean sun = ShazamPowers.isInSun(player);
        boolean sky = PassiveConditions.skyLight(player.level(), player.blockPosition());
        boolean voidDim = player.level().dimensionType().hasFixedTime();   // Nether & End
        if (transformed) {
            if (kelam) {
                return -ShazamPowers.LINTANG_KELAM_DRAIN_PER_SECOND;
            }
            if (sun) {   // 0.40 fisika: sebanding sinar yang sampai (ketinggian matahari, cuaca)
                return ShazamPowers.LINTANG_SUN_CHARGE_PER_SECOND * (0.35f + 0.65f * LintangPhysics.solarIrradiance(player));
            }
            if (sky) {
                return ShazamPowers.LINTANG_SKY_CHARGE_PER_SECOND;
            }
            return -(voidDim ? ShazamPowers.LINTANG_VOID_DRAIN_PER_SECOND : ShazamPowers.LINTANG_DARK_DRAIN_PER_SECOND);
        }
        if (kelam) {
            return 0f;
        }
        float rate = ShazamPowers.LINTANG_RECHARGE_PER_SECOND;
        return sun ? rate * ShazamPowers.LINTANG_SUN_RECHARGE_MULTIPLIER : voidDim ? rate * 0.5f : rate;
    }

    /** Darah pulih per detik: x2 di bawah matahari, berhenti dekat Batu Kelam. */
    public static float regenPerSecond(ServerPlayer player) {
        if (kelamExposed(player)) {
            return 0f;
        }
        return ShazamPowers.LINTANG_REGEN_PER_SECOND * (ShazamPowers.isInSun(player) ? 2f : 1f);
    }

    // ----------------------------------------------------------- Tiap tick

    public static void tick(ServerPlayer player) {
        UUID id = player.getUUID();
        long now = player.level().getGameTime();
        if (player.tickCount % KELAM_SCAN_TICKS == 0) {
            kelamScan(player, now);
        }
        Long iris = IRIS_UNTIL.get(id);
        if (iris != null) {
            if (now >= iris) {
                IRIS_UNTIL.remove(id);
            } else if ((iris - now) % 4 == 0) {
                irisStep(player);
            }
        }
        Long frost = FROST_UNTIL.get(id);
        if (frost != null) {
            if (now >= frost) {
                FROST_UNTIL.remove(id);
            } else if ((frost - now) % 4 == 0) {
                frostStep(player, (frost - now) % 12 == 0);
            }
        }
        Long gale = GALE_UNTIL.get(id);   // 0.37 Napas Topan
        if (gale != null) {
            if (now >= gale) {
                GALE_UNTIL.remove(id);
            } else if ((gale - now) % 2 == 0) {
                galeStep(player, (gale - now) % 4 == 0);
            }
        }
        Combo combo = COMBOS.get(id);     // 0.37 Kombo Langit
        if (combo != null) {
            comboStep(player, combo, now);
        }
        Barrage barrage = BARRAGES.get(id);
        if (barrage != null) {
            barrageStep(player, barrage, (int) (now - barrage.start()));
        }
        long[] slam = SLAMS.get(id);
        if (slam != null) {
            slamStep(player, slam, now);
        }
        Lift lift = LIFTS.get(id);   // 0.36 Angkat & Lempar
        if (lift != null) {
            liftHold(player, lift, now);
        }
        tickFlung(player, now);
        LintangPhysics.tick(player); // 0.40 benda terlempar (energi kinetik) & gelombang tekanan yang merambat
        iceTick(player, now);        // 0.36 patung es
        LintangDog.tick(player);     // 0.36 anjing super
        Long rage = RAGE_UNTIL.get(id);
        if (rage != null) {
            if (now >= rage) {
                endRage(player);
                ShazamNetwork.broadcastState(player);
            } else if ((rage - now) % 20 == 0) {
                rageLances(player);
            }
        }
        ShazamPassives.tick(player);   // Serapan Cahaya tiap 2 detik, Muatan Cahaya, Tepisan Beku, Hati Pahlawan
    }

    /** Hentikan skill yang sedang berjalan (balik jadi manusia, respawn). Cooldown tetap jalan. */
    public static void cancelActive(ServerPlayer player) {
        UUID id = player.getUUID();
        IRIS_UNTIL.remove(id);
        FROST_UNTIL.remove(id);
        LIFTS.remove(id);
        FLUNG.removeIf(f -> f.owner().equals(id));
        GALE_UNTIL.remove(id);
        COMBOS.remove(id);
        NOVA_POWER.remove(id);
        ICED.entrySet().removeIf(entry -> {   // es langsung pecah (nggak ada yang tersimpan di makhluknya)
            if (!entry.getValue().owner().equals(id)) {
                return false;
            }
            if (entry.getKey().isAlive()) {
                ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_ICE_BREAK, chest(entry.getKey()));
            }
            return true;
        });
        LintangDog.release(player);
        BARRAGES.remove(id);
        SLAMS.remove(id);
        FLARE_POWER.remove(id);
        KELAM_UNTIL.remove(id);
        KELAM_ON.remove(id);
        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null) {
            speed.removeModifier(KELAM_SLOW_ID);
        }
        endRage(player);
    }

    public static void forget(UUID id) {
        LintangPhysics.forget(id);   // 0.40
        GALE_UNTIL.remove(id);
        COMBOS.remove(id);
        COMBO_READY_AT.remove(id);
        NOVA_READY_AT.remove(id);
        NOVA_POWER.remove(id);
        LIFTS.remove(id);
        FLUNG.removeIf(f -> f.owner().equals(id));
        ICED.values().removeIf(ice -> ice.owner().equals(id));
        LintangDog.forget(id);
        READY_AT.remove(id);
        CALL_READY_AT.remove(id);
        RESCUE_READY_AT.remove(id);
        IRIS_UNTIL.remove(id);
        FROST_UNTIL.remove(id);
        BARRAGES.remove(id);
        SLAMS.remove(id);
        FLARE_POWER.remove(id);
        RAGE_UNTIL.remove(id);
        KELAM_UNTIL.remove(id);
        KELAM_ON.remove(id);
        QUIET_UNTIL.remove(id);
    }

    public static boolean isRageActive(ServerPlayer player) {
        Long until = RAGE_UNTIL.get(player.getUUID());
        return until != null && until > player.level().getGameTime();
    }

    private static List<LivingEntity> enemies(ServerPlayer player, Vec3 center, double radius) {
        return player.serverLevel().getEntitiesOfClass(LivingEntity.class, new AABB(center, center).inflate(radius),
                m -> m.isAlive() && m instanceof Enemy && !DemonSoldier.isFriendly(m)
                        && m.distanceToSqr(center) <= radius * radius);
    }

    private static void sound(ServerPlayer player, Vec3 at, SoundEvent sound, float volume, float pitch) {
        player.serverLevel().playSound(null, at.x, at.y, at.z, sound, SoundSource.PLAYERS, volume, pitch);
    }

    private static Vec3 flatLook(ServerPlayer player) {
        Vec3 look = player.getViewVector(1f);
        Vec3 flat = new Vec3(look.x, 0, look.z);
        if (flat.lengthSqr() < 1.0E-4) {
            float yaw = player.getYRot() * Mth.DEG_TO_RAD;
            flat = new Vec3(-Mth.sin(yaw), 0, Mth.cos(yaw));
        }
        return flat.normalize();
    }

    private static Vec3 away(Vec3 center, LivingEntity entity) {
        Vec3 away = new Vec3(entity.getX() - center.x, 0, entity.getZ() - center.z);
        return away.lengthSqr() < 1.0E-4 ? Vec3.ZERO : away.normalize();
    }

    private static Vec3 chest(LivingEntity entity) {
        return entity.position().add(0, entity.getBbHeight() * 0.55, 0);
    }

    // ----------------------------------------------------------- Batu Kelam (kelemahan)

    public static boolean kelamExposed(ServerPlayer player) {
        Long until = KELAM_UNTIL.get(player.getUUID());
        return until != null && until > player.level().getGameTime();
    }

    public static boolean isKelam(ItemStack stack) {
        return !stack.isEmpty() && (stack.is(LintangItems.KELAM_SHARD.get()) || stack.is(LintangItems.KELAM_ORE_ITEM.get()));
    }

    public static boolean holdsKelam(LivingEntity entity) {
        return isKelam(entity.getMainHandItem()) || isKelam(entity.getOffhandItem());
    }

    /**
     * Ada Batu Kelam di dekat pemain ini? Dipakai server dan client (efek untuk pemain lain): dibawa sendiri (cuma kalau
     * ownInventory), dipegang makhluk lain, tergeletak di tanah, atau bijihnya di batu sekitar.
     */
    public static boolean kelamAround(Level level, Player player, boolean ownInventory) {
        if (ownInventory) {
            Inventory inventory = player.getInventory();
            for (int i = 0; i < inventory.getContainerSize(); i++) {
                if (isKelam(inventory.getItem(i))) {
                    return true;
                }
            }
        }
        AABB area = player.getBoundingBox().inflate(KELAM_ENTITY_RADIUS);
        if (!level.getEntitiesOfClass(LivingEntity.class, area, e -> e != player && e.isAlive() && holdsKelam(e)).isEmpty()
                || !level.getEntitiesOfClass(ItemEntity.class, area, item -> isKelam(item.getItem())).isEmpty()) {
            return true;
        }
        BlockPos c = player.blockPosition();
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        int r = KELAM_BLOCK_RADIUS;
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r + 1; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    p.set(c.getX() + dx, c.getY() + dy, c.getZ() + dz);
                    if (level.getBlockState(p).is(LintangItems.KELAM_ORE.get())) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /** Tiap KELAM_SCAN_TICKS: cahaya terhisap selama Batu Kelam dekat (nggak bisa terbang, lambat, daya separuh). */
    private static void kelamScan(ServerPlayer player, long now) {
        UUID id = player.getUUID();
        boolean found = kelamAround(player.serverLevel(), player, true);
        if (found) {
            KELAM_UNTIL.put(id, now + KELAM_SCAN_TICKS + 2);
            if (!player.isCreative() && !player.isSpectator()
                    && (player.getAbilities().mayfly || player.getAbilities().flying)) {
                player.getAbilities().flying = false;
                player.getAbilities().mayfly = false;
                player.onUpdateAbilities();
            }
            if (KELAM_ON.add(id)) {
                AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
                if (speed != null && !speed.hasModifier(KELAM_SLOW_ID)) {
                    speed.addTransientModifier(new AttributeModifier(KELAM_SLOW_ID, KELAM_SLOW,
                            AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
                }
                ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_KELAM, player.position());
                sound(player, player.position(), ShazamSounds.KELAM_HUM.get(), 1.2f, 1f);
                player.displayClientMessage(Component.translatable("message.shazammod.kelam_near")
                        .withStyle(ChatFormatting.DARK_PURPLE), true);
                ShazamNetwork.sync(player);
            }
        } else if (KELAM_ON.remove(id)) {
            AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
            if (speed != null) {
                speed.removeModifier(KELAM_SLOW_ID);
            }
            player.displayClientMessage(Component.translatable("message.shazammod.kelam_clear")
                    .withStyle(ChatFormatting.AQUA), true);
            ShazamNetwork.sync(player);
        }
    }

    /** Pukulan (bukan proyektil) dari makhluk yang memegang Batu Kelam. */
    public static boolean isKelamHit(DamageSource source) {
        return source.getEntity() instanceof LivingEntity attacker && source.getDirectEntity() == attacker
                && holdsKelam(attacker);
    }

    /** Dipukul dengan Batu Kelam: cahaya terhisap keluar dari tubuh. */
    public static void kelamWound(ServerPlayer victim) {
        ShazamData data = ShazamPowers.data(victim);
        ShazamPowers.setData(victim, data.withEnergy(data.energy() - KELAM_HIT_DRAIN));
        long now = victim.level().getGameTime();
        Long quiet = QUIET_UNTIL.get(victim.getUUID());
        if (quiet == null || now >= quiet) {
            QUIET_UNTIL.put(victim.getUUID(), now + 40);
            ShazamNetwork.playAnim(victim, ShazamAnim.LINTANG_KELAM, victim.position());
            victim.displayClientMessage(Component.translatable("message.shazammod.kelam_hit")
                    .withStyle(ChatFormatting.DARK_PURPLE), true);
        }
    }

    // ----------------------------------------------------------- Kulit Baja

    /** Serangan lemah dari makhluk memantul dari kulit Lintang (bukan sihir, bukan Batu Kelam, bukan saat dekat Kelam). */
    public static boolean bounces(ServerPlayer victim, DamageSource source, float amount) {
        if (ShazamPowers.LINTANG_TOUGH_SKIN <= 0f || amount >= ShazamPowers.LINTANG_TOUGH_SKIN || kelamExposed(victim)) {
            return false;
        }
        if (source.getEntity() == null && source.getDirectEntity() == null) {
            return false;
        }
        return !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY) && !source.is(DamageTypes.MAGIC)
                && !source.is(DamageTypes.INDIRECT_MAGIC);
    }

    public static void bounce(ServerPlayer victim, DamageSource source) {
        long now = victim.level().getGameTime();
        Long quiet = QUIET_UNTIL.get(victim.getUUID());
        if (quiet != null && now < quiet) {
            return;   // hujan panah: efeknya nggak perlu tiap anak panah
        }
        QUIET_UNTIL.put(victim.getUUID(), now + 4);
        Entity from = source.getDirectEntity() != null ? source.getDirectEntity() : source.getEntity();
        Vec3 c = chest(victim);
        Vec3 hit = c;
        if (from != null) {
            Vec3 toward = from.position().add(0, from.getBbHeight() * 0.5, 0).subtract(c);
            if (toward.lengthSqr() > 1.0E-4) {
                hit = c.add(toward.normalize().scale(0.5));
            }
        }
        ShazamNetwork.playAnim(victim, ShazamAnim.LINTANG_BOUNCE, hit);
        sound(victim, hit, ShazamSounds.DEFLECT.get(), 0.9f, ShazamSounds.tune(1.7f));
    }

    // ---------------------------------------------------- L - Lesatan Bintang

    private static final double LESAT_SPEED = 2.0;   // 0.40 kecepatan lesatan (blok/tick = 40 m/s) buat tumbukan

    private static boolean lesatan(ServerPlayer player) {
        Vec3 look = player.getViewVector(1f);
        Vec3 from = player.position();
        Vec3 eye = from.add(0, 0.9, 0);
        BlockHitResult hit = player.level().clip(new ClipContext(eye, eye.add(look.scale(LESAT_RANGE)), ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, player));
        double reach = LESAT_RANGE;
        if (hit.getType() != HitResult.Type.MISS) {
            reach = Math.max(1.5, hit.getLocation().distanceTo(eye) - 1.0);
        }
        Vec3 end = from.add(look.scale(reach));
        ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_DASH, end);
        sound(player, from, ShazamSounds.SPEED_DASH.get(), 1.6f, 1f);
        later(player, ShazamAnim.LESAT_WINDUP + ShazamAnim.LESAT_TICKS / 2, p -> dashHits(p, from, end));
        later(player, ShazamAnim.LESAT_WINDUP + ShazamAnim.LESAT_TICKS, p -> dashEnd(p, end));
        return true;
    }

    /** Musuh di sepanjang jalur lesatan tertabrak & terlempar ke samping. */
    private static void dashHits(ServerPlayer player, Vec3 a, Vec3 b) {
        Vec3 ab = b.subtract(a);
        double len2 = Math.max(1.0E-4, ab.lengthSqr());
        DamageSource source = ShazamPowers.forceSource(player);
        AABB box = new AABB(a, b).inflate(LESAT_HIT_RADIUS + 1.0);
        for (LivingEntity target : player.serverLevel().getEntitiesOfClass(LivingEntity.class, box,
                m -> m.isAlive() && m instanceof Enemy && !DemonSoldier.isFriendly(m))) {
            Vec3 c = chest(target);
            double t = Mth.clamp(c.subtract(a).dot(ab) / len2, 0.0, 1.0);
            Vec3 closest = a.add(ab.scale(t)).add(0, 0.9, 0);
            if (closest.distanceToSqr(c) > LESAT_HIT_RADIUS * LESAT_HIT_RADIUS) {
                continue;
            }
            // 0.40 fisika: tumbukan lenting dengan badan Lintang (400 kg, melaju ~2 blok/tick). Sasaran ringan terpental
            // hampir 2x kecepatannya, yang berat cuma tergeser; tabrakan menyerong membelokkan sasaran ke samping
            Vec3 side = new Vec3(c.x - closest.x, 0, c.z - closest.z);
            Vec3 along = ab.normalize();
            Vec3 v = along.scale(LESAT_SPEED).add(side.lengthSqr() < 1.0E-4 ? Vec3.ZERO : side.normalize().scale(LESAT_SPEED * 0.45));
            double joule = LintangPhysics.collide(player, target, LintangPhysics.LINTANG_MASS, v);
            LintangPhysics.hurtByEnergy(player, target, joule, LESAT_DAMAGE * 2.5f);
            ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_HIT, c);
        }
    }

    /** 0.40 fisika: berhenti mendadak, udara yang terbawa lesatan terus melaju jadi gelombang tekanan ke depan. */
    private static void dashEnd(ServerPlayer player, Vec3 end) {
        Vec3 look = player.getViewVector(1f);
        LintangPhysics.blast(player, end.add(0, 0.9, 0), look, 0.2, LESAT_END_RADIUS + 2.0, LESAT_END_DAMAGE, 70.0, 3.5,
                LESAT_END_CORE);
    }

    // ---------------------------------------------------- I - Iris Surya

    private static final float IRIS_HEAT_PER_PULSE = 260f;   // 0.40 °C per denyut (tiap 4 tick) di titik kena

    private static boolean iris(ServerPlayer player) {
        if (player.isShiftKeyDown() && !LIFTS.containsKey(player.getUUID())) {   // 0.36 Shift + X: Angkat & Lempar
            LivingEntity target = liftTarget(player);
            if (target != null) {
                return lift(player, target);
            }
        }
        ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_EYES);
        sound(player, player.getEyePosition(), ShazamSounds.HEAT_VISION.get(), 1.8f, 1f);
        later(player, ShazamAnim.IRIS_WINDUP, p -> IRIS_UNTIL.put(p.getUUID(), p.level().getGameTime() + ShazamAnim.IRIS_TICKS));
        return true;
    }

    /**
     * Satu denyut sinar: menembus sampai IRIS_PIERCE musuh di jalurnya, lalu berhenti di blok. 0.36: blok yang kena
     * dibakar/dilelehkan (burn), jadi sinar yang ditahan ke satu arah perlahan menembus penghalang. Patung es mencair.
     */
    /**
     * 0.40 fisika: sinar panas menembus kaca (sedikit melemah tiap lapis) dan berhenti di blok buram atau air. Blok yang
     * terus disorot makin panas sampai bahannya berubah (LintangPhysics.heatBlock); musuh di jalurnya menumpuk panas,
     * damage-nya naik, lalu terbakar (LintangPhysics.heatEntity).
     */
    private static void irisStep(ServerPlayer player) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getViewVector(1f);
        float[] power = {1f};
        BlockHitResult hit = LintangPhysics.beamClip(player, eye, look, IRIS_RANGE, power);
        boolean block = hit != null && hit.getType() != HitResult.Type.MISS;
        double reach = block ? hit.getLocation().distanceTo(eye) : IRIS_RANGE;
        int pierced = 0;
        for (LivingEntity target : beamTargets(player, eye, look, reach)) {
            LintangPhysics.heatEntity(player, target, IRIS_HEAT_PER_PULSE * power[0], IRIS_DAMAGE * power[0]);
            if (++pierced >= IRIS_PIERCE) {
                break;
            }
        }
        if (block) {
            float t = LintangPhysics.heatBlock(player, hit.getBlockPos(), hit.getDirection(), IRIS_HEAT_PER_PULSE * power[0]);
            if (IRIS_BURNS_BLOCKS && t >= 300f) {
                burn(player, hit);   // 0.36 penghalang tipis (jeruji, sarang laba-laba) langsung terbakar putus
            }
        }
    }

    private static List<LivingEntity> beamTargets(ServerPlayer player, Vec3 from, Vec3 dir, double reach) {
        List<LivingEntity> out = new ArrayList<>();
        AABB area = new AABB(from, from.add(dir.scale(reach))).inflate(1.0);
        for (LivingEntity e : player.serverLevel().getEntitiesOfClass(LivingEntity.class, area,
                m -> m.isAlive() && m != player && m instanceof Enemy && !DemonSoldier.isFriendly(m))) {
            AABB box = e.getBoundingBox().inflate(0.35);
            for (double s = 0.5; s <= reach; s += 0.5) {
                if (box.contains(from.add(dir.scale(s)))) {
                    out.add(e);
                    break;
                }
            }
        }
        out.sort(Comparator.comparingDouble(e -> e.distanceToSqr(from)));
        return out;
    }

    private static void melt(ServerLevel level, BlockPos pos) {
        for (BlockPos p : new BlockPos[] {pos, pos.above()}) {
            BlockState state = level.getBlockState(p);
            if (state.is(Blocks.SNOW) || state.is(Blocks.SNOW_BLOCK) || state.is(Blocks.POWDER_SNOW)) {
                level.destroyBlock(p, false);
            } else if (state.is(Blocks.ICE) || state.is(Blocks.FROSTED_ICE)) {
                level.setBlockAndUpdate(p, Blocks.WATER.defaultBlockState());
            }
        }
    }

    // ---------------------------------------------------- N - Napas Salju

    private static boolean napas(ServerPlayer player) {
        if (player.isShiftKeyDown()) {   // 0.37 Shift + C: Napas Topan (menerbangkan, bukan membekukan)
            ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_GUST);
            sound(player, player.position(), ShazamSounds.SUPER_BREATH.get(), 2.2f, 1f);
            later(player, ShazamAnim.FROST_WINDUP, p -> GALE_UNTIL.put(p.getUUID(), p.level().getGameTime() + ShazamAnim.FROST_TICKS));
            return true;
        }
        ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_BREATH);
        sound(player, player.position(), ShazamSounds.FROST_BREATH.get(), 2.0f, 1f);
        later(player, ShazamAnim.FROST_WINDUP, p -> FROST_UNTIL.put(p.getUUID(), p.level().getGameTime() + ShazamAnim.FROST_TICKS));
        return true;
    }

    private static void frostStep(ServerPlayer player, boolean freezeGround) {
        Vec3 mouth = player.getEyePosition().add(0, -0.15, 0);
        Vec3 look = player.getViewVector(1f);
        DamageSource source = ShazamPowers.forceSource(player);
        for (LivingEntity target : enemies(player, mouth, FROST_RANGE)) {
            Vec3 to = chest(target).subtract(mouth);
            if (to.lengthSqr() < 1.0E-4 || to.normalize().dot(look) < FROST_CONE_COS || !player.hasLineOfSight(target)) {
                continue;
            }
            target.invulnerableTime = 0;
            target.hurt(source, FROST_DAMAGE);
            target.clearFire();
            target.setTicksFrozen(Math.min(target.getTicksFrozen() + FROST_FREEZE_PER_STEP, FROST_FREEZE_MAX));
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, FROST_SLOW_TICKS, 2));
            if (ICED.containsKey(target)) {
                continue;   // sudah jadi patung es: nggak terdorong lagi
            }
            if (target.isAlive() && target.getTicksFrozen() >= target.getTicksRequiredToFreeze()
                    && target.getMaxHealth() <= ICE_MAX_HEALTH) {
                encase(player, target);   // 0.36 membeku penuh: jadi patung es
                continue;
            }
            Vec3 push = look.scale(0.08);
            target.push(push.x, 0.0, push.z);
            target.hurtMarked = true;
        }
        if (freezeGround) {   // air di ujung hembusan membeku, api padam
            ServerLevel level = player.serverLevel();
            BlockHitResult hit = level.clip(new ClipContext(mouth, mouth.add(look.scale(FROST_RANGE)), ClipContext.Block.COLLIDER,
                    ClipContext.Fluid.ANY, player));
            if (hit.getType() == HitResult.Type.MISS) {
                return;
            }
            BlockPos center = hit.getBlockPos();
            for (int dx = -2; dx <= 2; dx++) {   // 0.40 fisika: air membeku, lava memadat, api padam, embun jadi salju
                for (int dz = -2; dz <= 2; dz++) {
                    if (dx * dx + dz * dz > 5) {
                        continue;
                    }
                    for (int dy = -1; dy <= 1; dy++) {
                        LintangPhysics.chill(player, level, center.offset(dx, dy, dz));
                    }
                }
            }
        }
    }

    // ---------------------------------------------------- T - Tepukan Guruh

    private static boolean tepukan(ServerPlayer player) {
        ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_CLAP);
        later(player, ShazamAnim.SONIC_WINDUP, LintangSkills::clap);
        return true;
    }

    private static void clap(ServerPlayer player) {
        Vec3 origin = player.getEyePosition().add(0, -0.4, 0);
        Vec3 look = player.getViewVector(1f);
        sound(player, origin, ShazamSounds.SONIC_CLAP.get(), 3.0f, 1f);
        // 0.40 fisika: tepukan memampatkan udara jadi gelombang tekanan yang merambat ke depan; makin jauh makin telat &
        // makin lemah (~1/r), makhluk ringan terlempar jauh, kaca dalam jangkauan pecah, proyektil berbelok, api padam.
        // 0.41: tepukan Lintang menggebrak udara selebar CLAP_CORE blok, jadi tekanan puncaknya rata sampai sejauh itu
        LintangPhysics.blast(player, origin, look, CLAP_CONE_COS, CLAP_RANGE + 4.0, CLAP_DAMAGE * 2.0, CLAP_IMPULSE, CLAP_GLASS_RANGE,
                CLAP_CORE);
        for (LivingEntity target : enemies(player, origin, CLAP_RANGE * 0.6)) {   // dekat sumbernya: telinga berdenging
            Vec3 to = chest(target).subtract(origin);
            if (to.lengthSqr() > 1.0E-4 && to.normalize().dot(look) >= CLAP_CONE_COS) {
                target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, CLAP_STUN_TICKS, 3));
                target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, CLAP_STUN_TICKS, 1));
            }
        }
    }

    private static final double CLAP_IMPULSE = 260.0;     // 0.40 impuls per m^2 pada jarak 1 blok
    private static final double CLAP_GLASS_RANGE = 14.0;  // 0.40 kaca pecah sampai jarak ini

    // ---------------------------------------------------- A - Amukan Kilat

    /** Musuh terdekat di depan (dalam jangkauan, terlihat). */
    private static LivingEntity frontTarget(ServerPlayer player, double reach) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getViewVector(1f);
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        for (LivingEntity e : enemies(player, eye, reach)) {
            Vec3 to = chest(e).subtract(eye);
            double d = to.length();
            if (d < 0.01) {
                continue;
            }
            double dot = to.normalize().dot(look);
            if (dot < 0.5 || !player.hasLineOfSight(e)) {
                continue;
            }
            double score = d * (2.0 - dot);
            if (score < bestScore) {
                bestScore = score;
                best = e;
            }
        }
        return best;
    }

    private static final double BARRAGE_HIT_IMPULSE = 22.0;     // 0.40 kg·blok/tick per pukulan
    private static final double BARRAGE_FINAL_IMPULSE = 380.0;  // 0.40 pukulan penutup

    private static boolean amukan(ServerPlayer player) {
        LivingEntity target = frontTarget(player, BARRAGE_REACH);
        if (target == null) {
            return false;
        }
        Vec3 to = target.position().subtract(player.position());
        if (to.horizontalDistance() > 2.4) {   // melesat ke depan sasaran dulu
            Vec3 dir = new Vec3(to.x, 0, to.z).normalize();
            double speed = Math.min(1.6, (to.horizontalDistance() - 1.6) * 0.5);
            player.setDeltaMovement(dir.x * speed, Math.max(0.0, to.y * 0.1), dir.z * speed);
            player.hurtMarked = true;
        }
        ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_BARRAGE, target.position());
        sound(player, player.position(), ShazamSounds.BARRAGE.get(), 1.6f, 1f);
        BARRAGES.put(player.getUUID(), new Barrage(target, player.level().getGameTime()));
        return true;
    }

    private static void barrageStep(ServerPlayer player, Barrage barrage, int k) {
        LivingEntity target = barrage.target();
        int w = ShazamAnim.BARRAGE_WINDUP, end = w + ShazamAnim.BARRAGE_TICKS;
        if (!target.isAlive() || target.distanceToSqr(player) > 36.0 || k > end) {
            BARRAGES.remove(player.getUUID());
            return;
        }
        if (k >= w && target.distanceToSqr(player) > 2.6 * 2.6) {   // 0.40: Lintang ikut maju mengejar sasaran yang terdorong
            Vec3 to = target.position().subtract(player.position());
            Vec3 dir = new Vec3(to.x, 0, to.z).normalize();
            player.setDeltaMovement(dir.x * 0.45, player.getDeltaMovement().y, dir.z * 0.45);
            player.hurtMarked = true;
        }
        if (k < w || (k != end && (k - w) % 6 != 0)) {
            return;
        }
        DamageSource source = ShazamPowers.forceSource(player);
        target.invulnerableTime = 0;
        boolean last = k == end;
        target.hurt(source, last ? BARRAGE_FINAL_DAMAGE : BARRAGE_HIT_DAMAGE);
        ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_HIT, chest(target));
        Vec3 dir = away(player.position(), target);
        if (last) {   // 0.40 fisika: pukulan penutup = impuls besar; sasaran ringan melayang jauh & menabrak apa saja
            BARRAGES.remove(player.getUUID());
            LintangPhysics.impulse(player, target, dir.add(0, 0.55, 0).scale(BARRAGE_FINAL_IMPULSE));
            sound(player, target.position(), ShazamSounds.DAWN_PUNCH.get(), 1.4f, ShazamSounds.tune(1.1f));
        } else {      // tiap pukulan menambah momentum: sasaran terdorong mundur sedikit demi sedikit
            Vec3 v = target.getDeltaMovement();
            target.setDeltaMovement(v.x * 0.3, v.y, v.z * 0.3);   // gesekan kaki di tanah
            LintangPhysics.impulse(player, target, dir.scale(BARRAGE_HIT_IMPULSE));
        }
    }

    // ---------------------------------------------------- N - Napak Langit

    private static final double NAPAK_REF_JOULE = 1.4e6;   // 0.40 energi rujukan (ukuran kawah 1x)
    // 0.41 radius sumber gelombang (LintangPhysics.blast/quake core): di dalamnya damage & dorongan penuh, di luarnya ~1/r
    private static final double NAPAK_CORE = 0.35;         // x radius hantaman (= kawahnya)
    private static final double CLAP_CORE = 3.0;           // blok
    private static final double LESAT_END_CORE = 2.0;      // blok
    private static final double LIFT_SPLASH_CORE = 2.0;    // blok
    private static final double SOLAR_CORE = 0.2;          // x radius Gelegar / Ledakan Surya (bola apinya)

    private static boolean napak(ServerPlayer player) {
        boolean grounded = player.onGround();
        if (player.getAbilities().flying) {
            player.getAbilities().flying = false;
            player.onUpdateAbilities();
            grounded = false;
        }
        ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_LEAP);
        sound(player, player.position(), ShazamSounds.SPEED_DASH.get(), 1.2f, ShazamSounds.tune(0.7f));
        long now = player.level().getGameTime();
        long top = Double.doubleToLongBits(player.getY());   // 0.40: titik tertinggi dicatat buat energi jatuh
        if (grounded) {
            Vec3 look = flatLook(player);
            player.setDeltaMovement(look.x * 0.5, NAPAK_LEAP, look.z * 0.5);
            player.hurtMarked = true;
            SLAMS.put(player.getUUID(), new long[] {now, now + ShazamAnim.LEAP_WINDUP + NAPAK_RISE_TICKS, top});
        } else {
            SLAMS.put(player.getUUID(), new long[] {now, now + ShazamAnim.LEAP_WINDUP, top});
        }
        return true;
    }

    private static void slamStep(ServerPlayer player, long[] slam, long now) {
        if (now - slam[0] > 100) {   // nggak pernah sampai tanah (misalnya di atas jurang): batal
            SLAMS.remove(player.getUUID());
            return;
        }
        if (slam.length > 2 && player.getY() > Double.longBitsToDouble(slam[2])) {
            slam[2] = Double.doubleToLongBits(player.getY());
        }
        if (now < slam[1]) {
            return;
        }
        if (now > slam[1] + 1 && (player.onGround() || player.isInWater())) {
            SLAMS.remove(player.getUUID());
            double fall = slam.length > 2 ? Double.longBitsToDouble(slam[2]) - player.getY() : 4.0;
            slamImpact(player, Math.max(1.0, fall));
            return;
        }
        if (player.getAbilities().flying) {
            player.getAbilities().flying = false;
            player.onUpdateAbilities();
        }
        Vec3 dm = player.getDeltaMovement();
        player.setDeltaMovement(dm.x * 0.4, -NAPAK_DIVE_SPEED, dm.z * 0.4);   // menukik
        player.hurtMarked = true;
    }

    /**
     * 0.40 fisika: energi hantaman E = 1/2 m v^2 dengan v = kecepatan menukik + sqrt(2 g h) dari tinggi jatuh. Ukuran
     * kawah & jangkauannya ~ akar pangkat tiga energi (seperti ledakan): jatuh dari 4x lebih tinggi -> ~1,6x lebih luas.
     * Gelombang seismik merambat di tanah & cuma melontarkan yang berpijak; udara di atasnya ikut terdorong.
     */
    private static void slamImpact(ServerPlayer player, double fall) {
        Vec3 c = player.position();
        double v = NAPAK_DIVE_SPEED + Math.sqrt(2.0 * LintangPhysics.G * fall);
        double joule = LintangPhysics.kinetic(LintangPhysics.LINTANG_MASS, v);
        double scale = Mth.clamp(Math.cbrt(joule / NAPAK_REF_JOULE), 0.6, 2.2);
        ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_SLAM, c);
        sound(player, c, ShazamSounds.SONIC_CLAP.get(), (float) (2.0 + scale), ShazamSounds.tune((float) (0.85 - 0.12 * scale)));
        double r = NAPAK_RADIUS * scale;
        double core = r * NAPAK_CORE;   // 0.41 seluruh kawah ikut berguncang penuh, baru di luar kawah melemah ~1/r
        LintangPhysics.quake(player, c, r * 1.4, NAPAK_DAMAGE * scale, 110.0 * scale, core);
        LintangPhysics.blast(player, c.add(0, 0.5, 0), null, -1.0, r, NAPAK_DAMAGE * 0.5 * scale, 60.0 * scale, r * 0.6, core);
    }

    // ---------------------------------------------------- G - Gelegar Surya & Mode Surya

    private static boolean gelegar(ServerPlayer player) {
        ShazamData data = ShazamPowers.data(player);
        float spare = Math.max(0f, data.energy() - Skill.GELEGAR.cost - FLARE_KEEP_ENERGY);   // semua cahaya dibakar
        ShazamPowers.setData(player, data.withEnergy(data.energy() - spare));
        FLARE_POWER.put(player.getUUID(), spare + Skill.GELEGAR.cost);
        ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_FLARE);
        sound(player, player.position(), ShazamSounds.SOLAR_FLARE.get(), 3.0f, 1f);
        later(player, ShazamAnim.FLARE_WINDUP, LintangSkills::flare);
        return true;
    }

    private static void flare(ServerPlayer player) {
        UUID id = player.getUUID();
        Float spent = FLARE_POWER.remove(id);
        float energy = spent == null ? Skill.GELEGAR.cost : spent;
        ServerLevel level = player.serverLevel();
        Vec3 c = player.position().add(0, 1.0, 0);
        solarBlast(player, c, energy, FLARE_RADIUS, FLARE_MIN_DAMAGE + energy * FLARE_DAMAGE_PER_ENERGY, 6f);
        RAGE_UNTIL.put(id, level.getGameTime() + ShazamAnim.RAGE_TICKS);
        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null && !speed.hasModifier(RAGE_SPEED)) {
            speed.addTransientModifier(new AttributeModifier(RAGE_SPEED, RAGE_SPEED_BONUS,
                    AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        }
        ShazamNetwork.broadcastState(player);
        ShazamNetwork.sync(player);
    }

    /**
     * 0.40 fisika ledakan tenaga surya: jangkauan ~ akar pangkat tiga energi yang dibakar (hukum skala ledakan).
     * 1) Kilat panas merambat secepat cahaya: cuma mengenai yang punya garis pandang ke Lintang (berlindung di balik
     *    dinding = selamat dari panasnya), membakar & menyilaukan. 2) Gelombang kejut menyusul dengan kecepatan suara,
     *    damage & dorongan turun ~1/r, kaca pecah.
     */
    static void solarBlast(ServerPlayer player, Vec3 c, float energy, double baseRadius, float damage, float burnSeconds) {
        double radius = baseRadius * Mth.clamp(Math.cbrt(energy / 600.0), 0.75, 1.6);
        ServerLevel level = player.serverLevel();
        for (LivingEntity target : enemies(player, c, radius)) {
            Vec3 at = chest(target);
            boolean sight = level.clip(new ClipContext(c, at, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player))
                    .getType() == HitResult.Type.MISS;
            if (!sight) {
                continue;   // terlindung dari kilat panas
            }
            double d = Math.sqrt(target.distanceToSqr(c));
            float heat = (float) (1.0 / Math.max(1.0, d * d / 16.0));   // panas radiasi turun ~1/r^2
            target.invulnerableTime = 0;
            target.hurt(ShazamPowers.forceSource(player), damage * 0.45f * heat);
            target.igniteForSeconds(burnSeconds * heat + 1f);
            target.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, (int) (30 + 50 * heat), 0));
        }
        // 0.41 bola apinya selebar SOLAR_CORE x radius: di dalamnya gelombang kejut penuh, di luarnya ~1/r
        LintangPhysics.blast(player, c, null, -1.0, radius, damage * 0.55 * 2.5, 260.0, radius * 0.7, radius * SOLAR_CORE);
    }

    private static void endRage(ServerPlayer player) {
        RAGE_UNTIL.remove(player.getUUID());
        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null) {
            speed.removeModifier(RAGE_SPEED);
        }
    }

    /**
     * 0.35 Sinar panas mata (ala Superman, pengganti tombak cahaya): sorotan singkat dari kedua mata Lintang ke musuh,
     * damage + terbakar (panas), efeknya di client (LINTANG_LANCE = sorotan mata ke titik ini).
     */
    private static void heatZap(ServerPlayer player, LivingEntity target, float damage) {
        target.hurt(ShazamPowers.forceSource(player), damage);
        target.igniteForSeconds(2f);
        ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_LANCE, chest(target));
    }

    /** Mode Surya: tiap detik sinar panas mata menyambar dua musuh terdekat. */
    private static void rageLances(ServerPlayer player) {
        List<LivingEntity> targets = enemies(player, player.position(), RAGE_LANCE_RADIUS);
        targets.sort(Comparator.comparingDouble(m -> m.distanceToSqr(player)));
        for (int i = 0; i < Math.min(2, targets.size()); i++) {
            heatZap(player, targets.get(i), RAGE_LANCE_DAMAGE);
        }
    }

    /** Pukulan Mode Surya: sinar panas mata ikut menyambar dua musuh lain di dekat sasaran. */
    public static void ragePunch(ServerPlayer player, LivingEntity target) {
        List<LivingEntity> near = enemies(player, target.position(), 6.0);
        near.remove(target);
        near.sort(Comparator.comparingDouble(m -> m.distanceToSqr(target)));
        for (int i = 0; i < Math.min(2, near.size()); i++) {
            heatZap(player, near.get(i), RAGE_PUNCH_LANCE_DAMAGE);
        }
    }

    /**
     * 0.35 Tinju Baja (ala Superman, padanan Pukulan Guntur; damage-nya sudah dikali di event pukulannya), tanpa cahaya
     * dan tanpa api: sasaran terlempar jauh dan terhuyung, udara yang terdorong pukulannya jadi gelombang kejut yang
     * menghantam sampai 3 musuh lain di sekitar sasaran (14 damage, terhempas menjauh dari sasaran).
     */
    private static final double DAWN_IMPULSE = 420.0;   // 0.41 kg·blok/tick (zombie sampai batas 3,6 blok/tick, golem ~0,66)

    public static void dawnPunch(ServerPlayer player, LivingEntity target) {
        Vec3 at = chest(target);
        ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_DAWNPUNCH, at);
        sound(player, at, ShazamSounds.DAWN_PUNCH.get(), 2.0f, 1f);
        ShazamPowers.schedule(player, 1, p -> {
            if (target.isAlive()) {   // 0.40 fisika: impuls tinju; sasaran ringan melayang jauh & menabrak apa saja
                LintangPhysics.impulse(p, target, away(p.position(), target).add(0, 0.3, 0).scale(DAWN_IMPULSE));
                target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20, 2));   // terhuyung
            }
            Vec3 hit = target.position();
            DamageSource source = ShazamPowers.forceSource(p);
            List<LivingEntity> near = enemies(p, hit, DAWN_LANCE_RADIUS);
            near.remove(target);
            near.sort(Comparator.comparingDouble(m -> m.distanceToSqr(target)));
            for (int i = 0; i < Math.min(3, near.size()); i++) {   // gelombang kejut dari titik hantaman
                LivingEntity foe = near.get(i);
                foe.hurt(source, DAWN_LANCE_DAMAGE);
                Vec3 shove = away(hit, foe).scale(1.5);
                foe.push(shove.x, 0.45, shove.z);
                foe.hurtMarked = true;
                ShazamNetwork.playAnim(p, ShazamAnim.LINTANG_HIT, chest(foe));
            }
        });
    }

    // ---------------------------------------------------- M - Serap Surya

    public static void sunCall(ServerPlayer player) {
        if (!ShazamPowers.isLintang(player) || callCooldownTicks(player) > 0) {
            return;
        }
        CALL_READY_AT.put(player.getUUID(), player.level().getGameTime() + CALL_COOLDOWN_TICKS);
        ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_CALL);
        sound(player, player.position(), ShazamSounds.SUN_CALL.get(), 2.4f, 1f);
        later(player, ShazamAnim.SUNCALL_WINDUP, p -> {
            ServerLevel level = p.serverLevel();
            Vec3 c = p.position();
            // 0.35: tanpa tiang cahaya dari langit. Sel tubuhnya menyerap sinar matahari langsung (di bawah tanah cuma
            // cadangan di tubuh), lalu panas berlebihnya dilepas sebagai gelombang panas yang menghempas
            boolean sky = PassiveConditions.skyLight(level, p.blockPosition()) && !kelamExposed(p);
            ShazamData data = ShazamPowers.data(p);
            // 0.40 fisika: yang terserap sebanding sinar matahari yang sampai (siang terik penuh, fajar/hujan lebih sedikit)
            float sun = sky ? 0.3f + 0.7f * LintangPhysics.solarIrradiance(p) : 0f;
            ShazamPowers.setData(p, data.withEnergy(data.energy() + CALL_ENERGY_DARK + (CALL_ENERGY_SKY - CALL_ENERGY_DARK) * sun));
            p.heal((sky ? CALL_HEAL_SKY : CALL_HEAL_DARK) * ShazamPowers.healScale(p));
            p.clearFire();
            for (Holder<MobEffect> debuff : DEBUFFS) {
                if (p.hasEffect(debuff)) {
                    p.removeEffect(debuff);
                }
            }
            DamageSource source = ShazamPowers.forceSource(p);
            for (LivingEntity target : enemies(p, c, CALL_RADIUS)) {
                target.hurt(source, CALL_DAMAGE);
                target.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 40, 0));
                Vec3 push = away(c, target).scale(1.3);
                target.push(push.x, 0.45, push.z);
                target.hurtMarked = true;
            }
            ShazamNetwork.sync(p);
        });
        ShazamNetwork.sync(player);
    }

    // ---------------------------------------------------- J - Selamatkan

    private static boolean isAlly(LivingEntity entity) {
        if (entity instanceof Player other) {
            return !other.isSpectator() && !other.isCreative();
        }
        return entity instanceof AbstractVillager || (entity instanceof TamableAnimal pet && pet.isTame())
                || entity instanceof IronGolem || DemonSoldier.isFriendly(entity);
    }

    public static void rescue(ServerPlayer player) {
        if (!ShazamPowers.isLintang(player)) {
            if (ShazamPowers.data(player).isLintang()) {
                player.displayClientMessage(Component.translatable("message.shazammod.not_transformed_lintang")
                        .withStyle(ChatFormatting.GRAY), true);
            }
            return;
        }
        if (rescueCooldownTicks(player) > 0) {
            return;
        }
        ShazamData data = ShazamPowers.data(player);
        if (data.energy() < RESCUE_COST) {
            player.displayClientMessage(Component.translatable("message.shazammod.skill_no_energy",
                    Math.round(RESCUE_COST)).withStyle(ChatFormatting.RED), true);
            return;
        }
        List<LivingEntity> allies = player.serverLevel().getEntitiesOfClass(LivingEntity.class,
                player.getBoundingBox().inflate(RESCUE_RADIUS), e -> e != player && e.isAlive() && isAlly(e));
        if (allies.isEmpty()) {
            player.displayClientMessage(Component.translatable("message.shazammod.rescue_none")
                    .withStyle(ChatFormatting.GRAY), true);
            return;
        }
        // yang paling terluka & paling dekat duluan
        allies.sort(Comparator.comparingDouble(e -> e.getHealth() / Math.max(1f, e.getMaxHealth()) * 100.0
                + e.distanceToSqr(player) * 0.01));
        ShazamPowers.setData(player, data.withEnergy(data.energy() - RESCUE_COST));
        RESCUE_READY_AT.put(player.getUUID(), player.level().getGameTime() + RESCUE_COOLDOWN_TICKS);
        ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_RESCUE);
        sound(player, player.position(), ShazamSounds.SPEED_DASH.get(), 1.6f, ShazamSounds.tune(1.2f));
        for (int i = 0; i < Math.min(RESCUE_MAX, allies.size()); i++) {
            LivingEntity ally = allies.get(i);
            later(player, ShazamAnim.RESCUE_WINDUP + i * 2, p -> save(p, ally));
        }
        ShazamNetwork.sync(player);
    }

    private static void save(ServerPlayer player, LivingEntity ally) {
        if (!ally.isAlive()) {
            return;
        }
        ally.heal(RESCUE_HEAL);
        ally.clearFire();
        ally.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, RESCUE_SHIELD_TICKS, 1));
        ally.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, RESCUE_SHIELD_TICKS, 1));
        ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_SAVE, chest(ally));
        sound(player, ally.position(), ShazamSounds.SOLAR_PULSE.get(), 0.9f, ShazamSounds.tune(1.3f));
        if (ally instanceof AbstractVillager) {   // 0.36 warga yang diselamatkan berterima kasih (ala DLC Superman)
            player.serverLevel().broadcastEntityEvent(ally, (byte) 14);   // wajah senang penduduk desa
            if (!player.hasEffect(MobEffects.HERO_OF_THE_VILLAGE)) {
                player.displayClientMessage(Component.translatable("message.shazammod.lintang_citizens")
                        .withStyle(ChatFormatting.AQUA), true);
            }
            player.addEffect(new MobEffectInstance(MobEffects.HERO_OF_THE_VILLAGE, CITIZEN_HERO_TICKS, 0, false, false, true));
        }
        DamageSource source = ShazamPowers.forceSource(player);
        for (LivingEntity foe : enemies(player, ally.position(), RESCUE_BLAST_RADIUS)) {
            foe.hurt(source, RESCUE_BLAST_DAMAGE);
            Vec3 push = away(ally.position(), foe).scale(1.3);
            foe.push(push.x, 0.4, push.z);
            foe.hurtMarked = true;
        }
    }

    // ---------------------------------------------------- 0.36 Iris Surya membakar penghalang

    /**
     * Sinar panas mengenai blok (ala DLC Superman: sinar panas membakar penghalang). Kaca, jeruji besi, daun, jaring
     * laba-laba, wol, karpet, tanaman merambat, dan jerami terbakar/meleleh habis; pasir meleleh jadi kaca; es mencair;
     * kayu & blok mudah terbakar lainnya tersulut di sisi yang kena. Nggak jalan di mode Petualangan atau area spawn yang
     * dilindungi. Matikan semua lewat IRIS_BURNS_BLOCKS.
     */
    private static void burn(ServerPlayer player, BlockHitResult hit) {
        ServerLevel level = player.serverLevel();
        BlockPos pos = hit.getBlockPos();
        if (!IRIS_BURNS_BLOCKS || !player.mayBuild() || !level.mayInteract(player, pos)) {
            return;
        }
        BlockState state = level.getBlockState(pos);
        if (state.isAir() || state.getDestroySpeed(level, pos) < 0f) {
            return;   // udara & blok yang nggak bisa dihancurkan (bedrock, barrier)
        }
        if (state.is(BlockTags.ICE)) {   // es padat & es biru juga mencair
            level.setBlockAndUpdate(pos, level.dimensionType().ultraWarm() ? Blocks.AIR.defaultBlockState()
                    : Blocks.WATER.defaultBlockState());
        } else if (state.is(BlockTags.SAND)) {   // pasir meleleh jadi kaca
            level.setBlockAndUpdate(pos, Blocks.GLASS.defaultBlockState());
            level.playSound(null, pos, SoundEvents.FIRE_EXTINGUISH, SoundSource.BLOCKS, 0.6f, 1.4f);
        } else if (state.is(BlockTags.IMPERMEABLE) || state.getBlock() instanceof IronBarsBlock || state.is(BlockTags.LEAVES)
                || state.is(BlockTags.WOOL) || state.is(BlockTags.WOOL_CARPETS) || state.is(Blocks.COBWEB)
                || state.is(Blocks.VINE) || state.is(Blocks.HAY_BLOCK) || state.is(BlockTags.SNOW)) {
            level.destroyBlock(pos, false, player);   // kaca pecah, jeruji meleleh, daun & wol habis terbakar
        } else if (state.isFlammable(level, pos, hit.getDirection())) {   // kayu dll.: tersulut di sisi yang kena
            BlockPos firePos = pos.relative(hit.getDirection());
            if (level.getBlockState(firePos).isAir() && BaseFireBlock.canBePlacedAt(level, firePos, hit.getDirection())) {
                level.setBlockAndUpdate(firePos, BaseFireBlock.getState(level, firePos));
            }
        }
    }

    // ---------------------------------------------------- 0.36 Angkat & Lempar (Shift + X)

    /** Musuh di depan yang bisa diangkat: yang terdekat ke arah pandang. */
    private static LivingEntity liftTarget(ServerPlayer player) {
        LivingEntity target = frontTarget(player, LIFT_REACH);
        return canLift(target) ? target : null;
    }

    private static boolean canLift(LivingEntity entity) {
        return entity != null && entity.isAlive() && entity instanceof Enemy && !(entity instanceof Player)
                && entity.getMaxHealth() <= LIFT_MAX_HEALTH && !isLifted(entity);
    }

    private static boolean isLifted(LivingEntity entity) {
        for (Lift lift : LIFTS.values()) {
            if (lift.target() == entity) {
                return true;
            }
        }
        for (Flung flung : FLUNG) {
            if (flung.target() == entity) {
                return true;
            }
        }
        return false;
    }

    /** Yang sedang diangkat nggak bisa melukai yang mengangkatnya. */
    public static boolean isHeldBy(ServerPlayer player, Entity entity) {
        Lift lift = LIFTS.get(player.getUUID());
        return lift != null && entity != null && lift.target() == entity;
    }

    private static boolean lift(ServerPlayer player, LivingEntity target) {
        ICED.remove(target);   // patung es pun bisa diangkat
        LIFTS.put(player.getUUID(), new Lift(target, player.level().getGameTime()));
        ShazamNetwork.playAnim(player, ShazamAnim.HERCULES_THROW, target.position());   // klip mengangkat & melempar
        sound(player, target.position(), ShazamSounds.PUNCH.get(), 1.0f, ShazamSounds.tune(0.6f));
        sound(player, player.position(), ShazamSounds.CAPE_SNAP.get(), 0.8f, ShazamSounds.tune(0.9f));
        return true;
    }

    /** Musuh diangkat dari depan dada ke atas kepala (ringan saja buat Lintang), lalu (THROW_RELEASE) dilempar. */
    private static final double THROW_JOULE = 400000.0;   // 0.40 energi lemparan Lintang

    private static void liftHold(ServerPlayer player, Lift lift, long now) {
        LivingEntity target = lift.target();
        int k = (int) (now - lift.start());
        if (!target.isAlive() || target.isRemoved() || target.level() != player.level() || k > ShazamAnim.THROW_RELEASE + 2) {
            LIFTS.remove(player.getUUID());
            return;
        }
        if (k < ShazamAnim.THROW_RELEASE) {
            double u = Mth.clamp(k / (double) ShazamAnim.THROW_LIFT, 0.0, 1.0);
            u = u * u * (3.0 - 2.0 * u);
            Vec3 flat = flatLook(player);
            double height = player.getBbHeight();
            Vec3 front = player.position().add(flat.scale(1.3)).add(0, height * 0.45, 0);
            Vec3 over = player.position().add(flat.scale(-0.15)).add(0, height + 0.2, 0);
            Vec3 at = front.lerp(over, u);
            target.moveTo(at.x, at.y, at.z);
            target.setDeltaMovement(Vec3.ZERO);
            target.fallDistance = 0f;
            target.hurtMarked = true;
            return;
        }
        LIFTS.remove(player.getUUID());
        // 0.40 fisika: energi lemparan tetap, jadi kecepatan = sqrt(2E/m): makhluk ringan melesat, yang berat lebih pelan
        double speed = Math.sqrt(2.0 * THROW_JOULE / LintangPhysics.mass(target)) / 20.0;
        Vec3 velocity = player.getViewVector(1f).scale(Math.min(LIFT_THROW_SPEED * 1.2, speed)).add(0, 0.15, 0);
        LintangPhysics.setVelocity(player, target, velocity);
        FLUNG.add(new Flung(player.getUUID(), target, now));
        sound(player, player.position(), ShazamSounds.WHOOSH_HEAVY.get(), 1.6f, ShazamSounds.tune(0.8f));
        sound(player, player.position(), ShazamSounds.SONIC_BOOM.get(), 0.8f, ShazamSounds.tune(1.3f));
    }

    /** Musuh yang dilempar: menghantam begitu menabrak tanah, dinding, atau musuh lain. */
    private static void tickFlung(ServerPlayer player, long now) {
        List<LivingEntity> impacts = new ArrayList<>();
        FLUNG.removeIf(flung -> {
            if (!flung.owner().equals(player.getUUID())) {
                return false;
            }
            LivingEntity mob = flung.target();
            int k = (int) (now - flung.start());
            if (!mob.isAlive() || mob.isRemoved() || k > LIFT_MAX_FLIGHT) {
                return true;
            }
            if (k < 2) {
                return false;
            }
            boolean hit = mob.horizontalCollision || mob.verticalCollision || mob.onGround() || mob.isInWater();
            if (!hit) {
                for (LivingEntity other : enemies(player, mob.position(), 1.6)) {
                    if (other != mob) {
                        hit = true;
                        break;
                    }
                }
            }
            if (hit) {
                impacts.add(mob);
            }
            return hit;
        });
        for (LivingEntity mob : impacts) {
            flungImpact(player, mob);
        }
    }

    private static void flungImpact(ServerPlayer player, LivingEntity mob) {
        Vec3 c = mob.position();
        // 0.40 fisika: damage benturannya dari energi kinetik (LintangPhysics), di sini cuma udara & tanah yang terhempas
        LintangPhysics.blast(player, c.add(0, 0.4, 0), null, -1.0, LIFT_SPLASH_RADIUS + 1.0, LIFT_SPLASH_DAMAGE * 1.6, 60.0, 2.5,
                LIFT_SPLASH_CORE);
        ShazamNetwork.playAnim(player, ShazamAnim.HERCULES_IMPACT, c);   // efeknya fisik di client (LintangFx)
        sound(player, c, ShazamSounds.IMPACT.get(), 1.6f, ShazamSounds.tune(0.7f));
        sound(player, c, ShazamSounds.EARTH_CRACK.get(), 1.0f, ShazamSounds.tune(0.8f));
    }

    // ---------------------------------------------------- 0.36 Patung es (Napas Salju)

    private static void encase(ServerPlayer player, LivingEntity target) {
        ICED.put(target, new Ice(player.getUUID(), player.level().getGameTime() + ShazamAnim.LINTANG_ICE_TICKS, target.getYRot()));
        target.setDeltaMovement(0, Math.min(target.getDeltaMovement().y, 0), 0);
        target.hurtMarked = true;
        ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_ICE, chest(target));
        player.serverLevel().playSound(null, target.getX(), target.getY(), target.getZ(), SoundEvents.GLASS_PLACE,
                SoundSource.PLAYERS, 1.2f, 0.7f);
        player.serverLevel().playSound(null, target.getX(), target.getY(), target.getZ(), SoundEvents.POWDER_SNOW_PLACE,
                SoundSource.PLAYERS, 1.0f, 0.6f);
    }

    /** Patung es milik pemain ini: dikunci di tempat, nggak bisa menyerang; habis waktunya esnya pecah sendiri. */
    private static void iceTick(ServerPlayer player, long now) {
        List<LivingEntity> melted = new ArrayList<>();
        ICED.entrySet().removeIf(entry -> {
            Ice ice = entry.getValue();
            if (!ice.owner().equals(player.getUUID())) {
                return false;
            }
            LivingEntity mob = entry.getKey();
            if (!mob.isAlive() || mob.isRemoved()) {
                return true;
            }
            if (now >= ice.until()) {
                melted.add(mob);
                return true;
            }
            mob.setTicksFrozen(Math.max(mob.getTicksFrozen(), mob.getTicksRequiredToFreeze() + 20));
            mob.setDeltaMovement(0, Math.min(mob.getDeltaMovement().y, 0), 0);   // diam, tapi tetap jatuh kalau melayang
            mob.setYRot(ice.yaw());
            mob.setYHeadRot(ice.yaw());
            mob.yBodyRot = ice.yaw();
            mob.hurtMarked = true;
            if (mob instanceof Mob m) {
                m.getNavigation().stop();
                m.setTarget(null);
            }
            if (mob instanceof Creeper creeper) {
                creeper.setSwellDir(-1);   // creeper beku nggak bisa meledak
            }
            mob.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 10, 6, false, false));
            mob.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 10, 9, false, false));
            return false;
        });
        for (LivingEntity mob : melted) {
            thaw(player, mob, true);
        }
    }

    /** Es lepas: pecah sendiri (habis waktunya) atau mencair kena panas. */
    private static void thaw(ServerPlayer player, LivingEntity mob, boolean crack) {
        mob.setTicksFrozen(0);
        ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_ICE_BREAK, chest(mob));
        player.serverLevel().playSound(null, mob.getX(), mob.getY(), mob.getZ(),
                crack ? SoundEvents.GLASS_BREAK : SoundEvents.FIRE_EXTINGUISH, SoundSource.PLAYERS, crack ? 0.8f : 0.7f,
                crack ? 1.1f : 1.3f);
    }

    /** Pukulan Lintang ke patung es: esnya pecah berkeping-keping (damage dikali ICE_SHATTER_MULTIPLIER di ShazamPowers). */
    public static boolean shatterIce(ServerPlayer player, LivingEntity target) {
        if (ICED.remove(target) == null) {
            return false;
        }
        target.setTicksFrozen(0);
        ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_ICE_BREAK, chest(target));
        player.serverLevel().playSound(null, target.getX(), target.getY(), target.getZ(), SoundEvents.GLASS_BREAK,
                SoundSource.PLAYERS, 1.4f, 0.75f);
        return true;
    }

    // ---------------------------------------------------- 0.37 Napas Topan (Shift + C)

    /**
     * Satu hembusan angin topan: musuh, hewan, barang, dan anak panah di dalam kerucut terdorong jauh (dorongannya
     * menumpuk tiap 2 tick), api di badan & di jalur angin padam, anak panah berbalik arah jadi milik Lintang.
     * Pemain lain, hewan peliharaan Lintang, dan warga desa nggak ikut diterbangkan.
     */
    private static void galeStep(ServerPlayer player, boolean hurt) {
        ServerLevel level = player.serverLevel();
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getViewVector(1f);
        DamageSource source = ShazamPowers.forceSource(player);
        AABB box = new AABB(eye, eye.add(look.scale(GALE_RANGE))).inflate(4.0);
        for (Entity e : level.getEntities(player, box, en -> en.isAlive() && !en.isSpectator())) {
            Vec3 c = e.position().add(0, e.getBbHeight() * 0.5, 0);
            Vec3 to = c.subtract(eye);
            double dist = to.length();
            if (dist > GALE_RANGE || dist < 0.2 || to.scale(1.0 / dist).dot(look) < GALE_CONE_DOT) {
                continue;
            }
            double k = 1.0 - 0.55 * dist / GALE_RANGE;
            if (e instanceof Projectile projectile) {   // anak panah, bola api, trisula: berbalik arah
                projectile.setOwner(player);
                double speed = Math.max(1.2, projectile.getDeltaMovement().length());
                projectile.setDeltaMovement(look.scale(speed));
                projectile.hurtMarked = true;
                continue;
            }
            if (e instanceof LivingEntity living) {
                if (living instanceof Player || living instanceof AbstractVillager || DemonSoldier.isFriendly(living)
                        || (living instanceof TamableAnimal pet && pet.isOwnedBy(player)) || isLifted(living)) {
                    continue;
                }
                living.clearFire();
                if (ICED.containsKey(living)) {
                    continue;   // patung es terlalu berat untuk diterbangkan
                }
                // 0.40 fisika: gaya angin ~1/r^2 dari mulut (makin dekat makin dahsyat), percepatan = gaya/massa: ayam
                // terbang jauh, zombie terdorong, golem besi nyaris diam. Impuls tiap 2 tick menumpuk.
                double near = 1.0 / Math.max(1.0, dist * dist / 9.0);
                Vec3 j = look.add(0, 0.12, 0).scale(GALE_IMPULSE * near * LintangPhysics.area(living));
                LintangPhysics.impulse(player, living, j);
                if (hurt && living instanceof Enemy) {
                    living.invulnerableTime = 0;
                    living.hurt(source, GALE_DAMAGE);
                }
            } else if (e instanceof ItemEntity) {
                Vec3 push = look.scale(0.35 * k);
                e.push(push.x, 0.04, push.z);
                e.hurtMarked = true;
            }
        }
        if (hurt) {
            galeFire(level, eye, look);
        }
    }

    /** Api di jalur angin padam. */
    private static void galeFire(ServerLevel level, Vec3 eye, Vec3 look) {
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        boolean any = false;
        for (double d = 1.5; d <= GALE_RANGE; d += 1.5) {
            Vec3 p = eye.add(look.scale(d));
            int r = d > 7.0 ? 2 : 1;
            for (int x = -r; x <= r; x++) {
                for (int y = -r; y <= r; y++) {
                    for (int z = -r; z <= r; z++) {
                        m.set(p.x + x, p.y + y, p.z + z);
                        if (level.getBlockState(m).is(BlockTags.FIRE)) {
                            level.removeBlock(m, false);
                            any = true;
                        }
                    }
                }
            }
        }
        if (any) {
            level.playSound(null, eye.x, eye.y, eye.z, SoundEvents.FIRE_EXTINGUISH, SoundSource.PLAYERS, 0.8f, 1.2f);
        }
    }

    // ---------------------------------------------------- 0.37 Kombo Langit (Shift + Z)

    /** Mulai Kombo Langit. false = nggak bisa (nggak ada sasaran, masih jeda, energi kurang): jadi Lesatan biasa. */
    private static boolean comboUse(ServerPlayer player) {
        UUID id = player.getUUID();
        long now = player.level().getGameTime();
        if (COMBOS.containsKey(id) || now < COMBO_READY_AT.getOrDefault(id, 0L)) {
            return false;
        }
        float cost = Skill.LESATAN.cost + COMBO_EXTRA_COST;
        ShazamData data = ShazamPowers.data(player);
        if (data.energy() < cost) {
            return false;
        }
        LivingEntity target = frontTarget(player, COMBO_RANGE);
        if (target == null || !(target instanceof Enemy) || target instanceof Player || target.getMaxHealth() > COMBO_MAX_HEALTH
                || isLifted(target)) {
            return false;
        }
        Vec3 to = target.position().subtract(player.position());
        Vec3 dir = new Vec3(to.x, 0, to.z);
        dir = dir.lengthSqr() < 1.0E-4 ? flatLook(player) : dir.normalize();
        Vec3 arrive = target.position().subtract(dir.scale(1.1));
        COMBOS.put(id, new Combo(target, now, -1L));
        COMBO_READY_AT.put(id, now + COMBO_COOLDOWN);
        ShazamPowers.setData(player, data.withEnergy(data.energy() - cost));
        ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_COMBO, arrive);   // client menggerakkan badan ke titik tiba
        sound(player, player.position(), ShazamSounds.SPEED_DASH.get(), 1.6f, 1.1f);
        ShazamNetwork.sync(player);
        return true;
    }

    /** Titik tanah di bawah makhluk ini. */
    private static Vec3 groundBelow(ServerLevel level, LivingEntity entity) {
        Vec3 top = entity.position();
        BlockHitResult hit = level.clip(new ClipContext(top, top.subtract(0, 48, 0), ClipContext.Block.COLLIDER,
                ClipContext.Fluid.ANY, entity));
        return hit.getType() == HitResult.Type.MISS ? top.subtract(0, 4, 0) : hit.getLocation();
    }

    private static void comboStep(ServerPlayer player, Combo combo, long now) {
        UUID id = player.getUUID();
        LivingEntity target = combo.target();
        int k = (int) (now - combo.start());
        if (!target.isAlive() || target.isRemoved() || target.level() != player.level() || k > 90) {
            COMBOS.remove(id);
            return;
        }
        DamageSource source = ShazamPowers.forceSource(player);
        if (k == ShazamAnim.COMBO_UPPERCUT) {   // tiba: uppercut melempar sasaran ke udara
            if (player.distanceToSqr(target) > 6.5 * 6.5) {
                COMBOS.remove(id);   // sasaran keburu lolos
                return;
            }
            shatterIce(player, target);   // patung es pecah kena uppercut (kalau nggak, esnya menahan lemparan)
            target.invulnerableTime = 0;   // tiap pukulan kombo harus masuk penuh (jeda kebal vanila dilewati)
            target.hurt(source, COMBO_UPPERCUT_DAMAGE);
            target.setDeltaMovement(0, 1.6, 0);
            target.hurtMarked = true;
            ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_HIT, chest(target));
            sound(player, target.position(), ShazamSounds.PUNCH.get(), 1.4f, ShazamSounds.tune(0.8f));
            sound(player, target.position(), ShazamSounds.SONIC_BOOM.get(), 0.6f, ShazamSounds.tune(1.4f));
        } else if (k == ShazamAnim.COMBO_RISE) {   // menyusul ke atas sasaran
            Vec3 over = target.position().add(0, target.getBbHeight() + 1.6, 0);
            ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_COMBO_RISE, over);
            sound(player, player.position(), ShazamSounds.WHOOSH_HEAVY.get(), 1.2f, ShazamSounds.tune(1.2f));
        } else if (k > ShazamAnim.COMBO_RISE && k < ShazamAnim.COMBO_SMASH) {   // sasaran tertahan di puncak lemparan
            target.setDeltaMovement(0, 0.04, 0);
            target.fallDistance = 0f;
            target.hurtMarked = true;
        } else if (k == ShazamAnim.COMBO_SMASH) {   // dua kepalan menghantam ke bawah
            target.invulnerableTime = 0;
            target.hurt(source, COMBO_SMASH_DAMAGE);
            target.setDeltaMovement(0, -3.2, 0);
            target.hurtMarked = true;
            Vec3 ground = groundBelow(player.serverLevel(), target);
            Vec3 land = ground.subtract(flatLook(player).scale(1.3)).add(0, 1.0, 0);
            ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_COMBO_SMASH, land);   // ikut menukik ke dekat kawah
            sound(player, target.position(), ShazamSounds.PUNCH.get(), 1.6f, ShazamSounds.tune(0.6f));
            sound(player, target.position(), ShazamSounds.WHOOSH_HEAVY.get(), 1.4f, ShazamSounds.tune(0.9f));
        } else if (k > ShazamAnim.COMBO_SMASH && combo.impact() < 0) {   // menunggu sasaran menghantam tanah
            if (target.onGround() || target.isInWater() || k > ShazamAnim.COMBO_SMASH + 16) {
                comboImpact(player, target);
                COMBOS.put(id, new Combo(target, combo.start(), now));
            } else {
                target.setDeltaMovement(0, Math.min(target.getDeltaMovement().y, -2.0), 0);
                target.hurtMarked = true;
            }
        } else if (combo.impact() >= 0) {   // menyorot kawahnya dengan sinar panas
            int j = (int) (now - combo.impact());
            if (j > 0 && j % 4 == 0 && j <= 16) {
                target.invulnerableTime = 0;
                heatZap(player, target, COMBO_HEAT_DAMAGE);
            }
            if (j >= 16) {
                COMBOS.remove(id);
            }
        }
    }

    /** Sasaran menghantam tanah: kawah besar, musuh di sekitarnya ikut terlempar. */
    private static void comboImpact(ServerPlayer player, LivingEntity target) {
        Vec3 c = target.position();
        DamageSource source = ShazamPowers.forceSource(player);
        target.invulnerableTime = 0;
        target.hurt(source, COMBO_IMPACT_DAMAGE);
        for (LivingEntity other : enemies(player, c, 4.0)) {
            if (other == target) {
                continue;
            }
            other.hurt(source, COMBO_SPLASH_DAMAGE);
            Vec3 push = away(c, other);
            other.push(push.x * 1.3, 0.5, push.z * 1.3);
            other.hurtMarked = true;
        }
        ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_SLAM, c);   // hantaman tanah (kawah, debu, retakan)
        sound(player, c, ShazamSounds.IMPACT.get(), 1.8f, ShazamSounds.tune(0.6f));
        sound(player, c, ShazamSounds.EARTH_CRACK.get(), 1.4f, ShazamSounds.tune(0.8f));
    }

    public static int comboCooldownTicks(ServerPlayer player) {
        return left(COMBO_READY_AT, player);
    }

    // ---------------------------------------------------- 0.37 Ledakan Surya (Shift + R)

    private static void novaUse(ServerPlayer player) {
        UUID id = player.getUUID();
        long now = player.level().getGameTime();
        long ready = NOVA_READY_AT.getOrDefault(id, 0L);
        if (now < ready || NOVA_POWER.containsKey(id)) {
            player.displayClientMessage(Component.translatable("message.shazammod.nova_cooldown", Math.max(1L, (ready - now + 19) / 20))
                    .withStyle(ChatFormatting.GRAY), true);
            return;
        }
        ShazamData data = ShazamPowers.data(player);
        if (data.energy() < NOVA_MIN_ENERGY) {
            player.displayClientMessage(Component.translatable("message.shazammod.nova_energy", Math.round(NOVA_MIN_ENERGY))
                    .withStyle(ChatFormatting.RED), true);
            return;
        }
        NOVA_POWER.put(id, data.energy() - NOVA_KEEP_ENERGY);   // semua tenaga surya dibakar
        ShazamPowers.setData(player, data.withEnergy(NOVA_KEEP_ENERGY));
        NOVA_READY_AT.put(id, now + NOVA_COOLDOWN);
        int windup = ShazamAnim.SOLAR_NOVA_WINDUP;
        // tubuh sekeras baja & tertahan di tempat selama mengumpulkan panas
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, windup + 10, 3, false, false));
        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, windup, 3, false, false));
        ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_NOVA);
        sound(player, player.position(), ShazamSounds.SOLAR_NOVA.get(), 4.0f, 1f);
        later(player, windup, LintangSkills::nova);
        ShazamNetwork.sync(player);
    }

    private static void nova(ServerPlayer player) {
        UUID id = player.getUUID();
        Float spent = NOVA_POWER.remove(id);
        float energy = spent == null ? NOVA_MIN_ENERGY : spent;
        float damage = NOVA_MIN_DAMAGE + energy * NOVA_DAMAGE_PER_ENERGY;
        ServerLevel level = player.serverLevel();
        Vec3 c = player.position().add(0, 1.0, 0);
        for (LivingEntity target : enemies(player, c, NOVA_RADIUS * 1.6)) {   // patung es mencair kena panasnya
            if (ICED.remove(target) != null) {
                thaw(player, target, false);
            }
        }
        // 0.40 fisika: kilat panas (garis pandang) lalu gelombang kejut yang merambat, jangkauan ~ energi^(1/3)
        solarBlast(player, c, energy * 1.5f, NOVA_RADIUS, damage, 8f);
        RAGE_UNTIL.put(id, level.getGameTime() + ShazamAnim.RAGE_TICKS);   // sesudahnya Mode Surya, seperti Gelegar Surya
        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null && !speed.hasModifier(RAGE_SPEED)) {
            speed.addTransientModifier(new AttributeModifier(RAGE_SPEED, RAGE_SPEED_BONUS,
                    AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        }
        ShazamNetwork.broadcastState(player);
        ShazamNetwork.sync(player);
    }

    public static int novaCooldownTicks(ServerPlayer player) {
        return left(NOVA_READY_AT, player);
    }
}
