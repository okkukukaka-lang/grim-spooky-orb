package com.shazammod.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamMod;

import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.PlayerSkin;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.HumanoidArm;

/**
 * 0.38 Kostum Lintang (desain orisinal, bukan kostum Superman): kain biru minyak tua bertekstur halus dengan panel samping
 * grafit berbentuk V, list perak, sabuk perak bergesper cakram matahari, sarung tangan & sepatu bot grafit. Digambar di
 * atas badan, lengan, dan kaki (bentuk lapisan luar kulit, 0,25 piksel lebih besar), kepala tetap kulit asli pemain.
 * Lapisan luar kulit pemain (jaket, lengan baju, celana) disembunyikan selama kostum dipakai supaya nggak bertumpuk.
 * Tekstur 256x256 dengan tata letak UV kulit 64x64 (lihat tools/textures/lintang_suit.py).
 */
public class LintangSuitLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    public static final ResourceLocation SUIT = ShazamMod.id("textures/entity/lintang/suit.png");

    public LintangSuitLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    /** Kostum sedang dipakai: berubah jadi Lintang (kostum terpasang di akhir putaran ganti baju), dan terlihat. */
    public static boolean worn(AbstractClientPlayer player) {
        return !player.isInvisible() && ShazamClientState.isTransformed(player.getId())
                && ShazamClientState.isLintang(player.getId());
    }

    /** Dipanggil dari RenderPlayerEvent.Pre: lapisan luar kulit disembunyikan (kostum menggantikannya). */
    public static void hideOuter(PlayerModel<AbstractClientPlayer> m) {
        m.jacket.visible = false;
        m.rightSleeve.visible = false;
        m.leftSleeve.visible = false;
        m.rightPants.visible = false;
        m.leftPants.visible = false;
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buffers, int light, AbstractClientPlayer player, float limbSwing,
                       float limbAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        try {
            if (!worn(player)) {
                return;
            }
            PlayerModel<AbstractClientPlayer> m = getParentModel();
            VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(SUIT));
            int overlay = LivingEntityRenderer.getOverlayCoords(player, 0f);   // ikut memerah saat terluka
            draw(m.jacket, m.body, ps, vc, light, overlay);
            draw(m.rightSleeve, m.rightArm, ps, vc, light, overlay);
            draw(m.leftSleeve, m.leftArm, ps, vc, light, overlay);
            draw(m.rightPants, m.rightLeg, ps, vc, light, overlay);
            draw(m.leftPants, m.leftLeg, ps, vc, light, overlay);
            // 0.39 kostum 3D: sabuk & gesper, kerah, manset sarung tangan, sepatu bot (manset, sol, ujung), pelindung
            // lutut, dan otot perut yang benar-benar timbul dari badan
            VertexConsumer solid = buffers.getBuffer(RenderType.entityCutoutNoCull(WHITE));
            boolean slim = player.getSkin().model() == PlayerSkin.Model.SLIM;
            detail(m.body, ps, solid, light, overlay, BODY);
            detail(m.rightArm, ps, solid, light, overlay, slim ? RIGHT_ARM_SLIM : RIGHT_ARM);
            detail(m.leftArm, ps, solid, light, overlay, slim ? LEFT_ARM_SLIM : LEFT_ARM);
            detail(m.rightLeg, ps, solid, light, overlay, LEG);
            detail(m.leftLeg, ps, solid, light, overlay, LEG);
        } catch (Throwable ignored) {
            // lapisan kostum nggak boleh bikin game crash
        }
    }

    // ------------------------------------------------------------------ 0.39 bagian 3D kostum

    private static final ResourceLocation WHITE = ShazamMod.id("textures/entity/shazam_white.png");
    private static final int SILVER = 0xBAC2CC, SILVER_DARK = 0x8C96A2, GRAPHITE = 0x2C2F36, GRAPHITE_HI = 0x40454E;
    private static final int GOLD = 0xE2B046, GOLD_HI = 0xFFD678, SOLE = 0x18191C, SUIT_DARK = 0x1E4C62;

    /**
     * Kotak-kotak timbul per bagian badan, dalam piksel model (y ke bawah dari poros, depan = -z):
     * {x0, y0, z0, x1, y1, z1, warna}. Semua di luar lapisan luar kulit (0,25 piksel), jadi benar-benar menonjol.
     */
    private static final float[][] BODY = {
            {-4.55f, 9.35f, -2.55f, 4.55f, 11.05f, 2.55f, SILVER},          // sabuk melingkar pinggang
            {-4.6f, 9.35f, -2.6f, 4.6f, 9.55f, 2.6f, SILVER_DARK},          // tepi atas sabuk
            {-4.6f, 10.85f, -2.6f, 4.6f, 11.05f, 2.6f, SILVER_DARK},        // tepi bawah sabuk
            {-1.2f, 9.0f, -3.1f, 1.2f, 11.4f, -2.55f, GOLD},                 // gesper
            {-0.62f, 9.58f, -3.38f, 0.62f, 10.82f, -3.1f, GOLD_HI},          // cakram matahari di gesper
            {-4.45f, 0.0f, -2.45f, 4.45f, 0.85f, 2.45f, GRAPHITE},          // kerah tinggi
            {-4.5f, 0.85f, -2.5f, 4.5f, 1.05f, 2.5f, SILVER},               // list perak di bawah kerah
            {-1.65f, 7.45f, -2.47f, -0.18f, 8.3f, -2.25f, SUIT_DARK},        // otot perut
            {0.18f, 7.45f, -2.47f, 1.65f, 8.3f, -2.25f, SUIT_DARK},
            {-1.65f, 8.42f, -2.47f, -0.18f, 9.27f, -2.25f, SUIT_DARK},
            {0.18f, 8.42f, -2.47f, 1.65f, 9.27f, -2.25f, SUIT_DARK},
    };
    private static final float[][] RIGHT_ARM = arm(-3f, 1f);
    private static final float[][] LEFT_ARM = arm(-1f, 3f);
    private static final float[][] RIGHT_ARM_SLIM = arm(-2f, 1f);
    private static final float[][] LEFT_ARM_SLIM = arm(-1f, 2f);
    private static final float[][] LEG = {
            {-2.55f, 6.7f, -2.55f, 2.55f, 7.6f, 2.55f, GRAPHITE},           // manset sepatu bot
            {-2.6f, 6.7f, -2.6f, 2.6f, 6.92f, 2.6f, SILVER},                // list perak di atasnya
            {-2.42f, 11.35f, -2.75f, 2.42f, 12.02f, 2.42f, SOLE},            // sol tebal, sedikit maju ke depan
            {-2.32f, 9.6f, -2.6f, 2.32f, 11.35f, -2.28f, GRAPHITE_HI},       // ujung sepatu
            {-1.55f, 3.75f, -2.5f, 1.55f, 5.35f, -2.25f, SUIT_DARK},         // pelindung lutut
    };

    /** Manset sarung tangan yang melebar (lengan dari y -2 sampai 10, x0..x1 lebar lengan). */
    private static float[][] arm(float x0, float x1) {
        return new float[][] {
                {x0 - 0.6f, 5.7f, -2.6f, x1 + 0.6f, 6.75f, 2.6f, GRAPHITE},
                {x0 - 0.65f, 5.7f, -2.65f, x1 + 0.65f, 5.92f, 2.65f, SILVER},
                {x0 - 0.32f, 9.55f, -2.32f, x1 + 0.32f, 10.05f, 2.32f, GRAPHITE_HI},   // buku jari kepalan
        };
    }

    private static void detail(ModelPart part, PoseStack ps, VertexConsumer vc, int light, int overlay, float[][] boxes) {
        if (!part.visible) {
            return;
        }
        ps.pushPose();
        part.translateAndRotate(ps);
        PoseStack.Pose pose = ps.last();
        for (float[] b : boxes) {
            box(vc, pose, b[0] / 16f, b[1] / 16f, b[2] / 16f, b[3] / 16f, b[4] / 16f, b[5] / 16f, (int) b[6], light, overlay);
        }
        ps.popPose();
    }

    /** Kotak penuh 6 sisi (ruang ModelPart: y ke bawah). Sisi bawah sedikit lebih gelap. */
    private static void box(VertexConsumer vc, PoseStack.Pose pose, float x0, float y0, float z0, float x1, float y1, float z1,
                            int rgb, int light, int overlay) {
        int r = (rgb >> 16) & 0xFF, g = (rgb >> 8) & 0xFF, b = rgb & 0xFF;
        int rd = r * 3 / 4, gd = g * 3 / 4, bd = b * 3 / 4;
        quad(vc, pose, r, g, b, light, overlay, 0f, 0f, -1f, x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0);   // depan
        quad(vc, pose, r, g, b, light, overlay, 0f, 0f, 1f, x1, y0, z1, x0, y0, z1, x0, y1, z1, x1, y1, z1);    // belakang
        quad(vc, pose, r, g, b, light, overlay, -1f, 0f, 0f, x0, y0, z1, x0, y0, z0, x0, y1, z0, x0, y1, z1);   // kiri
        quad(vc, pose, r, g, b, light, overlay, 1f, 0f, 0f, x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0);    // kanan
        quad(vc, pose, r, g, b, light, overlay, 0f, -1f, 0f, x0, y0, z1, x1, y0, z1, x1, y0, z0, x0, y0, z0);   // atas (y kecil)
        quad(vc, pose, rd, gd, bd, light, overlay, 0f, 1f, 0f, x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1); // bawah
    }

    private static void quad(VertexConsumer vc, PoseStack.Pose pose, int r, int g, int b, int light, int overlay,
                             float nx, float ny, float nz, float x1, float y1, float z1, float x2, float y2, float z2,
                             float x3, float y3, float z3, float x4, float y4, float z4) {
        vertex(vc, pose, x1, y1, z1, r, g, b, light, overlay, nx, ny, nz);
        vertex(vc, pose, x2, y2, z2, r, g, b, light, overlay, nx, ny, nz);
        vertex(vc, pose, x3, y3, z3, r, g, b, light, overlay, nx, ny, nz);
        vertex(vc, pose, x4, y4, z4, r, g, b, light, overlay, nx, ny, nz);
    }

    private static void vertex(VertexConsumer vc, PoseStack.Pose pose, float x, float y, float z, int r, int g, int b, int light,
                               int overlay, float nx, float ny, float nz) {
        vc.addVertex(pose, x, y, z).setColor(r, g, b, 255).setUv(0.5f, 0.5f).setOverlay(overlay).setLight(light)
                .setNormal(pose, nx, ny, nz);
    }

    /** Gambar kostum di bentuk lapisan luar (posenya sudah disalin dari bagian dasarnya oleh PlayerModel). */
    private static void draw(ModelPart outer, ModelPart base, PoseStack ps, VertexConsumer vc, int light, int overlay) {
        if (!base.visible) {
            return;
        }
        boolean was = outer.visible;
        outer.visible = true;
        outer.render(ps, vc, light, overlay);
        outer.visible = was;
    }

    /**
     * Tangan orang pertama (RenderArmEvent): lengan kulit asli + lengan kostum & sarung tangan, tanpa lengan baju kulit.
     * Sama seperti PlayerRenderer.renderHand bawaan, cuma lapisan luarnya diganti tekstur kostum.
     */
    public static void renderFirstPersonArm(PlayerRenderer renderer, PoseStack ps, MultiBufferSource buffers, int light,
                                            AbstractClientPlayer player, HumanoidArm arm) {
        PlayerModel<AbstractClientPlayer> m = renderer.getModel();
        m.attackTime = 0f;
        m.crouching = false;
        m.swimAmount = 0f;
        m.setupAnim(player, 0f, 0f, 0f, 0f, 0f);
        boolean right = arm == HumanoidArm.RIGHT;
        ModelPart base = right ? m.rightArm : m.leftArm;
        ModelPart outer = right ? m.rightSleeve : m.leftSleeve;
        boolean baseWas = base.visible, outerWas = outer.visible;
        base.visible = true;
        outer.visible = true;
        base.xRot = 0f;
        base.render(ps, buffers.getBuffer(RenderType.entitySolid(player.getSkin().texture())), light, OverlayTexture.NO_OVERLAY);
        outer.xRot = 0f;
        outer.render(ps, buffers.getBuffer(RenderType.entityCutoutNoCull(SUIT)), light, OverlayTexture.NO_OVERLAY);
        boolean slim = player.getSkin().model() == PlayerSkin.Model.SLIM;   // 0.39 manset 3D juga di tangan orang pertama
        detail(base, ps, buffers.getBuffer(RenderType.entityCutoutNoCull(WHITE)), light, OverlayTexture.NO_OVERLAY,
                right ? (slim ? RIGHT_ARM_SLIM : RIGHT_ARM) : (slim ? LEFT_ARM_SLIM : LEFT_ARM));
        base.visible = baseWas;
        outer.visible = outerWas;
    }
}
