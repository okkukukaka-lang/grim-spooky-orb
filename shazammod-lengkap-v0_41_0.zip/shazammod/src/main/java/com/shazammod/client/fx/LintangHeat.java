package com.shazammod.client.fx;

import java.util.List;

import org.joml.Matrix4f;
import org.joml.Vector3f;

import com.shazammod.LintangPhysics;
import com.shazammod.LintangSkills;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * 0.39 Sinar panas mata Lintang, ditulis ulang dari nol (gaya film, tanpa sihir).
 *
 * Perbaikan bug sinar lama:
 * - sinar keluar dari mata yang BENAR-BENAR digambar (ikut pose terbang, menunduk, skill), bukan dari titik mata tegak
 *   yang melayang di atas badan saat terbang mendatar;
 * - ujung sinar dihitung tiap frame (bukan tiap tick), jadi nggak tersendat/melompat saat disapukan;
 * - sinar cuma berhenti di musuh (sama dengan yang dilukai server), bukan di penduduk desa atau hewan peliharaan.
 *
 * Tampilan: mata menyala merah dulu, lalu dua berkas merah tebal yang hidup (lebarnya bergetar halus seperti energi
 * panas yang tak stabil) dengan inti putih panas dan pendar merah lebar, riak udara panas di sekelilingnya, bara kecil
 * yang terlepas di sepanjang berkas, dan di titik kena: titik leleh putih-jingga, cipratan lelehan yang jatuh &
 * memantul, api kecil, asap yang membubung, dan bekas hangus yang menyambung.
 */
final class LintangHeat {
    static final int RED = 0xFF2412;
    static final int ORANGE = 0xFF7424;
    static final int HOT = 0xFFD29A;
    static final int CORE = 0xFFF6EC;
    private static final Vec3 UP = new Vec3(0, 1, 0);

    private LintangHeat() {}

    private static boolean firstPerson(AbstractClientPlayer p) {
        Minecraft mc = Minecraft.getInstance();
        return p == mc.player && mc.options.getCameraType().isFirstPerson();
    }

    /**
     * Posisi kedua mata (kanan, kiri) di dunia, dari kepala yang terakhir digambar: badan (termasuk miring saat terbang)
     * x pose kepala. Orang pertama: sedikit di bawah & di depan kamera.
     */
    static Vec3[] eyes(AbstractClientPlayer p, float pt) {
        Vec3 look = p.getViewVector(pt);
        if (firstPerson(p)) {   // 0.40 POV: tepat dari kedua mata (sedikit di depan kamera), menyatu di titik bidik
            Vec3 eye = p.getEyePosition(pt);
            Vec3 side = look.cross(UP);
            side = side.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : side.normalize();
            Vec3 up = side.cross(look);
            Vec3 base = eye.add(look.scale(0.3)).add(up.scale(-0.06));
            return new Vec3[] {base.add(side.scale(0.07)), base.subtract(side.scale(0.07))};
        }
        float[] h = ShazamPoses.headPose(p);
        double sc = p.getScale();
        if (h == null) {   // belum pernah digambar: perkiraan dari titik mata biasa
            float yaw = p.getViewYRot(pt) * Mth.DEG_TO_RAD;
            Vec3 right = new Vec3(-Math.cos(yaw), 0, -Math.sin(yaw)).scale(0.11 * sc);
            Vec3 e = p.getEyePosition(pt).add(look.scale(0.24 * sc));
            return new Vec3[] {e.add(right), e.subtract(right)};
        }
        float bodyYaw = Mth.rotLerp(pt, p.yBodyRotO, p.yBodyRot);
        Matrix4f head = ShazamPoses.bodyMatrix(p, pt, bodyYaw).translate(h[0], h[1], h[2]).rotateY(h[4]).rotateX(h[3]);
        double crouch = p.isCrouching() ? -0.125 * sc : 0.0;
        double px = Mth.lerp(pt, p.xo, p.getX()), py = Mth.lerp(pt, p.yo, p.getY()) + crouch, pz = Mth.lerp(pt, p.zo, p.getZ());
        // mata: 1,9 piksel dari tengah, 3,6 piksel di atas leher, tepat di depan wajah (skala model 0,9375)
        Vector3f r = head.transformPosition(new Vector3f(0.111f, 0.211f, -0.262f));
        Vector3f l = head.transformPosition(new Vector3f(-0.111f, 0.211f, -0.262f));
        return new Vec3[] {new Vec3(px + r.x, py + r.y, pz + r.z), new Vec3(px + l.x, py + l.y, pz + l.z)};
    }

    /** Ujung sinar: blok pertama di garis pandang (dihitung saat ini juga), atau musuh terdekat (tick terakhir). */
    static Vec3 aimEnd(AbstractClientPlayer p, float pt, double entityDist, boolean[] blockHit, Direction[] face) {
        Vec3 eye = p.getEyePosition(pt);
        Vec3 look = p.getViewVector(pt);
        double range = LintangSkills.IRIS_RANGE;
        // 0.40 fisika (sama dengan server): sinar menembus kaca bening & berhenti di air yang menyerap panasnya
        Vec3 start = eye;
        BlockHitResult hit = null;
        for (int layer = 0; layer < 5; layer++) {
            hit = p.level().clip(new ClipContext(start, eye.add(look.scale(range)), ClipContext.Block.COLLIDER,
                    ClipContext.Fluid.SOURCE_ONLY, p));
            if (hit.getType() == HitResult.Type.MISS || !LintangPhysics.isGlass(p.level().getBlockState(hit.getBlockPos()))) {
                break;
            }
            BlockPos glass = hit.getBlockPos();
            Vec3 q = hit.getLocation();
            for (int i = 0; i < 8 && BlockPos.containing(q).equals(glass); i++) {
                q = q.add(look.scale(0.2));
            }
            start = q;
        }
        boolean block = hit.getType() != HitResult.Type.MISS;
        double reach = block ? hit.getLocation().distanceTo(eye) : range;
        if (entityDist < reach) {
            reach = entityDist;
            block = false;
        }
        if (blockHit != null) {
            blockHit[0] = block;
        }
        if (face != null) {
            face[0] = block ? hit.getDirection() : null;
        }
        return eye.add(look.scale(reach));
    }

    /** Jarak musuh terdekat di garis pandang (sama dengan sasaran server: makhluk Enemy yang hidup), atau tak hingga. */
    static double enemyDistance(AbstractClientPlayer p) {
        Vec3 eye = p.getEyePosition(1f);
        Vec3 look = p.getViewVector(1f);
        double range = LintangSkills.IRIS_RANGE;
        double best = Double.MAX_VALUE;
        List<LivingEntity> near = p.level().getEntitiesOfClass(LivingEntity.class,
                new AABB(eye, eye.add(look.scale(range))).inflate(1.0), e -> e != p && e.isAlive() && e instanceof Enemy);
        for (LivingEntity e : near) {
            AABB box = e.getBoundingBox().inflate(0.3);
            var clip = box.clip(eye, eye.add(look.scale(range)));
            if (clip.isPresent()) {
                best = Math.min(best, clip.get().distanceTo(eye));
            }
        }
        return best;
    }

    // ------------------------------------------------------------------ gambar berkas

    /**
     * Satu berkas panas dari mata ke ujung: pendar merah lebar, badan merah-jingga yang lebarnya bergetar halus, dan
     * inti putih panas. a = kekuatan, w = lebar dasar, t = waktu (buat getaran).
     */
    static void beam(Draw d, Vec3 from, Vec3 to, float w, float a, float t, int seed) {
        Vec3 path = to.subtract(from);
        double len = path.length();
        if (len < 0.05 || a <= 0.01f) {
            return;
        }
        int n = Mth.clamp((int) (len * 1.6) + 2, 3, 40);
        float[] pts = new float[n * 3];
        float[] wid = new float[n];
        float[] alp = new float[n];
        for (int i = 0; i < n; i++) {
            double u = i / (double) (n - 1);
            Vec3 q = from.add(path.scale(u));
            pts[i * 3] = (float) q.x;
            pts[i * 3 + 1] = (float) q.y;
            pts[i * 3 + 2] = (float) q.z;
            // getaran lebar yang merambat dari mata ke ujung (energi panas yang tak stabil), pangkal sedikit lebih ramping
            float wob = 0.88f + 0.12f * Mth.sin((float) (u * 19.0) - t * 2.4f + seed * 1.7f)
                    + 0.06f * Mth.sin((float) (u * 47.0) + t * 3.9f + seed);
            float base = (float) Math.min(1.0, 0.55 + u * len * 0.9);
            wid[i] = w * wob * base;
            alp[i] = a * (0.9f + 0.1f * wob);
        }
        // pendar merah lebar (udara di sekitar berkas ikut menyala)
        d.strip(pts, n, wid, 3.2f, alp, 0.16f, RED);
        d.strip(pts, n, wid, 1.9f, alp, 0.26f, ORANGE);
        // badan & inti
        d.polyline(pts, n, wid, alp, RED, HOT);
        float[] core = new float[n];
        for (int i = 0; i < n; i++) {
            core[i] = wid[i] * 0.42f;
        }
        d.strip(pts, n, core, 1f, alp, 1f, CORE);
    }

    /** Mata yang menyala: pendar merah, titik putih panas, dan kilau lensa horizontal tipis (ala film). */
    static void eyeGlow(Draw d, Vec3 e, AbstractClientPlayer p, float pt, float a, boolean fp) {
        if (a <= 0.01f || fp) {
            return;
        }
        float sc = (float) p.getScale();
        d.glow(e.x, e.y, e.z, 0.32f * sc, RED, a * 0.7f);
        d.flare(e.x, e.y, e.z, 0.18f * sc, ORANGE, a);
        d.glow(e.x, e.y, e.z, 0.06f * sc, CORE, a);
        float yaw = p.getViewYRot(pt) * Mth.DEG_TO_RAD;
        double len = 0.55 * sc, rx = -Math.cos(yaw) * len, rz = -Math.sin(yaw) * len;
        d.line(e.x, e.y, e.z, e.x + rx, e.y, e.z + rz, 0.022f * sc, 0f, ORANGE, a * 0.55f, 0f);
        d.line(e.x, e.y, e.z, e.x - rx, e.y, e.z - rz, 0.022f * sc, 0f, ORANGE, a * 0.55f, 0f);
    }

    /** Titik leleh di ujung sinar. */
    static void hotspot(Draw d, Vec3 end, float w, float a, float t) {
        float flick = 0.82f + 0.18f * Mth.sin(t * 3.1f) + 0.08f * Mth.sin(t * 7.7f);
        float old = d.body(0.4f);
        d.glow(end.x, end.y, end.z, 1.9f, RED, a * 0.42f);
        d.body(old);
        d.glow(end.x, end.y, end.z, w * 11f * flick, ORANGE, a * 0.55f);
        d.flare(end.x, end.y, end.z, 0.55f * flick, HOT, a);
        d.glow(end.x, end.y, end.z, w * 3.6f, CORE, a * 0.95f);
    }

    // ------------------------------------------------------------------ 0.40 suhu blok (cermin server)

    /** Suhu blok yang disorot (°C) & arah sisinya: {suhu, tick, nx, ny, nz}. Dingin pelan (hukum pendinginan Newton). */
    private static final java.util.Map<BlockPos, float[]> GLOW = new java.util.HashMap<>();
    private static boolean glowLayer;

    /** Panas dari sinar ke blok ini, sama dengan server (170 °C tiap 4 tick). Mengembalikan suhu sekarang. */
    static float heat(ClientLevel level, BlockPos pos, Direction face, float q) {
        long now = level.getGameTime();
        float[] h = GLOW.computeIfAbsent(pos.immutable(), k -> new float[] {20f, now, 0, 1, 0});
        cool(h, now);
        h[0] = Math.min(1700f, h[0] + q);
        if (face != null) {
            h[2] = face.getStepX();
            h[3] = face.getStepY();
            h[4] = face.getStepZ();
        }
        if (!glowLayer) {
            glowLayer = true;
            Vfx.add(new GlowLayer());
        }
        return h[0];
    }

    private static void cool(float[] h, long now) {
        float dt = Math.max(0f, now - h[1]);
        h[0] = 20f + (h[0] - 20f) * (float) Math.exp(-0.025f * dt);
        h[1] = now;
    }

    /** Warna benda pijar menurut suhunya: merah redup ~500 °C, jingga ~900, kuning ~1200, putih kekuningan ~1500. */
    static int blackbody(float t) {
        float[][] stops = {{450f, 0x5A0E02}, {650f, 0xB0220A}, {900f, 0xFF5A14}, {1100f, 0xFF9A38}, {1300f, 0xFFCF70},
                {1550f, 0xFFF2DA}};
        if (t <= stops[0][0]) {
            return (int) stops[0][1];
        }
        for (int i = 1; i < stops.length; i++) {
            if (t <= stops[i][0]) {
                float k = (t - stops[i - 1][0]) / (stops[i][0] - stops[i - 1][0]);
                return Draw.mix((int) stops[i - 1][1], (int) stops[i][1], k);
            }
        }
        return (int) stops[stops.length - 1][1];
    }

    /** Pendar sisi blok yang masih panas, memudar dari putih ke merah lalu padam saat mendingin. */
    static final class GlowLayer extends Effect {
        GlowLayer() {
            super(20 * 60 * 10);
        }

        @Override
        public boolean tick(ClientLevel level) {
            long now = level.getGameTime();
            GLOW.values().forEach(h -> cool(h, now));
            GLOW.values().removeIf(h -> h[0] < 380f);
            if (GLOW.isEmpty()) {
                glowLayer = false;
                return false;
            }
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            for (java.util.Map.Entry<BlockPos, float[]> en : GLOW.entrySet()) {
                float[] h = en.getValue();
                float a = Mth.clamp((h[0] - 380f) / 900f, 0f, 1f);
                if (a <= 0.02f) {
                    continue;
                }
                BlockPos p = en.getKey();
                double x = p.getX() + 0.5 + h[2] * 0.505, y = p.getY() + 0.5 + h[3] * 0.505, z = p.getZ() + 0.5 + h[4] * 0.505;
                int col = blackbody(h[0]);
                d.glow(x, y, z, 0.55f + 0.25f * a, col, a * 0.85f);
                d.glow(x, y, z, 1.1f, col, a * 0.3f);
            }
        }
    }

    // ------------------------------------------------------------------ Iris Surya

    /** Iris Surya (X): mata memanas IRIS_WINDUP tick, lalu sinar selama IRIS_TICKS tick mengikuti arah pandang. */
    static final class Beam extends Effect {
        private final AbstractClientPlayer owner;
        private double enemyDist = Double.MAX_VALUE;
        private Vec3 lastEnd;
        private int scorchCooldown;
        private float spotTemp = 20f;   // 0.40 suhu blok yang sedang disorot

        Beam(AbstractClientPlayer owner) {
            super(ShazamAnim.IRIS_WINDUP + ShazamAnim.IRIS_TICKS + 4);
            this.owner = owner;
        }

        private boolean firing(float t) {
            return t >= ShazamAnim.IRIS_WINDUP && t < ShazamAnim.IRIS_WINDUP + ShazamAnim.IRIS_TICKS;
        }

        private float strength(float t) {
            float left = ShazamAnim.IRIS_WINDUP + ShazamAnim.IRIS_TICKS - t;
            float in = Mth.clamp((t - ShazamAnim.IRIS_WINDUP) / 1.5f, 0f, 1f);
            return Mth.clamp(left / 3f, 0f, 1f) * in;
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (!owner.isAlive() || owner.isRemoved() || !ShazamClientState.isTransformed(owner.getId())) {
                return false;
            }
            if (firing(age)) {
                enemyDist = enemyDistance(owner);
                boolean[] block = new boolean[1];
                Direction[] face = new Direction[1];
                Vec3 end = aimEnd(owner, 1f, enemyDist, block, face);
                lastEnd = end;
                if (block[0] && face[0] != null) {   // 0.40: suhu titik kena naik terus selama disorot
                    Vec3 in = end.subtract(face[0].getStepX() * 0.05, face[0].getStepY() * 0.05, face[0].getStepZ() * 0.05);
                    spotTemp = heat(level, BlockPos.containing(in), face[0], 170f / 4f);
                } else {
                    spotTemp = 20f;
                }
                impact(level, end, block[0], face[0]);
                trailEmbers(level, end);
            }
            return super.tick(level);
        }

        /** Cipratan lelehan, api kecil, asap, dan bekas hangus di titik kena. */
        private void impact(ClientLevel level, Vec3 end, boolean block, Direction face) {
            RandomSource r = level.random;
            Vec3 n = face != null ? new Vec3(face.getStepX(), face.getStepY(), face.getStepZ()) : UP;
            for (int i = 0, k = Vfx.count(6); i < k; i++) {   // cipratan lelehan: terlempar dari permukaan, jatuh & memantul
                Vec3 v = ShazamFx.randomDir(r).add(n.scale(1.2)).normalize().scale(0.1 + r.nextDouble() * 0.18);
                Vfx.spark(end.x, end.y, end.z, v.x, v.y + 0.06, v.z, i % 3 == 0 ? CORE : (i % 3 == 1 ? HOT : ORANGE),
                        0.045f + r.nextFloat() * 0.03f, 9 + r.nextInt(8), end.y - 2.5);
            }
            if (age % 2 == 0) {   // api kecil dari benda yang terbakar
                Vfx.flame(end.x, end.y, end.z, (r.nextDouble() - 0.5) * 0.04, 0.05, (r.nextDouble() - 0.5) * 0.04, ORANGE,
                        0.16f + r.nextFloat() * 0.08f, 10);
            }
            if (age % 3 == 0) {   // asap gelap yang membubung
                Vfx.smoke(end.x, end.y + 0.1, end.z, (r.nextDouble() - 0.5) * 0.02, 0.05, (r.nextDouble() - 0.5) * 0.02, 0x2A2420,
                        0.35f + r.nextFloat() * 0.2f, 30);
            }
            if (block && face == Direction.UP && --scorchCooldown <= 0) {   // jejak hangus menyambung di tanah
                scorchCooldown = 2;
                Ground.Map map = ShazamFx.ground(level, end, 1.0);
                if (map != null && map.found && Math.abs(map.centerY - end.y) < 0.8) {
                    Vfx.add(new Fx.Scorch(map.center(end), 0.4, 140, 50, map));
                }
            }
        }

        /** Bara kecil yang sesekali terlepas dari berkas dan melayang naik. */
        private void trailEmbers(ClientLevel level, Vec3 end) {
            if (age % 2 != 0 || firstPerson(owner)) {
                return;
            }
            RandomSource r = level.random;
            Vec3[] e = eyes(owner, 1f);
            Vec3 a = e[r.nextInt(2)];
            Vec3 q = a.lerp(end, 0.15 + r.nextDouble() * 0.8);
            Vfx.ember(q.x, q.y, q.z, (r.nextDouble() - 0.5) * 0.02, 0.02 + r.nextDouble() * 0.02, (r.nextDouble() - 0.5) * 0.02,
                    0.05f, 10 + r.nextInt(6));
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float t = age + pt;
            boolean fp = firstPerson(owner);
            Vec3[] e = eyes(owner, pt);
            float w = ShazamAnim.IRIS_WINDUP;
            if (t < w) {   // mata memanas: merah membara makin terang
                float charge = Mth.clamp(t / w, 0f, 1f);
                eyeGlow(d, e[0], owner, pt, charge * charge, fp);
                eyeGlow(d, e[1], owner, pt, charge * charge, fp);
                return;
            }
            float a = strength(t);
            if (a <= 0.01f) {
                return;
            }
            Vec3 end = firing(t) ? aimEnd(owner, pt, enemyDist, null, null) : lastEnd;
            if (end == null) {
                return;
            }
            float bw = (fp ? 0.075f : 0.115f) * (float) owner.getScale();
            beam(d, e[0], end, bw, a, t, 1);
            beam(d, e[1], end, bw, a, t, 7);
            eyeGlow(d, e[0], owner, pt, a, fp);
            eyeGlow(d, e[1], owner, pt, a, fp);
            hotspot(d, end, bw, a, t);
            if (spotTemp > 450f) {   // 0.40: titik kena berpijar sesuai suhunya (merah -> jingga -> kuning -> putih)
                d.glow(end.x, end.y, end.z, 0.9f, blackbody(spotTemp), a * Mth.clamp((spotTemp - 450f) / 700f, 0f, 1f));
            }
        }

        /** Riak udara panas di sekeliling sinar: garis bergelombang tipis tembus pandang yang merambat. */
        @Override
        public void renderSoft(Draw d) {
            float pt = d.partialTick, t = age + pt;
            if (!firing(t) || firstPerson(owner)) {
                return;
            }
            Vec3[] e = eyes(owner, pt);
            Vec3 end = aimEnd(owner, pt, enemyDist, null, null);
            Vec3 mid = e[0].add(e[1]).scale(0.5);
            Vec3 dir = end.subtract(mid);
            double len = dir.length();
            if (len < 0.8) {
                return;
            }
            dir = dir.scale(1.0 / len);
            Vec3 side = dir.cross(UP);
            side = side.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : side.normalize();
            Vec3 up2 = side.cross(dir).normalize();
            int segs = Mth.clamp((int) (len * 1.2), 6, 30);
            float a = strength(t) * 0.13f;
            for (int k = 0; k < 3; k++) {
                double phase = t * 0.9 + k * 2.1, amp = 0.07 + 0.03 * k;
                Vec3 axis = k == 1 ? up2 : side;
                double off = k == 0 ? 0.16 : k == 1 ? -0.15 : -0.17;
                Vec3 prev = null;
                for (int i = 0; i <= segs; i++) {
                    double u = i / (double) segs, s0 = u * len;
                    double wob = Math.sin(u * 22.0 - phase * 3.0) * amp * Math.min(1.0, s0 / 1.5);
                    Vec3 q = mid.add(dir.scale(s0)).add(axis.scale(wob + off));
                    if (prev != null) {
                        d.line(prev.x, prev.y, prev.z, q.x, q.y, q.z, 0.03f, 0.03f, 0xFFF4EC, a, a);
                    }
                    prev = q;
                }
            }
        }
    }

    // ------------------------------------------------------------------ sorotan singkat (Mode Surya)

    /** Sorotan sinar panas singkat dari kedua mata ke satu titik (Mode Surya & sasaran tambahan). */
    static final class Zap extends Effect {
        private final AbstractClientPlayer owner;
        private final Vec3 target;

        Zap(AbstractClientPlayer owner, Vec3 target) {
            super(8);
            this.owner = owner;
            this.target = target;
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float k = progress(pt);
            float a = (k < 0.15f ? k / 0.15f : 1f) * (1f - k * k);
            if (a <= 0.01f || !owner.isAlive()) {
                return;
            }
            boolean fp = firstPerson(owner);
            Vec3[] e = eyes(owner, pt);
            float bw = (fp ? 0.065f : 0.1f) * (float) owner.getScale();
            float t = age + pt;
            beam(d, e[0], target, bw, a, t, 3);
            beam(d, e[1], target, bw, a, t, 9);
            eyeGlow(d, e[0], owner, pt, a, fp);
            eyeGlow(d, e[1], owner, pt, a, fp);
            hotspot(d, target, bw * 0.8f, a, t);
        }
    }
}
