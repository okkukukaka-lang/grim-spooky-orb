package com.shazammod.client.vfx;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.ShazamMod;

import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;

/**
 * Alat gambar efek di dunia: semua bentuk dibuat dari geometri dengan gradasi warna per titik (bukan partikel
 * Minecraft), jadi cahayanya halus di jarak berapa pun. Koordinat masukan = posisi dunia; kamera diurus di sini.
 *
 * Dua jenis lapisan:
 * - additive: cahaya (ditambahkan ke layar, nggak menulis kedalaman, jadi nggak menutupi apa pun di belakangnya);
 * - soft: tembus pandang biasa dengan alpha halus (debu, bekas hangus, retakan gelap).
 */
public final class Draw {
    public static final ResourceLocation WHITE = ShazamMod.id("textures/entity/shazam_white.png");
    /** Gambar kedua sisi (jenis render yang dipakai membuang sisi belakang). */
    private static final boolean DOUBLE_SIDED = true;

    public static RenderType additiveType() {
        return RenderType.eyes(WHITE);
    }

    public static RenderType softType() {
        return RenderType.entityShadow(WHITE);
    }

    public final double camX, camY, camZ;
    public final float partialTick;
    private final PoseStack.Pose pose;
    private VertexConsumer vc;
    private boolean additive;
    // basis menghadap kamera (diisi basis())
    private double rx, ry, rz, ux, uy, uz, fx, fy, fz;

    public Draw(PoseStack.Pose pose, Vec3 camera, float partialTick) {
        this.pose = pose;
        this.camX = camera.x;
        this.camY = camera.y;
        this.camZ = camera.z;
        this.partialTick = partialTick;
    }

    public void begin(VertexConsumer consumer, boolean additive) {
        this.vc = consumer;
        this.additive = additive;
    }

    public boolean additive() {
        return additive;
    }

    /** Jarak ke kamera (buat mengurangi detail efek yang jauh). */
    public double distance(double x, double y, double z) {
        double dx = x - camX, dy = y - camY, dz = z - camZ;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    // ------------------------------------------------------------------ titik & segi empat

    private void vertex(double x, double y, double z, int rgb, float a) {
        float k = a < 0f ? 0f : (a > 1f ? 1f : a);
        int r = (rgb >> 16) & 0xFF, g = (rgb >> 8) & 0xFF, b = rgb & 0xFF;
        int alpha;
        if (additive) {   // cahaya: kekuatan masuk ke warna (dijumlahkan ke layar)
            r = (int) (r * k);
            g = (int) (g * k);
            b = (int) (b * k);
            alpha = 255;
        } else {
            alpha = (int) (k * 255f);
        }
        vc.addVertex(pose, (float) (x - camX), (float) (y - camY), (float) (z - camZ)).setColor(r, g, b, alpha)
                .setUv(0.5f, 0.5f).setOverlay(OverlayTexture.NO_OVERLAY).setLight(LightTexture.FULL_BRIGHT)
                .setNormal(pose, 0f, 1f, 0f);
    }

    /** Segi empat a-b-c-d dengan alpha per titik (dua sisi). */
    public void quad(double ax, double ay, double az, double bx, double by, double bz,
                     double cx, double cy, double cz, double dx, double dy, double dz,
                     int rgb, float aa, float ab, float ac, float ad) {
        if (aa <= 0.002f && ab <= 0.002f && ac <= 0.002f && ad <= 0.002f) {
            return;
        }
        vertex(ax, ay, az, rgb, aa);
        vertex(bx, by, bz, rgb, ab);
        vertex(cx, cy, cz, rgb, ac);
        vertex(dx, dy, dz, rgb, ad);
        if (DOUBLE_SIDED) {
            vertex(dx, dy, dz, rgb, ad);
            vertex(cx, cy, cz, rgb, ac);
            vertex(bx, by, bz, rgb, ab);
            vertex(ax, ay, az, rgb, aa);
        }
    }

    /** Segi empat dengan dua warna (a,b memakai c1; c,d memakai c2) - buat gradasi warna. */
    public void quad2(double ax, double ay, double az, double bx, double by, double bz,
                      double cx, double cy, double cz, double dx, double dy, double dz,
                      int c1, int c2, float aa, float ab, float ac, float ad) {
        if (aa <= 0.002f && ab <= 0.002f && ac <= 0.002f && ad <= 0.002f) {
            return;
        }
        vertex(ax, ay, az, c1, aa);
        vertex(bx, by, bz, c1, ab);
        vertex(cx, cy, cz, c2, ac);
        vertex(dx, dy, dz, c2, ad);
        if (DOUBLE_SIDED) {
            vertex(dx, dy, dz, c2, ad);
            vertex(cx, cy, cz, c2, ac);
            vertex(bx, by, bz, c1, ab);
            vertex(ax, ay, az, c1, aa);
        }
    }

    // ------------------------------------------------------------------ menghadap kamera

    /** Isi basis kanan/atas yang menghadap kamera di titik ini. */
    private void basis(double x, double y, double z) {
        double dx = x - camX, dy = y - camY, dz = z - camZ;
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1.0E-6) {
            dx = 0; dy = 0; dz = 1; len = 1;
        }
        fx = dx / len; fy = dy / len; fz = dz / len;
        // kanan = arah pandang x atas dunia
        rx = -fz; ry = 0; rz = fx;
        double rl = Math.sqrt(rx * rx + rz * rz);
        if (rl < 1.0E-4) {   // melihat lurus ke atas/bawah
            rx = 1; ry = 0; rz = 0;
        } else {
            rx /= rl; rz /= rl;
        }
        // atas = kanan x arah pandang
        ux = ry * fz - rz * fy;
        uy = rz * fx - rx * fz;
        uz = rx * fy - ry * fx;
    }

    /** Cahaya bulat lembut menghadap kamera: terang di tengah, memudar halus ke tepi. */
    public void glow(double x, double y, double z, float radius, int rgb, float a) {
        if (a <= 0.003f || radius <= 0f) {
            return;
        }
        basis(x, y, z);
        int seg = radius > 1.2f ? 14 : radius > 0.35f ? 10 : 7;
        double inner = radius * 0.36;
        float ai = a * 0.42f;
        for (int k = 0; k < seg; k++) {
            double t0 = Math.PI * 2.0 * k / seg, t1 = Math.PI * 2.0 * (k + 1) / seg;
            double c0 = Math.cos(t0), s0 = Math.sin(t0), c1 = Math.cos(t1), s1 = Math.sin(t1);
            double ix0 = x + (rx * c0 + ux * s0) * inner, iy0 = y + (ry * c0 + uy * s0) * inner, iz0 = z + (rz * c0 + uz * s0) * inner;
            double ix1 = x + (rx * c1 + ux * s1) * inner, iy1 = y + (ry * c1 + uy * s1) * inner, iz1 = z + (rz * c1 + uz * s1) * inner;
            double ox0 = x + (rx * c0 + ux * s0) * radius, oy0 = y + (ry * c0 + uy * s0) * radius, oz0 = z + (rz * c0 + uz * s0) * radius;
            double ox1 = x + (rx * c1 + ux * s1) * radius, oy1 = y + (ry * c1 + uy * s1) * radius, oz1 = z + (rz * c1 + uz * s1) * radius;
            quad(x, y, z, x, y, z, ix0, iy0, iz0, ix1, iy1, iz1, rgb, a, a, ai, ai);
            quad(ix0, iy0, iz0, ox0, oy0, oz0, ox1, oy1, oz1, ix1, iy1, iz1, rgb, ai, 0f, 0f, ai);
        }
    }

    /** Cahaya berlapis: inti putih kecil + pendar berwarna (khas petir/energi). */
    public void flare(double x, double y, double z, float radius, int rgb, float a) {
        glow(x, y, z, radius, rgb, a * 0.8f);
        glow(x, y, z, radius * 0.32f, 0xFFFFFF, a);
    }

    /** Bintang kilau empat sudut menghadap kamera. */
    public void glint(double x, double y, double z, float size, float rot, int rgb, float a) {
        if (a <= 0.003f) {
            return;
        }
        basis(x, y, z);
        double c = Math.cos(rot), s = Math.sin(rot);
        // dua sumbu bintang (diputar)
        double ax = rx * c + ux * s, ay = ry * c + uy * s, az = rz * c + uz * s;
        double bx = -rx * s + ux * c, by = -ry * s + uy * c, bz = -rz * s + uz * c;
        double w = size * 0.12;
        for (int k = 0; k < 2; k++) {
            double px = k == 0 ? ax : bx, py = k == 0 ? ay : by, pz = k == 0 ? az : bz;   // panjang
            double qx = k == 0 ? bx : ax, qy = k == 0 ? by : ay, qz = k == 0 ? bz : az;   // lebar
            for (int sgn = -1; sgn <= 1; sgn += 2) {
                double tx = x + px * size * sgn, ty = y + py * size * sgn, tz = z + pz * size * sgn;
                quad(x + qx * w, y + qy * w, z + qz * w, tx, ty, tz, tx, ty, tz, x - qx * w, y - qy * w, z - qz * w,
                        rgb, a, 0f, 0f, a);
            }
        }
        glow(x, y, z, size * 0.45f, rgb, a * 0.6f);
    }

    /**
     * Garis menghadap kamera dari a ke b dengan tepi lembut (dua pita: tepi 0, tengah penuh).
     * wa/wb = lebar di a/b, aa/ab = kekuatan di a/b.
     */
    public void line(double ax, double ay, double az, double bx, double by, double bz,
                     float wa, float wb, int rgb, float aa, float ab) {
        if (aa <= 0.003f && ab <= 0.003f) {
            return;
        }
        double sx = bx - ax, sy = by - ay, sz = bz - az;
        double mx = (ax + bx) * 0.5 - camX, my = (ay + by) * 0.5 - camY, mz = (az + bz) * 0.5 - camZ;
        // samping = arah garis x arah pandang
        double px = sy * mz - sz * my, py = sz * mx - sx * mz, pz = sx * my - sy * mx;
        double pl = Math.sqrt(px * px + py * py + pz * pz);
        if (pl < 1.0E-9) {
            return;
        }
        px /= pl; py /= pl; pz /= pl;
        double ha = wa * 0.5, hb = wb * 0.5;
        quad(ax + px * ha, ay + py * ha, az + pz * ha, ax, ay, az, bx, by, bz, bx + px * hb, by + py * hb, bz + pz * hb,
                rgb, 0f, aa, ab, 0f);
        quad(ax, ay, az, ax - px * ha, ay - py * ha, az - pz * ha, bx - px * hb, by - py * hb, bz - pz * hb, bx, by, bz,
                rgb, aa, 0f, 0f, ab);
    }

    /** Garis berlapis: pendar lebar berwarna + inti terang tipis (buat petir dan berkas cahaya). */
    public void beam(double ax, double ay, double az, double bx, double by, double bz,
                     float width, int rgb, int core, float aa, float ab) {
        line(ax, ay, az, bx, by, bz, width, width, rgb, aa * 0.55f, ab * 0.55f);
        line(ax, ay, az, bx, by, bz, width * 0.28f, width * 0.28f, core, aa, ab);
    }

    /** Polyline xyz (titik berurutan) sebagai berkas: lebar/kekuatan di ujung awal dan akhir. */
    public void polyline(float[] pts, int count, float w0, float w1, int rgb, int core, float a0, float a1) {
        for (int i = 0; i + 1 < count; i++) {
            float f0 = i / (float) (count - 1), f1 = (i + 1) / (float) (count - 1);
            int o = i * 3;
            float wa = w0 + (w1 - w0) * f0, wb = w0 + (w1 - w0) * f1;
            beam(pts[o], pts[o + 1], pts[o + 2], pts[o + 3], pts[o + 4], pts[o + 5],
                    (wa + wb) * 0.5f, rgb, core, a0 + (a1 - a0) * f0, a0 + (a1 - a0) * f1);
        }
    }

    // ------------------------------------------------------------------ bentuk di bidang tertentu

    /** Dua vektor satuan tegak lurus normal (bidang lingkaran). out = {e1x, e1y, e1z, e2x, e2y, e2z}. */
    public static void plane(double nx, double ny, double nz, double[] out) {
        double ax = Math.abs(ny) < 0.9 ? 0 : 1, ay = Math.abs(ny) < 0.9 ? 1 : 0, az = 0;
        double e1x = ay * nz - az * ny, e1y = az * nx - ax * nz, e1z = ax * ny - ay * nx;
        double l = Math.sqrt(e1x * e1x + e1y * e1y + e1z * e1z);
        e1x /= l; e1y /= l; e1z /= l;
        out[0] = e1x; out[1] = e1y; out[2] = e1z;
        out[3] = ny * e1z - nz * e1y;
        out[4] = nz * e1x - nx * e1z;
        out[5] = nx * e1y - ny * e1x;
    }

    /** Tinggi tanah per sudut & jarak (buat cincin/retakan yang menempel di tanah), atau null = rata. */
    public interface Height {
        double at(double angle, double radius);
    }

    /**
     * Cincin lembut di bidang (normal n): tepi dalam dan luar memudar, paling terang di jari-jari r.
     * @param fill kekuatan isian samar di dalam cincin (0 = cuma cincin)
     */
    public void ring(double cx, double cy, double cz, double nx, double ny, double nz, double radius, double width,
                     int rgb, float a, float fill, Height ground) {
        if (a <= 0.003f || radius <= 0.0) {
            return;
        }
        double[] e = new double[6];
        plane(nx, ny, nz, e);
        int seg = Math.max(16, Math.min(64, (int) (radius * 10)));
        double r0 = Math.max(0.0, radius - width * 0.5), r1 = radius + width * 0.5;
        for (int k = 0; k < seg; k++) {
            double t0 = Math.PI * 2.0 * k / seg, t1 = Math.PI * 2.0 * (k + 1) / seg;
            double c0 = Math.cos(t0), s0 = Math.sin(t0), c1 = Math.cos(t1), s1 = Math.sin(t1);
            double dx0 = e[0] * c0 + e[3] * s0, dy0 = e[1] * c0 + e[4] * s0, dz0 = e[2] * c0 + e[5] * s0;
            double dx1 = e[0] * c1 + e[3] * s1, dy1 = e[1] * c1 + e[4] * s1, dz1 = e[2] * c1 + e[5] * s1;
            double h0i = ground == null ? 0 : ground.at(t0, r0), h1i = ground == null ? 0 : ground.at(t1, r0);
            double h0m = ground == null ? 0 : ground.at(t0, radius), h1m = ground == null ? 0 : ground.at(t1, radius);
            double h0o = ground == null ? 0 : ground.at(t0, r1), h1o = ground == null ? 0 : ground.at(t1, r1);
            quad(cx + dx0 * r0, cy + dy0 * r0 + h0i, cz + dz0 * r0, cx + dx0 * radius, cy + dy0 * radius + h0m, cz + dz0 * radius,
                    cx + dx1 * radius, cy + dy1 * radius + h1m, cz + dz1 * radius, cx + dx1 * r0, cy + dy1 * r0 + h1i, cz + dz1 * r0,
                    rgb, a * fill, a, a, a * fill);
            quad(cx + dx0 * radius, cy + dy0 * radius + h0m, cz + dz0 * radius, cx + dx0 * r1, cy + dy0 * r1 + h0o, cz + dz0 * r1,
                    cx + dx1 * r1, cy + dy1 * r1 + h1o, cz + dz1 * r1, cx + dx1 * radius, cy + dy1 * radius + h1m, cz + dz1 * radius,
                    rgb, a, 0f, 0f, a);
            if (fill > 0f && r0 > 0.05) {
                double hc = ground == null ? 0 : ground.at(0, 0);
                quad(cx, cy + hc, cz, cx, cy + hc, cz, cx + dx1 * r0, cy + dy1 * r0 + h1i, cz + dz1 * r0,
                        cx + dx0 * r0, cy + dy0 * r0 + h0i, cz + dz0 * r0, rgb, 0f, 0f, a * fill, a * fill);
            }
        }
    }

    /** Cakram di bidang: kekuatan aCenter di tengah ke aEdge di tepi. */
    public void disc(double cx, double cy, double cz, double nx, double ny, double nz, double radius,
                     int rgb, float aCenter, float aEdge, Height ground) {
        double[] e = new double[6];
        plane(nx, ny, nz, e);
        int seg = Math.max(12, Math.min(40, (int) (radius * 8)));
        double hc = ground == null ? 0 : ground.at(0, 0);
        double rm = radius * 0.5;
        float am = (aCenter + aEdge) * 0.5f;
        for (int k = 0; k < seg; k++) {
            double t0 = Math.PI * 2.0 * k / seg, t1 = Math.PI * 2.0 * (k + 1) / seg;
            double c0 = Math.cos(t0), s0 = Math.sin(t0), c1 = Math.cos(t1), s1 = Math.sin(t1);
            double dx0 = e[0] * c0 + e[3] * s0, dy0 = e[1] * c0 + e[4] * s0, dz0 = e[2] * c0 + e[5] * s0;
            double dx1 = e[0] * c1 + e[3] * s1, dy1 = e[1] * c1 + e[4] * s1, dz1 = e[2] * c1 + e[5] * s1;
            double hm0 = ground == null ? 0 : ground.at(t0, rm), hm1 = ground == null ? 0 : ground.at(t1, rm);
            double he0 = ground == null ? 0 : ground.at(t0, radius), he1 = ground == null ? 0 : ground.at(t1, radius);
            quad(cx, cy + hc, cz, cx, cy + hc, cz, cx + dx1 * rm, cy + dy1 * rm + hm1, cz + dz1 * rm,
                    cx + dx0 * rm, cy + dy0 * rm + hm0, cz + dz0 * rm, rgb, aCenter, aCenter, am, am);
            quad(cx + dx0 * rm, cy + dy0 * rm + hm0, cz + dz0 * rm, cx + dx1 * rm, cy + dy1 * rm + hm1, cz + dz1 * rm,
                    cx + dx1 * radius, cy + dy1 * radius + he1, cz + dz1 * radius, cx + dx0 * radius, cy + dy0 * radius + he0,
                    cz + dz0 * radius, rgb, am, am, aEdge, aEdge);
        }
    }

    /** Garis datar di bidang (normal n), tepi lembut. */
    public void flatLine(double ax, double ay, double az, double bx, double by, double bz,
                         double nx, double ny, double nz, float width, int rgb, float aa, float ab) {
        double sx = bx - ax, sy = by - ay, sz = bz - az;
        double px = sy * nz - sz * ny, py = sz * nx - sx * nz, pz = sx * ny - sy * nx;
        double pl = Math.sqrt(px * px + py * py + pz * pz);
        if (pl < 1.0E-9) {
            return;
        }
        double h = width * 0.5 / pl;
        px *= h; py *= h; pz *= h;
        quad(ax + px, ay + py, az + pz, ax, ay, az, bx, by, bz, bx + px, by + py, bz + pz, rgb, 0f, aa, ab, 0f);
        quad(ax, ay, az, ax - px, ay - py, az - pz, bx - px, by - py, bz - pz, bx, by, bz, rgb, aa, 0f, 0f, ab);
    }

    /**
     * Cangkang bola (atau kubah) yang tepinya paling terang, seperti gelembung energi:
     * kekuatan tiap titik = (1 - |normal · arah ke kamera|)^power.
     * @param upper 1 = bola penuh, 0.5 = kubah setengah bola di atas tanah
     */
    public void shell(double cx, double cy, double cz, double radius, int rgb, float a, double power, double upper) {
        if (a <= 0.003f || radius <= 0.0) {
            return;
        }
        int lon = radius > 6 ? 28 : 18, lat = radius > 6 ? 14 : 10;
        double latMax = Math.PI * upper;
        double[][] px = new double[lat + 1][lon + 1], py = new double[lat + 1][lon + 1], pz = new double[lat + 1][lon + 1];
        float[][] k = new float[lat + 1][lon + 1];
        for (int i = 0; i <= lat; i++) {
            double th = latMax * i / lat;   // 0 = puncak
            double st = Math.sin(th), ct = Math.cos(th);
            for (int j = 0; j <= lon; j++) {
                double ph = Math.PI * 2.0 * j / lon;
                double nx = st * Math.cos(ph), ny = ct, nz = st * Math.sin(ph);
                double x = cx + nx * radius, y = cy + ny * radius, z = cz + nz * radius;
                px[i][j] = x; py[i][j] = y; pz[i][j] = z;
                double vx = camX - x, vy = camY - y, vz = camZ - z;
                double vl = Math.sqrt(vx * vx + vy * vy + vz * vz);
                double f = vl < 1.0E-6 ? 1.0 : 1.0 - Math.abs((nx * vx + ny * vy + nz * vz) / vl);
                k[i][j] = (float) (a * Math.pow(Math.max(0.0, f), power));
            }
        }
        for (int i = 0; i < lat; i++) {
            for (int j = 0; j < lon; j++) {
                quad(px[i][j], py[i][j], pz[i][j], px[i][j + 1], py[i][j + 1], pz[i][j + 1],
                        px[i + 1][j + 1], py[i + 1][j + 1], pz[i + 1][j + 1], px[i + 1][j], py[i + 1][j], pz[i + 1][j],
                        rgb, k[i][j], k[i][j + 1], k[i + 1][j + 1], k[i + 1][j]);
            }
        }
    }

    /**
     * Kerucut terbuka dari puncak a ke arah d (sudah satuan), panjang len, setengah sudut atan(spread).
     * Kekuatan naik dari puncak ke mulut kerucut, tepi paling terang (khas gelombang udara / uap sonic boom).
     */
    public void cone(double ax, double ay, double az, double dx, double dy, double dz, double len, double spread,
                     int rgb, float a, double power) {
        if (a <= 0.003f || len <= 0.0) {
            return;
        }
        double[] e = new double[6];
        plane(dx, dy, dz, e);
        int seg = 24, rings = 6;
        double[][] px = new double[rings + 1][seg + 1], py = new double[rings + 1][seg + 1], pz = new double[rings + 1][seg + 1];
        float[][] k = new float[rings + 1][seg + 1];
        for (int i = 0; i <= rings; i++) {
            double t = i / (double) rings;
            double dist = len * t, r = dist * spread;
            for (int j = 0; j <= seg; j++) {
                double ph = Math.PI * 2.0 * j / seg;
                double ox = e[0] * Math.cos(ph) + e[3] * Math.sin(ph);
                double oy = e[1] * Math.cos(ph) + e[4] * Math.sin(ph);
                double oz = e[2] * Math.cos(ph) + e[5] * Math.sin(ph);
                double x = ax + dx * dist + ox * r, y = ay + dy * dist + oy * r, z = az + dz * dist + oz * r;
                px[i][j] = x; py[i][j] = y; pz[i][j] = z;
                // normal kerucut (kira-kira) = arah keluar dikurangi sedikit arah sumbu
                double nx = ox - dx * spread, ny = oy - dy * spread, nz = oz - dz * spread;
                double nl = Math.sqrt(nx * nx + ny * ny + nz * nz);
                double vx = camX - x, vy = camY - y, vz = camZ - z;
                double vl = Math.sqrt(vx * vx + vy * vy + vz * vz);
                double f = vl < 1.0E-6 || nl < 1.0E-9 ? 1.0 : 1.0 - Math.abs((nx * vx + ny * vy + nz * vz) / (vl * nl));
                k[i][j] = (float) (a * Math.pow(Math.max(0.0, f), power) * t * t);
            }
        }
        for (int i = 0; i < rings; i++) {
            for (int j = 0; j < seg; j++) {
                quad(px[i][j], py[i][j], pz[i][j], px[i][j + 1], py[i][j + 1], pz[i][j + 1],
                        px[i + 1][j + 1], py[i + 1][j + 1], pz[i + 1][j + 1], px[i + 1][j], py[i + 1][j], pz[i + 1][j],
                        rgb, k[i][j], k[i][j + 1], k[i + 1][j + 1], k[i + 1][j]);
            }
        }
    }

    /** Pilar cahaya tegak menghadap kamera (lebar w, dari y0 ke y1), tepi lembut, ujung atas memudar. */
    public void pillar(double x, double y0, double z, double y1, float width, int rgb, int core, float a) {
        int steps = 6;
        for (int i = 0; i < steps; i++) {
            double ya = y0 + (y1 - y0) * i / steps, yb = y0 + (y1 - y0) * (i + 1) / steps;
            float fa = 1f - i / (float) steps, fb = 1f - (i + 1) / (float) steps;
            beam(x, ya, z, x, yb, z, width, rgb, core, a * (0.35f + 0.65f * fa), a * (0.35f + 0.65f * fb) * (i == steps - 1 ? 0f : 1f));
        }
    }
}
