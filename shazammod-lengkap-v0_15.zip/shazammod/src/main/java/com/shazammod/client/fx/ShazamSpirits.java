package com.shazammod.client.fx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.joml.Matrix4f;
import org.joml.Vector3f;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.ShazamMod;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Runes;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.ChatFormatting;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TextColor;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Roh enam dewa (S-H-A-Z-A-M) saat transformasi. Mereka datang SATU PER SATU dengan cara masuk masing-masing
 * (lihat {@link GodShow}), berwujud dewa sungguhan (lihat {@link GodFigures}): Solomon berjubah & bermahkota
 * dengan kitab, Hercules berkulit singa dengan gada, Atlas memanggul bola langit, Zeus dengan petirnya,
 * Achilles berhelm jambul dengan perisai & tombak, Mercury bertopi & bersandal sayap dengan caduceus.
 * Lalu tiap dewa mengalirkan sinar energinya ke kepalan yang terangkat dan lenyap saat petir menyambar.
 *
 * Semua dihitung di client (cuma tampilan): tiap pemain melihat dewa-dewa berdiri melengkung di seberang
 * kameranya sendiri, berurutan S-H-A-Z-A-M dari kiri ke kanan.
 */
public final class ShazamSpirits {
    private ShazamSpirits() {}

    // ======= Pilihan =======
    /** Nama & kekuatan tiap dewa muncul di atas hotbar saat dia datang (cuma untuk yang berubah). */
    private static final boolean SHOW_NAMES = true;
    /** Lebih jauh dari ini (blok) dewa nggak digambar. */
    private static final double DRAW_DISTANCE = 96.0;

    private static final ResourceLocation WHITE = ShazamMod.id("textures/entity/shazam_white.png");
    private static final String[] NAMES = {"solomon", "hercules", "atlas", "zeus", "achilles", "mercury"};
    private static final int N = GodFigures.COUNT;

    /** Satu pemanggilan dewa oleh satu pemain. */
    private static final class Ritual {
        final int caster;
        final long start;
        final double ox, oy, oz;
        final GodShow.Layout layout = new GodShow.Layout();
        final GodShow.State[] states = new GodShow.State[N];
        final GodMesh[] meshes = new GodMesh[N];
        /** Pusaka & badan tiap dewa di dunia dari gambar terakhir (buat efek di tick). */
        final double[][] focus = new double[N][3];
        final boolean[] seen = new boolean[N];
        final GodShow.State tmp = new GodShow.State();

        Ritual(int caster, long start, Vec3 origin) {
            this.caster = caster;
            this.start = start;
            this.ox = origin.x;
            this.oy = origin.y;
            this.oz = origin.z;
            for (int i = 0; i < N; i++) {
                states[i] = new GodShow.State();
                meshes[i] = new GodMesh();
            }
        }
    }

    private static final Map<Integer, Ritual> RITUALS = new HashMap<>();

    public static void start(AbstractClientPlayer caster) {
        Minecraft mc = Minecraft.getInstance();
        if (!(caster.level() instanceof ClientLevel level)) {
            return;
        }
        Ritual r = new Ritual(caster.getId(), level.getGameTime(), caster.position());
        // arah pandang penonton ke pemain: dewa-dewa berdiri di seberang kamera
        double dx, dz;
        if (caster == mc.player) {
            CameraType type = mc.options.getCameraType();
            boolean front = type == CameraType.THIRD_PERSON_FRONT || (type.isFirstPerson() && ShazamCinematic.ENABLED);
            double yaw = Math.toRadians(caster.getYRot());
            double fx = -Math.sin(yaw), fz = Math.cos(yaw);
            dx = front ? -fx : fx;
            dz = front ? -fz : fz;
        } else {
            Vec3 cam = mc.gameRenderer.getMainCamera().getPosition();
            dx = caster.getX() - cam.x;
            dz = caster.getZ() - cam.z;
        }
        r.layout.arrange(dx, dz, caster.getScale());
        for (int i = 0; i < N; i++) {
            r.layout.y[i] = groundOffset(level, caster, r.ox + r.layout.x[i], r.oy, r.oz + r.layout.z[i]);
        }
        RITUALS.put(caster.getId(), r);
    }

    public static void clear() {
        RITUALS.clear();
    }

    /** Tinggi tanah di (x, z) relatif kaki pemain (dewa berdiri di permukaan; tanpa tanah = melayang). */
    private static double groundOffset(ClientLevel level, AbstractClientPlayer viewer, double x, double y, double z) {
        BlockHitResult hit = level.clip(new ClipContext(new Vec3(x, y + 2.5, z), new Vec3(x, y - 3.5, z),
                ClipContext.Block.COLLIDER, ClipContext.Fluid.ANY, viewer));
        if (hit.getType() == HitResult.Type.MISS) {
            return 0.0;
        }
        return Math.max(-3.0, Math.min(2.5, hit.getLocation().y - y));
    }

    // ------------------------------------------------------------------ tick: efek & suara tiap kedatangan

    public static void tick(ClientLevel level) {
        long now = level.getGameTime();
        Iterator<Map.Entry<Integer, Ritual>> it = RITUALS.entrySet().iterator();
        while (it.hasNext()) {
            Ritual r = it.next().getValue();
            int t = (int) (now - r.start);
            if (!(level.getEntity(r.caster) instanceof AbstractClientPlayer caster) || t > GodShow.STRIKE + 2 || t < 0) {
                it.remove();
                continue;
            }
            Vec3 fist = ShazamPoses.handPos(caster, true, 1f);
            for (int i = 0; i < N; i++) {
                GodShow.State s = r.tmp;
                GodShow.state(i, t, r.layout, fist.x - r.ox, fist.y - r.oy, fist.z - r.oz, s);
                int tau = t - GodShow.start(i);
                if (tau >= 0) {
                    entrance(level, r, caster, i, tau, s);
                    ambient(level, r, i, t, s);
                }
            }
            if (t == GodShow.CHORUS) {
                chorus(level, r);
            }
            for (int i = 0; i < N; i++) {
                if (t == GodShow.CONVERGE + 4 + i && r.seen[i]) {   // sinar tiap dewa menyala berurutan
                    double[] f = r.focus[i];
                    Vfx.add(new Fx.Flash(new Vec3(f[0], f[1], f[2]), 1.1f, GodFigures.AURA[i], 8, 0.9f));
                    play(level, f[0], f[1], f[2], SoundEvents.AMETHYST_BLOCK_CHIME, 1.0f, 0.8f + i * 0.12f);
                }
            }
            if (t == GodShow.STRIKE) {
                strike(level, fist);
            }
        }
    }

    /** Efek & suara gerak masuk tiap dewa (tau = tick sejak dewa itu mulai muncul). */
    private static void entrance(ClientLevel level, Ritual r, AbstractClientPlayer caster, int god, int tau, GodShow.State s) {
        RandomSource rnd = level.random;
        double sc = s.scale;
        double fx = r.ox + s.x, fy = r.oy + s.y, fz = r.oz + s.z;   // kaki dewa sekarang
        double ax = r.ox + r.layout.x[god], ay = r.oy + r.layout.y[god], az = r.oz + r.layout.z[god];   // tempat berdiri
        Vec3 anchor = new Vec3(ax, ay, az);
        int arrive = GodShow.ARRIVE[god] - GodShow.start(god);
        int aura = GodFigures.AURA[god];
        switch (god) {
            case GodFigures.SOLOMON -> {
                if (tau == 0) {
                    int life = GodShow.STRIKE - GodShow.start(god) + 6;
                    Vfx.add(new Runes.Circle(Lightning.Anchor.fixed(anchor.add(0, 0.04, 0)), new Vec3(0, 1, 0), 1.3 * sc, aura,
                            life, 0.035f, 0.95f, null));
                    play(level, ax, ay, az, SoundEvents.ENCHANTMENT_TABLE_USE, 1.4f, 0.7f);
                    play(level, ax, ay, az, SoundEvents.AMETHYST_BLOCK_RESONATE, 1.0f, 0.7f);
                }
                if (tau < arrive) {   // huruf-huruf cahaya naik di garis tubuh yang sedang terbentuk
                    double y = fy + s.mask.scanY * sc;
                    for (int k = 0; k < 3; k++) {
                        double a = rnd.nextDouble() * Math.PI * 2, rr = (0.25 + rnd.nextDouble() * 0.3) * sc;
                        Vfx.glint(fx + Math.cos(a) * rr, y, fz + Math.sin(a) * rr, GodLook.lighten(aura, 0.5), 0.14f, 8);
                    }
                }
                if (tau == arrive + 1) {
                    play(level, ax, ay, az, SoundEvents.BOOK_PAGE_TURN, 1.4f, 0.8f);
                }
            }
            case GodFigures.HERCULES -> {
                if (tau == 0) {
                    Vfx.add(new Fx.Flash(new Vec3(fx, fy + sc, fz), 2.5f, aura, 10, 1f));
                    play(level, caster.getX(), caster.getY(), caster.getZ(), SoundEvents.PHANTOM_SWOOP, 1.0f, 0.6f);
                }
                if (tau < arrive) {   // bintang jatuh: percikan di belakangnya
                    for (int k = 0; k < 3; k++) {
                        Vfx.mote(fx + (rnd.nextDouble() - 0.5) * 0.6 * sc, fy + (0.6 + rnd.nextDouble()) * sc,
                                fz + (rnd.nextDouble() - 0.5) * 0.6 * sc, 0, 0.02, 0, aura, 0.2f, 14);
                    }
                }
                if (tau == arrive) {   // mendarat bertumpu kepalan: tanah retak, gelombang kejut
                    ShazamFx.impact(level, caster, anchor, 1.6f, aura, 0xFFF2A8, true);
                    ShazamFx.shakeAround(anchor, 0.8f, 24.0);
                    play(level, ax, ay, az, SoundEvents.MACE_SMASH_GROUND_HEAVY, 1.4f, 0.7f);
                    play(level, ax, ay, az, SoundEvents.ANVIL_LAND, 0.5f, 0.5f);
                }
            }
            case GodFigures.ATLAS -> {
                Ground.Map map = tau == 0 || tau == 2 || tau == arrive ? ShazamFx.ground(level, anchor, 3.0) : null;
                if (tau == 0) {   // bumi retak membara
                    if (map != null && map.found) {
                        Vfx.add(new Ground.Cracks(map.center(anchor), map, 11, 1.4f * (float) sc, GodShow.STRIKE + 40, 70, aura,
                                rnd.nextLong()));
                    }
                    play(level, ax, ay, az, SoundEvents.MACE_SMASH_GROUND_HEAVY, 1.0f, 0.5f);
                    play(level, ax, ay, az, SoundEvents.IRON_GOLEM_DAMAGE, 1.0f, 0.5f);
                    ShazamFx.shakeAround(anchor, 0.35f, 20.0);
                }
                if (tau == 2 && map != null && map.found) {   // batu-batu terlempar
                    Vfx.add(new Ground.Debris(map.center(anchor), map, 12, 0.18, 0.42, 0.9, 50));
                    ShazamFx.dustPuffs(level, map.center(anchor), map.dustColor(level, anchor), 14, 1.2, 0.12);
                }
                if (tau < arrive + 2 && tau % 2 == 0) {   // bara naik dari celah
                    for (int k = 0; k < 4; k++) {
                        double a = rnd.nextDouble() * Math.PI * 2, rr = rnd.nextDouble() * 1.3 * sc;
                        Vfx.ember(ax + Math.cos(a) * rr, ay + 0.1, az + Math.sin(a) * rr, 0, 0.05 + rnd.nextDouble() * 0.06, 0,
                                0.1f, 24);
                    }
                }
                if (tau == arrive) {
                    Vfx.add(new Fx.Wave(anchor.add(0, 0.05, 0), new Vec3(0, 1, 0), 3.2 * sc, 0.5, aura, 16, 0.85f, 0.1f, map));
                    play(level, ax, ay, az, SoundEvents.RAVAGER_STUNNED, 0.8f, 0.5f);
                    ShazamFx.shakeAround(anchor, 0.4f, 20.0);
                }
            }
            case GodFigures.ZEUS -> {
                if (tau < arrive) {   // badai berkumpul di atasnya
                    Vec3 cloud = anchor.add((rnd.nextDouble() - 0.5) * 2.5, 14 + rnd.nextDouble() * 2, (rnd.nextDouble() - 0.5) * 2.5);
                    Vfx.add(new Fx.Flash(cloud, 3.5f, 0xBFD8FF, 6, 0.45f));
                    if (tau == 0) {
                        play(level, ax, ay + 8, az, SoundEvents.LIGHTNING_BOLT_THUNDER, 0.5f, 1.4f);
                    }
                }
                if (tau == arrive) {   // petir menyambar: Zeus berdiri di tempat petir jatuh
                    Vec3 sky = anchor.add(0, 42, 0);
                    Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(sky), Lightning.Anchor.fixed(anchor.add(0, 0.1, 0)),
                            0xFFF0B0, 0.42f, 9, 1, 4, 0.2));
                    Vfx.add(new Fx.Pillar(anchor, 42.0, 1.3f, aura, 12));
                    Vfx.add(new Fx.Flash(anchor.add(0, 1.4 * sc, 0), 4.0f, 0xFFFFFF, 12, 1f));
                    ShazamFx.impact(level, caster, anchor, 0.7f, aura, 0xFFF6E2, false);
                    ShazamFx.groundArcs(level, anchor, 7, 3.0, 0xFFE680, 8);
                    ShazamFx.shakeAround(anchor, 0.6f, 28.0);
                    play(level, ax, ay, az, SoundEvents.LIGHTNING_BOLT_THUNDER, 1.0f, 1.0f);
                    play(level, ax, ay, az, SoundEvents.LIGHTNING_BOLT_IMPACT, 1.2f, 0.9f);
                    if (Minecraft.getInstance().player != null
                            && Minecraft.getInstance().player.position().distanceTo(anchor) < 32.0) {
                        ScreenFlash.flash(0.35f, 0xF2F6FF);
                    }
                }
                if (tau > arrive && tau < arrive + 10) {   // listrik merayap di badannya
                    for (int k = 0; k < 2; k++) {
                        Vec3 a = bodyPoint(rnd, fx, fy, fz, sc), b = bodyPoint(rnd, fx, fy, fz, sc);
                        Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(a), Lightning.Anchor.fixed(b), 0xE8F2FF, 0.05f, 2, 1, 0,
                                0.3));
                    }
                }
                if (tau > arrive + 6 && tau % 7 == 0 && r.seen[god]) {   // petir di tangannya memercik
                    double[] f = r.focus[god];
                    Vec3 a = new Vec3(f[0], f[1], f[2]);
                    Vec3 b = a.add((rnd.nextDouble() - 0.5) * 1.6, (rnd.nextDouble() - 0.2) * 1.4, (rnd.nextDouble() - 0.5) * 1.6);
                    Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(a), Lightning.Anchor.fixed(b), 0xFFF0B0, 0.05f, 3, 1, 1, 0.3));
                }
            }
            case GodFigures.ACHILLES -> {
                if (tau == 0) {   // cincin api di tanah
                    Ground.Map map = ShazamFx.ground(level, anchor, 2.5);
                    Vfx.add(new Fx.Wave(anchor.add(0, 0.05, 0), new Vec3(0, 1, 0), 1.7 * sc, 0.45, 0xFF8A30, 18, 0.9f, 0.25f, map));
                    play(level, ax, ay, az, SoundEvents.BLAZE_SHOOT, 1.2f, 0.6f);
                }
                if (tau < arrive) {   // pusaran api emas berpilin naik
                    for (int k = 0; k < 4; k++) {
                        double a = tau * 0.75 + k * Math.PI / 2;
                        double rr = (0.95 - tau * 0.045) * sc;
                        double y = ay + (0.1 + tau * 0.2 + k * 0.08) * sc;
                        Vfx.ember(ax + Math.cos(a) * rr, y, az + Math.sin(a) * rr, -Math.sin(a) * 0.08, 0.06, Math.cos(a) * 0.08,
                                0.12f, 18);
                        if (k % 2 == 0) {
                            Vfx.mote(ax + Math.cos(a) * rr, y, az + Math.sin(a) * rr, 0, 0.03, 0, 0xFF9A3C, 0.22f, 12);
                        }
                    }
                }
                if (tau == arrive) {   // perisai dihentakkan: kilatan & percikan
                    Vec3 sh = shieldPoint(s, r);
                    Vfx.add(new Fx.Flash(sh, 2.2f, 0xFFE8A0, 10, 1f));
                    ShazamFx.ringOfSparks(level, sh, 26, 0xFFD060, 0.45);
                    play(level, ax, ay, az, SoundEvents.SHIELD_BLOCK, 1.3f, 0.75f);
                    play(level, ax, ay, az, SoundEvents.ANVIL_LAND, 0.35f, 1.4f);
                }
            }
            default -> {   // MERCURY
                if (tau == 0) {
                    play(level, caster.getX(), caster.getY(), caster.getZ(), SoundEvents.PHANTOM_SWOOP, 1.2f, 1.5f);
                }
                if (tau < arrive) {   // jejak secepat kilat & debu yang tersibak
                    for (int k = 0; k < 3; k++) {
                        Vfx.spark(fx + (rnd.nextDouble() - 0.5) * 0.4, fy + (0.4 + rnd.nextDouble() * 1.8) * sc,
                                fz + (rnd.nextDouble() - 0.5) * 0.4, 0, 0, 0, k == 0 ? 0xFFFFFF : aura, 0.06f, 8, Double.NaN);
                    }
                    Vfx.dust(fx, fy + 0.1, fz, (rnd.nextDouble() - 0.5) * 0.1, 0.02, (rnd.nextDouble() - 0.5) * 0.1, 0xC8C0B0,
                            0.5f, 16);
                }
                if (tau == arrive) {   // berhenti mendadak: hembusan angin
                    Ground.Map map = ShazamFx.ground(level, anchor, 3.0);
                    Vfx.add(new Fx.Wave(anchor.add(0, 0.05, 0), new Vec3(0, 1, 0), 2.6 * sc, 0.35, aura, 12, 0.8f, 0f, map));
                    ShazamFx.dustPuffs(level, anchor, 0xC8C0B0, 12, 0.9, 0.16);
                    ShazamFx.ringOfSparks(level, anchor.add(0, 1.0 * sc, 0), 14, aura, 0.35);
                    play(level, ax, ay, az, SoundEvents.ENDER_DRAGON_FLAP, 0.9f, 1.7f);
                }
            }
        }
        if (tau == arrive) {   // tiap dewa tiba dengan denting yang makin tinggi + namanya
            play(level, ax, ay, az, SoundEvents.AMETHYST_BLOCK_CHIME, 1.6f, 0.6f + god * 0.14f);
            Vfx.add(new Fx.Flash(new Vec3(ax, ay + 1.3 * sc, az), 2.0f, aura, 10, 0.55f));
            Minecraft mc = Minecraft.getInstance();
            if (SHOW_NAMES && caster == mc.player) {
                mc.gui.setOverlayMessage(Component.translatable("spirit.shazammod." + NAMES[god])
                        .withStyle(style -> style.withColor(TextColor.fromRgb(GodLook.lighten(aura, 0.25))))
                        .withStyle(ChatFormatting.BOLD), false);
            }
        }
    }

    /** Kabut & butiran cahaya di sekitar dewa yang sudah hadir. */
    private static void ambient(ClientLevel level, Ritual r, int god, int t, GodShow.State s) {
        if (!s.visible || s.appear < 0.5f || (t + god) % 3 != 0) {
            return;
        }
        RandomSource rnd = level.random;
        double sc = s.scale;
        double a = rnd.nextDouble() * Math.PI * 2, rr = (0.3 + rnd.nextDouble() * 0.5) * sc;
        Vfx.mote(r.ox + s.x + Math.cos(a) * rr, r.oy + s.y + 0.1, r.oz + s.z + Math.sin(a) * rr, 0, 0.025 + rnd.nextDouble() * 0.02,
                0, GodFigures.AURA[god], 0.12f, 30);
    }

    /** Semua dewa sudah hadir: bersinar bersamaan. */
    private static void chorus(ClientLevel level, Ritual r) {
        for (int i = 0; i < N; i++) {
            double x = r.ox + r.layout.x[i], y = r.oy + r.layout.y[i], z = r.oz + r.layout.z[i];
            double sc = GodFigures.SCALE[i] * r.layout.size;
            Vfx.add(new Fx.Flash(new Vec3(x, y + 1.2 * sc, z), 2.6f, GodFigures.AURA[i], 12, 0.7f));
        }
        play(level, r.ox, r.oy, r.oz, SoundEvents.AMETHYST_BLOCK_RESONATE, 1.6f, 1.0f);
        play(level, r.ox, r.oy, r.oz, SoundEvents.BEACON_ACTIVATE, 0.9f, 1.3f);
    }

    /** Petir mengenai kepalan: semburan cahaya enam warna. */
    private static void strike(ClientLevel level, Vec3 fist) {
        RandomSource rnd = level.random;
        for (int i = 0; i < N; i++) {
            for (int k = 0; k < 10; k++) {
                Vfx.mote(fist.x, fist.y, fist.z, (rnd.nextDouble() - 0.5) * 0.5, (rnd.nextDouble() - 0.3) * 0.4,
                        (rnd.nextDouble() - 0.5) * 0.5, GodFigures.AURA[i], 0.14f, 16 + rnd.nextInt(10));
            }
        }
        for (int k = 0; k < 10; k++) {
            Vfx.glint(fist.x + (rnd.nextDouble() - 0.5) * 1.4, fist.y + (rnd.nextDouble() - 0.5) * 1.4,
                    fist.z + (rnd.nextDouble() - 0.5) * 1.4, 0xFFFFFF, 0.35f, 10 + rnd.nextInt(6));
        }
    }

    private static Vec3 bodyPoint(RandomSource rnd, double x, double y, double z, double sc) {
        double a = rnd.nextDouble() * Math.PI * 2, rr = (0.12 + rnd.nextDouble() * 0.25) * sc;
        return new Vec3(x + Math.cos(a) * rr, y + (0.3 + rnd.nextDouble() * 1.5) * sc, z + Math.sin(a) * rr);
    }

    /** Kira-kira titik perisai Achilles (dari gambar terakhir, atau dari posisinya). */
    private static Vec3 shieldPoint(GodShow.State s, Ritual r) {
        GodMesh m = r.meshes[GodFigures.ACHILLES];
        if (r.seen[GodFigures.ACHILLES]) {
            double[] p = new double[3];
            GodLook.toWorld(s, r.ox, r.oy, r.oz, m.anchor[GodMesh.EXTRA * 3], m.anchor[GodMesh.EXTRA * 3 + 1],
                    m.anchor[GodMesh.EXTRA * 3 + 2], p);
            return new Vec3(p[0], p[1], p[2]);
        }
        return new Vec3(r.ox + s.x, r.oy + s.y + 1.25 * s.scale, r.oz + s.z);
    }

    private static void play(ClientLevel level, double x, double y, double z, SoundEvent sound, float volume, float pitch) {
        level.playLocalSound(x, y, z, sound, SoundSource.PLAYERS, volume, ShazamFx.slowPitch(level, pitch), false);
    }

    // ------------------------------------------------------------------ gambar

    private static final class Item {
        final Ritual ritual;
        final int god;
        final double distance;

        Item(Ritual ritual, int god, double distance) {
            this.ritual = ritual;
            this.god = god;
            this.distance = distance;
        }
    }

    /** Penghubung pernik cahaya ke vfx.Draw. */
    private static final class DrawGlows implements GodLook.Glows {
        Draw d;

        @Override
        public void glow(double x, double y, double z, float radius, int rgb, float a) {
            d.glow(x, y, z, radius, rgb, a);
        }

        @Override
        public void line(double ax, double ay, double az, double bx, double by, double bz, float width, int rgb, float a) {
            d.line(ax, ay, az, bx, by, bz, width, width, rgb, a, a);
        }

        @Override
        public void ring(double cx, double cy, double cz, double nx, double ny, double nz, double radius, double width, int rgb,
                         float a) {
            d.ring(cx, cy, cz, nx, ny, nz, radius, width, rgb, a, 0f, null);
        }

        @Override
        public void disc(double cx, double cy, double cz, double radius, int rgb, float aCenter) {
            d.disc(cx, cy, cz, 0, 1, 0, radius, rgb, aCenter, 0f, null);
        }
    }

    private static final DrawGlows GLOWS = new DrawGlows();
    private static final GodMesh GHOST = new GodMesh();
    private static final GodShow.State GHOST_STATE = new GodShow.State();
    /** Dorongan kedalaman lapis pertama (ruang pandang). */
    private static final float PUSH = 1.0006f;
    private static int[] fill = new int[2048], glow = new int[2048];
    private static float[] wx = new float[2048], wy = new float[2048], wz = new float[2048];
    private static float[] vx = new float[2048], vy = new float[2048], vz = new float[2048];
    private static boolean[] back = new boolean[2048];

    public static void render(RenderLevelStageEvent event) {
        if (RITUALS.isEmpty() || event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) {
            return;
        }
        float pt = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        Vec3 cam = event.getCamera().getPosition();
        PoseStack.Pose pose = event.getPoseStack().last();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();

        // keadaan semua dewa saat ini, digambar dari yang terjauh
        List<Item> items = new ArrayList<>();
        Map<Ritual, Vec3> fists = new HashMap<>();
        for (Ritual r : RITUALS.values()) {
            if (!(level.getEntity(r.caster) instanceof AbstractClientPlayer caster)) {
                continue;
            }
            double t = level.getGameTime() - r.start + pt;
            Vec3 fist = ShazamPoses.handPos(caster, true, pt);
            fists.put(r, fist);
            for (int i = 0; i < N; i++) {
                GodShow.State s = r.states[i];
                GodShow.state(i, t, r.layout, fist.x - r.ox, fist.y - r.oy, fist.z - r.oz, s);
                if (!s.visible) {
                    continue;
                }
                double dx = r.ox + s.x - cam.x, dy = r.oy + s.y + s.scale - cam.y, dz = r.oz + s.z - cam.z;
                double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
                if (d < DRAW_DISTANCE) {
                    items.add(new Item(r, i, d));
                }
            }
        }
        if (items.isEmpty()) {
            return;
        }
        items.sort((a, b) -> Double.compare(b.distance, a.distance));
        for (Item it : items) {
            Ritual r = it.ritual;
            GodShow.State s = r.states[it.god];
            GodMesh m = r.meshes[it.god];
            GodFigures.build(it.god, s.pose, m);
            drawGod(m, s, r, it.god, cam, pose, buffers, s.pose.time);
            GodLook.toWorld(s, r.ox, r.oy, r.oz, m.anchor[0], m.anchor[1], m.anchor[2], r.focus[it.god]);
            r.seen[it.god] = true;
        }

        // pernik cahaya, jejak, bayangan Mercury, sinar ke kepalan
        RenderType additive = Draw.additiveType();
        VertexConsumer add = buffers.getBuffer(additive);
        Draw draw = new Draw(pose, cam, pt);
        draw.begin(add, true);
        GLOWS.d = draw;
        double[] trail = new double[14 * 3];
        for (Item it : items) {
            Ritual r = it.ritual;
            GodShow.State s = r.states[it.god];
            float time = s.pose.time;
            GodMesh m = r.meshes[it.god];
            GodLook.extras(it.god, m, s, r.ox, r.oy, r.oz, cam.x, cam.y, cam.z, time, GLOWS);
            Vec3 fist = fists.get(r);
            if (fist != null) {
                GodLook.beam(it.god, m, s, r.ox, r.oy, r.oz, fist.x, fist.y, fist.z, time, GLOWS);
            }
            if (s.trail > 0.01f) {
                int n = GodShow.trailPoints(it.god, time, r.layout, 3.0, 14, trail, r.tmp);
                for (int k = 0; k < n; k++) {
                    trail[k * 3] += r.ox;
                    trail[k * 3 + 1] += r.oy;
                    trail[k * 3 + 2] += r.oz;
                }
                GodLook.trail(trail, n, (float) (0.55 * s.scale), GodFigures.AURA[it.god], 0.85f * s.trail, GLOWS);
            }
            if (it.god == GodFigures.MERCURY && s.trail > 0.01f) {   // bayangan-bayangan yang tertinggal
                for (int k = 1; k <= 4; k++) {
                    double tk = time - k * 0.7;
                    if (tk < GodShow.start(it.god)) {
                        break;
                    }
                    GodShow.state(it.god, tk, r.layout, 0, 0, 0, GHOST_STATE);
                    GHOST_STATE.mask.boost = 0.8f / k;
                    GodFigures.build(it.god, GHOST_STATE.pose, GHOST);
                    ghost(GHOST, GHOST_STATE, r, it.god, cam, pose, add, time);
                }
            }
        }
        buffers.endBatch(additive);
    }

    /** Satu dewa: kedalaman -> isi tembus pandang -> cahaya tepi. */
    private static void drawGod(GodMesh m, GodShow.State s, Ritual r, int god, Vec3 cam, PoseStack.Pose pose,
                                MultiBufferSource.BufferSource buffers, float time) {
        prepare(m, s, r, god, cam, pose, time);
        int quads = m.quadCount;
        int[] q = m.quads;
        // 1) kedalaman saja (sedikit didorong menjauh supaya isi selalu lolos uji kedalaman)
        RenderType depth = RenderType.waterMask();
        VertexConsumer vc = buffers.getBuffer(depth);
        for (int k = 0; k < quads; k++) {
            int o = k * 4;
            if (back[k] || maxAlpha(q, o) < 26) {
                continue;
            }
            for (int j = 0; j < 4; j++) {
                int v = q[o + j];
                vc.addVertex(vx[v] * PUSH, vy[v] * PUSH, vz[v] * PUSH);
            }
        }
        buffers.endBatch(depth);
        // 2) isi tembus pandang
        RenderType body = RenderType.entityTranslucentEmissive(WHITE);
        vc = buffers.getBuffer(body);
        for (int k = 0; k < quads; k++) {
            int o = k * 4;
            if (back[k] || maxAlpha(q, o) < 26) {
                continue;
            }
            for (int j = 0; j < 4; j++) {
                int v = q[o + j];
                vc.addVertex(vx[v], vy[v], vz[v], fill[v], 0.5f, 0.5f, OverlayTexture.NO_OVERLAY, LightTexture.FULL_BRIGHT,
                        0f, 1f, 0f);
            }
        }
        buffers.endBatch(body);
        // 3) cahaya tepi (aditif)
        RenderType additive = Draw.additiveType();
        vc = buffers.getBuffer(additive);
        emitGlow(vc, q, quads);
        buffers.endBatch(additive);
    }

    /** Bayangan Mercury: cuma cahaya tepinya. */
    private static void ghost(GodMesh m, GodShow.State s, Ritual r, int god, Vec3 cam, PoseStack.Pose pose, VertexConsumer vc,
                              float time) {
        prepare(m, s, r, god, cam, pose, time);
        emitGlow(vc, m.quads, m.quadCount);
    }

    private static void emitGlow(VertexConsumer vc, int[] q, int quads) {
        for (int k = 0; k < quads; k++) {
            int o = k * 4;
            if (back[k]) {
                continue;
            }
            int g0 = glow[q[o]], g1 = glow[q[o + 1]], g2 = glow[q[o + 2]], g3 = glow[q[o + 3]];
            if (((g0 | g1 | g2 | g3) & 0xF0F0F0) == 0) {
                continue;   // hampir gelap: lewati
            }
            for (int j = 0; j < 4; j++) {
                int v = q[o + j];
                vc.addVertex(vx[v], vy[v], vz[v], 0xFF000000 | glow[v], 0.5f, 0.5f, OverlayTexture.NO_OVERLAY,
                        LightTexture.FULL_BRIGHT, 0f, 1f, 0f);
            }
        }
    }

    /**
     * Warna tiap titik (GodLook), posisinya di ruang pandang kamera (sudah dikali matriks pose, jadi tiap titik cuma
     * diubah sekali untuk ketiga lapis), dan sisi mana yang membelakangi kamera (dibuang di semua lapis).
     */
    private static void prepare(GodMesh m, GodShow.State s, Ritual r, int god, Vec3 cam, PoseStack.Pose pose, float time) {
        int n = m.verts;
        if (fill.length < n) {
            int size = Math.max(n, fill.length * 2);
            fill = new int[size];
            glow = new int[size];
            vx = new float[size];
            vy = new float[size];
            vz = new float[size];
            wx = new float[size];
            wy = new float[size];
            wz = new float[size];
        }
        if (back.length < m.quadCount) {
            back = new boolean[Math.max(m.quadCount, back.length * 2)];
        }
        double[] local = new double[3];
        GodLook.toLocal(s, r.ox, r.oy, r.oz, cam.x, cam.y, cam.z, local);
        GodLook.shade(m, local[0], local[1], local[2], GodFigures.AURA[god], s.mask, time, fill, glow);
        double c = Math.cos(s.yaw), sn = Math.sin(s.yaw), sc = s.scale;
        double bx = r.ox + s.x - cam.x, by = r.oy + s.y - cam.y, bz = r.oz + s.z - cam.z;
        Matrix4f mat = pose.pose();
        Vector3f t = new Vector3f();
        for (int i = 0; i < n; i++) {
            double x = m.x[i], z = m.z[i];
            float px = (float) (bx + sc * (x * c + z * sn));
            float py = (float) (by + sc * m.y[i]);
            float pz = (float) (bz + sc * (-x * sn + z * c));
            wx[i] = px;
            wy[i] = py;
            wz[i] = pz;
            mat.transformPosition(px, py, pz, t);
            vx[i] = t.x;
            vy[i] = t.y;
            vz[i] = t.z;
        }
        int[] q = m.quads;
        for (int k = 0; k < m.quadCount; k++) {
            back[k] = backFacing(m, q, k * 4, c, sn);
        }
    }

    /** Sisi menghadap menjauhi kamera? (rata-rata normal titik-titiknya vs arah dari kamera). */
    private static boolean backFacing(GodMesh m, int[] q, int o, double c, double sn) {
        double nx = 0, ny = 0, nz = 0, px = 0, py = 0, pz = 0;
        for (int j = 0; j < 4; j++) {
            int v = q[o + j];
            nx += m.nx[v];
            ny += m.ny[v];
            nz += m.nz[v];
            px += wx[v];
            py += wy[v];
            pz += wz[v];
        }
        double wnx = nx * c + nz * sn, wnz = -nx * sn + nz * c;
        return wnx * px + ny * py + wnz * pz > 0.0;
    }

    private static int maxAlpha(int[] q, int o) {
        int a = fill[q[o]] >>> 24;
        a = Math.max(a, fill[q[o + 1]] >>> 24);
        a = Math.max(a, fill[q[o + 2]] >>> 24);
        return Math.max(a, fill[q[o + 3]] >>> 24);
    }
}
