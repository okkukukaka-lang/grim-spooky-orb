package com.shazammod.client.fx;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.shazammod.LintangSkills;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamSounds;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * 0.35 Efek Lintang ala Superman: TANPA unsur sihir. Nggak ada tiang cahaya dari langit, sinar dewa, korona, tombak
 * cahaya, perisai cahaya, atau butiran berkilau. Semua yang terlihat adalah fisika: udara terdorong (gelombang kejut,
 * riak, uap kondensasi), debu, puing, retakan tanah, sisa gerak secepat kilat (motion blur), sinar panas mata yang
 * merah membara, embun beku dari napas, dan panas yang membakar. Semua dipicu animasi dari server (ShazamAnim.LINTANG_*).
 */
public final class LintangFx {
    /** 0.33: penguat sinematik semua efek Lintang (bloom + butiran lebih padat/besar/lama, lihat Vfx). */
    public static final float BOOST = 1.5f;

    private LintangFx() {}

    // ======= Warna (RGB) =======
    public static final int SUN = 0xFFD878;          // matahari keemasan (dipakai lapisan lain sebagai warna Lintang)
    public static final int SUN_HOT = 0xFFF6DC;      // putih panas
    public static final int AMBER = 0xFFA640;
    public static final int STAR = 0xBFE4FF;
    public static final int FROST = 0xCFF4FF;        // embun beku
    public static final int FROST_DEEP = 0x7FD0FF;
    public static final int KELAM = 0x8A3CC8;        // Batu Cryon
    public static final int KELAM_DARK = 0x1C0A2A;
    // 0.35 warna fisik
    public static final int HEAT = 0xFF3A16;         // sinar panas mata: merah membara
    public static final int HEAT_MID = 0xFF8A3A;
    public static final int HEAT_CORE = 0xFFEDE0;    // inti putih panas
    public static final int AIR = 0xF2F6FA;          // udara terkompresi / uap kondensasi
    public static final int AIR_DIM = 0xC8D2DC;
    public static final int DUST = 0xB8AA94;         // debu (kalau warna tanah nggak terbaca)
    private static final Vec3 UP = new Vec3(0, 1, 0);

    private static final Map<Integer, long[]> EYES = new HashMap<>();        // Iris Surya: {mulai, selesai}
    private static final Map<Integer, IceShell> ICE = new HashMap<>();       // 0.36 patung es per makhluk
    public static final int ICE_FACE = 0xCDEEFF;     // es bening kebiruan
    public static final int ICE_EDGE = 0xF6FCFF;
    public static final int ICE_SHARD = 0xBFE9FF;

    public static void clear() {
        EYES.clear();
        ICE.clear();
    }

    /** Animasi ini diurus LintangFx (ShazamFx & ChampionFx melewatinya). */
    public static boolean handles(AbstractClientPlayer caster, ShazamAnim anim) {
        return switch (anim) {
            case SUMMON, TRANSFORM, REVERT, KNOCKOUT, LAUNCH, LAND_HERO, CRASH, SONIC_BOOM, HERO_CALL, HERCULES_THROW,
                    HERCULES_IMPACT -> ShazamClientState.isLintang(caster.getId());   // 0.36: Angkat & Lempar Lintang
            default -> anim.name().startsWith("LINTANG_");
        };
    }

    public static void onAnim(AbstractClientPlayer caster, ShazamAnim anim, Vec3 pos) {
        float boostOld = Vfx.setBoost(BOOST);
        try {
            onAnim0(caster, anim, pos);
        } finally {
            Vfx.setBoost(boostOld);
        }
    }

    private static void onAnim0(AbstractClientPlayer caster, ShazamAnim anim, Vec3 pos) {
        if (!handles(caster, anim)) {
            return;
        }
        boolean self = caster == Minecraft.getInstance().player;
        switch (anim) {
            case SUMMON -> { }   // 0.35: Lintang nggak memanggil apa pun (server juga nggak mengirimnya lagi)
            case TRANSFORM -> suitUp(caster, self);
            case REVERT -> suitDown(caster, self);
            case KNOCKOUT -> knockout(caster, self);
            case LAUNCH -> launch(caster);
            case LAND_HERO -> landing(caster, self, false);
            case CRASH -> landing(caster, self, true);
            case SONIC_BOOM -> sonicBoom(caster, self);
            case HERO_CALL -> hear(pos);
            case LINTANG_DASH -> dash(caster, pos, self);
            case LINTANG_EYES -> eyes(caster, self);
            case LINTANG_BREATH -> breath(caster, self);
            case LINTANG_CLAP -> clap(caster, self);
            case LINTANG_BARRAGE -> barrage(caster, self);
            case LINTANG_HIT -> hit(caster, pos);
            case LINTANG_LEAP -> leap(caster);
            case LINTANG_SLAM -> slam(caster, pos, self);
            case LINTANG_FLARE -> flare(caster, self);
            case LINTANG_CALL -> call(caster, self);
            case LINTANG_RESCUE -> rescue(caster, self);
            case LINTANG_SAVE -> save(caster, pos);
            case LINTANG_LANCE -> heatZap(caster, pos);
            case LINTANG_PULSE -> { }   // Regenerasi Surya: sel tubuhnya menyerap sinar matahari tanpa terlihat
            case LINTANG_DAWNPUNCH -> steelPunch(caster, pos, self);
            case LINTANG_PARRY -> parry(caster, pos);
            case LINTANG_BOUNCE -> bounce(pos);
            case LINTANG_PUNCH -> punch(pos);
            case LINTANG_FADE -> { }    // melemah: cuma gerak badannya (LintangBody), tanpa asap/butiran
            case LINTANG_RETURN -> strengthBack(caster);
            case LINTANG_KELAM -> kelam(self);
            case LINTANG_RITE -> { }    // eksperimen evolusi diurus LintangCine (nggak lewat sini)
            case HERCULES_THROW -> liftThrow(caster, pos, self);   // 0.36 Angkat & Lempar (Shift + X)
            case HERCULES_IMPACT -> flungImpact(pos, self);
            case LINTANG_ICE -> encase(caster, pos);                // 0.36 patung es
            case LINTANG_ICE_BREAK -> shatter(pos);
            case LINTANG_GUST -> gale(caster, self);                 // 0.37 Napas Topan
            case LINTANG_COMBO -> comboDash(caster, pos, self);       // 0.37 Kombo Langit
            case LINTANG_COMBO_RISE -> comboRise(caster, pos);
            case LINTANG_COMBO_SMASH -> comboSmash(caster, self);
            case LINTANG_NOVA -> nova(caster, self);                  // 0.37 Ledakan Surya
            default -> { }
        }
    }

    // ------------------------------------------------------------------ dibaca lapisan lain

    /** 0-1: mata memanas & menyala merah selama Iris Surya (ShazamEyesLayer). */
    public static float eyeGlow(AbstractClientPlayer player, float partialTick) {
        long[] e = EYES.get(player.getId());
        if (e == null) {
            return 0f;
        }
        float now = player.level().getGameTime() + partialTick;
        if (now < e[0]) {
            return 0f;
        }
        return Mth.clamp((now - e[0]) / 4f, 0f, 1f) * Mth.clamp((e[1] - now) / 6f, 0f, 1f);
    }

    // ------------------------------------------------------------------ tiap tick

    public static void tick(ClientLevel level) {
        long now = level.getGameTime();
        EYES.entrySet().removeIf(e -> now > e.getValue()[1] + 2);
        ICE.values().removeIf(IceShell::done);
        dogTrails(level);   // 0.36 anjing super: jejak uap saat melesat & terbang
        // 0.35: nggak ada aura. Siang, malam, atau Mode Surya, badan Lintang nggak berkilau; yang terlihat cuma kostum,
        // jubah, dan mata yang menyala merah saat sinar panas. Batu Cryon terlihat dari urat di kulitnya (CryonSkinLayer).
    }

    /** Muatan penuh (dari ChampionFx): kepalan yang panas, udara di sekitarnya beriak & sesekali mengepulkan uap tipis. */
    static void chargedFists(ClientLevel level, AbstractClientPlayer p) {
        float boostOld = Vfx.setBoost(BOOST);
        try {
            chargedFists0(level, p);
        } finally {
            Vfx.setBoost(boostOld);
        }
    }

    private static void chargedFists0(ClientLevel level, AbstractClientPlayer p) {
        if (p.tickCount % 4 != 0 || firstPerson(p)) {
            return;
        }
        RandomSource r = level.random;
        Vec3 h = ShazamPoses.handPos(p, r.nextBoolean(), 1f);
        Vfx.smoke(h.x, h.y, h.z, (r.nextDouble() - 0.5) * 0.02, 0.025, (r.nextDouble() - 0.5) * 0.02, 0xD8D4CE,
                0.16f + r.nextFloat() * 0.08f, 12);
    }

    /** Jejak terbang (dari ShazamFx.flightTrail): uap kondensasi tipis dari tangan & badan saat melesat. */
    static void flightGlints(ClientLevel level, AbstractClientPlayer player, float speed) {
        float boostOld = Vfx.setBoost(BOOST);
        try {
            flightGlints0(level, player, speed);
        } finally {
            Vfx.setBoost(boostOld);
        }
    }

    private static void flightGlints0(ClientLevel level, AbstractClientPlayer player, float speed) {
        if (speed < 0.9f || player.isInvisible()) {
            return;
        }
        Vec3 motion = new Vec3(player.getX() - player.xo, player.getY() - player.yo, player.getZ() - player.zo);
        if (motion.lengthSqr() < 1.0E-4) {
            return;
        }
        RandomSource r = level.random;
        Vec3 back = motion.normalize().scale(-1);
        float k = Mth.clamp((speed - 0.9f) / 1.6f, 0f, 1f);
        if (r.nextInt(2) == 0) {   // uap di belakang badan, makin cepat makin tebal
            Vec3 p = player.position().add(0, 0.9 * player.getScale(), 0).add(back.scale(0.8 + r.nextDouble() * 0.6))
                    .add(ShazamFx.randomDir(r).scale(0.25));
            Vfx.smoke(p.x, p.y, p.z, back.x * 0.04, back.y * 0.04, back.z * 0.04, AIR, 0.28f + 0.3f * k, 10 + r.nextInt(6));
        }
        if (k > 0.3f && player.tickCount % 2 == 0) {   // ujung kepalan membelah udara: garis uap tipis
            Vec3 h = ShazamPoses.handPos(player, r.nextBoolean(), 1f);
            Vfx.dust(h.x, h.y, h.z, back.x * 0.08, back.y * 0.08, back.z * 0.08, AIR, 0.18f, 8);
        }
        Vec3 c = player.position().add(0, 0.9 * player.getScale(), 0);
        if (k > 0.55f && player.tickCount % 5 == 0) {   // 0.38: garis angin yang tertinggal di belakang saat ngebut
            LintangFilm.windStreaks(c.subtract(back.scale(2.0)), c.add(back.scale(6.0)), 8, 6);
        }
        if (k > 0.35f && player.tickCount % 2 == 0) {   // 0.38: terbang rendah & cepat: debu tanah tersibak ke samping
            BlockHitResult hit = level.clip(new ClipContext(c, c.subtract(0, 4.0, 0), ClipContext.Block.COLLIDER,
                    ClipContext.Fluid.ANY, player));
            if (hit.getType() != HitResult.Type.MISS) {
                Vec3 g = hit.getLocation();
                Vec3 side = new Vec3(-back.z, 0, back.x);
                side = side.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : side.normalize();
                double near = 1.0 - (c.y - g.y) / 4.0;
                for (int i = 0, n = Vfx.count(2 + 3 * near); i < n; i++) {
                    double sd = r.nextBoolean() ? 1 : -1;
                    Vfx.dust(g.x + side.x * sd * 0.4, g.y + 0.1, g.z + side.z * sd * 0.4, side.x * sd * 0.22 + back.x * 0.08, 0.05,
                            side.z * sd * 0.22 + back.z * 0.08, DUST, 0.4f + r.nextFloat() * 0.3f, 16 + r.nextInt(6));
                }
            }
        }
    }

    // ------------------------------------------------------------------ alat bantu

    private static void schedule(int delay, int duration, ShazamFx.Step step) {
        ShazamFx.schedule(delay, duration, step);
    }

    private static void sound(ClientLevel level, Vec3 at, SoundEvent sound, float volume, float pitch) {
        level.playLocalSound(at.x, at.y, at.z, sound, SoundSource.PLAYERS, volume, ShazamFx.slowPitch(level, pitch), false);
    }

    private static boolean firstPerson(AbstractClientPlayer player) {
        Minecraft mc = Minecraft.getInstance();
        return player == mc.player && mc.options.getCameraType().isFirstPerson();
    }

    private static Vec3 chest(AbstractClientPlayer player) {
        return player.position().add(0, 1.2 * player.getScale(), 0);
    }

    private static Vec3 mouth(AbstractClientPlayer p, float pt) {
        return p.getEyePosition(pt).add(0, -0.15 * p.getScale(), 0).add(p.getViewVector(pt).scale(firstPerson(p) ? 0.8 : 0.3));
    }

    /** 0.37: ada tanah tepat di bawah kaki (dalam depth blok)? */
    private static boolean nearGround(ClientLevel level, AbstractClientPlayer p, double depth) {
        Vec3 f = p.position();
        return level.clip(new ClipContext(f.add(0, 0.2, 0), f.subtract(0, depth, 0), ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, p)).getType() != HitResult.Type.MISS;
    }

    private static Vec3 flat(Vec3 v) {
        Vec3 f = new Vec3(v.x, 0, v.z);
        return f.lengthSqr() < 1.0E-6 ? new Vec3(0, 0, 1) : f.normalize();
    }

    /** Gelombang udara: cincin uap tipis yang mengembang (lapisan soft, bukan cahaya) + riak samar di dalamnya. */
    private static void airShock(Vec3 at, Vec3 normal, double radius, int life, float strength) {
        Vfx.add(new Fx.Wave(at, normal, radius, Math.max(0.15, radius * 0.06), AIR, life, strength * 0.55f, 0.03f, null, true));
        Vfx.add(new Fx.Ripple(at, normal, 0.0, radius * 0.12, radius * 0.8, Math.max(0.08, radius * 0.035), AIR_DIM, life,
                strength * 0.35f, true));
    }

    /**
     * Hantaman ke tanah tanpa cahaya: cincin & dinding debu, retakan, puing yang terlempar (blok tanah aslinya), dan asap
     * tanah yang mengepul. size kira-kira 1 (mendarat) sampai 3 (hantaman besar).
     */
    private static void groundHit(ClientLevel level, Vec3 at, double size, boolean debris) {
        Ground.Map map = ShazamFx.ground(level, at, 2.5 + size * 2.2);
        if (map == null) {
            return;
        }
        Vec3 g = map.center(at);
        int dust = map.found ? map.dustColor(level, at) : DUST;
        Vfx.add(new Fx.Wave(g, UP, 2.0 + size * 2.0, 0.9 + size * 0.3, dust, 26, 0.6f, 0f, map, true));
        Vfx.add(new Fx.Wave(g, UP, 2.6 + size * 2.4, 0.3 + size * 0.1, AIR, 12, 0.4f, 0f, map, true));
        if (map.found) {
            Vfx.add(new Ground.Cracks(g, map, 6 + (int) (size * 3.0), (float) (1.2 + size * 1.2), 160, 1, 0x3A3028,
                    level.random.nextLong()));
            if (debris) {
                Vfx.add(new Ground.Debris(g, map, 6 + (int) (size * 6.0), 0.12 + size * 0.08, 0.3 + size * 0.12,
                        0.5 + size * 0.3, 50));
            }
        }
        ShazamFx.dustPuffs(level, g, dust, (int) (8 + size * 8), 0.6 + size * 0.5, 0.1 + size * 0.05);
        ShazamFx.smokeCloud(level, g, dust, (int) (4 + size * 4), 0.7 + size * 0.7);
    }

    /** Debu & udara yang berputar kencang di sekeliling badan (putaran secepat kilat). */
    private static void whirl(ClientLevel level, AbstractClientPlayer p, int t, float strength) {
        RandomSource r = level.random;
        double sc = p.getScale();
        boolean grounded = p.onGround();
        Ground.Map map = grounded && t % 4 == 0 ? ShazamFx.ground(level, p.position(), 2.5) : null;
        int dust = map != null && map.found ? map.dustColor(level, p.position()) : DUST;
        for (int i = 0, n = Vfx.count(3 * strength); i < n; i++) {
            double a = r.nextDouble() * Math.PI * 2.0, rr = (0.7 + r.nextDouble() * 0.9) * sc;
            double y = grounded ? 0.1 + r.nextDouble() * 0.4 : r.nextDouble() * 1.8 * sc;
            double tang = 0.28 + r.nextDouble() * 0.12;
            Vfx.dust(p.getX() + Math.cos(a) * rr, p.getY() + y, p.getZ() + Math.sin(a) * rr, -Math.sin(a) * tang,
                    0.02 + r.nextDouble() * 0.04, Math.cos(a) * tang, grounded ? dust : AIR, 0.35f + r.nextFloat() * 0.3f,
                    10 + r.nextInt(6));
        }
        if (t % 2 == 0) {   // sapuan udara setinggi badan
            double a = r.nextDouble() * Math.PI * 2.0;
            Vfx.smoke(p.getX() + Math.cos(a) * 0.55 * sc, p.getY() + (0.3 + r.nextDouble() * 1.4) * sc,
                    p.getZ() + Math.sin(a) * 0.55 * sc, -Math.sin(a) * 0.3, 0.01, Math.cos(a) * 0.3, AIR, 0.3f * strength, 7);
        }
    }

    // ------------------------------------------------------------------ efek khusus

    /** Iris Surya: sinar panas dari kedua mata, mengikuti arah pandang, berhenti di blok atau makhluk pertama. */
    static final class EyeBeams extends Effect {
        private final AbstractClientPlayer owner;
        private Vec3 end;
        private boolean blockHit;

        EyeBeams(AbstractClientPlayer owner) {
            super(ShazamAnim.IRIS_WINDUP + ShazamAnim.IRIS_TICKS + 3);
            this.owner = owner;
        }

        private boolean firing() {
            return age >= ShazamAnim.IRIS_WINDUP && age < ShazamAnim.IRIS_WINDUP + ShazamAnim.IRIS_TICKS;
        }

        private boolean tick0(ClientLevel level) {
            if (!owner.isAlive() || !ShazamClientState.isTransformed(owner.getId())) {
                return false;
            }
            if (firing()) {
                aim(level);
                RandomSource r = level.random;
                for (int i = 0, n = Vfx.count(5); i < n; i++) {   // percikan lelehan di titik kena
                    Vec3 v = ShazamFx.randomDir(r).scale(0.12 + r.nextDouble() * 0.14);
                    Vfx.spark(end.x, end.y, end.z, v.x, Math.abs(v.y) + 0.05, v.z, i % 2 == 0 ? HEAT_CORE : HEAT_MID, 0.05f,
                            8 + r.nextInt(6), end.y - 2.0);
                }
                if (age % 3 == 0) {
                    Vfx.smoke(end.x, end.y, end.z, 0, 0.03, 0, 0x2A2420, 0.35f, 26);
                }
                if (blockHit && age % 3 == 0) {   // 0.38: jejak hangus menyambung di sepanjang sapuan sinar
                    Ground.Map map = ShazamFx.ground(level, end, 1.2);
                    if (map != null && map.found && Math.abs(map.centerY - end.y) < 1.0) {
                        Vfx.add(new Fx.Scorch(map.center(end), 0.45, 120, 40, map));
                    }
                }
            }
            return super.tick(level);
        }

        private void aim(ClientLevel level) {
            Vec3 eye = owner.getEyePosition(1f);
            Vec3 look = owner.getViewVector(1f);
            BlockHitResult hit = level.clip(new ClipContext(eye, eye.add(look.scale(LintangSkills.IRIS_RANGE)),
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, owner));
            blockHit = hit.getType() != HitResult.Type.MISS;
            double reach = blockHit ? hit.getLocation().distanceTo(eye) : LintangSkills.IRIS_RANGE;
            double best = reach;
            List<LivingEntity> near = level.getEntitiesOfClass(LivingEntity.class,
                    new AABB(eye, eye.add(look.scale(reach))).inflate(1.0), e -> e != owner && e.isAlive());
            for (LivingEntity e : near) {
                AABB box = e.getBoundingBox().inflate(0.2);
                for (double s = 0.5; s < best; s += 0.5) {
                    if (box.contains(eye.add(look.scale(s)))) {
                        best = s;
                        break;
                    }
                }
            }
            if (best < reach) {
                blockHit = false;
            }
            end = eye.add(look.scale(best));
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float time = age + pt;
            float w = ShazamAnim.IRIS_WINDUP;
            boolean fp = firstPerson(owner);
            Vec3[] eyes = eyePair(owner, pt, fp);
            Vec3 eyeR = eyes[0], eyeL = eyes[1];
            double sc = owner.getScale();
            if (time < w) {   // mata memanas dulu: merah membara makin terang, kilau lensa tipis di mata
                float charge = Mth.clamp(time / w, 0f, 1f);
                if (!fp) {
                    for (Vec3 e : eyes) {
                        d.flare(e.x, e.y, e.z, (0.1f + 0.14f * charge) * (float) sc, HEAT, charge);
                        eyeStreak(d, e, owner, pt, 0.35f * charge * (float) sc, charge * 0.6f);
                    }
                }
                return;
            }
            float left = w + ShazamAnim.IRIS_TICKS - time;
            float a = Mth.clamp(left / 3f, 0f, 1f) * (0.88f + 0.12f * Mth.sin(time * 2.7f));
            if (end == null || a <= 0.01f) {
                return;
            }
            // 0.38 sinar sinematik: lebih tebal, inti putih panas, pendar merah lebar, berdenyut pelan
            float width = (fp ? 0.085f : 0.13f) * (float) sc;
            float pulse = 1f + 0.08f * Mth.sin(time * 5.3f);
            for (Vec3 e : new Vec3[] {eyeR, eyeL}) {
                d.beam(e.x, e.y, e.z, end.x, end.y, end.z, width * pulse, HEAT, HEAT_CORE, a * 0.95f, a);
                d.beam(e.x, e.y, e.z, end.x, end.y, end.z, width * 3.0f, HEAT, HEAT_MID, a * 0.2f, a * 0.28f);
                if (!fp) {
                    d.flare(e.x, e.y, e.z, 0.24f * (float) sc, HEAT, a);
                    eyeStreak(d, e, owner, pt, 0.6f * (float) sc, a * 0.7f);
                }
            }
            float flick = 0.8f + 0.2f * Mth.sin(time * 3.1f);
            d.flare(end.x, end.y, end.z, 0.6f * flick, HEAT_MID, a);   // titik leleh
            float old = d.body(0.4f);
            d.glow(end.x, end.y, end.z, 1.8f, HEAT, a * 0.4f);
            d.body(old);
            d.glow(end.x, end.y, end.z, width * 10f * flick, HEAT, a * 0.5f);
            d.glow(end.x, end.y, end.z, width * 3.4f, 0xFFFFFF, a * 0.9f);
        }

        /** 0.38: riak udara panas di sekeliling sinar: dua garis bergelombang tipis yang tembus pandang. */
        @Override
        public void renderSoft(Draw d) {
            if (end == null || !firing()) {
                return;
            }
            float pt = d.partialTick, time = age + pt;
            Vec3[] eyes = eyePair(owner, pt, firstPerson(owner));
            Vec3 mid = eyes[0].add(eyes[1]).scale(0.5);
            Vec3 dir = end.subtract(mid);
            double len = dir.length();
            if (len < 0.8) {
                return;
            }
            dir = dir.scale(1.0 / len);
            Vec3 side = dir.cross(UP);
            side = side.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : side.normalize();
            Vec3 up2 = side.cross(dir).normalize();
            int segs = 18;
            for (int k = 0; k < 2; k++) {
                double phase = time * 0.9 + k * 2.1, amp = 0.09 + 0.04 * k;
                Vec3 axis = k == 0 ? side : up2;
                Vec3 prev = null;
                for (int i = 0; i <= segs; i++) {
                    double u = i / (double) segs, s0 = u * len;
                    double wob = Math.sin(u * 22.0 - phase * 3.0) * amp * Math.min(1.0, s0 / 1.5);
                    Vec3 q = mid.add(dir.scale(s0)).add(axis.scale(wob + (k == 0 ? 0.17 : -0.17)));
                    if (prev != null) {
                        d.line(prev.x, prev.y, prev.z, q.x, q.y, q.z, 0.03f, 0.03f, 0xFFF4EC, 0.12f, 0.12f);
                    }
                    prev = q;
                }
            }
        }

        @Override
        public boolean tick(ClientLevel level) {
            boolean ok = tick0(level);
            if (ok && firing() && end != null && boost > 1.001f) {   // HD: api kecil dari benda yang terbakar sinar
                float old = Vfx.setBoost(boost);
                try {
                    RandomSource r = level.random;
                    Vfx.flame(end.x, end.y, end.z, (r.nextDouble() - 0.5) * 0.04, 0.04, (r.nextDouble() - 0.5) * 0.04, HEAT_MID,
                            0.14f, 10);
                } finally {
                    Vfx.setBoost(old);
                }
            }
            return ok;
        }
    }

    /** 0.38: kilau lensa horizontal tipis di mata yang memanas (ala film), meruncing ke kedua ujung. */
    static void eyeStreak(Draw d, Vec3 e, AbstractClientPlayer owner, float pt, float len, float a) {
        if (a <= 0.01f) {
            return;
        }
        float yaw = owner.getViewYRot(pt) * Mth.DEG_TO_RAD;
        double rx = -Math.cos(yaw) * len, rz = -Math.sin(yaw) * len;
        d.line(e.x, e.y, e.z, e.x + rx, e.y, e.z + rz, 0.022f, 0f, HEAT_MID, a * 0.7f, 0f);
        d.line(e.x, e.y, e.z, e.x - rx, e.y, e.z - rz, 0.022f, 0f, HEAT_MID, a * 0.7f, 0f);
    }

    /** Posisi kedua mata (kanan, kiri), sedikit di depan wajah. */
    static Vec3[] eyePair(AbstractClientPlayer owner, float pt, boolean fp) {
        Vec3 eye = owner.getEyePosition(pt);
        Vec3 look = owner.getViewVector(pt);
        float yaw = owner.getViewYRot(pt) * Mth.DEG_TO_RAD;
        double sc = owner.getScale();
        Vec3 right = new Vec3(-Math.cos(yaw), 0, -Math.sin(yaw)).scale(0.11 * sc);
        Vec3 forward = look.scale(fp ? 0.9 : 0.22 * sc);
        return new Vec3[] {eye.add(right).add(forward), eye.subtract(right).add(forward)};
    }

    /** Sorotan sinar panas singkat dari kedua mata ke satu titik (Mode Surya & sasaran tambahan). */
    static final class HeatZap extends Effect {
        private final AbstractClientPlayer owner;
        private final Vec3 target;

        HeatZap(AbstractClientPlayer owner, Vec3 target) {
            super(7);
            this.owner = owner;
            this.target = target;
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float t = progress(pt);
            float a = (t < 0.15f ? t / 0.15f : 1f) * (1f - t * t);
            if (a <= 0.01f || !owner.isAlive()) {
                return;
            }
            boolean fp = firstPerson(owner);
            Vec3[] eyes = eyePair(owner, pt, fp);
            float width = (fp ? 0.07f : 0.11f) * (float) owner.getScale();
            for (Vec3 e : eyes) {
                d.beam(e.x, e.y, e.z, target.x, target.y, target.z, width, HEAT, HEAT_CORE, a * 0.9f, a);
                d.beam(e.x, e.y, e.z, target.x, target.y, target.z, width * 3.0f, HEAT, HEAT_MID, a * 0.2f, a * 0.28f);
                if (!fp) {
                    d.flare(e.x, e.y, e.z, 0.2f, HEAT, a);
                    eyeStreak(d, e, owner, pt, 0.45f, a * 0.6f);
                }
            }
            d.flare(target.x, target.y, target.z, 0.5f, HEAT_MID, a);
            d.glow(target.x, target.y, target.z, 1.3f, HEAT, a * 0.45f);
        }
    }

    // ------------------------------------------------------------------ ganti kostum (berubah wujud)

    /**
     * Ganti kostum secepat kilat (klip Lintang TRANSFORM): kemeja dirobek di tick LINTANG_RIP (serat kain beterbangan),
     * badan berputar dua kali dengan debu & udara yang ikut berpusar (sisa geraknya terlihat sebagai bayangan kabur),
     * lalu di tick LINTANG_SUITUP udara yang terdorong putarannya meledak ke luar sebagai gelombang kejut.
     */
    private static void suitUp(AbstractClientPlayer caster, boolean self) {
        int rip = ShazamAnim.LINTANG_RIP, suit = ShazamAnim.LINTANG_SUITUP;
        schedule(rip, 1, (level, t) -> {
            Vec3 c = chest(caster);
            Vec3 look = flat(caster.getViewVector(1f));
            sound(level, c, ShazamSounds.CAPE_SNAP.get(), 1.1f, 1.45f);   // kain robek
            RandomSource r = level.random;
            for (int i = 0, n = Vfx.count(12); i < n; i++) {   // serpihan kain kemeja terlempar ke samping
                double side = r.nextBoolean() ? 1 : -1;
                Vec3 v = new Vec3(-look.z * side, 0.05 + r.nextDouble() * 0.1, look.x * side).scale(0.14 + r.nextDouble() * 0.12)
                        .add(look.scale(0.06));
                Vfx.dust(c.x, c.y, c.z, v.x, v.y, v.z, 0xE4E0DA, 0.12f + r.nextFloat() * 0.12f, 14 + r.nextInt(6));
            }
        });
        schedule(rip + 2, suit - rip - 1, (level, t) -> {   // putaran secepat kilat
            whirl(level, caster, t, 1.6f);
            if (t == 0) {
                ShazamPoses.ghostBurst(caster, suit - rip + 2);
            }
        });
        schedule(suit, 1, (level, t) -> {   // udara yang terdorong putaran meledak keluar (dinding debu: LintangCine)
            Vec3 c = chest(caster);
            LintangFilm.shockwave(c, UP, 7.5, 16, 1f);
            LintangFilm.shockwave(c.add(0, -0.5, 0), UP, 4.5, 11, 0.8f);
            RandomSource r = level.random;
            for (int i = 0, n = Vfx.count(18); i < n; i++) {   // uap terlempar ke segala arah setinggi badan
                double a = r.nextDouble() * Math.PI * 2.0;
                Vfx.smoke(c.x + Math.cos(a) * 0.6, c.y + (r.nextDouble() - 0.5) * 1.4, c.z + Math.sin(a) * 0.6,
                        Math.cos(a) * 0.42, 0.02, Math.sin(a) * 0.42, AIR, 0.45f + r.nextFloat() * 0.35f, 13);
            }
            if (caster.onGround()) {
                ShazamFx.dustPuffs(level, caster.position(), DUST, 14, 1.3, 0.22);
            }
            if (self) {
                CameraShake.add(0.5f);
                FovKick.punch(0.4f);
            } else {
                ShazamFx.shakeAround(c, 0.4f, 18);
            }
        });
    }

    /** Kembali jadi manusia: berputar secepat kilat lagi (kostum & jubah lepas di tick REVERT_WINDUP). */
    private static void suitDown(AbstractClientPlayer caster, boolean self) {
        int back = ShazamAnim.REVERT_WINDUP;
        schedule(1, back + 1, (level, t) -> {
            whirl(level, caster, t, 1.0f);
            if (t == 0) {
                ShazamPoses.ghostBurst(caster, back + 3);
            }
        });
        schedule(back, 1, (level, t) -> {
            airShock(chest(caster), UP, 3.0, 9, 0.6f);
            ShazamFx.dustPuffs(level, caster.position(), DUST, 8, 0.9, 0.1);
        });
    }

    /** Terhantam sampai lepas wujud: terlempar, debu & puing di tempatnya jatuh (tanpa cahaya yang keluar dari dada). */
    private static void knockout(AbstractClientPlayer caster, boolean self) {
        schedule(0, 1, (level, t) -> {
            Vec3 c = chest(caster);
            airShock(c, UP, 3.2, 10, 0.7f);
            groundHit(level, caster.position(), 1.0, true);
            if (self) {
                CameraShake.add(0.7f);
                ScreenFx.vignette(0.4f, 0x200808, 16);
            }
        });
    }

    // ------------------------------------------------------------------ terbang

    private static void launch(AbstractClientPlayer caster) {
        schedule(0, 1, (level, t) -> takeoff(level, caster, 0.8));
    }

    /** 0.38 tolakan kaki saat lepas landas: tanah retak & batu terlempar, gelombang udara, uap terdorong ke bawah. */
    private static void takeoff(ClientLevel level, AbstractClientPlayer caster, double size) {
        Vec3 f = caster.position();
        if (!nearGround(level, caster, 2.5)) {
            return;   // lepas landas dari udara: nggak ada tanah yang ditolak
        }
        LintangFilm.crater(level, f, size, false);
        LintangFilm.shockwave(f.add(0, 0.15, 0), UP, 3.5 + size * 2.0, 14, 0.8f);
        RandomSource r = level.random;
        for (int i = 0, n = Vfx.count(10 + size * 6); i < n; i++) {
            double a = r.nextDouble() * Math.PI * 2.0;
            Vfx.smoke(f.x + Math.cos(a) * 0.4, f.y + 0.15, f.z + Math.sin(a) * 0.4, Math.cos(a) * 0.34, 0.0, Math.sin(a) * 0.34, AIR,
                    0.4f + r.nextFloat() * 0.3f, 12);
        }
    }

    private static void landing(AbstractClientPlayer caster, boolean self, boolean crash) {
        schedule(0, 1, (level, t) -> {   // 0.38 mendarat gaya pahlawan: kawah, batu terlempar, gelombang debu menyapu
            Vec3 f = caster.position();
            LintangFilm.crater(level, f, crash ? 2.6 : 1.5, false);
            LintangFilm.groundShock(level, f, crash ? 9.0 : 5.5, crash ? 24 : 18, crash ? 0.95f : 0.75f);
            if (crash) {
                LintangFilm.impactFlash(f.add(0, 0.3, 0), 1.3f);
            }
            if (self) {
                CameraShake.add(crash ? 0.7f : 0.4f);
            }
        });
    }

    /** Menembus kecepatan suara: kerucut uap kondensasi & cincin udara di belakang (tanpa kilatan). */
    private static void sonicBoom(AbstractClientPlayer caster, boolean self) {
        schedule(0, 1, (level, t) -> {   // 0.38: kerucut uap tebal, cincin uap melebar, garis angin di belakang
            Vec3 motion = new Vec3(caster.getX() - caster.xo, caster.getY() - caster.yo, caster.getZ() - caster.zo);
            Vec3 dir = motion.lengthSqr() > 1.0E-4 ? motion.normalize() : caster.getViewVector(1f);
            Vec3 c = caster.position().add(0, 0.9, 0);
            LintangFilm.vaporCone(c, dir, 1.2);
            LintangFilm.windStreaks(c.subtract(dir.scale(9.0)), c, 18, 8);
            if (self) {
                CameraShake.add(0.45f);
                FovKick.kick(0.3f);
            } else {
                ShazamFx.shakeAround(c, 0.4f, 32);
            }
        });
    }

    // ------------------------------------------------------------------ pasif

    /** Hati Pahlawan: pendengaran super, riak bunyi samar di penyerang yang terdengar. */
    private static void hear(Vec3 pos) {
        schedule(0, 6, (level, t) -> {
            if (t % 3 == 0) {
                Vfx.add(new Fx.Ripple(pos, UP, 0.0, 0.3, 1.6, 0.05, AIR, 12, 0.35f, true));
            }
        });
    }

    /** Tinju Baja: udara yang terdorong pukulan jadi gelombang kejut searah pukulan, debu & puing di bawah sasaran. */
    private static void steelPunch(AbstractClientPlayer caster, Vec3 pos, boolean self) {
        schedule(0, 1, (level, t) -> {   // 0.38: kilatan benturan, gelombang kejut searah pukulan, tanah retak di bawah sasaran
            Vec3 dir = pos.subtract(chest(caster));
            dir = dir.lengthSqr() < 1.0E-4 ? caster.getViewVector(1f) : dir.normalize();
            LintangFilm.impactFlash(pos, 1.0f);
            LintangFilm.shockwave(pos.subtract(dir.scale(0.3)), dir, 5.5, 14, 1f);
            for (int k = 0; k < 2; k++) {   // cincin udara berlapis yang melesat lewat sasaran
                Vfx.add(new Fx.Ripple(pos.subtract(dir.scale(0.4)), dir, 6.5 - k * 2.0, 0.45 + k * 0.15, 2.8 - k * 0.6,
                        0.24, k == 0 ? AIR : AIR_DIM, 12 + k * 3, 0.65f - k * 0.15f, true));
            }
            Vfx.add(new Fx.Cone(pos, dir, 5.0, 0.7, AIR, 10, 0.4f, 2.0, true));
            LintangFilm.crater(level, pos.subtract(0, 1.0, 0), 1.0, false);
            ShazamFx.ringOfSparks(level, pos, 8, 0xF2E8D8, 0.34);
            sound(level, pos, ShazamSounds.SHOCKWAVE.get(), 1.0f, 1.3f);
            if (self) {
                CameraShake.add(0.55f);
                FovKick.punch(0.45f);
            } else {
                ShazamFx.shakeAround(pos, 0.4f, 16);
            }
        });
    }

    /** Refleks Kilat: serangan ditangkap secepat kilat - tangan yang kabur, hentakan udara, percikan benturan. */
    private static void parry(AbstractClientPlayer caster, Vec3 pos) {
        ShazamPoses.ghostBurst(caster, 4);
        schedule(0, 1, (level, t) -> {
            LintangFilm.impactFlash(pos, 0.45f);
            Vfx.add(new Fx.Ripple(pos, pos.subtract(chest(caster)), 0.6, 0.2, 0.9, 0.06, AIR, 7, 0.5f, true));
            RandomSource r = level.random;
            for (int i = 0, n = Vfx.count(8); i < n; i++) {
                Vec3 v = ShazamFx.randomDir(r).scale(0.15 + r.nextDouble() * 0.15);
                Vfx.spark(pos.x, pos.y, pos.z, v.x, v.y + 0.06, v.z, 0xF4EEE4, 0.04f, 8 + r.nextInt(5), pos.y - 2.0);
            }
            Vfx.dust(pos.x, pos.y, pos.z, 0, 0.02, 0, AIR, 0.3f, 8);
        });
    }

    /** Kulit Baja: serangan kecil memantul dari kulitnya - percikan seperti peluru mengenai baja. */
    private static void bounce(Vec3 pos) {
        schedule(0, 1, (level, t) -> {
            LintangFilm.impactFlash(pos, 0.25f);
            for (int i = 0; i < 6; i++) {
                Vec3 v = ShazamFx.randomDir(level.random).scale(0.25);
                Vfx.spark(pos.x, pos.y, pos.z, v.x, v.y + 0.1, v.z, i % 2 == 0 ? 0xFFF4E0 : 0xFFC070, 0.04f, 8, pos.y - 2.0);
            }
        });
    }

    private static void punch(Vec3 pos) {
        schedule(0, 1, (level, t) -> {   // 0.38: tiap pukulan biasa ada kilatan benturan kecil & udara terpukul
            LintangFilm.impactFlash(pos, 0.35f);
            Vfx.add(new Fx.Ripple(pos, UP, 0.0, 0.2, 1.2, 0.08, AIR, 7, 0.5f, true));
            ShazamFx.dustPuffs(level, pos.subtract(0, 0.6, 0), DUST, 3, 0.3, 0.08);
        });
    }

    /** Tenaga surya kembali (keluar dari bawah tanah / Batu Cryon menjauh): badan tegak lagi, hentakan udara kecil. */
    private static void strengthBack(AbstractClientPlayer caster) {
        schedule(0, 1, (level, t) -> {
            Vfx.add(new Fx.Ripple(chest(caster), UP, 0.0, 0.3, 1.8, 0.08, AIR, 10, 0.4f, true));
            if (caster.onGround()) {
                ShazamFx.dustPuffs(level, caster.position(), DUST, 6, 0.7, 0.08);
            }
        });
    }

    /** Batu Cryon menghisap tenaganya: cuma terasa (pandangan menggelap, badan tersentak), urat terlihat di kulit. */
    private static void kelam(boolean self) {
        if (self) {
            ScreenFx.vignette(0.6f, 0x0E2A10, 20);
            CameraShake.add(0.2f);
        }
    }

    // ------------------------------------------------------------------ L - Lesatan Bintang

    private static void dash(AbstractClientPlayer caster, Vec3 end, boolean self) {
        int w = ShazamAnim.LESAT_WINDUP;
        schedule(0, w, (level, t) -> {   // merunduk: debu di kaki mulai berputar
            ShazamFx.swirlDust(level, caster, t);
        });
        schedule(w, 1, (level, t) -> {   // 0.38: kerucut uap saat melesat, garis angin & terowongan udara sepanjang jalur
            double up = 0.9 * caster.getScale();
            Vec3 start = caster.position().add(0, up, 0);
            Vec3 stop = end.add(0, up, 0);
            Vec3 dir = stop.subtract(start);
            if (dir.lengthSqr() > 1.0E-4) {
                Vec3 n = dir.normalize();
                LintangFilm.vaporCone(start, n, 0.9);
                LintangFilm.windStreaks(start, stop, 26, 10);
                Vfx.add(new Fx.Ripple(start, n, dir.length(), 0.5, 1.6, 0.14, AIR, 10, 0.45f, true));
            }
            groundHit(level, caster.position(), 0.6, false);
            ShazamPoses.ghostBurst(caster, ShazamAnim.LESAT_TICKS + 4);
            if (self) {
                FovKick.kick(0.45f);
                ScreenFx.speedLines(0.9f);
            }
        });
        schedule(w + ShazamAnim.LESAT_TICKS, 1, (level, t) -> {   // berhenti mendadak: udara yang terbawa menghantam
            Vec3 c = caster.position().add(0, 0.9, 0);
            LintangFilm.shockwave(c, UP, 4.0, 12, 0.85f);
            ShazamFx.dustPuffs(level, caster.position(), DUST, 12, 1.1, 0.18);
            ShazamFx.shakeAround(c, 0.45f, 16);
        });
    }

    // ------------------------------------------------------------------ I - Iris Surya

    private static void eyes(AbstractClientPlayer caster, boolean self) {
        long now = caster.level().getGameTime();
        EYES.put(caster.getId(), new long[] {now, now + ShazamAnim.IRIS_WINDUP + ShazamAnim.IRIS_TICKS});
        Vfx.add(new EyeBeams(caster));
        if (self) {
            CameraShake.add(0.15f);
        }
    }

    // ------------------------------------------------------------------ N - Napas Salju

    private static void breath(AbstractClientPlayer caster, boolean self) {
        int w = ShazamAnim.FROST_WINDUP;
        schedule(0, w, (level, t) -> {   // menarik napas: udara di sekitar tersedot ke mulut
            Vec3 m = mouth(caster, 1f);
            for (int i = 0, n = Vfx.count(2.5); i < n; i++) {
                Vec3 off = ShazamFx.randomDir(level.random).scale(1.4 + level.random.nextDouble() * 0.7);
                Vfx.dust(m.x + off.x, m.y + off.y * 0.6, m.z + off.z, -off.x * 0.17, -off.y * 0.1, -off.z * 0.17, AIR, 0.17f, 6);
            }
        });
        schedule(w, ShazamAnim.FROST_TICKS, (level, t) -> {   // 0.38: semburan embun beku tebal bergulung (uap dingin, bukan cahaya)
            Vec3 m = mouth(caster, 1f);
            Vec3 look = caster.getViewVector(1f);
            RandomSource r = level.random;
            for (int i = 0, n = Vfx.count(7); i < n; i++) {
                Vec3 v = look.add(ShazamFx.randomDir(r).scale(0.24)).normalize().scale(0.5 + r.nextDouble() * 0.45);
                Vfx.smoke(m.x, m.y, m.z, v.x, v.y, v.z, i % 3 == 0 ? 0xFFFFFF : FROST, 0.32f + r.nextFloat() * 0.4f,
                        14 + r.nextInt(8));
            }
            for (int i = 0, n = Vfx.count(2); i < n; i++) {   // butir es
                Vec3 v = look.add(ShazamFx.randomDir(r).scale(0.2)).normalize().scale(0.6 + r.nextDouble() * 0.3);
                Vfx.shard(m.x, m.y, m.z, v.x, v.y, v.z, FROST, 0.05f + r.nextFloat() * 0.03f, 14 + r.nextInt(6), m.y - 3.0);
            }
            if (t % 3 == 0) {   // kabut dingin yang turun & melebar di ujung hembusan
                Vec3 e = m.add(look.scale(6.0 + r.nextDouble() * 4.0));
                Vfx.smoke(e.x, e.y, e.z, (r.nextDouble() - 0.5) * 0.06, -0.02, (r.nextDouble() - 0.5) * 0.06, FROST,
                        0.7f + r.nextFloat() * 0.4f, 30 + r.nextInt(10));
            }
            if (self && t % 10 == 0) {
                CameraShake.add(0.08f);
            }
        });
    }

    // ------------------------------------------------------------------ T - Tepukan Guruh

    private static void clap(AbstractClientPlayer caster, boolean self) {
        schedule(ShazamAnim.SONIC_WINDUP, 1, (level, t) -> {   // 0.38: kilatan tepukan, gelombang kejut raksasa, debu tersapu
            Vec3 hands = ShazamPoses.handPos(caster, true, 1f).add(ShazamPoses.handPos(caster, false, 1f)).scale(0.5);
            Vec3 look = caster.getViewVector(1f);
            LintangFilm.impactFlash(hands, 0.9f);
            LintangFilm.shockwave(hands, look, 6.0, 12, 1f);
            for (int k = 0; k < 3; k++) {   // gelombang udara berlapis melesat ke depan (soft, bukan cahaya)
                Vfx.add(new Fx.Ripple(hands, look, 14.0 - k * 2.5, 0.4 + k * 0.2, 6.0 - k, 0.3, k == 0 ? AIR : AIR_DIM,
                        12 + k * 3, 0.6f - k * 0.12f, true));
            }
            Vfx.add(new Fx.Ripple(hands, look, 12.0, 0.6, 5.0, 0.9, 0xD8D0C4, 18, 0.45f, true));
            LintangFilm.windStreaks(hands, hands.add(look.scale(14.0)), 22, 10);
            Vec3 f = flat(look);
            for (int i = 0, n = Vfx.count(22); i < n; i++) {   // dinding debu tersapu ke depan
                double d0 = 2 + level.random.nextDouble() * 10, side = (level.random.nextDouble() - 0.5) * d0 * 1.2;
                Vec3 p = caster.position().add(f.scale(d0)).add(-f.z * side, 0.2, f.x * side);
                Vfx.dust(p.x, p.y, p.z, f.x * 0.28, 0.04, f.z * 0.28, 0xC8BBA8, 0.65f, 24);
            }
            ShazamFx.shakeAround(hands, 0.9f, 24);
            if (self) {
                FovKick.punch(0.55f);
            }
        });
    }

    // ------------------------------------------------------------------ A - Amukan Kilat

    private static void barrage(AbstractClientPlayer caster, boolean self) {
        int w = ShazamAnim.BARRAGE_WINDUP;
        ShazamPoses.ghostBurst(caster, w + ShazamAnim.BARRAGE_TICKS + 4);   // kepalan kabur (motion blur)
        schedule(w, ShazamAnim.BARRAGE_TICKS, (level, t) -> {   // 0.38: tiap pukulan ada kilatan benturan
            if (t % 2 != 0) {
                return;
            }
            Vec3 hand = ShazamPoses.handPos(caster, (t / 2) % 2 == 0, 1f);
            Vec3 look = caster.getViewVector(1f);
            Vec3 tip = hand.add(look.scale(0.6)).add(ShazamFx.randomDir(level.random).scale(0.2));
            boolean last = t >= ShazamAnim.BARRAGE_TICKS - 2;
            LintangFilm.impactFlash(tip, last ? 0.9f : 0.32f);
            Vfx.add(new Fx.Ripple(tip, look, 0.6, 0.15, 0.7, 0.05, AIR, 5, 0.5f, true));   // udara terpukul
            Vfx.dust(tip.x, tip.y, tip.z, look.x * 0.1, 0.01, look.z * 0.1, AIR, 0.2f, 6);
            if (last) {   // pukulan penutup
                LintangFilm.shockwave(tip, look, 4.0, 12, 0.9f);
            }
            if (self && t % 4 == 0) {
                CameraShake.add(last ? 0.3f : 0.06f);
            }
        });
    }

    private static void hit(AbstractClientPlayer caster, Vec3 pos) {
        schedule(0, 1, (level, t) -> {   // 0.38: kilatan benturan + gelombang udara searah pukulan
            Vec3 n = pos.subtract(caster.getEyePosition());
            Vec3 dir = n.lengthSqr() > 1.0E-4 ? n.normalize() : UP;
            LintangFilm.impactFlash(pos, 0.6f);
            LintangFilm.shockwave(pos.subtract(dir.scale(0.2)), dir, 2.4, 9, 0.8f);
            ShazamFx.ringOfSparks(level, pos, 5, 0xF2E8D8, 0.28);
            ShazamFx.dustPuffs(level, pos.subtract(0, 0.8, 0), DUST, 4, 0.4, 0.1);
            ShazamFx.shakeAround(pos, 0.2f, 12);
        });
    }

    // ------------------------------------------------------------------ N - Napak Langit

    private static void leap(AbstractClientPlayer caster) {
        schedule(ShazamAnim.LEAP_WINDUP, 1, (level, t) -> takeoff(level, caster, 1.3));   // 0.38: tolakan kaki meretakkan tanah
        schedule(ShazamAnim.LEAP_WINDUP, 14, (level, t) -> {   // uap tipis saat melambung & menukik
            if (t % 2 == 0) {
                Vec3 c = caster.position().add(0, 0.9, 0);
                Vfx.smoke(c.x, c.y, c.z, 0, 0, 0, AIR, 0.32f, 10);
            }
        });
    }

    private static void slam(AbstractClientPlayer caster, Vec3 pos, boolean self) {
        schedule(0, 1, (level, t) -> {   // 0.38: kawah raksasa, batu besar terlempar, kilatan benturan, gelombang debu
            LintangFilm.crater(level, pos, 3.2, false);
            LintangFilm.groundShock(level, pos, 11.0, 26, 0.95f);
            LintangFilm.impactFlash(pos.add(0, 0.4, 0), 1.6f);
            LintangFilm.shockwave(pos.add(0, 0.6, 0), UP, 7.5, 16, 0.9f);
            if (self) {
                CameraShake.add(0.9f);
                FovKick.punch(0.5f);
            }
        });
    }

    // ------------------------------------------------------------------ G - Gelegar Surya

    /**
     * Gelegar Surya: seluruh tenaga surya yang tersimpan di sel tubuh dilepas sekaligus jadi ledakan panas. Cahayanya
     * kilatan panas biasa (seperti ledakan), tanpa sinar dewa, tombak cahaya, atau butiran berkilau.
     */
    private static void flare(AbstractClientPlayer caster, boolean self) {
        int w = ShazamAnim.FLARE_WINDUP;
        schedule(0, w, (level, t) -> {   // menahan panas: udara di sekitar badan beriak, debu terdorong menjauh
            if (t % 3 == 0) {
                Vec3 c = chest(caster);
                Vfx.add(new Fx.Ripple(c, UP, 0.0, 0.4, 1.4 + t * 0.06, 0.06, AIR, 8, 0.25f + 0.02f * t, true));
            }
            if (caster.onGround()) {
                ShazamFx.swirlDust(level, caster, t);
            }
        });
        if (self) {
            ScreenFx.vignette(0.35f, 0x401808, w);
        }
        schedule(w, 1, (level, t) -> {   // 0.38: kilatan ledakan, gelombang kejut raksasa, kawah membara, batu terlempar
            Vec3 c = chest(caster);
            LintangFilm.impactFlash(c, 2.4f);
            Vfx.add(new Fx.Flash(c, 6.0f, HEAT_MID, 12, 0.35f));
            LintangFilm.shockwave(c, UP, 16.0, 24, 1f);
            Ground.Map map = ShazamFx.ground(level, c, 16.0);
            if (map != null && map.found) {
                Vec3 g = map.center(c);
                int dust = map.dustColor(level, c);
                Vfx.add(new Fx.Wave(g, UP, 14.0, 2.0, dust, 34, 0.6f, 0f, map, true));
            }
            LintangFilm.crater(level, c, 2.6, true);
            ShazamFx.smokeCloud(level, c.subtract(0, 1.0, 0), DUST, 14, 4.0);
            ShazamFx.shakeAround(c, 1.4f, 40);
            if (self) {
                ScreenFlash.flash(0.45f, 0xFFF0E0);
                FovKick.punch(0.9f);
            } else {
                flashNear(c, 0.35f, 0xFFF0E0, 40);
            }
        });
    }

    /** Kilatan layar untuk penonton di dekat titik ini (makin dekat makin terang). */
    private static void flashNear(Vec3 c, float strength, int rgb, double radius) {
        var me = Minecraft.getInstance().player;
        if (me == null) {
            return;
        }
        double d = me.position().distanceTo(c);
        if (d < radius) {
            ScreenFlash.flash(strength * (float) (1.0 - d / radius), rgb);
        }
    }

    // ------------------------------------------------------------------ M - Serap Surya

    /**
     * Serap Surya: lengan terbuka menghadap matahari, sel tubuhnya menyerap sinar (nggak terlihat, cuma udara di sekitar
     * badan yang memanas dan beriak), lalu panas berlebihnya dilepas: gelombang panas, debu terhempas, kilatan singkat.
     */
    private static void call(AbstractClientPlayer caster, boolean self) {
        int w = ShazamAnim.SUNCALL_WINDUP;
        schedule(0, w, (level, t) -> {
            if (t % 3 == 0) {
                Vec3 c = chest(caster);
                Vfx.add(new Fx.Ripple(c.add(0, 0.3, 0), UP, 0.6, 0.5, 1.2, 0.05, AIR, 10, 0.3f, true));
            }
        });
        schedule(w, 1, (level, t) -> {   // 0.38: panas berlebih dilepas: kilatan singkat & gelombang udara
            Vec3 c = chest(caster);
            LintangFilm.impactFlash(c, 1.0f);
            LintangFilm.shockwave(c, UP, 6.5, 14, 0.9f);
            groundHit(level, caster.position(), 1.2, false);
            if (self) {
                CameraShake.add(0.4f);
            }
        });
    }

    // ------------------------------------------------------------------ J - Selamatkan

    private static void rescue(AbstractClientPlayer caster, boolean self) {
        ShazamPoses.ghostBurst(caster, ShazamAnim.RESCUE_WINDUP + 16);
        schedule(ShazamAnim.RESCUE_WINDUP, 1, (level, t) -> {
            ShazamFx.dustPuffs(level, caster.position(), DUST, 10, 0.9, 0.16);
            if (self) {
                ScreenFx.speedLines(0.6f);
                FovKick.kick(0.3f);
            }
        });
    }

    /** Satu sekutu diselamatkan: Lintang tiba secepat kilat, debu & udara berputar di sekelilingnya. */
    private static void save(AbstractClientPlayer caster, Vec3 pos) {
        schedule(0, 1, (level, t) -> {   // 0.38: Lintang tiba secepat kilat: gelombang udara di kaki, debu & angin berputar
            Vec3 feet = pos.subtract(0, 0.9, 0);
            LintangFilm.shockwave(feet.add(0, 0.2, 0), UP, 2.8, 12, 0.6f);
            ShazamFx.dustPuffs(level, feet, DUST, 12, 1.0, 0.16);
            RandomSource r = level.random;
            for (int i = 0, n = Vfx.count(10); i < n; i++) {
                double a = r.nextDouble() * Math.PI * 2.0;
                Vfx.dust(pos.x + Math.cos(a) * 0.9, pos.y + (r.nextDouble() - 0.5), pos.z + Math.sin(a) * 0.9, -Math.sin(a) * 0.27,
                        0.02, Math.cos(a) * 0.27, AIR, 0.32f, 10);
            }
        });
    }

    // ------------------------------------------------------------------ tiang cahaya (sisa, nggak dipakai Lintang lagi)

    /**
     * MagicBolt varian 3 menyentuh tanah (dipanggil ShazamFx.boltStrike). Sejak 0.35 Lintang nggak memanggil tiang
     * cahaya lagi; ini cuma dipertahankan supaya bolt varian 3 lama (misalnya dari perintah) tetap aman: hantaman tanah biasa.
     */
    public static void sunStrike(ClientLevel level, Vec3 g, Ground.Map map, float size) {
        float boostOld = Vfx.setBoost(BOOST);
        try {
            groundHit(level, g, 0.8 + size, true);
        } finally {
            Vfx.setBoost(boostOld);
        }
    }

    /** Sinar panas singkat dari mata ke titik ini (LINTANG_LANCE). */
    private static void heatZap(AbstractClientPlayer caster, Vec3 pos) {
        schedule(0, 1, (level, t) -> {
            Vfx.add(new HeatZap(caster, pos));
            RandomSource r = level.random;
            for (int i = 0, n = Vfx.count(6); i < n; i++) {
                Vec3 v = ShazamFx.randomDir(r).scale(0.15 + r.nextDouble() * 0.15);
                Vfx.spark(pos.x, pos.y, pos.z, v.x, Math.abs(v.y) + 0.05, v.z, i % 2 == 0 ? HEAT_CORE : HEAT_MID, 0.05f,
                        8 + r.nextInt(5), pos.y - 2.0);
            }
            Vfx.smoke(pos.x, pos.y, pos.z, 0, 0.03, 0, 0x2A2420, 0.4f, 24);
            sound(level, pos, ShazamSounds.HEAT_VISION.get(), 0.7f, 1.3f);
        });
    }

    // ------------------------------------------------------------------ 0.36 anjing super

    /**
     * Serigala ini sedang jadi anjing super? (jinak, pemiliknya Lintang dalam Mode Surya di dekatnya, nggak duduk, sudah
     * dewasa). Dipakai SuperDogCapeLayer (jubah merah kecil) dan jejak uapnya.
     */
    public static boolean superDog(net.minecraft.world.entity.animal.Wolf wolf) {
        if (!wolf.isTame() || wolf.isBaby() || wolf.isInvisible()) {
            return false;
        }
        LivingEntity owner = wolf.getOwner();
        return owner != null && ShazamClientState.isTransformed(owner.getId()) && ShazamClientState.isLintang(owner.getId())
                && owner.distanceToSqr(wolf) < com.shazammod.LintangDog.RANGE * com.shazammod.LintangDog.RANGE;
    }

    /** Anjing super yang melesat (lari kencang atau terbang mengikuti Lintang): uap tipis di belakangnya. */
    private static void dogTrails(ClientLevel level) {
        float boostOld = Vfx.setBoost(BOOST);
        try {
            RandomSource r = level.random;
            for (AbstractClientPlayer p : level.players()) {
                if (!ShazamClientState.isTransformed(p.getId()) || !ShazamClientState.isLintang(p.getId())) {
                    continue;
                }
                for (net.minecraft.world.entity.animal.Wolf dog : level.getEntitiesOfClass(net.minecraft.world.entity.animal.Wolf.class,
                        p.getBoundingBox().inflate(com.shazammod.LintangDog.RANGE), w -> w.isAlive() && superDog(w))) {
                    Vec3 m = new Vec3(dog.getX() - dog.xo, dog.getY() - dog.yo, dog.getZ() - dog.zo);
                    double speed = m.length();
                    if (speed < (dog.onGround() ? 0.42 : 0.3) || r.nextInt(2) != 0) {
                        continue;
                    }
                    Vec3 back = dog.position().add(0, dog.getBbHeight() * 0.6, 0).subtract(m.normalize().scale(0.6))
                            .add(ShazamFx.randomDir(r).scale(0.15));
                    Vfx.smoke(back.x, back.y, back.z, -m.x * 0.05, -m.y * 0.05, -m.z * 0.05, AIR, 0.16f + (float) Math.min(0.2, speed * 0.08),
                            8 + r.nextInt(4));
                }
            }
        } finally {
            Vfx.setBoost(boostOld);
        }
    }

    // ------------------------------------------------------------------ 0.36 Angkat & Lempar (Shift + X)

    /** Musuh diraih & diangkat ke atas kepala (debu di kaki), lalu di tick THROW_RELEASE dilempar: hentakan udara. */
    private static void liftThrow(AbstractClientPlayer caster, Vec3 pos, boolean self) {
        schedule(2, 1, (level, t) -> {   // kaki menapak saat mengangkat
            if (caster.onGround()) {
                ShazamFx.dustPuffs(level, caster.position(), DUST, 6, 0.6, 0.08);
            }
        });
        schedule(ShazamAnim.THROW_RELEASE, 1, (level, t) -> {
            Vec3 look = caster.getViewVector(1f);
            Vec3 c = chest(caster).add(look.scale(0.6));
            Vfx.add(new Fx.Ripple(c, look, 4.0, 0.4, 1.8, 0.16, AIR, 10, 0.55f, true));
            Vfx.add(new Fx.Cone(c, look.scale(-1), 2.6, 0.8, AIR, 9, 0.35f, 2.0, true));
            ShazamPoses.ghostBurst(caster, 4);
            LivingEntity mob = nearest(level, caster, pos, 3.0);
            if (mob != null) {   // jejak uap di belakang musuh yang melayang dilempar
                schedule(1, 14, (lv, tt) -> {
                    if (!mob.isAlive()) {
                        return;
                    }
                    Vec3 m = new Vec3(mob.getX() - mob.xo, mob.getY() - mob.yo, mob.getZ() - mob.zo);
                    if (m.lengthSqr() < 0.04) {
                        return;
                    }
                    Vec3 b = mob.position().add(0, mob.getBbHeight() * 0.5, 0);
                    Vfx.smoke(b.x, b.y, b.z, -m.x * 0.05, -m.y * 0.05, -m.z * 0.05, AIR, 0.3f, 10);
                });
            }
            if (self) {
                CameraShake.add(0.25f);
                FovKick.punch(0.25f);
            }
        });
    }

    /** Musuh yang dilempar menghantam: tanah retak, puing, debu, gelombang udara. */
    private static void flungImpact(Vec3 pos, boolean self) {
        schedule(0, 1, (level, t) -> {   // 0.38: musuh yang dilempar menghantam: kilatan, kawah, batu terlempar
            LintangFilm.impactFlash(pos.add(0, 0.4, 0), 0.9f);
            LintangFilm.crater(level, pos, 1.5, false);
            LintangFilm.shockwave(pos.add(0, 0.4, 0), UP, 4.5, 14, 0.8f);
            if (self) {
                CameraShake.add(0.35f);
            }
        });
    }

    /** Makhluk hidup terdekat dari titik itu (selain si pemakai). */
    private static LivingEntity nearest(ClientLevel level, AbstractClientPlayer caster, Vec3 pos, double radius) {
        LivingEntity best = null;
        double bestD = radius * radius;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(pos, pos).inflate(radius),
                e -> e != caster && e.isAlive())) {
            double d = e.position().add(0, e.getBbHeight() * 0.5, 0).distanceToSqr(pos);
            if (d < bestD) {
                bestD = d;
                best = e;
            }
        }
        return best;
    }

    // ------------------------------------------------------------------ 0.36 patung es (Napas Salju)

    /** Makhluk yang membeku penuh terbungkus balok es bening: es merambat naik dari kaki, kabut dingin, butir es. */
    private static void encase(AbstractClientPlayer caster, Vec3 pos) {
        schedule(0, 1, (level, t) -> {
            LivingEntity mob = nearest(level, caster, pos, 2.5);
            if (mob == null) {
                return;
            }
            IceShell old = ICE.remove(mob.getId());
            if (old != null) {
                old.shatter();
            }
            IceShell shell = new IceShell(mob);
            ICE.put(mob.getId(), shell);
            Vfx.add(shell);
            RandomSource r = level.random;
            Vec3 f = mob.position();
            for (int i = 0, n = Vfx.count(10); i < n; i++) {   // kabut dingin menyebar dari kaki
                double a = r.nextDouble() * Math.PI * 2.0;
                Vfx.dust(f.x + Math.cos(a) * 0.5, f.y + 0.1, f.z + Math.sin(a) * 0.5, Math.cos(a) * 0.06, 0.01, Math.sin(a) * 0.06,
                        FROST, 0.3f + r.nextFloat() * 0.2f, 18 + r.nextInt(8));
            }
            for (int i = 0, n = Vfx.count(5); i < n; i++) {
                Vec3 v = ShazamFx.randomDir(r).scale(0.08);
                Vfx.shard(pos.x, pos.y, pos.z, v.x, Math.abs(v.y) + 0.04, v.z, ICE_SHARD, 0.05f, 12, f.y);
            }
        });
    }

    /** Patung es pecah (dipukul / habis waktunya / mencair): kepingan es berhamburan, kabut dingin, riak udara. */
    private static void shatter(Vec3 pos) {
        schedule(0, 1, (level, t) -> {
            IceShell shell = null;
            double best = 9.0;
            for (IceShell s : ICE.values()) {
                double d = s.center().distanceToSqr(pos);
                if (d < best) {
                    best = d;
                    shell = s;
                }
            }
            double h = 1.8;
            if (shell != null) {
                h = shell.height();
                shell.shatter();
                ICE.values().remove(shell);
            }
            RandomSource r = level.random;
            double floor = pos.y - h * 0.6 - 0.2;
            for (int i = 0, n = Vfx.count(6 + h * 2); i < n; i++) {   // kepingan es besar (sesekali berkilau kena cahaya)
                Vec3 v = ShazamFx.randomDir(r).scale(0.12 + r.nextDouble() * 0.2);
                Vec3 at = pos.add((r.nextDouble() - 0.5) * 0.6, (r.nextDouble() - 0.5) * h * 0.8, (r.nextDouble() - 0.5) * 0.6);
                Vfx.shard(at.x, at.y, at.z, v.x, Math.abs(v.y) * 0.8 + 0.06, v.z, ICE_SHARD, 0.07f + r.nextFloat() * 0.06f,
                        16 + r.nextInt(10), floor);
            }
            for (int i = 0, n = Vfx.count(10 + h * 4); i < n; i++) {   // serbuk es halus yang berhamburan (es biasa, tanpa kilau)
                Vec3 v = ShazamFx.randomDir(r).scale(0.06 + r.nextDouble() * 0.12);
                Vec3 at = pos.add((r.nextDouble() - 0.5) * 0.7, (r.nextDouble() - 0.5) * h * 0.9, (r.nextDouble() - 0.5) * 0.7);
                Vfx.dust(at.x, at.y, at.z, v.x, Math.abs(v.y) * 0.5 + 0.02, v.z, i % 2 == 0 ? ICE_EDGE : ICE_FACE,
                        0.1f + r.nextFloat() * 0.1f, 14 + r.nextInt(8));
            }
            for (int i = 0, n = Vfx.count(8); i < n; i++) {
                Vec3 v = ShazamFx.randomDir(r).scale(0.05);
                Vfx.dust(pos.x, pos.y, pos.z, v.x, v.y * 0.5 + 0.01, v.z, FROST, 0.35f + r.nextFloat() * 0.25f, 16 + r.nextInt(8));
            }
            Vfx.add(new Fx.Ripple(pos, UP, 0.0, 0.3, 1.6, 0.08, AIR, 8, 0.45f, true));
        });
    }

    /**
     * 0.36 Balok es bening yang membungkus makhluk (mengikuti posisinya). Es merambat naik dari kaki (3 tick), retak-retak
     * makin banyak menjelang lepas, lalu hilang (pecahnya digambar shatter()). Seluruhnya di lapisan soft: es biasa yang
     * kena cahaya dunia, bukan cahaya sihir.
     */
    static final class IceShell extends Effect {
        private final LivingEntity mob;
        private final float[] cracks;   // tiap retak: {sisi 0-3, u0, v0, u1, v1, mulai (0..1 umur)}
        private final float[] fog;      // kabut beku di dalam es: {u, v, w, besar} (0..1 di dalam balok)
        private final float[] spikes;   // kristal es mencuat di tepi atas: {sisi 0-3, posisi 0..1, panjang}
        private boolean broken;

        IceShell(LivingEntity mob) {
            super(ShazamAnim.LINTANG_ICE_TICKS + 6);
            this.mob = mob;
            RandomSource r = Vfx.random();
            int n = 14;
            this.cracks = new float[n * 6];
            for (int i = 0; i < n; i++) {
                float u = r.nextFloat(), v = r.nextFloat();
                float ang = r.nextFloat() * (float) (Math.PI * 2.0), len = 0.15f + r.nextFloat() * 0.3f;
                cracks[i * 6] = r.nextInt(4);
                cracks[i * 6 + 1] = u;
                cracks[i * 6 + 2] = v;
                cracks[i * 6 + 3] = Mth.clamp(u + Mth.cos(ang) * len, 0f, 1f);
                cracks[i * 6 + 4] = Mth.clamp(v + Mth.sin(ang) * len, 0f, 1f);
                cracks[i * 6 + 5] = 0.45f + 0.5f * r.nextFloat();
            }
            this.fog = new float[6 * 4];
            for (int i = 0; i < 6; i++) {
                fog[i * 4] = 0.25f + 0.5f * r.nextFloat();
                fog[i * 4 + 1] = 0.1f + 0.8f * r.nextFloat();
                fog[i * 4 + 2] = 0.25f + 0.5f * r.nextFloat();
                fog[i * 4 + 3] = 0.6f + 0.5f * r.nextFloat();
            }
            this.spikes = new float[8 * 3];
            for (int i = 0; i < 8; i++) {
                spikes[i * 3] = r.nextInt(4);
                spikes[i * 3 + 1] = 0.1f + 0.8f * r.nextFloat();
                spikes[i * 3 + 2] = 0.1f + 0.14f * r.nextFloat();
            }
        }

        void shatter() {
            broken = true;
        }

        boolean done() {
            return broken || age >= life || !mob.isAlive() || mob.isRemoved();
        }

        Vec3 center() {
            return mob.position().add(0, mob.getBbHeight() * 0.5, 0);
        }

        double height() {
            return mob.getBbHeight();
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (done()) {
                return false;
            }
            if (age % 5 == 0) {   // hawa dingin turun dari es
                RandomSource r = level.random;
                double hw = mob.getBbWidth() * 0.5 + 0.15;
                Vfx.smoke(mob.getX() + (r.nextDouble() - 0.5) * hw * 2, mob.getY() + 0.1, mob.getZ() + (r.nextDouble() - 0.5) * hw * 2,
                        0, -0.003, 0, 0xE4F4FF, 0.18f, 18);
            }
            return super.tick(level);
        }

        @Override
        public void renderSoft(Draw d) {
            if (done()) {
                return;
            }
            float pt = d.partialTick;
            float t = age + pt;
            Vec3 p = mob.getPosition(pt);
            double hw = mob.getBbWidth() * 0.5 + 0.14, h = mob.getBbHeight() + 0.18;
            float grow = Mth.clamp(t / 3f, 0f, 1f);
            float fade = Mth.clamp((life - t) / 4f, 0f, 1f);
            double y0 = p.y - 0.03, y1 = y0 + h * grow;
            double x0 = p.x - hw, x1 = p.x + hw, z0 = p.z - hw, z1 = p.z + hw;
            float a = 0.33f * fade, ab = a * 1.55f, at = a * 0.85f;   // lebih tebal & putih di bawah
            int c = ICE_FACE;
            d.quad(x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0, c, ab, ab, at, at);
            d.quad(x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0, c, ab, ab, at, at);
            d.quad(x1, y0, z1, x0, y0, z1, x0, y1, z1, x1, y1, z1, c, ab, ab, at, at);
            d.quad(x0, y0, z1, x0, y0, z0, x0, y1, z0, x0, y1, z1, c, ab, ab, at, at);
            if (grow >= 1f) {
                d.quad(x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1, c, at, at, at, at);
            }
            // kabut beku di dalam es: makhluknya terlihat samar, membeku padat
            for (int i = 0; i < fog.length / 4; i++) {
                double fx = x0 + (x1 - x0) * fog[i * 4], fy = y0 + h * grow * fog[i * 4 + 1], fz = z0 + (z1 - z0) * fog[i * 4 + 2];
                d.puff(fx, fy, fz, (float) (hw * 0.75 * fog[i * 4 + 3]), 0xF2FAFF, 0xB8D8EC, 0.2f * fade * grow);
            }
            float ew = 0.045f, ea = 0.75f * fade;   // tepi es yang terang
            int e = ICE_EDGE;
            double[][] corners = {{x0, z0}, {x1, z0}, {x1, z1}, {x0, z1}};
            if (grow >= 1f) {   // kristal es kecil mencuat dari tepi atas
                for (int i = 0; i < spikes.length / 3; i++) {
                    int side = (int) spikes[i * 3];
                    double[] q = corners[side], n = corners[(side + 1) % 4];
                    double f = spikes[i * 3 + 1], len = spikes[i * 3 + 2];
                    double sx = q[0] + (n[0] - q[0]) * f, sz = q[1] + (n[1] - q[1]) * f;
                    double ox = (sx - p.x) / hw * 0.4, oz = (sz - p.z) / hw * 0.4;
                    d.line(sx, y1, sz, sx + ox * len, y1 + len, sz + oz * len, 0.07f, 0.005f, e, 0.7f * fade, 0.4f * fade);
                }
            }
            for (int i = 0; i < 4; i++) {
                double[] q = corners[i], n = corners[(i + 1) % 4];
                d.line(q[0], y0, q[1], q[0], y1, q[1], ew, ew, e, ea, ea * 0.8f);
                d.line(q[0], y0 + 0.02, q[1], n[0], y0 + 0.02, n[1], ew, ew, e, ea * 0.7f, ea * 0.7f);
                if (grow >= 1f) {
                    d.line(q[0], y1, q[1], n[0], y1, n[1], ew, ew, e, ea, ea);
                }
            }
            // retak-retak yang makin banyak menjelang es lepas
            float k = t / life;
            for (int i = 0; i < cracks.length / 6; i++) {
                float start = cracks[i * 6 + 5];
                if (k < start || grow < 1f) {
                    continue;
                }
                float ca = Mth.clamp((k - start) / 0.1f, 0f, 1f) * 0.6f * fade;
                int side = (int) cracks[i * 6];
                double[] q = corners[side], n = corners[(side + 1) % 4];
                double u0 = cracks[i * 6 + 1], v0 = cracks[i * 6 + 2], u1 = cracks[i * 6 + 3], v1 = cracks[i * 6 + 4];
                double ax = q[0] + (n[0] - q[0]) * u0, az = q[1] + (n[1] - q[1]) * u0, ay = y0 + h * v0;
                double bx = q[0] + (n[0] - q[0]) * u1, bz = q[1] + (n[1] - q[1]) * u1, by = y0 + h * v1;
                d.line(ax, ay, az, bx, by, bz, 0.025f, 0.015f, 0xFFFFFF, ca, ca * 0.6f);
            }
        }
    }

    // ------------------------------------------------------------------ 0.37 Napas Topan (Shift + C)

    /**
     * Napas Topan: menarik napas (udara di sekitar tersedot ke mulut), lalu angin topan: garis-garis angin putih melesat
     * dalam kerucut, udara & uap terdorong, debu di tanah tersapu sepanjang hembusan. Semuanya udara, bukan cahaya.
     */
    private static void gale(AbstractClientPlayer caster, boolean self) {
        int w = ShazamAnim.FROST_WINDUP;
        schedule(0, w, (level, t) -> {
            Vec3 m = mouth(caster, 1f);
            for (int i = 0, n = Vfx.count(2.5); i < n; i++) {
                Vec3 off = ShazamFx.randomDir(level.random).scale(1.6 + level.random.nextDouble() * 0.8);
                Vfx.dust(m.x + off.x, m.y + off.y * 0.6, m.z + off.z, -off.x * 0.18, -off.y * 0.1, -off.z * 0.18, AIR, 0.18f, 6);
            }
        });
        schedule(w, ShazamAnim.FROST_TICKS, (level, t) -> {
            Vec3 m = mouth(caster, 1f);
            Vec3 look = caster.getViewVector(1f);
            RandomSource r = level.random;
            if (t % 2 == 0) {
                Vfx.add(new GaleStreaks(m.add(look.scale(0.3)), look, 5));
            }
            for (int i = 0, n = Vfx.count(4); i < n; i++) {   // udara & uap yang terdorong
                Vec3 v = look.add(ShazamFx.randomDir(r).scale(0.22)).normalize().scale(0.7 + r.nextDouble() * 0.5);
                Vfx.smoke(m.x, m.y, m.z, v.x, v.y, v.z, i % 2 == 0 ? 0xFFFFFF : AIR, 0.22f + r.nextFloat() * 0.25f, 10 + r.nextInt(6));
            }
            if (t % 3 == 0) {   // debu di tanah tersapu searah hembusan
                Vec3 flat = flat(look);
                for (double d = 3.0; d <= 13.0; d += 2.5) {
                    Vec3 p = m.add(look.scale(d));
                    BlockHitResult hit = level.clip(new ClipContext(p, p.subtract(0, 3.5, 0), ClipContext.Block.COLLIDER,
                            ClipContext.Fluid.NONE, caster));
                    if (hit.getType() == HitResult.Type.MISS) {
                        continue;
                    }
                    Vec3 g = hit.getLocation();
                    Vfx.dust(g.x + (r.nextDouble() - 0.5) * d * 0.4, g.y + 0.15, g.z + (r.nextDouble() - 0.5) * d * 0.4,
                            flat.x * 0.35, 0.03 + r.nextDouble() * 0.04, flat.z * 0.35, DUST, 0.45f + r.nextFloat() * 0.3f, 16);
                }
            }
            if (self && t % 8 == 0) {
                CameraShake.add(0.08f);
            }
        });
    }

    /** Garis-garis angin Napas Topan: goresan putih tipis (udara, bukan cahaya) yang melesat dalam kerucut. */
    static final class GaleStreaks extends Effect {
        private final Vec3 origin;
        private final Vec3[] dirs;
        private final float[] speed;

        GaleStreaks(Vec3 origin, Vec3 look, int n) {
            super(9);
            this.origin = origin;
            RandomSource r = Vfx.random();
            int count = Math.max(1, Vfx.count(n));
            this.dirs = new Vec3[count];
            this.speed = new float[count];
            for (int i = 0; i < count; i++) {
                dirs[i] = look.add(ShazamFx.randomDir(r).scale(0.2)).normalize();
                speed[i] = 1.3f + r.nextFloat() * 0.6f;
            }
        }

        @Override
        public void renderSoft(Draw d) {
            float t = age + d.partialTick;
            float fade = Mth.clamp(1f - t / life, 0f, 1f);
            for (int i = 0; i < dirs.length; i++) {
                double head = 0.6 + t * speed[i], tail = Math.max(0.3, head - 1.8);
                Vec3 a = origin.add(dirs[i].scale(tail)), b = origin.add(dirs[i].scale(head));
                d.line(a.x, a.y, a.z, b.x, b.y, b.z, 0f, 0.045f, 0xFFFFFF, 0f, 0.5f * fade);
            }
        }
    }

    // ------------------------------------------------------------------ 0.37 Kombo Langit (Shift + Z)

    /** Merunduk, melesat ke sasaran (bayangan gerak, terowongan udara), lalu uppercut: udara terdorong ke atas. */
    private static void comboDash(AbstractClientPlayer caster, Vec3 pos, boolean self) {
        int w = ShazamAnim.COMBO_DASH_WINDUP;
        schedule(0, w, (level, t) -> ShazamFx.swirlDust(level, caster, t));
        schedule(w, 1, (level, t) -> {
            Vec3 start = chest(caster);
            Vec3 stop = pos.add(0, 0.9 * caster.getScale(), 0);
            Vec3 dir = stop.subtract(start);
            if (dir.lengthSqr() > 1.0E-4) {
                Vfx.add(new Fx.Ripple(start, dir.normalize(), dir.length(), 0.5, 1.4, 0.12, AIR, 8, 0.5f, true));
            }
            ShazamFx.dustPuffs(level, caster.position(), DUST, 8, 0.8, 0.14);
            ShazamPoses.ghostBurst(caster, ShazamAnim.COMBO_DASH_TICKS + 4);
            if (self) {
                FovKick.kick(0.35f);
                ScreenFx.speedLines(0.7f);
            }
        });
        schedule(ShazamAnim.COMBO_UPPERCUT, 1, (level, t) -> {   // uppercut: udara di atas sasaran terdorong naik
            Vec3 hit = pos.add(0, 1.2, 0);
            Vfx.add(new Fx.Ripple(hit, UP, 3.0, 0.4, 1.6, 0.14, AIR, 10, 0.6f, true));
            Vfx.add(new Fx.Cone(hit, UP, 3.0, 0.7, AIR, 9, 0.35f, 2.0, true));
            RandomSource r = level.random;
            for (int i = 0, n = Vfx.count(8); i < n; i++) {
                Vfx.smoke(hit.x, hit.y, hit.z, (r.nextDouble() - 0.5) * 0.1, 0.35 + r.nextDouble() * 0.3, (r.nextDouble() - 0.5) * 0.1,
                        AIR, 0.25f, 10);
            }
            ShazamFx.shakeAround(hit, 0.35f, 16);
        });
    }

    /** Menyusul ke atas sasaran secepat kilat: bayangan gerak & jejak uap. */
    private static void comboRise(AbstractClientPlayer caster, Vec3 pos) {
        ShazamPoses.ghostBurst(caster, ShazamAnim.COMBO_RISE_TICKS + 3);
        schedule(0, 1, (level, t) -> {
            Vec3 a = chest(caster);
            RandomSource r = level.random;
            for (int i = 0, n = Vfx.count(10); i < n; i++) {
                Vec3 p = a.lerp(pos, r.nextDouble()).add(ShazamFx.randomDir(r).scale(0.25));
                Vfx.smoke(p.x, p.y, p.z, 0, 0.02, 0, AIR, 0.28f, 10 + r.nextInt(5));
            }
        });
    }

    /** Dua kepalan menghantam ke bawah: udara terdorong ke bawah (hantaman tanahnya dari LINTANG_SLAM). */
    private static void comboSmash(AbstractClientPlayer caster, boolean self) {
        ShazamPoses.ghostBurst(caster, ShazamAnim.COMBO_SMASH_TICKS + 3);
        schedule(0, 1, (level, t) -> {
            Vec3 c = chest(caster).add(0, -0.6, 0);
            Vec3 down = new Vec3(0, -1, 0);
            Vfx.add(new Fx.Ripple(c, down, 3.5, 0.5, 2.0, 0.16, AIR, 10, 0.6f, true));
            Vfx.add(new Fx.Cone(c, down, 4.0, 0.8, AIR, 10, 0.4f, 2.0, true));
            if (self) {
                FovKick.punch(0.4f);
                CameraShake.add(0.3f);
            }
        });
    }

    // ------------------------------------------------------------------ 0.37 Ledakan Surya (Shift + R)

    /**
     * Ledakan Surya: 3 detik mengumpulkan panas matahari - udara di sekeliling badan beriak makin kuat, debu tersedot
     * berputar, kerikil terangkat, tanah di bawahnya retak & memerah panas - lalu meledak seperti bom: kilatan panas,
     * gelombang kejut raksasa, kawah, puing, dan kepulan asap yang membubung tinggi.
     */
    private static void nova(AbstractClientPlayer caster, boolean self) {
        int w = ShazamAnim.SOLAR_NOVA_WINDUP;
        if (self) {
            ScreenFx.vignette(0.5f, 0x401808, w);
        }
        schedule(0, w, (level, t) -> {
            float k = t / (float) w;
            RandomSource r = level.random;
            Vec3 c = chest(caster);
            Vec3 f = caster.position();
            boolean low = nearGround(level, caster, 1.5);
            if (t % 4 == 0) {
                Vfx.add(new Fx.Ripple(c, UP, 0.0, 0.5, 1.4 + 2.5 * k, 0.07, AIR, 9, 0.2f + 0.3f * k, true));
            }
            for (int i = 0, n = Vfx.count(1 + 4 * k); i < n; i++) {   // debu (di darat) / uap (di udara) tersedot berputar
                double a = r.nextDouble() * Math.PI * 2.0, rr = 2.5 + r.nextDouble() * 4.0;
                double tang = 0.12 + 0.2 * k, in = 0.08 + 0.12 * k;
                double y = low ? f.y + 0.1 + r.nextDouble() * 0.5 : c.y + (r.nextDouble() - 0.5) * 2.0;
                Vfx.dust(f.x + Math.cos(a) * rr, y, f.z + Math.sin(a) * rr,
                        -Math.cos(a) * in - Math.sin(a) * tang, low ? 0.03 + 0.06 * k : (c.y - y) * 0.04, -Math.sin(a) * in + Math.cos(a) * tang,
                        low ? DUST : AIR, 0.3f + r.nextFloat() * 0.3f, 16);
            }
            if (low && t % 3 == 0 && k > 0.3f) {   // kerikil kecil melayang naik
                double a = r.nextDouble() * Math.PI * 2.0, rr = 1.5 + r.nextDouble() * 3.0;
                Vfx.dust(f.x + Math.cos(a) * rr, f.y + 0.1, f.z + Math.sin(a) * rr, 0, 0.08 + 0.1 * k, 0, 0x6A5E50, 0.12f, 22);   // 0.38: kerikil (bukan butiran berkilau)
            }
            if (t == 20 || t == 40) {   // tanah retak makin lebar & memerah panas
                Ground.Map map = ShazamFx.ground(level, f, 6.0);
                if (map != null && map.found) {
                    Vfx.add(new Ground.Cracks(map.center(f), map, 8 + t / 5, t == 20 ? 2.5f : 4.5f, 160, 40, HEAT_MID, r.nextLong()));
                }
            }
            if (t % 10 == 0) {
                if (self) {
                    CameraShake.add(0.1f + 0.4f * k);
                } else {
                    ShazamFx.shakeAround(c, 0.1f + 0.3f * k, 24);
                }
            }
        });
        schedule(w, 1, (level, t) -> novaBlast(level, caster, self));
    }

    private static void novaBlast(ClientLevel level, AbstractClientPlayer caster, boolean self) {
        if (!caster.isAlive() || caster.isRemoved()) {
            return;   // ledakan dibatalkan di server kalau Lintang tumbang selama ancang-ancang
        }
        Vec3 c = chest(caster);
        Vec3 f = caster.position();
        Vfx.add(new Fx.Flash(c, 3.5f, 0xFFF6E8, 4, 0.7f));   // kilatan panas ledakan (singkat & kecil, bukan bola cahaya)
        Vfx.add(new Fx.Flash(c, 7.0f, HEAT_MID, 12, 0.4f));
        airShock(c, UP, 24.0, 30, 0.9f);   // dinding debu di tanah dari LintangCine (CineKit.shock)
        Ground.Map map = ShazamFx.ground(level, f, 22.0);
        boolean grounded = map != null && map.found;
        if (grounded) {
            Vec3 g = map.center(f);
            int dust = map.dustColor(level, f);
            Vfx.add(new Fx.Scorch(g, 7.0, 300, 80, map));
            Vfx.add(new Ground.Cracks(g, map, 16, 9.0f, 260, 90, HEAT_MID, level.random.nextLong()));
            Vfx.add(new Ground.Debris(g, map, 28, 0.35, 0.6, 3.0, 70));
            ShazamFx.smokeCloud(level, f, dust, 20, 6.0);
        } else {
            ShazamFx.smokeCloud(level, c, 0x6A5E54, 14, 4.0);
        }
        double base = grounded ? 1.0 : 0.0;
        double top = grounded ? 10.0 : 3.0;
        schedule(2, 50, (lv, t) -> {   // di darat: tiang asap membubung lalu melebar di puncak; di udara: kepulan yang naik pelan
            RandomSource r = lv.random;
            double h = grounded ? base + t * 0.32 : Math.min(top, t * 0.08);
            if (grounded || t < 14) {
                for (int i = 0, n = Vfx.count(3); i < n; i++) {
                    double a = r.nextDouble() * Math.PI * 2.0, rr = r.nextDouble() * (0.8 + h * 0.08);
                    Vfx.smoke(f.x + Math.cos(a) * rr, f.y + h, f.z + Math.sin(a) * rr, Math.cos(a) * 0.02, 0.12, Math.sin(a) * 0.02,
                            i % 2 == 0 ? 0x5A5048 : 0x7A6A5C, 0.9f + r.nextFloat() * 0.6f, 50 + r.nextInt(20));
                }
            }
            if (h >= top && t % 2 == 0) {
                for (int i = 0, n = Vfx.count(4); i < n; i++) {
                    double a = r.nextDouble() * Math.PI * 2.0;
                    Vfx.smoke(f.x + Math.cos(a) * 1.5, f.y + h, f.z + Math.sin(a) * 1.5, Math.cos(a) * 0.12, 0.02, Math.sin(a) * 0.12,
                            0x6A5A4C, 1.1f + r.nextFloat() * 0.6f, 60 + r.nextInt(20));
                }
            }
        });
        ShazamFx.shakeAround(c, 2.0f, 60);
        if (self) {
            ScreenFlash.flash(0.7f, 0xFFF4E8);
            FovKick.punch(1.0f);
            CameraShake.add(1.2f);
        } else {
            flashNear(c, 0.6f, 0xFFF4E8, 60);
        }
    }
}
