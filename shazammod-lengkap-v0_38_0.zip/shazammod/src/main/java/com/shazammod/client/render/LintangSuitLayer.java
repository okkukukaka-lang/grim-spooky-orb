package com.shazammod.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamMod;

import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.HumanoidArm;

/**
 * 0.38 Kostum Lintang (desain orisinal, bukan kostum Superman): kain biru minyak tua bertekstur halus dengan panel samping
 * grafit berbentuk V, list perak, sabuk perak bergesper cakram matahari, sarung tangan & sepatu bot grafit. Digambar di
 * atas badan, lengan, dan kaki (bentuk lapisan luar kulit, 0,25 piksel lebih besar), kepala tetap kulit asli pemain.
 * Lapisan luar kulit pemain (jaket, lengan baju, celana) disembunyikan selama kostum dipakai supaya nggak bertumpuk.
 * Tekstur 256x256 dengan tata letak UV kulit 64x64 (lihat tools/textures/lintang_suit.py).
 */
public class LintangSuitLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    public static final ResourceLocation SUIT = ShazamMod.id("textures/entity/lintang/suit.png");

    public LintangSuitLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    /** Kostum sedang dipakai: berubah jadi Lintang (kostum terpasang di akhir putaran ganti baju), dan terlihat. */
    public static boolean worn(AbstractClientPlayer player) {
        return !player.isInvisible() && ShazamClientState.isTransformed(player.getId())
                && ShazamClientState.isLintang(player.getId());
    }

    /** Dipanggil dari RenderPlayerEvent.Pre: lapisan luar kulit disembunyikan (kostum menggantikannya). */
    public static void hideOuter(PlayerModel<AbstractClientPlayer> m) {
        m.jacket.visible = false;
        m.rightSleeve.visible = false;
        m.leftSleeve.visible = false;
        m.rightPants.visible = false;
        m.leftPants.visible = false;
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buffers, int light, AbstractClientPlayer player, float limbSwing,
                       float limbAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        try {
            if (!worn(player)) {
                return;
            }
            PlayerModel<AbstractClientPlayer> m = getParentModel();
            VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(SUIT));
            int overlay = LivingEntityRenderer.getOverlayCoords(player, 0f);   // ikut memerah saat terluka
            draw(m.jacket, m.body, ps, vc, light, overlay);
            draw(m.rightSleeve, m.rightArm, ps, vc, light, overlay);
            draw(m.leftSleeve, m.leftArm, ps, vc, light, overlay);
            draw(m.rightPants, m.rightLeg, ps, vc, light, overlay);
            draw(m.leftPants, m.leftLeg, ps, vc, light, overlay);
        } catch (Throwable ignored) {
            // lapisan kostum nggak boleh bikin game crash
        }
    }

    /** Gambar kostum di bentuk lapisan luar (posenya sudah disalin dari bagian dasarnya oleh PlayerModel). */
    private static void draw(ModelPart outer, ModelPart base, PoseStack ps, VertexConsumer vc, int light, int overlay) {
        if (!base.visible) {
            return;
        }
        boolean was = outer.visible;
        outer.visible = true;
        outer.render(ps, vc, light, overlay);
        outer.visible = was;
    }

    /**
     * Tangan orang pertama (RenderArmEvent): lengan kulit asli + lengan kostum & sarung tangan, tanpa lengan baju kulit.
     * Sama seperti PlayerRenderer.renderHand bawaan, cuma lapisan luarnya diganti tekstur kostum.
     */
    public static void renderFirstPersonArm(PlayerRenderer renderer, PoseStack ps, MultiBufferSource buffers, int light,
                                            AbstractClientPlayer player, HumanoidArm arm) {
        PlayerModel<AbstractClientPlayer> m = renderer.getModel();
        m.attackTime = 0f;
        m.crouching = false;
        m.swimAmount = 0f;
        m.setupAnim(player, 0f, 0f, 0f, 0f, 0f);
        boolean right = arm == HumanoidArm.RIGHT;
        ModelPart base = right ? m.rightArm : m.leftArm;
        ModelPart outer = right ? m.rightSleeve : m.leftSleeve;
        boolean baseWas = base.visible, outerWas = outer.visible;
        base.visible = true;
        outer.visible = true;
        base.xRot = 0f;
        base.render(ps, buffers.getBuffer(RenderType.entitySolid(player.getSkin().texture())), light, OverlayTexture.NO_OVERLAY);
        outer.xRot = 0f;
        outer.render(ps, buffers.getBuffer(RenderType.entityCutoutNoCull(SUIT)), light, OverlayTexture.NO_OVERLAY);
        base.visible = baseWas;
        outer.visible = outerWas;
    }
}
