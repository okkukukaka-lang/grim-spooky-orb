"""Tekstur PRALAYA, Sang Mesin Kiamat (0.51, desain orisinal, robot/AI — bukan magis).

Android berangka logam gunmetal gelap: pelat berbaut, garis panel, ventilasi, sambungan sendi, sirkuit tipis, satu
PITA OPTIK merah menyilang wajah (bukan mata manusia), dan REAKTOR INTI merah heksagonal di dada. Tanpa topeng gading,
tanpa mahkota, tanpa batik. Jubah diganti mantel pelat logam. Warna subsistem (dipakai drone & HUD) di AksaraSkills.RGB.

    python3 aksara_textures.py ASSETS_DIR [PREVIEW.png]

Menulis (tata letak UV pemain 64x64, skala 4):
  textures/entity/aksara/skin.png        256x256  rangka logam (base) — lapisan luar dikosongkan (robot tanpa kain)
  textures/entity/aksara/glow.png        256x256  optik, inti reaktor, sirkuit (mask intensitas; diberi warna merah di AksaraLayer)
  textures/entity/aksara/gold.png        16x16    logam trim (gunmetal sikat) untuk mahkota antena, ventilasi, cincin drone
  textures/entity/aksara/plate.png       16x16    pelat polos (diberi warna di kode: baja, grafit, inti)
  textures/entity/aksara/cape_cloth.png  64x128   mantel pelat logam gelap bergaris merah (bukan batik)
  textures/entity/aksara_emblem.png      32x32    lambang heksagon bahaya (reaktor)
  textures/item/lontar_sabda.png         16x16    ikon Inti Pralaya (bola logam gelap, enam lampu subsistem)
"""
import os
import sys

import numpy as np
from PIL import Image

S = 4
N = 64 * S
rng = np.random.default_rng(51)

STEEL = np.array([52, 57, 66], float)
STEEL_HI = np.array([96, 104, 118], float)
STEEL_DK = np.array([22, 24, 30], float)
EDGE = np.array([132, 140, 156], float)
DARK = np.array([30, 32, 40], float)
RED = np.array([255, 46, 52], float)
RED_HOT = np.array([255, 224, 214], float)
CORE = np.array([255, 70, 60], float)
SUB = [np.array(c, float) for c in ((255, 48, 72), (138, 108, 255), (64, 230, 255), (255, 79, 200), (255, 184, 64),
                                     (92, 255, 160))]


def noise(h, w, cell, amp):
    gh, gw = h // cell + 2, w // cell + 2
    g = rng.random((gh, gw))
    yy, xx = np.mgrid[0:h, 0:w]
    fy, fx = yy / cell, xx / cell
    y0, x0 = fy.astype(int), fx.astype(int)
    ty, tx = fy - y0, fx - x0
    ty, tx = ty * ty * (3 - 2 * ty), tx * tx * (3 - 2 * tx)
    a = g[y0, x0] * (1 - tx) + g[y0, x0 + 1] * tx
    b = g[y0 + 1, x0] * (1 - tx) + g[y0 + 1, x0 + 1] * tx
    return (a * (1 - ty) + b * ty - 0.5) * 2 * amp


def seg_dist(x, y, ax, ay, bx, by):
    dx, dy = bx - ax, by - ay
    L2 = dx * dx + dy * dy + 1e-9
    t = np.clip(((x - ax) * dx + (y - ay) * dy) / L2, 0, 1)
    return np.hypot(x - (ax + t * dx), y - (ay + t * dy))


class Face:
    """Satu sisi kubus model (w x h piksel model, digambar S kali lebih rapat)."""

    def __init__(self, w, h, base=STEEL):
        self.w, self.h = w, h
        ys, xs = np.mgrid[0:h * S, 0:w * S]
        self.x, self.y = (xs + 0.5) / S, (ys + 0.5) / S
        hh, ww = self.x.shape
        k = 1.0 + noise(hh, ww, 3, 0.06) + noise(hh, ww, 9, 0.06)
        self.rgb = np.clip(base[None, None] * k[..., None], 0, 255)
        self.alpha = np.full((hh, ww), 255.0)
        self.glow = np.zeros((hh, ww))

    def shade(self, edge=0.26, top=0.12):
        u = (self.x / self.w) * 2 - 1
        v = self.y / self.h
        k = 1.0 - edge * np.abs(u) ** 2.2 + top * (0.5 - v)
        self.rgb = np.clip(self.rgb * k[..., None], 0, 255)

    def clear(self):
        self.alpha[:] = 0.0

    def rect(self, x0, y0, x1, y1, col):
        m = (self.x >= x0) & (self.x < x1) & (self.y >= y0) & (self.y < y1)
        self.rgb = np.where(m[..., None], col, self.rgb)
        return m

    def seam(self, pts, width=0.12):
        """Garis panel gelap berbevel: celah gelap + tepi terang di satu sisi (kesan pelat timbul)."""
        m = np.zeros_like(self.x)
        for (ax, ay), (bx, by) in zip(pts[:-1], pts[1:]):
            m = np.maximum(m, np.clip(1 - seg_dist(self.x, self.y, ax, ay, bx, by) / width, 0, 1))
        groove = m > 0.3
        self.rgb = np.where(groove[..., None], STEEL_DK, self.rgb)
        hi = (m > 0.1) & (m <= 0.3)
        self.rgb = np.where(hi[..., None], np.clip(self.rgb * 1.25, 0, 255), self.rgb)

    def panel(self, x0, y0, x1, y1, raise_=0.12):
        """Pelat timbul: isi sedikit lebih terang, dikelilingi alur."""
        inside = (self.x >= x0) & (self.x < y1 * 0 + x1) & (self.y >= y0) & (self.y < y1)
        self.rgb = np.where(inside[..., None], np.clip(self.rgb * (1 + raise_), 0, 255), self.rgb)
        self.seam([(x0, y0), (x1, y0), (x1, y1), (x0, y1), (x0, y0)], 0.1)

    def bolt(self, cx, cy, r=0.4):
        d = np.hypot(self.x - cx, self.y - cy)
        self.rgb = np.where((d < r)[..., None], STEEL_DK, self.rgb)
        self.rgb = np.where((np.abs(d - r * 0.6) < 0.12)[..., None], EDGE, self.rgb)

    def vent(self, x0, y0, x1, y1, n=4):
        for i in range(n):
            yy = y0 + (i + 0.5) / n * (y1 - y0)
            self.rect(x0, yy - 0.12, x1, yy + 0.12, STEEL_DK)
            self.rect(x0, yy + 0.12, x1, yy + 0.2, EDGE * 0.6)

    def circuit(self, pts, width=0.08, glow=0.55):
        """Jalur sirkuit tipis yang menyala (ke glow, diberi warna merah di AksaraLayer)."""
        m = np.zeros_like(self.x)
        for (ax, ay), (bx, by) in zip(pts[:-1], pts[1:]):
            m = np.maximum(m, np.clip(1 - seg_dist(self.x, self.y, ax, ay, bx, by) / width, 0, 1))
        hard = m > 0.3
        self.rgb = np.where(hard[..., None], np.array([90, 30, 32], float), self.rgb)
        self.glow = np.maximum(self.glow, (m ** 1.3) * glow)

    def node(self, cx, cy, r=0.3, glow=1.0):
        d = np.hypot(self.x - cx, self.y - cy)
        self.rgb = np.where((d < r)[..., None], RED_HOT, self.rgb)
        self.glow = np.maximum(self.glow, np.clip(1 - d / (r * 2.2), 0, 1) ** 1.2 * glow)

    def optic(self, cx, cy, w, h, glow=1.0):
        """Pita optik merah menyilang (mata robot)."""
        d = np.hypot((self.x - cx) / w, (self.y - cy) / h)
        band = d < 1
        self.rgb = np.where(band[..., None], np.array([40, 10, 12], float), self.rgb)
        hot = d < 0.6
        self.rgb = np.where(hot[..., None], RED_HOT, self.rgb)
        self.glow = np.maximum(self.glow, np.clip(1 - d, 0, 1) ** 0.7 * glow)
        # bingkai pita
        frame = (np.abs(d - 1.08) < 0.12)
        self.rgb = np.where(frame[..., None], EDGE, self.rgb)

    def reactor(self, cx, cy, r, glow=1.0):
        """Reaktor inti heksagonal merah di dada."""
        ang = np.arctan2(self.y - cy, self.x - cx)
        hexr = r / np.cos((ang % (np.pi / 3)) - np.pi / 6)
        d = np.hypot(self.x - cx, self.y - cy)
        ring = np.abs(d - hexr) < 0.3
        self.rgb = np.where(ring[..., None], EDGE, self.rgb)
        inner = d < hexr - 0.3
        self.rgb = np.where(inner[..., None], np.array([60, 16, 16], float), self.rgb)
        hub = d < r * 0.45
        self.rgb = np.where(hub[..., None], RED_HOT, self.rgb)
        self.glow = np.maximum(self.glow, np.where(inner, np.clip(1 - d / hexr, 0, 1) ** 0.8, 0) * glow)
        self.glow = np.maximum(self.glow, hub * glow)
        for k in range(6):   # jari-jari ke tiap sudut
            a = k * np.pi / 3
            self.circuit([(cx, cy), (cx + np.cos(a) * r, cy + np.sin(a) * r)], 0.09, glow * 0.7)


def put(img, glow, u, v, f):
    hh, ww = f.x.shape
    y0, x0 = v * S, u * S
    img[y0:y0 + hh, x0:x0 + ww, :3] = np.clip(f.rgb, 0, 255)
    img[y0:y0 + hh, x0:x0 + ww, 3] = f.alpha
    glow[y0:y0 + hh, x0:x0 + ww] = np.maximum(glow[y0:y0 + hh, x0:x0 + ww], f.glow)


def box(img, glow, u, v, w, h, d, faces):
    top, bottom, right, front, left, back = faces
    put(img, glow, u + d, v, top)
    put(img, glow, u + d + w, v, bottom)
    put(img, glow, u, v + d, right)
    put(img, glow, u + d, v + d, front)
    put(img, glow, u + d + w, v + d, left)
    put(img, glow, u + d + w + d, v + d, back)


def six(w, h, d):
    return [Face(w, d), Face(w, d), Face(d, h), Face(w, h), Face(d, h), Face(w, h)]


# ------------------------------------------------------------------ bagian badan

def head_faces(outer):
    f = six(8, 8, 8)
    top, bottom, right, front, left, back = f
    if outer:
        for x in f:
            x.clear()
        return f
    for face in f:
        face.shade(0.22, 0.1)
    # muka: helm logam dengan satu pita optik merah menyilang, rahang berpelat, garis panel
    front.rect(0, 0, 8, 2.4, STEEL_HI)             # dahi
    front.seam([(0, 2.4), (8, 2.4)], 0.1)
    front.optic(4.0, 3.5, 3.5, 0.75, 1.0)          # pita optik
    front.rect(0, 5.2, 8, 8, STEEL)                # rahang/pelat mulut
    front.seam([(2.6, 5.2), (2.6, 8)], 0.09)
    front.seam([(5.4, 5.2), (5.4, 8)], 0.09)
    front.vent(3.0, 6.2, 5.0, 7.6, 3)              # grill mulut
    front.bolt(0.9, 1.1); front.bolt(7.1, 1.1)
    for side in (right, left):                     # sisi kepala: panel & ventilasi + sirkuit
        side.rect(0, 0, 8, 8, STEEL)
        side.panel(1.0, 1.2, 7.0, 6.6, 0.1)
        side.vent(2.0, 2.0, 6.0, 5.6, 4)
        side.bolt(1.0, 7.0); side.bolt(7.0, 7.0)
        side.circuit([(0.5, 4.0), (3.0, 4.0), (3.0, 6.5)], 0.08, 0.5)
    top.rect(0, 0, 8, 8, STEEL_HI)
    top.seam([(4, 0), (4, 8)], 0.1)
    top.seam([(0, 4), (8, 4)], 0.1)
    top.node(4.0, 4.0, 0.5, 0.7)                   # dudukan antena (antena 3D di Geo)
    back.rect(0, 0, 8, 8, STEEL)
    back.vent(1.5, 1.5, 6.5, 6.5, 6)               # ventilasi tengkuk
    back.bolt(1.0, 1.0); back.bolt(7.0, 1.0); back.bolt(1.0, 7.0); back.bolt(7.0, 7.0)
    return f


def body_faces(outer):
    f = six(8, 12, 4)
    top, bottom, right, front, left, back = f
    if outer:
        for x in f:
            x.clear()
        return f
    for face in f:
        face.shade(0.24, 0.1)
    # dada: reaktor inti heksagonal, pelat dada kiri-kanan, panel perut bersegmen, sirkuit turun ke inti
    front.panel(0.6, 0.8, 3.4, 5.0, 0.12)
    front.panel(4.6, 0.8, 7.4, 5.0, 0.12)
    front.reactor(4.0, 6.0, 1.9, 1.0)
    for yy in (8.0, 9.4, 10.8):                    # perut bersegmen
        front.seam([(1.6, yy), (6.4, yy)], 0.1)
    front.rect(1.6, 7.2, 6.4, 11.8, STEEL)
    front.circuit([(2.0, 2.0), (2.0, 6.0), (2.2, 6.0)], 0.08, 0.45)
    front.circuit([(6.0, 2.0), (6.0, 6.0), (5.8, 6.0)], 0.08, 0.45)
    front.bolt(0.9, 1.1); front.bolt(7.1, 1.1); front.bolt(0.9, 11.0); front.bolt(7.1, 11.0)
    # punggung: rig drone (kotak gelap timbul) + rel & ventilasi
    back.rect(0, 0, 8, 12, STEEL)
    back.panel(2.4, 1.0, 5.6, 5.0, 0.14)           # mount rig
    back.vent(2.8, 1.6, 5.2, 4.4, 4)
    for sx in (0.5, 7.5):
        back.circuit([(sx, 1.0), (sx, 11.0)], 0.1, 0.4)
    back.node(4.0, 3.0, 0.45, 0.8)
    back.bolt(1.0, 6.5); back.bolt(7.0, 6.5)
    for side in (right, left):
        side.panel(0.4, 1.0, 3.6, 11.0, 0.1)
        side.vent(1.0, 3.0, 3.0, 8.0, 5)
    return f


def limb_faces(outer, arm):
    f = six(4, 12, 4)
    top, bottom, right, front, left, back = f
    if outer:
        for x in f:
            x.clear()
        return f
    for face in f:
        face.shade(0.28, 0.08)
    joint = 5.2 if arm else 6.4                    # garis sendi (siku/lutut)
    for face in (front, back, right, left):
        face.panel(0.4, 0.4, 3.6, joint - 0.4, 0.12)      # pelat atas
        face.panel(0.4, joint + 0.4, 3.6, 11.6, 0.1)      # pelat bawah
        face.rect(0, joint - 0.4, 4, joint + 0.4, STEEL_DK)  # celah sendi
        face.rect(0.3, joint - 0.1, 3.7, joint + 0.1, EDGE * 0.7)
        face.circuit([(2.0, 0.6), (2.0, joint - 0.6)], 0.07, 0.4)
        face.node(2.0, joint, 0.3, 0.7)            # lampu sendi
        face.bolt(1.0, 1.2); face.bolt(3.0, 1.2)
    if arm:
        front.vent(1.0, 8.0, 3.0, 11.0, 3)         # ventilasi lengan bawah
    else:
        front.rect(0.6, 10.8, 3.4, 12.0, STEEL_HI)  # telapak kaki
    return f


def skin(out):
    img = np.zeros((N, N, 4), float)
    glow = np.zeros((N, N))
    box(img, glow, 0, 0, 8, 8, 8, head_faces(False))
    box(img, glow, 32, 0, 8, 8, 8, head_faces(True))
    box(img, glow, 16, 16, 8, 12, 4, body_faces(False))
    box(img, glow, 16, 32, 8, 12, 4, body_faces(True))
    box(img, glow, 40, 16, 4, 12, 4, limb_faces(False, True))
    box(img, glow, 40, 32, 4, 12, 4, limb_faces(True, True))
    box(img, glow, 32, 48, 4, 12, 4, limb_faces(False, True))
    box(img, glow, 48, 48, 4, 12, 4, limb_faces(True, True))
    box(img, glow, 0, 16, 4, 12, 4, limb_faces(False, False))
    box(img, glow, 0, 32, 4, 12, 4, limb_faces(True, False))
    box(img, glow, 16, 48, 4, 12, 4, limb_faces(False, False))
    box(img, glow, 0, 48, 4, 12, 4, limb_faces(True, False))
    from scipy import ndimage
    soft = ndimage.gaussian_filter(glow, 1.5) * 1.5
    g = np.clip((glow + soft * 0.6) * 255, 0, 255)
    gimg = np.zeros((N, N, 4), np.uint8)
    gimg[..., 0] = g.astype(np.uint8)
    gimg[..., 1] = g.astype(np.uint8)
    gimg[..., 2] = g.astype(np.uint8)
    gimg[..., 3] = 255
    d = os.path.join(out, "textures/entity/aksara")
    os.makedirs(d, exist_ok=True)
    Image.fromarray(np.clip(img, 0, 255).astype(np.uint8), "RGBA").save(os.path.join(d, "skin.png"))
    Image.fromarray(gimg, "RGBA").save(os.path.join(d, "glow.png"))
    return img, gimg


def steel(out):
    """Logam trim 16x16: gunmetal sikat vertikal dengan highlight dingin (dipakai sebagai 'gold.png')."""
    n = 16
    ys, xs = np.mgrid[0:n, 0:n]
    v = (ys + 0.5) / n
    u = (xs + 0.5) / n
    brush = 1.0 + 0.1 * np.sin(u * 40) + noise(n, n, 2, 0.05)
    col = (STEEL_HI[None, None] * (1 - v[..., None]) ** 0.8 + STEEL[None, None] * v[..., None]) * brush[..., None]
    hi = np.abs(v - 0.3) < 0.07
    col = np.where(hi[..., None], EDGE, col)
    img = np.zeros((n, n, 4), np.uint8)
    img[..., :3] = np.clip(col, 0, 255).astype(np.uint8)
    img[..., 3] = 255
    Image.fromarray(img, "RGBA").save(os.path.join(out, "textures/entity/aksara/gold.png"))


def plate(out):
    """Pelat polos terang 16x16 (warnanya dari kode): bintik & gradasi halus."""
    n = 16
    ys, xs = np.mgrid[0:n, 0:n]
    v = (ys + 0.5) / n
    k = 0.9 + 0.1 * (1 - v) + noise(n, n, 2, 0.04) + noise(n, n, 5, 0.03)
    col = np.clip(230 * k, 0, 255)
    img = np.zeros((n, n, 4), np.uint8)
    img[..., :3] = col[..., None].astype(np.uint8)
    img[..., 3] = 255
    Image.fromarray(img, "RGBA").save(os.path.join(out, "textures/entity/aksara/plate.png"))


def cape(out):
    """Mantel 64x128: pelat logam gelap bersegmen horizontal, dua garis merah di tepi, baut."""
    w, h = 64, 128
    ys, xs = np.mgrid[0:h, 0:w]
    x, y = xs + 0.5, ys + 0.5
    base = DARK[None, None] * (1.0 + noise(h, w, 3, 0.06) + noise(h, w, 10, 0.05))[..., None]
    col = base.copy()
    for yy in range(14, h, 16):                    # segmen pelat horizontal
        band = np.abs(y - yy) < 1.2
        col = np.where(band[..., None], STEEL_DK, col)
        hi = (np.abs(y - (yy - 1.4)) < 0.6)
        col = np.where(hi[..., None], STEEL_HI, col)
    red = ((np.abs(x - 7) < 1.1) | (np.abs(x - (w - 8)) < 1.1)) & (y > 6)   # pita merah di kedua sisi
    col = np.where(red[..., None], RED, col)
    spine = np.abs(x - w / 2) < 1.0
    col = np.where(spine[..., None], STEEL_HI, col)
    for yy in range(20, h, 16):                    # baut
        for xx in (12, w - 12):
            col = np.where((np.hypot(x - xx, y - yy) < 1.4)[..., None], STEEL_DK, col)
    img = np.zeros((h, w, 4), np.uint8)
    img[..., :3] = np.clip(col, 0, 255).astype(np.uint8)
    img[..., 3] = 255
    Image.fromarray(img, "RGBA").save(os.path.join(out, "textures/entity/aksara/cape_cloth.png"))


def emblem(out):
    """Lambang 32x32: heksagon reaktor merah berbingkai baja."""
    n = 32
    ys, xs = np.mgrid[0:n, 0:n]
    x, y = (xs + 0.5), (ys + 0.5)
    cx = cy = 16.0
    ang = np.arctan2(y - cy, x - cx)
    r = 13.0
    hexr = r / np.cos((ang % (np.pi / 3)) - np.pi / 6)
    d = np.hypot(x - cx, y - cy)
    img = np.zeros((n, n, 4), np.uint8)
    inside = d < hexr
    img[..., 3] = np.where(inside, 255, 0).astype(np.uint8)
    col = np.where(inside[..., None], np.array([40, 14, 16], float), 0)
    ring = np.abs(d - hexr) < 1.4
    col = np.where(ring[..., None], EDGE, col)
    hub = d < 4.5
    col = np.where(hub[..., None], RED_HOT, col)
    for k in range(6):
        a = k * np.pi / 3
        bar = seg_dist(x, y, cx, cy, cx + np.cos(a) * r, cy + np.sin(a) * r) < 0.9
        col = np.where(bar[..., None], RED, col)
    img[..., :3] = np.clip(col, 0, 255).astype(np.uint8)
    Image.fromarray(img, "RGBA").save(os.path.join(out, "textures/entity/aksara_emblem.png"))


def core_item(out):
    """Ikon Inti Pralaya 16x16: bola logam gelap, cincin ekuator baja, enam lampu subsistem warna."""
    n = 16
    img = np.zeros((n, n, 4), float)
    ys, xs = np.mgrid[0:n, 0:n]
    x, y = xs + 0.5, ys + 0.5
    cx = cy = 8.0
    d = np.hypot(x - cx, y - cy)
    ball = d < 7.0
    shade = np.clip(1 - d / 7.0, 0, 1)
    body = DARK[None, None] * (0.5 + 0.9 * shade[..., None] ** 0.6)
    body = body + STEEL_HI[None, None] * np.clip(1 - np.hypot(x - 5.5, y - 5.5) / 3.0, 0, 1)[..., None] * 0.5  # sorot
    img[..., :3] = np.where(ball[..., None], body, 0)
    img[..., 3] = np.where(ball, 255, 0)
    ring = (np.abs(y - cy) < 0.8) & ball                    # cincin ekuator
    img[..., :3] = np.where(ring[..., None], EDGE, img[..., :3])
    for k in range(6):                                      # enam lampu subsistem
        a = -np.pi / 2 + k * np.pi / 3
        px, py = cx + np.cos(a) * 4.6, cy + np.sin(a) * 4.6
        m = np.hypot(x - px, y - py) < 1.0
        img[..., :3] = np.where(m[..., None], SUB[k], img[..., :3])
    hub = d < 1.6                                           # inti merah
    img[..., :3] = np.where(hub[..., None], RED_HOT, img[..., :3])
    out_dir = os.path.join(out, "textures/item")
    os.makedirs(out_dir, exist_ok=True)
    Image.fromarray(np.clip(img, 0, 255).astype(np.uint8), "RGBA").save(os.path.join(out_dir, "lontar_sabda.png"))


def preview(path, img, gimg):
    base = Image.fromarray(np.clip(img, 0, 255).astype(np.uint8), "RGBA")
    g = Image.fromarray(gimg, "RGBA")
    red = np.zeros_like(gimg)
    red[..., 0] = gimg[..., 0]
    red[..., 1] = (gimg[..., 0] * 0.15).astype(np.uint8)
    red[..., 2] = (gimg[..., 0] * 0.18).astype(np.uint8)
    red[..., 3] = 255
    combo = np.clip(img[..., :3] * 0.8 + red[..., :3].astype(float) * 1.0, 0, 255).astype(np.uint8)
    c = Image.fromarray(np.dstack([combo, np.clip(img[..., 3], 0, 255).astype(np.uint8)]), "RGBA")
    sheet = Image.new("RGBA", (N * 3 + 20, N), (36, 38, 46, 255))
    sheet.paste(base, (0, 0), base)
    sheet.paste(Image.fromarray(red, "RGBA"), (N + 10, 0))
    sheet.paste(c, (2 * N + 20, 0), c)
    sheet = sheet.resize((sheet.width * 2, sheet.height * 2), Image.NEAREST)
    sheet.save(path)


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "out"
    img, gimg = skin(out)
    steel(out)
    plate(out)
    cape(out)
    emblem(out)
    core_item(out)
    if len(sys.argv) > 2:
        preview(sys.argv[2], img, gimg)
    print("ok")
