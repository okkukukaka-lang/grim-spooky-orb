"""SFX PRALAYA, Sang Mesin Kiamat (0.51, robot/AI — bukan magis). Dibuat dari nol dengan synth.py.

    python3 tools/sfx/aksara_sfx.py src/main/resources/assets/shazammod/sounds [nama ...]

Ciri suaranya: MEKANIS & DIGITAL — servo/aktuator, dentang logam, dengung reaktor, bass sub, zap/glitch digital, dan
suara sintetis dingin yang terdistorsi (tanpa kata) untuk momen besar. Nama recipe & jumlahnya SAMA dengan versi lama
supaya names.txt/gen.py nggak berubah; cuma DSP-nya yang diganti. Puncaknya tetap dikunci ke tick ShazamAnim.AKSARA_*:

    aksara_transform 2,2 dtk | aksara_nova 1,1 | aksara_purna 1,7 | aksara_erase 3,2 | aksara_rite 7,5 | aksara_soul 2,4
    aksara_timestop 0,6 | aksara_lance 0,45 | aksara_beam mulai 0,4 | aksara_dominion 0,9 | aksara_rewrite 0,8
    aksara_fold 0,25 | aksara_gate 0,5 | aksara_ward 0,6 | aksara_rewind 0,5
Putar di pitch 1 supaya puncaknya nggak bergeser.
"""
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
_argv = sys.argv
sys.argv = [sys.argv[0]]
import synth as s                 # noqa: E402
sys.argv = _argv

SR = s.SR


# ------------------------------------------------------------------ alat bantu mekanis

def env(dur, tau):
    return s.env_exp(int(dur * SR), tau)


def crush(x, bits=6, rate=6000):
    """Bitcrush + penurunan sample-rate: bikin suara jadi digital/kasar."""
    step = 2.0 ** (bits - 1)
    y = np.round(np.clip(x, -1, 1) * step) / step
    hold = max(1, int(SR / rate))
    n = len(y)
    idx = (np.arange(n) // hold) * hold
    return y[np.clip(idx, 0, n - 1)]


def servo(dur, f0, f1, rng, amp=0.4, grit=0.3):
    """Aktuator: nada saw yang menyapu pitch + flutter amplitudo + sedikit noise gerigi."""
    n = int(dur * SR)
    t = np.arange(n) / SR
    f = np.geomspace(max(1.0, f0), max(1.0, f1), n)
    y = s.osc(f, dur, "saw") * (0.6 + 0.4 * np.sin(2 * np.pi * 42 * t))
    y = s.lp(y, 2600)
    g = s.bp(s.white(n, rng), 1500, 5000, 2) * grit
    e = np.minimum(1, t / 0.02) * np.minimum(1, (dur - t) / 0.05)
    return (y + g) * e * amp


def whine(dur, f0, f1, amp=0.3):
    """Spin-up/spin-down murni (sine naik/turun)."""
    n = int(dur * SR)
    t = np.arange(n) / SR
    f = np.geomspace(max(1.0, f0), max(1.0, f1), n)
    y = np.sin(2 * np.pi * np.cumsum(f) / SR) + 0.4 * np.sin(2 * np.pi * np.cumsum(f * 1.5) / SR)
    e = np.minimum(1, t / 0.02) * np.minimum(1, (dur - t) / 0.06)
    return y * e * amp


def clank(rng, f=520, dur=0.4, bright=1.0, tau=0.12):
    """Dentang logam: bell inharmonik + klik noise transient."""
    partials = ((1.0, 1.0), (1.42, 0.5 * bright), (2.31, 0.3 * bright), (3.17, 0.16 * bright), (4.9, 0.08 * bright))
    bell = s.bell(f, dur, rng, partials, tau, 0.001)
    click = s.bp(s.white(int(0.02 * SR), rng), 1800, 8000, 2) * env(0.02, 0.004) * 0.9
    return s.mix(bell * 0.7, click)


def boom(rng, f0=90, f1=34, dur=1.0, body=0.5, sub=0.6):
    """Hentakan sub-bass mekanis."""
    return s.thump(rng, f0, f1, dur, 0.1, body, sub)


def zap(dur, rng, lo=400, hi=6000, drop=True):
    """Zap digital: noise terfilter + nada turun, lalu di-bitcrush."""
    n = int(dur * SR)
    t = np.arange(n) / SR
    tone = s.osc(np.geomspace(1400, 300, n) if drop else np.geomspace(300, 1400, n), dur, "square") * 0.3
    nz = s.bp(s.white(n, rng), lo, hi, 2) * 0.5
    y = crush((tone + nz) * env(dur, dur / 3), 5, 7000)
    return y


def charge(dur, f0=120, f1=1200, amp=0.4):
    """Pengisian daya: saw naik + filter membuka + flutter, makin keras."""
    n = int(dur * SR)
    t = np.arange(n) / SR
    y = s.osc(np.geomspace(f0, f1, n), dur, "saw")
    y = s.sweep_filter(y, np.geomspace(400, 5000, n), "low", 1.4)
    y = y * (t / dur) ** 2 * (0.7 + 0.3 * np.sin(2 * np.pi * 30 * t))
    return y * amp


def reactorhum(dur, f=70, amp=0.22):
    """Dengung reaktor kontinu (dua saw berselisih tipis + filter)."""
    n = int(dur * SR)
    t = np.arange(n) / SR
    y = s.osc(f, dur, "saw") + s.osc(f * 1.004, dur, "saw") + s.osc(f * 2, dur, "saw") * 0.4
    y = s.lp(y, 900) * (1 + 0.15 * np.sin(2 * np.pi * 7 * t))
    e = np.minimum(1, t / 0.1) * np.minimum(1, (dur - t) / 0.2)
    return y * e * amp


def glitch(dur, rng, amp=0.4):
    """Semburan glitch digital yang ter-gate acak."""
    n = int(dur * SR)
    y = s.bp(s.white(n, rng), 300, 9000, 2)
    gate = np.zeros(n)
    i = 0
    while i < n:
        seg = rng.integers(int(0.005 * SR), int(0.04 * SR))
        if rng.random() < 0.55:
            gate[i:i + seg] = rng.uniform(0.3, 1.0)
        i += seg
    return crush(y * gate, 4, 5000) * amp


def voice(dur, rng, base=120, menace=1.0, amp=0.26):
    """Suara sintetis dingin tanpa kata (saw detune + formant bandpass + soft clip): aura AI yang mengancam."""
    n = int(dur * SR)
    t = np.arange(n) / SR
    vib = 1 + 0.01 * np.sin(2 * np.pi * 5.5 * t)
    y = sum(s.osc(base * r * vib, dur, "saw") for r in (0.5, 1.0, 1.5 * menace)) / 3
    f1 = s.bp(y, 350, 700, 2)
    f2 = s.bp(y, 1100, 2100, 2) * 0.7
    y = np.tanh((f1 + f2) * 2.2)
    e = s.env_adsr(dur, 0.2, 0.2, 0.8, 0.5)
    return y * e * amp


def static_bed(dur, rng, lo=80, hi=12000, amp=0.5):
    return s.bp(s.white(int(dur * SR), rng), lo, hi, 2) * env(dur, dur / 3) * amp


def place(total, *items):
    out = np.zeros(int(total * SR))
    for sec, x in items:
        i = int(sec * SR)
        if i >= len(out):
            continue
        e = min(len(out), i + len(x))
        out[i:e] += x[:e - i]
    return out


def tape(x, f0=1.0, f1=0.25):
    """Pita melambat (untuk Stasis): nada & tempo turun bersamaan."""
    n = len(x)
    speed = np.geomspace(f0, f1, n)
    pos = np.cumsum(speed)
    pos = pos[pos < n - 1]
    return np.interp(pos, np.arange(n), x)


# ------------------------------------------------------------------ resep

def aksara_transform(rng, v):
    total, hit = 3.6, 2.2
    parts = [(0.0, servo(hit, 200, 900, rng, 0.3)), (0.0, charge(hit, 80, 400, 0.4)),
             (0.0, reactorhum(total, 70, 0.18))]
    for i in range(6):                              # enam drone mengunci
        parts.append((0.5 + i * 0.26, clank(rng, 400 + i * 80, 0.35, 1.0)))
    parts.append((hit, boom(rng, 90, 30, 2.0, 0.6, 0.8) * 1.4))
    parts.append((hit, clank(rng, 240, 1.2, 1.3, 0.3) * 1.2))
    parts.append((hit, static_bed(0.8, rng, 200, 9000, 0.5)))
    parts.append((hit, voice(1.6, rng, 90, 1.0, 0.3)))
    parts.append((hit - 0.4, whine(0.4, 300, 1600, 0.3)))
    return s.reverb(place(total, *parts), 1.6, 0.22, rng=rng)


def aksara_revert(rng, v):
    parts = [(0.0, whine(1.0, 900, 120, 0.35)), (0.0, reactorhum(1.2, 60, 0.12) * np.linspace(1, 0, int(1.2 * SR)))]
    for i in range(6):
        parts.append((i * 0.09, clank(rng, 520 - i * 40, 0.25, 0.7, 0.08)))
    return s.reverb(place(1.6, *parts), 1.4, 0.2, rng=rng)


def aksara_pulse(rng, v):
    base = 480 + v * 120
    parts = [(i * 0.05, clank(rng, base + i * 50, 0.2, 0.6, 0.06) * 0.4) for i in range(4)]
    parts.append((0.0, servo(0.5, 300, 360, rng, 0.12, 0.1)))
    return s.reverb(place(0.9, *parts), 0.9, 0.16, rng=rng)


def aksara_punch(rng, v):
    hit = s.mix(boom(rng, 130, 60, 0.4, 0.3, 0.5) * 0.9, clank(rng, 300, 0.3, 1.0, 0.07))
    return s.reverb(place(0.6, (0.0, hit), (0.0, zap(0.2, rng, 600, 7000) * 0.4)), 0.7, 0.16, rng=rng)


def aksara_sixfold(rng, v):
    total = 1.6
    hiss = whine(0.3, 200, 900, 0.25)              # piston hidrolik
    slam = s.mix(boom(rng, 80, 30, 1.0, 0.4, 0.9) * 1.3, clank(rng, 180, 0.8, 1.4, 0.2) * 1.2)
    metal = static_bed(0.4, rng, 300, 8000, 0.6)
    return s.reverb(place(total, (0.0, hiss), (0.3, slam), (0.3, metal), (0.3, glitch(0.4, rng, 0.3))), 1.4, 0.24, rng=rng)


def aksara_beam(rng, v):
    total, start, end = 2.6, 0.4, 2.0
    pre = charge(start, 200, 1000, 0.4)
    dur = end - start
    m = int(dur * SR)
    t = np.arange(m) / SR
    body = (s.osc(110 * (1 + 0.008 * np.sin(2 * np.pi * 8 * t)), dur, "saw") + s.osc(165, dur, "saw") * 0.6)
    body = s.sweep_filter(body, 1400 + 300 * np.sin(2 * np.pi * 6 * t), "low", 1.6) * 0.34
    hiss = s.bp(s.white(m, rng), 2500, 11000, 2) * (0.22 + 0.08 * np.sin(2 * np.pi * 12 * t))
    beam = (body + hiss) * np.minimum(1, t / 0.03) * np.minimum(1, (dur - t) / 0.08)
    blast = boom(rng, 110, 44, 0.6, 0.2, 0.5)
    return s.reverb(place(total, (0.0, pre), (start, beam), (end - 0.05, blast)), 1.3, 0.2, rng=rng)


def aksara_nova(rng, v):
    total, hit = 3.0, 1.1
    gather = charge(hit, 100, 1400, 0.5)
    blast = s.mix(boom(rng, 80, 26, 2.0, 0.5, 1.0) * 1.4, static_bed(1.0, rng, 150, 9000, 0.8))
    zp = zap(0.6, rng, 300, 9000) * 0.6
    return s.reverb(place(total, (0.0, gather), (0.0, whine(hit, 120, 900, 0.2)), (hit, blast), (hit, zp)), 2.0, 0.26,
                    rng=rng)


def aksara_fold(rng, v):
    snap = 0.25
    pre = whine(snap, 1400, 300, 0.25)
    pop = s.mix(zap(0.08, rng, 1500, 10000), clank(rng, 700, 0.2, 0.9, 0.05) * 0.6)
    sub = s.sub_drop(220, 60, 0.3, 0.07) * 0.6
    return s.reverb(place(0.8, (0.0, pre), (snap, pop), (snap, sub)), 0.9, 0.2, rng=rng)


def aksara_gate(rng, v):
    total, open_ = 2.6, 0.5
    n = int(total * SR)
    t = np.arange(n) / SR
    drone = (s.osc(55, total, "saw") + s.osc(55 * 1.006, total, "saw")) * 0.5
    drone = s.sweep_filter(drone, np.concatenate([np.geomspace(120, 900, int(0.5 * SR)),
                                                  np.full(n - int(0.5 * SR), 900.0)]), "low", 1.6)
    drone = drone * np.minimum(1, t / 0.3) * np.minimum(1, (total - t) / 0.4) * 0.5
    pull = s.air_whoosh(1.4, rng, 1200, 300, 120, 1.1, 0.4) * 0.5   # graviton menyedot
    y = place(total, (0.0, drone), (0.1, pull), (open_, boom(rng, 55, 28, 1.2, 0.3, 0.6) * 0.9),
              (open_, whine(0.3, 300, 80, 0.2)))
    return s.reverb(y, 2.2, 0.26, rng=rng)


def aksara_lance(rng, v):
    total, hit = 1.2, 0.45
    pre = whine(hit, 500, 2600, 0.22)
    stab = s.mix(zap(0.25, rng, 1000, 11000), clank(rng, 1400, 0.3, 0.8, 0.06) * 0.5)
    return s.reverb(place(total, (0.0, pre), (hit, stab), (hit, boom(rng, 160, 80, 0.3, 0.1, 0.4) * 0.5)), 1.2, 0.24,
                    rng=rng)


def aksara_dominion(rng, v):
    total, hit = 2.4, 0.9
    scan = servo(hit, 300, 600, rng, 0.2, 0.2)
    wave = s.air_whoosh(1.0, rng, 300, 1400, 400, 1.0, 0.3) * 0.5
    wash = glitch(1.0, rng, 0.35)                  # sinyal retas
    return s.reverb(place(total, (0.0, scan), (hit, wave), (hit, wash), (hit, boom(rng, 70, 34, 0.8, 0.2, 0.4) * 0.6)),
                    1.8, 0.24, rng=rng)


def aksara_rewrite(rng, v):
    total, hit = 1.6, 0.8
    buzz = s.bp(s.white(int(hit * SR), rng), 1500, 7000, 2) * 0.3   # kerumunan nanite
    buzz = crush(buzz, 5, 8000)
    brk = s.mix(zap(0.25, rng, 300, 9000), clank(rng, 360, 0.4, 0.9, 0.08) * 0.5)
    return s.reverb(place(total, (0.0, buzz), (hit, brk), (hit, boom(rng, 130, 50, 0.5, 0.1, 0.5) * 0.6)), 1.3, 0.22,
                    rng=rng)


def aksara_veil(rng, v):
    total = 1.2
    sweep = s.air_whoosh(0.8, rng, 400, 3000, 600, 1.0, 0.4) * 0.45
    dig = glitch(0.5, rng, 0.3)                     # kamuflase optik mengaktif
    return s.reverb(place(total, (0.05, sweep), (0.0, dig), (0.0, whine(0.6, 1800, 600, 0.15))), 1.4, 0.26, rng=rng)


def aksara_timestop(rng, v):
    total, hit = 2.4, 0.6
    build = whine(hit, 200, 700, 0.2)
    hum = reactorhum(1.6, 70, 0.2)
    freeze = tape(hum, 1.0, 0.12)                   # semua melambat & membeku
    clk = clank(rng, 300, 0.6, 1.0, 0.2)
    return s.reverb(place(total, (0.0, build), (hit, freeze), (hit, clk), (hit, boom(rng, 60, 30, 1.0, 0.3, 0.6) * 0.8)),
                    2.4, 0.3, rng=rng)


def aksara_timeresume(rng, v):
    total = 1.8
    hum = reactorhum(0.8, 70, 0.2)
    start = tape(hum, 0.12, 1.0)                    # waktu berjalan lagi
    bill = s.mix(boom(rng, 90, 30, 1.2, 0.35, 0.9) * 1.1, static_bed(0.6, rng, 200, 8000, 0.6))
    ticks = [(0.5 + i * 0.05, clank(rng, 900, 0.1, 0.5, 0.03) * 0.5) for i in range(8)]
    return s.reverb(place(total, (0.0, start), (0.45, bill), *ticks), 1.8, 0.26, rng=rng)


def aksara_rewind(rng, v):
    total, hit = 1.4, 0.5
    g = clank(rng, 500, 0.5, 1.0, 0.15)
    rev = g[::-1] * 0.8
    back = s.air_whoosh(0.5, rng, 2000, 600, 200, 1.0, 0.7) * 0.5
    return s.reverb(place(total, (0.0, rev), (0.0, back), (hit, zap(0.3, rng, 600, 9000) * 0.5),
                          (hit, boom(rng, 120, 60, 0.4, 0.1, 0.4) * 0.5)), 1.5, 0.24, rng=rng)


def aksara_soul(rng, v):
    total, rip = 3.2, 2.4
    drain = whine(rip, 180, 90, 0.18) + s.bp(s.pink(int(rip * SR), rng), 200, 2000, 2) * 0.12
    tt = s.t_axis(rip)
    drain = drain * np.minimum(1, tt / 0.4)
    tear = s.mix(zap(0.5, rng, 200, 7000), boom(rng, 90, 40, 0.8, 0.2, 0.6) * 0.8)
    return s.reverb(place(total, (0.0, drain), (rip, tear), (rip, static_bed(0.5, rng, 150, 6000, 0.5))), 2.2, 0.28,
                    rng=rng)


def aksara_ward(rng, v):
    total, hit = 2.0, 0.6
    spin = whine(hit, 300, 900, 0.22)
    bloom = s.mix(clank(rng, 420, 0.8, 1.0, 0.3), reactorhum(1.2, 110, 0.16))
    return s.reverb(place(total, (0.0, spin), (hit, bloom), (hit, static_bed(0.4, rng, 400, 7000, 0.3))), 2.0, 0.28,
                    rng=rng)


def aksara_purna(rng, v):
    total, hit = 4.0, 1.7
    parts = [(0.1 + i * 0.22, clank(rng, 360 + i * 60, 0.5, 1.0, 0.2) * 0.6) for i in range(6)]
    parts.append((0.0, charge(hit, 90, 500, 0.4)))
    parts.append((0.0, reactorhum(total, 70, 0.2)))
    parts.append((hit, boom(rng, 75, 24, 2.2, 0.6, 1.0) * 1.4))
    parts.append((hit, voice(2.2, rng, 85, 1.2, 0.34)))
    parts.append((hit, static_bed(1.2, rng, 150, 10000, 0.7)))
    parts.append((hit - 0.4, whine(0.4, 400, 1600, 0.3)))
    return s.reverb(place(total, *parts), 2.6, 0.3, rng=rng)


def aksara_erase(rng, v):
    total, hit = 6.2, 3.2
    n = int(hit * SR)
    tt = np.arange(n) / SR
    build = charge(hit, 60, 2000, 0.6)
    drone = voice(hit, rng, 70, 1.4, 0.28) * (tt / hit)[..., ] ** 1.2
    whiteout = s.mix(boom(rng, 70, 20, 3.0, 0.7, 1.0) * 1.5, static_bed(2.5, rng, 60, 14000, 1.0))
    glitchy = glitch(1.2, rng, 0.5)
    return s.reverb(place(total, (0.0, build), (0.0, drone), (hit, whiteout), (hit, glitchy),
                          (hit, voice(2.6, rng, 80, 1.3, 0.3))), 3.0, 0.32, rng=rng)


def aksara_disc(rng, v):
    total = 1.0
    parts = []
    for i in range(6):                              # enam drone diluncurkan
        parts.append((i * 0.03, s.mix(whine(0.4, 400 + i * 120, 1200, 0.2),
                                      s.bp(s.white(int(0.3 * SR), rng), 800 + i * 150, 4000, 2) * env(0.3, 0.1) * 0.3)))
    return s.reverb(place(total, *parts), 1.0, 0.2, rng=rng)


def aksara_shield(rng, v):
    deploy = s.mix(clank(rng, 380, 0.7, 1.0, 0.25), whine(0.3, 200, 700, 0.2))
    hum = reactorhum(0.8, 120, 0.18)
    return s.reverb(place(0.9, (0.0, deploy), (0.0, hum)), 1.0, 0.2, rng=rng)


def aksara_step(rng, v):
    pre = whine(0.12, 1600, 400, 0.25)
    pop = s.mix(zap(0.06, rng, 1500, 10000), clank(rng, 900, 0.25, 0.6, 0.04) * 0.4)
    return s.reverb(place(0.45, (0.0, pre), (0.12, pop)), 0.7, 0.18, rng=rng)


def aksara_parry(rng, v):
    fwip = s.air_whoosh(0.18, rng, 1200, 4500, 1500, 1.0, 0.4) * 0.6
    tk = s.mix(clank(rng, 1200, 0.3, 0.7, 0.05) * 0.5, zap(0.12, rng, 800, 9000) * 0.4)
    return s.reverb(place(0.5, (0.0, fwip), (0.1, tk)), 0.8, 0.2, rng=rng)


def aksara_rite(rng, v):
    total, read, etch, burst = 9.0, 2.5, 5.5, 7.5
    parts = [(0.0, reactorhum(burst, 60, 0.16)), (0.0, servo(read, 150, 400, rng, 0.2, 0.2))]
    for i in range(6):                              # subsistem demi subsistem online
        parts.append((read + i * 0.5, clank(rng, 360 + i * 70, 0.6, 1.0, 0.2) * 0.6))
        parts.append((read + i * 0.5, whine(0.3, 300 + i * 80, 900, 0.1)))
    parts.append((etch, charge(burst - etch, 90, 500, 0.4)))
    parts.append((etch, voice(burst - etch + 1, rng, 85, 1.0, 0.24)))
    parts.append((burst, boom(rng, 70, 24, 2.0, 0.55, 1.0) * 1.3))
    parts.append((burst, static_bed(1.2, rng, 150, 10000, 0.7)))
    return s.reverb(place(total, *parts), 2.6, 0.28, rng=rng)


RECIPES = {
    "aksara_transform": (aksara_transform, 1, 1.0),
    "aksara_revert": (aksara_revert, 1, 0.8),
    "aksara_pulse": (aksara_pulse, 3, 0.6),
    "aksara_punch": (aksara_punch, 2, 0.9),
    "aksara_sixfold": (aksara_sixfold, 1, 1.0),
    "aksara_beam": (aksara_beam, 1, 0.95),
    "aksara_nova": (aksara_nova, 1, 1.0),
    "aksara_fold": (aksara_fold, 1, 0.85),
    "aksara_gate": (aksara_gate, 1, 0.95),
    "aksara_lance": (aksara_lance, 1, 0.9),
    "aksara_dominion": (aksara_dominion, 1, 0.9),
    "aksara_rewrite": (aksara_rewrite, 1, 0.9),
    "aksara_veil": (aksara_veil, 1, 0.8),
    "aksara_timestop": (aksara_timestop, 1, 1.0),
    "aksara_timeresume": (aksara_timeresume, 1, 1.0),
    "aksara_rewind": (aksara_rewind, 1, 0.85),
    "aksara_soul": (aksara_soul, 1, 0.9),
    "aksara_ward": (aksara_ward, 1, 0.8),
    "aksara_purna": (aksara_purna, 1, 1.0),
    "aksara_erase": (aksara_erase, 1, 1.0),
    "aksara_disc": (aksara_disc, 1, 0.85),
    "aksara_shield": (aksara_shield, 1, 0.85),
    "aksara_step": (aksara_step, 1, 0.75),
    "aksara_rite": (aksara_rite, 1, 1.0),
    "aksara_parry": (aksara_parry, 1, 0.8),
}
WINDUPS = set()
LOOPS = set()

s.RECIPES.update(RECIPES)
s.WINDUPS.update(WINDUPS)
s.LOOPS.update(LOOPS)

if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "out"
    only = sys.argv[2:] if len(sys.argv) > 2 else None
    os.makedirs(out, exist_ok=True)
    for name, (fn, count, gain) in RECIPES.items():
        if only and name not in only:
            continue
        for v in range(count):
            y = s.render(name, fn, v, gain)
            fname = f"{name}_{v + 1}.ogg"
            s.encode(y, os.path.join(out, fname))
            rms = 20 * np.log10(np.sqrt(np.mean(y ** 2)) + 1e-9)
            print(fname, round(len(y) / SR, 2), "dtk", round(float(rms), 1), "dB", flush=True)
