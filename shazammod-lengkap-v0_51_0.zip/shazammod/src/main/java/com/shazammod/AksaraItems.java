package com.shazammod;

import net.minecraft.ChatFormatting;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * 0.50 Barang Aksara:
 * - Lontar Sabda (lontar_sabda): naskah daun lontar berlapis prada; enam aksara di atasnya berdenyut, satu untuk tiap
 *   ranah. Resep (data/shazammod/recipe/lontar_sabda.json): blok redstone (Daya), ender pearl (Ruang), jam (Kala),
 *   echo shard (Benak), Nether Star (inti), amethyst shard (Maya), dua batang emas (prada) dan ghast tear (Atma).
 *   Klik kanan dalam wujud manusia untuk Penulisan Ulang (lihat AksaraRite): kamu bisa berubah jadi Aksara.
 */
@EventBusSubscriber(modid = ShazamMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public final class AksaraItems {
    private AksaraItems() {}

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(ShazamMod.MODID);

    public static final DeferredItem<LontarItem> LONTAR = ITEMS.register("lontar_sabda",
            () -> new LontarItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));

    @SubscribeEvent
    public static void addToCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            event.accept(LONTAR.get());
        }
    }

    /** Lontar Sabda: klik kanan dalam wujud manusia untuk Penulisan Ulang. */
    public static class LontarItem extends LintangItems.LoreItem {
        public LontarItem(Item.Properties properties) {
            super(properties, "item.shazammod.lontar_sabda", ChatFormatting.GOLD, true);
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            if (player instanceof ServerPlayer serverPlayer) {
                AksaraRite.tryBegin(serverPlayer);
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
        }
    }
}
