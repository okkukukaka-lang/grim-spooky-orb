package com.shazammod;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

/**
 * 0.50 Penulisan Ulang: Lontar Sabda dibuka dalam wujud manusia. Enam aksara terangkat dari daun lontar dan mengorbit
 * (AKSARA_RITE_READ), lalu satu per satu menggurat tubuh dengan garis prada emas (AKSARA_RITE_ETCH), lalu keenamnya
 * menyatu jadi Cakram Sabda di punggung (AKSARA_RITE_BURST): tubuhmu sekarang bisa ditulis ulang jadi Aksara.
 * Nggak ada syarat tempat, tapi selama ritual kamu nggak bisa apa-apa (dan nggak bisa dilukai).
 */
public final class AksaraRite {
    public static final int READ = ShazamAnim.AKSARA_RITE_READ;
    public static final int ETCH = ShazamAnim.AKSARA_RITE_ETCH;
    public static final int BURST = ShazamAnim.AKSARA_RITE_BURST;
    public static final int LENGTH = ShazamAnim.AKSARA_RITE_TICKS;

    private static final Map<UUID, Long> RITES = new HashMap<>();
    private static final Set<UUID> FORCED = new HashSet<>();

    private AksaraRite() {}

    public static boolean isAwakening(ServerPlayer p) {
        Long t = RITES.get(p.getUUID());
        return t != null && p.level().getGameTime() - t <= LENGTH + 4;
    }

    public static void tryBegin(ServerPlayer p) {
        ShazamData d = ShazamPowers.data(p);
        String err = null;
        if (isAwakening(p) || LintangRite.isAwakening(p) || HelionRite.isAwakening(p) || Helion3Rite.isAwakening(p)) {
            err = "message.shazammod.aksara_rite.already";
        } else if (d.aksaraUnlocked()) {
            err = "message.shazammod.aksara_rite.already_yours";
        } else if (d.transformed()) {
            err = "message.shazammod.aksara_rite.human_only";
        } else if (KahndaqTrial.isRunning(p) || ShazamTotems.isAwakening(p) || SabbacPact.isAwakening(p)) {
            err = "message.shazammod.aksara_rite.busy";
        }
        if (err != null) {
            p.displayClientMessage(Component.translatable(err).withStyle(ChatFormatting.GOLD, ChatFormatting.ITALIC), true);
            return;
        }
        begin(p, false);
    }

    public static void begin(ServerPlayer p, boolean forced) {
        if (isAwakening(p)) {
            return;
        }
        UUID id = p.getUUID();
        if (forced) {
            FORCED.add(id);
        } else {
            FORCED.remove(id);
        }
        if (ShazamPowers.isTransformed(p)) {
            ShazamPowers.revert(p, false);
        }
        final long start = p.serverLevel().getGameTime();
        RITES.put(id, start);
        ShazamNetwork.playAnim(p, ShazamAnim.AKSARA_RITE);
        // satu suara panjang yang memuncak tepat di BURST (lihat tools/sfx/aksara_sfx.py: aksara_rite)
        sound(p, ShazamSounds.AKSARA_RITE.get(), 2.4f, 1f);
        log(p, "message.shazammod.aksara_lontar.start", ChatFormatting.GOLD);
        for (int t = 6; t < BURST; t += 6) {
            final int tick = t;
            ShazamPowers.schedule(p, t, sp -> progress(sp, start, tick));
        }
        for (int t = READ; t < ETCH; t += 10) {   // tiap aksara yang menggurat badan: denting prada
            final float pitch = 0.8f + (t - READ) / (float) (ETCH - READ) * 0.6f;
            ShazamPowers.schedule(p, t, sp -> {
                if (active(sp, start)) {
                    sound(sp, ShazamSounds.AKSARA_PUNCH.get(), 0.9f, pitch);
                }
            });
        }
        ShazamPowers.schedule(p, READ, sp -> {
            if (active(sp, start)) {
                log(sp, "message.shazammod.aksara_lontar.etch", ChatFormatting.YELLOW);
            }
        });
        ShazamPowers.schedule(p, ETCH, sp -> {
            if (active(sp, start)) {
                log(sp, "message.shazammod.aksara_lontar.bind", ChatFormatting.GOLD);
            }
        });
        ShazamPowers.schedule(p, BURST, sp -> finish(sp, start));
    }

    private static boolean active(ServerPlayer p, long start) {
        Long t = RITES.get(p.getUUID());
        return t != null && t.longValue() == start;
    }

    private static void progress(ServerPlayer p, long start, int tick) {
        if (!active(p, start)) {
            return;
        }
        String stage;
        float frac;
        if (tick < READ) {
            stage = "message.shazammod.aksara_lontar.stage.read";
            frac = tick / (float) READ;
        } else if (tick < ETCH) {
            stage = "message.shazammod.aksara_lontar.stage.etch";
            frac = (tick - READ) / (float) (ETCH - READ);
        } else {
            stage = "message.shazammod.aksara_lontar.stage.bind";
            frac = (tick - ETCH) / (float) (BURST - ETCH);
        }
        int pct = Math.max(1, Math.min(100, Math.round(frac * 100f)));
        int full = Math.min(6, Math.round(pct / 100f * 6f));
        StringBuilder bar = new StringBuilder();
        for (int i = 0; i < 6; i++) {
            bar.append(i < full ? '◆' : '◇');
        }
        ChatFormatting c = tick < READ ? ChatFormatting.YELLOW : tick < ETCH ? ChatFormatting.GOLD : ChatFormatting.WHITE;
        p.displayClientMessage(Component.translatable("message.shazammod.aksara_lontar.bar",
                Component.translatable(stage), bar.toString(), String.valueOf(pct)).withStyle(c), true);
    }

    private static void finish(ServerPlayer p, long start) {
        if (!active(p, start)) {
            return;
        }
        UUID id = p.getUUID();
        RITES.remove(id);
        boolean forced = FORCED.remove(id);
        if (ShazamPowers.data(p).aksaraUnlocked()) {
            return;
        }
        if (!forced && !consumeLontar(p)) {
            p.displayClientMessage(Component.translatable("message.shazammod.aksara_rite.no_lontar")
                    .withStyle(ChatFormatting.GRAY), true);
            return;
        }
        log(p, "message.shazammod.aksara_lontar.done", ChatFormatting.GOLD);
        ShazamPowers.unlockAksara(p);
    }

    private static boolean consumeLontar(ServerPlayer p) {
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (!s.isEmpty() && s.is(AksaraItems.LONTAR.get())) {
                s.shrink(1);
                return true;
            }
        }
        return false;
    }

    private static void log(ServerPlayer p, String key, ChatFormatting color) {
        p.sendSystemMessage(Component.translatable("message.shazammod.aksara_lontar.prefix")
                .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD)
                .append(Component.literal(" "))
                .append(Component.translatable(key).withStyle(color)));
    }

    private static void sound(ServerPlayer p, SoundEvent sound, float volume, float pitch) {
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), sound, SoundSource.PLAYERS, volume, pitch);
    }

    public static void forget(UUID id) {
        RITES.remove(id);
        FORCED.remove(id);
    }

    public static void clear() {
        RITES.clear();
        FORCED.clear();
    }
}
