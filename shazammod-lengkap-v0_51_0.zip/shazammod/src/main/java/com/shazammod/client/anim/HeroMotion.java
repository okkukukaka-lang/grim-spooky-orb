package com.shazammod.client.anim;

import java.util.HashMap;
import java.util.Map;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.client.render.ShazamCape;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;

/**
 * 0.49 Lapisan gerak sehari-hari untuk Lintang, Helion-6, dan Subjek Tiga (dipanggil LintangBody sesudah pose dasar & klip
 * skill, sebelum penghalus PoseFilter). Model bawaan cuma mengayun lengan & kaki lurus; lapisan ini menambah yang membuat
 * tubuh terasa punya berat:
 *
 *   semua     pinggang berputar melawan langkah (bahu ikut, kepala tetap menatap ke depan), badan naik-turun tiap langkah,
 *             dan pukulan yang digerakkan pinggul: putaran badan lebih besar, badan condong masuk ke pukulannya
 *   Lintang   langkah tegap: dada membusung, siku sedikit terbuka; saat berlari lengannya memompa & badan condong ke depan
 *   Helion-6  jalan pemangsa yang angkuh: ayunan lengan ditahan, bahu bergulir bergantian, badan bergoyang ke kaki yang
 *             menapak, dagu turun menatap mangsanya
 *   Subjek 3  monster yang membungkuk dari pinggul (kaki tetap tegak): lengan raksasa menggantung ke depan dan berayun
 *             berat, badan oleng & menghentak tiap langkah, cakarnya mencakar dari atas menyilang badan saat memukul;
 *             bungkuknya hilang sendiri saat klipnya mendongak (meraung) dan berkurang saat klipnya sudah menunduk
 *
 * Semua tambahan dikali (1 - kuat klip skill), jadi gerakan skill nggak terganggu.
 */
public final class HeroMotion {
    private HeroMotion() {}

    private static final int LINTANG = 1, HELION = 2, SUBJEK = 3, AKSARA = 4;

    /** Langkah yang tersimpan per pemain (dibaca lagi saat seluruh badannya diputar di frame berikutnya). */
    private static final class Gait {
        int kind;
        float stride;   // -1..1: langkah sekarang (tanda = kaki mana yang di depan), sudah dikali kuat langkahnya
        float walk;     // 0..1 sedang melangkah
        float sprint;   // 0..1 sedang berlari kencang
        float punch;    // 0..1 puncak ayunan pukulan
        float free;     // 1 = nggak ada klip skill
    }

    private static final Map<Integer, Gait> GAITS = new HashMap<>();

    private static int kind(int id) {
        if (!ShazamClientState.isTransformed(id)) {
            return 0;
        }
        return ShazamClientState.isAksara(id) ? AKSARA : ShazamClientState.isHelion3(id) ? SUBJEK
                : ShazamClientState.isHelion(id) ? HELION
                : ShazamClientState.isLintang(id) ? LINTANG : 0;
    }

    /** Pose bagian badan (lengan, kaki, kepala, putaran pinggang). */
    public static void pose(HumanoidModel<?> m, AbstractClientPlayer p, float age) {
        if (age <= 0.0001f) {
            return;   // tangan orang pertama
        }
        int id = p.getId();
        int kind = kind(id);
        if (kind == 0 || p.isSleeping() || p.isPassenger() || p.isFallFlying() || p.isVisuallySwimming()) {
            GAITS.remove(id);
            return;
        }
        float pt = Mth.clamp(age - p.tickCount, 0f, 1f);
        Gait g = GAITS.get(id);
        if (g == null) {
            if (GAITS.size() > 64) {
                GAITS.clear();
            }
            g = new Gait();
            GAITS.put(id, g);
        }
        g.kind = kind;
        // klip skill yang sedang berjalan mengalahkan lapisan ini
        ShazamAnim anim = ShazamPoses.currentAnim(p);
        float time = ShazamPoses.animTime(p, pt);
        Clip clip = anim == null || time < 0f ? null : Clips.get(anim, ShazamClientState.form(id));
        float busy = clip == null ? 0f : clip.weight(time);
        float free = 1f - busy;
        boolean flying = ShazamClientState.isFlying(id);
        double dx = p.getX() - p.xo, dz = p.getZ() - p.zo;
        float speed = (float) Math.sqrt(dx * dx + dz * dz);
        float walk = flying || !p.onGround() ? 0f : Mth.clamp(speed / 0.16f, 0f, 1f);
        float sprint = flying ? 0f : Mth.clamp((speed - 0.3f) / 0.3f, 0f, 1f);
        // langkah dibaca dari kaki model bawaan (kanan = cos(fase) x 1,4 x kuat langkah, kiri kebalikannya)
        float stride = flying ? 0f : Mth.clamp((m.leftLeg.xRot - m.rightLeg.xRot) / 2.8f, -1f, 1f) * free;
        float swing = Mth.sin(m.attackTime * (float) Math.PI);
        float punch = m.attackTime > 0f ? swing * free : 0f;
        g.stride = stride;
        g.walk = walk * free;
        g.sprint = sprint * free;
        g.punch = punch;
        g.free = free;

        // --- pukulan dari pinggul: putaran badan bawaan (0,2 rad) diperbesar, poros bahu ikut, kepala tetap ke sasaran
        float twist = m.body.yRot * 0.85f * free;
        // --- pinggang melawan langkah
        float counter = kind == HELION ? 0.15f : kind == SUBJEK ? 0.11f : kind == AKSARA ? 0.05f : 0.1f;
        twist += stride * counter;
        if (Math.abs(twist) > 1.0E-4f) {
            float angle = m.body.yRot + twist;
            m.body.yRot = angle;
            m.rightArm.z = Mth.sin(angle) * 5.0f;
            m.rightArm.x = -Mth.cos(angle) * 5.0f;
            m.leftArm.z = -Mth.sin(angle) * 5.0f;
            m.leftArm.x = Mth.cos(angle) * 5.0f;
            m.rightArm.yRot += twist;
            m.leftArm.yRot += twist;
            m.head.yRot -= stride * counter * 0.5f;
        }
        float still = (1f - walk) * free;
        switch (kind) {
            case LINTANG -> lintang(m, g, age, still);
            case HELION -> helion(m, g, age, still);
            case AKSARA -> aksara(m, g, age, still);
            default -> subjek(m, p, g, age, pt, still, clip, time, busy);
        }
        m.hat.copyFrom(m.head);
    }

    /** Lintang: langkah tegap, lengan memompa saat berlari, tangan bebasnya mengepal ke belakang saat memukul. */
    private static void lintang(HumanoidModel<?> m, Gait g, float age, float still) {
        float w = g.walk, s = g.sprint;
        m.rightArm.zRot += 0.09f * w + 0.05f * s;      // siku sedikit terbuka
        m.leftArm.zRot -= 0.09f * w + 0.05f * s;
        m.rightArm.xRot = m.rightArm.xRot * (1f + 0.25f * s) - 0.3f * s;   // berlari: lengan menekuk ke depan & memompa
        m.leftArm.xRot = m.leftArm.xRot * (1f + 0.25f * s) - 0.3f * s;
        m.head.xRot -= 0.05f * w;                      // dagu terangkat
        m.head.yRot += Mth.sin(age * 0.031f) * 0.05f * still;   // diam: memandang berkeliling pelan
        if (g.punch > 0f) {
            m.leftArm.xRot += 0.45f * g.punch;         // tangan bebas tertarik ke belakang
            m.leftArm.zRot -= 0.12f * g.punch;
        }
    }

    /**
     * 0.50 Aksara: melayang seperti wayang yang digerakkan dalang. Kaki menggantung rapat dengan ujung kaki menunjuk ke
     * bawah (langkahnya cuma ayunan kecil), lengan sedikit terbuka dengan telapak menghadap ke depan, jari kanan sesekali
     * "menulis" pelan saat diam, kepala tegak dan tenang.
     */
    private static void aksara(HumanoidModel<?> m, Gait g, float age, float still) {
        float w = g.walk, free = g.free;
        m.rightLeg.xRot = m.rightLeg.xRot * (1f - 0.7f * free) + 0.12f * free;   // ujung kaki ke bawah, langkah kecil
        m.leftLeg.xRot = m.leftLeg.xRot * (1f - 0.7f * free) + 0.06f * free;
        m.rightLeg.zRot += 0.02f * free;
        m.leftLeg.zRot -= 0.02f * free;
        m.rightArm.xRot = m.rightArm.xRot * (1f - 0.6f * free) - 0.18f * free;   // lengan melayang, ayunannya ditahan
        m.leftArm.xRot = m.leftArm.xRot * (1f - 0.6f * free) - 0.18f * free;
        m.rightArm.zRot += (0.26f + 0.04f * Mth.sin(age * 0.06f)) * free;
        m.leftArm.zRot -= (0.26f + 0.04f * Mth.sin(age * 0.06f + 1.3f)) * free;
        m.rightArm.yRot -= 0.25f * free;                                         // telapak menghadap ke depan
        m.leftArm.yRot += 0.25f * free;
        m.rightArm.xRot += Mth.sin(age * 0.21f) * 0.06f * still;                 // jari menulis pelan di udara
        m.rightArm.yRot += Mth.cos(age * 0.17f) * 0.07f * still;
        m.head.xRot -= 0.04f * w;
        m.head.yRot += Mth.sin(age * 0.023f + 0.6f) * 0.05f * still;
        if (g.punch > 0f) {   // tinju telapak: tangan bebas ditarik ke dada
            m.leftArm.xRot -= 0.4f * g.punch;
            m.leftArm.yRot += 0.3f * g.punch;
        }
    }

    /** Helion-6: jalan pemangsa yang angkuh. */
    private static void helion(HumanoidModel<?> m, Gait g, float age, float still) {
        float w = g.walk, st = g.stride;
        float hold = 1f - 0.45f * w;                   // ayunan lengan ditahan
        m.rightArm.xRot *= hold;
        m.leftArm.xRot *= hold;
        m.rightArm.zRot += 0.17f * w;                  // lengan agak terbuka, siap mencengkeram
        m.leftArm.zRot -= 0.17f * w;
        m.rightArm.y -= st * 0.7f;                     // bahu bergulir bergantian
        m.leftArm.y += st * 0.7f;
        m.head.xRot += 0.07f * w;                      // dagu turun, menatap dari bawah alis
        m.head.zRot += st * 0.035f;
        m.head.yRot += Mth.sin(age * 0.027f + 1.7f) * 0.04f * still;
        if (g.punch > 0f) {
            m.leftArm.xRot += 0.35f * g.punch;
            m.leftArm.zRot -= 0.2f * g.punch;
            m.head.xRot += 0.08f * g.punch;
        }
    }

    /**
     * Subjek Tiga: bungkuk dari pinggul + lengan raksasa menggantung & berayun berat + cakaran dari atas.
     * clip/time/busy = klip skill yang sedang berjalan (bungkuknya mengikuti condong klip itu).
     */
    private static void subjek(HumanoidModel<?> m, AbstractClientPlayer p, Gait g, float age, float pt, float still, Clip clip,
                               float time, float busy) {
        float w = g.walk, st = g.stride, free = g.free;
        // lengan menggantung ke depan, sedikit terbuka; ayunannya lebih lambat & berat dari kaki
        m.rightArm.xRot = m.rightArm.xRot * (1f - 0.25f * free) - 0.36f * free;
        m.leftArm.xRot = m.leftArm.xRot * (1f - 0.25f * free) - 0.36f * free;
        m.rightArm.zRot += 0.2f * free;
        m.leftArm.zRot -= 0.2f * free;
        m.body.zRot += st * 0.075f;                    // badan oleng ke kaki yang menapak
        m.head.zRot -= st * 0.05f;
        m.rightLeg.zRot += 0.08f * free;               // kaki terbuka lebar
        m.leftLeg.zRot -= 0.08f * free;
        float breathe = Mth.sin(age * 0.09f);
        m.rightArm.zRot += 0.03f * breathe * still;
        m.leftArm.zRot -= 0.03f * breathe * still;
        m.head.yRot += Mth.sin(age * 0.043f) * 0.1f * still;        // mengendus kiri-kanan
        // cakaran: lengan pemukul terangkat tinggi lalu mencakar turun menyilang badan (menggantikan tinju lurus bawaan)
        if (g.punch > 0f && m.attackTime > 0f) {
            float a = m.attackTime;
            boolean right = m.rightArm.xRot <= m.leftArm.xRot;      // lengan yang sedang diayun bawaan = yang lebih ke depan
            float raise = Mth.clamp(a / 0.22f, 0f, 1f) * (1f - Mth.clamp((a - 0.22f) / 0.28f, 0f, 1f));
            float slash = Mth.clamp((a - 0.22f) / 0.28f, 0f, 1f) * (1f - Mth.clamp((a - 0.6f) / 0.4f, 0f, 1f));
            float side = right ? 1f : -1f;
            if (right) {
                swipe(m.rightArm, raise * free, -2.75f, -0.3f * side, 0.45f * side);
                swipe(m.rightArm, slash * free, -0.95f, 0.55f * side, -0.45f * side);
            } else {
                swipe(m.leftArm, raise * free, -2.75f, -0.3f * side, 0.45f * side);
                swipe(m.leftArm, slash * free, -0.95f, 0.55f * side, -0.45f * side);
            }
        }
        // bungkuk dari pinggul: dasar 17 derajat, bertambah tiap langkah & napas; mengikuti condong klip skill
        float reveal = ShazamCape.revealTime(p, pt);
        float in = reveal < 0f ? 1f : Mth.clamp(reveal / 6f, 0f, 1f);   // baru berubah wujud: bungkuknya masuk pelan
        float theta = 0.3f + 0.035f * breathe * still + Math.abs(st) * 0.06f + 0.1f * g.sprint;
        if (clip != null && busy > 0f) {
            float ct = clip.tilt(time) * busy;                          // derajat, positif = klipnya condong ke depan
            theta *= 1f - Mth.clamp(-ct / 12f, 0f, 1f);                 // mendongak (meraung): tegak
            theta *= 1f - 0.75f * Mth.clamp((ct - 18f) / 30f, 0f, 1f);  // sudah menunduk dalam: jangan dobel
        }
        hunch(m, theta * in);
    }

    private static void swipe(net.minecraft.client.model.geom.ModelPart arm, float w, float x, float y, float z) {
        if (w <= 0f) {
            return;
        }
        arm.xRot = Mth.lerp(w, arm.xRot, x);
        arm.yRot = Mth.lerp(w, arm.yRot, y);
        arm.zRot = Mth.lerp(w, arm.zRot, z);
    }

    /**
     * Membungkuk dari pinggul sebesar theta (radian): badan, kepala, & bahu maju-turun, kaki tetap di tanah (sama seperti
     * model bosnya). Kepala dijulurkan mendongak sedikit supaya tetap menatap ke depan.
     */
    private static void hunch(HumanoidModel<?> m, float theta) {
        if (theta <= 0.001f) {
            return;
        }
        float c = Mth.cos(theta), s = Mth.sin(theta);
        float down = 12f - 12f * c, fwd = -12f * s;
        m.body.xRot += theta;
        m.body.y += down;
        m.body.z += fwd;
        m.head.y += down;
        m.head.z += fwd;
        m.head.xRot -= theta * 0.75f;
        float ay = down + 2f * c - 2f, az = fwd + 2f * s;
        m.rightArm.y += ay;
        m.rightArm.z += az;
        m.leftArm.y += ay;
        m.leftArm.z += az;
    }

    /**
     * Tambahan untuk seluruh badan (dipanggil LintangBody.applyBodyTransform, memakai langkah frame sebelumnya).
     * out = {condong ke depan (derajat), turun (blok), condong ke samping (derajat)} ditambahkan ke isinya.
     */
    public static void body(AbstractClientPlayer p, float pt, float[] out) {
        Gait g = GAITS.get(p.getId());
        if (g == null || kind(p.getId()) != g.kind) {
            return;
        }
        float bob = (1f - Math.abs(g.stride)) * g.walk;   // dua kali naik-turun tiap siklus langkah
        switch (g.kind) {
            case LINTANG -> {
                out[0] += -2.2f * g.walk + 8.5f * g.sprint + 7f * g.punch;
                out[1] += 0.03f * bob;
                out[2] += g.stride * 1.2f;
            }
            case HELION -> {
                out[0] += -1.2f * g.walk + 6f * g.sprint + 8f * g.punch;
                out[1] += 0.035f * bob;
                out[2] += g.stride * 3.4f;
            }
            case AKSARA -> {   // 0.50: selalu melayang sedikit di atas tanah, naik-turun pelan seperti bernapas
                float age = p.tickCount + pt + p.getId() * 7f;
                out[0] += -1.5f * g.walk + 7f * g.sprint + 6f * g.punch;
                out[1] += -(0.16f + 0.035f * Mth.sin(age * 0.075f)) * g.free;
                out[2] += g.stride * 0.6f + Mth.sin(age * 0.05f) * 0.8f * g.free;
            }
            default -> {
                out[0] += 2f * g.walk + 5f * g.sprint + 10f * g.punch;
                out[1] += 0.07f * bob + 0.02f * g.walk;
                out[2] += g.stride * 2.4f;
            }
        }
    }

    /** Juara ini memakai lapisan gerak ini (buat penghalus PoseFilter). */
    public static boolean covers(int id) {
        return kind(id) != 0;
    }
}
