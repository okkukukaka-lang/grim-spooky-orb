package com.shazammod.client.fx;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.shazammod.AksaraRite;
import com.shazammod.AksaraSkills;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Hd;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Runes;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * 0.51 Efek PRALAYA, Sang Mesin Kiamat (orisinal, robot/AI — bukan magis). Bahasa visualnya: hard-light tech (cincin
 * hologram bidik, braket sudut, grid), logam baja putih-panas, plasma/repulsor, drone, dan enam warna subsistem
 * (Plasma merah, Graviton ungu, Siber sian, Nanite magenta, Stasis amber, Reaktor hijau). Tanpa rune, tanpa prada.
 *
 *   berubah        enam Cakram Sabda datang melayang dari enam arah dengan ekor warnanya, lingkaran aksara di bawah kaki,
 *                  garis prada menggurat badan, lalu cakram mengunci di punggung: kilatan, gelombang, gempa kecil
 *   Sinar Daya     sinar merah berinti putih dari telapak (ikut bidikan, berhenti di blok), cincin aksara meluncur di
 *                  sepanjang sinar, ledakan di ujungnya
 *   Ledak Daya     tenaga merah dipadatkan di dada (bola mengecil, butiran tersedot), lalu meledak (nova besar)
 *   Lipat Ruang    jentikan, bayangan tertinggal, garis ruang terlipat, implosi di titik berangkat & tiba
 *   Gerbang Ruang  gerbang tegak berpusat kehampaan + cincin aksara berputar; gerbang kecil di langit memuntahkan musuh
 *   Tusuk/Kuasa    tombak benak sian dari mata ke sasaran; cincin pengunci benak di kepala musuh; gelombang benak
 *   Ubah/Cermin    jari menulis aksara magenta di udara; robekan kenyataan (pecahan glitch); bayangan cermin
 *   Henti/Putar    kubah amber + jam raksasa di tanah yang jarumnya berhenti; jarum berputar mundur & bayangan amber
 *   Rampas/Tirai   tali jiwa hijau bergelombang dari musuh ke tangan; perisai arwah
 *   Purna          keenam cakram menyala, tiang cahaya, korona putih-emas; selama Purna: aura & butiran naik
 *   Penghapusan    naik, heksagram raksasa enam warna, dunia menggelap, lalu gelombang putih penghapus
 *   Cakram/Perisai enam cakram terbang ke enam musuh (kilatan warna ranahnya); perisai heksagon enam cakram di depan
 *   selalu         butiran warna dari halo, cincin prada samar di bawah kaki (melayang), jejak terbang pita prada
 */
public final class AksaraFx {
    public static final float BOOST = 1.45f;
    // GOLD/IVORY dipertahankan namanya tapi sekarang warna baja hard-light (bukan emas); merah/putih untuk inti & plasma
    public static final int GOLD = 0xC6D2DE, GOLD_HOT = 0xFFFFFF, IVORY = 0xB8C2CE, INDIGO = 0x141A26, VOID = 0x05060A;
    static final int[] RGB = AksaraSkills.RGB;
    static final int DAYA = RGB[0], RUANG = RGB[1], BENAK = RGB[2], MAYA = RGB[3], KALA = RGB[4], ATMA = RGB[5], PURNA = RGB[6];
    private static final Vec3 UP = new Vec3(0, 1, 0);

    private static final class State {
        long flareAt = -999L;
        long pulseAt = -999L;
        long discsOutUntil = -1L;
        int discCounter;
        final long[] discFlash = {-999L, -999L, -999L, -999L, -999L, -999L};
        int inscribed;
        int active = -1;
        long activeUntil;
        long veilUntil;
        Fx.Trail[] trails;
    }

    private static final Map<Integer, State> STATES = new HashMap<>();
    private static int rootTicks;
    private static Vec3 rootAt;

    private AksaraFx() {}

    public static void clear() {
        STATES.clear();
        rootTicks = 0;
        rootAt = null;
    }

    private static State state(AbstractClientPlayer p) {
        State s = STATES.get(p.getId());
        if (s == null) {
            if (STATES.size() > 64) {
                STATES.clear();
            }
            s = new State();
            STATES.put(p.getId(), s);
        }
        return s;
    }

    /** Animasi ini diurus AksaraFx (ShazamFx & ChampionFx melewatinya). */
    public static boolean handles(AbstractClientPlayer caster, ShazamAnim anim) {
        return switch (anim) {
            case SUMMON, TRANSFORM, REVERT, KNOCKOUT, LAUNCH, LAND_HERO, CRASH, SONIC_BOOM, HERO_CALL, ROLL_LEFT, ROLL_RIGHT ->
                    ShazamClientState.isAksara(caster.getId());
            default -> anim.name().startsWith("AKSARA_") || anim.name().startsWith("SABDA_");
        };
    }

    // ------------------------------------------------------------------ angka buat AksaraLayer

    /** 0..1 kilatan gurat prada sesudah skill (turun dalam 16 tick). */
    public static float flare(AbstractClientPlayer p, float pt) {
        State s = STATES.get(p.getId());
        if (s == null) {
            return 0f;
        }
        float t = p.level().getGameTime() - s.flareAt + pt;
        return t < 0f || t >= 16f ? 0f : 1f - t / 16f;
    }

    /** 0..1 denyut Halo Sabda (tiap 2 detik dari server). */
    public static float pulse(AbstractClientPlayer p, float pt) {
        State s = STATES.get(p.getId());
        if (s == null) {
            return 0f;
        }
        float t = p.level().getGameTime() - s.pulseAt + pt;
        return t < 0f || t >= 22f ? 0f : (float) Math.exp(-t / 6f);
    }

    /** 1 selama keenam cakram sedang dilempar (Lontar Cakram): halonya kosong. */
    public static float discsOut(AbstractClientPlayer p, float pt) {
        State s = STATES.get(p.getId());
        return s != null && p.level().getGameTime() < s.discsOutUntil ? 1f : 0f;
    }

    /** 0..1 terang cakram ke-i: dasar, sabda tertulis, cooldown (pemain sendiri), denyut berurutan, skill yang dipakai. */
    public static float discGlow(AbstractClientPlayer p, int i, float pt) {
        State s = STATES.get(p.getId());
        long now = p.level().getGameTime();
        boolean self = p == Minecraft.getInstance().player;
        int mask = self ? ShazamClientState.aksaraInscribed() : s == null ? 0 : s.inscribed;
        float k = (mask & (1 << i)) != 0 ? 0.62f : 0.28f;
        if (self && ShazamClientState.cooldown(i) > 0) {
            k *= 0.55f;   // ranahnya sedang jeda: cakramnya meredup
        }
        if (s != null) {
            float t = now - s.pulseAt - i * 2f + pt;
            if (t >= 0f && t < 14f) {
                k += 0.5f * (1f - t / 14f);
            }
            float f = now - s.discFlash[i] + pt;
            if (f >= 0f && f < 20f) {
                k += 0.7f * (1f - f / 20f);
            }
            if (s.active == i && now < s.activeUntil) {
                k = 1f;
            }
        }
        if (ShazamClientState.isRaging(p.getId())) {
            k = Math.max(k, 0.9f);
        }
        return Mth.clamp(k, 0f, 1f);
    }

    // ------------------------------------------------------------------ alat bantu

    private static void schedule(int delay, int duration, ShazamFx.Step step) {
        ShazamFx.schedule(delay, duration, step);
    }

    private static Vec3 chest(Entity e) {
        return e.position().add(0, e.getBbHeight() * 0.62, 0);
    }

    private static Vec3 forward(LivingEntity e) {
        float yaw = e.yBodyRot * Mth.DEG_TO_RAD;
        return new Vec3(-Mth.sin(yaw), 0, Mth.cos(yaw));
    }

    private static Vec3 camera() {
        return Minecraft.getInstance().gameRenderer.getMainCamera().getPosition();
    }

    private static Vec3 toCamera(Vec3 p) {
        Vec3 d = camera().subtract(p);
        return d.lengthSqr() < 1.0E-6 ? UP : d.normalize();
    }

    private static void flash(AbstractClientPlayer p, int sabda, int ticks) {
        State s = state(p);
        s.flareAt = p.level().getGameTime();
        if (sabda >= 0 && sabda < 6) {
            s.active = sabda;
            s.activeUntil = p.level().getGameTime() + ticks;
            s.discFlash[sabda] = p.level().getGameTime();
        }
    }

    /**
     * Titik cakram ke-i di dunia (kira-kira sama dengan AksaraGeo.discCenter): di belakang punggung, mengorbit di bidang
     * punggung. Dipakai buat butiran dari halo & titik berangkat cakram yang dilempar.
     */
    static Vec3 haloPoint(AbstractClientPlayer p, int i, float pt) {
        float age = p.tickCount + pt + p.getId() * 13f;
        float purna = ShazamRage.glow(p, pt);
        double model = 0.9375 * p.getScale();   // skala model pemain (15/16) x ukuran badan
        double orbit = (7.6 + 1.6 * purna) / 16.0 * model;
        double a = age * (0.012 + 0.03 * purna) + i * Math.PI / 3.0 + Math.PI / 2.0;
        float yaw = Mth.lerp(pt, p.yBodyRotO, p.yBodyRot) * Mth.DEG_TO_RAD;
        Vec3 fwd = new Vec3(-Mth.sin(yaw), 0, Mth.cos(yaw));
        Vec3 right = new Vec3(-fwd.z, 0, fwd.x);
        // pusat halo: 3 px di bawah leher (leher 24 px dari kaki), 6,4 px di belakang punggung, + melayang 0,16 blok
        Vec3 center = p.getPosition(pt).add(0, (24.0 - 3.0) / 16.0 * model + 0.16, 0)
                .subtract(fwd.scale((6.4 + 0.6 * purna) / 16.0 * model));
        return center.add(right.scale(-Math.cos(a) * orbit)).add(0, Math.sin(a) * orbit, 0);
    }

    private static int sabdaColor(int i) {
        return RGB[Math.floorMod(i, RGB.length)];
    }

    /** Kilatan kecil berlapis: inti putih, pendar warna, cincin aksara menghadap kamera, percikan. */
    private static void burst(Vec3 at, int rgb, float size, int sparks) {
        Vfx.add(new Fx.Flash(at, 0.9f * size, 0xFFFFFF, 4, 0.9f));
        Vfx.add(new Fx.Flash(at, 1.9f * size, rgb, 9, 0.45f));
        Vfx.add(new HoloRing(Lightning.Anchor.fixed(at), toCamera(at), 0.65 * size, rgb, 12, 0.18f, 0.8f, null));
        if (sparks > 0) {
            CineKit.sparks(at, sparks, rgb, 0.32 * size, 0.06f, 12, at.y - 2.5);
        }
    }

    /** Lingkaran aksara rebah di tanah (atau di udara: ground null). */
    private static void groundSigil(Vec3 at, double radius, int rgb, int life, float spin) {
        Vfx.add(new HoloRing(Lightning.Anchor.fixed(at.add(0, 0.06, 0)), UP, radius, rgb, life, spin, 0.85f, null));
    }

    private static List<LivingEntity> nearbyEnemies(AbstractClientPlayer p, double radius, int max) {
        List<LivingEntity> out = new ArrayList<>(p.level().getEntitiesOfClass(LivingEntity.class,
                p.getBoundingBox().inflate(radius), e -> e.isAlive() && e instanceof Enemy && e != p
                        && e.distanceToSqr(p) <= radius * radius && p.hasLineOfSight(e)));
        out.sort(Comparator.comparingDouble(e -> e.distanceToSqr(p)));
        return out.size() > max ? out.subList(0, max) : out;
    }

    private static void root(AbstractClientPlayer p, int ticks) {
        if (p == Minecraft.getInstance().player) {
            rootTicks = ticks;
            rootAt = p.position();
        }
    }

    /** Sebelum gerak pemain sendiri dihitung: selama tertahan (berubah, ritual, Purna, Penghapusan) badannya diam. */
    public static void preTick(LocalPlayer player) {
        if (rootTicks <= 0 || rootAt == null) {
            return;
        }
        double ox = rootAt.x - player.getX(), oz = rootAt.z - player.getZ();
        if (ox * ox + oz * oz > 6.25) {   // sudah dipindahkan server: jangan ditarik balik
            rootTicks = 0;
            return;
        }
        rootTicks--;
        Vec3 v = player.getDeltaMovement();
        player.setDeltaMovement(ox * 0.6, Math.min(v.y, 0.02), oz * 0.6);
    }

    // ------------------------------------------------------------------ animasi dari server

    public static void onAnim(AbstractClientPlayer caster, ShazamAnim anim, Vec3 pos) {
        if (!handles(caster, anim)) {
            return;
        }
        float old = Vfx.setBoost(BOOST);
        try {
            onAnim0(caster, anim, pos);
        } catch (RuntimeException ignored) {
            // efek nggak boleh bikin game crash
        } finally {
            Vfx.setBoost(old);
        }
    }

    private static void onAnim0(AbstractClientPlayer caster, ShazamAnim anim, Vec3 pos) {
        boolean self = caster == Minecraft.getInstance().player;
        switch (anim) {
            case TRANSFORM -> transform(caster, self);
            case REVERT -> revert(caster);
            case KNOCKOUT -> knockout(caster, self);
            case LAUNCH -> launch(caster);
            case LAND_HERO, CRASH -> land(caster, anim == ShazamAnim.CRASH, self);
            case SONIC_BOOM -> sonicBoom(caster);
            case ROLL_LEFT, ROLL_RIGHT -> Vfx.add(new Hd.Ghost(caster.position(), caster.yBodyRot, caster.getScale(), 1,
                    INDIGO, GOLD, 10, 0.7f));
            case HERO_CALL -> {
                burst(pos, GOLD, 1f, 6);
                HelionComic.word(pos.add(0, 0.9, 0), "!", 0xFFFFFF, 0xFF2A32, 1.1f);
            }
            case AKSARA_RITE -> rite(caster, self);
            case AKSARA_BEAM -> beam(caster, self);
            case AKSARA_NOVA -> nova(caster, self);
            case AKSARA_FOLD -> fold(caster, pos);
            case AKSARA_GATE -> gate(caster, pos, self);
            case AKSARA_LANCE -> lance(caster, pos, self);
            case AKSARA_DOMINION -> dominion(caster, self);
            case AKSARA_REWRITE -> rewrite(caster, pos, self);
            case AKSARA_VEIL -> veil(caster);
            case AKSARA_TIMESTOP -> timeStop(caster, self);
            case AKSARA_REWIND -> rewind(caster, pos);
            case AKSARA_SOUL -> soul(caster);
            case AKSARA_WARD -> ward(caster);
            case AKSARA_PURNA -> purna(caster, self);
            case AKSARA_ERASE -> erase(caster, self);
            case AKSARA_DISCS -> discs(caster);
            case AKSARA_SHIELD -> shield(caster);
            case AKSARA_STEP -> step(caster, pos);
            case AKSARA_SELF -> selfRewrite(caster);
            case SABDA_PULSE -> haloPulse(caster);
            case SABDA_PUNCH -> punch(caster, pos);
            case SABDA_SIXFOLD -> sixfold(caster, pos, self);
            case SABDA_PHASE -> phase(caster, pos);
            case SABDA_HIT -> {
                State s = state(caster);
                int rgb = s.active >= 0 && caster.level().getGameTime() < s.activeUntil + 40 ? sabdaColor(s.active) : GOLD;
                burst(pos, rgb, 1.1f, 10);
            }
            case SABDA_IMPLODE -> Vfx.add(new Implosion(pos, RUANG, 14, 3.2));
            case SABDA_SKYGATE -> {
                Vfx.add(new Portal(pos.add(0, 0.4, 0), new Vec3(0, -1, 0), 1.6, RUANG, 24, 4));
                CineKit.motesOut(pos, 10, RUANG, 0.2, 0.06f, 14);
            }
            case SABDA_STUN -> Vfx.add(new MindLock(pos.add(0, 0.55, 0), 50));
            case SABDA_POOF -> poof(caster.level() instanceof ClientLevel level ? level : null, pos);
            case SABDA_TIME_END -> timeEnd(caster, pos, self);
            case SABDA_SOUL_RIP -> soulRip(pos);
            case SABDA_DISC -> discHit(caster, pos);
            case SABDA_DRONE -> droneShot(caster, pos);
            case SABDA_BLOCK -> {
                burst(pos, RUANG, 0.9f, 8);
                Vfx.add(new Fx.Wave(pos, forward(caster), 0.9, 0.12, GOLD, 8, 0.8f, 0.1f, null));
            }
            case SABDA_INSCRIBE -> inscribe(caster, (int) Math.round(pos.x), pos.y > 0.5, self);
            case SABDA_PURNA_END -> schedule(0, 12, (level, t) -> {
                for (int i = 0; i < 6; i++) {
                    Vec3 h = haloPoint(caster, i, 0f);
                    Vfx.mote(h.x, h.y, h.z, 0, -0.03, 0, sabdaColor(i), 0.06f, 16);
                }
            });
            case SABDA_ERASED -> erased(pos);
            case SABDA_VEIL_END -> {
                state(caster).veilUntil = 0L;
                mirrorShatter(pos, 1.0f);
            }
            default -> { }
        }
    }

    // ------------------------------------------------------------------ berubah wujud

    private static void transform(AbstractClientPlayer caster, boolean self) {
        int burst = ShazamAnim.AKSARA_MORPH_BURST;
        root(caster, burst);
        Vec3 feet = caster.position();
        groundSigil(feet, 2.4, GOLD, burst + 10, 0.06f);
        Vfx.add(new HoloRing(Lightning.Anchor.fixed(feet.add(0, 0.05, 0)), UP, 3.4, GOLD, burst + 12, 0.02f, 0.7f, null));
        // enam cakram datang dari enam arah, satu per satu, dan mengunci di slotnya
        for (int i = 0; i < 6; i++) {
            final int k = i;
            double a = i * Math.PI / 3.0 + caster.yBodyRot * Mth.DEG_TO_RAD;
            Vec3 from = feet.add(Math.cos(a) * 7.0, 2.2 + (i % 2) * 1.4, Math.sin(a) * 7.0);
            Vfx.add(new FlyingDisc(Lightning.Anchor.fixed(from), pt -> haloPoint(caster, k, pt), sabdaColor(i),
                    6 + i * 4, burst - 6 - i * 4, 1.4, 0.32f, true));
        }
        schedule(0, burst, (level, t) -> {
            RandomSource r = level.random;
            // garis prada menggurat badan: kilau emas merayap naik
            float k = t / (float) burst;
            for (int n = 0, c = Vfx.count(2 + 4 * k); n < c; n++) {
                double ang = r.nextDouble() * Math.PI * 2.0, d = 0.32 + r.nextDouble() * 0.12;
                double y = caster.getY() + Math.min(caster.getBbHeight(), r.nextDouble() * caster.getBbHeight() * (0.3 + k));
                Vfx.glint(caster.getX() + Math.cos(ang) * d, y, caster.getZ() + Math.sin(ang) * d, GOLD_HOT,
                        0.08f + 0.08f * k, 8);
            }
            if (t % 6 == 0) {
                Vfx.add(new Fx.Wave(caster.position().add(0, 0.06, 0), UP, 1.0 + k * 2.0, 0.12, GOLD, 12, 0.4f + 0.4f * k,
                        0.04f, null));
            }
            if (t > burst - 10) {
                ShazamFx.shakeAround(caster.position(), 0.05f, 16);
            }
        });
        schedule(burst, 1, (level, t) -> {
            Vec3 c = chest(caster);
            Vfx.add(new Fx.Flash(c, 3.2f, 0xFFFFFF, 6, 1f));
            Vfx.add(new Hd.Nova(c, 3.2, GOLD_HOT, GOLD, INDIGO, 0, 22, 0.8f, false));
            Vfx.add(new Fx.Wave(caster.position().add(0, 0.08, 0), UP, 6.5, 0.5, GOLD, 16, 0.9f, 0.08f,
                    ShazamFx.ground(level, caster.position(), 7.0)));
            for (int i = 0; i < 6; i++) {
                Vfx.add(new Fx.Wave(caster.position().add(0, 0.1 + i * 0.02, 0), UP, 2.0 + i * 0.8, 0.12, sabdaColor(i),
                        10 + i * 2, 0.7f, 0f, null));
            }
            CineKit.sparks(c, 40, GOLD, 0.5, 0.07f, 18, caster.getY());
            ShazamFx.dustPuffs(level, caster.position(), 0x8A7A66, 10, 1.6, 0.18);
            ShazamFx.shakeAround(c, 0.6f, 26);
            flash(caster, -1, 0);
            if (self) {
                FovKick.punch(0.18f);
                HelionComic.caption(Component.translatable("caption.shazammod.aksara"));
            }
        });
    }

    private static void revert(AbstractClientPlayer caster) {
        for (int i = 0; i < 6; i++) {
            final int k = i;
            Vec3 h = haloPoint(caster, i, 0f);
            Vec3 out = h.add(ShazamFx.randomDir(caster.getRandom()).scale(3.0)).add(0, 1.5, 0);
            Vfx.add(new FlyingDisc(pt -> haloPoint(caster, k, 0f), Lightning.Anchor.fixed(out), sabdaColor(i), 0, 14, 0.6,
                    0.3f, true));
        }
        schedule(0, 12, (level, t) -> {
            Vec3 c = chest(caster);
            HdKit.cinders(c, 6, 0.5, 0.01, GOLD, 0.08f, 26, 0.02f);
        });
        STATES.remove(caster.getId());
    }

    private static void knockout(AbstractClientPlayer caster, boolean self) {
        schedule(0, 1, (level, t) -> {
            Vec3 c = chest(caster);
            mirrorShatter(c, 1.4f);
            for (int i = 0; i < 6; i++) {
                Vec3 h = haloPoint(caster, i, 0f);
                CineKit.sparks(h, 8, sabdaColor(i), 0.25, 0.06f, 16, caster.getY());
            }
            ShazamFx.shakeAround(c, 0.5f, 30);
            if (self) {
                ScreenFx.vignette(0.5f, 0x1A1030, 30);
            }
        });
        STATES.remove(caster.getId());
    }

    private static void launch(AbstractClientPlayer caster) {
        Vec3 f = caster.position();
        groundSigil(f, 1.4, GOLD, 16, 0.2f);
        Vfx.add(new Fx.Ripple(f.add(0, 0.2, 0), new Vec3(0, -1, 0), 1.5, 0.6, 2.2, 0.16, GOLD, 10, 0.7f, false));
        CineKit.motesOut(f.add(0, 0.2, 0), 12, GOLD, 0.25, 0.06f, 14);
    }

    private static void land(AbstractClientPlayer caster, boolean crash, boolean self) {
        Vec3 f = caster.position();
        ClientLevel level = Minecraft.getInstance().level;
        Vfx.add(new HoloRing(Lightning.Anchor.fixed(f.add(0, 0.05, 0)), UP, crash ? 4.2 : 2.8, GOLD, 24, 0.05f, 0.8f, null));
        Vfx.add(new Fx.Wave(f.add(0, 0.08, 0), UP, crash ? 5.5 : 3.6, 0.3, GOLD, 12, 0.8f, 0.06f, null));
        if (crash && level != null) {
            ShazamFx.impact(level, caster, f, 1.6f, GOLD, GOLD_HOT, true, 0.6f);
        } else if (level != null) {
            ShazamFx.dustPuffs(level, f, 0x8A7A66, 8, 1.2, 0.14);
        }
        ShazamFx.shakeAround(f, crash ? 0.6f : 0.25f, 20);
    }

    private static void sonicBoom(AbstractClientPlayer caster) {
        Vec3 c = chest(caster);
        Vec3 d = caster.getDeltaMovement().lengthSqr() > 1.0E-4 ? caster.getDeltaMovement().normalize() : forward(caster);
        Vfx.add(new Fx.Ripple(c, d.scale(-1), 3.0, 0.8, 3.6, 0.22, RUANG, 12, 0.8f, false));
        Vfx.add(new Fx.Ripple(c, d.scale(-1), 2.0, 0.5, 2.6, 0.14, GOLD, 10, 0.9f, false));
        Vfx.add(new HoloRing(Lightning.Anchor.fixed(c), d, 1.8, GOLD, 12, 0.3f, 0.8f, null));
    }

    // ------------------------------------------------------------------ Penulisan Ulang (ritual)

    private static void rite(AbstractClientPlayer caster, boolean self) {
        int read = AksaraRite.READ, etch = AksaraRite.ETCH, burstAt = AksaraRite.BURST;
        root(caster, burstAt);
        Vec3 feet = caster.position();
        groundSigil(feet, 2.0, GOLD, burstAt + 10, 0.03f);
        // daun lontar berpendar di tangan kanan, lalu enam aksara terangkat dan mengorbit
        schedule(0, read, (level, t) -> {
            Vec3 h = ShazamPoses.handPos(caster, true, 1f);
            Vfx.glint(h.x, h.y + 0.05, h.z, GOLD_HOT, 0.18f, 3);
            if (t % 4 == 0) {
                Vfx.mote(h.x, h.y, h.z, 0, 0.05, 0, sabdaColor(t / 4), 0.07f, 18);
            }
        });
        for (int i = 0; i < 6; i++) {
            final int k = i;
            int start = 10 + i * 6;
            Vfx.add(new OrbitGlyph(caster, k, start, etch - start - (5 - i) * 10, 1.3));
            // menggurat badan satu per satu (READ..ETCH)
            schedule(read + i * 10, 1, (level, t) -> {
                Vec3 c = chest(caster);
                burst(c, sabdaColor(k), 0.8f, 8);
                ShazamFx.shakeAround(c, 0.12f, 14);
            });
        }
        schedule(read, etch - read, (level, t) -> {
            RandomSource r = level.random;
            for (int n = 0; n < 3; n++) {
                double ang = r.nextDouble() * Math.PI * 2.0;
                Vfx.glint(caster.getX() + Math.cos(ang) * 0.34, caster.getY() + r.nextDouble() * caster.getBbHeight(),
                        caster.getZ() + Math.sin(ang) * 0.34, GOLD_HOT, 0.1f, 8);
            }
        });
        // keenam aksara menyatu jadi cakram di punggung
        for (int i = 0; i < 6; i++) {
            final int k = i;
            double a = i * Math.PI / 3.0;
            Vec3 from = feet.add(Math.cos(a) * 1.4, 1.2 + 0.2 * i, Math.sin(a) * 1.4);
            Vfx.add(new FlyingDisc(Lightning.Anchor.fixed(from), pt -> haloPoint(caster, k, pt), sabdaColor(i),
                    etch + i * 4, burstAt - etch - i * 4, 0.6, 0.26f, true));
        }
        schedule(burstAt, 1, (level, t) -> {
            Vec3 c = chest(caster);
            Vfx.add(new Fx.Flash(c, 3.6f, 0xFFFFFF, 6, 1f));
            Vfx.add(new Hd.Nova(c, 3.6, GOLD_HOT, GOLD, INDIGO, 0, 24, 0.9f, false));
            Vfx.add(new Fx.Wave(feet.add(0, 0.08, 0), UP, 6.0, 0.4, GOLD, 18, 0.9f, 0.08f, null));
            CineKit.sparks(c, 50, GOLD, 0.55, 0.07f, 20, caster.getY());
            ShazamFx.shakeAround(c, 0.7f, 26);
            if (self) {
                FovKick.punch(0.2f);
                HelionComic.caption(Component.translatable("caption.shazammod.aksara_rite"));
            }
        });
    }

    // ------------------------------------------------------------------ Z - Sabda Daya

    private static void beam(AbstractClientPlayer caster, boolean self) {
        int w = ShazamAnim.AKSARA_BEAM_WINDUP, n = ShazamAnim.AKSARA_BEAM_TICKS;
        flash(caster, 0, w + n);
        schedule(0, w, (level, t) -> {   // tenaga merah tersedot ke telapak
            Vec3 h = ShazamPoses.handPos(caster, true, 1f);
            RandomSource r = level.random;
            for (int k = 0; k < 3; k++) {
                Vec3 d = ShazamFx.randomDir(r).scale(0.9 + r.nextDouble() * 0.6);
                Vfx.mote(h.x + d.x, h.y + d.y, h.z + d.z, -d.x * 0.14, -d.y * 0.14, -d.z * 0.14, DAYA, 0.06f, 7);
            }
            Vfx.glint(h.x, h.y, h.z, 0xFFFFFF, 0.12f + t * 0.02f, 3);
        });
        Vfx.add(new PowerBeam(caster, w, n));
        if (self) {
            schedule(w, n, (level, t) -> {
                CameraShake.add(0.06f);
                if (t == 0) {
                    FovKick.punch(-0.06f);
                }
            });
        }
    }

    private static void nova(AbstractClientPlayer caster, boolean self) {
        int w = ShazamAnim.AKSARA_NOVA_WINDUP;
        flash(caster, 0, w + 6);
        root(caster, w);
        Vfx.add(new Fx.Bubble(chest(caster), 2.4, DAYA, w, 0.6f, 1.0, 2.0, false));
        Vfx.add(new HoloRing(Lightning.Anchor.fixed(caster.position().add(0, 0.05, 0)), UP, 4.0, DAYA, w + 10, 0.08f, 0.8f, null));
        schedule(0, w, (level, t) -> {
            Vec3 c = chest(caster);
            RandomSource r = level.random;
            float k = t / (float) w;
            for (int i = 0; i < Vfx.count(3 + 5 * k); i++) {
                Vec3 d = ShazamFx.randomDir(r).scale(2.5 + r.nextDouble() * 1.5);
                Vfx.streak(c.x + d.x, c.y + d.y, c.z + d.z, -d.x * 0.22, -d.y * 0.22, -d.z * 0.22, DAYA, 0.05f, 9);
            }
            Vfx.glint(c.x, c.y, c.z, 0xFFFFFF, 0.2f + 0.3f * k, 3);
            ShazamFx.shakeAround(c, 0.02f + 0.06f * k, 14);
        });
        schedule(w, 1, (level, t) -> {
            Vec3 c = chest(caster);
            Vfx.add(new Fx.Flash(c, 4.5f, 0xFFFFFF, 6, 1f));
            Vfx.add(new Hd.Nova(c, AksaraSkills.NOVA_RADIUS, 0xFFE0D8, DAYA, 0x5A0812, 0x2A1414, 26, 1f, false));
            Vfx.add(new Fx.Wave(caster.position().add(0, 0.08, 0), UP, AksaraSkills.NOVA_RADIUS, 0.6, DAYA, 16, 1f, 0.1f,
                    ShazamFx.ground(level, caster.position(), AksaraSkills.NOVA_RADIUS + 1)));
            Vfx.add(new Fx.Wave(c, UP, AksaraSkills.NOVA_RADIUS * 0.7, 0.4, GOLD, 12, 0.8f, 0f, null));
            CineKit.sparks(c, 60, DAYA, 0.7, 0.08f, 20, caster.getY());
            ShazamFx.dustPuffs(level, caster.position(), 0x8A7A66, 14, 3.0, 0.25);
            ShazamFx.shakeAround(c, 0.9f, 30);
            if (self) {
                FovKick.punch(0.22f);
            }
        });
    }

    // ------------------------------------------------------------------ X - Sabda Ruang

    private static void fold(AbstractClientPlayer caster, Vec3 dest) {
        int snap = ShazamAnim.AKSARA_FOLD_SNAP;
        flash(caster, 1, snap + 10);
        schedule(0, snap, (level, t) -> {
            Vec3 h = ShazamPoses.handPos(caster, true, 1f);
            Vfx.glint(h.x, h.y, h.z, RUANG, 0.12f + t * 0.03f, 3);
        });
        schedule(snap, 1, (level, t) -> {
            Vec3 from = caster.position();
            Vfx.add(new Hd.Ghost(from, caster.yBodyRot, caster.getScale(), 0, RUANG, GOLD, 14, 0.8f));
            Vfx.add(new Hd.Lance(from.add(0, 1.0, 0), dest.add(0, 1.0, 0), 0.12f, RUANG, 0xFFFFFF, 2, 8));
        });
    }

    private static void gate(AbstractClientPlayer caster, Vec3 center, boolean self) {
        int open = ShazamAnim.AKSARA_GATE_OPEN, swallow = ShazamAnim.AKSARA_GATE_SWALLOW;
        flash(caster, 1, swallow + 6);
        Vec3 n = forward(caster).scale(-1);
        Vfx.add(new Portal(center, n, 2.4, RUANG, swallow - open + 14, open));
        Vfx.add(new HoloRing(Lightning.Anchor.fixed(center), n, 2.9, GOLD, swallow + 10, 0.08f, 0.8f, null));
        schedule(0, swallow + 4, (level, t) -> {
            RandomSource r = level.random;
            if (t >= open) {   // butiran & debu tersedot ke gerbang
                for (int k = 0; k < 3; k++) {
                    Vec3 d = ShazamFx.randomDir(r).scale(3.0 + r.nextDouble() * 4.0);
                    Vfx.streak(center.x + d.x, center.y + d.y * 0.5, center.z + d.z, -d.x * 0.12, -d.y * 0.06, -d.z * 0.12,
                            r.nextBoolean() ? RUANG : 0xC8B8FF, 0.05f, 10);
                }
            }
            if (self && t >= open) {
                CameraShake.add(0.02f);
            }
        });
    }

    // ------------------------------------------------------------------ C - Sabda Benak

    private static void lance(AbstractClientPlayer caster, Vec3 target, boolean self) {
        int hit = ShazamAnim.AKSARA_LANCE_HIT;
        flash(caster, 2, hit + 10);
        schedule(0, hit, (level, t) -> {
            Vec3 e = caster.getEyePosition(1f);
            if (t % 3 == 0) {
                Vfx.add(new HoloRing(Lightning.Anchor.fixed(e.add(0, 0.35, 0)), UP, 0.45 + t * 0.03, BENAK, 8, 0.3f,
                        0.7f, null));
            }
        });
        schedule(hit, 1, (level, t) -> {
            Vec3 e = caster.getEyePosition(1f).add(caster.getViewVector(1f).scale(0.3));
            Vfx.add(new Hd.Lance(e, target, 0.2f, BENAK, 0xFFFFFF, 2, 10));
            burst(target, BENAK, 1.3f, 14);
            Vfx.add(new Fx.Ripple(target, target.subtract(e), 2.0, 0.4, 1.6, 0.1, BENAK, 10, 0.8f, false));
            if (self) {
                FovKick.punch(-0.05f);
            }
        });
    }

    private static void dominion(AbstractClientPlayer caster, boolean self) {
        int hit = ShazamAnim.AKSARA_DOMINION_HIT;
        flash(caster, 2, hit + 20);
        schedule(0, hit, (level, t) -> {
            Vec3 h = caster.getEyePosition(1f).add(0, 0.3, 0);
            if (t % 3 == 0) {
                Vfx.add(new HoloRing(Lightning.Anchor.fixed(h), UP, 0.5 + t * 0.05, BENAK, 10, -0.25f, 0.8f, null));
            }
        });
        schedule(hit, 1, (level, t) -> {
            Vec3 c = chest(caster);
            Vfx.add(new Fx.Wave(c, UP, AksaraSkills.DOMINION_RADIUS, 0.35, BENAK, 18, 0.9f, 0.04f, null));
            Vfx.add(new Fx.Wave(caster.position().add(0, 0.08, 0), UP, AksaraSkills.DOMINION_RADIUS, 0.25, 0xFFFFFF, 14,
                    0.5f, 0f, null));
            Vfx.add(new Hd.Pressure(c, UP, 4.0, 2.0, BENAK, 16, 0.7f, true));
            burst(c, BENAK, 1.6f, 20);
            if (self) {
                ScreenFx.vignette(0.35f, BENAK, 20);
            }
        });
    }

    // ------------------------------------------------------------------ V - Sabda Maya

    private static void rewrite(AbstractClientPlayer caster, Vec3 at, boolean self) {
        int hit = ShazamAnim.AKSARA_REWRITE_HIT;
        flash(caster, 3, hit + 10);
        schedule(0, hit, (level, t) -> {   // jari menulis aksara magenta di udara
            Vec3 h = ShazamPoses.handPos(caster, true, 1f);
            Vfx.mote(h.x, h.y, h.z, 0, 0.005, 0, t % 2 == 0 ? MAYA : 0xFFE6F6, 0.07f, 18);
            Vfx.glint(h.x, h.y, h.z, MAYA, 0.1f, 4);
        });
        schedule(hit, 1, (level, t) -> {
            Vfx.add(new HoloRing(Lightning.Anchor.fixed(at.add(0, -0.5, 0)), UP, AksaraSkills.REWRITE_RADIUS, MAYA, 30, -0.06f,
                    0.9f, ShazamFx.ground(level, at, AksaraSkills.REWRITE_RADIUS + 1)));
            Vfx.add(new Fx.Flash(at, 3.0f, 0xFFFFFF, 5, 0.9f));
            Vfx.add(new Fx.Wave(at, UP, AksaraSkills.REWRITE_RADIUS, 0.3, MAYA, 14, 0.9f, 0.08f, null));
            glitch(level, at, 28, 2.4);
            ShazamFx.shakeAround(at, 0.3f, 20);
        });
    }

    /** Pecahan kenyataan: kepingan magenta, sian, dan putih yang melompat-lompat (glitch). */
    private static void glitch(ClientLevel level, Vec3 c, int count, double spread) {
        RandomSource r = level.random;
        int[] colors = {MAYA, BENAK, 0xFFFFFF, 0x8A2BE2};
        for (int i = 0, n = Vfx.count(count); i < n; i++) {
            Vec3 d = ShazamFx.randomDir(r).scale(spread * r.nextDouble());
            Vfx.shard(c.x + d.x, c.y + d.y, c.z + d.z, (r.nextDouble() - 0.5) * 0.2, 0.05 + r.nextDouble() * 0.15,
                    (r.nextDouble() - 0.5) * 0.2, colors[r.nextInt(colors.length)], 0.08f + r.nextFloat() * 0.1f,
                    16 + r.nextInt(10), c.y - 3.0);
        }
    }

    private static void poof(ClientLevel level, Vec3 at) {
        if (level == null) {
            return;
        }
        Vfx.add(new Fx.Flash(at, 1.6f, MAYA, 7, 0.7f));
        glitch(level, at, 14, 0.8);
        ShazamFx.smokeCloud(level, at, 0xF4E8F0, 6, 0.6);
        HelionComic.word(at.add(0, 0.8, 0), "DEL", 0xFFFFFF, MAYA, 0.8f);
    }

    private static void veil(AbstractClientPlayer caster) {
        int hit = ShazamAnim.AKSARA_VEIL_HIT;
        flash(caster, 3, hit + 6);
        schedule(hit, 1, (level, t) -> {
            Vec3 f = caster.position();
            mirrorShatter(chest(caster), 1.0f);
            for (int i = 0; i < 4; i++) {   // empat bayangan cermin di sekelilingnya
                double a = i * Math.PI / 2.0 + caster.yBodyRot * Mth.DEG_TO_RAD + Math.PI / 4.0;
                Vec3 g = f.add(Math.cos(a) * 1.6, 0, Math.sin(a) * 1.6);
                Vfx.add(new Hd.Ghost(g, caster.yBodyRot + i * 37f, caster.getScale(), 0, MAYA, 0xFFE6F6, 40 + i * 6, 0.55f));
            }
            state(caster).veilUntil = level.getGameTime() + ShazamAnim.AKSARA_VEIL_TICKS;
        });
    }

    private static void mirrorShatter(Vec3 c, float size) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) {
            return;
        }
        RandomSource r = level.random;
        Vfx.add(new Fx.Flash(c, 1.8f * size, 0xFFE6F6, 5, 0.8f));
        for (int i = 0, n = Vfx.count(24 * size); i < n; i++) {
            Vec3 d = ShazamFx.randomDir(r);
            Vfx.shard(c.x, c.y, c.z, d.x * 0.25 * size, d.y * 0.25 * size + 0.08, d.z * 0.25 * size,
                    r.nextBoolean() ? 0xFFE6F6 : MAYA, 0.07f + r.nextFloat() * 0.08f, 18 + r.nextInt(8), c.y - 2.5);
        }
    }

    // ------------------------------------------------------------------ B - Sabda Kala

    private static void timeStop(AbstractClientPlayer caster, boolean self) {
        int hit = ShazamAnim.AKSARA_TIMESTOP_HIT, ticks = ShazamAnim.AKSARA_TIMESTOP_TICKS;
        flash(caster, 4, hit + ticks);
        schedule(0, hit, (level, t) -> {   // jam kecil terbentuk di atas telapak yang terangkat
            Vec3 h = ShazamPoses.handPos(caster, true, 1f).add(0, 0.35, 0);
            if (t % 2 == 0) {
                Vfx.add(new HoloRing(Lightning.Anchor.fixed(h), toCamera(h), 0.3 + t * 0.03, KALA, 6, 0.4f, 0.8f, null));
            }
        });
        schedule(hit, 1, (level, t) -> {
            Vec3 c = caster.position().add(0, 1.0, 0);
            Vfx.add(new ClockField(caster.position().add(0, 0.07, 0), AksaraSkills.TIMESTOP_RADIUS, ticks));
            Vfx.add(new Fx.Bubble(c, AksaraSkills.TIMESTOP_RADIUS, KALA, ticks, 0.28f, 1.0, 3.0, true));
            Vfx.add(new Fx.Flash(c, 5f, 0xFFF4D8, 6, 0.8f));
            Vfx.add(new Fx.Wave(caster.position().add(0, 0.08, 0), UP, AksaraSkills.TIMESTOP_RADIUS, 0.4, KALA, 14, 0.9f,
                    0.05f, null));
            if (self) {
                ScreenFx.vignette(0.32f, KALA, ticks);
                FovKick.punch(-0.08f);
            }
        });
        schedule(hit, ticks, (level, t) -> {   // debu & butiran yang berhenti di udara
            if (t % 3 == 0) {
                RandomSource r = level.random;
                Vec3 c = caster.position();
                for (int k = 0; k < 4; k++) {
                    double a = r.nextDouble() * Math.PI * 2.0, d = r.nextDouble() * AksaraSkills.TIMESTOP_RADIUS;
                    Vfx.mote(c.x + Math.cos(a) * d, c.y + 0.3 + r.nextDouble() * 3.0, c.z + Math.sin(a) * d, 0, 0, 0,
                            r.nextInt(3) == 0 ? 0xFFFFFF : KALA, 0.05f, 30);
                }
            }
        });
    }

    private static void timeEnd(AbstractClientPlayer caster, Vec3 c, boolean self) {
        Vfx.add(new Fx.Flash(c, 6f, 0xFFF4D8, 6, 0.9f));
        Vfx.add(new Fx.Wave(c.add(0, -0.9, 0), UP, AksaraSkills.TIMESTOP_RADIUS + 2, 0.6, KALA, 16, 1f, 0.06f, null));
        Vfx.add(new Hd.Pressure(c, UP, 6.0, 3.0, KALA, 14, 0.8f, true));
        CineKit.sparks(c, 40, KALA, 0.6, 0.07f, 18, c.y - 1.5);
        ShazamFx.shakeAround(c, 0.7f, 30);
        if (self) {
            FovKick.punch(0.16f);
        }
    }

    private static void rewind(AbstractClientPlayer caster, Vec3 dest) {
        int hit = ShazamAnim.AKSARA_REWIND_HIT;
        flash(caster, 4, hit + 8);
        Vec3 from = caster.position();
        schedule(0, hit, (level, t) -> {
            Vec3 c = chest(caster);
            Vfx.add(new HoloRing(Lightning.Anchor.fixed(c), toCamera(c), 0.9, KALA, 5, -0.6f, 0.8f, null));
        });
        schedule(hit, 1, (level, t) -> {
            Vfx.add(new Hd.Ghost(from, caster.yBodyRot, caster.getScale(), 0, KALA, 0xFFF4D8, 18, 0.7f));
            Vfx.add(new Hd.Lance(from.add(0, 1.0, 0), dest.add(0, 1.0, 0), 0.08f, KALA, 0xFFFFFF, 3, 10));
            Vfx.add(new ClockField(dest.add(0, 0.07, 0), 2.2, 18));
            burst(dest.add(0, 1.0, 0), KALA, 1.2f, 12);
        });
    }

    // ------------------------------------------------------------------ N - Sabda Atma

    private static void soul(AbstractClientPlayer caster) {
        int w = ShazamAnim.AKSARA_SOUL_WINDUP, n = ShazamAnim.AKSARA_SOUL_TICKS;
        flash(caster, 5, w + n);
        for (LivingEntity target : nearbyEnemies(caster, AksaraSkills.SOUL_RADIUS, 5)) {
            Vfx.add(new SoulTether(caster, target, w, n));
        }
        Vfx.add(new Hd.Haze(Lightning.Anchor.on(caster, 0, 0, 0), 1.2, 2.2, 6, ATMA, w + n, 0.5f));
    }

    private static void soulRip(Vec3 at) {
        Vfx.add(new Fx.Flash(at, 1.6f, ATMA, 8, 0.7f));
        Vfx.add(new Hd.Ghost(at.add(0, -0.9, 0), Vfx.random().nextFloat() * 360f, 0.8, 0, ATMA, 0xE0FFE8, 22, 0.6f));
        CineKit.motesOut(at, 14, ATMA, 0.18, 0.07f, 20);
    }

    private static void ward(AbstractClientPlayer caster) {
        int hit = ShazamAnim.AKSARA_WARD_HIT;
        flash(caster, 5, hit + 10);
        schedule(hit, 1, (level, t) -> {
            Vfx.add(new Hd.Shield(Lightning.Anchor.on(caster, 0, caster.getBbHeight() * 0.55, 0), 1.6 * caster.getScale(),
                    ATMA, 0xE0FFE8, ShazamAnim.AKSARA_WARD_TICKS, 0.55f));
            burst(chest(caster), ATMA, 1.4f, 16);
            Vfx.add(new Fx.Wave(caster.position().add(0, 0.08, 0), UP, 4.0, 0.25, ATMA, 14, 0.8f, 0.05f, null));
        });
    }

    // ------------------------------------------------------------------ R - Sabda Purna & Penghapusan

    private static void purna(AbstractClientPlayer caster, boolean self) {
        int hit = ShazamAnim.AKSARA_PURNA_HIT;
        root(caster, hit);
        State s = state(caster);
        for (int i = 0; i < 6; i++) {
            s.discFlash[i] = caster.level().getGameTime() + i * 4L;
        }
        schedule(0, hit, (level, t) -> {
            float k = t / (float) hit;
            for (int i = 0; i < 6; i++) {
                if (t >= i * 4) {
                    Vec3 h = haloPoint(caster, i, 1f);
                    Vfx.glint(h.x, h.y, h.z, sabdaColor(i), 0.15f + 0.2f * k, 3);
                }
            }
            Vec3 c = chest(caster);
            for (int n = 0; n < Vfx.count(2 + 4 * k); n++) {
                Vec3 d = ShazamFx.randomDir(level.random).scale(3.0);
                Vfx.streak(c.x + d.x, c.y + d.y, c.z + d.z, -d.x * 0.18, -d.y * 0.18, -d.z * 0.18, PURNA, 0.05f, 9);
            }
            ShazamFx.shakeAround(c, 0.03f + 0.08f * k, 16);
        });
        Vfx.add(new Hd.Corona(Lightning.Anchor.on(caster, 0, caster.getBbHeight() * 0.62, 0), 0.6, 2.6, 18, GOLD, PURNA,
                hit + 30, 0.7f, null));
        schedule(hit, 1, (level, t) -> {
            Vec3 c = chest(caster);
            Vfx.add(new Fx.Flash(c, 5f, 0xFFFFFF, 7, 1f));
            Vfx.add(new Hd.Nova(c, AksaraSkills.PURNA_BURST_RADIUS, 0xFFFFFF, PURNA, GOLD, 0, 26, 1f, false));
            Vfx.add(new Fx.Pillar(caster.position(), 26.0, 1.4f, PURNA, 22));
            for (int i = 0; i < 6; i++) {
                Vfx.add(new Fx.Wave(caster.position().add(0, 0.1 + i * 0.03, 0), UP, 3.0 + i * 1.1, 0.2, sabdaColor(i),
                        12 + i * 2, 0.9f, 0f, null));
            }
            CineKit.sparks(c, 60, PURNA, 0.7, 0.08f, 22, caster.getY());
            ShazamFx.shakeAround(c, 0.9f, 30);
            if (self) {
                FovKick.punch(0.24f);
                ScreenFlash.flash(0.35f, 0xFFF4DC);
                HelionComic.caption(Component.translatable("caption.shazammod.aksara_purna"));
            }
        });
    }

    private static void erase(AbstractClientPlayer caster, boolean self) {
        int hit = ShazamAnim.AKSARA_ERASE_HIT;
        root(caster, hit + 6);
        Vec3 feet = caster.position();
        double r = AksaraSkills.ERASE_RADIUS;
        // heksagram raksasa di tanah, enam tiang warna di penjurunya, dunia menggelap
        Vfx.add(new HoloRing(Lightning.Anchor.fixed(feet.add(0, 0.06, 0)), UP, r * 0.55, PURNA, hit + 20, 0.015f, 0.9f,
                ShazamFx.ground(Minecraft.getInstance().level, feet, r * 0.6)));
        groundSigil(feet, r * 0.3, GOLD, hit + 16, -0.03f);
        for (int i = 0; i < 6; i++) {
            final int k = i;
            double a = i * Math.PI / 3.0;
            Vec3 p = feet.add(Math.cos(a) * r * 0.55, 0, Math.sin(a) * r * 0.55);
            schedule(10 + i * 6, hit - 10 - i * 6, (level, t) -> {
                if (t % 4 == 0) {
                    Vfx.add(new Fx.Pillar(p, 9.0, 0.45f, sabdaColor(k), 6));
                }
                Vfx.mote(p.x, p.y + level.random.nextDouble() * 6.0, p.z, 0, 0.08, 0, sabdaColor(k), 0.08f, 14);
            });
        }
        schedule(0, hit, (level, t) -> {
            float k = t / (float) hit;
            Vec3 c = chest(caster);
            RandomSource rnd = level.random;
            for (int n = 0; n < Vfx.count(2 + 6 * k); n++) {
                Vec3 d = ShazamFx.randomDir(rnd).scale(6.0 + rnd.nextDouble() * 6.0);
                Vfx.streak(c.x + d.x, c.y + d.y, c.z + d.z, -d.x * 0.14, -d.y * 0.14, -d.z * 0.14, 0xFFFFFF, 0.05f, 12);
            }
            ShazamFx.shakeAround(c, 0.02f + 0.12f * k, 30);
            if (self && t == 20) {
                ScreenFx.vignette(0.6f, 0x05040A, hit - 20);
            }
        });
        schedule(hit, 1, (level, t) -> {
            Vec3 c = chest(caster);
            Vfx.add(new Fx.Flash(c, 9f, 0xFFFFFF, 8, 1f));
            Vfx.add(new Hd.Nova(c, r, 0xFFFFFF, PURNA, INDIGO, 0, 30, 1f, false));
            Vfx.add(new Fx.Wave(feet.add(0, 0.1, 0), UP, r, 1.0, 0xFFFFFF, 22, 1f, 0.1f,
                    ShazamFx.ground(level, feet, r + 1)));
            Vfx.add(new Fx.Wave(feet.add(0, 0.12, 0), UP, r * 0.7, 0.6, GOLD, 18, 0.9f, 0f, null));
            CineKit.sparks(c, 90, 0xFFFFFF, 0.9, 0.09f, 24, caster.getY());
            ShazamFx.shakeAround(c, 1.4f, 48);
            if (self) {
                ScreenFlash.flash(0.8f, 0xFFFFFF);
                FovKick.punch(0.3f);
                HelionComic.caption(Component.translatable("caption.shazammod.aksara_erase"));
            }
        });
    }

    private static void erased(Vec3 at) {
        Vfx.add(new Hd.Ghost(at.add(0, -0.9, 0), Vfx.random().nextFloat() * 360f, 1.0, 0, 0xFFFFFF, PURNA, 26, 0.9f));
        Vfx.add(new Fx.Flash(at, 2.4f, 0xFFFFFF, 8, 0.9f));
        CineKit.motesOut(at, 24, 0xFFFFFF, 0.3, 0.07f, 22);
    }

    // ------------------------------------------------------------------ M - Lontar Cakram / Perisai Sabda

    private static void discs(AbstractClientPlayer caster) {
        int throwAt = ShazamAnim.AKSARA_DISCS_THROW, flight = ShazamAnim.AKSARA_DISCS_FLIGHT;
        State s = state(caster);
        s.discCounter = 0;
        s.discsOutUntil = caster.level().getGameTime() + throwAt + flight + 16;
        List<LivingEntity> targets = nearbyEnemies(caster, AksaraSkills.DISC_RANGE, 6);
        for (int i = 0; i < 6; i++) {
            final int k = i;
            Lightning.Anchor to;
            if (!targets.isEmpty()) {
                LivingEntity e = targets.get(i % targets.size());
                to = pt -> e.getPosition(pt).add(0, e.getBbHeight() * 0.55, 0);
            } else {
                double a = (i - 2.5) * 0.35 + caster.yBodyRot * Mth.DEG_TO_RAD;
                Vec3 end = caster.position().add(-Math.sin(a) * 12.0, 1.4, Math.cos(a) * 12.0);
                to = Lightning.Anchor.fixed(end);
            }
            Vfx.add(new FlyingDisc(pt -> haloPoint(caster, k, pt), to, sabdaColor(i), throwAt, flight + k, 0.8, 0.3f,
                    false));
        }
        // kembali ke halo sesudah mengenai
        for (int i = 0; i < 6; i++) {
            final int k = i;
            Lightning.Anchor from = !targets.isEmpty() ? pt -> {
                LivingEntity e = targets.get(k % targets.size());
                return e.getPosition(pt).add(0, e.getBbHeight() * 0.55, 0);
            } : Lightning.Anchor.fixed(caster.position().add(0, 1.4, 0));
            Vfx.add(new FlyingDisc(from, pt -> haloPoint(caster, k, pt), sabdaColor(i), throwAt + flight + k + 1, 10, 0.5,
                    0.24f, true));
        }
    }

    private static void discHit(AbstractClientPlayer caster, Vec3 at) {
        State s = state(caster);
        int k = Math.floorMod(s.discCounter++, 6);
        s.discFlash[k] = caster.level().getGameTime();
        burst(at, sabdaColor(k), 1.0f, 10);
        if (k == 1) {
            Vfx.add(new Implosion(at, RUANG, 10, 1.6));
        } else if (k == 2) {
            Vfx.add(new MindLock(at.add(0, 0.5, 0), 40));
        } else if (k == 5) {
            Vfx.add(new SoulTether(caster, null, 0, 8, at));
        }
    }

    /** Pasif Rombongan Drone: drone terdekat menembak — bolt merah-putih + percikan kecil. */
    private static void droneShot(AbstractClientPlayer caster, Vec3 at) {
        Vec3 best = null;
        double bd = Double.MAX_VALUE;
        for (int i = 0; i < 6; i++) {
            Vec3 h = haloPoint(caster, i, 1f);
            double d = h.distanceToSqr(at);
            if (d < bd) {
                bd = d;
                best = h;
            }
        }
        if (best != null) {
            Vfx.add(new Hd.Lance(best, at, 0.09f, 0xFF3A3A, 0xFFFFFF, 0, 5));
        }
        Vfx.add(new Fx.Flash(at, 0.9f, 0xFF3A3A, 5, 0.6f));
        CineKit.sparks(at, 4, 0xFF5A4A, 0.22, 0.05f, 8, at.y - 2.0);
    }

    private static void shield(AbstractClientPlayer caster) {
        flash(caster, 1, 10);
        State s = state(caster);
        s.discsOutUntil = caster.level().getGameTime() + ShazamAnim.AKSARA_SHIELD_TICKS;
        Vfx.add(new DiscShield(caster, ShazamAnim.AKSARA_SHIELD_TICKS));
    }

    // ------------------------------------------------------------------ J - Langkah Ruang / Tulis Ulang Diri

    private static void step(AbstractClientPlayer caster, Vec3 dest) {
        Vec3 from = caster.position();
        Vfx.add(new Hd.Ghost(from, caster.yBodyRot, caster.getScale(), 1, INDIGO, GOLD, 12, 0.8f));
        Vfx.add(new Hd.Lance(from.add(0, 1.0, 0), dest.add(0, 1.0, 0), 0.07f, RUANG, GOLD_HOT, 1, 6));
        Vfx.add(new Implosion(from.add(0, 1.0, 0), RUANG, 8, 1.4));
        Vfx.add(new HoloRing(Lightning.Anchor.fixed(dest.add(0, 0.06, 0)), UP, 1.0, GOLD, 12, 0.3f, 0.8f, null));
    }

    private static void selfRewrite(AbstractClientPlayer caster) {
        int hit = ShazamAnim.AKSARA_SELF_HIT;
        schedule(0, hit, (level, t) -> {
            RandomSource r = level.random;
            for (int n = 0; n < 3; n++) {
                double a = r.nextDouble() * Math.PI * 2.0;
                Vfx.glint(caster.getX() + Math.cos(a) * 0.34, caster.getY() + r.nextDouble() * caster.getBbHeight(),
                        caster.getZ() + Math.sin(a) * 0.34, GOLD_HOT, 0.1f, 8);
            }
        });
        schedule(hit, 1, (level, t) -> {
            flash(caster, -1, 0);
            Vec3 c = chest(caster);
            burst(c, GOLD, 1.6f, 18);
            Vfx.add(new Fx.Wave(caster.position().add(0, 0.08, 0), UP, 3.0, 0.2, ATMA, 12, 0.8f, 0.05f, null));
            CineKit.motesOut(c, 18, ATMA, 0.15, 0.07f, 20);
        });
    }

    // ------------------------------------------------------------------ penanda kecil & pasif

    private static void haloPulse(AbstractClientPlayer caster) {
        State s = state(caster);
        s.pulseAt = caster.level().getGameTime();
        if (caster.isInvisible()) {
            return;
        }
        schedule(0, 12, (level, t) -> {
            if (t % 2 == 0 && t / 2 < 6) {
                int i = t / 2;
                Vec3 h = haloPoint(caster, i, 1f);
                Vfx.glint(h.x, h.y, h.z, sabdaColor(i), 0.22f, 6);
                Vfx.mote(h.x, h.y, h.z, 0, 0.03, 0, sabdaColor(i), 0.06f, 14);
            }
        });
        Vfx.add(new Fx.Wave(caster.position().add(0, 0.06, 0), UP, 1.4, 0.1, GOLD, 12, 0.35f, 0.03f, null));
    }

    private static void punch(AbstractClientPlayer caster, Vec3 at) {
        RandomSource r = Vfx.random();
        int rgb = sabdaColor(r.nextInt(6));
        Vfx.add(new Fx.Flash(at, 1.1f, 0xFFFFFF, 3, 0.8f));
        Vfx.add(new Fx.Flash(at, 1.8f, rgb, 7, 0.4f));
        Vfx.add(new HoloRing(Lightning.Anchor.fixed(at), at.subtract(caster.getEyePosition(1f)), 0.55, GOLD, 8, 0.5f,
                0.8f, null));
        CineKit.sparks(at, 8, rgb, 0.3, 0.05f, 10, at.y - 2.0);
    }

    private static void sixfold(AbstractClientPlayer caster, Vec3 at, boolean self) {
        Vfx.add(new Fx.Flash(at, 2.6f, 0xFFFFFF, 5, 1f));
        for (int i = 0; i < 6; i++) {
            double a = i * Math.PI / 3.0;
            Vec3 p = at.add(Math.cos(a) * 0.9, Math.sin(a) * 0.9, 0);
            Vfx.add(new Fx.Flash(p, 1.2f, sabdaColor(i), 9, 0.6f));
            CineKit.sparks(at, 8, sabdaColor(i), 0.45, 0.06f, 14, at.y - 2.5);
        }
        Vfx.add(new HoloRing(Lightning.Anchor.fixed(at), at.subtract(caster.getEyePosition(1f)), 1.4, GOLD, 14, 0.4f,
                1f, null));
        Vfx.add(new Fx.Wave(at, at.subtract(caster.getEyePosition(1f)), AksaraSkills.SIXFOLD_RADIUS, 0.3, GOLD, 12, 0.8f,
                0.05f, null));
        ShazamFx.shakeAround(at, 0.4f, 20);
        if (self) {
            FovKick.punch(0.08f);
        }
    }

    private static void phase(AbstractClientPlayer caster, Vec3 to) {
        Vec3 from = caster.position();
        Vfx.add(new Hd.Ghost(from, caster.yBodyRot, caster.getScale(), 0, RUANG, GOLD, 12, 0.75f));
        Vfx.add(new Implosion(from.add(0, 1.0, 0), RUANG, 10, 1.8));
        Vfx.add(new HoloRing(Lightning.Anchor.fixed(to.add(0, 0.06, 0)), UP, 1.1, RUANG, 12, 0.4f, 0.8f, null));
    }

    private static void inscribe(AbstractClientPlayer caster, int sabda, boolean full, boolean self) {
        State s = state(caster);
        if (sabda >= 0 && sabda < 6) {
            s.inscribed |= 1 << sabda;
            s.discFlash[sabda] = caster.level().getGameTime();
            Vec3 h = haloPoint(caster, sabda, 1f);
            burst(h, sabdaColor(sabda), 0.6f, 6);
        }
        if (full) {
            for (int i = 0; i < 6; i++) {
                s.discFlash[i] = caster.level().getGameTime() + i * 2L;
            }
            Vfx.add(new Fx.Wave(caster.position().add(0, 0.08, 0), UP, 3.0, 0.2, GOLD, 16, 0.9f, 0.05f, null));
            Vfx.add(new HoloRing(Lightning.Anchor.fixed(caster.position().add(0, 0.05, 0)), UP, 2.6, GOLD, 30, 0.05f, 0.8f, null));
            if (self) {
                HelionComic.caption(Component.translatable("caption.shazammod.aksara_complete"));
            }
        }
    }

    // ------------------------------------------------------------------ tiap tick: efek yang selalu ada

    public static void tick(ClientLevel level) {
        try {
            Minecraft mc = Minecraft.getInstance();
            long now = level.getGameTime();
            for (AbstractClientPlayer p : level.players()) {
                if (!ShazamClientState.isAksara(p.getId()) || !ShazamClientState.isTransformed(p.getId())) {
                    continue;
                }
                State s = state(p);
                boolean firstPerson = p == mc.player && mc.options.getCameraType().isFirstPerson();
                float old = Vfx.setBoost(BOOST);
                try {
                    if (p.isInvisible()) {   // Cermin Maya: cuma kilau samar yang terlihat
                        if (now < s.veilUntil && p.tickCount % 6 == 0) {
                            Vec3 c = chest(p);
                            Vfx.glint(c.x + (level.random.nextDouble() - 0.5) * 0.6, c.y + (level.random.nextDouble() - 0.5),
                                    c.z + (level.random.nextDouble() - 0.5) * 0.6, MAYA, 0.06f, 6);
                        }
                        continue;
                    }
                    ambient(level, p, s, firstPerson, now);
                } finally {
                    Vfx.setBoost(old);
                }
            }
            STATES.keySet().removeIf(id -> level.getEntity(id) == null);
        } catch (RuntimeException ignored) {
            // efek nggak boleh bikin game crash
        }
    }

    private static void ambient(ClientLevel level, AbstractClientPlayer p, State s, boolean firstPerson, long now) {
        RandomSource r = level.random;
        boolean purna = ShazamClientState.isRaging(p.getId());
        boolean flying = ShazamClientState.isFlying(p.getId());
        // butiran warna dari halo
        if (!firstPerson && now >= s.discsOutUntil && p.tickCount % (purna ? 1 : 4) == 0) {
            int i = r.nextInt(6);
            Vec3 h = haloPoint(p, i, 1f);
            Vfx.mote(h.x, h.y, h.z, (r.nextDouble() - 0.5) * 0.02, purna ? 0.05 : 0.015, (r.nextDouble() - 0.5) * 0.02,
                    sabdaColor(i), purna ? 0.07f : 0.045f, purna ? 18 : 14);
        }
        // melayang: cincin prada samar di bawah kaki
        if (!flying && p.tickCount % 12 == 0) {
            Vec3 f = p.position().add(0, 0.05, 0);
            Vfx.add(new Fx.Wave(f, UP, 0.75, 0.07, GOLD, 14, purna ? 0.5f : 0.25f, 0.06f, null));
        }
        if (!flying && p.tickCount % 3 == 0) {
            Vfx.mote(p.getX() + (r.nextDouble() - 0.5) * 0.4, p.getY() + 0.05, p.getZ() + (r.nextDouble() - 0.5) * 0.4,
                    0, 0.01, 0, GOLD, 0.035f, 12);
        }
        // Sabda Purna: butiran putih-emas naik dari badan
        if (purna && p.tickCount % 2 == 0) {
            Vfx.glint(p.getX() + (r.nextDouble() - 0.5) * 0.9, p.getY() + r.nextDouble() * p.getBbHeight(),
                    p.getZ() + (r.nextDouble() - 0.5) * 0.9, PURNA, 0.08f, 8);
        }
        // tinju bermuatan (Tinju Enam Sabda siap): kepalan memercikkan enam warna
        if (ShazamClientState.isCharged(p.getId()) && !firstPerson && p.tickCount % 3 == 0) {
            Vec3 h = ShazamPoses.handPos(p, r.nextBoolean(), 1f);
            Vfx.glint(h.x, h.y, h.z, sabdaColor(r.nextInt(6)), 0.09f, 5);
        }
    }

    /** Jejak terbang (dipanggil ShazamFx.flightTrail): pita prada dari kedua tangan, butiran enam warna dari halo. */
    static void flightTrail(ClientLevel level, AbstractClientPlayer player, float speed) {
        State s = state(player);
        if (s.trails == null || !s.trails[0].following()) {
            s.trails = new Fx.Trail[] {
                    new Fx.Trail(player, pt -> ShazamPoses.handPos(player, true, pt), GOLD, 0.08f, 12, 4, false),
                    new Fx.Trail(player, pt -> ShazamPoses.handPos(player, false, pt), GOLD, 0.08f, 12, 4, false)};
            Vfx.add(s.trails[0]);
            Vfx.add(s.trails[1]);
        }
        s.trails[0].sustain(3);
        s.trails[1].sustain(3);
        if (speed > 1.0f && level.random.nextInt(2) == 0) {
            int i = level.random.nextInt(6);
            Vec3 h = haloPoint(player, i, 1f);
            Vfx.streak(h.x, h.y, h.z, -(player.getX() - player.xo) * 0.3, -(player.getY() - player.yo) * 0.3,
                    -(player.getZ() - player.zo) * 0.3, sabdaColor(i), 0.05f, 8);
        }
    }

    // ================================================================== efek khusus

    /** Cakram yang melayang dari satu titik ke titik lain (melengkung), dengan ekor warnanya. */
    static final class FlyingDisc extends Effect {
        private final Lightning.Anchor from, to;
        private final int rgb, delay, flight;
        private final double arc;
        private final float size;
        private final boolean fade;

        FlyingDisc(Lightning.Anchor from, Lightning.Anchor to, int rgb, int delay, int flight, double arc, float size,
                   boolean fade) {
            super(delay + Math.max(1, flight) + (fade ? 4 : 2));
            this.from = from;
            this.to = to;
            this.rgb = rgb;
            this.delay = delay;
            this.flight = Math.max(1, flight);
            this.arc = arc;
            this.size = size;
            this.fade = fade;
        }

        private Vec3 at(float time, float pt) {
            float u = Mth.clamp((time - delay) / flight, 0f, 1f);
            float e = 1f - (1f - u) * (1f - u) * (1f - u);
            Vec3 a = from.at(pt), b = to.at(pt);
            return a.lerp(b, e).add(0, Math.sin(e * Math.PI) * arc, 0);
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float time = age + pt;
            if (time < delay) {
                return;
            }
            float a = 1f;
            if (time > delay + flight) {
                if (!fade) {
                    return;
                }
                a = Mth.clamp(1f - (time - delay - flight) / 4f, 0f, 1f);
            }
            Vec3 p = at(time, pt);
            Vec3 n = toCamera(p);
            d.glow(p.x, p.y, p.z, size * 2.2f, rgb, 0.45f * a);
            d.ring(p.x, p.y, p.z, n.x, n.y, n.z, size, size * 0.3, rgb, 0.95f * a, 0.3f, null);
            d.ring(p.x, p.y, p.z, n.x, n.y, n.z, size * 0.55, size * 0.12, GOLD_HOT, 0.8f * a, 0f, null);
            d.glint(p.x, p.y, p.z, size * 0.9f, time * 0.4f, 0xFFFFFF, 0.7f * a);
            Vec3 q = at(Math.max(delay, time - 2.5f), pt);
            d.line(q.x, q.y, q.z, p.x, p.y, p.z, size * 0.15f, size * 0.7f, rgb, 0f, 0.55f * a);
        }
    }

    /** Sinar Daya: dari telapak kanan ke titik bidik (dihitung ulang tiap frame, berhenti di blok). */
    static final class PowerBeam extends Effect {
        private final AbstractClientPlayer caster;
        private final int delay, ticks;
        private Vec3 lastEnd;

        PowerBeam(AbstractClientPlayer caster, int delay, int ticks) {
            super(delay + ticks + 6);
            this.caster = caster;
            this.delay = delay;
            this.ticks = ticks;
        }

        private Vec3 end(Vec3 eye, Vec3 look) {
            Vec3 far = eye.add(look.scale(40.0));
            BlockHitResult hit = caster.level().clip(new ClipContext(eye, far, ClipContext.Block.COLLIDER,
                    ClipContext.Fluid.NONE, caster));
            return hit.getType() == HitResult.Type.MISS ? far : hit.getLocation();
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (age >= delay && age < delay + ticks && lastEnd != null) {   // percikan & asap di ujung sinar
                RandomSource r = level.random;
                CineKit.sparks(lastEnd, 4, DAYA, 0.35, 0.06f, 9, lastEnd.y - 2.0);
                if (age % 3 == 0) {
                    Vfx.add(new Fx.Flash(lastEnd, 1.6f, DAYA, 5, 0.5f));
                    ShazamFx.smokeCloud(level, lastEnd, 0x3A1A1A, 1, 0.3);
                }
                if (r.nextInt(3) == 0) {
                    Vfx.ember(lastEnd.x, lastEnd.y, lastEnd.z, (r.nextDouble() - 0.5) * 0.2, 0.1, (r.nextDouble() - 0.5) * 0.2,
                            0.06f, 14);
                }
            }
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float time = age + pt;
            if (time < delay || caster.isRemoved()) {
                return;
            }
            float on = time < delay + 2 ? (time - delay) / 2f : time > delay + ticks ? 1f - (time - delay - ticks) / 6f : 1f;
            on = Mth.clamp(on, 0f, 1f);
            if (on <= 0.01f) {
                return;
            }
            Vec3 hand = ShazamPoses.handPos(caster, true, pt);
            Vec3 eye = caster.getEyePosition(pt);
            Vec3 look = caster.getViewVector(pt).normalize();
            Vec3 end = end(eye, look);
            lastEnd = end;
            Vec3 dir = end.subtract(hand);
            double len = dir.length();
            if (len < 0.2) {
                return;
            }
            dir = dir.scale(1.0 / len);
            float width = (0.34f + 0.05f * Mth.sin(time * 1.7f)) * on;
            d.beam(hand.x, hand.y, hand.z, end.x, end.y, end.z, width, DAYA, 0xFFFFFF, 0.95f * on, 0.9f * on);
            d.line(hand.x, hand.y, hand.z, end.x, end.y, end.z, width * 2.6f, width * 3.2f, 0x6A0A18, 0.25f * on, 0.2f * on);
            // cincin aksara meluncur di sepanjang sinar
            double gap = 2.6;
            double shift = (time * 0.9) % gap;
            for (double s = shift; s < len; s += gap) {
                Vec3 p = hand.add(dir.scale(s));
                float fade = (float) (1.0 - s / len) * on;
                d.ring(p.x, p.y, p.z, dir.x, dir.y, dir.z, width * 1.6 + 0.05 * s, 0.05, s % (gap * 2) < gap ? GOLD : DAYA,
                        0.7f * fade, 0f, null);
            }
            d.flare(hand.x, hand.y, hand.z, 0.9f * on, DAYA, 0.9f);
            d.flare(end.x, end.y, end.z, 1.5f * on, DAYA, 0.9f);
            d.glow(end.x, end.y, end.z, 2.4f * on, DAYA, 0.5f);
            d.glint(end.x, end.y, end.z, 0.8f * on, time * 0.3f, 0xFFFFFF, 0.9f);
        }
    }

    /** Ruang terlipat: cincin-cincin mengerut ke satu titik, gores-gores tersedot, kilatan di akhir. */
    static final class Implosion extends Effect {
        private final Vec3 c;
        private final int rgb;
        private final double radius;
        private final Vec3[] dirs = new Vec3[14];
        private final Vec3[] normals = new Vec3[3];

        Implosion(Vec3 c, int rgb, int life, double radius) {
            super(life);
            this.c = c;
            this.rgb = rgb;
            this.radius = radius;
            RandomSource r = Vfx.random();
            for (int i = 0; i < dirs.length; i++) {
                dirs[i] = ShazamFx.randomDir(r);
            }
            for (int i = 0; i < normals.length; i++) {
                normals[i] = ShazamFx.randomDir(r);
            }
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (age == life - 2) {
                Vfx.add(new Fx.Flash(c, (float) radius * 0.7f, 0xFFFFFF, 4, 0.9f));
                Vfx.add(new Fx.Flash(c, (float) radius, rgb, 7, 0.5f));
            }
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float k = progress(d.partialTick);
            float shrink = 1f - k * k;
            for (int i = 0; i < normals.length; i++) {
                Vec3 n = normals[i];
                d.ring(c.x, c.y, c.z, n.x, n.y, n.z, radius * shrink * (1.0 - i * 0.15), 0.08, i == 0 ? GOLD : rgb,
                        0.8f * (0.3f + 0.7f * k), 0f, null);
            }
            for (Vec3 v : dirs) {
                double a = radius * shrink, b = Math.max(0.0, a - 0.9);
                d.line(c.x + v.x * a, c.y + v.y * a, c.z + v.z * a, c.x + v.x * b, c.y + v.y * b, c.z + v.z * b,
                        0.02f, 0.06f, rgb, 0f, 0.8f);
            }
            d.glow(c.x, c.y, c.z, (float) (0.4 + radius * 0.2 * k), rgb, 0.6f * k);
        }
    }

    /** Gerbang: cakram kehampaan bertepi cincin berputar & lengan spiral, terbuka lalu menutup. */
    static final class Portal extends Effect {
        private final Vec3 c, n, u, v;
        private final double radius;
        private final int rgb, open;

        Portal(Vec3 c, Vec3 normal, double radius, int rgb, int life, int open) {
            super(life);
            this.c = c;
            this.n = normal.normalize();
            Vec3 h = Math.abs(n.y) > 0.9 ? new Vec3(1, 0, 0) : UP;
            this.u = n.cross(h).normalize();
            this.v = n.cross(u).normalize();
            this.radius = radius;
            this.rgb = rgb;
            this.open = Math.max(1, open);
        }

        private float size(float time) {
            float in = Mth.clamp(time / open, 0f, 1f);
            float out = Mth.clamp((life - time) / 6f, 0f, 1f);
            return (1f - (1f - in) * (1f - in)) * out;
        }

        @Override
        public void renderSoft(Draw d) {
            float s = size(age + d.partialTick);
            if (s > 0.01f) {
                d.disc(c.x, c.y, c.z, n.x, n.y, n.z, radius * 0.92 * s, VOID, 0.92f, 0.6f, null);
            }
        }

        @Override
        public void renderGlow(Draw d) {
            float time = age + d.partialTick;
            float s = size(time);
            if (s <= 0.01f) {
                return;
            }
            double r = radius * s;
            d.ring(c.x, c.y, c.z, n.x, n.y, n.z, r, 0.16, rgb, 0.95f, 0.05f, null);
            d.ring(c.x, c.y, c.z, n.x, n.y, n.z, r * 1.12, 0.06, GOLD, 0.7f, 0f, null);
            d.ring(c.x, c.y, c.z, n.x, n.y, n.z, r * 0.6, 0.05, 0xC8B8FF, 0.5f, 0f, null);
            for (int k = 0; k < 6; k++) {   // lengan spiral yang berputar masuk
                double a0 = time * 0.18 + k * Math.PI / 3.0;
                double px = 0, py = 0, pz = 0;
                for (int j = 0; j <= 6; j++) {
                    double t = j / 6.0;
                    double a = a0 + t * 2.2;
                    double rr = r * (1.0 - t * 0.85);
                    Vec3 p = c.add(u.scale(Math.cos(a) * rr)).add(v.scale(Math.sin(a) * rr));
                    if (j > 0) {
                        d.line(px, py, pz, p.x, p.y, p.z, 0.05f, 0.03f, rgb, 0.7f * (float) (1.0 - t), 0.7f * (float) (1.0 - t));
                    }
                    px = p.x;
                    py = p.y;
                    pz = p.z;
                }
            }
            d.glow(c.x, c.y, c.z, (float) r * 1.3f, rgb, 0.25f);
        }
    }

    /** Henti Kala: jam raksasa di tanah (dua lingkaran, dua belas garis, dua jarum yang berhenti). */
    static final class ClockField extends Effect {
        private final Vec3 c;
        private final double radius;
        private final float handA, handB;

        ClockField(Vec3 c, double radius, int life) {
            super(life);
            this.c = c;
            this.radius = radius;
            RandomSource r = Vfx.random();
            this.handA = r.nextFloat() * Mth.TWO_PI;
            this.handB = r.nextFloat() * Mth.TWO_PI;
        }

        @Override
        public void renderGlow(Draw d) {
            float time = age + d.partialTick;
            float in = Mth.clamp(time / 6f, 0f, 1f), out = Mth.clamp((life - time) / 8f, 0f, 1f);
            float a = in * out;
            if (a <= 0.01f) {
                return;
            }
            double r = radius * (0.6 + 0.4 * in);
            d.ring(c.x, c.y, c.z, 0, 1, 0, r, 0.18, KALA, 0.8f * a, 0.03f, null);
            d.ring(c.x, c.y, c.z, 0, 1, 0, r * 0.82, 0.08, GOLD_HOT, 0.6f * a, 0f, null);
            for (int k = 0; k < 12; k++) {
                double ang = k * Math.PI / 6.0;
                double r0 = r * (k % 3 == 0 ? 0.7 : 0.76);
                d.flatLine(c.x + Math.cos(ang) * r0, c.y, c.z + Math.sin(ang) * r0,
                        c.x + Math.cos(ang) * r * 0.82, c.y, c.z + Math.sin(ang) * r * 0.82, 0, 1, 0,
                        k % 3 == 0 ? 0.18f : 0.09f, KALA, 0.8f * a, 0.8f * a);
            }
            // jarum: berputar sebentar lalu berhenti (waktu berhenti)
            float spin = Mth.clamp(1f - time / 8f, 0f, 1f);
            double ha = handA + spin * 3.0, hb = handB + spin * 9.0;
            d.flatLine(c.x, c.y, c.z, c.x + Math.cos(ha) * r * 0.45, c.y, c.z + Math.sin(ha) * r * 0.45, 0, 1, 0, 0.3f,
                    GOLD_HOT, 0.9f * a, 0.6f * a);
            d.flatLine(c.x, c.y, c.z, c.x + Math.cos(hb) * r * 0.68, c.y, c.z + Math.sin(hb) * r * 0.68, 0, 1, 0, 0.18f,
                    KALA, 0.9f * a, 0.5f * a);
            d.glow(c.x, c.y + 0.05, c.z, 0.9f, GOLD_HOT, 0.8f * a);
        }
    }

    /** Pengunci benak: dua cincin sian yang berputar miring di kepala musuh. */
    static final class MindLock extends Effect {
        private final Vec3 c;

        MindLock(Vec3 c, int life) {
            super(life);
            this.c = c;
        }

        @Override
        public void renderGlow(Draw d) {
            float time = age + d.partialTick;
            float a = Mth.clamp(time / 4f, 0f, 1f) * Mth.clamp((life - time) / 8f, 0f, 1f);
            for (int k = 0; k < 2; k++) {
                double ang = time * (k == 0 ? 0.25 : -0.32);
                double nx = Math.sin(ang) * 0.5, ny = 1.0, nz = Math.cos(ang) * 0.5;
                d.ring(c.x, c.y, c.z, nx, ny, nz, 0.55 + k * 0.15, 0.05, k == 0 ? BENAK : 0xFFFFFF, 0.8f * a, 0f, null);
            }
            for (int k = 0; k < 3; k++) {
                double ang = time * 0.2 + k * Mth.TWO_PI / 3.0;
                d.glint(c.x + Math.cos(ang) * 0.6, c.y + 0.1, c.z + Math.sin(ang) * 0.6, 0.12f, time * 0.2f, BENAK, 0.9f * a);
            }
        }
    }

    /** Tali jiwa: pita hijau bergelombang dari musuh ke kedua tangan Aksara, butiran mengalir ke arahnya. */
    static final class SoulTether extends Effect {
        private final AbstractClientPlayer caster;
        private final LivingEntity target;
        private final Vec3 fixed;
        private final int delay, ticks;

        SoulTether(AbstractClientPlayer caster, LivingEntity target, int delay, int ticks) {
            this(caster, target, delay, ticks, null);
        }

        SoulTether(AbstractClientPlayer caster, LivingEntity target, int delay, int ticks, Vec3 fixed) {
            super(delay + ticks + 4);
            this.caster = caster;
            this.target = target;
            this.fixed = fixed;
            this.delay = delay;
            this.ticks = ticks;
        }

        private Vec3 source(float pt) {
            if (target != null && target.isAlive()) {
                return target.getPosition(pt).add(0, target.getBbHeight() * 0.6, 0);
            }
            return fixed;
        }

        @Override
        public boolean tick(ClientLevel level) {
            Vec3 s = source(1f);
            if (age >= delay && age < delay + ticks && s != null && age % 2 == 0) {
                Vec3 h = ShazamPoses.handPos(caster, level.random.nextBoolean(), 1f);
                Vec3 d = h.subtract(s).scale(0.09);
                Vfx.mote(s.x, s.y, s.z, d.x, d.y, d.z, level.random.nextBoolean() ? ATMA : 0xE0FFE8, 0.06f, 11);
            }
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float time = age + pt;
            Vec3 s = source(pt);
            if (time < delay || s == null || caster.isRemoved()) {
                return;
            }
            float a = Mth.clamp((time - delay) / 3f, 0f, 1f) * Mth.clamp((delay + ticks + 4 - time) / 4f, 0f, 1f);
            Vec3 h = ShazamPoses.handPos(caster, true, pt).add(ShazamPoses.handPos(caster, false, pt)).scale(0.5);
            Vec3 dir = h.subtract(s);
            double len = dir.length();
            if (len < 0.1) {
                return;
            }
            Vec3 side = dir.cross(UP);
            side = side.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : side.normalize();
            Vec3 up = side.cross(dir).normalize();
            double px = s.x, py = s.y, pz = s.z;
            for (int i = 1; i <= 12; i++) {
                double t = i / 12.0;
                double w = Math.sin(t * Math.PI) * 0.35 * Math.sin(time * 0.5 + t * 9.0);
                double w2 = Math.sin(t * Math.PI) * 0.25 * Math.cos(time * 0.4 + t * 7.0);
                Vec3 p = s.add(dir.scale(t)).add(side.scale(w)).add(up.scale(w2));
                d.line(px, py, pz, p.x, p.y, p.z, 0.09f, 0.09f, ATMA, 0.75f * a, 0.75f * a);
                d.line(px, py, pz, p.x, p.y, p.z, 0.03f, 0.03f, 0xFFFFFF, 0.6f * a, 0.6f * a);
                px = p.x;
                py = p.y;
                pz = p.z;
            }
            d.glow(s.x, s.y, s.z, 0.8f, ATMA, 0.5f * a);
        }
    }

    /** Perisai Sabda: heksagon enam cakram berputar di depan dada, bidang cahaya tipis. */
    static final class DiscShield extends Effect {
        private final AbstractClientPlayer caster;

        DiscShield(AbstractClientPlayer caster, int life) {
            super(life);
            this.caster = caster;
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float time = age + pt;
            if (caster.isRemoved() || caster.isInvisible()) {
                return;
            }
            float a = Mth.clamp(time / 3f, 0f, 1f) * Mth.clamp((life - time) / 6f, 0f, 1f);
            float yaw = Mth.lerp(pt, caster.yBodyRotO, caster.yBodyRot) * Mth.DEG_TO_RAD;
            Vec3 fwd = new Vec3(-Mth.sin(yaw), 0, Mth.cos(yaw));
            Vec3 right = new Vec3(-fwd.z, 0, fwd.x);
            Vec3 c = caster.getPosition(pt).add(0, caster.getBbHeight() * 0.6, 0).add(fwd.scale(0.85));
            double r = 0.62 * caster.getScale();
            d.disc(c.x, c.y, c.z, fwd.x, fwd.y, fwd.z, r * 1.25, RUANG, 0.16f * a, 0.3f * a, null);
            double px = 0, py = 0, pz = 0, fx = 0, fy = 0, fz = 0;
            for (int i = 0; i <= 6; i++) {
                double ang = time * 0.12 + i * Math.PI / 3.0;
                Vec3 p = c.add(right.scale(Math.cos(ang) * r)).add(0, Math.sin(ang) * r, 0);
                if (i < 6) {
                    d.ring(p.x, p.y, p.z, fwd.x, fwd.y, fwd.z, 0.18, 0.05, sabdaColor(i), 0.9f * a, 0.3f, null);
                }
                if (i > 0) {
                    d.line(px, py, pz, p.x, p.y, p.z, 0.03f, 0.03f, GOLD, 0.8f * a, 0.8f * a);
                } else {
                    fx = p.x;
                    fy = p.y;
                    fz = p.z;
                }
                px = p.x;
                py = p.y;
                pz = p.z;
            }
            d.line(px, py, pz, fx, fy, fz, 0.03f, 0.03f, GOLD, 0.8f * a, 0.8f * a);
        }
    }

    /**
     * Cincin hologram tech (pengganti Runes.Circle, tanpa rune): dua cincin konsentris, sisir tick berputar, dan empat
     * braket sudut bidik. Argumennya sama persis dengan Runes.Circle lama supaya bisa ditukar langsung.
     */
    static final class HoloRing extends Effect {
        private final Lightning.Anchor center;
        private final double nx, ny, nz;
        private final double radius;
        private final int rgb;
        private final float spin, strength;
        private final Draw.Height ground;

        HoloRing(Lightning.Anchor center, Vec3 normal, double radius, int rgb, int life, float spin, float strength,
                 Draw.Height ground) {
            super(life);
            this.center = center;
            Vec3 n = normal.normalize();
            this.nx = n.x;
            this.ny = n.y;
            this.nz = n.z;
            this.radius = radius;
            this.rgb = rgb;
            this.spin = spin;
            this.strength = strength;
            this.ground = ground;
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float time = age + pt;
            float appear = Math.min(1f, time / 6f);
            float scale = 1f - (1f - appear) * (1f - appear) * (1f - appear);   // out-cubic (Fx.outCubic package-private)
            float fade = Math.min(1f, (life - time) / 8f);
            float a = strength * fade;
            if (a <= 0.01f || scale <= 0.01f) {
                return;
            }
            Vec3 c = center.at(pt);
            double r = radius * scale;
            double[] e = new double[6];
            Draw.plane(nx, ny, nz, e);
            d.ring(c.x, c.y, c.z, nx, ny, nz, r, 0.07 * scale, rgb, a, 0.08f, ground);
            d.ring(c.x, c.y, c.z, nx, ny, nz, r * 0.62, 0.045 * scale, rgb, a * 0.7f, 0f, ground);
            float rot = time * spin;
            for (int k = 0; k < 24; k++) {                 // sisir tick di tepi luar
                double ang = Math.PI * 2.0 * k / 24 + rot * 0.3;
                double len = k % 4 == 0 ? 0.16 : 0.07;
                seg(d, c, e, ang, r * 1.02, ang, r * 1.02 + len * scale, 0.04f * scale, a * 0.8f);
            }
            for (int k = 0; k < 4; k++) {                  // braket sudut bidik yang berputar
                double base = Math.PI / 2.0 * k + rot;
                seg(d, c, e, base - 0.18, r * 0.86, base + 0.18, r * 0.86, 0.06f * scale, a);
                seg(d, c, e, base - 0.18, r * 0.86, base - 0.18, r * 0.99, 0.06f * scale, a);
                seg(d, c, e, base + 0.18, r * 0.86, base + 0.18, r * 0.99, 0.06f * scale, a);
            }
            d.glow(c.x + nx * 0.03, c.y + ny * 0.03, c.z + nz * 0.03, (float) (r * 0.5), rgb, a * 0.18f);
        }

        private void seg(Draw d, Vec3 c, double[] e, double a0, double r0, double a1, double r1, float w, float a) {
            double x0 = c.x + (e[0] * Math.cos(a0) + e[3] * Math.sin(a0)) * r0;
            double y0 = c.y + (e[1] * Math.cos(a0) + e[4] * Math.sin(a0)) * r0;
            double z0 = c.z + (e[2] * Math.cos(a0) + e[5] * Math.sin(a0)) * r0;
            double x1 = c.x + (e[0] * Math.cos(a1) + e[3] * Math.sin(a1)) * r1;
            double y1 = c.y + (e[1] * Math.cos(a1) + e[4] * Math.sin(a1)) * r1;
            double z1 = c.z + (e[2] * Math.cos(a1) + e[5] * Math.sin(a1)) * r1;
            if (ground != null) {
                y0 += ground.at(Math.atan2(z0 - c.z, x0 - c.x), Math.hypot(x0 - c.x, z0 - c.z));
                y1 += ground.at(Math.atan2(z1 - c.z, x1 - c.x), Math.hypot(x1 - c.x, z1 - c.z));
            }
            d.flatLine(x0, y0, z0, x1, y1, z1, nx, ny, nz, w, rgb, a, a);
        }
    }

    /** Ikon subsistem yang terangkat dari inti dan mengorbit (pengunduhan kesadaran), lalu menyelam ke badan. */
    static final class OrbitGlyph extends Effect {
        private final AbstractClientPlayer caster;
        private final int index, start, orbit;
        private final double radius;

        OrbitGlyph(AbstractClientPlayer caster, int index, int start, int orbit, double radius) {
            super(start + Math.max(1, orbit) + 8);
            this.caster = caster;
            this.index = index;
            this.start = start;
            this.orbit = Math.max(1, orbit);
            this.radius = radius;
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float time = age + pt - start;
            if (time < 0f || caster.isRemoved()) {
                return;
            }
            Vec3 c = caster.getPosition(pt).add(0, caster.getBbHeight() * 0.6, 0);
            float dive = Mth.clamp((time - orbit) / 8f, 0f, 1f);
            double ang = time * 0.12 + index * Math.PI / 3.0;
            double r = radius * Mth.clamp(time / 10f, 0f, 1f) * (1f - dive);
            Vec3 p = c.add(Math.cos(ang) * r, Math.sin(time * 0.15 + index) * 0.4 * (1f - dive), Math.sin(ang) * r);
            int rgb = sabdaColor(index);
            float a = 1f - dive * 0.8f;
            d.glint(p.x, p.y, p.z, 0.3f, time * 0.2f, rgb, 0.9f * a);
            d.glow(p.x, p.y, p.z, 0.6f, rgb, 0.45f * a);
            Vec3 n = toCamera(p);
            d.ring(p.x, p.y, p.z, n.x, n.y, n.z, 0.22, 0.04, GOLD_HOT, 0.7f * a, 0f, null);
        }
    }
}
