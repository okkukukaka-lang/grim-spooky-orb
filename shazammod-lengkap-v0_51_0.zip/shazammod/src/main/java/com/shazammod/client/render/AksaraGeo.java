package com.shazammod.client.render;

import com.shazammod.AksaraSkills;
import com.shazammod.ShazamMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.shazammod.client.vfx.Draw;

import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * 0.51 Bentuk 3D PRALAYA (orisinal, robot/android — bukan magis), menempel pada bagian badan model pemain (ikut gerak &
 * putarannya), memakai alat gambar titik Helion3Geo.Out. Angka dalam piksel model (1/16 blok).
 *
 *   kepala  : pita optik merah tunggal menyilang wajah, brow/visor bersudut, pelat rahang, dan ANTENA (deret spike komunikasi
 *             naik dari tengkuk) + dua pod sensor di pelipis
 *   badan   : kolar bahu bersudut, housing REAKTOR INTI merah di dada, rig drone di punggung, pelat pinggang, dan
 *             ROMBONGAN DRONE: enam drone oktagon mengorbit di punggung (tiap drone lampu status warna subsistemnya),
 *             makin besar & cepat saat Singularitas, padam sebentar saat dilempar
 *   lengan  : pauldron bahu bersudut, pelindung siku, housing ventilasi lengan bawah
 *   kaki    : pelindung lutut, pelat tulang kering
 */
public final class AksaraGeo {
    public static final ResourceLocation GOLD = ShazamMod.id("textures/entity/aksara/gold.png");   // logam trim (baja sikat)
    public static final ResourceLocation PLATE = ShazamMod.id("textures/entity/aksara/plate.png");
    private static final int FULLBRIGHT = 15728880;
    private static final int STEEL = 0x3C424C, DARK = 0x20222A, DRONE = 0x2A2D36;
    private static final int RED_GLOW = 0xFF2A32, WHITE_GLOW = 0xFFF0EC;

    private AksaraGeo() {}

    /** Keadaan drone & cahaya yang dihitung AksaraLayer dari AksaraFx (per pemain, per frame). */
    public static final class Look {
        public float age;          // waktu (tick + pt)
        public float purna;        // 0..1 Protokol Singularitas
        public float flare;        // 0..1 kilatan sesudah skill
        public float discsOut;     // 0..1 drone sedang dilempar (rig kosong)
        public final float[] disc = new float[6];   // 0..1 terang tiap drone
    }

    // ------------------------------------------------------------------ bentuk (rangka logam)

    /** Brow/visor bersudut, pelat rahang, pod sensor pelipis. */
    private static void helm(Helion3Geo.Out o) {
        o.slab(0f, -5.35f, -4.2f, 3.7f, 0f, 0f, 0f, 0.5f, 0.1f, 0f, -0.1f, 0.3f);    // brow visor
        o.slab(0f, -1.1f, -4.15f, 3.0f, 0f, 0f, 0f, 0.9f, 0.08f, 0f, -0.08f, 0.28f);  // pelat rahang
        for (int s = -1; s <= 1; s += 2) {
            o.slab(4.1f * s, -4.2f, 0f, 0.3f, 0f, 0f, 0f, 1.3f, 0f, 0f, 0f, 1.5f);     // pod sensor pelipis
            o.slab(4.3f * s, -4.2f, -1.2f, 0.18f, 0f, 0f, 0f, 0.5f, 0f, 0f, 0f, 0.4f);
        }
    }

    /** Antena komunikasi: tiga spike naik dari tengkuk + fin kecil (mengganti mahkota). */
    private static void antenna(Helion3Geo.Out o) {
        o.prism(0f, -8.0f, 2.6f, 0.2f, -13.6f, 3.6f, 0.26f, 0.06f, 0.26f, 0.06f, true);      // antena utama
        for (int s = -1; s <= 1; s += 2) {
            o.prism(2.0f * s, -7.8f, 2.4f, 2.9f * s, -11.6f, 3.4f, 0.2f, 0.05f, 0.2f, 0.05f, true);
        }
        o.slab(0f, -8.1f, 1.4f, 0.14f, 0f, 0f, 0f, 1.0f, 0f, 0.3f, 0f, 1.6f);                // fin punggung kepala
        o.slab(0f, -7.7f, -4.2f, 1.4f, 0f, 0f, 0f, 0.3f, 0f, 0f, 0f, 0.2f);                  // visor atas dahi
    }

    /** Kolar bahu, housing reaktor, rig drone punggung, pelat pinggang. */
    private static void frame(Helion3Geo.Out o) {
        for (int s = -1; s <= 1; s += 2) {                                                   // kolar bahu bersudut
            o.slab(2.8f * s, 1.2f, -1.4f, 1.5f, 0f, 0f, 0f, 0.7f, 0.2f, 0f, -0.2f, 1.3f);
        }
        o.slab(0f, 1.0f, -2.35f, 1.6f, 0f, 0f, 0f, 0.6f, 0f, 0f, 0f, 0.25f);                 // pelat dada atas
        // housing reaktor inti (bingkai di sekeliling inti merah)
        for (int s = -1; s <= 1; s += 2) {
            o.slab(1.9f * s, 6.0f, -2.35f, 0.4f, 0f, 0f, 0f, 1.7f, 0f, 0f, 0f, 0.3f);
            o.slab(0f, 4.2f + 1.8f * (s + 1) / 2f, -2.35f, 1.9f, 0f, 0f, 0f, 0.35f, 0f, 0f, 0f, 0.3f);
        }
        o.slab(0f, 11.2f, 0f, 4.2f, 0f, 0f, 0f, 0.6f, 0f, 0f, 0f, 2.25f);                    // pelat pinggang
        o.slab(0f, 11.2f, -2.35f, 1.4f, 0f, 0f, 0f, 1.0f, 0f, 0f, 0f, 0.25f);                // gesper depan
        // rig drone di punggung
        o.slab(0f, 3.2f, 2.35f, 1.7f, 0f, 0f, 0f, 2.0f, 0f, 0f, 0f, 0.35f);
        for (int s = -1; s <= 1; s += 2) {
            o.prism(1.3f * s, 2.0f, 2.5f, 2.2f * s, 1.2f, 3.4f, 0.2f, 0.12f, 0.9f, 0.4f, true);   // rel peluncur
        }
    }

    /** Pauldron bahu bersudut + housing ventilasi lengan bawah. */
    private static void armPlate(Helion3Geo.Out o) {
        o.slab(-1.4f, -2.55f, 0f, 2.5f, -0.6f, 0f, 0.2f, 0.75f, 0f, 0f, 0f, 2.45f);          // pauldron
        o.slab(-1.0f, 7.4f, -1.1f, 1.7f, 0f, 0f, 0f, 1.6f, 0f, 0f, 0f, 0.5f);                // housing ventilasi depan
    }

    /** Trim baja: tepi pauldron, pelindung siku, gelang. */
    private static void armTrim(Helion3Geo.Out o) {
        o.slab(-1.45f, -3.1f, 0f, 2.55f, -0.6f, 0f, 0.2f, 0.18f, 0f, 0f, 0f, 2.55f);         // tepi pauldron
        o.slab(-1.0f, 4.6f, 0f, 2.3f, 0f, 0f, 0f, 0.6f, 0f, 0f, 0f, 2.3f);                   // pelindung siku
        o.slab(-1.0f, 9.4f, 0f, 2.25f, 0f, 0f, 0f, 0.4f, 0f, 0f, 0f, 2.25f);                 // gelang
    }

    /** Pelindung lutut + pelat tulang kering (baja). */
    private static void legTrim(Helion3Geo.Out o) {
        o.slab(0f, 6.2f, -1.0f, 2.2f, 0f, 0f, 0f, 0.7f, 0f, 0f, 0f, 1.4f);                   // lutut
        o.slab(0f, 9.0f, -2.1f, 1.5f, 0f, 0f, 0f, 1.8f, 0f, 0f, 0f, 0.4f);                   // tulang kering
        o.slab(0f, 10.9f, 0f, 2.18f, 0f, 0f, 0f, 0.4f, 0f, 0f, 0f, 2.18f);                   // gelang kaki
    }

    // ------------------------------------------------------------------ rombongan drone

    private static final int SIDES = 8;   // oktagon: terlihat mekanis

    /** Badan drone oktagon pipih menghadap ke belakang (+z). */
    private static void disc(Helion3Geo.Out o, float cx, float cy, float cz, float r, float thick, float spin) {
        float z0 = cz - thick * 0.5f, z1 = cz + thick * 0.5f;
        for (int i = 0; i < SIDES; i++) {
            float a0 = spin + i * Mth.TWO_PI / SIDES, a1 = spin + (i + 1) * Mth.TWO_PI / SIDES;
            float x0 = cx + Mth.cos(a0) * r, y0 = cy + Mth.sin(a0) * r;
            float x1 = cx + Mth.cos(a1) * r, y1 = cy + Mth.sin(a1) * r;
            o.quad(cx, cy, z1, x0, y0, z1, x1, y1, z1, cx, cy, z1, cx, cy, cz, 0.5f, 0.5f, 1f, 1f);
            o.quad(cx, cy, z0, x1, y1, z0, x0, y0, z0, cx, cy, z0, cx, cy, cz, 0.5f, 0.5f, 1f, 1f);
            o.quad(x0, y0, z0, x1, y1, z0, x1, y1, z1, x0, y0, z1, cx, cy, cz, 0f, 0f, 1f, 0.25f);
        }
    }

    /** Bingkai drone (baja) di tepi oktagon. */
    private static void rim(Helion3Geo.Out o, float cx, float cy, float cz, float r, float width, float thick, float spin) {
        float z0 = cz - thick * 0.5f, z1 = cz + thick * 0.5f;
        float ri = r - width;
        for (int i = 0; i < SIDES; i++) {
            float a0 = spin + i * Mth.TWO_PI / SIDES, a1 = spin + (i + 1) * Mth.TWO_PI / SIDES;
            float c0 = Mth.cos(a0), s0 = Mth.sin(a0), c1 = Mth.cos(a1), s1 = Mth.sin(a1);
            o.quad(cx + c0 * ri, cy + s0 * ri, z1, cx + c0 * r, cy + s0 * r, z1, cx + c1 * r, cy + s1 * r, z1,
                    cx + c1 * ri, cy + s1 * ri, z1, cx, cy, cz, 0f, 0f, 1f, 1f);
            o.quad(cx + c1 * ri, cy + s1 * ri, z0, cx + c1 * r, cy + s1 * r, z0, cx + c0 * r, cy + s0 * r, z0,
                    cx + c0 * ri, cy + s0 * ri, z0, cx, cy, cz, 0f, 0f, 1f, 1f);
            o.quad(cx + c0 * r, cy + s0 * r, z0, cx + c1 * r, cy + s1 * r, z0, cx + c1 * r, cy + s1 * r, z1,
                    cx + c0 * r, cy + s0 * r, z1, cx, cy, cz, 0f, 0f, 1f, 1f);
        }
    }

    /** Mata sensor drone yang menyala (warna subsistemnya): kotak terang + palang pindai mendatar. */
    private static void droneEye(Helion3Geo.Out o, float cx, float cy, float cz, float r, float side) {
        float z = cz + side;
        float s = r * 0.32f;
        o.quad(cx - s, cy - s, z, cx + s, cy - s, z, cx + s, cy + s, z, cx - s, cy + s, z, cx, cy, cz, 0f, 0f, 1f, 1f);
        float w = r * 0.62f, h = r * 0.1f;
        o.quad(cx - w, cy - h, z, cx + w, cy - h, z, cx + w, cy + h, z, cx - w, cy + h, z, cx, cy, cz, 0f, 0f, 1f, 1f);
    }

    /** Titik pusat drone ke-i di ruang badan. */
    private static float[] discCenter(int i, Look look) {
        float orbit = 7.4f + 1.6f * look.purna;
        float speed = 0.012f + 0.03f * look.purna;
        float a = look.age * speed + i * Mth.TWO_PI / 6f + Mth.HALF_PI;
        float bob = Mth.sin(look.age * 0.09f + i) * 0.35f;
        return new float[] {Mth.cos(a) * orbit, 3.0f - Mth.sin(a) * orbit + bob, 6.4f + 0.6f * look.purna};
    }

    private static float discRadius(Look look) {
        return 1.75f + 0.7f * look.purna;
    }

    // ------------------------------------------------------------------ gambar

    /** Semua bagian 3D di badan (sesudah kulit & cahaya kulit digambar AksaraLayer). */
    public static void render(ModelPart head, ModelPart body, ModelPart rightArm, ModelPart leftArm, ModelPart rightLeg,
                              ModelPart leftLeg, PoseStack ps, MultiBufferSource buffers, int light, int overlay, Look look) {
        Helion3Geo.Out o = new Helion3Geo.Out();
        o.light = light;
        o.overlay = overlay;
        boolean rig = look.discsOut < 0.5f;
        // 1) trim baja (antena, kolar, housing, pauldron edge, siku/lutut, bingkai drone)
        o.vc = buffers.getBuffer(RenderType.entityCutoutNoCull(GOLD));
        Helion3Geo.tint(o, 0xFFFFFF, 1f);
        Helion3Geo.part(head, ps, o, 1f, AksaraGeo::antenna);
        Helion3Geo.part(body, ps, o, 1f, AksaraGeo::frame);
        Helion3Geo.part(rightArm, ps, o, 1f, AksaraGeo::armTrim);
        Helion3Geo.part(leftArm, ps, o, -1f, AksaraGeo::armTrim);
        Helion3Geo.part(rightLeg, ps, o, 1f, AksaraGeo::legTrim);
        Helion3Geo.part(leftLeg, ps, o, -1f, AksaraGeo::legTrim);
        if (rig) {
            float r = discRadius(look);
            Helion3Geo.part(body, ps, o, 1f, out -> {
                for (int i = 0; i < 6; i++) {
                    float[] c = discCenter(i, look);
                    rim(out, c[0], c[1], c[2], r, 0.42f, 0.7f, look.age * 0.05f + i);
                }
            });
        }
        // 2) pelat gelap: helm/visor (baja), pauldron & housing lengan (grafit), badan drone (logam gelap)
        o.vc = buffers.getBuffer(RenderType.entityCutoutNoCull(PLATE));
        Helion3Geo.tint(o, STEEL, 1f);
        Helion3Geo.part(head, ps, o, 1f, AksaraGeo::helm);
        Helion3Geo.tint(o, DARK, 1f);
        Helion3Geo.part(rightArm, ps, o, 1f, AksaraGeo::armPlate);
        Helion3Geo.part(leftArm, ps, o, -1f, AksaraGeo::armPlate);
        if (rig) {
            Helion3Geo.tint(o, DRONE, 1f);
            float r = discRadius(look) - 0.3f;
            Helion3Geo.part(body, ps, o, 1f, out -> {
                for (int i = 0; i < 6; i++) {
                    float[] c = discCenter(i, look);
                    disc(out, c[0], c[1], c[2], r, 0.5f, look.age * 0.05f + i);
                }
            });
        }
        // 3) cahaya: pita optik merah, inti reaktor, mata tiap drone (warna subsistem)
        o.vc = buffers.getBuffer(RenderType.eyes(Draw.WHITE));
        o.light = FULLBRIGHT;
        o.overlay = OverlayTexture.NO_OVERLAY;
        float hot = Mth.clamp(0.6f + 0.4f * look.purna + 0.5f * look.flare, 0f, 1f);
        int coreGlow = look.purna > 0.3f ? WHITE_GLOW : RED_GLOW;
        Helion3Geo.tint(o, coreGlow, hot);
        Helion3Geo.part(head, ps, o, 1f, out -> {
            out.slab(0f, -4.5f, -4.46f, 2.85f, 0f, 0f, 0f, 0.3f, 0f, 0f, 0f, 0.05f);         // pita optik tunggal
            out.slab(0f, -7.55f, -4.46f, 0.35f, 0f, 0f, 0f, 0.18f, 0f, 0f, 0f, 0.04f);       // sensor dahi
        });
        Helion3Geo.part(body, ps, o, 1f, out -> {
            out.gem(0f, 6.0f, -2.5f, 1.05f, 1.15f, 0.4f);                                    // inti reaktor
            out.slab(0f, 6.0f, -2.5f, 0.12f, 0f, 0f, 0f, 1.5f, 0f, 0f, 0f, 0.05f);           // garis inti vertikal
            out.slab(0f, 6.0f, -2.5f, 1.5f, 0f, 0f, 0f, 0.12f, 0f, 0f, 0f, 0.05f);
        });
        if (rig) {
            float r = discRadius(look);
            float fade = 1f - look.discsOut * 2f;
            for (int i = 0; i < 6; i++) {
                final int k = i;
                float glow = Mth.clamp((0.4f + 0.6f * look.disc[i]) * fade, 0f, 1f);
                if (glow < 0.02f) {
                    continue;
                }
                Helion3Geo.tint(o, AksaraSkills.RGB[i], glow);
                Helion3Geo.part(body, ps, o, 1f, out -> {
                    float[] c = discCenter(k, look);
                    droneEye(out, c[0], c[1], c[2], r - 0.5f, 0.32f);
                });
            }
            if (look.purna > 0.05f) {   // Singularitas: tali daya merah-putih menghubungkan keenam drone
                Helion3Geo.tint(o, WHITE_GLOW, look.purna * 0.8f);
                Helion3Geo.part(body, ps, o, 1f, out -> {
                    for (int i = 0; i < 6; i++) {
                        float[] a = discCenter(i, look), b = discCenter((i + 1) % 6, look);
                        out.prism(a[0], a[1], a[2], b[0], b[1], b[2], 0.12f, 0.12f, 0f, 1f, false);
                    }
                });
            }
        }
    }

    /** Lengan orang pertama: pauldron edge, siku, gelang, pauldron & housing. */
    public static void renderArm(ModelPart arm, boolean left, PoseStack ps, MultiBufferSource buffers, int light) {
        Helion3Geo.Out o = new Helion3Geo.Out();
        o.light = light;
        o.overlay = OverlayTexture.NO_OVERLAY;
        float sx = left ? -1f : 1f;
        o.vc = buffers.getBuffer(RenderType.entityCutoutNoCull(GOLD));
        Helion3Geo.tint(o, 0xFFFFFF, 1f);
        Helion3Geo.part(arm, ps, o, sx, AksaraGeo::armTrim);
        o.vc = buffers.getBuffer(RenderType.entityCutoutNoCull(PLATE));
        Helion3Geo.tint(o, DARK, 1f);
        Helion3Geo.part(arm, ps, o, sx, AksaraGeo::armPlate);
    }
}
