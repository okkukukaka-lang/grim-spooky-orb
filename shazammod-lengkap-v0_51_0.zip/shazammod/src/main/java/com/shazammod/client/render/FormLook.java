package com.shazammod.client.render;

import com.shazammod.ShazamClientState;
import com.shazammod.ShazamForm;
import com.shazammod.ShazamMod;

import net.minecraft.resources.ResourceLocation;

/**
 * Warna & gambar kostum tiap juara. Bentuk jubah, mantel, hood, list, pelat bahu, dan bros sama; yang beda bahannya:
 *
 * Shazam     : kain putih, lapisan dalam biru tua, emas cerah, permata putih, lambang kilat bintang.
 * Black Adam : kain hitam legam (hood & jubah juara Kahndaq), lapisan dalam merah marun tua, emas antik yang lebih
 *              jingga, permata pirus seperti perhiasan firaun, lambang petir emas tajam.
 * Sabbac     : 0.30 kain hangus hitam kemerahan (seperti abu yang masih membara), lapisan dalam merah bara, besi hitam
 *              bertepi merah membara (pengganti emas), permata api, lambang segel enam iblis bertanduk. Tanpa hood
 *              (tanduknya nggak muat).
 */
public final class FormLook {
    /** Warna kain luar (dikali tekstur kain). */
    public final int cloth;
    /** Lapisan dalam jubah & hood. */
    public final int lining;
    /** Emas list & aksesoris: utama, tepi luar berkilau, tepi dalam berbayang, celah gelap. */
    public final int[] gold, goldEdge, goldShade, goldDark;
    /** Permata & paku keling (terang sendiri). */
    public final int[] gem;
    /** Butiran cahaya saat kain lenyap, dan kilau putihnya. */
    public final int dissolve, dissolveHot;
    /** Kilau aditif saat kain terbentuk/lenyap (RGB 0-255). */
    public final int[] weave;
    /** Kilau lambang: kilatan menyapu & pendar di sekitarnya (RGB 0-255). */
    public final int[] emblemSweep, emblemHalo;
    /** Percikan kecil dari lambang dada. */
    public final int sparkle;
    /** Kilau kostum saat terbentuk (SuitRevealLayer), RGB 0-255. */
    public final int[] suitShimmer;
    /** Lambang dada & lambang punggung jubah. */
    public final ResourceLocation emblem, backEmblem;
    /** 0 = Shazam, 1 = Black Adam, 2 = Sabbac (indeks cache gambar). */
    public final int index;

    private FormLook(int index, int cloth, int lining, int[] gold, int[] goldEdge, int[] goldShade, int[] goldDark, int[] gem,
                     int dissolve, int dissolveHot, int[] weave, int[] emblemSweep, int[] emblemHalo, int sparkle,
                     int[] suitShimmer, ResourceLocation emblem, ResourceLocation backEmblem) {
        this.index = index;
        this.cloth = cloth;
        this.lining = lining;
        this.gold = gold;
        this.goldEdge = goldEdge;
        this.goldShade = goldShade;
        this.goldDark = goldDark;
        this.gem = gem;
        this.dissolve = dissolve;
        this.dissolveHot = dissolveHot;
        this.weave = weave;
        this.emblemSweep = emblemSweep;
        this.emblemHalo = emblemHalo;
        this.sparkle = sparkle;
        this.suitShimmer = suitShimmer;
        this.emblem = emblem;
        this.backEmblem = backEmblem;
    }

    public static final FormLook SHAZAM = new FormLook(0,
            0xFFFFFF, 0x2E3458,
            new int[] {242, 194, 66}, new int[] {255, 228, 128}, new int[] {184, 134, 36}, new int[] {150, 105, 30},
            new int[] {255, 248, 222},
            0xFFD978, 0xFFF4D0,
            new int[] {255, 205, 110}, new int[] {255, 250, 225}, new int[] {255, 205, 90}, 0xFFF0C0,
            new int[] {255, 215, 90},
            ShazamMod.id("textures/entity/shazam_emblem.png"), ShazamMod.id("textures/entity/shazam_cape_emblem.png"));

    public static final FormLook BLACK_ADAM = new FormLook(1,
            0x2B272C, 0x3A1216,
            new int[] {222, 160, 44}, new int[] {255, 206, 104}, new int[] {150, 98, 24}, new int[] {92, 58, 14},
            new int[] {72, 226, 206},
            0xFFB347, 0xFFE2A8,
            new int[] {255, 168, 60}, new int[] {255, 236, 190}, new int[] {255, 160, 40}, 0xFFD27A,
            new int[] {255, 165, 50},
            ShazamMod.id("textures/entity/adam_emblem.png"), ShazamMod.id("textures/entity/adam_cape_emblem.png"));

    public static final FormLook SABBAC = new FormLook(2,
            0x3B2624, 0x7A1C10,
            new int[] {104, 70, 62}, new int[] {226, 98, 44}, new int[] {64, 40, 34}, new int[] {36, 20, 16},
            new int[] {255, 84, 34},
            0xFF5A1E, 0xFFC890,
            new int[] {255, 96, 40}, new int[] {255, 214, 170}, new int[] {255, 72, 24}, 0xFF8A4A,
            new int[] {255, 86, 30},
            ShazamMod.id("textures/entity/sabbac_emblem.png"), ShazamMod.id("textures/entity/sabbac_cape_emblem.png"));

    /**
     * 0.32 Lintang (orisinal): kain biru toska tua, lapisan dalam kuning keemasan (kontras dengan kainnya), list platina
     * yang dingin, permata matahari, lambang matahari delapan sinar.
     */
    // 0.42 Lintang tanpa kostum: jubah dari cahaya keemasan (ShazamCape.lightCape), lambang matahari yang menyala
    public static final FormLook LINTANG = new FormLook(3,
            0xFFC860, 0xFF8A30,
            new int[] {226, 232, 240}, new int[] {255, 255, 255}, new int[] {150, 160, 176}, new int[] {92, 100, 116},
            new int[] {255, 214, 120},
            0xFFE7A0, 0xFFFFF0,
            new int[] {255, 230, 160}, new int[] {255, 255, 240}, new int[] {255, 210, 110}, 0xFFF2C0,
            new int[] {255, 225, 140},
            ShazamMod.id("textures/entity/lintang_emblem.png"), ShazamMod.id("textures/entity/lintang_cape_emblem.png"));

    /**
     * 0.43 Helion-6 (orisinal): jubah kain hitam arang dengan lapisan dalam hijau tua, logam gunmetal bertepi hijau radiasi,
     * permata kristal Cryon, lambang reaktor heksagon.
     */
    public static final FormLook HELION = new FormLook(4,
            0x2A2E30, 0x0E3A22,
            new int[] {92, 100, 108}, new int[] {110, 255, 160}, new int[] {48, 54, 60}, new int[] {24, 28, 32},
            new int[] {90, 255, 150},
            0x5CFF8A, 0xD8FFE4,
            new int[] {90, 255, 150}, new int[] {210, 255, 225}, new int[] {60, 255, 120}, 0x8CFFB0,
            new int[] {90, 255, 150},
            ShazamMod.id("textures/entity/helion_emblem.png"), ShazamMod.id("textures/entity/helion_emblem.png"));

    /**
     * 0.50 Aksara (orisinal): jubah panjang nila-hitam bermotif parang prada (tekstur kain sendiri, lihat
     * tools/textures/aksara_textures.py), lapisan dalam ungu tua, logam prada emas, permata enam warna, lambang aksara.
     */
    public static final FormLook AKSARA = new FormLook(5,
            0x26233A, 0x3A2450,
            new int[] {232, 186, 82}, new int[] {255, 230, 150}, new int[] {160, 116, 40}, new int[] {96, 66, 22},
            new int[] {255, 242, 200},
            0xFFD27A, 0xFFF4D8,
            new int[] {255, 214, 120}, new int[] {255, 248, 225}, new int[] {255, 200, 96}, 0xFFE6A8,
            new int[] {255, 214, 120},
            ShazamMod.id("textures/entity/aksara_emblem.png"), ShazamMod.id("textures/entity/aksara_emblem.png"));

    /** Jumlah juara (ukuran cache gambar per juara). */
    public static final int COUNT = 6;

    public static FormLook of(ShazamForm form) {
        return switch (form) {
            case BLACK_ADAM -> BLACK_ADAM;
            case SABBAC -> SABBAC;
            case LINTANG -> LINTANG;
            case HELION -> HELION;
            case AKSARA -> AKSARA;   // 0.50
            default -> SHAZAM;
        };
    }

    /** Kostum pemain ini (dari status juara yang dikirim server). */
    public static FormLook of(int entityId) {
        return of(ShazamClientState.form(entityId));
    }
}
