package com.shazammod;

import java.util.List;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/**
 * Server -> client: data buat HUD. flags = status ya/tidak (lihat konstanta di bawah), energi, sisa cooldown (tick)
 * tiap skill juara yang dipilih (7), lalu sisa waktu pulih sesudah terlempar balik jadi manusia, lalu (Black Adam)
 * cooldown Panggil Petir Kahndaq; dan juara yang dipakai (ShazamForm).
 */
public record ShazamSyncPayload(int flags, float energy, List<Integer> cooldowns, int form) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<ShazamSyncPayload> TYPE =
            new CustomPacketPayload.Type<>(ShazamMod.id("sync"));

    public static final int UNLOCKED = 1;       // punya paling nggak satu juara
    public static final int TRANSFORMED = 2;
    public static final int STORM = 4;          // badai petir di atas Shazam
    public static final int SUN = 8;            // Berkah Aton: Black Adam di bawah matahari
    public static final int HAS_SHAZAM = 16;
    public static final int HAS_ADAM = 32;
    public static final int DARK = 64;          // 0.30: Sabbac di kegelapan neraka (malam, Nether, End)
    public static final int HAS_SABBAC = 128;   // 0.30

    public static final StreamCodec<ByteBuf, ShazamSyncPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, ShazamSyncPayload::flags,
            ByteBufCodecs.FLOAT, ShazamSyncPayload::energy,
            ByteBufCodecs.VAR_INT.apply(ByteBufCodecs.list()), ShazamSyncPayload::cooldowns,
            ByteBufCodecs.VAR_INT, ShazamSyncPayload::form,
            ShazamSyncPayload::new);

    public boolean has(int flag) {
        return (flags & flag) != 0;
    }

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
