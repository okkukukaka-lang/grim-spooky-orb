package com.shazammod.client;

import com.shazammod.PassiveConditions;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamPowers;
import com.shazammod.client.flight.MercuryMode;
import com.shazammod.client.fx.AdamFx;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

/**
 * HUD Shazam / Black Adam: Energi Petir, juara yang dipilih, dan skill di kiri atas; bar darah di atas hotbar saat
 * berubah wujud. Warna mengikuti juara (emas Shazam / emas membara Black Adam).
 */
public final class ShazamHud {
    private ShazamHud() {}

    private static final int X = 6;
    private static final int Y = 6;
    private static final int BAR_WIDTH = 130;
    private static final String LETTERS = "SHAZAM\u26A1";   // kotak terakhir: Zeus Rage
    private static final String ADAM_LETTERS = "SHAZAM\u2625"; // Black Adam: Shu Heru Amon Zehuti Aton Mehen + ankh (Murka Kahndaq)
    private static final int ADAM_GOLD = 0xFFFFB13D;           // emas membara
    private static final int ADAM_BAR = 0xFFE89A2C;
    private static final int ADAM_SHADE = 0xB0140A06;          // kotak gelap kecokelatan, seperti batu Kahndaq
    private static final int MEHEN_ON = 0xFF5FE6CF;            // lilitan Mehen aktif: pirus
    private static final int MEHEN_BG = 0xB0102A26;
    private static final int GOLD = 0xFFFFD34D;
    private static final int GRAY = 0xFF9E9E9E;
    private static final int STORM_BLUE = 0xFF55FFFF;
    private static final int SHADE = 0xA0000000;
    private static final int MERCURY_ON = 0xFF86F0FF;
    private static final int MERCURY_BG = 0xA0103848;
    private static final int MERCURY_RUN = 0xFFFFE28A;   // auto-hit dimatikan: cuma lari
    private static final int RECOVERING = 0xFFFF7A6B;    // habis terlempar balik jadi manusia: belum bisa SHAZAM
    private static final int SUN_GOLD = 0xFFFFC94A;      // Berkah Aton (Black Adam di bawah matahari)
    private static final int CHARGE_FILL = 0xB0B88A1E;   // Muatan Petir terisi
    private static final int CHARGE_FULL = 0xFFFFD34D;   // penuh: Pukulan Guntur siap
    private static final int CHARGE_FLASH = 0xFFFFF6C8;
    private static final int FAMILY_BG = 0xB0402A08;     // 0.26 Kekuatan Keluarga siap
    private static final String CALL_LETTER = "\u03DF";  // Panggil Petir Kahndaq (tombol M Black Adam): petir
    private static final String HAND_LETTER = "\u270B";  // 0.27 Tangan Kahndaq (tombol J Black Adam): telapak terbuka
    private static final String BLOCK_LETTER = "\u26E8"; // 0.28 Tangkisan Kahndaq (Black Adam): perisai
    // ======= 0.30 Sabbac: enam iblis S-A-B-B-A-C, warna api neraka =======
    private static final String SABBAC_LETTERS = "SABBAC\u2620"; // Setan Aym Belial Beelzebub Asmodeus Crateis + Gerbang Neraka
    private static final int SABBAC_RED = 0xFFFF6A3A;          // huruf & judul: merah bara
    private static final int SABBAC_BAR = 0xFFD8341A;
    private static final int SABBAC_SHADE = 0xB0220806;        // kotak gelap kemerahan, seperti batu neraka
    private static final int SABBAC_READY = 0xC0380A04;
    private static final String HELL_CALL_LETTER = "\u03DF";  // Panggil Petir Neraka (M)
    private static final String LEGION_LETTER = "\u2694";     // Pasukan Iblis (J)
    private static final String HELL_CHARGE_LETTER = "\u2739"; // Muatan Neraka (penuh = Tinju Neraka)
    private static final String ENGULF_LETTER = "\u2668";     // Kulit Bara

    public static void render(GuiGraphics graphics, DeltaTracker deltaTracker) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.player == null || !ShazamClientState.unlocked) {
            return;
        }
        if (ShazamClientState.transformed) {
            renderHealth(graphics, mc, mc.player);
        }
        renderEnergy(graphics, mc);
    }

    /** Pengganti baris hati: 100 darah nggak muat dalam hati biasa. */
    private static void renderHealth(GuiGraphics graphics, Minecraft mc, LocalPlayer player) {
        if (mc.gameMode == null || !mc.gameMode.canHurtPlayer()) {
            return;
        }
        int x = graphics.guiWidth() / 2 - 91;
        int y = graphics.guiHeight() - 39;
        int width = 81;
        int height = 9;
        float health = player.getHealth();
        float max = Math.max(1f, player.getMaxHealth());
        float absorption = player.getAbsorptionAmount();
        graphics.fill(x - 1, y - 1, x + width + 1, y + height + 1, 0xFF6B4E12);
        graphics.fill(x, y, x + width, y + height, 0xFF1A0E0E);
        int filled = Math.round(Mth.clamp(health / max, 0f, 1f) * width);
        graphics.fill(x, y, x + filled, y + height, 0xFFC62828);
        graphics.fill(x, y, x + filled, y + 3, 0xFFE57373);
        if (absorption > 0f) {
            // 0.25: Perisai Petir (hati emas dari Penangkal Petir Hidup) diukur terhadap perisai penuh (20), bukan darah 300,
            // jadi kelihatan jelas habis kena serangan lalu terisi lagi tiap petir menyambar (baris armor vanila di atasnya
            // nggak ketutup)
            int extra = Math.round(Mth.clamp(absorption / Math.max(20f, absorption), 0f, 1f) * width);
            graphics.fill(x, y + height - 3, x + extra, y + height, GOLD);
        }
        String text = "\u2764 " + Math.round(health) + " / " + Math.round(max)
                + (absorption > 0f ? " +" + Math.round(absorption) : "");
        graphics.pose().pushPose();
        graphics.pose().translate(x + width / 2f, y + 2f, 0f);
        graphics.pose().scale(0.7f, 0.7f, 1f);
        graphics.drawCenteredString(mc.font, text, 0, 0, 0xFFFFFFFF);
        graphics.pose().popPose();
    }

    private static void renderEnergy(GuiGraphics graphics, Minecraft mc) {
        boolean transformed = ShazamClientState.transformed;
        float energy = ShazamClientState.energy;
        int recovery = transformed ? 0 : ShazamClientState.recovery();
        if (!transformed && energy >= ShazamPowers.MAX_ENERGY && recovery <= 0) {
            return; // wujud manusia, energi penuh, dan nggak sedang pulih: disembunyikan
        }
        Font font = mc.font;
        if (ShazamClientState.isSabbac()) {
            renderSabbac(graphics, mc, font, transformed, energy, recovery);
            return;
        }
        boolean adam = ShazamClientState.isAdam();
        int color = transformed ? (adam ? ADAM_GOLD : GOLD) : GRAY;

        Component title = Component.literal("\u26A1 ")
                .append(Component.translatable("hud.shazammod.energy"))
                .append(" " + Math.round(energy) + "/" + Math.round(ShazamPowers.MAX_ENERGY));
        graphics.drawString(font, title, X, Y, color, true);
        // juara yang dipilih, kecil di samping judul
        Component champion = Component.translatable(adam ? "champion.shazammod.black_adam" : "champion.shazammod.shazam");
        int titleWidth = font.width(title);
        graphics.pose().pushPose();
        graphics.pose().translate(X + titleWidth + 6, Y + 1.5f, 0);
        graphics.pose().scale(0.75f, 0.75f, 1f);
        graphics.drawString(font, champion, 0, 0, adam ? 0xFFE0A050 : 0xFFE8D8A0, true);
        graphics.pose().popPose();

        int barY = Y + 12;
        graphics.fill(X - 1, barY - 1, X + BAR_WIDTH + 1, barY + 5, adam ? ADAM_SHADE : SHADE);
        int filled = Math.round(energy / ShazamPowers.MAX_ENERGY * BAR_WIDTH);
        graphics.fill(X, barY, X + filled, barY + 4, transformed && adam ? ADAM_BAR : color);
        if (adam ? ShazamClientState.sun : ShazamClientState.storm) {   // Shazam: badai petir. Black Adam: matahari Kahndaq.
            graphics.drawString(font, Component.translatable(adam ? "hud.shazammod.sun" : "hud.shazammod.storm"),
                    X + BAR_WIDTH + 6, barY - 2, adam ? SUN_GOLD : STORM_BLUE, true);
        }
        if (!transformed) {
            if (recovery > 0) {   // habis kena serangan mematikan: sisa waktu sampai bisa SHAZAM lagi
                graphics.drawString(font, Component.translatable("hud.shazammod.recovering", (recovery + 19) / 20),
                        X, barY + 9, RECOVERING, true);
            }
            return;
        }

        // Kotak skill S-H-A-Z-A-M dan amarah: huruf dewa di atas, tombol (atau sisa detik cooldown) di bawah.
        // Black Adam: huruf yang sama, dewa yang beda (Shu, Heru, Amon, Zehuti, Aton, Mehen) + ankh untuk Murka Kahndaq.
        int boxY = barY + 9;
        boolean mercury = !adam && mc.player != null && ShazamClientState.isMercury(mc.player.getId());
        boolean mehen = adam && mc.player != null && AdamFx.mehenStrength(mc.player, 0f) > 0.05f;
        String letters = adam ? ADAM_LETTERS : LETTERS;
        int letterGold = adam ? ADAM_GOLD : GOLD;
        for (int i = 0; i < ShazamClient.SKILL_KEYS.length; i++) {
            int boxX = X + i * 22;
            int cooldown = ShazamClientState.cooldown(i);
            boolean ready = cooldown <= 0;
            boolean on = i == 5 && mercury;   // M: Mode Kilat menyala
            boolean coiled = i == 5 && mehen; // M: ular Mehen sedang melilit
            graphics.fill(boxX - 1, boxY - 1, boxX + 20, boxY + 21, on ? MERCURY_BG : coiled ? MEHEN_BG : adam ? ADAM_SHADE : SHADE);
            graphics.drawCenteredString(font, String.valueOf(letters.charAt(i)), boxX + 10, boxY + 2,
                    on ? MERCURY_ON : coiled ? MEHEN_ON : (ready ? letterGold : GRAY));
            String sub;
            int subColor = ready ? 0xFFFFFFFF : GRAY;
            if (on) {
                boolean auto = MercuryMode.isAuto();
                sub = Component.translatable(auto ? "hud.shazammod.mercury_auto" : "hud.shazammod.mercury_run").getString();
                subColor = auto ? 0xFFFFFFFF : MERCURY_RUN;
            } else if (ready) {
                sub = ShazamClient.SKILL_KEYS[i].getTranslatedKeyMessage().getString();
                if (sub.length() > 4) {
                    sub = sub.substring(0, 4);
                }
            } else {
                sub = (cooldown + 19) / 20 + "s";
            }
            graphics.pose().pushPose();
            graphics.pose().translate(boxX + 10, boxY + 13, 0);
            graphics.pose().scale(0.7f, 0.7f, 1f);
            graphics.drawCenteredString(font, sub, 0, 0, subColor);
            graphics.pose().popPose();
        }
        if (!adam) {   // Shazam: kotak Muatan Petir & Refleks Mercury, sedikit terpisah
            renderPassives(graphics, font, X + ShazamClient.SKILL_KEYS.length * 22 + 4, boxY);
        }
        if (adam) {   // kotak ke-8: Panggil Petir Kahndaq (tombol M), sedikit terpisah
            int boxX = X + ShazamClient.SKILL_KEYS.length * 22 + 4;
            int cooldown = ShazamClientState.callCooldown();
            boolean ready = cooldown <= 0;
            graphics.fill(boxX - 1, boxY - 1, boxX + 20, boxY + 21, ready ? 0xC0301206 : ADAM_SHADE);
            graphics.fill(boxX - 1, boxY - 1, boxX + 20, boxY, ready ? ADAM_BAR : 0xFF5A3A1A);
            graphics.drawCenteredString(font, CALL_LETTER, boxX + 10, boxY + 2, ready ? ADAM_GOLD : GRAY);
            String sub = ready ? ShazamClient.MERCURY_AUTO.getTranslatedKeyMessage().getString() : (cooldown + 19) / 20 + "s";
            if (sub.length() > 4) {
                sub = sub.substring(0, 4);
            }
            graphics.pose().pushPose();
            graphics.pose().translate(boxX + 10, boxY + 13, 0);
            graphics.pose().scale(0.7f, 0.7f, 1f);
            graphics.drawCenteredString(font, sub, 0, 0, ready ? 0xFFFFFFFF : GRAY);
            graphics.pose().popPose();
            // 0.27 kotak ke-9: Tangan Kahndaq (tombol J) - jumlah proyektil yang sedang melayang tertahan
            int handX = boxX + 22;
            int held = ShazamClientState.heldCount();
            boolean any = held > 0;
            graphics.fill(handX - 1, boxY - 1, handX + 20, boxY + 21, any ? 0xC0301206 : ADAM_SHADE);
            if (any) {
                graphics.fill(handX - 1, boxY - 1, handX + 20, boxY, ADAM_BAR);
            }
            graphics.drawCenteredString(font, HAND_LETTER, handX + 10, boxY + 2, any ? ADAM_GOLD : GRAY);
            String handSub = any ? "x" + held : ShazamClient.FAMILY.getTranslatedKeyMessage().getString();
            if (handSub.length() > 4) {
                handSub = handSub.substring(0, 4);
            }
            small(graphics, font, handSub, handX + 10, boxY + 13, any ? 0xFFFFFFFF : GRAY);
            // 0.28 kotak ke-10 & ke-11: Muatan Petir (Tinju Kahndaq) & Tangkisan Kahndaq, padanan pasif Shazam
            renderAdamPassives(graphics, font, handX + 22, boxY);
        }
    }

    /** 0.30 HUD Sabbac: energi, enam iblis + Gerbang Neraka, Petir Neraka (M), Pasukan Iblis (J), dan dua pasif. */
    private static void renderSabbac(GuiGraphics graphics, Minecraft mc, Font font, boolean transformed, float energy,
                                     int recovery) {
        int color = transformed ? SABBAC_RED : GRAY;
        Component title = Component.literal("\u2668 ")
                .append(Component.translatable("hud.shazammod.energy_sabbac"))
                .append(" " + Math.round(energy) + "/" + Math.round(ShazamPowers.MAX_ENERGY));
        graphics.drawString(font, title, X, Y, color, true);
        int titleWidth = font.width(title);
        graphics.pose().pushPose();
        graphics.pose().translate(X + titleWidth + 6, Y + 1.5f, 0);
        graphics.pose().scale(0.75f, 0.75f, 1f);
        graphics.drawString(font, Component.translatable("champion.shazammod.sabbac"), 0, 0, 0xFFE0705A, true);
        graphics.pose().popPose();

        int barY = Y + 12;
        graphics.fill(X - 1, barY - 1, X + BAR_WIDTH + 1, barY + 5, SABBAC_SHADE);
        int filled = Math.round(energy / ShazamPowers.MAX_ENERGY * BAR_WIDTH);
        graphics.fill(X, barY, X + filled, barY + 4, transformed ? SABBAC_BAR : color);
        if (ShazamClientState.dark) {   // kegelapan neraka: Muatan Neraka 2x, energi terisi
            graphics.drawString(font, Component.translatable("hud.shazammod.dark"), X + BAR_WIDTH + 6, barY - 2, SABBAC_RED, true);
        }
        if (!transformed) {
            if (recovery > 0) {
                graphics.drawString(font, Component.translatable("hud.shazammod.recovering_sabbac", (recovery + 19) / 20),
                        X, barY + 9, RECOVERING, true);
            }
            return;
        }
        int boxY = barY + 9;
        for (int i = 0; i < ShazamClient.SKILL_KEYS.length; i++) {
            int boxX = X + i * 22;
            int cooldown = ShazamClientState.cooldown(i);
            boolean ready = cooldown <= 0;
            graphics.fill(boxX - 1, boxY - 1, boxX + 20, boxY + 21, ready ? SABBAC_READY : SABBAC_SHADE);
            graphics.drawCenteredString(font, String.valueOf(SABBAC_LETTERS.charAt(i)), boxX + 10, boxY + 2,
                    ready ? SABBAC_RED : GRAY);
            String sub;
            if (ready) {
                sub = ShazamClient.SKILL_KEYS[i].getTranslatedKeyMessage().getString();
                if (sub.length() > 4) {
                    sub = sub.substring(0, 4);
                }
            } else {
                sub = (cooldown + 19) / 20 + "s";
            }
            small(graphics, font, sub, boxX + 10, boxY + 13, ready ? 0xFFFFFFFF : GRAY);
        }
        // kotak ke-8: Panggil Petir Neraka (tombol M)
        int callX = X + ShazamClient.SKILL_KEYS.length * 22 + 4;
        int call = ShazamClientState.callCooldown();
        boolean callReady = call <= 0;
        graphics.fill(callX - 1, boxY - 1, callX + 20, boxY + 21, callReady ? SABBAC_READY : SABBAC_SHADE);
        graphics.fill(callX - 1, boxY - 1, callX + 20, boxY, callReady ? SABBAC_BAR : 0xFF4A1A12);
        graphics.drawCenteredString(font, HELL_CALL_LETTER, callX + 10, boxY + 2, callReady ? SABBAC_RED : GRAY);
        small(graphics, font, callReady ? key(ShazamClient.MERCURY_AUTO) : (call + 19) / 20 + "s", callX + 10, boxY + 13,
                callReady ? 0xFFFFFFFF : GRAY);
        // kotak ke-9: Pasukan Iblis (tombol J) - jumlah prajurit yang masih bertarung, atau sisa cooldown
        int legionX = callX + 22;
        int alive = ShazamClientState.legionCount();
        int legion = ShazamClientState.legionCooldown();
        boolean legionReady = legion <= 0;
        boolean fighting = alive > 0;
        graphics.fill(legionX - 1, boxY - 1, legionX + 20, boxY + 21, fighting || legionReady ? SABBAC_READY : SABBAC_SHADE);
        if (fighting || legionReady) {
            graphics.fill(legionX - 1, boxY - 1, legionX + 20, boxY, SABBAC_BAR);
        }
        graphics.drawCenteredString(font, LEGION_LETTER, legionX + 10, boxY + 2, fighting || legionReady ? SABBAC_RED : GRAY);
        String legionSub = fighting ? "x" + alive : legionReady ? key(ShazamClient.FAMILY) : (legion + 19) / 20 + "s";
        small(graphics, font, legionSub, legionX + 10, boxY + 13, fighting || legionReady ? 0xFFFFFFFF : GRAY);
        // kotak ke-10 & ke-11: Muatan Neraka (penuh = Tinju Neraka) & Kulit Bara, padanan pasif Shazam / Black Adam
        int x = legionX + 22;
        int charge = Mth.clamp(ShazamClientState.charge(), 0, 100);
        boolean full = charge >= 100;
        boolean blink = full && mc.level != null && (mc.level.getGameTime() / 4L) % 2L == 0L;
        // abu-abu = Api Neraka padam (di bawah matahari / di dalam air)
        boolean off = mc.level != null && mc.player != null && PassiveConditions.hellfireBlock(mc.level,
                mc.player.blockPosition(), mc.player.isUnderWater()) != PassiveConditions.Hellfire.NONE;
        graphics.fill(x - 1, boxY - 1, x + 20, boxY + 21, full && !off ? SABBAC_READY : SABBAC_SHADE);
        int height = Math.round(charge / 100f * 20f);
        graphics.fill(x, boxY + 20 - height, x + 19, boxY + 20,
                off ? 0x80505050 : full ? (blink ? 0xFFFFC890 : SABBAC_RED) : 0xB0902010);
        graphics.drawCenteredString(font, HELL_CHARGE_LETTER, x + 10, boxY + 2, off ? GRAY : full ? 0xFFFFFFFF : SABBAC_RED);
        small(graphics, font, full ? Component.translatable("hud.shazammod.charge_ready").getString() : charge + "%",
                x + 10, boxY + 13, 0xFFFFFFFF);
        int ex = x + 22;
        int engulf = ShazamClientState.dodgeCooldown();   // Kulit Bara memakai jeda yang sama dengan Refleks Mercury
        boolean engulfReady = engulf <= 0;
        graphics.fill(ex - 1, boxY - 1, ex + 20, boxY + 21, engulfReady ? SABBAC_READY : SABBAC_SHADE);
        if (engulfReady) {
            graphics.fill(ex - 1, boxY - 1, ex + 20, boxY, SABBAC_BAR);
        }
        graphics.drawCenteredString(font, ENGULF_LETTER, ex + 10, boxY + 2, engulfReady ? SABBAC_RED : GRAY);
        small(graphics, font, engulfReady ? Component.translatable("hud.shazammod.dodge_ready").getString()
                        : String.format(java.util.Locale.ROOT, "%.1fs", engulf / 20f),
                ex + 10, boxY + 13, engulfReady ? 0xFFFFFFFF : GRAY);
    }

    /** Nama tombol, paling panjang 4 huruf. */
    private static String key(net.minecraft.client.KeyMapping mapping) {
        String name = mapping.getTranslatedKeyMessage().getString();
        return name.length() > 4 ? name.substring(0, 4) : name;
    }

    /** 0.28 Black Adam: Muatan Surya (penuh = Tinju Aton) dan Tangkisan Kahndaq (jeda 1,8 detik), warna Kahndaq. */
    private static void renderAdamPassives(GuiGraphics graphics, Font font, int x, int y) {
        Minecraft mc = Minecraft.getInstance();
        int charge = Mth.clamp(ShazamClientState.charge(), 0, 100);
        boolean full = charge >= 100;
        boolean blink = full && mc.level != null && (mc.level.getGameTime() / 4L) % 2L == 0L;
        boolean night = mc.level != null && !PassiveConditions.sunUp(mc.level);   // 0.29: abu-abu = Cakram Aton padam
        graphics.fill(x - 1, y - 1, x + 20, y + 21, full && !night ? 0xC0301206 : ADAM_SHADE);
        int height = Math.round(charge / 100f * 20f);
        graphics.fill(x, y + 20 - height, x + 19, y + 20, night ? 0x80505050 : full ? (blink ? 0xFFFFE2A8 : ADAM_GOLD) : 0xB0A0561A);
        graphics.drawCenteredString(font, "\u2600", x + 10, y + 2, night ? GRAY : full ? 0xFFFFFFFF : ADAM_GOLD);   // Muatan Surya
        small(graphics, font, full ? Component.translatable("hud.shazammod.charge_ready").getString() : charge + "%",
                x + 10, y + 13, 0xFFFFFFFF);
        int bx = x + 22;
        int block = ShazamClientState.dodgeCooldown();   // Tangkisan Kahndaq memakai jeda yang sama dengan Refleks Mercury
        boolean ready = block <= 0;
        graphics.fill(bx - 1, y - 1, bx + 20, y + 21, ready ? 0xC0301206 : ADAM_SHADE);
        if (ready) {
            graphics.fill(bx - 1, y - 1, bx + 20, y, ADAM_BAR);
        }
        graphics.drawCenteredString(font, BLOCK_LETTER, bx + 10, y + 2, ready ? ADAM_GOLD : GRAY);
        small(graphics, font, ready ? Component.translatable("hud.shazammod.dodge_ready").getString()
                        : String.format(java.util.Locale.ROOT, "%.1fs", block / 20f),
                bx + 10, y + 13, ready ? 0xFFFFFFFF : GRAY);
    }

    /** Shazam 0.23: kotak Muatan Petir (terisi dari bawah; penuh = Pukulan Guntur siap) dan Refleks Mercury. */
    private static void renderPassives(GuiGraphics graphics, Font font, int x, int y) {
        Minecraft mc = Minecraft.getInstance();
        int charge = Mth.clamp(ShazamClientState.charge(), 0, 100);
        boolean full = charge >= 100;
        boolean blink = full && mc.level != null && (mc.level.getGameTime() / 4L) % 2L == 0L;
        // 0.29: abu-abu = petir tiap 2 detik sedang padam (gurun / es & salju / Nether)
        boolean off = mc.level != null && mc.player != null
                && PassiveConditions.lightningBlock(mc.level, mc.player.blockPosition()) != PassiveConditions.Block.NONE;
        graphics.fill(x - 1, y - 1, x + 20, y + 21, full && !off ? 0xC0302408 : SHADE);
        int height = Math.round(charge / 100f * 20f);
        graphics.fill(x, y + 20 - height, x + 19, y + 20, off ? 0x80505050 : full ? (blink ? CHARGE_FLASH : CHARGE_FULL) : CHARGE_FILL);
        graphics.drawCenteredString(font, "\u26A1", x + 10, y + 2, off ? GRAY : full ? 0xFFFFFFFF : GOLD);
        small(graphics, font, full ? Component.translatable("hud.shazammod.charge_ready").getString() : charge + "%",
                x + 10, y + 13, 0xFFFFFFFF);
        // Refleks Mercury: biru = siap mengelak
        int dx = x + 22;
        int dodge = ShazamClientState.dodgeCooldown();
        boolean ready = dodge <= 0;
        graphics.fill(dx - 1, y - 1, dx + 20, y + 21, ready ? MERCURY_BG : SHADE);
        graphics.drawCenteredString(font, "\u00BB", dx + 10, y + 2, ready ? MERCURY_ON : GRAY);
        // jedanya cuma 1,8 detik (0.25): tampilkan satu angka di belakang koma
        small(graphics, font, ready ? Component.translatable("hud.shazammod.dodge_ready").getString()
                        : String.format(java.util.Locale.ROOT, "%.1fs", dodge / 20f),
                dx + 10, y + 13, ready ? 0xFFFFFFFF : GRAY);
        // 0.26 Kekuatan Keluarga (tombol J): emas = siap, abu-abu = sisa cooldown
        int fx = dx + 22;
        int family = ShazamClientState.familyCooldown();
        boolean famReady = family <= 0;
        graphics.fill(fx - 1, y - 1, fx + 20, y + 21, famReady ? FAMILY_BG : SHADE);
        graphics.drawCenteredString(font, "\u2665", fx + 10, y + 2, famReady ? GOLD : GRAY);
        String famSub = famReady ? ShazamClient.FAMILY.getTranslatedKeyMessage().getString() : (family + 19) / 20 + "s";
        if (famSub.length() > 4) {
            famSub = famSub.substring(0, 4);
        }
        small(graphics, font, famSub, fx + 10, y + 13, famReady ? 0xFFFFFFFF : GRAY);
    }

    private static void small(GuiGraphics graphics, Font font, String text, int x, int y, int color) {
        graphics.pose().pushPose();
        graphics.pose().translate(x, y, 0);
        graphics.pose().scale(0.7f, 0.7f, 1f);
        graphics.drawCenteredString(font, text, 0, 0, color);
        graphics.pose().popPose();
    }
}
