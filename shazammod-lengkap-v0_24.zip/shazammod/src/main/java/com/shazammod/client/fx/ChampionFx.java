package com.shazammod.client.fx;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Runes;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Efek Shazam 0.23, "juara para dewa". Melengkapi ShazamFx (efek lama tetap jalan) dengan avatar dewa (GodAvatars) dan
 * efek buatan sendiri yang tebal:
 *
 * S Kebijaksanaan Solomon : avatar Solomon membuka kitab; segel bintang segi enam raksasa terproyeksi ke depan.
 * H Tepukan Guntur        : avatar Hercules melompat lalu menghantamkan gada tepat saat tepukan; petir menjalar di
 *                           sepanjang kerucut dan cincin guntur. Lemparan Hercules: musuh yang dilempar meninggalkan
 *                           jejak cahaya dan meledak (kubah, retakan, petir di tanah) saat menghantam.
 * A Beban Langit Atlas    : avatar Atlas mengangkat bola langit, debu tersedot ke pusat, lalu bola langit berbintang
 *                           (cincin emas & rasi bintang) jatuh dan pecah jadi bintang-bintang, cincin langit, dan pilar cahaya.
 * Z Petir Berantai Zeus   : avatar Zeus membidikkan petirnya; petir tebal dari ujung jari melompat dari musuh ke musuh.
 * A Perisai Achilles      : avatar Achilles menusukkan tombak; perisai matahari emas di depan dada; di akhir Ledakan
 *                           Keberanian: kubah emas, gelombang berlapis, pecahan perisai.
 * R Badai Para Dewa       : awan badai berputar di atas kepala (petir ke tanah di sekeliling), keenam dewa melingkar dan
 *                           tiap seranganya punya bentuk sendiri (segel, gada, bola langit kecil, petir, tombak, kilat).
 * Pasif                   : kepalan berlistrik saat Muatan Petir penuh, Pukulan Guntur, kedipan Refleks Mercury, tautan
 *                           cahaya Hati Pahlawan, dan petir alam yang diserap badan.
 */
public final class ChampionFx {
    private ChampionFx() {}

    // ======= Warna (RGB) =======
    static final int SKY_DEEP = 0x1B2A66;     // isi bola langit Atlas: malam berbintang
    static final int SKY_RIM = 0x9CC8FF;
    static final int SKY_GOLD = 0xFFD978;     // cincin bola langit
    static final int STAR = 0xF4F8FF;
    static final int CHARGE = 0xFFF2B0;       // Muatan Petir: emas keputihan
    static final int HERO = 0xFFE07A;
    static final int AEGIS = 0xFFD45E;        // perisai matahari Achilles
    static final int CLOUD = 0x262B38;
    static final int CLOUD_LIT = 0x5A6178;
    private static final Vec3 UP = new Vec3(0, 1, 0);

    private static final Map<Integer, Vec3> CHAIN = new HashMap<>();          // titik terakhir Petir Berantai tiap pemain
    private static final Map<Integer, StormCloud> CLOUDS = new HashMap<>();   // awan Badai Para Dewa

    public static void clear() {
        CHAIN.clear();
        CLOUDS.clear();
    }

    public static void tick(ClientLevel level) {
        chargedFists(level);
        CLOUDS.values().removeIf(c -> c.done);
    }

    public static void onAnim(AbstractClientPlayer caster, ShazamAnim anim, Vec3 pos, boolean self) {
        switch (anim) {
            case SOLOMON_SIGHT -> solomon(caster, self);
            case HERCULES_CLAP -> hercules(caster, self);
            case HERCULES_THROW -> herculesThrow(caster, pos, self);
            case HERCULES_IMPACT -> herculesImpact(caster, pos, self);
            case ATLAS_GROUND -> atlasRaise(caster, self);
            case ATLAS_GLOBE -> atlasGlobe(pos);
            case ATLAS_IMPACT -> atlasImpact(caster, self);
            case ZEUS_CALL -> zeus(caster, pos);
            case ZEUS_CHAIN_START -> zeusChain(caster, pos, true, self);
            case ZEUS_CHAIN -> zeusChain(caster, pos, false, self);
            case ACHILLES_ROAR -> achilles(caster);
            case ACHILLES_NOVA -> courageNova(caster, self);
            case ZEUS_RAGE -> rage(caster, self);
            case THUNDER_PUNCH -> thunderPunch(caster, pos, self);
            case MERCURY_DODGE -> dodge(caster, pos, self);
            case HERO_CALL -> heroCall(caster, pos, self);
            case STORM_ABSORB -> stormAbsorb(caster, self);
            case GOD_SOLOMON, GOD_HERCULES, GOD_ATLAS, GOD_ZEUS, GOD_ACHILLES, GOD_MERCURY ->
                    godStrike(caster, anim.godIndex(), pos);
            case REVERT, KNOCKOUT -> {
                GodAvatars.dismiss(caster);
                CHAIN.remove(caster.getId());
                StormCloud cloud = CLOUDS.remove(caster.getId());
                if (cloud != null) {
                    cloud.end();
                }
            }
            default -> { }
        }
    }

    // ------------------------------------------------------------------ alat bantu

    private static void schedule(int delay, int duration, ShazamFx.Step step) {
        ShazamFx.schedule(delay, duration, step);
    }

    private static void sound(ClientLevel level, Vec3 at, SoundEvent sound, float volume, float pitch) {
        level.playLocalSound(at.x, at.y, at.z, sound, SoundSource.PLAYERS, volume, ShazamFx.slowPitch(level, pitch), false);
    }

    private static boolean firstPerson(AbstractClientPlayer player) {
        Minecraft mc = Minecraft.getInstance();
        return player == mc.player && mc.options.getCameraType().isFirstPerson();
    }

    private static Vec3 flatLook(AbstractClientPlayer player) {
        Vec3 look = player.getViewVector(1f);
        Vec3 flat = new Vec3(look.x, 0, look.z);
        if (flat.lengthSqr() < 1.0E-4) {
            double yaw = Math.toRadians(player.getYRot());
            flat = new Vec3(-Math.sin(yaw), 0, Math.cos(yaw));
        }
        return flat.normalize();
    }

    /** Makhluk (bukan pemain) terdekat dari titik ini, atau null. */
    private static LivingEntity nearestMob(ClientLevel level, Vec3 pos, double radius) {
        LivingEntity best = null;
        double bestDistance = radius * radius;
        for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, new AABB(pos, pos).inflate(radius),
                m -> m.isAlive() && !(m instanceof AbstractClientPlayer))) {
            double d = entity.position().distanceToSqr(pos);
            if (d < bestDistance) {
                bestDistance = d;
                best = entity;
            }
        }
        return best;
    }

    /** Busur petir dari titik ke luar ke segala arah. */
    private static void arcsOut(ClientLevel level, Vec3 from, int count, double reach, int rgb, float width, int life) {
        for (int k = 0; k < count; k++) {
            Vec3 d = ShazamFx.randomDir(level.random);
            d = new Vec3(d.x, Math.abs(d.y) * 0.7 - 0.1, d.z).normalize();
            Vec3 end = from.add(d.scale(reach * (0.6 + level.random.nextDouble() * 0.5)));
            Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(from), Lightning.Anchor.fixed(end), rgb, width,
                    life + level.random.nextInt(3), 1, 2, 0.3));
        }
    }

    /** Muatan Petir penuh: busur listrik kecil menari di kedua kepalan, kilau sesekali. */
    private static void chargedFists(ClientLevel level) {
        for (AbstractClientPlayer p : level.players()) {
            if (!ShazamClientState.isCharged(p.getId()) || !ShazamClientState.isTransformed(p.getId())
                    || ShazamClientState.isAdam(p.getId()) || p.isInvisible() || firstPerson(p)) {
                continue;
            }
            if (p.tickCount % 2 == 0) {
                for (boolean right : new boolean[] {true, false}) {
                    Lightning.Anchor hand = pt -> ShazamPoses.handPos(p, right, pt);
                    Vec3 off = ShazamFx.randomDir(level.random).scale(0.3 + level.random.nextDouble() * 0.25);
                    Vfx.add(new Lightning.Arc(hand, pt -> hand.at(pt).add(off), CHARGE, 0.035f, 2, 1, 0, 0.35));
                }
            }
            if (p.tickCount % 5 == 0) {
                Vec3 h = ShazamPoses.handPos(p, level.random.nextBoolean(), 1f);
                Vfx.glint(h.x, h.y, h.z, CHARGE, 0.22f, 6);
            }
        }
    }

    // ------------------------------------------------------------------ S - Kebijaksanaan Solomon

    private static void solomon(AbstractClientPlayer caster, boolean self) {
        GodAvatars.Avatar a = GodAvatars.summon(caster, GodFigures.SOLOMON, 34);
        a.side = 1.6;
        a.back = 1.7;
        a.tau0 = 6f;            // kitab terbuka & tangan memberkati (lihat GodFigures)
        a.tauRate = 1.1f;
        a.tauMax = 40f;
        // sinema: cahaya terhisap ke mata (dua jari di pelipis) & kitab avatar menyala, lalu tepat saat membaca: suar ungu
        // melintang di mata dan berkas cahaya dari langit
        Lightning.Anchor eyes = pt -> caster.getEyePosition(pt).add(caster.getViewVector(pt).scale(0.3));
        CineFx.gather(caster, 0, ShazamAnim.CAST_WINDUP, eyes, ShazamFx.SOLOMON, 1.5, 4f, false);
        CineFx.gather(caster, 0, ShazamAnim.CAST_WINDUP + 3, pt -> GodAvatars.weapon(caster, GodFigures.SOLOMON), 0xFFF0C8,
                0.7, 2f, false);
        schedule(ShazamAnim.CAST_WINDUP, 1, (level, t) -> {
            CineFx.flareAt(eyes, 0xE2D2FF, 3.4f, 0.07f, 1f, 14);
            CineFx.godRays(Lightning.Anchor.on(caster, 0, 0, 0), 0xCDB8FF, 16.0, 1.6, 7, 0.8f, 34);
            if (self) {
                FovKick.punch(-0.04f);
            }
        });
        schedule(ShazamAnim.CAST_WINDUP, 1, (level, t) -> {
            Vec3 look = flatLook(caster);
            Vec3 c = caster.getEyePosition().add(look.scale(2.4));
            Vfx.add(new Runes.Circle(Lightning.Anchor.fixed(c), look, 1.7, ShazamFx.SOLOMON, 28, 0.09f, 1f, null));
            Vfx.add(new Runes.Circle(Lightning.Anchor.fixed(c), look, 0.9, ShazamFx.GOLD_LIGHT, 24, -0.14f, 0.8f, null));
            Vfx.add(new Fx.Ripple(c, look, 12.0, 1.2, 6.0, 0.35, ShazamFx.SOLOMON, 18, 0.7f, false));
            Vfx.add(new Fx.Flash(c, 2.0f, 0xE6D8FF, 9, 0.9f));
            sound(level, c, SoundEvents.AMETHYST_BLOCK_CHIME, 1.4f, 0.5f);
            if (self) {
                ScreenFlash.flash(0.15f, 0xE6D8FF);
            }
        });
    }

    // ------------------------------------------------------------------ H - Tepukan Guntur & Lemparan Hercules

    private static void hercules(AbstractClientPlayer caster, boolean self) {
        GodAvatars.Avatar a = GodAvatars.summon(caster, GodFigures.HERCULES, 30);
        a.side = -1.7;
        a.back = 1.6;
        a.tau0 = 5f;            // melompat (gada di atas kepala) lalu mendarat menghantam di tau 9-11
        a.tauRate = 1f;
        a.tauMax = 40f;
        a.hop = 1.6;
        a.hopUntil = ShazamAnim.CAST_WINDUP;
        a.aim = caster.position().add(flatLook(caster).scale(4.5));   // gada dihantamkan ke tanah di depan
        a.windAt = 0;
        a.strikeAt = ShazamAnim.CAST_WINDUP;
        a.convergeEnd = ShazamAnim.CAST_WINDUP + 12;
        // sinema: kedua telapak & gada avatar menghimpun guntur selama ancang-ancang; tepat saat tepukan, hantaman di
        // antara telapak dan gada avatar menghantam tanah, lalu listrik sisa merayap di tangan
        for (boolean right : new boolean[] {true, false}) {
            CineFx.gather(caster, 0, ShazamAnim.CAST_WINDUP, pt -> ShazamPoses.handPos(caster, right, pt), ShazamFx.HERCULES, 1.2,
                    3f, true);
        }
        CineFx.gather(caster, 0, ShazamAnim.CAST_WINDUP, pt -> GodAvatars.weapon(caster, GodFigures.HERCULES), 0xF4FFE8, 1.0,
                3f, true);
        schedule(ShazamAnim.CAST_WINDUP, 1, (level, t) -> {
            Vec3 look = caster.getViewVector(1f);
            Vec3 hands = caster.getEyePosition().add(look.scale(0.8)).subtract(0, 0.4, 0);
            CineFx.impact(level, hands, 1.2f, ShazamFx.HERCULES, 0xF4FFE8, self, false);
            Lightning.Crackle crackle = new Lightning.Crackle(caster, ShazamFx.HERCULES, 0.9f, 0.035f, 16).reach(0.7);
            crackle.strength(firstPerson(caster) ? 0.15f : 1f);
            Vfx.add(crackle);
        });
        schedule(ShazamAnim.CAST_WINDUP + 2, 1, (level, t) -> {   // gada avatar baru menyentuh tanah 2 tick sesudah tepukan
            Vec3 tip = GodAvatars.weapon(caster, GodFigures.HERCULES);
            Ground.Map map = ShazamFx.ground(level, tip, 2.5);
            Vec3 hit = map != null && map.found ? new Vec3(tip.x, map.centerY + 0.05, tip.z) : tip;
            ShazamFx.impact(level, caster, hit, 1.3f, ShazamFx.HERCULES, ShazamFx.WHITE_HOT, true);
            CineFx.impact(level, hit.add(0, 0.3, 0), 1.5f, ShazamFx.HERCULES, 0xF4FFE8, false, true);
        });
        schedule(ShazamAnim.CAST_WINDUP, 1, (level, t) -> {
            Vec3 look = caster.getViewVector(1f);
            Vec3 flat = new Vec3(look.x, look.y * 0.35, look.z).normalize();
            Vec3 hands = caster.getEyePosition().add(look.scale(0.8)).subtract(0, 0.4, 0);
            for (int k = 0; k < 5; k++) {   // guntur menjalar di sepanjang kerucut
                Vec3 dir = flat.add(ShazamFx.randomDir(level.random).scale(0.32)).normalize();
                Vec3 end = hands.add(dir.scale(5.0 + level.random.nextDouble() * 3.5));
                Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(hands), Lightning.Anchor.fixed(end), ShazamFx.HERCULES, 0.08f,
                        5 + level.random.nextInt(3), 1, 2, 0.24));
            }
            Vfx.add(new Fx.Wave(hands.add(flat.scale(0.5)), flat, 4.8, 0.28, 0xFFFFFF, 8, 0.9f, 0f, null));
            Vfx.add(new Fx.Bubble(hands, 2.6, ShazamFx.HERCULES, 9, 0.7f, 1.0, 2.0, true));
            sound(level, hands, SoundEvents.LIGHTNING_BOLT_IMPACT, 1.2f, 1.5f);
            if (self) {
                ScreenFlash.flash(0.18f, 0xF4FFE8);
            }
        });
    }

    private static void herculesThrow(AbstractClientPlayer caster, Vec3 pos, boolean self) {
        GodAvatars.Avatar a = GodAvatars.summon(caster, GodFigures.HERCULES, 34);
        a.side = -1.7;
        a.back = 1.5;
        a.tau0 = 40f;
        a.windAt = ShazamAnim.THROW_LIFT - 2;   // gada ditarik ke belakang selama musuh diangkat, lalu diayunkan
        for (boolean right : new boolean[] {true, false}) {   // sinema: tenaga terkumpul di tangan selama mengangkat
            CineFx.gather(caster, 0, ShazamAnim.THROW_RELEASE, pt -> ShazamPoses.handPos(caster, right, pt), ShazamFx.HERCULES,
                    1.0, 2.5f, true);
        }
        a.strikeAt = ShazamAnim.THROW_RELEASE;
        a.convergeEnd = ShazamAnim.THROW_RELEASE + 12;
        a.lunge = 1.0;
        a.aimAhead = 10.0;
        schedule(0, 1, (level, t) -> {
            for (boolean right : new boolean[] {true, false}) {
                Vfx.add(new Fx.Glow(caster, pt -> ShazamPoses.handPos(caster, right, pt), 0.6f, ShazamFx.HERCULES,
                        ShazamAnim.THROW_RELEASE + 3, ShazamAnim.THROW_LIFT));
            }
            LivingEntity mob = nearestMob(level, pos, 2.5);
            if (mob == null) {
                return;
            }
            Vfx.add(new Fx.Glow(mob, pt -> mob.getPosition(pt).add(0, mob.getBbHeight() * 0.5, 0), 0.9f, ShazamFx.HERCULES,
                    ShazamAnim.THROW_RELEASE + 2, ShazamAnim.THROW_LIFT));
            schedule(ShazamAnim.THROW_RELEASE, 1, (lv, tt) -> {
                if (!mob.isAlive()) {
                    return;
                }
                Vec3 look = caster.getViewVector(1f);
                Vec3 c = mob.position().add(0, mob.getBbHeight() * 0.5, 0);
                Vfx.add(new Fx.Trail(mob, pt -> mob.getPosition(pt).add(0, mob.getBbHeight() * 0.5, 0), ShazamFx.HERCULES, 0.9f,
                        10, 30, true));
                Vfx.add(new Fx.Cone(c, look, 4.0, 0.6, 0xF0FFF0, 10, 0.5f, 2.0, true));
                Vfx.add(new Fx.Ripple(c, look, 3.0, 0.5, 2.6, 0.3, 0xFFFFFF, 10, 0.8f, false));
                Vfx.add(new Fx.Flash(c, 1.6f, ShazamFx.WHITE_HOT, 6, 0.9f));
                CineFx.flare(c, 0xF4FFE8, 3.5f, 0.09f, 1f, 9);
                ShazamFx.shakeAround(c, 0.35f, 16);
                if (self) {
                    ScreenFx.speedLines(0.5f);
                    FovKick.punch(-0.06f);
                }
            });
        });
    }

    private static void herculesImpact(AbstractClientPlayer caster, Vec3 pos, boolean self) {
        schedule(0, 1, (level, t) -> {
            ShazamFx.impact(level, caster, pos, 1.7f, ShazamFx.HERCULES, ShazamFx.WHITE_HOT, true);
            CineFx.impact(level, pos.add(0, 0.4, 0), 2.0f, ShazamFx.HERCULES, 0xF4FFE8, self, true);
            Vfx.add(new Fx.Bubble(pos, 3.8, 0xF2FFE6, 10, 0.75f, 0.6, 2.0, true));
            Vfx.add(new Fx.Flash(pos.add(0, 0.8, 0), 2.4f, 0xFFFFFF, 8, 1f));
            ShazamFx.groundArcs(level, pos, 6, 3.6, ShazamFx.HERCULES, 6);
            ShazamFx.ringOfSparks(level, pos.add(0, 0.5, 0), 30, ShazamFx.HERCULES, 0.45);
            ShazamFx.shakeAround(pos, 0.8f, 28);
            if (self) {
                ScreenFlash.flash(0.2f, 0xF4FFE8);
            }
        });
    }

    // ------------------------------------------------------------------ A - Beban Langit Atlas

    private static void atlasRaise(AbstractClientPlayer caster, boolean self) {
        GodAvatars.Avatar a = GodAvatars.summon(caster, GodFigures.ATLAS, ShazamAnim.ATLAS_HOLD + 24);
        a.back = 2.3;
        a.scaleMul = 1.45f;
        a.convergeTo = 1f;      // bola langit diangkat tinggi
        a.convergeAt = 2;
        a.convergeLen = 6;
        a.convergeEnd = ShazamAnim.ATLAS_HOLD;
        // sinema: cahaya langit turun ke pusat gravitasi selama bola langit jatuh, kepalan yang menyangga langit membara
        schedule(2, 1, (level, t) -> CineFx.godRays(Lightning.Anchor.fixed(caster.position()), 0xBFD8FF, 18.0, 2.6, 9, 0.85f,
                ShazamAnim.ATLAS_HOLD + 10));
        CineFx.gather(caster, 0, ShazamAnim.ATLAS_HOLD,
                pt -> ShazamPoses.handPos(caster, true, pt).add(ShazamPoses.handPos(caster, false, pt)).scale(0.5), ShazamFx.ATLAS,
                1.6, 3f, true);
        schedule(0, 1, (level, t) -> {
            Vec3 c = caster.position();
            Ground.Map map = ShazamFx.ground(level, c, 6.0);
            double gy = (map == null ? c.y : map.centerY) + 0.04;
            Vfx.add(new Runes.Circle(Lightning.Anchor.fixed(new Vec3(c.x, gy, c.z)), UP, 6.0, ShazamFx.ATLAS,
                    ShazamAnim.ATLAS_HOLD + 8, -0.035f, 0.85f, map));
        });
        schedule(2, ShazamAnim.ATLAS_HOLD - 2, (level, t) -> {
            RandomSource r = level.random;
            Vec3 c = caster.position();
            for (int i = 0, n = Vfx.count(6); i < n; i++) {   // debu tersedot ke pusat: gravitasi langit
                double angle = r.nextDouble() * Math.PI * 2.0, d = 3.0 + r.nextDouble() * 7.0;
                double cs = Math.cos(angle), sn = Math.sin(angle);
                Vfx.dust(c.x + cs * d, c.y + 0.15, c.z + sn * d, -cs * 0.3, 0.005, -sn * 0.3, 0xB8A68C,
                        0.45f + r.nextFloat() * 0.4f, 14 + r.nextInt(6));
            }
            if (t % 2 == 0) {
                double angle = r.nextDouble() * Math.PI * 2.0;
                Vfx.glint(c.x + Math.cos(angle) * 2.0, c.y + 2.5 + r.nextDouble() * 3.0, c.z + Math.sin(angle) * 2.0, STAR,
                        0.22f, 8);
            }
            if (self && t % 2 == 0) {
                CameraShake.add(0.03f + t * 0.004f);
            }
        });
    }

    private static void atlasGlobe(Vec3 pos) {
        schedule(ShazamAnim.ATLAS_HOLD - ShazamAnim.ATLAS_GLOBE_DROP, 1, (level, t) -> {
            Ground.Map map = ShazamFx.ground(level, pos, 3.0);
            double gy = map != null && map.found ? map.centerY : pos.y;
            Vfx.add(new SkyGlobe(new Vec3(pos.x, gy, pos.z), 3.0, 15.0, ShazamAnim.ATLAS_GLOBE_DROP,
                    ShazamAnim.ATLAS_GLOBE_DROP + 9));
            sound(level, pos, SoundEvents.BEACON_ACTIVATE, 1.3f, 0.5f);
        });
    }

    private static void atlasImpact(AbstractClientPlayer caster, boolean self) {
        schedule(0, 1, (level, t) -> {
            Vec3 c = caster.position();
            RandomSource r = level.random;
            Ground.Map map = ShazamFx.ground(level, c, 10.0);
            if (map != null) {
                Vec3 g = map.center(c);
                int dust = map.dustColor(level, c);
                Vfx.add(new Fx.Wave(g, UP, 10.0, 0.5, SKY_RIM, 16, 0.85f, 0.05f, map));   // cincin langit
                Vfx.add(new Fx.Wave(g, UP, 6.5, 0.3, 0xFFE9A0, 12, 0.9f, 0.15f, map));
                Vfx.add(new Fx.Wave(g, UP, 8.0, 2.2, dust, 34, 0.7f, 0f, map, true));
                if (map.found) {
                    Vfx.add(new Ground.Debris(g, map, 16, 0.3, 0.5, 1.4, 50));
                }
                ShazamFx.smokeCloud(level, g, dust, 10, 4.0);
            }
            for (int i = 0, n = Vfx.count(26); i < n; i++) {   // bintang-bintang dari bola langit yang pecah
                double angle = r.nextDouble() * Math.PI * 2.0, d = r.nextDouble() * 4.0;
                Vfx.glint(c.x + Math.cos(angle) * d, c.y + 0.5 + r.nextDouble() * 2.5, c.z + Math.sin(angle) * d, STAR, 0.3f,
                        14 + r.nextInt(10));
            }
            for (int i = 0, n = Vfx.count(18); i < n; i++) {
                Vec3 v = ShazamFx.randomDir(r);
                Vfx.mote(c.x, c.y + 1.0, c.z, v.x * 0.35, Math.abs(v.y) * 0.25, v.z * 0.35, SKY_RIM, 0.1f, 20);
            }
            Vfx.add(new Fx.Bubble(c.add(0, 0.2, 0), 7.0, SKY_RIM, 12, 0.6f, 0.55, 2.0, true));
            Vfx.add(new Fx.Pillar(c, 30.0, 2.4f, 0xCFE4FF, 12));
            CineFx.impact(level, c.add(0, 0.6, 0), 2.8f, SKY_RIM, 0xFFFFFF, self, true);
            CineFx.flare(c.add(0, 1.0, 0), 0xDCE8FF, 8f, 0.2f, 1f, 16);
            ShazamFx.shakeAround(c, 1.2f, 36);
            if (self) {
                ScreenFlash.flash(0.45f, 0xE6EEFF);
                ScreenFx.vignette(0.5f, 0x0A1030, 10);
                FovKick.punch(-0.1f);
            }
        });
    }

    /**
     * Bola langit berbintang (seperti yang dipanggul Atlas): cangkang biru malam, dua cincin emas berputar, rasi bintang di
     * permukaannya. Jatuh makin cepat dari ketinggian, lalu pecah jadi bintang-bintang dan mengembang memudar.
     */
    static final class SkyGlobe extends Effect {
        private final double x, gy, z, radius, height;
        private final int fall;
        private final long seed = Vfx.random().nextLong();
        private boolean burst;

        SkyGlobe(Vec3 ground, double radius, double height, int fall, int life) {
            super(life);
            this.x = ground.x;
            this.gy = ground.y;
            this.z = ground.z;
            this.radius = radius;
            this.height = height;
            this.fall = Math.max(1, fall);
        }

        private double centerY(float pt) {
            float u = Math.min(1f, time(pt) / fall);
            return gy + radius * 0.35 + height * (1.0 - u * u);   // jatuh makin cepat
        }

        private double size(float pt) {
            float after = time(pt) - fall;
            return after <= 0f ? radius : radius * (1.0 + after * 0.12);
        }

        private float alpha(float pt) {
            float time = time(pt);
            float in = Math.min(1f, time / 3f);
            float out = time <= fall ? 1f : Math.max(0f, 1f - (time - fall) / Math.max(1f, life - fall));
            return in * out;
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (!burst && age >= fall) {
                burst = true;
                Vec3 c = new Vec3(x, gy + radius * 0.35, z);
                Vfx.add(new Fx.Flash(c, (float) radius * 1.6f, 0xDCE8FF, 10, 1f));
                for (int i = 0, n = Vfx.count(30); i < n; i++) {
                    Vec3 d = ShazamFx.randomDir(level.random);
                    Vfx.glint(c.x + d.x * radius, c.y + Math.abs(d.y) * radius, c.z + d.z * radius, STAR, 0.25f,
                            10 + level.random.nextInt(12));
                }
            }
            return super.tick(level);
        }

        @Override
        public void renderSoft(Draw d) {
            float a = alpha(d.partialTick);
            if (a > 0.01f) {
                d.shell(x, centerY(d.partialTick), z, size(d.partialTick) * 0.98, SKY_DEEP, 0.5f * a, 0.6, 1.0);
            }
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float a = alpha(pt);
            if (a <= 0.01f) {
                return;
            }
            float time = time(pt);
            double cy = centerY(pt);
            double r = size(pt);
            d.shell(x, cy, z, r, SKY_RIM, 0.8f * a, 2.2, 1.0);
            double spin = time * 0.08;
            d.ring(x, cy, z, Math.sin(0.5) * Math.cos(spin), Math.cos(0.5), Math.sin(0.5) * Math.sin(spin), r * 1.08, r * 0.06,
                    SKY_GOLD, 0.9f * a, 0f, null);
            d.ring(x, cy, z, -Math.sin(0.9) * Math.sin(spin), Math.cos(0.9), Math.sin(0.9) * Math.cos(spin), r, r * 0.04,
                    0xFFE9A8, 0.7f * a, 0f, null);
            Random random = new Random(seed);
            for (int k = 0; k < 6; k++) {   // rasi bintang: empat bintang bersambung
                double lon0 = random.nextDouble() * Math.PI * 2.0, lat0 = (random.nextDouble() - 0.5) * 2.2;
                double px = 0, py = 0, pz = 0;
                for (int s = 0; s < 4; s++) {
                    double lon = lon0 + s * 0.28 + random.nextDouble() * 0.15 + spin * 0.6;
                    double lat = lat0 + (random.nextDouble() - 0.5) * 0.5;
                    double cl = Math.cos(lat);
                    double sx = x + Math.cos(lon) * cl * r, sy = cy + Math.sin(lat) * r, sz = z + Math.sin(lon) * cl * r;
                    float size = (float) ((0.16 + random.nextDouble() * 0.1) * (r / 2.8));
                    d.glint(sx, sy, sz, size, time * 0.05f, STAR, 0.9f * a);
                    if (s > 0) {
                        d.line(px, py, pz, sx, sy, sz, 0.035f, 0.035f, 0xCFE0FF, 0.55f * a, 0.55f * a);
                    }
                    px = sx;
                    py = sy;
                    pz = sz;
                }
            }
            if (time < fall) {   // ekor meteor di atasnya
                double tail = 1.0 + 6.0 * (1.0 - time / fall);
                d.beam(x, cy + r, z, x, cy + r + tail, z, (float) r * 0.9f, SKY_RIM, 0xFFFFFF, 0.45f * a, 0f);
            }
        }
    }

    // ------------------------------------------------------------------ Z - Petir Berantai Zeus

    private static void zeus(AbstractClientPlayer caster, Vec3 target) {
        GodAvatars.Avatar a = GodAvatars.summon(caster, GodFigures.ZEUS, 40);
        a.side = 0.6;
        a.back = 2.1;
        a.lift = 1.3;           // melayang di atas bahu
        a.scaleMul = 1.35f;
        a.tau0 = 22f;
        a.aim = target;
        a.windAt = 0;           // petir ditarik ke belakang kepala, lalu dilempar tepat saat guntur menyambar
        a.strikeAt = ShazamAnim.CAST_WINDUP;
        a.convergeEnd = ShazamAnim.CAST_WINDUP + 16;
        a.lunge = 0.5;
        // sinema: petir di tangan Shazam & di tangan avatar Zeus menghimpun tenaga selama ancang-ancang; tepat saat jari
        // menunjuk, Zeus melempar petirnya (tombak petir) bersamaan dengan petir dari jari dan guntur dari langit
        CineFx.gather(caster, 0, ShazamAnim.CAST_WINDUP, pt -> ShazamPoses.handPos(caster, true, pt), ShazamFx.ZEUS, 1.1, 4f, true);
        CineFx.gather(caster, 0, ShazamAnim.CAST_WINDUP, pt -> GodAvatars.weapon(caster, GodFigures.ZEUS), 0xFFF6C8, 1.2, 4f, true);
        schedule(ShazamAnim.CAST_WINDUP, 1, (level, t) -> {
            Vec3 from = GodAvatars.weapon(caster, GodFigures.ZEUS);
            CineFx.boltSpear(from, target, 0xFFF0B0, 0.26f, 2, 10);
            CineFx.flare(from, 0xFFF4C8, 4f, 0.1f, 1f, 8);
        });
        schedule(0, ShazamAnim.CAST_WINDUP, (level, t) -> {   // langit di atas sasaran bergemuruh
            if (t % 2 == 0) {
                Vfx.add(new Fx.Flash(target.add(0, 12 + level.random.nextDouble() * 4, 0), 5f, 0x9FB8FF, 6, 0.3f));
            }
        });
    }

    private static void zeusChain(AbstractClientPlayer caster, Vec3 pos, boolean first, boolean self) {
        Vec3 last = first ? null : CHAIN.get(caster.getId());
        CHAIN.put(caster.getId(), pos);
        schedule(0, 1, (level, t) -> {
            Lightning.Anchor from;
            if (last == null) {
                from = pt -> ShazamPoses.handPos(caster, true, pt);   // dari ujung jari
            } else {
                from = Lightning.Anchor.fixed(last);
            }
            Lightning.Anchor to = Lightning.Anchor.fixed(pos);
            Vfx.add(new Lightning.Arc(from, to, ShazamFx.ZEUS, 0.17f, 9, 1, 3, 0.2));
            Vfx.add(new Lightning.Arc(from, to, 0xFFFFFF, 0.06f, 6, 1, 1, 0.28));
            Vfx.add(new Fx.Flash(pos, 1.5f, ShazamFx.GOLD_LIGHT, 7, 1f));
            Vfx.add(new Fx.Bubble(pos, 1.3, ShazamFx.ZEUS, 7, 0.6f, 1.0, 2.0, true));
            CineFx.flare(pos, 0xFFF4C8, first ? 4.5f : 3f, first ? 0.12f : 0.08f, 1f, 9);
            arcsOut(level, pos, 3, 1.3, ShazamFx.GOLD_LIGHT, 0.06f, 3);
            ShazamFx.ringOfSparks(level, pos, 16, ShazamFx.ZEUS, 0.35);
            ShazamFx.shakeAround(pos, 0.2f, 18);
            if (first && self) {
                ScreenFlash.flash(0.12f, 0xFFF4C8);
                FovKick.punch(-0.03f);
            }
        });
    }

    // ------------------------------------------------------------------ A - Perisai Achilles

    private static void achilles(AbstractClientPlayer caster) {
        GodAvatars.Avatar a = GodAvatars.summon(caster, GodFigures.ACHILLES, 32);
        a.side = 1.6;
        a.back = 1.5;
        a.tau0 = 9.5f;          // merunduk, lalu tombak ditusukkan tepat saat raungan (tau 13,5)
        a.tauRate = 1f;
        a.tauMax = 40f;
        a.windAt = 0;
        a.strikeAt = ShazamAnim.ROAR_WINDUP;
        a.convergeEnd = ShazamAnim.ROAR_WINDUP + 14;
        // sinema: tombak avatar menghimpun cahaya selama ancang-ancang, lalu ditusukkan bersamaan raungan: berkas tombak cahaya
        // melesat ke depan, dan kaki Shazam menghentak tanah
        CineFx.gather(caster, 0, ShazamAnim.ROAR_WINDUP, pt -> GodAvatars.weapon(caster, GodFigures.ACHILLES), AEGIS, 0.9, 3f,
                false);
        schedule(ShazamAnim.ROAR_WINDUP, 1, (level, t) -> CineFx.impact(level, caster.position().add(0, 0.2, 0), 1.3f, AEGIS,
                0xFFE9A8, caster == Minecraft.getInstance().player, true));   // raungan: kaki menghentak tanah
        schedule(ShazamAnim.ROAR_WINDUP + 1, 1, (level, t) -> {   // tombak avatar terdorong penuh 1 tick sesudahnya
            Vec3 from = GodAvatars.weapon(caster, GodFigures.ACHILLES);
            Vec3 forward = flatLook(caster);
            Vfx.add(new SpearBeam(from, from.add(forward.scale(9.0)), AEGIS, 0.4f, 11));
            Vfx.add(new Fx.Cone(from, forward, 6.0, 0.35, 0xFFF0C8, 10, 0.45f, 2.0, true));
            CineFx.flare(from, 0xFFE9A8, 4f, 0.1f, 1f, 10);
        });
        a.lunge = 1.0;
        schedule(ShazamAnim.ROAR_WINDUP, 1, (level, t) -> Vfx.add(new Aegis(caster, ShazamAnim.ACHILLES_TICKS + 12)));
    }

    private static void courageNova(AbstractClientPlayer caster, boolean self) {
        GodAvatars.Avatar a = GodAvatars.summon(caster, GodFigures.ACHILLES, 24);
        a.side = 1.6;
        a.back = 1.5;
        a.tau0 = 11f;
        a.tauRate = 1.2f;
        a.tauMax = 40f;
        a.windAt = 0;
        a.strikeAt = ShazamAnim.NOVA_WINDUP;
        a.convergeEnd = ShazamAnim.NOVA_WINDUP + 12;
        schedule(ShazamAnim.NOVA_WINDUP, 1, (level, t) -> {   // sinema: hantaman berlapis & suar emas raksasa
            Vec3 chest = caster.position().add(0, 1.2 * caster.getScale(), 0);
            CineFx.impact(level, chest, 2.4f, AEGIS, 0xFFF0C0, self, true);
            CineFx.flare(chest, 0xFFF0C0, 7f, 0.18f, 1f, 14);
        });
        schedule(0, ShazamAnim.NOVA_WINDUP, (level, t) -> {
            Vec3 chest = caster.position().add(0, 1.2 * caster.getScale(), 0);
            for (int i = 0, n = Vfx.count(10); i < n; i++) {   // cahaya emas terhisap ke dada
                Vec3 off = ShazamFx.randomDir(level.random).scale(2.0 + level.random.nextDouble());
                Vfx.mote(chest.x + off.x, chest.y + off.y * 0.7, chest.z + off.z, -off.x * 0.3, -off.y * 0.2, -off.z * 0.3,
                        AEGIS, 0.09f, 4);
            }
        });
        schedule(ShazamAnim.NOVA_WINDUP, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vec3 chest = c.add(0, 1.2 * caster.getScale(), 0);
            Vfx.add(new Fx.Flash(chest, 3.2f, 0xFFF0B0, 10, 1f));
            Vfx.add(new Fx.Bubble(c.add(0, 0.2, 0), 7.5, AEGIS, 13, 0.9f, 0.6, 2.0, true));
            Vfx.add(new Fx.Bubble(chest, 3.0, 0xFFFFFF, 7, 0.6f, 1.0, 2.6, true));
            Ground.Map map = ShazamFx.ground(level, c, 8.0);
            if (map != null) {
                Vec3 g = map.center(c);
                int dust = map.dustColor(level, c);
                Vfx.add(new Fx.Wave(g, UP, 8.0, 0.45, AEGIS, 14, 0.95f, 0.1f, map));
                Vfx.add(new Fx.Wave(g, UP, 6.0, 0.25, 0xFFFFFF, 10, 0.8f, 0f, map));
                Vfx.add(new Fx.Wave(g, UP, 7.0, 1.6, dust, 26, 0.6f, 0f, map, true));
                ShazamFx.dustPuffs(level, g, dust, 24, 2.5, 0.3);
            }
            ShazamFx.ringOfSparks(level, chest, 50, AEGIS, 0.6);
            for (int k = 0; k < 14; k++) {   // pecahan perisai emas
                double angle = Math.PI * 2.0 * k / 14 + level.random.nextDouble() * 0.3;
                Vfx.spark(chest.x, chest.y, chest.z, Math.cos(angle) * 0.7, 0.12 + level.random.nextDouble() * 0.2,
                        Math.sin(angle) * 0.7, 0xFFE9A8, 0.09f, 16 + level.random.nextInt(8), c.y);
            }
            ShazamFx.shakeAround(c, 0.9f, 28);
            if (self) {
                ScreenFlash.flash(0.4f, 0xFFF0C0);
                ScreenFx.vignette(0.4f, 0x2E1C00, 8);
            }
        });
    }

    /** Perisai matahari Achilles di depan dada: tepi emas, sinar berputar, matahari di tengah. */
    static final class Aegis extends Effect {
        private final AbstractClientPlayer owner;
        private final double[] plane = new double[6];

        Aegis(AbstractClientPlayer owner, int life) {
            super(life);
            this.owner = owner;
        }

        @Override
        public boolean tick(ClientLevel level) {
            return owner.isAlive() && ShazamClientState.isTransformed(owner.getId()) && super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float time = time(pt);
            float a = Math.min(1f, time / 4f) * Math.min(1f, ShazamPoses.auraStrength(owner, pt) * 1.5f);
            if (a <= 0.01f) {
                return;
            }
            Vec3 look = owner.getViewVector(pt);
            Vec3 f = new Vec3(look.x, 0, look.z);
            f = f.lengthSqr() < 1.0E-4 ? new Vec3(0, 0, 1) : f.normalize();
            double sc = owner.getScale();
            Vec3 c = owner.getPosition(pt).add(0, 1.15 * sc, 0).add(f.scale(0.95 * sc));
            a *= d.nearFade(c.x, c.y, c.z, 1.4, 3.0);   // dari mata sendiri nggak menutupi layar
            if (a <= 0.01f) {
                return;
            }
            double size = 0.9 * sc;
            float pulse = 0.85f + 0.15f * (float) Math.sin(time * 0.3f);
            d.ring(c.x, c.y, c.z, f.x, 0, f.z, size, 0.12 * sc, AEGIS, 0.95f * a, 0.12f, null);
            d.ring(c.x, c.y, c.z, f.x, 0, f.z, size * 0.66, 0.06 * sc, 0xFFE9A8, 0.7f * a, 0f, null);
            d.disc(c.x, c.y, c.z, f.x, 0, f.z, size * 0.3, 0xFFF4D0, 0.9f * a * pulse, 0.2f * a, null);
            Draw.plane(f.x, 0, f.z, plane);
            for (int k = 0; k < 12; k++) {
                double angle = k * Math.PI * 2.0 / 12 + time * 0.03;
                double cs = Math.cos(angle), sn = Math.sin(angle);
                double ux = plane[0] * cs + plane[3] * sn, uy = plane[1] * cs + plane[4] * sn, uz = plane[2] * cs + plane[5] * sn;
                d.line(c.x + ux * size * 0.34, c.y + uy * size * 0.34, c.z + uz * size * 0.34,
                        c.x + ux * size * 0.62, c.y + uy * size * 0.62, c.z + uz * size * 0.62,
                        (float) (0.08 * sc), (float) (0.02 * sc), AEGIS, 0.8f * a, 0.1f * a);
            }
            float old = d.body(0.4f);
            d.glow(c.x, c.y, c.z, (float) (size * 1.6), AEGIS, 0.25f * a * pulse);
            d.body(old);
        }
    }

    // ------------------------------------------------------------------ Badai Para Dewa

    private static void rage(AbstractClientPlayer caster, boolean self) {
        // sinema: pita film masuk, energi badai terhisap ke dada selama membungkuk; saat meraung: kartu judul, kilatan inti,
        // suar raksasa, dan berkas cahaya enam warna dewa turun di tempat tiap dewa berdiri
        if (self) {
            ScreenFx.cinema(ShazamAnim.RAGE_WINDUP + 44);
            ScreenFx.titleKey("title.shazammod.storm_gods", 0xFFE9A8, 64, ShazamAnim.RAGE_WINDUP);
        }
        CineFx.gather(caster, 0, ShazamAnim.RAGE_WINDUP, Lightning.Anchor.on(caster, 0, 1.2 * caster.getScale(), 0), ShazamFx.STORM,
                2.2, 6f, true);
        schedule(ShazamAnim.RAGE_WINDUP, 1, (level, t) -> {
            Vec3 chest = caster.position().add(0, 1.2 * caster.getScale(), 0);
            CineFx.impact(level, chest, 2.6f, ShazamFx.STORM, 0xFFFFFF, self, true);
            CineFx.flare(chest, 0xEAF4FF, 10f, 0.24f, 1f, 18);
            for (int i = 0; i < GodFigures.COUNT; i++) {
                double angle = i * Math.PI * 2.0 / GodFigures.COUNT;
                Vec3 at = caster.position().add(Math.cos(angle) * 3.8, 0, Math.sin(angle) * 3.8);
                CineFx.godRays(Lightning.Anchor.fixed(at), GodFigures.AURA[i], 20.0, 0.9, 3, 0.7f, 36);
            }
        });
        schedule(ShazamAnim.RAGE_WINDUP, 1, (level, t) -> {
            GodAvatars.ring(caster);
            StormCloud cloud = new StormCloud(caster, ShazamAnim.RAGE_TICKS + 40);
            StormCloud old = CLOUDS.put(caster.getId(), cloud);
            if (old != null) {
                old.end();
            }
            Vfx.add(cloud);
            Vec3 c = caster.position();
            for (int i = 0; i < GodFigures.COUNT; i++) {   // enam pilar cahaya: enam dewa turun
                double angle = i * Math.PI * 2.0 / GodFigures.COUNT;
                Vfx.add(new Fx.Pillar(c.add(Math.cos(angle) * 3.8, 0, Math.sin(angle) * 3.8), 24.0, 0.9f, GodFigures.AURA[i], 16));
            }
            if (self) {
                ScreenFx.vignette(0.45f, 0x0A1430, 14);
            }
        });
    }

    /** Satu dewa di lingkaran menyerang: tiap dewa dengan bentuknya sendiri. */
    private static void godStrike(AbstractClientPlayer caster, int god, Vec3 pos) {
        GodAvatars.strike(caster, god, pos);
        schedule(2, 1, (level, t) -> {
            Vec3 from = GodAvatars.focus(caster, god);
            int aura = GodFigures.AURA[god];
            Vfx.add(new Fx.Flash(pos, 1.6f, aura, 8, 0.95f));
            CineFx.flare(pos, GodLook.lighten(aura, 0.5), 2.6f, 0.07f, 1f, 8);
            switch (god) {
                case GodFigures.SOLOMON -> {   // segel bintang segi enam
                    Vec3 dir = pos.subtract(from);
                    dir = dir.lengthSqr() < 1.0E-4 ? UP : dir.normalize();
                    Vfx.add(new Runes.Circle(Lightning.Anchor.fixed(pos), dir, 1.1, aura, 24, 0.12f, 1f, null));
                    Vfx.add(new SpearBeam(from, pos, aura, 0.18f, 9));
                }
                case GodFigures.HERCULES -> {   // hantaman gada
                    ShazamFx.impact(level, caster, pos, 0.9f, aura, ShazamFx.WHITE_HOT, true);
                    Vfx.add(new Fx.Bubble(pos, 2.2, aura, 8, 0.7f, 1.0, 2.0, true));
                }
                case GodFigures.ATLAS -> {   // bola langit kecil
                    Ground.Map map = ShazamFx.ground(level, pos, 2.0);
                    double gy = map != null && map.found ? map.centerY : pos.y - 1.0;
                    Vfx.add(new SkyGlobe(new Vec3(pos.x, gy, pos.z), 1.3, 6.0, 4, 11));
                }
                case GodFigures.ZEUS -> Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(from), Lightning.Anchor.fixed(pos),
                        ShazamFx.ZEUS, 0.12f, 6, 1, 2, 0.22));
                case GodFigures.ACHILLES -> {   // tombak cahaya
                    Vfx.add(new SpearBeam(from, pos, AEGIS, 0.34f, 9));
                    ShazamFx.ringOfSparks(level, pos, 18, AEGIS, 0.4);
                }
                default -> {   // Mercury: kilat yang melesat
                    Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(from), Lightning.Anchor.fixed(pos), ShazamFx.MERCURY, 0.08f,
                            5, 1, 1, 0.25));
                    Vfx.add(new SpearBeam(from, pos, 0xE8FCFF, 0.12f, 6));
                    ShazamFx.ringOfSparks(level, pos, 14, ShazamFx.MERCURY, 0.4);
                }
            }
        });
    }

    /** Berkas lurus yang tumbuh dari a ke b lalu padam (tombak cahaya, segel). */
    static final class SpearBeam extends Effect {
        private final Vec3 a, b;
        private final int rgb;
        private final float width;

        SpearBeam(Vec3 a, Vec3 b, int rgb, float width, int life) {
            super(life);
            this.a = a;
            this.b = b;
            this.rgb = rgb;
            this.width = width;
        }

        @Override
        public void renderGlow(Draw d) {
            float p = progress(d.partialTick);
            float grow = Math.min(1f, time(d.partialTick) / 2f);
            float alpha = (1f - p) * (1f - p);
            if (alpha <= 0.01f) {
                return;
            }
            Vec3 e = a.lerp(b, grow);
            d.beam(a.x, a.y, a.z, e.x, e.y, e.z, width, rgb, 0xFFFFFF, alpha * 0.6f, alpha);
            d.flare(e.x, e.y, e.z, width * 3f, rgb, alpha);
        }
    }

    /** Awan badai berputar di atas kepala selama Badai Para Dewa; kilat di dalamnya, petir ke tanah di sekeliling. */
    static final class StormCloud extends Effect {
        private final AbstractClientPlayer owner;
        private float fade, fadeO;
        private boolean ending;
        boolean done;

        StormCloud(AbstractClientPlayer owner, int life) {
            super(life);
            this.owner = owner;
        }

        void end() {
            ending = true;
        }

        @Override
        public boolean tick(ClientLevel level) {
            fadeO = fade;
            boolean on = !ending && owner.isAlive() && age < life - 20
                    && (age < 30 || ShazamClientState.isRaging(owner.getId()));
            fade = Mth.approach(fade, on ? 1f : 0f, on ? 0.08f : 0.06f);
            if (on && age % 7 == 3) {
                Vec3 p = owner.position();
                double angle = level.random.nextDouble() * Math.PI * 2.0, r = 2.5 + level.random.nextDouble() * 4.5;
                Vec3 top = p.add(Math.cos(angle) * r * 0.6, 8.5, Math.sin(angle) * r * 0.6);
                Vec3 bottom = p.add(Math.cos(angle) * r, 0.1, Math.sin(angle) * r);
                Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(top), Lightning.Anchor.fixed(bottom), ShazamFx.STORM, 0.09f, 4,
                        1, 2, 0.25));
            }
            boolean alive = super.tick(level) && !(age > 20 && fade <= 0f);
            if (!alive) {
                done = true;
            }
            return alive;
        }

        private float strength(float pt) {
            return Mth.lerp(pt, fadeO, fade);
        }

        @Override
        public void renderSoft(Draw d) {
            float f = strength(d.partialTick);
            if (f <= 0.01f) {
                return;
            }
            Vec3 p = owner.getPosition(d.partialTick);
            float time = time(d.partialTick);
            double cy = p.y + 8.5;
            for (int k = 0; k < 14; k++) {
                double angle = k * Math.PI * 2.0 / 14 + time * 0.02 * (k % 2 == 0 ? 1 : -1);
                double r = 1.5 + (k % 3) * 1.6;
                d.puff(p.x + Math.cos(angle) * r, cy + Math.sin(time * 0.05 + k) * 0.3, p.z + Math.sin(angle) * r,
                        (float) (2.2 + (k % 4) * 0.5), CLOUD_LIT, CLOUD, 0.55f * f);
            }
        }

        @Override
        public void renderGlow(Draw d) {
            float f = strength(d.partialTick);
            if (f <= 0.01f) {
                return;
            }
            Vec3 p = owner.getPosition(d.partialTick);
            double cy = p.y + 8.5;
            Random random = new Random(age / 3 * 31L + owner.getId());
            if (random.nextInt(3) == 0) {   // kilat di dalam awan
                double angle = random.nextDouble() * Math.PI * 2.0, r = random.nextDouble() * 4.0;
                d.glow(p.x + Math.cos(angle) * r, cy, p.z + Math.sin(angle) * r, 2.6f, 0xC8DAFF, 0.5f * f);
            }
            float old = d.body(0.2f);
            d.glow(p.x, cy - 0.5, p.z, 6f, 0x6F86C8, 0.12f * f);
            d.body(old);
        }
    }

    // ------------------------------------------------------------------ pasif

    private static void thunderPunch(AbstractClientPlayer caster, Vec3 pos, boolean self) {
        schedule(0, 1, (level, t) -> {
            Vec3 dir = pos.subtract(caster.getEyePosition());
            dir = dir.lengthSqr() < 1.0E-4 ? caster.getViewVector(1f) : dir.normalize();
            Vfx.add(new Fx.Flash(pos, 2.6f, 0xFFFFFF, 9, 1f));
            Vfx.add(new Fx.Flash(pos, 3.4f, ShazamFx.GOLD, 12, 0.7f));
            Vfx.add(new Fx.Ripple(pos, dir, 4.5, 0.4, 3.4, 0.4, CHARGE, 12, 0.9f, false));
            Vfx.add(new Fx.Cone(pos, dir, 5.0, 0.5, 0xFFF6DC, 12, 0.55f, 2.0, true));
            Vfx.add(new Fx.Bubble(pos, 2.4, ShazamFx.GOLD, 9, 0.8f, 1.0, 2.0, true));
            CineFx.flare(pos, 0xFFF6DC, 6f, 0.16f, 1f, 12);
            arcsOut(level, pos, 8, 3.0, CHARGE, 0.1f, 4);
            ShazamFx.ringOfSparks(level, pos, 40, CHARGE, 0.6);
            ShazamFx.shakeAround(pos, 0.8f, 26);
            if (self) {
                ScreenFlash.flash(0.35f, 0xFFF6D8);
                FovKick.punch(-0.08f);
                CameraShake.add(0.25f);
            }
        });
    }

    private static void dodge(AbstractClientPlayer caster, Vec3 pos, boolean self) {
        ShazamPoses.ghostBurst(caster, 4);
        schedule(0, 1, (level, t) -> {
            Vec3 from = pos.add(0, 1.0, 0);
            Vfx.add(new Fx.Flash(from, 1.3f, ShazamFx.MERCURY, 6, 0.8f));
            CineFx.flare(from, 0xC8F4FF, 3f, 0.07f, 1f, 7);
            Vfx.add(new Fx.Trail(caster, pt -> caster.getPosition(pt).add(0, 1.0, 0), ShazamFx.MERCURY, 0.9f, 8, 5, true));
            Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(from), Lightning.Anchor.on(caster, 0, 1.0, 0), ShazamFx.MERCURY,
                    0.06f, 4, 1, 1, 0.3));
            for (int i = 0, n = Vfx.count(10); i < n; i++) {
                Vec3 v = ShazamFx.randomDir(level.random).scale(0.15);
                Vfx.spark(from.x, from.y, from.z, v.x, v.y, v.z, i % 2 == 0 ? ShazamFx.MERCURY : 0xFFFFFF, 0.05f,
                        6 + level.random.nextInt(4), pos.y);
            }
            if (self) {
                ScreenFx.speedLines(0.45f);
                FovKick.punch(0.05f);
            }
        });
    }

    private static void heroCall(AbstractClientPlayer caster, Vec3 pos, boolean self) {
        schedule(0, 1, (level, t) -> {
            LivingEntity foe = nearestMob(level, pos, 2.5);
            Lightning.Anchor chest = Lightning.Anchor.on(caster, 0, 1.3 * caster.getScale(), 0);
            Lightning.Anchor target;
            if (foe != null) {
                target = pt -> foe.getPosition(pt).add(0, foe.getBbHeight() * 0.6, 0);
                Vfx.add(new Runes.Reticle(foe, HERO, 160, 2));
            } else {
                target = Lightning.Anchor.fixed(pos);
            }
            Vfx.add(new Lightning.Arc(chest, target, HERO, 0.05f, 10, 2, 1, 0.18));
            Vfx.add(new Fx.Flash(pos, 1.6f, HERO, 8, 0.9f));
            if (self) {
                sound(level, caster.position(), SoundEvents.AMETHYST_BLOCK_CHIME, 1.0f, 1.6f);
                ScreenFx.vignette(0.25f, 0x3A2A00, 6);
            }
        });
    }

    private static void stormAbsorb(AbstractClientPlayer caster, boolean self) {
        schedule(0, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vec3 chest = c.add(0, 1.2 * caster.getScale(), 0);
            Vfx.add(new Fx.Flash(chest, 3.2f, 0xEAF4FF, 12, 1f));
            Vfx.add(new Fx.Pillar(c, 50.0, 1.4f, ShazamFx.STORM, 14));
            CineFx.flare(chest, 0xEAF4FF, 7f, 0.18f, 1f, 14);
            CineFx.godRays(Lightning.Anchor.on(caster, 0, 0, 0), ShazamFx.STORM, 24.0, 1.8, 7, 0.8f, 30);
            Lightning.Crackle crackle = new Lightning.Crackle(caster, ShazamFx.STORM, 1.4f, 0.05f, 50).reach(1.1);
            crackle.strength(firstPerson(caster) ? 0.2f : 1f);
            Vfx.add(crackle);
            ShazamFx.groundArcs(level, c, 8, 4.0, ShazamFx.STORM, 6);
            ShazamFx.ringOfSparks(level, chest, 40, ShazamFx.STORM, 0.5);
            if (self) {
                ScreenFlash.flash(0.6f, 0xE8F4FF);
                CameraShake.add(0.3f);
            }
        });
    }
}
