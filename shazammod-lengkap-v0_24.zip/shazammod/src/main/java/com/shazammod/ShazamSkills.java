package com.shazammod;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;

import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Enam skill Shazam (satu untuk tiap huruf S-H-A-Z-A-M) plus Badai Para Dewa. Semuanya jalan di server; gerakan, efek
 * visual, dan avatar dewa raksasa yang ikut bertarung diputar di client lewat ShazamAnim (lihat client.fx.ChampionFx).
 *
 * Sejak 0.23 tiap skill punya mekanik yang nggak dimiliki Black Adam:
 * S - Kebijaksanaan Solomon : semua musuh dalam 48 blok "terbaca": bersinar, +25% damage dari Shazam, damage DARI mereka
 *                             tinggal 60%, dan sihir pelindung mereka (tak terlihat, kekuatan, kecepatan, ...) terhapus.
 * H - Tepukan Guntur        : gelombang guntur berbentuk kerucut: musuh terhempas & limbung, proyektil di dalamnya hancur.
 *     Lemparan Hercules     : Shift + X: musuh di depan diangkat ke atas kepala lalu dilempar; meledak saat menghantam.
 * A - Beban Langit Atlas    : bola langit raksasa jatuh: musuh tersedot ke tengah, lalu yang di tengah tertekan ke tanah
 *                             (30 damage, terkunci) dan yang di pinggir terhempas. Dari udara: menukik seperti meteor.
 * Z - Petir Berantai Zeus   : petir dari ujung jari melompat ke sampai 6 musuh; musuh basah (air/hujan) kena 2x dan
 *                             lompatannya lebih jauh; tiap sasaran juga disambar guntur dari langit di saat yang sama.
 * A - Perisai Achilles      : hampir kebal 6 detik, musuh di sekitar dipancing menyerang Shazam (melindungi sekutu), dan
 *                             damage yang ditahan perisai dilepas di akhir sebagai Ledakan Keberanian.
 * M - Mode Kilat Mercury    : tombol nyala/mati (lihat ShazamMercury).
 * R - Badai Para Dewa       : enam dewa mengelilingi Shazam selama 12 detik; tiap detik dewa yang berbeda menyerang dengan
 *                             gayanya sendiri. Pukulan +50% dan petirnya merambat.
 */
public final class ShazamSkills {
    private ShazamSkills() {}

    public enum Skill {
        SOLOMON(40f, 600),    // S - Kebijaksanaan Solomon
        HERCULES(25f, 80),    // H - Tepukan Guntur Hercules (Shift: Lemparan Hercules)
        ATLAS(40f, 160),      // A - Beban Langit Atlas
        ZEUS(30f, 60),        // Z - Petir Berantai Zeus
        ACHILLES(80f, 900),   // A - Perisai Achilles
        MERCURY(0f, 0),       // M - Mode Kilat Mercury: tombol nyala/mati, energinya diatur ShazamMercury
        ZEUS_RAGE(150f, 1200); // Badai Para Dewa: enam dewa ikut bertarung

        public final float cost;
        public final int cooldownTicks;

        Skill(float cost, int cooldownTicks) {
            this.cost = cost;
            this.cooldownTicks = cooldownTicks;
        }
    }

    // ================= Angka-angka yang gampang diutak-atik =================
    // S - Kebijaksanaan Solomon
    private static final double SOLOMON_RADIUS = 48.0;
    public static final float SOLOMON_FORESIGHT = 0.6f;       // damage dari musuh yang "terbaca" tinggal 60%
    // H - Tepukan Guntur Hercules
    private static final double CLAP_RANGE = 9.0;
    private static final double CLAP_CONE_COS = 0.5;          // lebar kerucut ±60°
    private static final float CLAP_DAMAGE = 20f;
    private static final double CLAP_KNOCKBACK = 2.4;
    private static final int CLAP_STAGGER_TICKS = 50;         // musuh limbung (Slowness III + Weakness)
    // H - Lemparan Hercules (Shift + X)
    private static final double THROW_REACH = 5.5;            // musuh sejauh ini di depan bisa diangkat
    private static final float THROW_MAX_HEALTH = 200f;       // yang lebih kuat dari ini (bos) terlalu berat diangkat
    private static final double THROW_SPEED = 2.6;            // blok/tick saat dilempar
    private static final float THROW_HIT_DAMAGE = 26f;        // yang dilempar
    private static final float THROW_SPLASH_DAMAGE = 18f;     // musuh di sekitar titik jatuhnya
    private static final double THROW_SPLASH_RADIUS = 3.8;
    private static final int THROW_MAX_FLIGHT = 40;           // nggak menabrak apa-apa: berhenti dilacak
    // A - Beban Langit Atlas
    private static final double ATLAS_PULL_RADIUS = 10.0;     // musuh sejauh ini tersedot ke pusat selama bola langit jatuh
    private static final double ATLAS_PULL = 0.32;            // kecepatan tersedot (blok/tick)
    private static final double SLAM_RADIUS = 6.5;            // tengah: tertekan ke tanah
    private static final float SLAM_DAMAGE = 30f;
    private static final int SLAM_PIN_TICKS = 60;             // terkunci (Slowness IV) 3 detik
    private static final double SLAM_OUTER_RADIUS = 10.0;     // pinggir: terhempas keluar
    private static final float SLAM_OUTER_DAMAGE = 10f;
    private static final double SLAM_OUTER_KNOCKBACK = 1.4;
    private static final int SLAM_TIMEOUT_TICKS = 60;
    // Z - Petir Berantai Zeus
    private static final double ZEUS_RANGE = 32.0;
    private static final float ZEUS_DAMAGE = 20f;             // sasaran pertama
    private static final float ZEUS_FALLOFF = 0.15f;          // tiap lompatan berkurang 15%
    private static final int ZEUS_JUMPS = 5;                  // melompat ke paling banyak 5 musuh lain
    private static final double ZEUS_JUMP_RANGE = 7.0;
    private static final float ZEUS_WET_MULTIPLIER = 2f;      // basah (di air/kehujanan): damage x2
    private static final double ZEUS_WET_RANGE = 1.5;         // ... dan lompatan dari dia 1,5x lebih jauh
    private static final float ZEUS_SKY_DAMAGE = 14f;         // guntur dari langit di sasaran pertama (bersamaan petir dari jari)
    private static final float ZEUS_SKY_HOP_DAMAGE = 6f;      // guntur dari langit di tiap sasaran berikutnya
    private static final double ZEUS_RADIUS = 2.5;
    // A - Perisai Achilles
    private static final double ROAR_RADIUS = 6.0;
    public static final float ACHILLES_DAMAGE_MULTIPLIER = 0.15f;
    private static final double TAUNT_RADIUS = 14.0;          // musuh sejauh ini dipancing menyerang Shazam
    private static final double NOVA_RADIUS = 7.5;
    private static final float NOVA_MIN = 12f;                // Ledakan Keberanian = 12 + damage tertahan x 2,5 (maks 90)
    private static final float NOVA_GAIN = 2.5f;
    private static final float NOVA_MAX = 90f;
    private static final double NOVA_KNOCKBACK = 1.8;
    // Badai Para Dewa (R)
    public static final float RAGE_PUNCH_MULTIPLIER = 1.5f;   // pukulan +50%
    private static final double RAGE_CHAIN_RADIUS = 5.0;      // petir dari pukulan merambat ke musuh dekat
    private static final int RAGE_CHAIN_TARGETS = 2;
    private static final float RAGE_CHAIN_DAMAGE = 8f;
    private static final double RAGE_STORM_RADIUS = 14.0;     // tiap detik dewa di lingkaran menyerang musuh di sekitar
    private static final int RAGE_STORM_TARGETS = 2;
    private static final float RAGE_BURST_DAMAGE = 12f;       // ledakan saat para dewa turun
    private static final double RAGE_BURST_RADIUS = 5.0;
    private static final double RAGE_SPEED_BONUS = 0.2;
    private static final ResourceLocation RAGE_SPEED = ShazamMod.id("zeus_rage_speed");
    // =========================================================================

    private static final Map<UUID, long[]> READY_AT = new HashMap<>();
    private static final Map<UUID, Integer> SLAM_PENDING = new HashMap<>();
    private static final Map<UUID, Long> ACHILLES_UNTIL = new HashMap<>();
    private static final Map<UUID, Float> COURAGE = new HashMap<>();      // damage yang ditahan Perisai Achilles
    private static final Map<UUID, Long> EXPOSED_UNTIL = new HashMap<>();
    private static final Map<UUID, Long> RAGE_UNTIL = new HashMap<>();
    private static final Map<UUID, Integer> RAGE_STEP = new HashMap<>();  // giliran dewa di Badai Para Dewa
    private static final Map<UUID, Well> WELLS = new HashMap<>();         // Beban Langit: musuh tersedot ke pusat
    private static final Map<UUID, Grab> GRABS = new HashMap<>();         // Lemparan Hercules: musuh yang sedang diangkat
    private static final List<Thrown> THROWN = new ArrayList<>();         // musuh yang sedang melayang dilempar

    private record Well(Vec3 center, long until) {}

    private record Grab(LivingEntity target, long start) {}

    private record Thrown(UUID owner, LivingEntity target, long start) {}

    // ----------------------------------------------------------- Pakai skill

    public static void use(ServerPlayer player, Skill skill) {
        if (!ShazamPowers.isTransformed(player)) {
            if (ShazamPowers.data(player).unlocked()) {
                player.displayClientMessage(Component.translatable("message.shazammod.not_transformed")
                        .withStyle(ChatFormatting.GRAY), true);
            }
            return;
        }
        if (skill == Skill.MERCURY) {   // tombol nyala/mati tanpa cooldown
            ShazamMercury.toggle(player);
            return;
        }
        if (cooldownTicks(player, skill) > 0) {
            return;
        }
        if (ShazamPowers.data(player).energy() < skill.cost) {
            player.displayClientMessage(Component.translatable("message.shazammod.skill_no_energy",
                    Math.round(skill.cost)).withStyle(ChatFormatting.RED), true);
            return;
        }

        boolean used = switch (skill) {
            case SOLOMON -> solomon(player);
            case HERCULES -> hercules(player);
            case ATLAS -> atlas(player);
            case ZEUS -> zeus(player);
            case ACHILLES -> achilles(player);
            case MERCURY -> false;   // diurus ShazamMercury.toggle di atas
            case ZEUS_RAGE -> zeusRage(player);
        };
        if (!used) {
            // Meleset: energi dan cooldown nggak terpakai
            player.displayClientMessage(Component.translatable("message.shazammod.no_target")
                    .withStyle(ChatFormatting.GRAY), true);
            return;
        }

        ShazamData data = ShazamPowers.data(player);
        ShazamPowers.setData(player, data.withEnergy(data.energy() - skill.cost));
        READY_AT.computeIfAbsent(player.getUUID(), id -> new long[Skill.values().length])[skill.ordinal()] =
                player.level().getGameTime() + skill.cooldownTicks;
        ShazamNetwork.sync(player);
    }

    public static int cooldownTicks(ServerPlayer player, Skill skill) {
        long[] readyAt = READY_AT.get(player.getUUID());
        if (readyAt == null) {
            return 0;
        }
        long left = readyAt[skill.ordinal()] - player.level().getGameTime();
        return left > 0 ? (int) left : 0;
    }

    /** Efek dijalankan beberapa tick lagi, dan dibatalkan kalau pemain keburu balik jadi manusia. */
    private static void later(ServerPlayer player, int delay, Consumer<ServerPlayer> action) {
        ShazamPowers.schedule(player, delay, p -> {
            if (ShazamPowers.isTransformed(p)) {
                action.accept(p);
            }
        });
    }

    /** Dipanggil tiap tick selama pemain dalam wujud Shazam. */
    public static void tick(ServerPlayer player) {
        UUID id = player.getUUID();
        long now = player.level().getGameTime();

        Integer slamLeft = SLAM_PENDING.get(id);
        if (slamLeft != null) {
            if (player.onGround() || player.isInWater() || player.isInLava()) {
                SLAM_PENDING.remove(id);
                slamImpact(player);
            } else if (slamLeft <= 1) {
                SLAM_PENDING.remove(id);
            } else {
                SLAM_PENDING.put(id, slamLeft - 1);
            }
        }

        Well well = WELLS.get(id);
        if (well != null) {
            if (now >= well.until()) {
                WELLS.remove(id);
            } else {
                atlasPull(player, well);
            }
        }

        Grab grab = GRABS.get(id);
        if (grab != null) {
            herculesHold(player, grab, now);
        }
        tickThrown(player, now);

        ShazamMercury.tick(player);

        Long achillesUntil = ACHILLES_UNTIL.get(id);
        if (achillesUntil != null && now >= achillesUntil) {
            ACHILLES_UNTIL.remove(id);
            courageNova(player);
        }

        Long rageUntil = RAGE_UNTIL.get(id);
        if (rageUntil != null) {
            if (now >= rageUntil) {
                endRage(player);
                ShazamNetwork.broadcastState(player);   // mata kembali normal, dewa-dewa pergi
            } else if ((rageUntil - now) % 20 == 0) {
                rageStorm(player);
            }
        }

        ShazamPassives.tick(player);

        if (player.tickCount % 200 == 0) {
            EXPOSED_UNTIL.values().removeIf(until -> until < now);
        }
    }

    /** Hentikan skill yang sedang berjalan (balik jadi manusia, respawn). Cooldown tetap jalan. */
    public static void cancelActive(ServerPlayer player) {
        UUID id = player.getUUID();
        SLAM_PENDING.remove(id);
        ACHILLES_UNTIL.remove(id);
        COURAGE.remove(id);
        WELLS.remove(id);
        GRABS.remove(id);
        THROWN.removeIf(t -> t.owner().equals(id));
        RAGE_STEP.remove(id);
        endRage(player);
        ShazamMercury.stop(player, false);
        ShazamPassives.reset(player);
    }

    public static void forget(UUID id) {
        RAGE_UNTIL.remove(id);
        RAGE_STEP.remove(id);
        READY_AT.remove(id);
        SLAM_PENDING.remove(id);
        ACHILLES_UNTIL.remove(id);
        COURAGE.remove(id);
        WELLS.remove(id);
        GRABS.remove(id);
        THROWN.removeIf(t -> t.owner().equals(id));
        ShazamMercury.forget(id);
        ShazamPassives.forget(id);
    }

    public static boolean isRageActive(ServerPlayer player) {
        Long until = RAGE_UNTIL.get(player.getUUID());
        return until != null && until > player.level().getGameTime();
    }

    public static boolean isAchillesActive(ServerPlayer player) {
        Long until = ACHILLES_UNTIL.get(player.getUUID());
        return until != null && until > player.level().getGameTime();
    }

    public static boolean isExposed(LivingEntity entity) {
        Long until = EXPOSED_UNTIL.get(entity.getUUID());
        return until != null && until > entity.level().getGameTime();
    }

    /** Tandai musuh "terbaca" (Hati Pahlawan, serangan Solomon di Badai Para Dewa). */
    public static void expose(LivingEntity entity, int ticks) {
        long until = entity.level().getGameTime() + ticks;
        EXPOSED_UNTIL.merge(entity.getUUID(), until, Math::max);
    }

    /** Makhluk ini sedang diangkat Shazam ini (Lemparan Hercules). */
    public static boolean isHeldBy(ServerPlayer player, Entity entity) {
        Grab grab = GRABS.get(player.getUUID());
        return grab != null && entity != null && grab.target() == entity;
    }

    private static boolean isHeld(LivingEntity entity) {
        for (Grab grab : GRABS.values()) {
            if (grab.target() == entity) {
                return true;
            }
        }
        for (Thrown thrown : THROWN) {
            if (thrown.target() == entity) {
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------- Alat bantu

    private static void sound(ServerPlayer player, Vec3 at, SoundEvent sound, float volume, float pitch) {
        player.serverLevel().playSound(null, at.x, at.y, at.z, sound, SoundSource.PLAYERS, volume, pitch);
    }

    private static List<LivingEntity> enemies(ServerPlayer player, Vec3 center, double radius) {
        return player.serverLevel().getEntitiesOfClass(LivingEntity.class, new AABB(center, center).inflate(radius),
                m -> m.isAlive() && m instanceof Enemy && m.distanceToSqr(center) <= radius * radius);
    }

    private static Vec3 chest(LivingEntity entity) {
        return entity.position().add(0, entity.getBbHeight() * 0.6, 0);
    }

    private static Vec3 flatLook(ServerPlayer player) {
        Vec3 look = player.getViewVector(1f);
        Vec3 flat = new Vec3(look.x, 0, look.z);
        if (flat.lengthSqr() < 1.0E-4) {
            float yaw = player.getYRot() * Mth.DEG_TO_RAD;
            flat = new Vec3(-Mth.sin(yaw), 0, Mth.cos(yaw));
        }
        return flat.normalize();
    }

    /** Arah mendatar dari pusat ke makhluk ini (satuan), atau nol. */
    private static Vec3 away(Vec3 center, Entity entity) {
        Vec3 away = new Vec3(entity.getX() - center.x, 0, entity.getZ() - center.z);
        return away.lengthSqr() < 1.0E-4 ? Vec3.ZERO : away.normalize();
    }

    /** Musuh terdekat di dalam kerucut pandangan yang kelihatan (tanpa harus tepat dibidik). */
    private static LivingEntity coneTarget(ServerPlayer player, double range, double cos) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getViewVector(1f);
        LivingEntity best = null;
        double bestDistance = Double.MAX_VALUE;
        for (LivingEntity m : enemies(player, player.position(), range)) {
            Vec3 to = chest(m).subtract(eye);
            double d = to.length();
            if (d < 0.01 || to.normalize().dot(look) < cos || !player.hasLineOfSight(m)) {
                continue;
            }
            if (d < bestDistance) {
                bestDistance = d;
                best = m;
            }
        }
        return best;
    }

    // ---------------------------------------------------- S - Kebijaksanaan Solomon

    private static boolean solomon(ServerPlayer player) {
        ShazamNetwork.playAnim(player, ShazamAnim.SOLOMON_SIGHT);
        sound(player, player.position(), SoundEvents.ENCHANTMENT_TABLE_USE, 1.2f, 0.8f);
        sound(player, player.position(), SoundEvents.BOOK_PAGE_TURN, 1.4f, 0.7f);
        later(player, ShazamAnim.CAST_WINDUP, ShazamSkills::revealEnemies);
        return true;
    }

    private static void revealEnemies(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        long until = level.getGameTime() + ShazamAnim.SOLOMON_TICKS;
        for (LivingEntity enemy : enemies(player, player.position(), SOLOMON_RADIUS)) {
            dispel(enemy);
            enemy.addEffect(new MobEffectInstance(MobEffects.GLOWING, ShazamAnim.SOLOMON_TICKS, 0, false, false));
            EXPOSED_UNTIL.put(enemy.getUUID(), until);
        }
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 2f, 0.6f);
    }

    /** Kebenaran Solomon: sihir pelindung musuh (tak terlihat, kekuatan, kecepatan, pulih, ...) terhapus. */
    private static void dispel(LivingEntity enemy) {
        List<Holder<MobEffect>> remove = new ArrayList<>();
        for (MobEffectInstance effect : enemy.getActiveEffects()) {
            if (effect.getEffect().value().isBeneficial()) {
                remove.add(effect.getEffect());
            }
        }
        for (Holder<MobEffect> effect : remove) {
            enemy.removeEffect(effect);
        }
    }

    // ------------------------------------------------- H - Tepukan Guntur / Lemparan Hercules

    private static boolean hercules(ServerPlayer player) {
        if (player.isShiftKeyDown() && !GRABS.containsKey(player.getUUID())) {
            LivingEntity target = grabTarget(player);
            if (target != null) {
                return herculesThrow(player, target);
            }
        }
        ShazamNetwork.playAnim(player, ShazamAnim.HERCULES_CLAP);
        later(player, ShazamAnim.CAST_WINDUP, ShazamSkills::thunderclap);
        return true;
    }

    private static void thunderclap(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getViewVector(1f);
        DamageSource source = ShazamPowers.forceSource(player);
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(CLAP_RANGE),
                m -> m.isAlive() && m instanceof Enemy)) {
            Vec3 toTarget = target.position().add(0, target.getBbHeight() * 0.5, 0).subtract(eye);
            double distance = toTarget.length();
            if (distance > CLAP_RANGE || distance < 0.01 || toTarget.normalize().dot(look) < CLAP_CONE_COS) {
                continue;
            }
            float falloff = (float) (1.0 - distance / CLAP_RANGE * 0.5);
            target.hurt(source, CLAP_DAMAGE * falloff);
            Vec3 push = new Vec3(toTarget.x, 0, toTarget.z).normalize().scale(CLAP_KNOCKBACK * falloff);
            target.push(push.x, 0.35, push.z);
            target.hurtMarked = true;
            // guntur di telinga: limbung sesaat
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, CLAP_STAGGER_TICKS, 2), player);
            target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, CLAP_STAGGER_TICKS, 0), player);
        }
        // panah, bola api, dan proyektil lain di dalam kerucut hancur diterpa gelombang guntur
        double reach = CLAP_RANGE + 2.0;
        for (Projectile projectile : level.getEntitiesOfClass(Projectile.class, player.getBoundingBox().inflate(reach),
                p -> p.isAlive() && p.getOwner() != player)) {
            Vec3 to = projectile.position().subtract(eye);
            double distance = to.length();
            if (distance > reach || distance < 0.01 || to.normalize().dot(look) < CLAP_CONE_COS) {
                continue;
            }
            projectile.discard();
        }
        // gelombang kejutnya digambar di client (ShazamFx & ChampionFx), bukan partikel bawaan
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.WARDEN_SONIC_BOOM, SoundSource.PLAYERS, 1.2f, 1.6f);
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, 1.0f, 1.4f);
    }

    /** Musuh di depan yang bisa diangkat: yang dibidik, atau yang terdekat di depan. */
    private static LivingEntity grabTarget(ServerPlayer player) {
        LivingEntity aimed = aimedEntity(player, THROW_REACH);
        if (canLift(aimed)) {
            return aimed;
        }
        LivingEntity near = coneTarget(player, THROW_REACH, 0.55);
        return canLift(near) ? near : null;
    }

    private static boolean canLift(LivingEntity entity) {
        return entity != null && entity.isAlive() && entity instanceof Enemy && !(entity instanceof Player)
                && entity.getMaxHealth() <= THROW_MAX_HEALTH && !isHeld(entity);
    }

    private static boolean herculesThrow(ServerPlayer player, LivingEntity target) {
        GRABS.put(player.getUUID(), new Grab(target, player.level().getGameTime()));
        ShazamNetwork.playAnim(player, ShazamAnim.HERCULES_THROW, target.position());
        sound(player, target.position(), SoundEvents.PLAYER_ATTACK_STRONG, 1.0f, 0.6f);
        sound(player, player.position(), SoundEvents.IRON_GOLEM_DAMAGE, 0.8f, 0.6f);
        return true;
    }

    /** Musuh diangkat dari depan dada ke atas kepala, lalu (THROW_RELEASE) dilempar ke arah pandangan. */
    private static void herculesHold(ServerPlayer player, Grab grab, long now) {
        LivingEntity target = grab.target();
        int k = (int) (now - grab.start());
        if (!target.isAlive() || target.isRemoved() || k > ShazamAnim.THROW_RELEASE + 2) {
            GRABS.remove(player.getUUID());
            return;
        }
        if (k < ShazamAnim.THROW_RELEASE) {
            double u = Mth.clamp(k / (double) ShazamAnim.THROW_LIFT, 0.0, 1.0);
            u = u * u * (3.0 - 2.0 * u);
            Vec3 flat = flatLook(player);
            double height = player.getBbHeight();
            Vec3 front = player.position().add(flat.scale(1.3)).add(0, height * 0.45, 0);
            Vec3 over = player.position().add(flat.scale(-0.15)).add(0, height + 0.2, 0);
            Vec3 at = front.lerp(over, u);
            target.moveTo(at.x, at.y, at.z);
            target.setDeltaMovement(Vec3.ZERO);
            target.fallDistance = 0f;
            target.hurtMarked = true;
            return;
        }
        GRABS.remove(player.getUUID());
        Vec3 velocity = player.getViewVector(1f).scale(THROW_SPEED).add(0, 0.22, 0);
        target.setDeltaMovement(velocity);
        target.hurtMarked = true;
        THROWN.add(new Thrown(player.getUUID(), target, now));
        sound(player, player.position(), SoundEvents.PHANTOM_SWOOP, 1.6f, 0.6f);
        sound(player, player.position(), SoundEvents.WARDEN_SONIC_BOOM, 0.5f, 1.8f);
    }

    /** Musuh yang dilempar: meledak begitu menabrak tanah, dinding, atau musuh lain. */
    private static void tickThrown(ServerPlayer player, long now) {
        Iterator<Thrown> it = THROWN.iterator();
        List<LivingEntity> impacts = new ArrayList<>();
        while (it.hasNext()) {
            Thrown thrown = it.next();
            if (!thrown.owner().equals(player.getUUID())) {
                continue;
            }
            LivingEntity mob = thrown.target();
            int k = (int) (now - thrown.start());
            if (!mob.isAlive() || mob.isRemoved() || k > THROW_MAX_FLIGHT) {
                it.remove();
                continue;
            }
            if (k < 2) {
                continue;
            }
            boolean hit = mob.horizontalCollision || mob.verticalCollision || mob.onGround() || mob.isInWater();
            if (!hit) {
                for (LivingEntity other : enemies(player, mob.position(), 1.6)) {
                    if (other != mob) {
                        hit = true;
                        break;
                    }
                }
            }
            if (hit) {
                it.remove();
                impacts.add(mob);
            }
        }
        for (LivingEntity mob : impacts) {
            throwImpact(player, mob);
        }
    }

    private static void throwImpact(ServerPlayer player, LivingEntity mob) {
        Vec3 c = mob.position();
        DamageSource source = ShazamPowers.forceSource(player);
        mob.hurt(source, THROW_HIT_DAMAGE);
        for (LivingEntity other : enemies(player, c, THROW_SPLASH_RADIUS)) {
            if (other == mob) {
                continue;
            }
            other.hurt(source, THROW_SPLASH_DAMAGE);
            Vec3 push = away(c, other);
            other.push(push.x * 1.3, 0.45, push.z * 1.3);
            other.hurtMarked = true;
        }
        ShazamNetwork.playAnim(player, ShazamAnim.HERCULES_IMPACT, c);
        sound(player, c, SoundEvents.MACE_SMASH_GROUND_HEAVY, 1.6f, 0.7f);
        sound(player, c, SoundEvents.ANVIL_LAND, 0.7f, 0.5f);
    }

    // --------------------------------------------------- A - Beban Langit Atlas

    private static boolean atlas(ServerPlayer player) {
        if (player.onGround() || player.isInWater()) {
            // Atlas mengangkat langit: bola langit jatuh, musuh tersedot ke pusat, lalu kepalan menghantam
            Vec3 center = player.position();
            ShazamNetwork.playAnim(player, ShazamAnim.ATLAS_GROUND, center);
            ShazamNetwork.playAnim(player, ShazamAnim.ATLAS_GLOBE, center);
            WELLS.put(player.getUUID(), new Well(center, player.level().getGameTime() + ShazamAnim.ATLAS_HOLD));
            sound(player, center, SoundEvents.BEACON_POWER_SELECT, 1.4f, 0.5f);
            sound(player, center, SoundEvents.RESPAWN_ANCHOR_CHARGE, 1.0f, 0.6f);
            later(player, ShazamAnim.ATLAS_HOLD, ShazamSkills::slamImpact);
            return true;
        }
        // Di udara: menukik dulu, hantamannya terjadi waktu mendarat
        ShazamNetwork.playAnim(player, ShazamAnim.ATLAS_DIVE);
        player.getAbilities().flying = false;
        player.onUpdateAbilities();
        Vec3 look = player.getViewVector(1f);
        player.setDeltaMovement(look.x * 0.6, -2.5, look.z * 0.6);
        player.hurtMarked = true;
        SLAM_PENDING.put(player.getUUID(), SLAM_TIMEOUT_TICKS);
        return true;
    }

    /** Gravitasi langit: musuh di sekitar tersedot ke pusat dan tertarik ke tanah. */
    private static void atlasPull(ServerPlayer player, Well well) {
        Vec3 c = well.center();
        for (LivingEntity target : enemies(player, c, ATLAS_PULL_RADIUS)) {
            double dx = c.x - target.getX(), dz = c.z - target.getZ();
            double d = Math.sqrt(dx * dx + dz * dz);
            double down = Math.min(target.getDeltaMovement().y, 0.0) - 0.04;
            if (d < 1.2) {
                target.setDeltaMovement(0, down, 0);
            } else {
                double speed = Math.min(ATLAS_PULL, d * 0.2);
                target.setDeltaMovement(dx / d * speed, down, dz / d * speed);
            }
            target.fallDistance = 0f;
            target.hurtMarked = true;
        }
    }

    private static void slamImpact(ServerPlayer player) {
        WELLS.remove(player.getUUID());
        ShazamNetwork.playAnim(player, ShazamAnim.ATLAS_IMPACT);
        Vec3 center = player.position();
        DamageSource source = ShazamPowers.forceSource(player);
        for (LivingEntity target : enemies(player, center, SLAM_OUTER_RADIUS)) {
            Vec3 push = away(center, target);
            if (target.distanceToSqr(center) <= SLAM_RADIUS * SLAM_RADIUS) {
                target.hurt(source, SLAM_DAMAGE);
                target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, SLAM_PIN_TICKS, 3), player);
                target.setDeltaMovement(push.x * 0.15, -0.8, push.z * 0.15);   // tertekan beban langit
            } else {
                target.hurt(source, SLAM_OUTER_DAMAGE);
                target.push(push.x * SLAM_OUTER_KNOCKBACK, 0.45, push.z * SLAM_OUTER_KNOCKBACK);
            }
            target.hurtMarked = true;
        }
        sound(player, center, SoundEvents.MACE_SMASH_GROUND_HEAVY, 1.8f, 0.6f);
        sound(player, center, SoundEvents.ANVIL_LAND, 0.9f, 0.4f);
        sound(player, center, SoundEvents.LIGHTNING_BOLT_IMPACT, 1.0f, 0.5f);
    }

    // ------------------------------------------------------- Z - Petir Berantai Zeus

    private static boolean zeus(ServerPlayer player) {
        LivingEntity aimed = aimedEntity(player, ZEUS_RANGE);
        if (aimed == null) {
            aimed = coneTarget(player, ZEUS_RANGE, 0.9);
        }
        if (aimed == null || !(aimed instanceof Enemy)) {
            // tanpa musuh (atau yang dibidik bukan musuh): satu sambaran ke titik itu, yang cuma melukai monster
            Vec3 point;
            if (aimed != null) {
                point = aimed.position();
            } else {
                BlockHitResult block = clipBlocks(player, ZEUS_RANGE);
                if (block.getType() == HitResult.Type.MISS) {
                    return false;
                }
                point = block.getLocation();
            }
            ShazamNetwork.playAnim(player, ShazamAnim.ZEUS_CALL, point);
            later(player, ShazamAnim.CAST_WINDUP, p -> {
                ShazamNetwork.playAnim(p, ShazamAnim.ZEUS_CHAIN_START, point);
                ShazamPowers.strikeLightning(p, point, ZEUS_DAMAGE, ZEUS_RADIUS, 1.4f);
            });
            return true;
        }
        // rantai: dari sasaran pertama, petir melompat ke musuh terdekat yang belum tersambar
        List<LivingEntity> chain = new ArrayList<>();
        chain.add(aimed);
        LivingEntity last = aimed;
        for (int i = 0; i < ZEUS_JUMPS; i++) {
            double range = ZEUS_JUMP_RANGE * (last.isInWaterOrRain() ? ZEUS_WET_RANGE : 1.0);
            LivingEntity next = null;
            double best = range * range;
            for (LivingEntity m : enemies(player, last.position(), range)) {
                double d = m.distanceToSqr(last);
                if (!chain.contains(m) && d < best) {
                    best = d;
                    next = m;
                }
            }
            if (next == null) {
                break;
            }
            chain.add(next);
            last = next;
        }
        LivingEntity primary = aimed;
        ShazamNetwork.playAnim(player, ShazamAnim.ZEUS_CALL, chest(primary));
        for (int i = 0; i < chain.size(); i++) {
            LivingEntity target = chain.get(i);
            int index = i;
            // petir dari ujung jari dan guntur dari langit menyambar BERBARENGAN di tiap sasaran
            float damage = ZEUS_DAMAGE * Math.max(0.25f, 1f - ZEUS_FALLOFF * i) + (i == 0 ? ZEUS_SKY_DAMAGE : ZEUS_SKY_HOP_DAMAGE);
            later(player, ShazamAnim.CAST_WINDUP + i * ShazamAnim.ZEUS_HOP, p -> {
                if (!target.isAlive()) {
                    return;
                }
                Vec3 at = chest(target);
                ShazamNetwork.playAnim(p, index == 0 ? ShazamAnim.ZEUS_CHAIN_START : ShazamAnim.ZEUS_CHAIN, at);
                ShazamPowers.strikeLightning(p, target.position(), 0f, 0.0, index == 0 ? 1.6f : 1.05f);   // guntur dari langit
                float wet = target.isInWaterOrRain() ? ZEUS_WET_MULTIPLIER : 1f;
                target.hurt(ShazamPowers.lightningSource(p), damage * wet);
                if (index == 0) {   // guntur di sasaran pertama ikut menyambar musuh di sekitarnya
                    for (LivingEntity near : enemies(p, target.position(), ZEUS_RADIUS)) {
                        if (!chain.contains(near)) {
                            near.hurt(ShazamPowers.lightningSource(p), ZEUS_SKY_DAMAGE);
                        }
                    }
                }
                sound(p, at, SoundEvents.LIGHTNING_BOLT_IMPACT, 1.0f, 1.3f + index * 0.08f);
            });
        }
        return true;
    }

    // ------------------------------------------------- A - Perisai Achilles

    private static boolean achilles(ServerPlayer player) {
        ShazamNetwork.playAnim(player, ShazamAnim.ACHILLES_ROAR);
        later(player, ShazamAnim.ROAR_WINDUP, ShazamSkills::roar);
        return true;
    }

    private static void roar(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        ACHILLES_UNTIL.put(player.getUUID(), level.getGameTime() + ShazamAnim.ACHILLES_TICKS);
        COURAGE.put(player.getUUID(), 0f);
        Vec3 center = player.position();
        for (LivingEntity target : enemies(player, center, TAUNT_RADIUS)) {
            if (target.distanceToSqr(center) <= ROAR_RADIUS * ROAR_RADIUS) {
                Vec3 push = away(center, target);
                target.push(push.x * 1.4, 0.3, push.z * 1.4);
                target.hurtMarked = true;
                target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 120, 1), player); // musuh kehilangan nyali
            }
            if (target instanceof Mob mob) {
                mob.setTarget(player);   // tantangan Achilles: semua menyerang Shazam, bukan sekutunya
            }
        }
        level.playSound(null, center.x, center.y, center.z, SoundEvents.RAVAGER_ROAR, SoundSource.PLAYERS, 1.2f, 1.3f);
        level.playSound(null, center.x, center.y, center.z, SoundEvents.TOTEM_USE, SoundSource.PLAYERS, 0.8f, 1.2f);
    }

    /** Damage yang ditahan Perisai Achilles (dipanggil ShazamPowers saat damage masuk). */
    public static void storeCourage(ServerPlayer player, float blocked) {
        if (blocked > 0f && COURAGE.containsKey(player.getUUID())) {
            COURAGE.merge(player.getUUID(), blocked, Float::sum);
        }
    }

    /** Perisai habis: semua damage yang ditahannya meledak keluar. */
    private static void courageNova(ServerPlayer player) {
        Float stored = COURAGE.remove(player.getUUID());
        float damage = Mth.clamp(NOVA_MIN + (stored == null ? 0f : stored) * NOVA_GAIN, NOVA_MIN, NOVA_MAX);
        ShazamNetwork.playAnim(player, ShazamAnim.ACHILLES_NOVA);
        later(player, ShazamAnim.NOVA_WINDUP, p -> {
            Vec3 c = p.position();
            DamageSource source = ShazamPowers.forceSource(p);
            for (LivingEntity target : enemies(p, c, NOVA_RADIUS)) {
                target.hurt(source, damage);
                Vec3 push = away(c, target);
                target.push(push.x * NOVA_KNOCKBACK, 0.5, push.z * NOVA_KNOCKBACK);
                target.hurtMarked = true;
            }
            sound(p, c, SoundEvents.TOTEM_USE, 1.0f, 0.8f);
            sound(p, c, SoundEvents.WARDEN_SONIC_BOOM, 0.8f, 1.2f);
        });
    }

    // ---------------------------------------------------- Badai Para Dewa (R)

    private static boolean zeusRage(ServerPlayer player) {
        ShazamNetwork.playAnim(player, ShazamAnim.ZEUS_RAGE);
        sound(player, player.position(), SoundEvents.CONDUIT_ACTIVATE, 1.4f, 0.7f);
        later(player, ShazamAnim.RAGE_WINDUP, ShazamSkills::ignite);
        return true;
    }

    /** Para dewa turun: mata putih, enam petir di enam penjuru, musuh dekat terhantam. */
    private static void ignite(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        RAGE_UNTIL.put(player.getUUID(), level.getGameTime() + ShazamAnim.RAGE_TICKS);
        RAGE_STEP.put(player.getUUID(), 0);
        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null && !speed.hasModifier(RAGE_SPEED)) {
            speed.addTransientModifier(new AttributeModifier(RAGE_SPEED, RAGE_SPEED_BONUS,
                    AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        }
        Vec3 center = player.position();
        ShazamPowers.strikeLightning(player, center, RAGE_BURST_DAMAGE, RAGE_BURST_RADIUS, 1.6f);
        for (int i = 0; i < 6; i++) {   // enam petir: enam dewa turun mengelilingi
            double angle = Math.PI * 2.0 * i / 6.0 + level.random.nextDouble() * 0.3;
            ShazamPowers.spawnBolt(level, center.add(Math.cos(angle) * 3.8, 0, Math.sin(angle) * 3.8), 0.8f);
        }
        sound(player, center, SoundEvents.WARDEN_ROAR, 0.9f, 1.5f);
        sound(player, center, SoundEvents.BEACON_ACTIVATE, 1.4f, 0.6f);
        ShazamNetwork.broadcastState(player);
    }

    private static void endRage(ServerPlayer player) {
        RAGE_UNTIL.remove(player.getUUID());
        RAGE_STEP.remove(player.getUUID());
        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null) {
            speed.removeModifier(RAGE_SPEED);
        }
    }

    /** Tiap detik dua dewa (bergiliran S-H-A-Z-A-M) menyerang musuh terdekat dengan gayanya sendiri. */
    private static void rageStorm(ServerPlayer player) {
        List<LivingEntity> targets = enemies(player, player.position(), RAGE_STORM_RADIUS);
        if (targets.isEmpty()) {
            return;
        }
        targets.sort(Comparator.comparingDouble(m -> m.distanceToSqr(player)));
        int step = RAGE_STEP.merge(player.getUUID(), 1, Integer::sum) - 1;
        for (int i = 0; i < Math.min(RAGE_STORM_TARGETS, targets.size()); i++) {
            godStrike(player, (step * RAGE_STORM_TARGETS + i) % 6, targets.get(i));
        }
    }

    private static void godStrike(ServerPlayer player, int god, LivingEntity target) {
        ShazamNetwork.playAnim(player, ShazamAnim.godStrike(god), chest(target));
        DamageSource force = ShazamPowers.forceSource(player);
        Vec3 push = away(player.position(), target);
        switch (god) {
            case 0 -> {   // Solomon: segel kebijaksanaan, musuh terbaca
                target.hurt(ShazamPowers.lightningSource(player), 8f);
                expose(target, 200);
                target.addEffect(new MobEffectInstance(MobEffects.GLOWING, 200, 0, false, false));
                sound(player, target.position(), SoundEvents.ENCHANTMENT_TABLE_USE, 1.0f, 1.4f);
            }
            case 1 -> {   // Hercules: hantaman gada
                target.hurt(force, 16f);
                target.push(push.x * 1.8, 0.55, push.z * 1.8);
                sound(player, target.position(), SoundEvents.PLAYER_ATTACK_STRONG, 1.2f, 0.6f);
            }
            case 2 -> {   // Atlas: ditekan beban langit
                target.hurt(force, 14f);
                target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 3), player);
                target.setDeltaMovement(0, -0.7, 0);
                sound(player, target.position(), SoundEvents.MACE_SMASH_GROUND_HEAVY, 1.0f, 0.8f);
            }
            case 3 -> ShazamPowers.strikeLightning(player, target.position(), 14f, 1.4, 1.0f);   // Zeus: petir langit
            case 4 -> {   // Achilles: tusukan tombak
                target.hurt(force, 18f);
                target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 80, 1), player);
                target.push(push.x, 0.3, push.z);
                sound(player, target.position(), SoundEvents.PLAYER_ATTACK_CRIT, 1.2f, 0.8f);
            }
            default -> {   // Mercury: dua sambaran secepat kilat
                target.hurt(force, 9f);
                ShazamPowers.schedule(player, 11, p -> {
                    if (target.isAlive() && ShazamPowers.isTransformed(p)) {
                        target.hurt(ShazamPowers.forceSource(p), 9f);
                    }
                });
                sound(player, target.position(), SoundEvents.PHANTOM_SWOOP, 1.0f, 1.8f);
            }
        }
        target.hurtMarked = true;
    }

    /** Tinju berpetir: kilat di sasaran, lalu merambat ke musuh lain di dekatnya. */
    public static void ragePunch(ServerPlayer player, LivingEntity target) {
        ServerLevel level = player.serverLevel();
        ShazamPowers.spawnBolt(level, target.position(), 0.6f);
        level.playSound(null, target.getX(), target.getY(), target.getZ(), SoundEvents.LIGHTNING_BOLT_IMPACT,
                SoundSource.PLAYERS, 0.8f, 1.6f);
        List<LivingEntity> nearby = level.getEntitiesOfClass(LivingEntity.class, target.getBoundingBox().inflate(RAGE_CHAIN_RADIUS),
                m -> m.isAlive() && m != target && m instanceof Enemy);
        nearby.sort(Comparator.comparingDouble(m -> m.distanceToSqr(target)));
        for (int i = 0; i < Math.min(RAGE_CHAIN_TARGETS, nearby.size()); i++) {
            ShazamPowers.strikeLightning(player, nearby.get(i).position(), RAGE_CHAIN_DAMAGE, 0.8, 0.6f);
        }
    }

    // ------------------------------------------------------- Alat bantu bidik

    static BlockHitResult clipBlocks(ServerPlayer player, double range) {
        Vec3 eye = player.getEyePosition();
        Vec3 end = eye.add(player.getViewVector(1f).scale(range));
        return player.level().clip(new ClipContext(eye, end, ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, player));
    }

    /** Makhluk hidup yang sedang dilihat pemain (nggak tembus blok), atau null. */
    static LivingEntity aimedEntity(ServerPlayer player, double range) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getViewVector(1f);
        BlockHitResult block = clipBlocks(player, range);
        Vec3 end = block.getType() == HitResult.Type.MISS ? eye.add(look.scale(range)) : block.getLocation();
        AABB box = player.getBoundingBox().expandTowards(look.scale(range)).inflate(1.0);
        EntityHitResult hit = ProjectileUtil.getEntityHitResult(player, eye, end, box,
                e -> e instanceof LivingEntity && e.isAlive() && !e.isSpectator() && e.isPickable(),
                eye.distanceToSqr(end));
        return hit != null && hit.getEntity() instanceof LivingEntity living ? living : null;
    }
}
