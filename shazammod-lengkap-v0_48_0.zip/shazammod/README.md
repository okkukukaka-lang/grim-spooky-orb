# Mod Shazam untuk Minecraft 1.21.1 (NeoForge)

Versi 0.48.0. Isinya:
- **Subjek Tiga (Helion-3), Sang Penghancur Abadi (0.48):** bos baru dari Proyek Helion yang beradaptasi terhadap setiap jenis serangan dan bangkit dua kali dengan kekebalan total terhadap yang membunuhnya. Kedatangannya memaksa Lintang & Helion-6 bersekutu di sisimu. Lihat *Yang baru di 0.48*.
- **Duel AI Lintang vs Helion-6 (0.47):** kedua rival sains bisa datang bersamaan dan saling bertarung habis-habisan di dekatmu, sahut-sahutan lewat balon kata komik, dengan semua skill & kelemahan mereka. Kamu cuma saksi (atau ikut campur), dan hadiah yang kalah tertinggal di tanah. Lihat *Yang baru di 0.47*.
- **Rival AI Lintang & Helion-6 (0.46):** kedua juara sains sekarang bisa datang menantangmu sebagai bos, dengan skill, efek, suara, dan kelemahan yang sama dengan versi pemain. Lintang datang siang hari di bawah matahari, Helion-6 di malam hari atau di bawah tanah, dan Helion-6 memanggil Gerhana Buatan begitu terbakar matahari. Lihat *Yang baru di 0.46*.
- **Helion-6 0.45: skill lengkap & gaya komik:** Lahap Radiasi (C), Orbit Cryon (B), Nisan Kristal (N), dan Gerhana Buatan (J) yang benar-benar menutup matahari (kelemahannya hilang, Lintang & Black Adam ikut kehilangan tenaga surya), plus balon kata ejekan, tulisan SFX komik, kotak narasi, impact frame, dan pose melayang bersilang tangan. Lihat *Yang baru di 0.45*.
- **Lintang 0.44: dibuat ulang mengikuti video:** sinar mata sekarang benar-benar kelihatan (kamera bahu selama charge & menembak, berkas putih tebal berpendar jingga, juga di POV), charge dengan cincin persen & mata merah -> putih, blok yang disorot berpijar utuh merah -> kuning lalu meleleh, genangan lahar petak gaya Minecraft yang benar-benar mengalir, Lintas Detik dengan dunia yang memucat abu-abu, jubah emas & matahari bahu 3D yang pekat (nggak tembus pandang). Lihat *Yang baru di 0.44*.
- **Projek Helion-6 (0.43), juara kelima:** kebalikan Lintang. Kekuatannya dari radiasi Batu Cryon (kryptonite-nya mod ini) dan dia lemah di bawah matahari. Kostum tempur dengan jalur radiasi yang menyala, sinar mata Cryon, Hempasan Lesat, Injakan Cryon, Supernova-6, dan Hirup Cryon (M) untuk Lonjakan Cryon. Lihat *Yang baru di 0.43*.
- **Lintang 0.42: sinar mata di-charge, Z & N baru, tanpa kostum:** tahan X untuk charge sinar mata (tanpa jeda, makin lama makin kuat), yang kena langsung terbakar dengan api 3D & lahar; Z jadi *Lintas Detik* (dunia berhenti, semua musuh disambar sekaligus), N jadi *Nyala Mentari* (matahari mini yang menyedot & membakar, bisa ditinju jadi komet); kostum dicopot, tinggal lambang matahari menyala, jubah cahaya, dan sinar di kedua bahu. Lihat *Yang baru di 0.42*.
- **Lintang 0.41: juara terkuat:** tinju, darah, ketahanan, pemulihan, dan kecepatan dasarnya jauh di atas Shazam, Black Adam, dan Sabbac; semua skill-nya jauh lebih sakit, lebih luas, lebih murah, dan jedanya lebih singkat. Lihat *Yang baru di 0.41*.
- **Lintang 0.40: semua skill berbasis hukum fisika:** massa, momentum, energi kinetik, gelombang tekanan yang merambat, panas yang menumpuk & melelehkan bahan, dingin yang membekukan, dan tenaga matahari yang ikut ketinggian matahari. Sinar mata keluar tepat dari mata (juga di POV), menembus kaca, diserap air. Lihat *Yang baru di 0.40*.
- **Lintang 0.39: sinar mata ditulis ulang, kostum 3D, bug mendarat diperbaiki:** sinar mata yang tebal & menyala keluar dari mata yang benar-benar digambar (juga saat terbang) dan nggak tersendat lagi, kostum dengan sabuk, gesper, kerah, manset sarung tangan, sepatu bot, dan pelindung lutut yang benar-benar timbul, efek mendarat gaya pahlawan yang dulu nggak muncul di layar sendiri, ciri khas keemasan untuk skill tenaga surya, dan suara baru. Lihat *Yang baru di 0.39*.
- **Lintang dirombak gaya film (0.38):** kostum baru buatan sendiri (biru minyak tua, panel grafit berbentuk V, list perak, sabuk bergesper cakram matahari, sarung tangan & sepatu bot), lambang medali timbul berundak, jubah tebal, gerak baru (berdiri, melayang, lepas landas, mendarat gaya pahlawan, Tinju Baja), dan semua efek skill dibuat ulang lebih sinematik: kilatan benturan, gelombang kejut tebal, kawah & batu terlempar, sinar mata yang tebal menyala, kerucut uap sonic boom. Tetap tanpa unsur magis. Lihat *Yang baru di 0.38*.
- **Tiga kekuatan Superman klasik versi Lintang (0.37):** Napas Topan (Shift + C) yang menerbangkan musuh & membalikkan anak panah, Kombo Langit (Shift + Z: uppercut, susul ke udara, banting ke tanah, sorot sinar panas), dan Ledakan Surya (Shift + R): 3 detik mengumpulkan panas lalu meledak seperti bom. Semuanya dibuat sendiri, tetap tanpa unsur magis. Lihat *Yang baru di 0.37*.
- **Lintang makin mirip DLC Superman (0.36):** dengan DLC "Superman" (Oreville Studios, Minecraft Marketplace) sebagai referensi: sinar panas yang membakar & melelehkan penghalang, napas beku yang membuat musuh jadi patung es (lalu dipecahkan dengan pukulan), Angkat & Lempar (Shift + X), anjing super berjubah merah yang ikut terbang, dan warga desa yang berterima kasih saat diselamatkan. Lihat *Yang baru di 0.36*.
- **Lintang ala Superman, tanpa unsur magis sama sekali (0.35):** ganti kostum secepat kilat (kemeja dirobek, berputar, kostum & jubah terpasang dengan ledakan udara), jubah merah tunggal di bahu tanpa hood/mantel/hiasan emas, pasif baru (Regenerasi Surya, Tinju Baja, Refleks Kilat, pendengaran super, sinar panas mata), dan semua efek & suaranya fisik: gelombang udara, debu, puing, uap, panas, es. Nggak ada lagi tiang cahaya, sinar dewa, korona, butiran berkilau, paduan suara, atau lonceng. Lihat *Yang baru di 0.35*.
- **VFX HD Lintang & Sabbac + animasi halus (0.34):** semua efek Lintang & Sabbac digambar ulang dalam mode HD (pendar & berkas cahaya yang lebih halus dan bulat, gelombang tekanan yang siluetnya bulat sempurna), ditambah butiran baru (lidah api, kristal, gores cahaya, abu) dan efek besar baru di tiap skill: supernova, korona & plasma matahari, tornado api, segel neraka, es merambat, perisai heksagon. Gerak Lintang & Sabbac dihaluskan tiap frame. Lihat *Yang baru di 0.34*.
- **Lintang, hero sains (0.32, dirombak di 0.33, jadi ala Superman di 0.35):** juara keempat yang kekuatannya murni sains, tanpa unsur magis. Manusia biasa yang menyuntikkan Serum Helion-7 di bawah sinar matahari langsung (Eksperimen Evolusi Surya) sampai sel tubuhnya bermutasi jadi Sel Surya: baterai matahari hidup. Diaktifkan lewat tombol Transformasi (Mode Surya), bukan kata ajaib. Lemah di Nether (tanpa matahari) dan di dekat Batu Cryon yang banyak di sana, lengkap dengan animasi melemah & perubahan fisik HD. Lihat *Yang baru di 0.33*.
- **Restu Para Dewa, scaling Shazam (0.31):** seperti di komik dan film, Black Adam unggul di kekuatan mentah tapi ujung-ujungnya Shazam yang lebih kuat. Angka dasar Shazam tetap di bawah Black Adam, tapi tiap 2 detik bertarung darah, damage yang diterima, dan tinjunya naik sampai melampaui Black Adam (darah 400, damage diterima 30%, tinju 50). Lihat *Yang baru di 0.31*.
- **Sabbac, juara enam iblis (0.30):** juara ketiga dari film Black Adam. Kekuatannya dari api neraka enam iblis S-A-B-B-A-C (Satan, Aym, Belial, Beelzebub, Asmodeus, Crateis), didapat lewat Mahkota Sabbac yang ditempa dari bijih Eternium di Nether. Pasif tiap 2 detiknya paling kuat di malam hari & di Nether (tempat Shazam dan Black Adam lemah) dan padam di bawah matahari & di dalam air. Tanduk & sayap api, rantai neraka, napas api, dan pasukan iblis. Lihat *Yang baru di 0.30*.
- **Rival Juara (0.30):** Shazam, Black Adam, atau Sabbac versi AI datang menantangmu sebagai bos di tempat & waktu sumber kekuatannya (Black Adam di gurun siang hari, Shazam saat badai, Sabbac di malam hari atau di Nether), berubah wujud seperti pemain, dan bertarung dengan skill yang sama persis. Lihat *Yang baru di 0.30*.
- **Pasif tiap 2 detik punya batas (0.29):** Cakram Aton Black Adam padam saat malam (dan di Nether/End), petir Shazam padam di gurun, es & salju, dan Nether. Padam dan menyalanya ada animasinya. Lihat *Yang baru di 0.29*.
- **Black Adam setara Shazam (0.28), kekuatan dari matahari Aton (0.28.1):** Black Adam dapat padanan semua pasif kuat Shazam dengan angka yang sama, tapi bersumber dari matahari: Cakram Aton tiap 2 detik, Tinju Aton yang membakar, dan Tangkisan Kahndaq. Lihat *Yang baru di 0.28*.
- **SFX baru dirombak total (0.27.1):** suara petir tiap 2 detik, Kekuatan Keluarga, dan Tangan Kahndaq dibuat ulang dari model fisika guntur dan percikan listrik sungguhan. Lihat *Yang baru di 0.27.1*.
- **Tangan Kahndaq (0.27, Black Adam, tombol J):** seperti di film Black Adam, panah dan bola api berhenti di udara di sekelilingnya, lalu dilempar balik ke penembaknya dengan petir. Lihat *Yang baru di 0.27*.
- **Kekuatan Keluarga (0.26, tombol J):** seperti klimaks film Shazam!, petir menyambar seluruh keluargamu bersamaan dan mereka jadi juara kecil selama 30 detik. Lihat *Yang baru di 0.26*.
- **Petir & dash dipertebal (0.25.1):** petir Penangkal Petir Hidup dan dash Refleks Mercury dibuat jauh lebih tebal dan menyilaukan seperti di film. Lihat *Yang baru di 0.25.1*.
- **Petir menyambar Shazam tiap 2 detik (0.25):** pasif Penangkal Petir Hidup dirombak: tiap sambaran memulihkan energi, darah, dan armor, lalu pukulan berikutnya jadi Pukulan Guntur. Animasi & SFX ala film. Refleks Mercury dipercepat jadi tiap 1,8 detik. Lihat *Yang baru di 0.25*.
- **SFX khas tiap skill (0.24.2):** tiap skill Shazam dan Black Adam punya suara sendiri yang dikunci ke frame animasi: ancang-ancang yang memuncak tepat di tick hantaman, lalu hantaman khas skill itu. Lihat *Yang baru di 0.24.2*.
- **SFX sinematik ala film (0.24.1):** 33 suara baru buatan sendiri (72 file .ogg) menggantikan suara bawaan Minecraft untuk semua kekuatan: guntur bergemuruh panjang, petir yang berderak, hantaman dengan sub-bass, braam ala trailer, riser sebelum transformasi, paduan suara ilahi, desing, dan banyak lagi. Lihat *Yang baru di 0.24.1*.
- **VFX sinematik ala film (0.24):** tiap skill disusun jadi ancang-ancang, hantaman, dan sisa yang dikunci ke frame animasi; suar lensa anamorfik, berkas cahaya dari langit, tombak petir Zeus, pita film, dan kartu judul. Lihat *Yang baru di 0.24*.
- **Shazam juara para dewa (0.23):** tiap skill memanggil dewanya sebagai raksasa cahaya yang ikut bertarung (Avatar Dewa), lima pasif baru yang cuma dimiliki Shazam, dan skill yang dirombak supaya punya mekanik sendiri, beda total dari Black Adam. Lihat *Yang baru di 0.23*.
- Dua juara yang beda total: **Shazam** (enam dewa Yunani & Ibrani) dan **Black Adam** (juara Kahndaq, enam dewa Mesir). Jalan mendapatkannya beda (enam totem penjaga vs Skarabe Teth-Adam & Ujian Kahndaq di gurun), badan & kekuatannya beda, dan efek skill Black Adam bergaya film. Punya dua-duanya? Tombol K buat ganti.
- Transformasi SHAZAM beranimasi: enam dewa datang satu per satu dengan cara masuk masing-masing, enam kekuatan S-H-A-Z-A-M, dan Energi Petir.
- Enam skill (plus Zeus Rage) yang masing-masing punya gerakan sendiri (ancang-ancang, gemetar mengumpulkan tenaga, gerakan utama yang menghentak) dan efek visual buatan sendiri yang tebal, bukan partikel Minecraft.
- Terbang berbasis momentum dengan fisika dunia nyata (hambatan udara, belokan menikung, gravitasi saat menukik) ala Create: Lanterns: sonic boom, barrel roll, hero landing, dan kamera menikung.
- Kekuatan seperti di komik: darah 300, armor penuh, tahan banting, pukulan 40 (naik sampai darah 400 & pukulan 50 selama bertarung lewat Restu Para Dewa), darah langsung penuh tiap berubah wujud, dan Energi Petir 1000. Serangan mematikan nggak langsung membunuh: kamu terlempar balik jadi manusia.
- Jubah 3D dengan fisika kain dunia nyata yang utuh jadi satu pakaian: hood yang pas dengan kepala kotak Minecraft, mantel bahu dengan pelat emas, bros pengait dan rantai, dan jubah panjang. Plus lambang 3D yang berkilau saat berubah (skin tetap skin aslimu), dan kostum armor 4 bagian yang bisa di-craft.

## Yang baru di 0.48: Subjek Tiga (Helion-3), Sang Penghancur Abadi

Bos baru dari arsip Proyek Helion (rancangan orisinal). Helion-3 adalah prototipe awal yang paling nggak stabil: selnya berulang kali dihancurkan lalu dipaksa tumbuh lagi dengan radiasi Cryon dan sengatan cahaya buatan, sampai jadi monster biologis yang nggak mengenal rasa sakit. Dia nggak peduli kekuasaan Helion-6 atau niat Lintang melindungi manusia. Dia cuma menghancurkan apa pun yang bergerak, termasuk kamu yang membawa serum baru.

**Tampilan:** raksasa (1,45x) yang membungkuk, kulit hangus merah-arang penuh bekas jahitan operasi, retakan menyala dua warna (kanan putih-emas bekas cahaya, kiri hijau bekas Cryon), mata kanan putih & kiri hijau, pelat sel mati yang mengapur, duri tulang 3D di punggung, bahu, lengan, tengkorak, & betis (menghijau saat menyerap Cryon), sisa tali pengekang lab, dan kalung besi patah bertanda III. Asap & percikan dua warna terus bocor dari retakannya, dan langkahnya menggetarkan tanah.

**Adaptasi mutlak:**
- Serangan dibagi 7 jenis: ☀ Cahaya (Lintang, api), ☢ Cryon (Helion-6), ⚡ Petir & Sihir (Shazam, Black Adam, Sabbac, sihir), ❄ Dingin, ✊ Fisik, ➶ Proyektil, ✸ Ledakan.
- Tiap kali kena jenis yang sama, tubuhnya makin kebal terhadapnya (+6% per pukulan, paling kebal 60% selama satu nyawa). Kilat adaptasinya muncul dengan warna jenis itu, dan kamu diberi tahu supaya ganti cara menyerang.
- Pelat sel matinya menahan fisik & proyektil (x0,5) dan ledakan (x0,7). Penyerang jarak dekat tertusuk duri.

**Tiga nyawa, bangkit lagi:**
- Setiap kali "dibunuh", dia tumbang, tubuhnya tertutup kepompong sel mati yang berdetak seperti jantung, lalu bangkit dengan darah penuh (900 per nyawa), lebih kuat (+15%), dan **kebal total** terhadap jenis serangan yang membunuhnya. Bos bar menampilkan sisa nyawa dan semua kekebalannya.
- Kalau yang membunuhnya Cryon, radiasi Cryon malah **diserap**: dia pulih, dan cakar & tulangnya menguat (sampai +64%).
- Jadi tiap nyawa harus dihabisi dengan cara yang berbeda.

**Gaya bertarung (brutal, tanpa taktik rumit):**
- Raungan: yang dekat terlempar & pusing, proyektil hancur.
- Lompatan lalu hantaman dari udara.
- Serudukan yang menabrak apa saja. Kalau menabrak tembok, dia terhuyung.
- Kombo dua pukulan lalu kedua kepalan menghantam tanah. Pukulannya menembus dan mematahkan perisai.

**Musuh bebuyutan bersekutu:** 3,5 detik sesudah Subjek Tiga merangkak keluar dari tanah, **Lintang & Helion-6 datang di sisimu** sebagai sekutu, dengan kotak narasi "Untuk pertama kalinya, cahaya dan kegelapan berdiri di sisi yang sama."
- Mereka bertarung dengan semua skill-nya melawan Subjek Tiga, nggak bisa kamu lukai, dan nggak meninggalkan hadiah kalau tumbang.
- Mereka bersahutan lewat balon kata, misalnya Lintang: "Cahayaku nggak mempan lagi! Helion-6, giliranmu!", atau Helion-6: "Dia... menyerap radiasiku?!"
- Mereka berkomentar saat bosnya bangkit lagi, merayakan kemenangan, lalu berpisah kembali jadi musuh.

**Kapan muncul:**
- Malam hari di Overworld, kalau kamu sudah menyentuh Proyek Helion (punya Lintang atau Helion-6, atau membawa salah satu serumnya). Seperlima kedatangan rival saat itu jadi Subjek Tiga, paling sering sekali per jam.
- Tes cepat: `/shazam helion3`.

**Hadiah:** Nether Star, Serum Helion-6, Serum Helion-7, 6 Pecahan Cryon, 6 berlian, dan banyak XP.

**Kode:** baru `helion3/Helion3` (bos: AI, adaptasi, nyawa, bos bar), `helion3/Helion3Events` (damage), `client/render/Helion3Renderer` (model berpose, retakan menyala, duri 3D), `client/fx/Helion3Fx` (semua efek), `tools/textures/helion3_textures.py`, dan 11 SFX baru di `tools/sfx/helion_sfx.py`. Diubah: `ShazamEntities`, `ShazamClient`, `ShazamAnim` (HELION3_*), `RivalChampion` (mode sekutu, `notifyAllies`), `RivalSpawner` (`subjectThree`, `allies`), `ShazamCommands`, `HelionComic` (balon kata sekutu).

## Yang baru di 0.47: Duel AI Lintang vs Helion-6

Rival Lintang dan Rival Helion-6 sekarang bisa **saling bertarung** di dekatmu, AI lawan AI, seperti dua halaman komik yang bertabrakan. Keduanya datang berhadapan, menukik dari langit, saling menyapa lewat balon kata, berubah wujud, lalu bertarung habis-habisan dengan semua skill, pasif, dan kelemahan versi pemainnya:
- Lintang makin kuat di bawah matahari, tapi melemah di dekat radiasi Helion-6.
- Helion-6 terbakar di bawah matahari, jadi dia memanggil **Gerhana Buatan**. Dengan itu matahari Lintang ikut padam.
- Napas Salju bisa membekukan Helion-6. Nisan Kristal bisa mengurung Lintang.
- Pukulan Lintang membakar sel Cryon (x1,4), dan pukulan Helion-6 menembus Lintang (x1,5).

**Kapan terjadi:**
- Saat senja atau fajar di Overworld, di bawah langit terbuka (matahari dan kegelapan bertemu). Separuh kedatangan rival di waktu itu jadi duel.
- Tes cepat: `/shazam duel` (atau `/shazam duel <pemain>`).

**Kamu saksinya:**
- Judul "LINTANG vs HELION-6" muncul di layar, plus kotak narasi komik.
- Dua bos bar tampil, dan mereka saling bersahutan lewat balon kata selama duel (di awal, di tengah, saat menang, saat kalah).
- Mereka nggak menyerangmu, kecuali kamu ikut campur sebagai juara: yang kamu serang bisa membalas sebentar sebelum kembali ke seterunya.
- Yang kalah tumbang dan meninggalkan hadiahnya di tanah (Serum Helion-7, atau Serum Helion-6 + Pecahan Cryon). Pemenangnya mengejek lalu melesat ke langit.
- Kalau nggak ada yang menonton (pemain lebih dari 128 blok), lama-lama mereka bubar.

**Kode:**
- `RivalChampion`: mode duel (`setupDuel`, `setNemesis`), lawan & penyusup, sahut-sahutan `duelLine`, menang/kalah duel.
- `RivalSpawner.duel` & `duelTime`, `RivalKit.isChampion` (rival seteru dihitung juara), perintah `/shazam duel`.
- `ShazamAnim.HELION_DUEL_LINE` dan `HelionComic.duelLine` (balon kata duel & narasi).

## Yang baru di 0.46: Rival AI Lintang & Helion-6

Dua juara sains sekarang punya **Rival Juara** sendiri: versi AI yang datang menantangmu sebagai bos, berubah wujud seperti pemain, dan bertarung dengan skill, animasi, efek, suara, dan **kelemahan** yang sama dengan versi pemainnya. Semua efeknya diputar di pemain boneka rival (`client.RivalPuppets`), jadi kostum, jubah, lambang, mata, balon kata, dan semua VFX skill langsung muncul.

**Kapan datang** (rival juara lain tetap seperti dulu; satu rival per pemain, jeda 20 menit):
- **Rival Lintang:** siang hari di bawah langit terbuka, saat sumber kekuatannya (matahari) bersinar.
- **Rival Helion-6:** malam hari di Overworld, atau di bawah tanah tanpa langit (jauh dari matahari).
- Tes cepat: `/shazam rival lintang` atau `/shazam rival helion` (rival lain: `shazam`, `black_adam`, `sabbac`).

**Datang & berubah tanpa sihir:** kedua rival datang menukik dari langit dan menghantam tanah (kawah, dentum sonik), bukan lewat petir. Lintang ganti kostum secepat kilat dengan ledakan udara, Helion-6 radiasinya meledak keluar sambil mengejek. Saat kalah atau pergi, mereka melesat ke langit dengan dentum sonik.

**Rival Lintang:** pahlawan surya (bos bar biru).
- **Skill:**
  - Lesatan Bintang;
  - Iris Surya: mata di-charge 1-2 detik sambil membidik, lalu sinar panas yang mengikuti sasaran;
  - Napas Salju: lawan yang terlalu lama kena jadi patung es, lalu pecah berkeping kalau ditinju;
  - Tepukan Guruh: lawan terlempar, telinga berdenging, proyektil hancur;
  - Amukan Kilat: rentetan pukulan sambil mengejar;
  - Gelegar Surya, lalu Mode Surya: tinju x1,4, damage diterima x0,8;
  - Ledakan Surya: 3 detik hampir kebal, lalu ledakan raksasa;
  - Serap Surya: pulih banyak di bawah langit.
- **Pasif:** Serapan Cahaya tiap 2 detik, Tinju Fajar, Tepisan Beku (penyerang membeku sesaat).
- **Kekuatannya ikut cahaya:** x1,15 di bawah matahari, x0,85 tanpa langit, x0,7 di Nether.
- **Kelemahan:** dekat radiasi Cryon (Batu Cryon, atau Helion-6 pemain/rival yang sedang berubah wujud) daya tinggal x0,6 dan damage yang diterima naik 60%. Pukulan Helion-6 ke dia x1,5.

**Rival Helion-6:** penjahat radiasi (bos bar hijau), memakai kesembilan senjata Helion-6.
- **Skill:**
  - Hempasan Lesat;
  - Emisi Cryon: kepala & mata terus membidik;
  - Lahap Radiasi: menghisap darah pemain untuk dirinya;
  - Injakan Cryon dengan gempa susulan;
  - Orbit Cryon: kristal menghancurkan proyektilmu lalu memburumu;
  - Nisan Kristal: kamu terkurung kristal 3 detik;
  - Supernova-6 saat darahnya di bawah separuh;
  - Hirup Cryon: Lonjakan Cryon;
  - Gerhana Buatan.
- **Pasif:** Denyut Cryon, Tinju Cryon yang menyambar 3 lawan, Kulit Cryon yang menepis serangan.
- **Kelemahan matahari:** di bawah matahari damage-nya tinggal 60%, damage yang diterima naik 30%, dan Kulit Cryon padam. Begitu terbakar matahari dia hampir pasti memanggil **Gerhana Buatan** untuk mematikan matahari di wilayah itu, atau menghirup Cryon.
- **Musuh bebuyutan Lintang:** pukulannya ke pemain Lintang dihitung radiasi Cryon (x2 & menghisap cahaya), keberadaannya melemahkan Lintang di dekatnya, dan pukulan Lintang ke dia x1,4.
- **Balon kata:** dia mengejek lewat balon kata komik di atas kepalanya.

**Hadiah:**
- Rival Lintang: Serum Helion-7, jalan menuju Lintang.
- Rival Helion-6: Serum Helion-6 + 4 Pecahan Cryon.

**Kode:** baru `rival/RivalKit` (kerangka AI juara sains: pemilih skill berbobot, terjangan, bidikan kepala & mata, sinar, kerucut), `rival/RivalLintang`, `rival/RivalHelion`. Diubah: `RivalMoves` (meneruskan ke kit Lintang/Helion-6), `RivalChampion` (datang, berubah, & pergi tanpa sihir; warna bos bar), `RivalSpawner` (syarat datang & hadiah), `ShazamCommands`, `HelionSkills.radiatesRival`, `LintangSkills` (radiasi rival Helion-6), `HelionFx`/`HelionSkillFx` (sinar & aliran Lahap Radiasi milik rival membidik pemain).

## Yang baru di 0.45: Helion-6 lengkap & gaya komik

Semua tombol Helion-6 sekarang hidup, dan dia dibuat terasa seperti penjahat di halaman buku komik. Skill barunya dirancang khusus supaya **nggak meniru juara lain** (Lintang sudah punya angkat-lempar, tinju beruntun, dan hantaman dari langit): semuanya tentang radiasi & kristal Cryon dan sifat tiran Helion-6.

**Skill baru**

| Tombol | Skill | Isi |
|---|---|---|
| C | **L - Lahap Radiasi** | 2,5 detik menghisap radiasi & nyawa sampai 6 musuh dalam 12 blok: aliran radiasi hijau melengkung dari tiap musuh ke dada Helion-6 dengan denyut terang yang mengalir. Musuh terluka (5 tiap 0,25 dtk x daya), melambat, berpendar, tertarik pelan; Helion-6 pulih 2,5 darah & +6 radiasi per musuh per denyut. 20 energi, jeda 14 dtk |
| B | **O - Orbit Cryon** | enam kristal Cryon 3D (sisi hijau tembus pandang, rusuk menyala) terbentuk & mengorbit dada. Selama mengorbit: proyektil musuh di dekatnya dihancurkan, yang terlalu dekat tersayat. Lalu satu per satu melesat melengkung memburu musuh terdekat yang terlihat (18 x daya, terpapar radiasi). 28 energi, jeda 12 dtk |
| N | **N - Nisan Kristal** | telapak dihantamkan ke tanah, duri kristal Cryon meletus berderet 17 blok ke depan: musuh yang kena (24 x daya) **terkurung kristal** 3 detik (diam, creeper nggak bisa meledak), lalu kurungannya pecah (18 x daya). Ladang kristalnya memancarkan radiasi 6 detik: Helion-6 di dekatnya terisi deras & kebal matahari. 30 energi, jeda 11 dtk |
| J | **Gerhana Buatan** | kepalan diangkat ke matahari, berkas radiasi ke langit, lalu piringan gelap bergeser **menutup matahari sungguhan** (ikut waktu siang) dengan korona hijau pucat & kilau cincin berlian; dunia di sekitarnya menggelap. 45 detik di wilayah 48 blok **nggak ada matahari**: kelemahan Helion-6 hilang (malah terisi +3/detik), sedangkan Lintang kehilangan tenaga surya & Black Adam kehilangan Berkah Aton. 200 energi, jeda 90 dtk |

**Gaya komik** (bisa dimatikan lewat `HelionComic.ENABLED`)
- **Balon kata ejekan** di atas kepala Helion-6, terlihat semua pemain di dekatnya, muncul huruf demi huruf: saat berubah wujud, menyedot radiasi, mengurung, sinar mata, terbakar matahari, radiasi habis, dan lainnya. Momen besar (Supernova, Gerhana, Injakan) memakai **balon teriakan** bergerigi. Semua kalimatnya orisinal, ada di file bahasa (`taunt.shazammod.helion.*`).
- **Tulisan SFX** yang meletup di titik hantaman, dengan huruf bergaris tinta tebal di atas ledakan bergerigi: VRRA-KOOM! (berubah), WHAM!/KRAK! (lesatan), ZZRAAAK! (sinar), THOOOOM! (injakan), KA-BOOOOM! (Supernova), KRA-KOOM! (Tinju Cryon), SNNNRRK! (menghirup Cryon), SHLRRRP!, KRRZZING!, KRRSSHH!, dan lainnya.
- **Kotak narasi kuning** di pojok kanan atas layar sendiri, seperti narasi panel komik: saat pertama berubah wujud, eksperimen berhasil, Supernova, Gerhana, dan saat radiasi habis.
- **Impact frame** di layar sendiri saat hantaman besar: garis aksi tinta memusat ke titik hantaman, titik halftone di tepi layar, dan bingkai panel tebal selama beberapa frame.
- **Pose penjahat:** melayang dengan lengan bersilang angkuh di dada sambil menatap ke bawah.

**SFX baru** (dibuat dari nol): helion_lahap, helion_orbit, helion_shard, helion_nisan, helion_tomb_shatter, helion_eclipse.

**Kode:** baru `client/fx/HelionComic` (lapisan komik di layar) dan `client/fx/HelionSkillFx` (efek 4 skill baru & langit gerhana). Diubah: `HelionSkills`, `ShazamAnim`, `ShazamNetwork`, `ShazamClientState`, `ShazamPowers.isInSun`, `PassiveConditions.underSun`, `LintangPhysics.solarIrradiance` (gerhana), `ShazamPassives`, `HelionFx`, `ShazamClient`, `ShazamHud` (kotak Gerhana), `Clips`, `ShazamPoses`.

## Yang baru di 0.44: Lintang dibuat ulang mengikuti video

**Sinar mata (X) sekarang kelihatan.** Penyebab sinar "nggak tampak": di kamera orang ketiga dari belakang, sinar keluar lurus searah pandangan kamera, jadi cuma terlihat sebagai satu titik yang tertutup kepala sendiri; di POV sinarnya juga lurus ke bidikan. Perbaikannya:
- **Kamera bahu:** selama X ditahan & selama sinar menyala, kamera orang ketiga bergeser halus ke atas bahu kanan (seperti di video), jadi sinar dari kedua mata terlihat utuh sebagai garis panjang dari kepala sampai titik kena. Begitu sinar padam kamera kembali pelan. Nggak masuk dinding. Matikan lewat `LintangShoulderCam.ENABLED`, atur jaraknya di `SIDE`/`UP`/`IN`.
- **POV:** kedua berkas sekarang naik dari bawah layar menuju bidikan (dulu keluar tepat dari mata kamera, jadi cuma titik).
- **Berkas gaya video:** inti PUTIH tebal yang pekat (tetap kelihatan jelas di siang hari), badan jingga muda, pendar persik lebar yang melebar di dekat kepala, rona merah di pangkal mata, dan denyut energi yang mengalir ke sasaran. Titik kena: kilatan putih-kuning besar, bintang panas berduri, garis percikan putih-jingga yang memancar, lelehan menetes memantul, asap, bara yang lepas di sepanjang berkas.
- **Charge:** mata merah membara di awal lalu memutih menyilaukan (juga di lapisan mata model), bara jingga melayang di sekitar kepala & bahu, kilau bintang di mata saat hampir penuh. Meteran di bawah bidikan sekarang **cincin dengan persen** (merah -> jingga -> putih keemasan, "MAKS" berkedip saat penuh).
- Kepala yang agak tembus pandang saat menembak (0.42.1) dibuat lebih samar (`LintangHeadFade.MIN_ALPHA` 0,62), karena sinarnya sudah terlihat dari bahu.

**Blok berpijar & lahar.**
- Blok yang disorot sekarang **berpijar utuh** seperti di video: seluruh kubusnya (tekstur bloknya sendiri) memerah, menjingga, lalu kuning-putih menurut suhunya, dengan retakan pijar yang makin terang (dan mengalir saat hampir meleleh). Panasnya **merambat** ke blok padat di sebelahnya (tiang yang disorot di tengah: tengahnya kuning, atas-bawahnya merah), lalu memudar pelan saat mendingin. Blok yang hampir meleleh meneteskan lahar dari sisinya, berasap, dan melepaskan bara.
- **Genangan lahar baru (petak 1/4 blok, gaya Minecraft):** lahar benar-benar mengalir keluar dari titik leleh mengikuti lantai: nggak menembus dinding, berhenti di tepi jurang, menjulur tak beraturan. Tiap petak berwarna jingga-kuning sendiri dengan arus terang yang merambat, sisi tebalnya kelihatan di tepi, tepinya mendingin duluan jadi kerak gelap dengan retakan pijar, gelembung meletup, asap & bara naik, dan seluruh genangan berpendar ke udara di atasnya. Tetesan dari dinding & gumpalan yang jatuh ikut mengisi genangan.

**Lintas Detik (Z) gaya video.** Begitu waktu berhenti, **dunia memucat jadi abu-abu** (semua yang beku ikut pucat; pemain lain di dekatnya juga melihatnya). Tiap sambaran meninggalkan bayangan Lintang yang bercahaya keemasan, **cincin putih tegas** yang membeku di sekeliling musuh, dan **garis cahaya putih-emas** yang melesat lurus dari musuh ke musuh. Ada jeda sesaat supaya semuanya terlihat (waktu beku 0.44: 5 + 3/musuh + 8 tick), lalu waktu jalan lagi: kilatan putih, warna dunia kembali, semua cincin meledak melebar bersamaan, gelombang kejut, kilatan & debu di tiap musuh, musuh terlempar.

**Kostum Mode Surya 3D & pekat.**
- **Jubah emas pekat** (bukan cahaya tembus pandang lagi): kain emas bergaris cahaya tegak seperti di video, tebal kainnya kelihatan di tepi (±0,9 piksel), sisi dalam jingga keemasan, selalu terang karena terbuat dari sinar matahari (lipatannya tetap berbayang), cahaya keemasan mengalir pelan di permukaannya, tepinya bersinar tipis, dan kelimnya meneteskan sinar pendek.
- **Matahari bahu 3D:** di atas kedua bahu duduk matahari kecil padat: inti bulat putih keemasan dengan 16 duri sinar runcing berbentuk limas (panjang-pendek berselang) yang memancar ke atas & ke samping, berputar pelan & berdenyut, berbayang lembut supaya bentuk 3D-nya jelas, ditambah pendar tipis di sekelilingnya. Menempel di badan, jadi tetap di bahu walau lengan diayun.
- **Lambang matahari** di dada digambar ulang jadi bintang tajam 16 sinar dengan cakram putih panas (seperti di video).

**Serap Surya (M):** selain tiang cahaya di badan, sekarang beberapa tiang sinar matahari lebar menembus di sekeliling Lintang dan butiran cahaya keemasan naik ke badannya (seperti di video).

Tekstur baru dibuat dengan `tools/textures/lintang_sun.py` (jubah emas, retakan pijar, lambang). Semua masih belum dites di game: build lewat GitHub Actions seperti biasa dan hapus jar versi lama dari folder mods.

## Yang baru di 0.43: Projek Helion-6, juara kelima (ronde 1)

Juara kelima, rancangan orisinal (nama, kostum, lambang, dan aturan main). Konsepnya kebalikan Lintang, seperti "Superman dari Bumi terbalik": **kekuatannya dari radiasi Batu Cryon (kryptonite-nya mod ini) dan dia lemah di bawah matahari**. Lore: Helion-6 adalah eksperimen Helion sebelum Serum Helion-7. Serumnya disuntikkan di bawah radiasi Cryon, bukan matahari, jadi sel tubuhnya jadi Sel Cryon yang hidup dari radiasi itu dan terbakar sinar matahari.

**Cara mendapatkannya**
1. Craft **Serum Helion-6**: 6 Pecahan Cryon, mata laba-laba terfermentasi, Nether Star, botol kaca.

       C E C
       C N C
       C B C

2. Klik kanan serumnya dalam wujud manusia, **jauh dari matahari** (malam, di bawah tanah, di dalam ruangan, atau di Nether): **Eksperimen Proyek Helion-6** (7,5 detik). Serum disuntik di leher, urat hijau menjalar ke seluruh tubuh, kejang & berlutut, lalu radiasinya meledak keluar dengan kartu judul "PROJEK HELION-6". Kena matahari di tengah eksperimen = gagal (serum belum terpakai). Tes cepat: `/shazam unlock helion` atau `/shazam helion_rite`.
3. Tombol **G** untuk berubah, **K** untuk ganti juara.

**Berubah wujud (G):** radiasi tersedot ke dada dari segala arah, tanah retak membara hijau, badan menegang & bergetar, mata menyala, lalu radiasinya **meledak** (gelombang kejut, kubah radiasi, kristal Cryon terlempar, kawah, tiang radiasi) dan kostum tempurnya terbentuk dengan jalur radiasi yang menyala. Musuh dalam 7 blok kena 26 damage & terpapar radiasi.

**Tampilan:** kostum tempur hitam kehijauan bertekstur sarang lebah, pelat gunmetal (dada, perut beruas, bahu, gauntlet, pelindung lutut & tulang kering), sabuk bergesper heksagon, jalur radiasi hijau yang menyala (redup & berkedip di bawah matahari, membara saat Lonjakan), lambang reaktor heksagon 3D di dada, jubah hitam arang berjahitan hijau, mata hijau membara, urat Cryon di wajah, dan sikap angkuh dengan lengan bersilang. Kostumnya juga terlihat di tangan orang pertama. Bayangan geraknya hijau radiasi.

**Sumber tenaga: Radiasi Cryon (energi)**

| Tempat | Berwujud Helion-6 | Wujud manusia |
|---|---|---|
| Dekat bijih / pecahan Cryon di dunia | +25/detik (menetralkan matahari) | +30/detik |
| Membawa Cryon di inventori | +6/detik tambahan | +6/detik tambahan |
| Nether | +4/detik | +9/detik |
| Malam / bawah tanah / dalam ruangan | +1,5/detik | +6/detik |
| Siang tapi teduh atau hujan | -0,5/detik | +6/detik |
| **Di bawah matahari** | **-6 sampai -22/detik** (ikut terik) | 0 |

**Kelemahan: matahari** (siang, langit terbuka, nggak hujan): radiasi terbakar, Daya Cryon tinggal 60% (tinju lebih lemah, damage diterima naik), lari -25%, darah nggak pulih, Kulit Cryon & Denyut Cryon padam, kulit berasap & memercikkan bara, layar silau. Radiasi di bawah 150: nggak bisa terbang. Radiasi habis: jatuh berlutut lalu kembali jadi manusia.

**Kekuatan dasar** (radiasi penuh): darah 550, tinju 78 (paling brutal, kritis 117), damage diterima 22%, lari +25%, hempasan +1,4, sihir x1,3.

**Musuh bebuyutan Lintang:** tinju Helion-6 membawa radiasi Cryon (menembus Kulit Baja Lintang, x2, menghisap cahayanya), dan Helion-6 yang sedang berubah wujud membuat Lintang di dekatnya melemah seperti dekat Batu Cryon. Sebaliknya tinju Lintang (tenaga matahari) membakar sel Cryon: x1,4 ke Helion-6.

**Skill (huruf HUD H-E-L-I-O-N-6)**

| Tombol | Skill | Isi |
|---|---|---|
| Z | **H - Hempasan Lesat** | melesat 22 blok (badan digerakkan halus di client), menghantam & melempar semua musuh di jalurnya (34), gelombang radiasi di ujung. Jejak hijau berlistrik, bayangan gerak hijau, kerucut uap. 18 energi, jeda 2,5 dtk |
| X | **E - Emisi Cryon** | 0,5 dtk mata mengumpulkan radiasi, lalu dua sinar Cryon 2,5 detik mengikuti arah pandang: menembus 5 musuh (8 tiap 0,1 dtk x daya), membakar & melemahkan, menyulut permukaan. Sinar berpilin, titik kena memercik & berasap, dengung diulang. 25 energi, jeda 6 dtk |
| C | L | menyusul (ronde 2) |
| V | **I - Injakan Cryon** | melompat lalu berlutut menghantam tanah: gelombang radiasi 13 blok (48 penuh dalam 3,5 blok) melambungkan musuh, proyektil terlempar ke atas, retakan tanah membara hijau, semburan radiasi dari retakan, gempa susulan 19 blok. 30 energi, jeda 8 dtk |
| B | O | menyusul (ronde 2) |
| N | N | menyusul (ronde 2) |
| R | **6 - Supernova-6** | butuh 300 radiasi. 3 detik meringkuk menyerap radiasi (musuh tersedot, damage diterima x0,3, pusaran & korona hijau, retakan menjalar), tarikan terakhir yang hening, lalu SEMUA radiasi di atas 60 diledakkan: jari-jari 14-32 blok, damage 80-210, terbakar 6 dtk, kartu judul, letterbox, awan jamur, zona radiasi 5 detik. Jeda 45 dtk |
| M | **Hirup Cryon** | (butuh Pecahan/Bijih Cryon) pecahan diremukkan di genggaman, uap radiasinya dihirup: +450 radiasi, +150 darah, **Lonjakan Cryon** 12 detik (daya x1,3, damage diterima x0,8, lari +15%, aura radiasi 4/detik dalam 5 blok). Jeda 20 dtk |

**Pasif:** **Denyut Cryon** tiap 2 detik (energi +100, darah +40; x2 dekat Cryon, x1,5 di Nether; padam di bawah matahari), **Tinju Cryon** (Muatan Cryon penuh: x1,75, radiasi meledak & menyambar 3 musuh lain), **Kulit Cryon** (serangan di bawah 10 memantul; mati di bawah matahari). Serangan Helion-6 bisa membuat musuh Lemah & Lambat (radiasi).

**SFX baru** (dibuat dari nol, `tools/sfx/helion_sfx.py`): helion_transform, helion_burst, helion_pulse, geiger, helion_dash, helion_beam_charge/fire/loop, helion_quake, helion_nova, helion_inhale, helion_sun_burn, helion_punch, helion_cryon_punch, helion_rite, helion_power_down. Tekstur: `tools/textures/helion_textures.py`.

**Angka yang bisa diatur:** `ShazamPowers` (awalan `HELION_`) dan bagian atas `HelionSkills`.

**Kode:** baru `HelionSkills`, `HelionRite`, `HelionItems`, `client/fx/HelionFx`, `client/render/HelionLayer`. Diubah: `ShazamForm` (HELION di paling bawah, save lama aman), `ShazamData` (`helion_unlocked`), `ShazamAnim` (HELION_* di paling bawah), `ShazamPowers`, `ShazamPassives`, `ShazamNetwork`, `ShazamSyncPayload`, `ShazamClientState`, `ShazamCommands`, `ShazamMod`, `PassiveConditions`, `LintangSkills`, `ShazamFlightServer`, dan di client `ShazamClient`, `ShazamHud`, `Clips`, `ShazamPoses`, `LintangBody`, `ShazamFx`, `ChampionFx`, `ShazamFlight`, `FormLook`, `ShazamCape`, `ShazamEyesLayer`, `SuitRevealLayer`.

## Yang baru di 0.42: sinar mata di-charge, Lintas Detik, Nyala Mentari, tanpa kostum

**Iris Surya (X) di-charge, tanpa jeda.** Tahan X: mata memanas dari merah membara ke putih menyilaukan (panas & bara tersedot ke mata, sinar mulai bocor, dengungnya naik, meteran di bawah bidikan, tepi layar memerah). Lepas X: sinar ditembakkan. Penuh dalam 3 detik.

| | tanpa charge (tap) | charge penuh |
|---|---|---|
| Lama sinar | 0,8 detik | 4,5 detik |
| Jangkauan | 48 blok | 96 blok |
| Damage tiap 0,1 detik | 6 (sampai ±8 saat sasaran panas) | 16 (sampai ±22) |
| Panas tiap denyut | 120 °C | 300 °C (batu jadi lahar ±0,5 detik) |
| Musuh yang ditembus | 4 | 12 |
| Langsung terbakar | 4 detik | 10 detik |
| Energi | 3 | 15 |

- Tanpa jeda sama sekali: bisa langsung charge lagi, sinar baru menggantikan yang masih menyala. Energi nggak pernah menolak; kalau kurang, dayanya saja yang turun (paling rendah 40%).
- Apa pun yang kena **langsung terbakar**: makhluk menyala seketika (dengan api 3D yang membungkus badannya selama ia terbakar), kayu & daun tersulut, permukaan yang disorot dari atas ikut menyala sebentar.
- Titik kenanya mengikuti gambar rujukan: inti putih panas berduri, garis percikan memancar, permukaan memerah, lelehan berpijar menetes jatuh, asap membubung, dan api 3D yang tetap menyala beberapa detik sesudah sinarnya pindah.
- **Lahar**: makin lama disorot, batu & tanah memerah lalu meleleh: gumpalan lahar terlempar, lahar menetes turun di dinding, dan genangan lahar berpijar (berkerak pelan, gelembungnya pecah). Di dunianya sendiri batu/tanah jadi magma lalu **lahar sungguhan** yang membeku lagi jadi magma (8 detik sesudah nggak disorot) lalu basal. Matikan lewat `LintangPhysics.MELT_TO_LAVA` / `BLOCK_CHANGES`.
- Shift + X (Angkat & Lempar) sekarang punya biaya (20) & jeda sendiri (3 detik).
- 0.42.1: selama sinar mata dipakai (charge & menembak), kepala Lintang jadi agak tembus pandang kalau dilihat dari belakang (kamera orang ketiga dari belakang, atau pemain lain di belakangnya), jadi sinar yang keluar dari mata & titik kenanya tetap kelihatan menembus kepala. Dari depan kepalanya tetap biasa. Seberapa tembus: `LintangHeadFade.MIN_ALPHA` (0,45).

**Lintas Detik (Z), pengganti Lesatan Bintang.** Lintang bergerak begitu cepat sampai dunia seakan berhenti: sampai 8 musuh dalam 20 blok membeku di tempat (proyektil yang sedang terbang ikut berhenti di udara), Lintang menyambar mereka satu per satu (bayangan dirinya yang sedang memukul tertinggal di tiap musuh, jejak cahaya keemasan menyambung jalurnya, cincin kejut membeku di udara), lalu kembali ke tempatnya. Begitu waktu jalan lagi: semua pukulan mendarat bersamaan (40 damage tiap musuh, terlempar searah sambarannya), cincin-cincinnya meledak, dentuman sonik beruntun menyusul. Energi 20, jeda 3,5 detik. Shift + Z tetap Kombo Langit (40 energi).

**Nyala Mentari (N), pengganti Napak Langit.** Kedua tangan menangkup mengumpulkan cahaya jadi bola plasma, didorong ke titik bidik (sampai 24 blok) dan menggantung di sana sebagai matahari mini selama 6 detik:
- panasnya memancar (turun ~1/r²): musuh dalam 10 blok langsung terbakar, tanah di bawahnya meleleh/terbakar, salju & es mencair;
- udara panasnya naik, jadi musuh dalam 14 blok tersedot masuk dari bawah dan terangkat berputar ke dalamnya (pusaran api), lalu terpanggang di dalam;
- proyektil yang mendekat menguap;
- **tekan N lagi**: tinju udara supersonik, mataharinya melesat jadi komet berekor api dan meledak saat menghantam (95 damage, radius 15);
- kalau dibiarkan: berdenyut, runtuh, lalu meledak (70 damage, radius 13).
Energi 30, jeda 10 detik.

**Tanpa kostum.** Kostum 3D dicopot: kulit asli pemain terlihat utuh (termasuk lapisan luarnya, juga tangan orang pertama). Yang tersisa: lambang matahari di dada yang menyala & memercikkan cahaya, jubah dari cahaya keemasan (tetap berkibar seperti kain, cahayanya mengalir ke bawah, sinar memancar dari kelim & tepinya), dan "matahari bahu": kipas sinar keemasan yang berdenyut di kedua bahu.

**Suara baru:** charge mata (nadanya naik mengikuti charge), semburan & dengung sinar (diulang selama sinar menyala), dunia berhenti, dentuman sonik beruntun, matahari mini menyala & bergemuruh.

Catatan: link YouTube rujukan nggak bisa dibuka dari sini, jadi efek sinarnya mengikuti screenshot rujukan.

## Yang baru di 0.41: Lintang juara terkuat

Kekuatan dasar Lintang sekarang di atas tiga juara lain, dan semua skill-nya dibuat jauh lebih kuat. Fisika 0.40 tetap jalan: tinju & lemparan yang lebih kuat berarti impuls & energi yang lebih besar, dan badan Lintang sekarang 600 kg (dulu 400), jadi tumbukan lesatan & hantamannya ikut lebih dahsyat.

**Kekuatan dasar (cahaya penuh), dibanding juara lain**

| | Shazam | Sabbac | Black Adam | **Lintang 0.41** (dulu) |
|---|---|---|---|---|
| Tinju tangan kosong | 40 | 42 | 44 | **72** (48), kritis 108 |
| Darah | 300 | 325 | 350 | **600** (380) |
| Damage yang diterima | 40% | 38% | 35% | **20%** (32%) |
| Pulih per detik | 3 | 2 (5 di gelap) | 2 (6 di matahari) | **5, 10 di matahari** (2 / 4) |
| Kecepatan lari | +40% | +40% | +40% | **+82%** (+61%) |
| Hempasan (knockback) | 2,5 | 3,0 | 3,3 | **3,7** (3,1) |
| Kilatan saat berubah | 12 | 16 | 18 | **24** (16) |

- Kulit Baja: serangan di bawah 12 damage memantul (dulu 7). Saat energi habis pun Lintang masih 85% kuat (dulu 60%) dan paling banyak kena ±24% damage, dan energi penuh dicapai di 350 (dulu 500).
- Pengisian energi lebih cepat: matahari 4/detik (dulu 2), malam berbintang 1/detik (dulu 0,5), wujud manusia 8/detik (dulu 5). Pengurasan di tempat gelap separuhnya: 1/detik, Nether/End 1,5, dekat Batu Kelam 15 (dulu 25).
- Kelemahan tetap ada tapi lebih ringan: sihir x1,4 (dulu x2; sihir tetap menembus Kulit Baja, jadi kena penuh, bukan 20%), tinju juara bersihir x1,2 (dulu x1,5), pukulan Batu Kelam x2 (dulu x3) dan daya dekat Batu Kelam tinggal 70% (dulu 50%).

**Gelombang kejut sekarang punya radius sumber.** Di 0.40 tekanan gelombang turun 1/jarak dari titik 1 blok, jadi Tepukan Guruh, Napak Langit, dan Gelegar Surya cuma sakit di dekat Lintang. Sekarang sumbernya selebar tepukan / kawah / bola apinya: di dalamnya damage & dorongan penuh, baru di luarnya turun 1/jarak (`LintangPhysics.blast/quake` dengan `core`, angkanya `*_CORE` di `LintangSkills`).

**Skill: biaya energi / jeda (dulu)**
- Lesatan Bintang (Z): 15 / 2,5 dtk (25 / 5); jarak 28 blok (18), damage tumbukan dari energi kinetik sampai 90 (40), gelombang di ujungnya 20 (8).
- Iris Surya (X): 20 / 4,5 dtk (30 / 8); jangkauan 64 blok (32), menembus 8 musuh (3), damage 12 per denyut (5), ±17 begitu sasarannya panas; panasnya 260 °C per denyut (170), jadi bahan meleleh jauh lebih cepat.
- Napas Salju (C): 20 / 5 dtk (30 / 9); jangkauan 18 (12), damage 8 per denyut (3), membeku penuh dalam ±3 denyut, makhluk sampai 800 darah (300) bisa jadi patung es, pukulan ke patung es x2,5 (x1,5).
- Napas Topan (Shift + C): jangkauan 20 (14), angin hampir 2x lebih kuat, 3 damage per denyut (1).
- Tepukan Guruh (V): 25 / 6 dtk (35 / 12); jangkauan 22 (14), gelombangnya 80 damage sampai 3 blok lalu turun 1/jarak (10 blok ±24, 20 blok ±12; dulu 10 blok cuma ±4), kaca pecah sampai 14 blok (9), terhuyung 3,5 detik (2).
- Amukan Kilat (B): 20 / 3,5 dtk (30 / 7); jangkauan 10 (6), 18 per pukulan (8), pukulan penutup 50 (18) dengan impuls 380 (230).
- Napak Langit (N): 25 / 7 dtk (40 / 15); radius 10 (7). Di dalam kawah guncangan tanahnya 60 + gelombang udara 30 (dulu 26 + 13 di 1 blok), lalu turun 1/jarak; semuanya dikali skala tinggi jatuh (0,6 sampai 2,2).
- Gelegar Surya (R): 100 / 30 dtk (150 / 60); radius 24 (16), damage 50 + 0,08 per energi yang dibakar (18 + 0,03), gelombang kejutnya penuh di dalam bola api (seperlima radiusnya, ±5 blok), sisa energi 250 (100).
- Ledakan Surya (Shift + R): butuh 250 energi (400), radius 30 (18), damage 90 + 0,15 per energi (30 + 0,06), gelombang kejutnya penuh dalam 4,5 sampai 7 blok (makin banyak energinya makin lebar), jeda 45 detik (2 menit).
- Mode Surya: tinju x2 (x1,5), damage diterima x0,5 (x0,8), +35% lari (20%), sinar panas otomatis 24 damage dalam 22 blok (10 dalam 14).
- Kombo Langit (Shift + Z): 40 energi total (70), jeda 8 dtk (15); jangkauan 24 (16); uppercut 30, banting 36, hantaman 36, sorotan panas 12 (dulu 12 / 14 / 14 / 5); bisa ke musuh sampai 1000 darah (300).
- Angkat & Lempar (Shift + X): mengangkat makhluk sampai 1500 darah (300), Warden pun terangkat, dari 8 blok (5,5); energi lemparan 400 kJ (180), hempasan di titik jatuhnya ±58 sampai 2 blok.
- Tinju Baja: impuls 420 (260), gelombang kejutnya 30 damage dalam 10 blok (14 dalam 7).
- Serap Surya (M): jeda 15 dtk (25); +500 energi & pulih 300 darah di bawah langit (300 & 120), di tempat gelap +220 & 120 (120 & 40); gelombang panasnya 36 damage dalam 9 blok (16 dalam 6).
- Selamatkan (J): 40 energi / 20 dtk (80 / 45), memulihkan 60 darah tiap teman (20).

Semua angka ini ada di `ShazamPowers` (awalan `LINTANG_`) dan bagian atas `LintangSkills`. Kalau terlalu kuat, tinggal diturunkan lagi.

## Yang baru di 0.40: semua skill Lintang berbasis hukum fisika

Semua skill sekarang dihitung pakai fisika sederhana (`LintangPhysics`, 1 blok = 1 meter, 1 tick = 1/20 detik), dan efek di layar mengikuti hasil hitungannya. Desain & gayanya tetap punya Lintang sendiri.

**Dasar fisikanya**
- **Massa & momentum:** massa makhluk dihitung dari volume kotak tabrakannya (zombie ±84 kg, golem besi ±640 kg, ayam ±13 kg). Pukulan, angin, dan gelombang memberi *impuls*, jadi perubahan kecepatannya = impuls / massa: makhluk ringan terlempar jauh, yang berat cuma bergeser. Ketahanan dorong vanila tetap dihitung.
- **Energi kinetik:** makhluk yang terlempar dilacak. Begitu menabrak dinding, tanah, atau makhluk lain, damage-nya dari ½·m·v² (makin kencang makin sakit). Momentumnya pindah ke makhluk yang ditabrak (bisa beruntun seperti bola boling), dan kaca di titik tabrak pecah kalau energinya cukup.
- **Gelombang tekanan:** tepukan, ledakan, dan hantaman tanah membuat gelombang yang merambat, bukan kena serentak. Makin jauh makin telat sampai dan makin lemah (~1/r). Kaca dalam jangkauan pecah, api padam, proyektil berbelok, barang terhempas. Kecepatannya 3,4 blok/tick, yaitu kecepatan suara (343 m/s) diperlambat 5x supaya rambatannya kelihatan seperti adegan slow-motion di film.
- **Panas:** suhu blok yang disorot sinar mata naik terus (dan mendingin pelan menurut hukum pendinginan Newton). Begitu melewati titik leleh/nyalanya, bahannya berubah.
- **Dingin:** napas beku menyedot panas: air membeku, lava memadat, api padam, magma mendingin, uap air mengendap jadi salju.
- **Tenaga matahari:** pengisian di bawah matahari sebanding sinus ketinggian matahari (tengah hari penuh, pagi/sore lebih sedikit; hukum cosinus Lambert), berkurang saat hujan (55%) dan badai (30%), nol di Nether/End, malam, atau tanpa langit.

**Tiap skill**
- **Iris Surya (X), sinar mata:** keluar tepat dari kedua mata dan lurus ke arah pandangan (di POV juga, menyatu di titik bidik). Menembus kaca bening (melemah sedikit tiap lapis), berhenti di air (airnya mendidih). Panas menumpuk di titik yang disorot: es/salju mencair & menguap, air mendidih habis jadi uap, pasir jadi kaca, pasir merah jadi kaca jingga, batu memerah lalu jadi magma, benda mudah terbakar menyala, TNT tersulut. Titik kena berpijar sesuai suhunya: merah, jingga, kuning, lalu putih, dan tetap berpijar sesudahnya sampai dingin. Musuh menumpuk panas: damage naik makin lama disorot, lalu terbakar. Yang tahan api cuma menyerap 40%, yang di air/hujan cuma 35% (keluar uap).
- **Lesatan Bintang (Z):** musuh yang ditabrak kena tumbukan lenting dengan badan Lintang yang super padat. Yang ringan terpental hampir 2x kecepatan Lintang, yang berat cuma tergeser, yang tertabrak menyerong terbelok ke samping. Damage dari energi tumbukannya. Saat berhenti, udara yang terbawa terus melaju jadi gelombang tekanan ke depan.
- **Napas Salju (C):** musuh membeku sesuai suhunya (jadi patung es kalau beku penuh). Di ujung hembusan air jadi es, lava jadi obsidian (aliran lava jadi batu) dengan uap mendesis, api padam, magma jadi netherrack, dan tanah tertutup salju tipis.
- **Napas Topan (Shift + C):** gaya angin turun ~1/r² dari mulut. Percepatan = gaya/massa, jadi ayam terbang jauh, zombie terdorong, golem besi nyaris diam.
- **Tepukan Guruh (V):** gelombang tekanan merambat ke depan dalam kerucut. Jendela kaca sampai 9 blok pecah, proyektil berbelok, api padam, musuh ringan terlempar jauh. Yang dekat sumbernya juga terhuyung.
- **Amukan Kilat (B):** tiap pukulan menambah momentum, jadi sasaran terdorong mundur sedikit demi sedikit dan Lintang ikut maju mengejar. Pukulan penutup berupa impuls besar: sasaran ringan melayang dan menabrak apa saja di belakangnya.
- **Napak Langit (N):** energi hantaman dihitung dari tinggi jatuh (v = kecepatan menukik + √(2gh), E = ½mv²). Ukuran kawah & jangkauan ~ akar pangkat tiga energinya: makin tinggi lompatannya, makin besar kawahnya (di layar juga). Gelombang seismik merambat di tanah dan cuma melontarkan yang sedang berpijak; yang melayang selamat.
- **Gelegar Surya (R) & Ledakan Surya (Shift + R):** jangkauan ~ akar pangkat tiga energi yang dibakar (hukum skala ledakan). Kilat panasnya secepat cahaya dan cuma mengenai yang punya garis pandang ke Lintang (berlindung di balik dinding = selamat dari panasnya), membakar & menyilaukan dengan kekuatan ~1/r². Sesudahnya gelombang kejut menyusul dengan kecepatan suara dan memecahkan kaca.
- **Serap Surya (M):** energi yang terserap sebanding sinar matahari yang sampai: siang terik penuh, fajar atau hujan lebih sedikit.
- **Tinju Baja (pasif) & Angkat & Lempar (Shift + X):** pukulannya berupa impuls, jadi makhluk ringan melayang jauh dan menabrak. Lemparan punya energi tetap, jadi kecepatannya √(2E/m): makhluk ringan melesat, yang berat lebih pelan; damage benturannya dari energi kinetik.

**Angka yang bisa diatur**
- `LintangPhysics`: `BLOCK_CHANGES` (true; false = blok nggak pernah diubah), `MELT_TO_LAVA` (false; true = magma yang terus disorot jadi lava), `DENSITY` (120 kg/blok³), `LINTANG_MASS` (400 kg), `MAX_SPEED` (3,6 blok/tick), `WAVE_SPEED` (3,4), `SEISMIC_SPEED` (2,2), `JOULE_PER_DAMAGE` (2500), `GLASS_BREAK_JOULE` (3000), `COOLING` (0,025), `IGNITE_TEMP` (300 °C).
- `LintangSkills`: `IRIS_HEAT_PER_PULSE` (170 °C tiap 4 tick), `LESAT_SPEED` (2,0), `CLAP_IMPULSE` (150), `CLAP_GLASS_RANGE` (9), `BARRAGE_HIT_IMPULSE` (22), `BARRAGE_FINAL_IMPULSE` (230), `NAPAK_REF_JOULE` (1,4 juta), `DAWN_IMPULSE` (260), `THROW_JOULE` (180 ribu), `GALE_IMPULSE` (34).
- Titik leleh/nyala ada di `LintangPhysics.react` (es 60 °C, salju 35, air mendidih habis 420, pasir 900, batu 1100, nyala 300, TNT 200).
- Blok di daerah spawn yang dilindungi, blok berisi (peti dsb.), obsidian, dan bedrock nggak pernah diubah. Mode petualang juga nggak bisa mengubah blok.

**Kode**
- Baru: `LintangPhysics` (server: massa, impuls, tumbukan, gelombang, panas, dingin, matahari), animasi penanda `LINTANG_STEAM`, `LINTANG_MELT`, `LINTANG_SHATTER`.
- Diubah: `LintangSkills` (semua skill memakai fisika), `LintangHeat` (sinar dari mata di POV, tembus kaca, pijar sesuai suhu), `LintangFx` (uap, leleh, kaca pecah, kawah sesuai tinggi jatuh).

## Yang baru di 0.39: sinar mata baru, kostum 3D, bug mendarat diperbaiki

Tetap desain & gaya Lintang sendiri (bukan karakter DC); acuannya gaya sinematik dan jenis kekuatan ala pahlawan super (sinar panas, napas beku, terbang, tenaga matahari).

**Bug yang diperbaiki**
- **Mendarat gaya pahlawan nggak ada efeknya:** server cuma mengirim animasi terbang (lepas landas, mendarat, menabrak, sonic boom) ke pemain lain, dan client-nya sendiri cuma memutar efek Shazam & Black Adam. Akibatnya efek Lintang (dan Sabbac) untuk semua gerakan terbang itu nggak pernah muncul di layar pemainnya sendiri. Sekarang muncul: kawah, batu terlempar, gelombang debu, kilatan benturan, getaran layar, dan dentum mendarat baru (`hero_land`) menggantikan suara petir.
- **Sinar mata (Iris Surya):** dulu sinarnya keluar dari titik mata tegak, jadi saat terbang mendatar sinarnya muncul dari udara di atas badan; ujungnya cuma dihitung tiap tick, jadi tersendat & melompat saat disapukan; dan berhenti di penduduk desa/hewan padahal yang dilukai cuma musuh. Sekarang sinar keluar dari mata yang benar-benar digambar (ikut pose terbang & skill), ujungnya dihitung tiap frame, dan cuma berhenti di musuh, sama dengan server.

**Sinar mata baru (`LintangHeat`)**
- Mata menyala merah dulu, lalu dua berkas merah tebal yang hidup (lebarnya bergetar halus) dengan inti putih panas & pendar merah lebar, kilau lensa tipis di mata, riak udara panas di sekeliling berkas, dan bara kecil yang terlepas di sepanjang berkas.
- Di titik kena: titik leleh putih-jingga, cipratan lelehan yang jatuh & memantul (searah permukaan yang kena), api kecil, asap yang membubung, dan jejak hangus menyambung di tanah. Sorotan sinar Mode Surya memakai berkas yang sama.
- Suara baru: mata memanas, hentakan nyala, lalu dengung energi rendah yang berdenyut dengan desis terbakar yang berkedip.

**Kostum 3D**
- Di atas tekstur kostum sekarang ada bagian yang benar-benar timbul dari badan: sabuk melingkar dengan tepi, gesper & cakram matahari, kerah tinggi berlist perak, otot perut, manset sarung tangan yang melebar & buku jari, sepatu bot dengan manset berlist perak, ujung sepatu, sol tebal, dan pelindung lutut. Ikut gerak badan, ikut memerah saat terluka, manset juga terlihat di tangan orang pertama. Ukurannya bisa diatur di tabel `BODY`, `LEG`, dan `arm()` di `LintangSuitLayer`.

**Ciri khas tiap skill**
- Skill tenaga surya sekarang berwarna keemasan: Gelegar Surya meledak dengan kilatan putih-emas, mata Lintang menyala saat mengumpulkan tenaga (juga di Ledakan Surya), dan Serap Surya dikelilingi berkas sinar matahari hangat dari langit (cuma kalau langit terlihat), dilepas dengan kilatan keemasan.
- Mendarat gaya pahlawan yang biasa juga punya kilatan benturan & gelombang udara, bukan cuma saat menabrak.

**Kode**
- Baru: `client/fx/LintangHeat` (sinar mata & sorotan), suara `hero_land` (2 variasi), resep `heat_vision_film` di `tools/sfx/synth.py` (menggantikan `heat_vision` lama).
- Diubah: `ShazamFlight` (efek Lintang & Sabbac diputar untuk pemain sendiri), `ShazamFlightServer` (dentum mendarat Lintang), `LintangSuitLayer` (bagian 3D), `LintangFx` (sinar baru, ciri surya, mendarat), `LintangFilm` (`solarFlash`, `SunShaft`), `LintangHd` & `LintangCine` (riak panas sinar ikut mata yang digambar).

## Yang baru di 0.38: Lintang dirombak gaya film (kostum, jubah, lambang, gerak, semua efek)

Gaya baru: sinematik seperti film superhero, tetap tanpa unsur magis (benturan, udara, debu, batu, panas, es). Semuanya dibuat sendiri. Mod Man of Tomorrow yang dikirim nggak dipakai: lisensinya "All Rights Reserved", jadi kode, tekstur, model, dan efeknya nggak disalin. Desain Lintang tetap punyanya sendiri, bukan kostum Superman.

**Kostum baru**
- Begitu berubah jadi Lintang, badan, lengan, dan kaki tertutup kostum: kain biru minyak tua bertekstur halus dengan garis otot dada & perut, panel samping grafit berbentuk V (badan terlihat tegap), list perak, kerah tinggi, sabuk perak bergesper cakram matahari keemasan, sarung tangan & sepatu bot grafit bermanset perak. Kepala tetap kulit aslimu.
- Lapisan luar kulit (jaket, lengan baju, celana) disembunyikan selama kostum dipakai supaya nggak bertumpuk. Kostum ikut memerah saat terluka, dan lengan kostum + sarung tangan juga terlihat di tangan orang pertama.
- Tekstur 256x256 (4x resolusi kulit biasa) di `textures/entity/lintang/suit.png`, dibuat dengan `tools/textures/lintang_suit.py`.

**Lambang dada baru**
- Medali bundar: cincin perak, pelat merah tua, dan bintang-matahari delapan sinar keemasan dengan inti cakram. Timbulnya sekarang berundak seperti medali cetak (cincin & inti paling tinggi, sinar di tengah, pelat paling rendah), dengan kilap logam yang sesekali lewat.
- Tinggi timbul dibaca dari alpha gambar (128 paling rendah, 255 paling tinggi). Lambang juara lain yang alpha-nya penuh tetap seperti dulu. Dibuat dengan `tools/textures/lintang_emblem.py`.

**Jubah lebih tebal**
- Kain merah tua bertekstur kepar dengan jahitan di tepi kiri-kanan & kelim bawah (`textures/entity/lintang/cape_cloth.png`), lapisan dalam lebih gelap, dan sekarang ada tebalnya: tepi kain ditutup dinding kain, jadi saat berkibar menyamping kelihatan seperti kain tebal.

**Gerak baru**
- Berdiri gagah: kepalan di pinggang dengan siku terbuka lebar, dada membusung, dagu terangkat.
- Melayang: tenang, kepalan di sisi badan, kaki rapat, satu lutut sedikit ditekuk.
- Lepas landas: merunduk dalam, lalu melesat dengan kepalan kanan ke atas.
- Mendarat gaya pahlawan: satu lutut turun & kepalan menancap ke tanah, lengan kiri terentang ke belakang, lalu mendongak dan berdiri pelan.
- Tinju Baja: lengan tetap lurus menghunjam dengan badan terpelintir & bergetar. Refleks Kilat: tepisan lengan kiri di depan muka. Dua gerakan ini cuma diputar kalau nggak ada gerakan skill lain yang sedang jalan.

**Semua efek dirombak gaya film**
- Kilatan benturan singkat dengan garis pancar (2-4 tick, bukan bola cahaya) di pukulan biasa, Tinju Baja, tangkisan, Amukan Kilat, Kombo Langit, Tepukan Guruh, Napak Langit, Gelegar Surya, dan musuh yang dilempar.
- Gelombang kejut udara berlapis yang lebih tebal. Kawah dengan retakan, pecahan blok tanah asli yang terlempar jauh, semburan tanah, dinding debu, dan asap.
- Sinar Iris Surya lebih tebal: inti putih panas, pendar merah lebar, berdenyut, mata menyala dengan kilau lensa tipis, riak udara panas di sekeliling sinar, titik leleh yang lebih besar, dan jejak hangus menyambung di sepanjang sapuan. Sorotan sinar panas Mode Surya ikut ditebalkan.
- Terbang: kerucut uap sonic boom yang tebal, cincin uap, dan garis angin. Saat ngebut ada garis angin di belakang; saat terbang rendah debu tanah tersibak ke samping.
- Lepas landas & mendarat: tanah retak, batu terlempar, gelombang debu menyapu. Lesatan Bintang: kerucut uap saat melesat dan garis angin sepanjang jalur. Napas Salju: embun beku bergulung yang lebih tebal dan kabut dingin yang turun di ujung hembusan.
- Lapisan lama yang dobel dibuang (kawah & gelombang dari `LintangCine` sekarang diurus `LintangFx`), jadi efeknya tebal tapi nggak menumpuk jadi cincin berlapis-lapis.

**Kode**
- Baru: `client/render/LintangSuitLayer` (kostum), `client/fx/LintangFilm` (perangkat efek sinematik), `tools/textures/lintang_suit.py`, `lintang_emblem.py`, `lintang_cape.py`, tekstur `lintang/suit.png` & `lintang/cape_cloth.png`; `lintang_emblem.png` diganti (32x32).
- Diubah: `LintangFx` (semua skill & pasif), `LintangCine` (lapisan dobel dibuang), `ShazamEmblemLayer` & `EmblemImage` (timbul berundak), `ShazamCape` (kain & tebal jubah Lintang), `Clips` & `ShazamPoses` (gerak Lintang), `ShazamClient` (lapisan kostum, lapisan luar kulit disembunyikan, tangan orang pertama).

## Yang baru di 0.37: tiga kekuatan Superman klasik versi Lintang

Referensinya kekuatan-kekuatan Superman klasik: napas super yang bisa jadi angin topan, kombo udara (pukul ke atas, susul, banting), dan ledakan tenaga matahari. Mod Superman yang dikirim (Forge 1.20.1) cuma dipakai sebagai inspirasi ide: lisensinya "All Rights Reserved", jadi **nggak ada kode, gambar, model, atau suara dari mod itu yang dipakai**. Semua di bawah ini dibuat sendiri dari nol dengan sistem efek Lintang yang sudah ada, dan tetap fisik: udara, debu, panas, asap.

**Napas Topan (Shift + C)**
- Menarik napas dalam (udara di sekitar tersedot ke mulut), lalu menghembus **angin topan** berbentuk kerucut sejauh 14 blok selama 2 detik. Beda dengan Napas Salju (C biasa) yang membekukan, yang ini menerbangkan.
- Musuh, hewan, dan barang di dalam kerucut **terdorong makin jauh** selama dihembus (dorongannya menumpuk; arahkan pandangan ke atas buat melambungkan mereka). Musuh juga kena 1 damage tiap 0,2 detik.
- **Anak panah, bola api, dan trisula berbalik arah** dan jadi milik Lintang, jadi bisa melukai penembaknya sendiri. Api di badan makhluk yang kena dan api di jalur angin padam.
- Nggak ikut diterbangkan: pemain lain, penduduk desa, pasukan sekutu, hewan peliharaanmu, patung es, dan musuh yang sedang diangkat.
- Efeknya: garis-garis angin putih yang melesat, udara & uap yang terdorong, debu tanah tersapu searah hembusan, kerucut udara tembus pandang. Suara baru: tarikan napas lalu angin menderu. Biaya & jedanya sama dengan Napas Salju (30 / 9 dtk).

**Kombo Langit (Shift + Z)**
- Harus ada musuh di depan (sampai 16 blok, darah maksimal 300). Kalau nggak ada sasaran, masih jeda, atau energi kurang, Shift + Z jadi Lesatan Bintang biasa.
- Urutannya: merunduk, **melesat** ke sasaran, **uppercut** yang melambungkannya tinggi ke udara (12 damage), Lintang **menyusul** ke atas sasaran secepat kilat, sasaran tertahan sebentar di puncak, lalu **dua kepalan membantingnya** ke tanah (14 damage). Saat sasaran menghantam tanah: kawah, retakan, debu, 14 damage lagi, dan musuh lain dalam 4 blok kena 8 damage & terlempar. Terakhir Lintang **menyorot kawahnya dengan sinar panas** 4 kali (5 damage tiap sorotan, terbakar).
- Tiap pukulan kombo pasti masuk penuh (jeda kebal vanila dilewati). Patung es yang kena uppercut langsung pecah.
- Biaya 70 energi, jeda 15 detik (terpisah dari Lesatan Bintang).

**Ledakan Surya (Shift + R)**
- Butuh minimal 400 energi surya. Lintang meringkuk dan **mengumpulkan panas selama 3 detik**: udara di sekeliling badan beriak makin kuat, debu tersedot berputar ke badannya, kerikil terangkat, tanah di bawahnya retak & memerah panas, layar makin bergetar. Selama itu badannya sekeras baja (Ketahanan IV) tapi geraknya sangat lambat (Lambat IV).
- Lalu **meledak seperti bom**: kilatan panas singkat, bola ledakan panas yang cepat mendingin jadi asap, gelombang kejut raksasa, dinding debu yang menyapu tanah, kawah hangus, puing beterbangan, dan **tiang asap yang membubung lalu melebar di puncaknya** (di udara: kepulan asap saja, tanpa kawah). Suara baru: dengung pengisian yang makin naik lalu ledakan menggelegar.
- **Semua energi dibakar** (sisa 50): damage 30 + 0,06 per energi yang dibakar (energi penuh ±87) dalam 18 blok, makin jauh makin kecil (tinggal 40% di pinggir). Musuh terbakar 8 detik, silau 4 detik, dan terhempas. Patung es mencair, anak panah & barang terlempar.
- Sesudahnya langsung **Mode Surya** (sama seperti sesudah Gelegar Surya). Jeda 2 menit, terpisah dari Gelegar Surya (R biasa).

**Angka yang bisa diatur**
- `LintangSkills`: `GALE_RANGE` (14), `GALE_CONE_DOT` (0,82), `GALE_PUSH` (0,5), `GALE_DAMAGE` (1), `COMBO_RANGE` (16), `COMBO_EXTRA_COST` (45, ditambah biaya Lesatan 25), `COMBO_COOLDOWN` (300 tick), `COMBO_MAX_HEALTH` (300), `COMBO_UPPERCUT_DAMAGE` (12), `COMBO_SMASH_DAMAGE` (14), `COMBO_IMPACT_DAMAGE` (14), `COMBO_SPLASH_DAMAGE` (8), `COMBO_HEAT_DAMAGE` (5), `NOVA_MIN_ENERGY` (400), `NOVA_KEEP_ENERGY` (50), `NOVA_RADIUS` (18), `NOVA_MIN_DAMAGE` (30), `NOVA_DAMAGE_PER_ENERGY` (0,06), `NOVA_COOLDOWN` (2400 tick).
- `ShazamAnim`: `SOLAR_NOVA_WINDUP` (60 tick: lama mengumpulkan panas), `COMBO_RISE` & `COMBO_SMASH` (tick menyusul & membanting).

**Kode**
- Baru: animasi `LINTANG_GUST`, `LINTANG_COMBO`, `LINTANG_COMBO_RISE`, `LINTANG_COMBO_SMASH`, `LINTANG_NOVA`; suara `super_breath` (2 variasi) & `solar_nova`.
- Diubah: `LintangSkills` (Napas Topan, Kombo Langit, Ledakan Surya), `LintangFx` (garis angin `GaleStreaks`, efek kombo, pengisian & ledakan Ledakan Surya), `LintangHd` & `LintangCine` (lapisan tekanan udara, debu, kawah, riak panas), `Clips` (merunduk-melesat-uppercut, menyusul, banting dua kepalan, meringkuk lalu meledak terbuka), `ShazamClient` (badan Lintang digerakkan ke sasaran saat kombo).

## Yang baru di 0.36: Lintang ala DLC Superman (Oreville Studios)

Referensinya DLC "Superman" buatan Oreville Studios di Minecraft Marketplace: terbang secepat kilat, kekuatan super, sinar panas yang membakar penghalang, napas beku yang membekukan musuh, melindungi warga, dan anjing super di Benteng Kesunyian. Semua dibuat ulang dengan versi Lintang sendiri (nama, bentuk, dan efeknya orisinal, tanpa logo, nama, atau karakter DC).

**Iris Surya membakar penghalang (X)**
- Blok yang kena sinar panas ikut terbakar atau meleleh, jadi kalau ditahan ke satu arah sinarnya pelan-pelan menembus penghalang: kaca & panel kaca pecah, jeruji besi meleleh, daun, wol, karpet, sarang laba-laba, tanaman merambat & jerami habis terbakar, salju hilang, es (termasuk es padat & es biru) mencair jadi air, pasir meleleh jadi **kaca**, dan kayu atau blok mudah terbakar lain tersulut di sisi yang kena.
- Nggak jalan di mode Petualangan dan di area spawn yang dilindungi. Matikan lewat `LintangSkills.IRIS_BURNS_BLOCKS` (false = cuma salju & es seperti dulu).
- Patung es yang kena sinar panas langsung mencair.

**Napas Salju: patung es (C)**
- Musuh yang membeku penuh (sekitar 1 detik dihembus) jadi **patung es** selama 3,5 detik: terkunci di dalam balok es bening (es merambat naik dari kaki, kabut beku di dalam, kristal es mencuat di atasnya, retak-retak menjelang lepas), nggak bisa bergerak, menyerang, menembak, atau meledak (creeper).
- **Pukul patung esnya:** es pecah berkeping-keping dan pukulan itu damage-nya **×1,5**. Kalau dibiarkan, esnya pecah sendiri.
- Musuh sekuat bos (darah di atas 300) cuma melambat. Nggak ada yang disimpan di makhluknya, jadi aman walau server dimatikan di tengah efek.

**Angkat & Lempar (Shift + X)**
- Seperti Lemparan Hercules milik Shazam, tapi buat Lintang musuhnya ringan: diraih, diangkat lurus ke atas kepala tanpa gemetar, lalu dilempar sekuat tenaga ke arah pandangan (3 blok/tick). Musuh sampai darah 300 bisa diangkat.
- Yang dilempar kena 28 damage saat menabrak tanah, dinding, atau musuh lain. Musuh lain dalam 4 blok kena 18 damage dan terhempas, dengan retakan tanah, puing, debu, dan gelombang udara. Biaya & cooldown-nya sama dengan Iris Surya. Yang sedang diangkat nggak bisa melukai Lintang.

**Anjing super**
- Serigala jinak milikmu dalam 48 blok ikut jadi anjing super selama Lintang dalam Mode Surya: Kecepatan II, Kekuatan III (gigitan 4 jadi 13), Ketahanan III, kebal api & jatuh, dan pulih di bawah matahari. Efeknya tanpa pusaran butiran.
- Saat kamu terbang, mereka **ikut terbang** di samping-belakangmu (kiri & kanan bergantian kalau banyak), menyusul langsung kalau tertinggal jauh, dan meninggalkan jejak uap saat melesat. Serigala yang disuruh duduk atau diikat tali nggak ikut.
- Mereka memakai **jubah merah kecil** yang diikat di leher dan menutupi punggung. Saat diam ujungnya menjuntai, saat lari atau terbang jubahnya berkibar lurus ke belakang. Nggak dipakai saat duduk atau masih anak.
- Begitu Lintang berhenti (balik jadi manusia, keluar, atau terlalu jauh), serigalanya kembali biasa sendiri.

**Melindungi warga**
- Penduduk desa yang diselamatkan lewat **Selamatkan (J)** berwajah senang, dan kamu jadi **Pahlawan Desa** selama 2 menit (harga dagang lebih murah).

**Angka yang bisa diatur**
- `LintangSkills`: `IRIS_BURNS_BLOCKS`, `LIFT_REACH` (5,5), `LIFT_MAX_HEALTH` (300), `LIFT_THROW_SPEED` (3,0), `LIFT_HIT_DAMAGE` (28), `LIFT_SPLASH_DAMAGE` (18), `LIFT_SPLASH_RADIUS` (4), `ICE_MAX_HEALTH` (300), `ICE_SHATTER_MULTIPLIER` (1,5), `CITIZEN_HERO_TICKS` (2400).
- `ShazamAnim.LINTANG_ICE_TICKS` (70): lama patung es.
- `LintangDog`: `RANGE` (48), `SPEED_LEVEL`, `STRENGTH_LEVEL`, `RESIST_LEVEL`, `FLY_SPEED` (2,6), `FLY_TELEPORT` (40).
- `SuperDogCapeLayer`: panjang, lebar, dan juntaian jubah anjing (`LENGTH`, `HALF_MANE`, `HALF_BODY`, `DROP`).

**Kode**
- Baru: `LintangDog` (anjing super), `client/render/SuperDogCapeLayer` (jubah anjing, dipasang ke renderer serigala di `ShazamClient`), animasi `LINTANG_ICE` & `LINTANG_ICE_BREAK`.
- Diubah: `LintangSkills` (bakar penghalang, patung es, Angkat & Lempar, warga desa), `ShazamPowers` (pukulan memecahkan patung es, yang diangkat nggak bisa melukai), `LintangFx` (balok es `IceShell`, kepingan es, efek angkat & lempar, jejak uap anjing super), `LintangHd` & `LintangCine` (lapisan hantaman lemparan), `Clips` (klip angkat & lempar Lintang yang ringan).

## Yang baru di 0.35: Lintang ala Superman, tanpa unsur magis sama sekali

Lintang sekarang benar-benar hero sains ala Superman: manusia yang sel tubuhnya menyimpan tenaga matahari. Semua yang terlihat dan terdengar dari Lintang adalah fisika: udara yang terdorong, debu, puing, uap, panas, dan es. Nggak ada lagi tiang cahaya dari langit, sinar dewa, korona, plasma, tombak cahaya, perisai cahaya, butiran berkilau, paduan suara, atau lonceng. Lintang juga sengaja dibuat beda dari tiga juara lain: Shazam & Black Adam disambar petir sihir, Sabbac dibakar api neraka, Lintang nggak memanggil apa pun.

**Ganti kostum secepat kilat (tombol G)**
- Nggak ada pemanggilan, slow motion, atau petir. Kedua tangan merobek kemeja (tick 6) dan lambang matahari di dada langsung terlihat. Badan berputar dua kali secepat kilat dengan bayangan gerak & debu yang ikut berpusar, lalu di tick 12 kostum & jubah sudah terpasang dan udara yang terdorong putarannya meledak keluar: gelombang kejut udara, debu dari tanah, dan musuh dalam 5 blok kena 16 damage & terhempas. Ditutup pose pahlawan (kepalan di pinggang, dagu terangkat). Totalnya 2 detik.
- Badan nggak membesar (Lintang tetap seukuran manusia), dan kostum nggak terbentuk dari cahaya.
- Kembali jadi manusia: berputar secepat kilat lagi, kostum lepas dengan hembusan udara. Terhantam sampai lepas wujud: terlempar dengan debu & puing, tanpa cahaya yang keluar dari dada.

**Jubah tunggal ala Superman**
- Satu jubah merah tua di bahu, dua sisinya sewarna. Tanpa hood (tombol H ditolak), tanpa mantel bahu, tanpa pelat & rantai emas, tanpa lambang di punggung, tanpa kilau tenun, dan nggak larut jadi butiran cahaya saat dilepas.
- Lambang matahari delapan sinar di dada tetap milik Lintang sendiri (bukan lambang S Superman). Sekarang lambangnya pelat logam yang kena cahaya dunia biasa (ikut gelap di tempat gelap), dengan kilap tipis saat kena cahaya. Nggak berkilau sendiri lagi.
- Mata cuma menyala merah saat sinar panas. Bayangan gerak saat melesat & memukul sekarang bayangan biasa yang tembus pandang, bukan bayangan bercahaya.

**Pasif ala Superman**

| Pasif | 0.34 | 0.35 |
|---|---|---|
| Tiap 2 detik | Serapan Cahaya (sinar matahari turun menyentuh dada) | **Regenerasi Surya**: sel tubuhnya menyerap sinar matahari tanpa terlihat & tanpa suara (+100 energi, +40 darah, armor pulih, muatan penuh; malam hari separuh). Tetap padam di bawah tanah / di dalam ruangan, di Nether & End, dan dekat Batu Cryon. |
| Pukulan penuh | Tinju Fajar (ledakan & tiang cahaya, tombak cahaya) | **Tinju Baja**: damage ×1,75 dan gelombang kejut udara dari titik hantaman. Sasaran terhempas jauh & terhuyung, sampai 3 musuh lain dalam 7 blok kena 14 damage & terdorong. Tanpa api & cahaya. |
| Bertahan tiap 1,8 detik | Tepisan Beku (tangan membeku) | **Refleks Kilat**: serangan ditangkap secepat kilat (0 damage). Proyektil ditangkap di udara lalu diremukkan, penyerang dalam 6 blok langsung dibalas pukulan (6 damage, terhuyung, terdorong). |
| Makhluk tak berdosa diserang | tombak cahaya ke penyerangnya | **Pendengaran super**: penyerangnya terlihat menembus dinding, pukulanmu +25% selama 8 detik. |
| Mode Surya (sesudah Gelegar Surya) | tombak cahaya | **Sinar panas mata**: tiap detik menyambar 2 musuh terdekat, dan tiap pukulan menyambar 2 musuh lain di dekat sasaran. Udara di sekeliling badan beriak panas. |
| Kulit Baja | percikan cahaya | serangan kecil memantul seperti peluru mengenai baja (percikan benturan). |

**Semua efek skill jadi fisik**
- **Lesatan Bintang:** terowongan udara & uap sepanjang jalur, bayangan gerak biasa, debu; saat berhenti mendadak udara yang terbawa menghantam.
- **Iris Surya:** sinar panas merah membara dari kedua mata (dulu emas), titik leleh, percikan lelehan, asap, bekas hangus, dan udara di depan mata beriak panas.
- **Napas Salju:** embun beku & butir es yang menyembur, es merambat di tanah, tanpa butiran cahaya.
- **Tepukan Guruh:** gelombang udara berlapis & dinding debu yang tersapu ke depan, tanpa kilatan.
- **Amukan Kilat:** kepalan kabur secepat kilat, udara terpukul di tiap pukulan.
- **Napak Langit:** ledakan debu bervolume, dinding debu, retakan tanah, dan puing blok, tanpa tiang cahaya & gelombang api.
- **Gelegar Surya:** udara di sekeliling badan memanas & beriak, lalu ledakan panas yang cepat jadi asap, gelombang kejut raksasa, kawah, dan bekas hangus. Tanpa sinar dewa, korona, plasma, atau butiran berkilau.
- **Serap Surya:** tanpa tiang cahaya. Tubuhnya menyerap sinar matahari (riak panas naik dari badan), lalu panas berlebihnya dilepas jadi gelombang panas yang menghempas. Angkanya tetap.
- **Selamatkan:** tiba secepat kilat dengan debu berputar & hembusan udara, tanpa perisai cahaya.
- **Terbang, sonic boom, mendarat:** uap kondensasi tipis (tanpa pita cahaya & kilau bintang), kerucut uap Prandtl-Glauert, debu, puing, dan retakan tanah yang dingin (tanpa bara).
- **Eksperimen Evolusi Surya:** tanpa aliran foton, heliks DNA bercahaya, percikan listrik, atau tiang cahaya. Serum disuntik, tubuh menyerap matahari (urat di kulit menyebar, udara memanas, debu berputar, napas & detak jantung makin cepat), mutasi (kejang, berlutut), lalu kekuatan barunya meledak keluar sebagai gelombang tekanan udara dengan kawah & puing.
- **Melemah (Nether / Batu Cryon):** tanpa percikan listrik & butiran. Napas berat, detak jantung, jatuh berlutut dengan debu, dan urat hijau radiasi Cryon di kulit.
- **Muatan penuh:** kepalan yang panas (udara beriak & uap tipis), bukan api atau cahaya.
- **Efek HD baru `Hd.DustBurst`:** ledakan debu bervolume tanpa cahaya (warnanya diambil dari blok tanah) untuk semua hantaman Lintang.
- **Gelombang tekanan jadi selaput uap (`Hd.Pressure.vapor`):** gelombang kejut Lintang sekarang selaput uap tipis tembus pandang yang membiaskan pandangan, bukan kubah atau bola bercahaya.

**SFX tanpa paduan suara & lonceng** (dibuat ulang lewat `tools/sfx/synth.py`): `transform_lintang` (retakan sonik, dentum udara, kibasan jubah), `solar_pulse` (hembusan hangat & dentum lembut), `dawn_punch` (Tinju Baja: hantaman baja, retakan udara, dentum, puing), `barrage` (pukulan penutup tanpa denting), `solar_flare` (deru panas tertahan, ledakan & gelombang kejut), `sun_call` (dengung panas terserap, lalu hembusan & dentum), `lintang_rite` (klik injektor, desis serum, detak jantung), `frost_parry` (Refleks Kilat: desing tangan, tangkapan keras, dentum), `frost_breath` (tanpa denting kaca), `sun_strike` (hantaman tanah). Suara saat memilih Lintang dan saat muatan penuh juga nggak pakai denting sihir lagi.

**Angka yang bisa diatur**
- `ShazamAnim.LINTANG_RIP` (6), `LINTANG_SUITUP` (12), `LINTANG_SUIT_TICKS` (40): tick kemeja dirobek, tick kostum terpasang, dan panjang klip ganti kostum.
- `ShazamPowers.LINTANG_TRANSFORM_STRIKE_DAMAGE` (16) & `TRANSFORM_STRIKE_RADIUS` (5): ledakan udara saat kostum terpasang.
- `ShazamPassives.PARRY_DAMAGE` (6) & `PARRY_COUNTER_RANGE` (6): pukulan balik Refleks Kilat.
- `LintangSkills.DAWN_LANCE_DAMAGE` (14) & `DAWN_LANCE_RADIUS` (7): gelombang kejut Tinju Baja. `RAGE_LANCE_DAMAGE` (10): sinar panas Mode Surya.
- `ShazamEyesLayer.LINTANG_SMOLDER` (0): naikkan (misalnya 0.3) kalau mau mata Lintang selalu menyala merah samar.
- `FormLook.LINTANG`: warna jubah (merah tua `0xA3141C`, sisi dalam `0x6A0C12`).
- `LintangFx.BOOST` (1.5) & `HdKit.AMOUNT` (1.0) masih berlaku.

**Kode**
- Ditulis ulang (semua efek fisik): `client/fx/LintangFx`, `client/fx/LintangHd`, `client/fx/LintangCine`.
- Baru: `Hd.DustBurst`, `Hd.Pressure.vapor()`, `CineKit.shock(..., soft)`, `ShazamCape.plainCape`, `ShazamAnim.LINTANG_RIP/LINTANG_SUITUP/LINTANG_SUIT_TICKS`.
- Diubah: `ShazamPowers` (ganti kostum tanpa pemanggilan & petir, ledakan udara, nggak membesar, tanpa hood, suara memilih Lintang), `ShazamPassives` (Regenerasi Surya, Refleks Kilat, suara muatan penuh), `LintangSkills` (Tinju Baja, sinar panas, Serap Surya tanpa tiang cahaya), `LintangRite`, `Clips` (klip ganti kostum & kembali), `ShazamPoses` (bayangan gerak biasa, suara kibasan jubah, nggak membesar), `ShazamCape`, `FormLook`, `ShazamEmblemLayer`, `ShazamEyesLayer`, `SuitRevealLayer`, `ShazamFx` (jejak terbang), `ShazamRage` (tanpa percikan amarah), `tools/sfx/synth.py`, `tools/sfx/names.txt`, file bahasa.

## Yang baru di 0.34: VFX HD Lintang & Sabbac + animasi halus

**Mode HD di inti VFX** (`Draw`; cuma untuk efek yang dibuat dengan penguat, yaitu Lintang & Sabbac. Efek Shazam & Black Adam nggak berubah)
- Pendar bulat memakai profil lonceng yang lebih halus (8 titik, dulu 4) dan jumlah segmen yang naik sesuai besarnya di layar: tepinya lembut, nggak bergerigi atau berpita.
- Garis & pita yang lebar punya penampang bulat (terang di tengah, memudar halus ke tepi) seperti berkas cahaya sungguhan, bukan pipih.
- Cincin, cakram, cangkang, dan kerucut digambar dengan ±1,5x lebih banyak segmen.
- Gelombang tekanan & perisai berbentuk bola digambar sebagai cakram menghadap kamera yang siluetnya bulat sempurna dari jarak berapa pun (cangkang biasa terlihat bersudut di tepinya yang paling terang). Kalau kamera ada di dalam bola, otomatis pindah ke cangkang biasa.

**Butiran baru** (`Particles`, `Vfx.flame/shard/cinder/streak`)
- **Api:** lidah api berbentuk tetesan terbalik (pangkal bulat, ujung runcing yang menari berkelok), inti putih-kuning yang mendingin ke warna api lalu merah gelap. Naik karena panas, condong tertiup saat bergerak, dan saat disembur jadi aliran api yang menyambung dari mulut.
- **Kristal:** serpihan es/obsidian yang berputar, berkilau sesekali, dan memantul di tanah.
- **Gores cahaya:** garis kecepatan & hujan foton yang panjang dan tipis.
- **Abu:** bara yang menyala sebentar lalu jadi abu yang melayang turun atau naik terbawa panas.

**Efek HD baru** (`client/vfx/Hd`)
- **Nova:** bola ledakan bervolume (lobus-lobus yang mengembang, warna mendingin dari panas ke gelap, lalu asap), bisa meledak di tanah.
- **Plasma & Korona:** lengkung prominensa matahari dengan gumpalan panas yang mengalir, dan pancaran korona.
- **Gelombang tekanan:** bola atau kubah searah pukulan, tepinya terang dengan pita gelap tipis seperti udara yang membiaskan cahaya.
- **Pusaran:** tornado api / pusaran cahaya dengan lengan yang mulus, lembaran tembus pandang, dan asap. Di Sabbac ditambah lidah api yang naik berpilin (`HdKit.flameSpiral`).
- **Segel neraka:** cincin ganda, lengkung tanduk antar penjuru, jari-jari, cincin rune putus-putus yang berputar berlawanan, satu lingkaran di tiap penjuru (satu per iblis).
- **Es merambat** (pola kristal bercabang + duri es), **Perisai** (gelembung emas dengan sel heksagon geodesik yang terbentuk dari bawah dan disapu pita terang), **Tombak cahaya**, **Bayangan cahaya** (lesatan & pukulan), **Riak udara panas**.

**Lapisan HD per skill** (`client/fx/LintangHd`, `client/fx/SabbacHd`, dipanggil dari `LintangCine`/`SabbacCine` di atas efek yang sudah ada)
- **Lintang:** berubah wujud (ledakan cahaya dari dada, gelombang tekanan, korona, cincin api surya), Mode Surya (korona & plasma mengelilingi badan selama aktif), Lesatan Bintang (tombak cahaya, bayangan, gores kecepatan, ledakan di ujung), Iris Surya (sinar mata HD: cincin yang meluncur & halo), Napas Salju (kristal es + es merambat di tanah), Tepukan Guruh (kubah tekanan berlapis), Amukan Kilat (ledakan tiap pukulan, pukulan penutup bertombak cahaya), Napak Langit (kubah tekanan, tombak cahaya dari langit, gelombang api), Gelegar Surya (ancang-ancang korona, lalu supernova), Serap Surya (pusaran cahaya & hujan foton), Selamatkan (perisai heksagon di tiap sekutu), Serapan Cahaya, Tinju Fajar, Tepisan Beku, terbang, mendarat, sonic boom, dan Eksperimen Evolusi Surya.
- **Sabbac:** berubah wujud (bola api neraka, tornado api, gelombang api, hujan abu), Perjanjian Enam Iblis & kedatangan iblis (segel neraka + tiang api tiap iblis), Tanduk Setan, Tubuh Aym & Letusan Aym, Rantai Belial (segel & tiang api; rantainya sekarang berinti panas dan meneteskan api), Napas Beelzebub (semburan api + api di tanah), Teror Asmodeus, Kepakan Crateis (sayap dengan lidah api di sepanjang tulangnya), Gerbang Neraka, Panggil Petir Neraka, Pasukan Iblis, Api Neraka, Tinju Neraka, Kulit Bara, terbang, mendarat, dan kedatangan Rival Sabbac.
- Terus-menerus: api di bahu Sabbac (makin besar di tempat gelap), selubung api saat Gerbang Neraka, jejak api/cahaya saat terbang, kepalan yang menyala saat muatan penuh.
- Di sudut pandang orang pertama efek yang menutupi layar dikurangi.

**Animasi halus** (`client/anim/PoseFilter`)
- Pose akhir Lintang & Sabbac (sesudah semua lapisan animasi) diikuti pegas teredam per bagian tubuh yang dihitung **tiap frame**: perpindahan antar-animasi, sentakan keyframe, dan perubahan pose mendadak jadi mulus di FPS berapa pun. Lengan & kaki mengikuti cepat (pukulan tetap kena di saatnya), kepala sedikit lebih lambat, jadi ada gerak susulan alami.
- Nggak dipakai untuk tangan orang pertama dan boneka di layar inventaris, dan lepas otomatis saat tidur, naik kendaraan, elytra, atau berenang.

**Angka yang bisa diatur**
- `HdKit.AMOUNT` (1.0): kepadatan semua butiran HD. Turunkan (misalnya 0.6) kalau FPS turun saat skill besar.
- `PoseFilter.ENABLED` (true = aktif) dan kecepatan pegasnya `HEAD`, `BODY`, `ARM`, `LEG`, serta `DAMPING`.
- `LintangFx.BOOST` / `SabbacFx.BOOST` (1.5): penguat sinematik (bloom, kepadatan butiran, dan mode HD; 1 = mati).

**Kode**
- Baru: `client/vfx/Hd`, `client/fx/HdKit`, `client/fx/LintangHd`, `client/fx/SabbacHd`, `client/anim/PoseFilter`.
- Diubah: `Draw` (mode HD), `Vfx` (butiran baru, mode HD per efek), `Particles`, `LintangCine` & `SabbacCine` (memanggil lapisan HD), `LintangFx` (sinar mata HD), `SabbacFx` (api, rantai, sayap), `ShazamFx` (langkah efek terjadwal yang gagal dibuang, bukan bikin crash), `LintangBody` (memanggil PoseFilter), `ShazamClient` (penanda frame untuk PoseFilter).
- Semua lapisan baru dibungkus try/catch: kalau ada yang gagal, efeknya saja yang hilang, game nggak crash.

## Yang baru di 0.33: Lintang jadi hero sains, Batu Cryon, animasi melemah, efek Lintang & Sabbac dipertebal

**Lintang tanpa unsur magis**
- Kristal Bintang diganti **Serum Helion-7** (`helion_serum`). Resep: blok emas di 4 sudut, bunga matahari (sel fotosintetik), 2 glowstone, Nether Star (sumber energi eksotis), dan botol kaca.
- Penyatuan Bintang diganti **Eksperimen Evolusi Surya** (sekitar 6,8 detik, di bawah matahari langsung): injeksi serum di lengan, absorpsi foton UV (aliran foton dari arah matahari asli + heliks DNA dari cahaya), mutasi sel (kejang, berlutut, urat berkedip), lalu evolusi: ledakan cahaya dari *dalam* tubuh dan pilar cahaya yang naik. Ada log lab di chat dan progress bar di action bar. Kalau paparan matahari terputus, eksperimen batal dan serumnya belum terpakai. `/shazam rite <pemain>` menjalankan eksperimen paksa (untuk tes).
- Kata ajaib LINTANG di chat dihapus: **Mode Surya** diaktifkan dengan tombol Transformasi (default G).
- Transformasi Lintang: foton terserap ke dada, urat surya keemasan menyala dari dalam (tekstur 512 px di atas UV skin), lalu ledakan cahaya + gelombang kejut. Di bawah matahari urat emasnya berdenyut samar.

**Batu Cryon (dulu Batu Kelam)**
- ID baru: `cryon_ore` dan `cryon_shard` (item & blok Kelam / Kristal Bintang di world 0.32 hilang, buat world baru atau backup dulu).
- Banyak di Nether: 12 urat per chunk (ukuran 8) di netherrack/basalt/blackstone, plus sedikit di deepslate overworld. Kristalnya berpendar (model emissive, `neoforge_data`) dan memercikkan partikel hijau di sekitar Lintang.

**Lemah di Nether**
- Tanpa matahari, sel surya kelaparan: pukulan x0,7, damage diterima x1,35, gerak -15%, energi terkuras 4/detik (di atas drain bawaan). Di dekat Cryon berlaku kelemahan bawaan (daya x0,5, lambat, nggak bisa terbang, energi -25/detik). Lihat `LintangScience`.
- Animasi melemah: tersentak, memegang dada, jatuh satu lutut, napas berat, bangkit goyah; sesudahnya sikap lemah terus-menerus (bungkuk, kepala tertunduk, goyah, napas terlihat). Lihat `LintangBody`.
- Perubahan fisik HD (`CryonSkinLayer`): kulit pucat dengan lingkar mata gelap, urat hijau Cryon berdenyut yang menjalar dari dada (di Nether tanpa Cryon: urat redup), mata meredup. Kamera orang pertama: vignette berdenyut & detak jantung.

**Efek dipertebal (lebih "film")**
- Lintang: kerucut uap Prandtl-Glauert saat sonic boom & Lesatan, gelombang kejut berlapis, kawah retak panas, napas kriogenik, iris panas, rentetan pukulan, Gelegar Surya raksasa dengan god rays & afterglow.
- Sabbac: erupsi pilar api neraka saat berubah, tornado bara (Aym), sigil api (rantai & legiun), napas api berasap, raungan, Hellgate & geyser lava, jejak hangus di tanah, bara di sekitar tubuh.
- Efek asli tetap jalan; lapisan baru ditambahkan di atasnya dan dibungkus try/catch supaya kalau ada yang gagal, game nggak crash.

**Rombakan efek & animasi (lanjutan 0.33)**
- Penguat sinematik di inti VFX (`Vfx.setBoost`, `Draw.bloom`): semua efek Lintang & Sabbac, termasuk efek asli di `LintangFx`/`SabbacFx` dan semua efek terjadwalnya, mendapat lapisan bloom (tiap cahaya digambar ulang 2,2x lebih lebar & lembut), butiran 65% lebih padat, 25% lebih besar, dan 30% lebih lama. Shazam & Black Adam (penguat 1) nggak berubah, jadi Lintang & Sabbac jelas paling tebal. Atur di `LintangFx.BOOST` / `SabbacFx.BOOST` (1.5).
- Clip transformasi Lintang dirombak jadi sains: tenaga dikumpulkan dari dalam tubuh (kaki menapak, badan merunduk, gemetar), lalu meledak keluar dari dada; bukan lagi melayang menerima cahaya dari langit. Clip Eksperimen Evolusi Surya menggantikan Penyatuan Bintang (`Clips`, LINTANG_RITE).
- Gerak sekunder realistis untuk Lintang & Sabbac (`LintangBody`, pegas teredam): badan condong saat mempercepat dan tertahan ke belakang saat mengerem (dengan sedikit pantulan), miring ke dalam belokan, menekuk saat mendarat, napas & geser berat badan saat diam, tersentak saat kena pukul.
- Tekstur HD Sabbac: urat bara (`fx/embers.png`) dan magma (`fx/magma.png`) sekarang 512 px (dulu 64 px), seamless.

**Kode**
- Baru: `LintangScience`, `client/fx/CineKit`, `client/fx/LintangCine`, `client/fx/SabbacCine`, `client/anim/LintangBody`, `client/render/CryonSkinLayer`, `client/render/LintangLayers`. Ditulis ulang: `LintangRite`.
- Titik panggil diganti: `ShazamClient.GameEvents` (LintangCine/SabbacCine), `ShazamFx` (sunStrike), `ShazamEyesLayer` (eyeGlow + mata meredup), `HumanoidModelMixin` & `PlayerRendererMixin` (LintangBody), `ShazamEvents` (kata LINTANG dihapus), `LintangItems` (ID baru).

## Yang baru di 0.32: Lintang, juara bintang (orisinal)

Juara keempat, rancangan orisinal (nama, kostum, lambang, dan aturan mainnya baru). Tubuh Lintang menyimpan cahaya matahari & bintang. Angka mentahnya **paling tinggi di mod ini**, tapi kekuatannya **ikut cahaya yang tersimpan**, dan ia punya **kelemahan yang nyata**.

**Cara mendapatkannya:**
1. Kalahkan Wither, ambil Nether Star-nya.
2. Craft **Kristal Bintang**: Nether Star di tengah, glowstone di empat sisi, balok emas di empat sudut.

       O G O
       G N G
       O G O

3. Klik kanan kristalnya **dalam wujud manusia, di bawah matahari** (siang, langit terbuka, nggak hujan): **Penyatuan Bintang** (4 detik). Kristal terangkat ke langit, cahaya matahari mengumpul makin deras di sekelilingmu sementara Suara Bintang bicara di chat, lalu **tiang cahaya menghunjam dari langit** di detik ke-3 dan kristalnya menyatu dengan tubuhmu. Lintang langsung terpilih.
4. Ketik `lintang` di chat (atau tombol G) untuk berubah. Tombol K untuk ganti juara.

**Berubah wujud:** bukan dewa yang datang, tapi cahaya langit yang turun bergelombang enam kali dan terhisap ke dada, sementara lengan terbuka ke langit dan badan pelan-pelan terangkat. Lalu **tiang cahaya lurus** turun pelan dari langit (bukan petir zig-zag) dan menghunjam: kilatan putih, sinar dewa, cincin cahaya di tanah, dan kostum terbentuk dari cahaya dari kaki ke kepala.

**Badan & kekuatan dasar:**

| | Lintang | Pembanding |
|---|---|---|
| Darah | **380** | Black Adam 350, Shazam 300 (sampai 400 lewat Restu Para Dewa) |
| Damage yang diterima | **32%** (cahaya penuh), naik sampai 52% saat cahaya habis | Black Adam 35% |
| Tinju tangan kosong | **48** (critical 72) saat cahaya penuh, turun sampai 29 | Black Adam 44 |
| Lari | **tercepat**: +15% di atas juara lain | |
| Kulit Baja | serangan di bawah 7 damage **memantul** (zombie, panah, laba-laba) | |
| Pulih darah | 2/detik, ×2 di bawah matahari, berhenti dekat Batu Kelam | |
| Energi (Cahaya Tersimpan) saat berwujud juara | +2/detik di bawah matahari, +0,5 di bawah langit malam, -2 di bawah tanah / di dalam ruangan, -3 di Nether & End, **-25 dekat Batu Kelam** | |
| Isi energi (wujud manusia) | 5/detik, ×3 di bawah matahari, ×0,5 di Nether & End | |

**Daya Surya:** selama Cahaya Tersimpan **500 ke atas**, kekuatan penuh. Di bawahnya tinju & ketahanan menyusut sampai 60% saat cahaya habis. Jadi Lintang paling kuat di bawah langit, dan makin lama di gua tanpa langit makin lemah. Garis toska di bar energi HUD menandai batas 500. Di bawah kotak skill ada baris **☀ Daya Surya** dengan angka darah, damage diterima, dan tinju yang berlaku sekarang.

**Kelemahan:**
- **Batu Kelam:** mineral ungu kehitaman yang menghisap cahaya. **Bijih Kelam** ada di lapisan deepslate (y -64 sampai -16, ±2 urat kecil per chunk), ditambang beliung besi ke atas, dan menjatuhkan **Pecahan Kelam** (Fortune menambah, Silk Touch = bijihnya). Batu Kelam dihitung **dekat** kalau bijihnya ada di batu dalam 4 blok, dipegang makhluk atau tergeletak di tanah dalam 6 blok, atau dibawa Lintang sendiri. Saat dekat:
  - Cahayanya terkuras 25 per detik dan Daya Surya tinggal separuh.
  - **Nggak bisa terbang** dan lari 30% lebih lambat.
  - Serapan Cahaya, Kulit Baja, dan Tepisan Beku mati.
  - Asap ungu mengalir ke badannya dan HUD berkedip ungu.
  
  **Dipukul oleh yang memegang Pecahan/Bijih Kelam:** damage ×3 menembus semua ketahanan, dan cahayanya terhisap 60.
- **Sihir:** damage sihir ×2 (Shazam cuma ×1,5). **Tinju juara bertenaga sihir** (Shazam, Black Adam, Sabbac) dan **Bentrokan Juara** mereka ×1,5.
- **Jauh dari langit:** di bawah tanah, di Nether, dan di End cahayanya terkuras dan Serapan Cahaya padam.

**Skill (tombol sama dengan juara lain, huruf L-I-N-T-A-N-G):**

| Tombol | Skill | Biaya / cooldown | Isinya |
|---|---|---|---|
| Z | L - **Lesatan Bintang** | 25 / 5 dtk | Merunduk sesaat, lalu melesat lurus secepat cahaya sampai 18 blok (berhenti sebelum dinding), meninggalkan jejak cahaya & bayangan. Musuh di jalur kena 16 damage dan terlempar ke samping; ujungnya meledak (8 damage). |
| X | I - **Iris Surya** | 30 / 8 dtk | Mata memanas, lalu **sinar panas dari kedua mata** selama 2 detik, mengikuti arah pandangan. Menembus sampai 3 musuh (5 damage tiap 0,2 detik, terbakar 5 detik), berhenti di blok pertama: tanahnya hangus, salju & es di ujung sinar meleleh. |
| C | N - **Napas Salju** | 30 / 9 dtk | Menarik napas dalam, lalu menghembus angin beku berbentuk kerucut (12 blok) selama 2 detik: musuh **membeku** (efek beku vanila sampai menggigil), melambat, apinya padam; air di ujung hembusan jadi es, api padam. |
| V | T - **Tepukan Guruh** | 35 / 12 dtk | Lengan terentang lebar, lalu tepukan menggelegar: **gelombang suara** berlapis melesat ke depan (14 blok, ±50°): 18 damage, terhempas jauh, limbung 2 detik, dan **proyektil di depan terpental balik**. Dinding debu tersapu. |
| B | A - **Amukan Kilat** | 30 / 7 dtk | Melesat ke musuh di depan, lalu **rentetan pukulan secepat kilat** (kepalan meninggalkan bayangan cahaya) yang menahan musuh di tempat: 4 pukulan 8 damage, ditutup pukulan 18 damage yang melambungkannya. |
| N | N - **Napak Langit** | 40 / 15 dtk | Di tanah: melompat tinggi, meringkuk di puncak, lalu **menukik** kepalan duluan. Sedang terbang: langsung menukik. Hantaman di tanah: 26 damage dalam 7 blok, musuh terlempar, tiang cahaya, dan tanah retak. |
| R | G - **Gelegar Surya** | 150 / 60 dtk | Lengan menyilang menyerap cahaya (0,8 detik), lalu **membakar SEMUA cahaya tersimpan** (sisa 100) jadi ledakan surya 16 blok: 18 + 0,03 per cahaya yang dibakar (cahaya penuh ±45), terbakar, silau 3 detik, terhempas. Lalu **Mode Surya** 12 detik: pukulan ×1,5 & tiap pukulan menembakkan tombak cahaya ke 2 musuh lain, tiap detik tombak cahaya menyambar 2 musuh terdekat, damage diterima ×0,8, lari +20%. Sesudahnya cahayamu tinggal sedikit, jadi kekuatanmu menyusut sampai terisi lagi. |
| M | **Serap Surya** | gratis / 25 dtk | Lengan terangkat menyerap cahaya langit: **tiang cahaya** menghunjam, +300 energi & +120 darah, debuff & api hilang, musuh dalam 6 blok kena 16 damage dan silau. Di bawah tanah (atau dekat Batu Kelam) cuma +120 energi & +40 darah, tanpa tiang cahaya. |
| J | **Selamatkan** | 80 / 45 dtk | Melesat ke **semua sekutu** dalam 24 blok (villager, hewan peliharaan, golem besi, pemain lain; yang paling terluka duluan, paling banyak 8): masing-masing pulih 20 darah, dapat perisai (Absorption II & Resistance II 10 detik), dan musuh di sekitarnya terhempas (10 damage). |

**Pasif (padanan juara lain):**

| Pasif | Lintang |
|---|---|
| Tiap 2 detik | **Serapan Cahaya**: sinar matahari turun menyentuh dada (+100 energi, +40 darah, armor pulih, perisai, muatan penuh). **Malam hari di bawah langit: cahaya bintang biru pucat, separuhnya.** Padam di bawah tanah / di dalam ruangan, di Nether & End, dan dekat Batu Kelam (cahaya meredup ada animasinya). |
| Muatan | **Muatan Cahaya**, 2× di bawah matahari |
| Pukulan penuh | **Tinju Fajar**: damage ×1,75, ledakan cahaya & tiang cahaya di sasaran, terbakar & terhempas, tombak cahaya menyambar sampai 3 musuh lain (14 damage) |
| Bertahan tiap 1,8 detik | **Tepisan Beku**: serangan ditepis (0 damage) oleh tangan yang dingin membeku; penyerang kena 6 damage, membeku, melambat, dan terdorong |
| Makhluk tak berdosa diserang | Hati Pahlawan versi Lintang (tombak cahaya ke penyerangnya, pukulan +25% 8 detik) |

**Tampilan:** kostumnya memakai jubah, mantel, dan hood yang sama dengan juara lain, tapi dengan bahan orisinal: kain **biru toska tua**, lapisan dalam **kuning keemasan** yang kontras, list & aksesori **platina**, dan **lambang matahari delapan sinar** 3D di dada & punggung jubah. Matanya selalu bercahaya samar putih keemasan dan menyala penuh saat Iris Surya. Siang hari butiran cahaya keemasan naik dari badannya; malam hari kilau bintang biru pucat. Saat Mode Surya badannya berkorona. Jejak terbangnya meninggalkan kilau bintang.

**SFX baru (14 suara, 22 file, buatan sendiri lewat `tools/sfx/synth.py`):** `solar_pulse`, `heat_vision`, `frost_breath`, `sonic_clap`, `speed_dash`, `dawn_punch`, `barrage`, `solar_flare`, `sun_strike`, `sun_call`, `transform_lintang`, `lintang_rite`, `kelam_hum`, `frost_parry`. Puncak `solar_flare`, `sun_call`, dan `lintang_rite` jatuh tepat di tick hantaman animasinya.

**Menyetel:** angka badan, energi, dan kelemahan (`LINTANG_*`) ada di bagian atas `ShazamPowers.java`. Angka tiap skill, Daya Surya, dan Batu Kelam ada di bagian atas `LintangSkills.java`. Sebaran bijih ada di `data/shazammod/worldgen/` (`kelam_ore`). Palet kostum ada di `client/render/FormLook.java`, dan efeknya di `client/fx/LintangFx.java`.

**Perintah tes baru:**
- `/shazam unlock lintang [pemain]` / `/shazam lock lintang [pemain]`: membuka / mencabut Lintang.
- `/shazam rite [pemain]`: mulai Penyatuan Bintang di tempat, tanpa kristal & tanpa syarat matahari.
- `/shazam form lintang [pemain]`: memilih Lintang (kalau sudah didapat).

**Belum ada di versi ini:** Rival Lintang (AI) dan juara kedua (tiran dunia cermin yang justru kuat dari Batu Kelam) beserta event bosnya menyusul di 0.33. `/shazam rival lintang` sengaja ditolak sampai AI-nya ada.

## Yang baru di 0.31: Restu Para Dewa (scaling Shazam)

Di komik dan film, Black Adam unggul di kekuatan mentah, tapi ujung-ujungnya Shazam yang lebih kuat. Sekarang begitu juga di mod ini: angka dasar Shazam **tetap di bawah Black Adam**, tapi selama bertarung keenam dewa terus menuangkan kekuatannya ke juara yang mereka pilih. Darah, damage yang diterima, dan tinju Shazam naik terus sampai **melampaui angka mentah Black Adam**.

| | Shazam awal | Black Adam (tetap) | Shazam, restu penuh |
|---|---|---|---|
| Darah | 300 | 350 | **400** |
| Damage yang diterima | 40% | 35% | **30%** |
| Tinju tangan kosong | 40 (critical 60) | 44 (critical 66) | **50 (critical 75)** |
| Bentrokan Juara (damage Rival Juara) | 100% | 100% | **75%** |

**Cara kerjanya:**
- **+1 tumpukan tiap 2 detik bertarung**, paling banyak **20** (penuh sesudah ±40 detik). Tiap tumpukan: darah maksimal +5 (darah barunya langsung terisi), damage yang diterima -0,5%, tinju +0,5.
- **Melampaui Black Adam di ketiga angka mulai tumpukan ke-11** (±22 detik bertarung): darah 355, damage diterima 34,5%, tinju 45,5. Tinjunya saja sudah lebih keras dari Black Adam mulai tumpukan ke-9.
- **Bertarung** = memukul musuh atau diserang musuh dalam 8 detik terakhir (serangan yang dihindari Refleks Mercury juga dihitung). Musuh = monster, pemain lain, Rival Juara, atau makhluk apa pun yang sedang mengincarmu. Memukul sapi atau villager nggak dihitung.
- **Petir alam / trisula Channeling** yang diserap Penangkal Petir Hidup: **+3 tumpukan** sekaligus. Badai tetap wilayah Shazam.
- **Pertarungan reda:** ±10 detik sesudah pukulan terakhir, restu mulai luruh 1 tumpukan tiap 2 detik.
- **Hilang semua** saat balik jadi manusia, terlempar balik jadi manusia karena serangan mematikan, mati, atau keluar world. Tiap pertarungan baru, Shazam mulai lagi dari kekuatan dasarnya.
- **Tetap naik di gurun, es & salju, dan Nether**, walau Penangkal Petir Hidup padam di sana. Ini disengaja: Rival Black Adam selalu datang di gurun, jadi kalau restu ikut petir tiap 2 detik, duel paling pentingnya malah nggak pernah naik.
- **Bentrokan Juara** (damage Rival Juara) sejak 0.30 menembus tahan banting juara. Restu tetap ikut menahannya: damage-nya dikali (damage diterima sekarang / 40%), jadi tanpa restu sama persis seperti 0.30, dan di restu penuh tinggal 75%.
- **Yang nggak berubah:** kelemahan sihir (+50%), pakai senjata (damage x2), damage skill, dan semua angka Black Adam & Sabbac. Rival Shazam (AI) juga belum ikut scaling.

**Animasi & suara:** saat melampaui Black Adam dan saat restu penuh, petir menyambar badan seperti saat petir alam diserap (kilatan, tiang petir, suar, sinar dewa, listrik merambat di badan), dengan paduan suara ilahi dan suara kekuatan naik, plus kabar di action bar (restu penuh sekalian menyebut angka Shazam sekarang). Saat pertarungan reda, muncul kabar sekali bahwa restunya mulai memudar.

**HUD:** bar baru di bawah kotak S-H-A-Z-A-M: **✦ Restu Para Dewa** *x/20*, lalu angka Shazam sekarang: ❤ darah maksimal, ⛨ damage yang diterima, ✊ tinju. **Garis jingga di bar** = titik Shazam melampaui Black Adam; begitu lewat, barnya jadi lebih terang dan muncul tulisan *▲ di atas Black Adam*. Penuh: barnya berkedip. Bar darah di atas hotbar ikut menunjukkan darah maksimal yang baru.

**Menyetel:** semua angkanya (`FAVOR_*`) ada di bagian atas `ShazamPowers.java`, di bawah angka Shazam yang lain: tumpukan maksimal, tambahan tiap tumpukan, jeda naik & luruh, lama dihitung "bertarung", tambahan dari petir alam, dan `FAVOR_VS_CHAMPIONS` (`false` = restu nggak ikut menahan Bentrokan Juara). Garis jingga di HUD dan kabar "melampaui Black Adam" dihitung ulang otomatis dari angka-angka itu, jadi tetap tepat walau angka Shazam atau Black Adam diubah. Logikanya ada di `ShazamFavor.java`.

**Perintah tes baru:** `/shazam favor <0-20>` mengatur tumpukan Restu Para Dewa (harus sedang berwujud Shazam). Dianggap sedang bertarung selama 8 detik, lalu luruh seperti biasa kalau nggak ada musuh.

**Cara ngetes cepat:** `/shazam unlock`, ucapkan SHAZAM, lalu `/shazam favor 11` untuk melihat garis jingganya terlewati, atau `/shazam rival black_adam` lalu bertarung terus sambil memperhatikan bar restu dan darah maksimal naik tiap 2 detik.

## Yang baru di 0.30: Sabbac (juara enam iblis) & Rival Juara

### Sabbac: kekuatan dari api neraka

Juara ketiga, lawan Shazam di film Black Adam. Kalau Shazam dari petir para dewa dan Black Adam dari matahari Aton, **Sabbac dari api neraka enam iblis**: **S**atan (kekuatan), **A**ym (tubuh tak tertembus), **B**elial (belenggu), **B**eelzebub (napas api), **A**smodeus (teror), **C**rateis (sayap api). Kekuatannya setara dua juara lain (angka-angkanya di bawah), tapi sumbernya kebalikan Black Adam: **paling kuat dalam gelap**.

**Cara mendapatkannya:**
1. Cari **Bijih Eternium** di Nether (di batu Nether: netherrack, basalt, blackstone; ketinggian 10-110, ±3 urat kecil per chunk, separuhnya tersembunyi dari udara). Butuh beliung **berlian** atau lebih baik. Bijihnya berpendar merah samar. Silk Touch = bijihnya, Fortune = lebih banyak Eternium mentah. Peti benteng Nether & bastion juga kadang berisi Eternium.
2. Lebur **Eternium Mentah** di tungku (20 detik) atau blast furnace (10 detik) jadi **Batangan Eternium**.
3. Craft **Mahkota Sabbac**: 5 Batangan Eternium + 1 Tengkorak Wither Skeleton:

       E W E
       E E E

4. Klik kanan mahkotanya **dalam wujud manusia, jauh dari matahari** (malam hari, di gua atau di dalam ruangan, saat hujan, atau di Nether/End; di bawah matahari iblisnya nggak mau datang): **Perjanjian Enam Iblis** (4 detik). Lingkaran neraka menyala di tanah, mahkota berpendar merah di antara kedua tanganmu, enam lidah api menyala satu per satu di enam penjuru sementara keenam iblis bicara di chat, lalu petir neraka menyembur naik dari bawah kakimu dan mahkotanya lebur ke dalam darahmu. Sabbac terbuka.
5. Ketik `sabbac` di chat (atau tombol G) untuk berubah. Kata `shazam` tetap untuk Shazam & Black Adam; kalau salah kata, muncul pengingat. Punya lebih dari satu juara? Tombol K ganti urut Shazam → Black Adam → Sabbac.

**Ritual berubah: enam iblis datang** (jadwal & tempatnya sama dengan dewa Shazam & Mesir):
- **Satan**: tanah retak membara, raja iblis raksasa bertanduk domba menyeruak dari bawah tanah dengan kedua lengan terangkat.
- **Aym**: pusaran api neraka, tubuh obsidiannya yang berurat magma terbakar muncul dari kaki ke kepala, lalu obor nerakanya diangkat tinggi.
- **Belial**: raja kurus berjubah panjang tersingkap dari kegelapan, dari tanduk ke kaki, sementara rantai membara menyeruak dari tanah di sekelilingnya.
- **Beelzebub**: kawanan lalat berpusar makin rapat lalu memadat jadi penguasa lalat bermata majemuk dengan empat sayap serangga.
- **Asmodeus**: tanah meledak dalam semburan api dan iblis bertanduk tiga mendarat di tengahnya sambil meraung, surai api di tengkuknya.
- **Crateis**: menukik dari langit dengan sayap kelelawar bertepi api, lalu mendarat.

Lalu bukan kepalan ke langit: kedua kepalan menghantam tanah, dan **petir neraka merah-hitam merambat NAIK dari bawah kaki** (dibungkus asap hitam) sampai menembus badan: semburan api ke langit, kubah api, cincin api, tanah terbakar. Wujud iblisnya: **tanduk melengkung** yang tumbuh di kepala (ujungnya membara), **urat bara** yang mengalir di seluruh badan, jubah hangus hitam kemerahan bertepi besi membara, pelat bahu besi, lambang segel bertanduk di dada, mata merah yang selalu membara. Tanpa hood (tanduknya nggak muat). Berdiri membungkuk seperti binatang buas siap menerkam; terbang dan mendarat berat seperti Black Adam.

**Badan & kekuatan dasar:**

| | Shazam | Black Adam | Sabbac |
|---|---|---|---|
| Darah | 300 | 350 | 325 |
| Damage yang diterima | 40% | 35% | 38% |
| Tinju tangan kosong | 40 | 44 | 42, plus **menyulut sasaran 2 detik** |
| Ukuran | +10% | +10% | **+20%** |
| Pulih darah / detik | 3 | 2 (×3 di bawah matahari) | 2 (**×2,5 di kegelapan**) |
| Energi saat berwujud juara | -1/detik (badai: naik) | -1,5/detik (di bawah matahari: +1) | -1,5/detik (**di kegelapan: +1**) |
| Isi energi (wujud manusia) | 5/detik (badai ×4) | 4/detik (matahari ×3) | 4/detik (**kegelapan ×3**) |

*Kegelapan* di tabel ini dan di bawah = **malam hari, di Nether, atau di End** (kebalikan matahari Black Adam). Di gua pada siang hari denyut Api Neraka tetap menyala (lihat di bawah), tapi bonus kegelapan ini nggak.

**Skill (tombol sama dengan Shazam & Black Adam):**

| Tombol | Skill | Biaya / cooldown | Isinya |
|---|---|---|---|
| Z | S - **Tanduk Setan** | 25 / 4 dtk | Menggaruk tanah seperti banteng (tanduk membesar & menyala), lalu menyeruduk lurus sampai 14 blok. Musuh di jalur kena 10 damage dan tersangkut di tanduk (sampai 4 ikut terbawa), lalu dilempar tinggi di ujung serudukan (26 damage). |
| X | A - **Tubuh Aym** | 70 / 40 dtk | Kulit membatu jadi obsidian berurat magma selama 7 detik: damage tinggal 20%, yang memukul dari dekat terbakar. Di akhir cangkangnya pecah: **Letusan Aym** = 12 + 2× damage yang tertahan (maks 80) dalam 7 blok. |
| C | B - **Rantai Belial** | 30 / 15 dtk | Cakar mencakar tanah, rantai neraka membara menyeruak di bawah sampai 8 musuh yang terlihat (16 blok), membelit, lalu menyeret mereka ke depan Sabbac. Yang terbelenggu menerima +25% damage dari Sabbac selama 8 detik. |
| V | B - **Napas Beelzebub** | 35 / 8 dtk | Menarik napas, lalu menyemburkan api neraka berbentuk kerucut selama 2 detik (12 blok, 5 damage tiap 0,2 detik, terbakar 5 detik), dengan kawanan lalat hitam di dalam semburan. |
| B | A - **Teror Asmodeus** | 40 / 30 dtk | Raungan teror: musuh dalam 14 blok terhempas, lemah & lambat, dan **lari ketakutan** 5 detik. Sabbac sendiri dapat keberanian jahat: pukulan +40% selama 8 detik dan debuff terhapus. Pemain yang dekat ikut melihat layarnya menggelap. |
| N | C - **Kepakan Crateis** | 30 / 6 dtk | Sayap api terbentang, satu kepakan dahsyat (16 damage, terbakar, terhempas jauh dalam 9 blok, proyektil ikut terhempas), lalu Sabbac terangkat dan langsung terbang. Selama terbang, sayap apinya tetap terbentang. |
| R | **Gerbang Neraka** (amarah) | 150 / 60 dtk | Membesar jadi raksasa (+60% ukuran) di tengah lingkaran neraka, enam semburan petir neraka di enam penjuru. 12 detik: pukulan ×1,6 dan tiap pukulan meledakkan tiang api neraka, damage yang diterima ×0,8, tiap detik api neraka menyembur dari tanah di bawah 3 musuh terdekat, cincin api menjilat di kaki. |
| M | **Panggil Petir Neraka** | gratis / 25 dtk | Telapak menekan tanah, lalu petir neraka menyembur naik menembus badan: +220 energi, +120 darah, api & debuff hilang, musuh dalam 6,5 blok kena 20 damage dan terbakar. |
| J | **Pasukan Iblis** | 200 / 60 dtk | Lengan dihantamkan ke tanah, tanah terbelah membentuk lingkaran neraka, dan **6 prajurit iblis** (kerangka hangus bertanduk berurat bara) bangkit dari api, bertarung untukmu 30 detik (memburu monster, mengikutimu), lalu runtuh jadi bara. HUD menunjukkan berapa yang masih bertarung. Nggak bisa di Peaceful. |

**Pasif (padanan Shazam & Black Adam, angkanya sama):**

| Pasif | Shazam | Black Adam | Sabbac |
|---|---|---|---|
| Tiap 2 detik | Penangkal Petir Hidup | Cakram Aton | **Api Neraka**: tanah retak menyala di bawah kaki, api & petir neraka menyembur naik menelan badan: +100 energi, +40 darah, armor pulih, perisai, muatan penuh. **Di Nether** apinya juga membakar monster dalam 4,5 blok (8 damage). |
| Muatan | Muatan Petir, 2× saat hujan | Muatan Surya, 2× di bawah matahari | **Muatan Neraka**, 2× di kegelapan |
| Pukulan penuh | Pukulan Guntur | Tinju Aton | **Tinju Neraka**: damage ×1,75, ledakan api neraka, sasaran terbakar 4 detik & terhempas, rantai neraka menyambar sampai 3 musuh lain (14 damage) dan menyeret mereka ke sasaran |
| Bertahan tiap 1,8 detik | Refleks Mercury (menghindar) | Tangkisan Kahndaq (menahan, mendorong) | **Kulit Bara**: serangan ditelan bara (0 damage), penyerang kena 10 damage, terbakar 3 detik, dan **terseret rantai mendekat** |
| Makhluk tak berdosa diserang | Hati Pahlawan | Pelindung Kahndaq | **Pemburu Neraka**: rantai neraka mencap penyerangnya (terbakar 2 detik), pukulan +25% selama 8 detik |

**Pasif tiap 2 detik padam & menyala** (lanjutan 0.29): Api Neraka **padam di bawah matahari** (siang, langit terbuka, nggak hujan) dan **di dalam air**. Menyala di malam hari, di gua & di dalam ruangan, saat hujan, di End, dan **paling kuat di Nether**. Padam: lidah api tersendat makin kecil lalu asap (di air: uap). Menyala lagi: cincin api menyala dari tanah lalu naik ke dada. HUD: simbol ✹ abu-abu saat padam, tulisan ☾ *Kegelapan Neraka* di samping bar energi selama dalam kegelapan.

**SFX baru (21 suara, 35 file):** `transform_sabbac`, `hellfire_pulse`, `hellfire_punch`, `sabbac_engulf`, `hellfire_out`, `hellfire_in`, `horns_windup`, `horns_charge`, `aym_shell`, `aym_burst`, `belial_chains`, `beelzebub_breath`, `asmodeus_roar`, `crateis_wings`, `hellgate_windup`, `hellgate_open`, `legion_rise`, `demon_call_windup`, `demon_call`, `sabbac_pact`, `rival_arrive`. Semuanya buatan sendiri (`tools/sfx/synth.py`): deru & gemeretak api, geraman iblis yang sangat rendah, paduan suara iblis yang sumbang, rantai besi, batu obsidian, dengung lalat, bisikan enam iblis. Ancang-ancang panjangnya pas dengan tick ancang-ancang animasinya.

### Rival Juara: juara AI yang datang menantang

Shazam, Black Adam, atau Sabbac versi AI datang sebagai **bos** dan bertarung dengan **skill yang sama persis** dengan milik pemain: gerakan, efek, suara, dewa/iblis yang datang saat berubah, dan pasif tiap 2 detiknya (lengkap dengan aturan padam/menyala). Di client rival digambar sebagai pemain boneka, jadi jubah, lambang, tanduk, pose, dan semua efek skill pemain langsung berlaku untuknya.

**Kapan & di mana** (cuma ke pemain yang sudah punya paling nggak satu juara, bukan Creative & bukan Peaceful):

| Rival | Datang di |
|---|---|
| **Black Adam** | Gurun atau badlands, siang hari, di bawah langit terbuka & nggak hujan (matahari Kahndaq) |
| **Shazam** | Saat badai petir, di bawah langit terbuka |
| **Sabbac** | Malam hari di Overworld, atau di Nether |

Dicek tiap 30 detik dengan peluang 5% (rata-rata ±10 menit di tempat yang cocok). 5 menit pertama sesudah masuk world nggak ada rival, dan sesudah satu rival (kalah, menang, atau pergi) yang berikutnya baru bisa datang 20 menit kemudian.

**Alurnya:**
1. **Datang**: petir menyambar (atau semburan api neraka untuk Sabbac), gelombang kejut, dan judul tantangan di layar. Rival menyapa lewat chat.
2. **Berubah wujud** seperti pemain: dewa/iblisnya datang satu per satu, lalu petir menyambar. Selama ritual dia kebal.
3. **Menunggumu berubah wujud** (rival cuma mau melawan juara). Manusia biasa nggak bisa melukainya. Kalau kamu nggak berubah dalam 30 detik, atau kabur lebih dari 72 blok, dia pergi sambil mengejek.
4. **Duel**: darah 1200 (boss bar), terbang mengejar, tinju 20 tiap 0,7 detik, dan semua skill juaranya dengan damage ×0,6. Damage antar-juara (**Bentrokan Juara**) menembus armor dan tahan banting juara, dan yang kena dapat **Luka Juara**: pulihnya tinggal setengah selama 5 detik. Berlaku dua arah. Rival Sabbac juga membangkitkan prajurit iblis yang memburumu.
5. **Kalah**: kekuatannya tercabut dari dada (animasi terlempar balik jadi manusia), lalu dia menghilang dan meninggalkan **hadiah** + 600 XP: Rival Black Adam → **Skarabe Teth-Adam**, Rival Sabbac → **3 Batangan Eternium**, Rival Shazam → **satu totem penjaga** acak. **Menang** (kamu terlempar balik jadi manusia): dia pergi sambil mengejek.

**Skin rival:** taruh skin 64×64 (format skin pemain) di `assets/shazammod/textures/entity/rival/shazam.png`, `black_adam.png`, atau `sabbac.png` lewat resource pack, maka rival itu memakainya. Tanpa itu rival memakai skin bawaan Minecraft (kostum juaranya dari lapisan mod, sama seperti pemain).

**Menyetel:** peluang, jeda, dan jarak datang ada di `RivalSpawner.java` (`ENABLED = false` = rival cuma datang lewat perintah); darah, tinju, dan jarak kejar di `RivalChampion.java`; damage skill (`SKILL_DAMAGE`) dan jeda antar-skill di `RivalMoves.java`; Luka Juara (`WOUND_TICKS`, `WOUND_HEAL_MULTIPLIER`) di `ShazamPowers.java`. Angka Sabbac ada di `ShazamPowers.java` (`SABBAC_*`) dan `SabbacSkills.java`, sebaran bijih di `data/shazammod/worldgen/`.

### Perintah tes baru

- `/shazam unlock sabbac [pemain]` / `/shazam lock sabbac [pemain]`: membuka / mencabut Sabbac.
- `/shazam pact [pemain]`: mulai Perjanjian Enam Iblis tanpa mahkota & tanpa syarat matahari.
- `/shazam rival <shazam|black_adam|sabbac> [pemain]`: memanggil Rival Juara itu sekarang juga (syarat tempat & jeda dilewati).
- `/shazam form sabbac [pemain]`: memilih Sabbac (kalau sudah didapat).

## Yang baru di 0.29: pasif tiap 2 detik padam di tempat & waktu tertentu

Pasif tiap 2 detik dua juara sekarang bergantung pada sumber kekuatannya. Yang padam cuma denyut tiap 2 detik itu (energi, darah, armor, perisai, muatan penuh otomatis); pasif lain seperti menghindar, menahan, Hati Pahlawan, dan keluarga tetap jalan. Muatan juga masih bisa diisi lewat pukulan, dipukul, dan terbang.

| | Padam di | Kenapa |
|---|---|---|
| **Black Adam** (Cakram Aton) | **Malam** (matahari terbenam di tick 12542, terbit lagi di tick 23460), juga **Nether & End** | Kekuatannya dari matahari Aton |
| **Shazam** (Penangkal Petir Hidup) | **Gurun & badlands** (biome panas yang nggak pernah hujan) | Udaranya terlalu kering untuk petir |
| | **Es & salju** (tempat yang turun salju, bukan hujan, termasuk puncak gunung yang dingin) | Hawa beku memadamkan petir |
| | **Nether** | Langit petir nggak sampai ke sana |

Keadaannya harus bertahan 1 detik dulu sebelum berganti, jadi nggak berkedip-kedip saat berjalan di batas biome. Kalau berubah wujud di tempat atau waktu yang padam, cuma muncul kabar di action bar tanpa animasi.

**Animasi:**
- **Cakram Aton terbenam** (1,6 detik): cakram turun ke balik punggung Black Adam sambil mengecil dan memerah seperti matahari di cakrawala, mahkota sinarnya menguncup, bara berjatuhan dari cakram, asap tipis, dan cahaya senja jingga melebar pelan di tanah lalu padam. Layar sedikit menggelap.
- **Cakram Aton terbit** (1 detik): cakram naik dari balik punggung sambil membesar dan berubah dari merah ke emas, mahkota sinarnya mekar, sinar dewa memancar, bara naik ke cakram, lalu mekar hangat. Denyut pertama datang tepat sesudahnya.
- **Petir Shazam padam** (1,3 detik): mata & lambang berkilat untuk terakhir kali lalu meredup, listrik di badan tersendat dalam tiga gelombang yang makin lemah, sisa listrik dibuang ke tanah, percikan sekarat berjatuhan, dan beberapa kedipan terakhir. Jejaknya ikut tempatnya: **gurun** berdebu pasir, **es** berembun beku dan berkilau, **Nether** berasap dan berabu.
- **Petir Shazam kembali:** begitu keluar dari tempat itu, petirnya langsung menyambar lagi. Sambaran itulah animasi kembalinya.

**HUD:** simbol ⚡ (Shazam) dan ☀ (Black Adam) di kotak muatan jadi abu-abu selama pasifnya padam. Sejak 0.29.1 isi kotaknya juga ikut abu-abu, supaya ikon abu-abunya tetap terbaca walau muatannya penuh.

**SFX baru:** `rod_fade` (listrik tersendat-sendat lalu habis, deru yang turun seperti mesin mati, desis terakhir), `aton_set` (deru api yang meredup dan menutup, bara makin jarang, hembusan terakhir), dan `aton_rise` (hawa panas bangkit dan mekar hangat tepat di detik ke-1).

**Menyetel:** jam terbit/terbenam dan batas suhu gurun ada di `PassiveConditions.java`; lama animasinya (`SUN_SET_TICKS`, `SUN_RISE_TICKS`, `ROD_FADE_TICKS`) ada di `ShazamAnim.java`; jeda anti-berkedip (`STATE_HOLD`) ada di `ShazamPassives.java`.

## Yang baru di 0.28: Black Adam setara Shazam (0.28.1: kekuatannya dari matahari Aton)

Sejak 0.25-0.26 Shazam dapat banyak pasif kuat, sementara Black Adam cuma unggul di angka dasar. Sekarang Black Adam dapat **padanan semuanya dengan angka yang sama persis**. Sejak 0.28.1 semuanya **bersumber dari matahari Aton, bukan petir**, jadi dua juara ini terasa beda: Shazam = petir & badai, Black Adam = matahari, api, & pasir Kahndaq.

| Pasif | Shazam (petir) | Black Adam (matahari Aton) |
|---|---|---|
| Tiap 2 detik | Penangkal Petir Hidup: petir emas menyambar dada | **Cakram Aton**: cakram matahari emas melayang di atas kepalanya. Tiap 2 detik sinar-sinarnya yang **berujung tangan** (lambang Aten Mesir kuno) terulur menyentuh bahu & dadanya, lalu cakramnya **menyembur cahaya & api matahari**. Angkanya sama: +100 energi, +40 darah, armor pulih, perisai 10 hati emas, muatan penuh |
| Muatan | Muatan Petir ⚡, 2x saat hujan | **Muatan Surya** ☀, 2x di bawah matahari |
| Pukulan penuh | Pukulan Guntur: petir dari langit, merambat ke 3 musuh | **Tinju Aton**: damage x1,75, sasaran **terbakar 4 detik** dan terhempas jauh, sorot matahari & ledakan api di sasaran, semburan api membakar sampai 3 musuh lain (14 damage) |
| Bertahan tiap 1,8 detik | Refleks Mercury: serangan **dihindari** | **Tangkisan Kahndaq**: serangan **ditahan kulit 100%**, lalu panas matahari menyembur balik: penyerang kena 10 damage, **terbakar 3 detik**, dan terdorong |
| Makhluk tak berdosa diserang | Hati Pahlawan: tautan petir, pukulan +25% | **Pelindung Kahndaq**: sorot cahaya matahari ke penyerangnya, pukulan +25% selama 8 detik |
| Sekutu dalam 10 blok | Keluarga Shazam: Resistance I | Sama (rakyat & sekutu Kahndaq) |
| Petir alam / Channeling | Diserap jadi kekuatan | Tetap cuma kebal (kekuatannya dari matahari) |
| Tombol J | Kekuatan Keluarga | Tangan Kahndaq |

Efek denyut Cakram Aton: tiang cahaya matahari, kilatan hangat, dua cincin panas naik dari kaki ke kepala, gelombang panas & pasir tersibak di tanah, bekas terbakar, bara beterbangan, badan berpendar seperti emas yang dipanaskan, mata & lambang menyala, dan badan tersentak. Kepalan yang penuh muatan membara (bara & kilau matahari), bukan berlistrik. Dari sudut pandang orang pertama semuanya diredam dan cakram di atas kepala nggak menyilaukan.

Keunggulan Black Adam yang lama tetap ada: darah 350, damage diterima 35%, kebal proyektil, tinju 44, pulih 6/detik di bawah matahari, Panggil Petir Kahndaq (M), dan Tangan Kahndaq (J).

**HUD Black Adam:** dua kotak sesudah ✋, yaitu ☀ Muatan Surya (terisi dari bawah, berkedip "SIAP" saat penuh) dan ⛨ Tangkisan Kahndaq (sisa jeda dengan satu angka di belakang koma).

**SFX baru (cara 0.27.1, tapi berbahan api, bukan listrik):** gemeretak api dibuat dari letupan pendek yang jarang (beda dengan percikan listrik yang rapat), deru api dari noise rendah yang bergolak, dan semburan api dari deru yang terbuka cepat lalu meredup. Hasilnya hangat dan nyaris tanpa desis frekuensi tinggi, jelas beda dengan petir Shazam.

| Suara | Isinya |
|---|---|
| `aton_pulse` (3 varian) | Panas terhisap ke cakram (0,15 detik), lalu **semburan cahaya & api tepat di tick denyut**, dentum hangat, bara gemeretak, dengung panas |
| `aton_punch` (2 varian) | Hantaman berat & remuk kecil, lalu ledakan api matahari dan bara yang beterbangan |
| `adam_block` (2 varian) | Dentuman tertahan di kulit sekeras batu, lalu semburan panas & desis bara |

**Menyetel:** angka denyut (`ROD_*`) berlaku untuk kedua juara; tangkisan (`BLOCK_SHOCK_DAMAGE`, `BLOCK_FIRE_SECONDS`, `BLOCK_KNOCKBACK`) dan `SUN_FIRE_SECONDS` ada di bagian atas `ShazamPassives.java`. Tampilan cakram (`DISK_HEIGHT`, `DISK_RADIUS`, `HAND_RAYS`, kilatan layar) ada di bagian atas `client/fx/AtonFx.java`.

## Yang baru di 0.27.1: SFX baru dirombak total

Lima suara baru dari 0.25-0.27 (11 file) dibuat ulang dari nol dengan pendekatan lain. Suara lama terlalu banyak desis noise dan nada sintetis (sine yang menyapu, lonceng, paduan suara buatan), jadi terdengar murah.

- **Guntur dari model fisika.** Kanal petir dibuat berliku seperti petir sungguhan (jalan acak 3D, rata-rata belok 16 derajat per ruas, dengan cabang). Tiap ruasnya memancarkan gelombang kejut (gelombang-N) yang paling kuat tegak lurus ruasnya. Ruas yang dekat tiba duluan sebagai retakan tajam; ruas yang jauh tiba belakangan, gelombangnya lebih panjang (lebih rendah), dan frekuensi tingginya terserap udara, jadi gemuruhnya terbentuk sendiri. Ditambah pantulan tanah, tekstur gemeretak di tiap pulsa, dan gemuruh padat yang mengikuti kerapatan pulsanya.
- **Listrik dari percikan sungguhan.** Kereta impuls rapat yang tak beraturan dengan badan 350-1400 Hz dan resonansi logam elektroda ("bzzt", bukan "tsss"), bertebaran pendek-pendek dengan letupan keras sesekali.
- **Dentum** dari sub yang anjlok, "dada" 80-200 Hz, dan badan pink noise, lalu disaturasi supaya tetap terasa di speaker HP atau laptop.
- **Gema ruang terbuka:** frekuensi rendah bergema lebih lama dari yang tinggi.
- **EQ akhir:** sub dikurangi, frekuensi tengah dinaikkan, dan desis di atas 7 kHz diredam.

| Suara | Isinya sekarang |
|---|---|
| `rod_strike` (3 varian) | Gemuruh yang dibalik & percikan pemandu yang makin rapat (0,15 detik), retakan guntur **tepat di tick hantaman**, dentum di dada, listrik merayap di badan, tenaga terhisap masuk. Ekor < 2 detik. |
| `family_windup` | Guntur yang dibalik terhisap ke kepalan, angin tertarik, listrik makin rapat, tekanan naik; memuncak tepat di tick sambaran (0,5 detik). |
| `family_strike` (2 varian) | Lima petir hampir bersamaan (kepalan Shazam + empat anggota keluarga di jarak berbeda), dentum besar, tiupan kuningan rendah D mayor yang samar, listrik meredup. |
| `adam_catch` (3 varian) | Desing peluru mendekat, lalu DIHENTIKAN paksa (dentum pendek, cekat listrik, tekanan udara), lalu dengung medan listrik yang menahan. |
| `adam_release` (2 varian) | Tarikan napas, kibasan tangan, petir membara, dentum, enam proyektil melesat menjauh. |

Waktunya nggak berubah: retakan `rod_strike` tetap di 0,15 detik dan puncak `family_windup` tetap di 0,5 detik, jadi tetap pas dengan animasinya. Kerasnya disamakan dengan SFX lain di mod. Resepnya ada di `tools/sfx/synth.py` (bagian 0.27.1).

## Yang baru di 0.27: Tangan Kahndaq (Black Adam, tombol J)

Diambil dari adegan paling terkenal di film *Black Adam* (2022): peluru dan rudal berhenti di udara di depannya, lalu dia mengembalikannya ke penembaknya.

**Pasif (selalu aktif dalam wujud Black Adam):** proyektil yang meluncur ke arahnya **berhenti di udara**. Syaratnya proyektil itu dalam 7 blok dan lintasannya lewat dekat badan. Yang bisa ditangkap: panah, panah spektral, trisula, bola api ghast & blaze, tengkorak wither, bola api naga, wind charge breeze, ramuan lemparan penyihir, dan ludah llama.

Proyektil itu lalu ditarik pelan ke lingkaran 2,2 blok di sekeliling badan, melayang naik-turun dan ikut ke mana Black Adam bergerak. Tiap proyektil terikat busur petir membara dari telapak kanannya, yang terangkat menahan semuanya. Paling banyak 16 sekaligus. Mutiara ender, kail pancing, kembang api, peluru shulker, dan botol XP nggak ditangkap.

**Tombol J:** Black Adam menarik tangannya lalu mengibaskannya keluar, dan **semua proyektil yang tertahan melesat balik**:

| | |
|---|---|
| Sasaran | Penembaknya, kalau penembak itu monster dan masih hidup. Kalau penembaknya pemain, sekutu, atau sudah mati: monster terdekat dalam 40 blok. Kalau nggak ada sasaran sama sekali, proyektilnya dilempar menjauh. |
| Kecepatan | 3,2 blok/tick, lurus tanpa gravitasi selama 1,5 detik, dengan jejak petir membara |
| Panah | Jadi kritis dan damage-nya 1,5x |
| Petir membara | Tiap proyektil yang mengenai monster memanggil petir dari langit, +8 damage |
| Bola api / ramuan | Meledak atau memecah di sasaran seperti biasa, tapi sekarang milik Black Adam |

Tanpa menekan J, proyektil dikembalikan otomatis 3 detik sesudah tertangkap. Proyektil yang terlalu cepat untuk ditangkap tetap memantul dari kulit seperti dulu.

**HUD:** kotak ke-9 Black Adam (✋) menunjukkan jumlah proyektil yang sedang tertahan, dan menyala saat ada isinya.

**SFX baru:** `adam_catch` dan `adam_release` (dirombak di 0.27.1, lihat di atas).

**Menyetel:** angka ada di bagian atas `AdamCatch.java` (`CATCH_RADIUS`, `MAX_HELD`, `HOLD_TICKS`, `HOLD_DISTANCE`, `RETURN_SPEED`, `RETURN_BONUS`). Efeknya di `client/fx/AdamCatchFx.java`, gerakannya di `Clips.java` (`ADAM_HOLD`, `ADAM_RELEASE`).

**Cara ngetes:** jadi Black Adam, `/summon skeleton` tiga ekor sekitar 15 blok darimu, biarkan mereka menembak, lalu tekan J.

## Yang baru di 0.26: Kekuatan Keluarga (tombol J)

Diambil dari klimaks film *Shazam!* (2019): Billy membagi kekuatannya ke saudara-saudaranya dan petir menyambar mereka semua bersamaan.

**Cara pakai:** dalam wujud Shazam, tekan **J** saat ada keluarga dalam 16 blok. Yang dihitung keluarga: pemain lain, hewan peliharaan (anjing, kucing, burung beo), kuda jinak, villager, golem besi, dan golem salju. Biayanya 200 Energi Petir, cooldown 60 detik. Kalau nggak ada keluarga di sekitar, energinya nggak terpakai.

**Urutannya (sinematik):**
1. **Ancang-ancang (0,5 detik):** Shazam membungkuk menghimpun tenaga lalu mengangkat kepalan kanan ke langit. Cahaya emas terhimpun di kepalan, listrik merayap di badan, dan tautan petir emas menyambung dari dadanya ke tiap anggota keluarga, makin tebal.
2. **Sambaran:** petir sihir menyambar **seluruh keluarga dan kepalan Shazam bersamaan**. Ada kilatan putih & emas, cincin cahaya naik dari kaki ke kepala tiap anggota, gelombang emas di tanah, dan suar lensa. Shazam tersentak lalu membuka kedua lengannya lebar-lebar.
3. **Juara kecil (30 detik):** tiap anggota berpendar emas dengan bara naik dan listrik kecil merayap di badannya.

**Kekuatan yang dibagi (30 detik):**

| Kekuatan | Angka bawaan |
|---|---|
| Efek | Kekuatan II, Cepat II, Tahan II, Pulih II, kebal api |
| Darah | Langsung pulih separuh dari penuh |
| Pukulan berpetir | Tiap serangan anggota keluarga ke monster +50%, dan paling sering tiap 1 detik dipanggilkan petir kecil dari langit (+6 damage). Panah dari teman juga dihitung. |

Penjaga dewa yang jadi musuh (golem bumi Atlas) nggak dihitung keluarga. Paling banyak 12 anggota terdekat yang disambar sekaligus.

**HUD:** kotak **♥** baru di samping Refleks Mercury. Emas berarti siap (dengan nama tombolnya), abu-abu berarti sisa cooldown.

**SFX baru:** `family_windup` (memuncak tepat di tick sambaran) dan `family_strike` (dirombak di 0.27.1, lihat *Yang baru di 0.27.1*).

**Menyetel:** angka ada di bagian atas `ShazamFamily.java` (`RADIUS`, `COST`, `COOLDOWN_TICKS`, `DURATION_TICKS`, `EFFECT_LEVEL`, `HEAL_FRACTION`, `HIT_MULTIPLIER`, `HIT_BOLT_DAMAGE`, `MAX_FAMILY`). Efeknya di `client/fx/FamilyFx.java`, gerakannya di `Clips.java` (`FAMILY_CALL`).

**Cara ngetes:** jinakkan dua-tiga anjing (atau ajak teman), jadi Shazam, tekan J, lalu `/summon zombie` di dekat mereka.

## Yang baru di 0.25.1: petir & dash dipertebal

**Petir Penangkal Petir Hidup** (`client/fx/RodStrikeFx.java`):
- Petirnya 1,6 kali lebih tebal (`SIZE` 2,0, mendekati petir SHAZAM! yang 2,4), dengan korona emas yang sangat lebar di sekelilingnya.
- Dua untai petir membelit kanal utama dan berputar seperti tali plasma (`STRANDS`), menyatu di dada.
- Petirnya bertahan lebih lama dan berkedip empat kali (dulu tiga). Cabangnya lebih banyak dan bercabang lagi.
- Tiang cahaya berdiri dari tanah ke langit saat menghantam, dan listrik melilit badan berbentuk spiral naik dari kaki ke kepala (`COCOON_TICKS`).
- Gelombang kejut, busur listrik di tanah, bekas hangus, percikan, dan guncangan kamera dibuat lebih besar.

**Dash Refleks Mercury** (`ChampionFx.dodge`):
- Kilatan, suar lensa, gelombang kejut, dan debu tersibak di titik lepas.
- Jejak cahaya biru selebar 1,6 blok dengan inti putih.
- Tiga untai petir biru-putih (kaki, pinggang, dada) yang menyambung dari titik lepas ke badan sepanjang lesatan.
- Listrik biru merayap di badan selama melesat, bayangan berjejak dua kali lebih banyak, dan cincin percikan saat tiba.

Semua tetap diredam dari sudut pandang orang pertama supaya layar nggak tertutup. Angkanya ada di bagian atas `RodStrikeFx.java` dan di atas fungsi `dodge` di `ChampionFx.java` (`DODGE_GHOST_TICKS`, `DODGE_TRAIL`, `DODGE_STRANDS`).

## Yang baru di 0.25: petir menyambar Shazam tiap 2 detik

Pasif **Penangkal Petir Hidup** dirombak. Dulu cuma menyerap petir alam (dan sesekali badai memanggil petir ke Shazam). Sekarang **tiap 2 detik petir sihir turun dari langit menyambar dada Shazam**, di mana pun: siang, malam, hujan, di dalam ruangan, atau sambil terbang.

| Tiap sambaran | Angka bawaan |
|---|---|
| Energi Petir pulih | +100 (penuh 1000) |
| Darah pulih | +40 (penuh 300) |
| Armor pulih | Armor yang dipakai (kostum Shazam atau armor apa pun) diperbaiki penuh, plus **Perisai Petir**: 10 hati emas yang diisi lagi |
| Damage naik | Muatan Petir langsung penuh, jadi pukulan tangan kosong berikutnya **Pukulan Guntur**: damage x1,75, petir dari langit, hempasan jauh, dan petir merambat ke 3 musuh lain |

Kenapa ada Perisai Petir: armor Shazam dari Atlas (armor 20, toughness 12) nggak pernah berkurang, jadi "armor pulih" dibuat kelihatan sebagai hati emas yang habis kena serangan lalu terisi lagi tiap sambaran. Perisainya hilang saat balik jadi manusia. Di HUD, perisainya tampil sebagai garis emas di bagian bawah bar darah (penuh = 20) dan angka "+20" di samping darah.

Petir alam atau trisula Channeling yang menyambar Shazam tetap diserap (lebih besar: +150 energi, +40 darah) dan menggantikan sambaran berikutnya. Panggilan badai acak yang lama (rata-rata tiap 25 detik) dibuang karena sudah diganti sambaran tiap 2 detik. Sambaran pertama datang 2 detik sesudah berubah wujud (petir SHAZAM! baru saja menyambar).

### Animasi & VFX ala film

Tiap sambaran disusun tiga ketukan seperti VFX 0.24:

1. **Petir turun (3 tick):** ujung petir yang bercahaya menukik dari awan sambil memercik mencari jalan. Badan Shazam memancarkan busur listrik ke atas menyambutnya, seperti petir sungguhan, dan listrik mulai merayap di badan.
2. **Hantaman:** petir tebal (pendar emas, inti putih, udara terionisasi biru-putih) menyambung dari langit ke lambang di dada, sedikit miring, lalu berkedip tiga kali (sambaran balik). Awan berkilat, kilatan putih, suar lensa anamorfik, cangkang energi, gelombang kejut dan busur listrik di tanah, bekas hangus, percikan. Badan tersentak (kepala mendongak, lengan terbuka, gemetar listrik) tanpa memotong skill, pukulan, atau terbang yang sedang jalan. Mata dan lambang menyala putih, dan dua cincin cahaya naik dari kaki ke kepala: tenaganya pulih.
3. **Sisa:** listrik merayap di badan, kepalan berlistrik (Pukulan Guntur siap), bara dan debu tipis.

Petirnya ikut bergerak bersama Shazam, jadi tetap mengenai dada walau sedang terbang kencang. Dari sudut pandang orang pertama efeknya diredam (bagian petir yang lewat dekat kamera memudar, kilatan layar kecil) supaya layar nggak tertutup tiap 2 detik.

### SFX

Suara baru `rod_strike` (3 varian, ±1,6 detik), satu suara yang sudah di-mix (dirombak di 0.27.1):

1. Gemuruh yang dibalik dan percikan pemandu selama 0,15 detik (sama dengan 3 tick petir turun), makin rapat dan memuncak tepat di tick hantaman.
2. Retakan guntur dari model fisika tepat di tick hantaman, lalu gemeretak dan gemuruh pendek, dentum di dada.
3. Listrik yang merayap di badan dan tenaga yang terhisap masuk.

Suaranya menempel ke badan Shazam (ikut terbang) dan ekornya dijaga di bawah 2 detik, jadi sambaran berikutnya nggak menumpuk jadi bising. Resepnya fungsi `rod_strike` di `tools/sfx/synth.py`.

### Refleks Mercury: tiap 1,8 detik

Jeda Refleks Mercury (menghindar otomatis) dipercepat dari 8 detik jadi **1,8 detik**. Kotak » di HUD sekarang menampilkan sisa jedanya dengan satu angka di belakang koma.

### Menyetel

- Angka pasif ada di bagian atas `ShazamPassives.java`: `ROD_INTERVAL_TICKS` (40 = 2 detik), `ROD_ENERGY`, `ROD_HEAL`, `ROD_ARMOR_REPAIR` (1 = penuh, 0 = mati), `ROD_SHIELD` (20 = 10 hati emas, 0 = mati), `ROD_VOLUME`, dan `DODGE_COOLDOWN_TICKS` (36 = 1,8 detik).
- `ROD_SPLASH_DAMAGE` bawaannya 0: sambarannya cuma memberi kekuatan. Isi angka kalau mau petirnya ikut melukai monster dalam `ROD_SPLASH_RADIUS` blok (pemain lain, hewan peliharaan, dan villager tetap aman).
- Tampilan ada di bagian atas `client/fx/RodStrikeFx.java`: tinggi dan kemiringan petir, tebal, lama mata menyala, dan kuat kilatan layar.

### Cara ngetes

Jadi Shazam lalu tunggu 2 detik. Biar kelihatan pulihnya: `/shazam energy 300`, biarkan zombie memukulmu sampai hati emasnya habis, atau pakai armor yang sudah rusak. Refleks Mercury: biarkan dua skeleton menembakmu.

## Yang baru di 0.24.2: SFX khas tiap skill

Di 0.24.1 semua suara vanila sudah diganti, tapi masih dipakai bareng-bareng (misalnya Atlas, lemparan Hercules, dan Amon sama-sama memakai `impact`). Sekarang **tiap skill punya suara khasnya sendiri** (32 suara baru, 50 file .ogg), disusun seperti VFX 0.24 dalam dua ketukan:

1. **Ancang-ancang:** panjang file-nya **persis sama** dengan tick ancang-ancang di `ShazamAnim` (1 tick = 0,05 detik), jadi crescendo-nya memuncak tepat di tick hantaman, sama seperti energi yang terhisap di VFX.
2. **Hantaman:** satu suara yang sudah di-mix jadi satu (bukan 3-5 suara yang ditumpuk), jadi lebih tebal, lebih bersih, dan nggak pecah.

| Skill | Ancang-ancang | Hantaman |
|---|---|---|
| Z Solomon | Bisikan dan kilau yang ditarik masuk (5 tick) | Kilatan kaca "shiing", paduan suara, lonceng |
| X Tepukan Guntur | Listrik terhimpun di telapak (5 tick) | Tepukan + retakan petir, lalu **gada avatar Hercules menghantam tanah 2 tick kemudian** (sudah diatur di dalam suaranya) |
| Shift + X Lemparan | (pegangan tetap) | Lecutan + desing badan musuh yang berputar menjauh |
| C Atlas | **Langit runtuh** (13 tick): siulan benda jatuh, gemuruh, tekanan sub-bass | Hantaman + braam ala trailer + gelombang kejut + tanah runtuh |
| V Zeus | Dengung listrik yang naik (5 tick) | **Tombak petir**: lecutan, zap menukik, dentuman (lompatan berikutnya tetap petir biasa yang makin tinggi) |
| B Achilles | Tombak ditarik "shiing" (4 tick) | **Pekik perang**: tiupan terompet perang + hentakan kaki, tusukan tombak 1 tick kemudian |
| Ledakan Keberanian | - | Ledakan emas, paduan suara mayor |
| R Badai Para Dewa | Badai terhimpun, paduan suara menarik napas (9 tick) | Braam mayor heroik + paduan suara + **enam lonceng untuk enam dewa** |
| Pukulan Guntur | - | Pukulan + sambaran + guntur |
| Refleks Mercury | - | Kedipan secepat kilat |
| Shu | - | Pusaran pasir yang berputar 50 tick, lalu ledakan pasir |
| Heru | Merunduk (3 tick) | **Pekik elang** + desing terjangan, pendaratan berpasir |
| Amon | Melompat, gemuruh naik (7 tick) | Dua kepalan menghantam + erangan tanah terbelah |
| Zehuti | Bisikan gelap yang ditarik masuk (5 tick) | Gong gelap + paduan suara minor |
| Aton | Cakram matahari terbentuk (8 tick) | Sinar matahari yang membakar (3 varian) |
| Mehen | Getar ekor ular dari bayangan (6 tick) | Lilitan yang meremas, gigitan taring |
| R Murka Kahndaq | Amarah tertahan: detak jantung makin cepat (10 tick) | **Raungan** + braam gelap + retakan petir |
| M Panggil Petir | Langit bergemuruh (12 tick) | (petir Kahndaq) |

Suara vanila yang masih tersisa di skill (raungan ravager & warden, halaman buku, taring evoker, cermin illusioner) sudah hilang semua. Lapisan suara di client yang jadi dobel dengan suara khas ini juga dibuang. Roh Heru dan Mehen saat ritual transformasi ikut memakai suara khasnya.

Mau menyetel satu skill: ubah resepnya di `tools/sfx/synth.py` (fungsi dengan nama yang sama), lalu jalankan `python3 tools/sfx/synth.py src/main/resources/assets/shazammod/sounds atlas_windup atlas_slam`. Kalau mengubah tick ancang-ancang di `ShazamAnim`, panjang `d` di fungsi `*_windup` ikut diubah supaya puncaknya tetap pas. Daftar suara ada di `tools/sfx/names.txt`; `python3 tools/sfx/gen.py` membuat ulang `ShazamSounds.java`, `sounds.json`, dan subtitle-nya.

## Yang baru di 0.24.1: SFX sinematik ala film

VFX 0.24 tetap persis sama; yang dirombak cuma **suaranya**. Dulu tiap skill memakai suara bawaan Minecraft (guntur vanila, ametis, suar, kucing mendesis, landasan) yang nadanya diturunkan. Sekarang semuanya diganti **33 SFX buatan sendiri** (72 file .ogg di `assets/shazammod/sounds/`, 2-3 varian per suara supaya nggak monoton) yang disusun seperti sound design film: transien tajam di depan, badan yang tebal, sub-bass di bawah, dan ekor gema yang panjang.

| Suara baru | Dipakai untuk | Menggantikan |
|---|---|---|
| `thunder` | Guntur petir sihir: retakan, gemuruh bergulung 6-8 detik, sub-bass | Guntur vanila |
| `lightning_strike` | Sambaran: derak listrik, dengung busur, dentuman | Dampak petir vanila |
| `impact`, `impact_ring`, `shockwave` | Hantaman Atlas, lemparan Hercules, Amon, pendaratan | Mace, landasan, ravager |
| `punch`, `punch_crit`, `body_hit` | Pukulan Mercury, serangan dewa, Pukulan Guntur | Serangan pemain, golem besi |
| `whoosh`, `whoosh_heavy`, `sonic_boom` | Terjangan, kepakan sayap dewa Mesir, sonic boom terbang | Phantom, naga Ender, warden |
| `power_up`, `power_down`, `charge`, `energy_pulse` | Bangkit/redupnya kekuatan, tenaga terkumpul | Suar, jangkar respawn |
| `aura_swell`, `divine` | Ritual para dewa, Ledakan Keberanian | Conduit, totem |
| `shimmer`, `resonance`, `spell` | Sihir Solomon/Zehuti, rune, lambang | Ametis, meja enchant |
| `dark_hiss`, `dread`, `heartbeat` | Sihir gelap Black Adam, Ujian Kahndaq | Kucing mendesis, elder guardian, warden |
| `sand_burst`, `earth_crack`, `fire_blast` | Pasir Shu, retakan Amon, api Aton | Pasir, deepslate, blaze |
| `wind_loop`, `cape_snap` | Angin saat terbang, hood dipasang | Elytra, armor kulit |

Ada juga lapisan baru di momen-momen besar:

- **Transformasi:** *riser* yang memuncak selama petir sihir turun pelan (panjangnya otomatis pas dengan slow motion), lalu hantaman **"SHAZAM!"**: retakan petir + braam + sub-bass + gemuruh, dengan ekor paduan suara ilahi (Shazam) atau dengung gelap (Black Adam).
- **Braam ala trailer** di hantaman Atlas, pembuka Badai Para Dewa, dan pembuka Murka Kahndaq.
- **Balik jadi manusia / tumbang:** kekuatan meredup terdengar jelas.

Suara makhluk penjaga totem (raungan, erangan) sengaja dibiarkan suara aslinya. Semua SFX punya subtitle (en_us & id_id).

Pengaturan: `PITCH_UP_FOLLOW` dan `PITCH_DOWN_FOLLOW` di `ShazamSounds.java` (seberapa jauh nada ikut angka pitch di kode; angka pitch lama disetel untuk suara vanila, jadi dijinakkan supaya SFX baru nggak melar atau cempreng). Mau balik ke suara vanila untuk satu efek? Ganti `ShazamSounds.X.get()` di baris itu dengan `SoundEvents.Y`.

Semua suara dibuat dari nol dengan skrip `tools/sfx/synth.py` (Python + numpy/scipy + ffmpeg), jadi bebas lisensi. Mau ubah resepnya: edit fungsinya, lalu `python3 tools/sfx/synth.py src/main/resources/assets/shazammod/sounds` (atau tambahkan nama suara di belakangnya untuk membuat ulang yang itu saja).

## Yang baru di 0.24: VFX sinematik ala film

Tiap skill Shazam sekarang disusun seperti adegan film dalam tiga ketukan, dan tiap ketukan **dikunci ke frame animasi yang sudah ada** (gerak badan Shazam di `client/anim/Clips.java` dan gerak avatar dewa), jadi gerakan, efek, dan damage terjadi di tick yang sama:

1. **Ancang-ancang:** energi terhisap ke tangan atau ke pusaka dewa yang sedang ditarik ke belakang, makin deras, dengan listrik kecil yang menari dan cahaya inti yang membesar, lalu **memuncak tepat di tick hantaman**.
2. **Hantaman:** kilatan inti putih, **suar lensa anamorfik** (garis cahaya mendatar seperti lensa kamera film), gelombang udara berlapis (muka gelombang putih tipis yang cepat, gelombang berwarna, cincin debu di tanah), percikan, guncangan kamera menurut jarak, dan untuk pemain sendiri kilatan layar & sentakan pandangan.
3. **Sisa:** listrik merayap di tangan, bara & asap mengendap, cahaya meredup pelan.

| Skill | Ancang-ancang | Hantaman (tick) | Yang terlihat |
|---|---|---|---|
| Z Solomon | Dua jari ke pelipis: cahaya ungu terhisap ke mata, kitab avatar Solomon menyala | 5 | Suar ungu melintang di mata, berkas cahaya dari langit, lalu pindaian |
| X Tepukan Guntur | Kedua telapak dan gada avatar Hercules menghimpun guntur | 5 (tepukan), 7 (gada menyentuh tanah) | Hantaman di antara telapak, lalu hantaman kedua di titik gada avatar menghantam tanah, listrik sisa di tangan |
| Shift + X | Tenaga terkumpul di tangan selama mengangkat musuh | 9 (lempar), saat menabrak | Suar di tangan, jejak cahaya, hantaman berlapis di titik jatuh |
| C Atlas | Berkas cahaya langit turun ke pusat gravitasi, kepalan yang menyangga langit membara, bola langit jatuh | 13 | Hantaman terbesar: kilatan inti, suar 8 blok, gelombang berlapis, pilar cahaya |
| V Zeus | Petir di tangan Shazam dan di tangan avatar Zeus menghimpun tenaga | 5 | Zeus **melempar tombak petir** bersamaan dengan petir dari jari dan guntur dari langit; suar di tiap sasaran. Jari Shazam sekarang menunjuk tepat di tick 5 (dulu tick 7, terlambat dari petirnya) |
| B Achilles | Tombak avatar menghimpun cahaya | 4 (raungan), 5 (tusukan) | Kaki menghentak tanah, lalu berkas tombak cahaya 9 blok dan kerucut udara melesat ke depan |
| Ledakan Keberanian | Cahaya emas terhisap ke dada | 2 | Hantaman berlapis dan suar emas raksasa |
| R Badai Para Dewa | **Pita film masuk**, energi badai terhisap ke dada selama membungkuk | 9 | **Kartu judul "BADAI PARA DEWA"**, kilatan inti, suar 10 blok, berkas cahaya enam warna dewa turun di tempat tiap dewa berdiri |
| Transformasi | **Pita film** selama ritual; berkas cahaya dari langit mengiringi petir sihir yang turun | 18 | Suar lensa raksasa di kepalan dan **kartu judul "SHAZAM!"** |

Pukulan Guntur, Refleks Mercury, Penangkal Petir Hidup, dan tiap serangan dewa di lingkaran Badai Para Dewa juga dapat suar lensa (dan berkas cahaya langit untuk petir alam yang diserap). Black Adam ikut dapat pita film saat ritual & Murka Kahndaq, kartu judul "SHAZAM!" (emas membara) dan "MURKA KAHNDAQ".

Pita film dan kartu judul cuma tampil di layar pemain yang melakukannya. Pengaturan: `FLARES` dan `GOD_RAYS` di `client/fx/CineFx.java` (0 = mati), `CINEMA_BARS`, `TITLE_CARDS`, dan `BAR_HEIGHT` di `client/fx/ScreenFx.java`.

## Yang baru di 0.23: Shazam, juara para dewa

Di 0.22 Black Adam dapat jalan, badan, dan efek sendiri. Sekarang giliran Shazam. Black Adam itu tank yang buas: kulitnya memantulkan proyektil, kekuatannya dari matahari, gerakannya berat. Shazam dibuat jadi kebalikannya: **pahlawan yang lincah, dilindungi para dewa, dan kekuatannya dari badai**. Tiap skill punya mekanik yang nggak dimiliki Black Adam, ada lima pasif baru, dan satu identitas visual yang cuma dia punya: **para dewa ikut bertarung**.

### Avatar Dewa

Tiap skill Shazam memanggil dewanya sebagai raksasa cahaya tembus pandang (±4 blok) yang berdiri di belakang Shazam dan bergerak bersamanya. Bentuknya sama dengan roh dewa saat transformasi.

| Skill | Yang dilakukan dewanya |
|---|---|
| Z Solomon | Membuka kitab dan mengangkat tangan memberkati, lalu segel bintang segi enam raksasa terproyeksi ke depan |
| X Hercules | Melompat dari belakang lalu menghantamkan gada tepat saat tepukan. Saat Lemparan Hercules, gadanya diayunkan ke arah lemparan |
| C Atlas | Mengangkat bola langit tinggi-tinggi selama bola langit jatuh |
| V Zeus | Melayang di atas bahu dan membidikkan petir di tangannya ke sasaran |
| B Achilles | Merunduk lalu menusukkan tombak tepat saat raungan, dan sekali lagi saat Ledakan Keberanian |
| R Badai Para Dewa | Keenam dewa berdiri melingkar, berputar pelan, dan menerjang tiap kali giliran serangannya tiba |

Dari sudut pandang orang pertama, avatar pindah ke samping-depan supaya tetap kelihatan. Avatar bisa dimatikan lewat `ENABLED` di `client/fx/GodAvatars.java` (roh dewa saat transformasi tetap ada).

Avatar nggak cuma membidik: tiap serangan punya **ancang-ancang lalu hantaman**. Pusakanya ditarik ke belakang-atas kepala (gada Hercules terangkat tinggi, petir Zeus ditarik ke belakang, tombak Achilles ditarik), lalu tepat saat damage masuk dicambuk ke sasaran dengan sedikit kebablasan, badan dewanya menerjang ke depan, dan tubuhnya berkilat. Di antara serangan, avatar melayang naik-turun pelan. Dewa di lingkaran Badai Para Dewa juga menerjang keluar dari lingkaran tiap giliran serangannya, lalu kembali ke tempatnya.

### Dewa-dewa Shazam makin keren

Berlaku untuk avatar saat skill dan untuk roh dewa saat ritual transformasi.

- **Proporsi heroik:** Hercules, Atlas, Zeus, dan Achilles berbahu dan berdada lebih lebar dengan lengan & kaki lebih kekar (Hercules lengan +17%, Atlas +20%). Kulit Hercules lebih hangat (dulu pucat kehijauan).
- **Jubah panjang berkibar:** Solomon memakai mantel kerajaan ungu sampai tanah, Zeus jubah badai biru berlist emas, Achilles jubah merah sampai betis, Mercury jubah yang terangkat makin tinggi saat berlari. Kibarannya merambat dari bahu ke ujung, dan tepi bawahnya berlist emas yang menyala.
- **Cahaya ilahi:** urat-urat energi bercahaya mengalir naik di badan, gelombang cahaya menyapu dari kaki ke kepala tiap ±5 detik, tepi atas badan berkilau, dan kaki sedikit lebih gelap dari kepala supaya badannya terasa menjulang.
- **Lingkaran suci khas tiap dewa:** Solomon bintang segi enam yang berputar dengan permata di tiap sudut, Hercules surai matahari, Atlas rasi bintang yang mengorbit, Zeus mahkota enam petir zig-zag yang berganti bentuk, Achilles matahari enam belas sinar tajam, Mercury sepasang sayap cahaya yang mengepak.

Bentuk ada di `client/fx/GodFigures.java` (`godCape` dan angka badan di bagian `Body`), cahaya & lingkaran suci di `client/fx/GodLook.java` (`divine` dan `halo`), gerak avatar di `client/fx/GodAvatars.java`.

### Pasif baru (khusus Shazam)

| Pasif | Cara kerja |
|---|---|
| **Muatan Petir** | Memukul musuh (+9), kena serangan (+4), terbang kencang, berlari dengan Mode Kilat, dan berdiri di bawah badai mengisi muatan listrik di badan. Saat kehujanan semuanya masuk 2x. Penuh (100) = kepalan berlistrik dan pukulan tangan kosong berikutnya jadi **Pukulan Guntur**: petir dari langit, damage x1,75, hempasan jauh, dan petir merambat ke 3 musuh lain (14 damage). |
| **Refleks Mercury** | Sekali tiap 8 detik (0.25: tiap 1,8 detik), satu serangan (pukulan, panah, bola api, sonic boom) dihindari: Shazam melesat ke samping secepat kilat meninggalkan bayangan. Ledakan, jatuh, dan api nggak dihindari. Black Adam menahan serangan, Shazam menghindarinya. |
| **Hati Pahlawan** | Villager, hewan peliharaan, atau pemain lain diserang monster dalam 24 blok: tautan cahaya emas mengarah ke penyerangnya, penyerang itu bersinar dan terbaca (+25% damage dari Shazam), dan Shazam dapat **Amarah Pahlawan** (pukulan +25% selama 8 detik). |
| **Keluarga Shazam** | Pemain lain, villager, dan hewan peliharaan dalam 10 blok dapat Resistance I. |
| **Penangkal Petir Hidup** | Petir alam atau trisula Channeling yang menyambar Shazam diserap: +150 energi, +40 darah, dan Muatan Petir langsung penuh. Di bawah badai petir, sesekali (rata-rata tiap 25 detik) petir datang sendiri menyambar Shazam. **0.25: dirombak, petir menyambar tiap 2 detik di mana pun (lihat *Yang baru di 0.25*).** |

### Skill dirombak

| Tombol | Skill | Mekanik baru | Biaya / cooldown |
|---|---|---|---|
| Z | **S - Kebijaksanaan Solomon** | Pindaian 48 blok seperti dulu (bersinar, +25% damage dari Shazam), ditambah: damage dari musuh yang terbaca tinggal **60%** (gerakannya sudah terbaca), dan **sihir pelindung mereka terhapus** (tak terlihat, kekuatan, kecepatan, pulih, dan efek baik lain). | 40 / 30 detik |
| X | **H - Tepukan Guntur Hercules** | Kerucut 9 blok, 20 damage dan terhempas, musuh **limbung** 2,5 detik (Slowness III + Weakness), dan **panah, bola api, serta proyektil lain di dalam kerucut hancur**. Petir menjalar di sepanjang kerucut. | 25 / 4 detik |
| Shift + X | **H - Lemparan Hercules** | Musuh di depan (sampai 5,5 blok, darah maksimal 200) diangkat ke atas kepala lalu **dilempar** ke arah pandangan. Begitu menabrak tanah, dinding, atau musuh lain: yang dilempar kena 26 damage dan musuh dalam 3,8 blok kena 18 dan terhempas. Tanpa musuh di depan: jadi Tepukan Guntur biasa. | sama dengan X |
| C | **A - Beban Langit Atlas** | Di tanah: kepalan diangkat menyangga langit, **bola langit berbintang raksasa jatuh**, musuh dalam 10 blok **tersedot ke pusat**, lalu kepalan menghantam: yang di tengah (6,5 blok) kena 30 damage dan **tertekan ke tanah** (terkunci 3 detik), yang di pinggir kena 10 dan terhempas keluar. Dari udara: menukik seperti meteor, hantaman yang sama saat mendarat. | 40 / 8 detik |
| V | **Z - Petir Berantai Zeus** | Petir keluar dari ujung jari (seperti di film) ke musuh yang dibidik lalu **melompat ke sampai 5 musuh lain** (7 blok tiap lompatan, damage turun 15% tiap lompatan). **Musuh basah** (di air atau kehujanan) kena 2x dan lompatannya lebih jauh. Tiap sasaran juga disambar **guntur dari langit di saat yang sama** dengan petir dari jari: sasaran pertama +14 damage dan gunturnya ikut menyambar musuh di sekitarnya, sasaran berikutnya +6. | 30 / 3 detik |
| B | **A - Perisai Achilles** | Hampir kebal 6 detik seperti dulu, ditambah: musuh dalam 14 blok **dipancing menyerang Shazam** (melindungi sekutu), perisai matahari emas di depan dada, dan semua damage yang ditahan perisai **dilepas di akhir sebagai Ledakan Keberanian** (12 + damage tertahan x2,5, maksimal 90, dalam 7,5 blok). | 80 / 45 detik |
| N | **M - Mode Kilat Mercury** | Tetap (sudah unik). | - |
| R | **Badai Para Dewa** | Pengganti Zeus Rage (yang dulu hampir kembar dengan Murka Kahndaq). Enam petir menyambar di enam penjuru, awan badai berputar di atas kepala, dan **keenam dewa mengelilingi Shazam selama 12 detik**. Tiap detik dua dewa bergiliran S-H-A-Z-A-M menyerang musuh terdekat dalam 14 blok dengan gayanya sendiri: Solomon menyegel (8 damage, terbaca), Hercules menghantamkan gada (16, terhempas), Atlas menjatuhkan bola langit kecil (14, terkunci), Zeus menyambar (14), Achilles menusukkan tombak cahaya (18, lemah), Mercury menerjang dua kali (9 + 9). Pukulan tetap +50% dan berpetir, lari lebih cepat. | 150 / 60 detik |

### Black Adam vs Shazam sekarang

| | Shazam | Black Adam |
|---|---|---|
| Gaya | Pahlawan lincah, para dewa ikut bertarung | Tank buas, berat, lugas |
| Bertahan | Menghindar (Refleks Mercury), membaca musuh (Solomon), menahan lalu membalas (Achilles) | Kulit memantulkan proyektil, damage diterima 35%, lilitan Mehen |
| Sumber kekuatan | Badai, hujan, dan petir alam | Matahari Kahndaq |
| Pasif unik | Muatan Petir, Pukulan Guntur, Hati Pahlawan, Keluarga Shazam, Penangkal Petir Hidup | Proyektil memantul, Berkah Aton, listrik membara di kulit |
| Kendali massa | Menyedot ke tengah (Atlas), melempar musuh (Hercules), memancing (Achilles) | Pusaran (Shu), segel (Zehuti), tanah terbelah (Amon) |
| Ultimate (R) | Badai Para Dewa: enam dewa bergiliran menyerang | Murka Kahndaq: petir membara memburu musuh |

### HUD

Di samping kotak S-H-A-Z-A-M ada dua kotak baru (khusus Shazam): **⚡ Muatan Petir** yang terisi dari bawah dan berkedip *SIAP* saat penuh, dan **» Refleks Mercury** yang biru saat siap mengelak (abu-abu dengan sisa detik saat belum siap).

### Cara ngetes cepat

- **Pukulan Guntur:** pukul monster 11 kali dengan tangan kosong, atau berdiri di bawah badai/hujan. Saat penuh ada pesan di atas hotbar.
- **Refleks Mercury:** biarkan skeleton menembakmu.
- **Hati Pahlawan:** `/summon zombie` di dekat villager atau serigala peliharaan.
- **Penangkal Petir Hidup:** (0.25) cukup jadi Shazam dan tunggu 2 detik. Petir alam: `/weather thunder`, atau minta teman melempar trisula Channeling ke arahmu saat badai.
- **Lemparan Hercules:** tahan Shift lalu tekan X sambil menghadap monster dalam 5 blok.

Angka-angkanya ada di bagian atas `ShazamPassives.java` (pasif), `ShazamSkills.java` (skill), dan `client/fx/GodAvatars.java` (ukuran, kepekatan, dan lingkaran avatar). Efek baru di `client/fx/ChampionFx.java`.

## Yang baru di 0.22: Black Adam beda total dari Shazam

Black Adam sekarang bukan sekadar "Shazam warna hitam". Cara mendapatkannya beda, badannya beda, kekuatannya beda, dan semua efek & animasi skill-nya ditulis ulang supaya tebal dan sinematik seperti di film.

### Dua jalan, dua juara

| | Shazam | Black Adam |
|---|---|---|
| Dipilih oleh | Penyihir di Batu Keabadian | Dewan Kahndaq (enam dewa Mesir) |
| Syarat | Kalahkan enam penjaga kuil, kumpulkan keenam totemnya | Temukan Skarabe Teth-Adam, lulus Ujian Kahndaq |
| Cara membuka | Ucapkan SHAZAM sambil membawa keenam totem | Klik kanan skarabe di gurun/badlands (wujud manusia, langit terbuka) |
| Tempat | Di mana saja | Tanah Kahndaq: gurun atau badlands |

- Dua juara terpisah: punya yang satu belum tentu punya yang lain. Tombol **K** (ganti juara) baru berfungsi kalau kamu sudah punya dua-duanya.
- Save dari 0.21 yang memilih Black Adam tanpa ujian otomatis memakai Shazam sampai Black Adam didapat lewat jalannya (buat ngetes: `/shazam unlock black_adam`).

#### Jalan Shazam: enam totem

1. Kalahkan enam penjaga kuil (Solomon, Hercules, Atlas, Zeus, Achilles, Mercury). Untuk sekarang penjaganya dimunculkan dengan telur spawn (tab Creative) atau `/shazam summon <nama>`.
2. Tiap penjaga menjatuhkan totemnya. Kumpulkan keenamnya di inventory.
3. Ucapkan **SHAZAM** (ketik di chat atau tombol G). Keenam totem terangkat dan berputar mengelilingimu sebagai enam cahaya berwarna (ungu Solomon, hijau pucat Hercules, jingga Atlas, emas Zeus, emas pucat Achilles, biru muda Mercury), menyatu jadi bintang emas di atas kepala, lalu petir Penyihir menyambar. Totemnya habis terpakai, dan kekuatan Shazam terbuka.

#### Jalan Black Adam: Skarabe Teth-Adam & Ujian Kahndaq

1. **Temukan Skarabe Teth-Adam** (jimat kumbang emas berpermata pirus). Ada di peti **Piramida Gurun** (Desert Temple), peluang 30% tiap peti (satu piramida punya 4 peti), atau sesekali (2%) dijatuhkan Husk yang kamu kalahkan di gurun.
2. Bawa ke **gurun atau badlands**, berdiri di bawah **langit terbuka**, dalam **wujud manusia**, lalu **klik kanan** skarabenya. (Nggak bisa di Peaceful.)
3. **Ujian Kahndaq** dimulai: skarabe diangkat ke langit, lingkaran hieroglif menyala di tanah, badai pasir raksasa melingkari tanah ujian, dan **Bayangan Teth-Adam** (siluet bertudung dari asap setinggi ±12 blok, mata membara, lambang petir samar di dada) menjulang di dalam badai sambil bersuara di chat. Tiga gelombang makhluk makam menyeruak dari pasir:
   - Gelombang 1: 5 Prajurit Makam Kahndaq (Husk berhelm emas).
   - Gelombang 2: 3 Prajurit Makam berpedang emas + 6 Kumbang Skarabe.
   - Gelombang 3: **Penjaga Makam Teth-Adam**, Husk raksasa setinggi ±4,5 blok (darah 220, berzirah & berpedang emas), ditemani 2 prajurit.

   Bar di atas layar menunjukkan gelombang dan sisa musuh (di gelombang 3: darah sang penjaga).
4. **Lulus:** badai runtuh ke dalam, enam cahaya dewa Mesir mengorbit, skarabe naik ke atas kepala lalu menyatu ke dadamu, dan petir Kahndaq menyambar. Kekuatan Black Adam jadi milikmu (langsung terpilih sebagai juara).
5. **Gagal** kalau kamu mati, keluar dari game, pergi lebih dari 40 blok dari titik mulai, berubah wujud, atau lewat 5 menit. Makhluk makam runtuh jadi pasir dan skarabe tertidur lagi. Skarabenya tetap ada, jadi bisa dicoba lagi.

Ujian ini untuk manusianya, bukan juaranya: pakai zirah & senjata terbaik dan bawa makanan.

### Black Adam vs Shazam: badan & kekuatan

| | Shazam | Black Adam |
|---|---|---|
| Darah | 300 | **350** |
| Damage yang diterima | 40% | **35%** |
| Panah, trisula, bola api, peluru mod lain | kena (40%) | **memantul** (kebal; percikan & denting di titik kena) |
| Pulih darah | 3/detik | 2/detik, **6/detik di bawah matahari** |
| Energi Petir saat berwujud juara | -1/detik, +2/detik saat badai petir | -1,5/detik, **+1/detik di bawah matahari** |
| Energi Petir sebagai manusia | +5/detik, x4 saat badai petir | +4/detik, **x3 di bawah matahari** |
| Sumber kekuatan (HUD) | Badai petir ("Badai!") | Matahari Kahndaq ("☀ Berkah Aton") |
| Tombol M | Auto-hit Mode Kilat | **Panggil Petir Kahndaq** |
| Tinju | 40 | 44, hempasan lebih jauh, percikan petir di tiap pukulan |
| Pendaratan keras | gelombang kejut | radius x1,35, damage x1,3, tanah retak membara & kubah petir |
| Terbang | lincah: barrel roll, kepalan di depan seperti Superman | berat & lugas: dorongan menghentak, berhenti mendadak lalu melayang tegak; lengan lurus di sisi badan; nggak berguling, tapi melesat menyamping meninggalkan bayangan membara |
| Berdiri diam | kepalan di pinggang | lengan bersilang di dada seperti firaun, dagu terangkat |
| Mata | menyala saat skill/amarah | selalu membara samar emas |
| Kulit | - | listrik membara samar merayap di kulit, bara naik pelan |

"Di bawah matahari" = siang hari, nggak hujan, dan langit terbuka di atas kepala.

### Kostum Black Adam

- **Kalung lebar Mesir (usekh)** di atas mantel: pita emas, deretan manik pirus, pita emas lebar beralur, dan rumbai liontin tetes emas & pirus. Menggantikan pelat bahu, bros, dan rantai Shazam.
- **Gelang lengan (bracer) emas tebal** di kedua lengan bawah, dengan permata pirus dan alur petir.
- **Sabuk emas lebar** dengan gesper berpermata pirus.
- Tetap: hood, jubah, dan mantel hitam legam berlapis merah marun, lambang petir emas di dada & punggung.

### M: Panggil Petir Kahndaq (khusus Black Adam)

Kepalan kanan diangkat ke langit, awan gelap berputar di atas kepala, busur listrik naik dari kepalan, lalu petir sihir menyambar badan sendiri: kubah petir, tiang cahaya, tanah retak, dan listrik membelit badan dari kaki ke kepala.

- Energi Petir +220, darah +120, api padam, efek penghambat hilang.
- Musuh dalam 6,5 blok kena 20 damage petir dan terhempas.
- Gratis (tanpa energi), cooldown 25 detik. Kotak ke-8 di HUD (ϟ).

### Efek & animasi skill Black Adam ditulis ulang (gaya film)

Semua efek lebih tebal: petir emas-jingga bercabang dengan inti putih panas, listrik merayap di kulit sesudah tiap skill besar, gelombang kejut berlapis, kubah petir, batu & pasir beterbangan, dan kamera ikut terguncang. Gerakannya juga baru: ancang-ancang lebih dalam, hantaman lebih keras, dan tahanan sesudahnya.

- **Z Badai Shu:** badai pasir tebal setinggi 7 blok dengan inti debu gelap, petir menyambar di dalamnya, batu-batu mengorbit; badan berayun dihantam badai. Lalu badai meledak: gelombang pasir 10 blok, kubah, dan petir merambat di tanah.
- **X Sambaran Heru:** kerucut sonic & cincin uap saat melesat, sayap elang dari berkas cahaya bertepi listrik, petir yang tertinggal di sepanjang lintasan, dan musuh yang ditabrak tersambar; badan nyaris mendatar, lalu mengerem dengan sayap terbentang dan mendarat merunduk.
- **C Tinju Amon:** melonjak tinggi lalu menghantam: kubah kejut 5 blok, gelombang putih, petir merayap di tanah. Celah membaranya lebih lebar dengan petir melompat-lompat di dalamnya, **tiang-tiang batu (bertekstur tanahnya) mencuat** di kiri-kanan celah, dan debu menyembur seperti geiser. Badan berlutut gemetar menahan getaran.
- **V Segel Zehuti:** lingkaran hieroglif di kepala, gelombang hieroglif melesat ke depan, **rantai huruf cahaya** ke tiap musuh, dan **tiga cincin hieroglif** + pilar cahaya + lingkaran di tanah yang mengunci.
- **B Sinar Aton:** cakram matahari lebih besar bermahkota sinar berdenyut, garis silau, dan petir kecil berkejaran di tepinya. Sinarnya 2x lebih tebal dengan **dua pilinan petir** dan cincin panas; di sasaran ada ledakan api, bekas hangus, dan retakan. Badan tersentak tiap sinar melesat.
- **N Lilitan Mehen:** ular menyeruak dari pasir (tanah retak merah), badan ular lebih tebal, sisik lebih terang, **listrik merambat di kulit ular**, tudung kobra lebih lebar.
- **R Murka Kahndaq:** saat menahan amarah, **petir dari langit menghujani sekeliling** dan tanah retak membara. Saat meraung: kubah petir 6 blok, empat petir menyambar di empat penjuru, guncangan besar. Listrik di badan lebih tebal dan batu yang mengorbit lebih banyak.
- **Berubah wujud:** petir yang mengenai kepalan sekarang memunculkan kubah petir, hantaman tanah, dan listrik membelit badan dari kaki ke kepala selagi kostum terbentuk. Ritualnya punya lingkaran hieroglif ketiga (merah membara).
- **Terbang:** lepas landas meretakkan tanah, pendaratan menghantam dengan kubah & petir, sonic boom membara dengan petir memancar ke belakang, dan petir memercik di belakang lintasan saat ngebut.

### Perintah tes baru

- `/shazam unlock black_adam [pemain]`, `/shazam unlock shazam [pemain]`, `/shazam unlock all [pemain]` (`/shazam unlock` saja = Shazam).
- `/shazam lock black_adam|shazam|all [pemain]` (`/shazam lock` saja = dua-duanya).
- `/shazam trial [pemain]`: mulai Ujian Kahndaq di tempat, tanpa syarat gurun & langit terbuka.
- `/shazam form <juara>` sekarang cuma bisa ke juara yang sudah didapat.
- `/give @s shazammod:scarab_of_teth_adam` (skarabe juga ada di tab Creative Ingredients).

Angka-angkanya: `KahndaqTrial.java` (ujian), `ShazamPowers.java` bagian `ADAM_*` (badan & kekuatan), `AdamSkills.java` bagian `CALL_*` (Panggil Petir).

## Yang baru di 0.21: Black Adam

Sekarang ada juara kedua: **Black Adam**, juara Kahndaq. Kata ajaibnya sama (**SHAZAM**), alur berubahnya sama (dewa datang satu per satu, kepalan ke langit, petir turun pelan dalam slow motion), tapi dewanya, warnanya, skill-nya, dan pakaiannya beda total, seperti di komik: kekuatannya datang dari enam dewa Mesir.

| Huruf | Dewa Black Adam | Kekuatan |
|---|---|---|
| S | **Shu** | Stamina |
| H | **Heru** (Horus) | Kecepatan |
| A | **Amon** (Amun) | Kekuatan |
| Z | **Zehuti** (Thoth) | Kebijaksanaan |
| A | **Aton** (Aten) | Kekuasaan |
| M | **Mehen** | Keberanian |

### Cara memilih

- Tekan **K** (bisa diganti di Controls) untuk ganti juara: Shazam ⇄ Black Adam. Mulai 0.22, cuma bisa kalau kamu sudah mendapatkan dua-duanya lewat jalannya masing-masing (lihat *Yang baru di 0.22*), dan cuma dalam wujud manusia, karena petir memilih juaranya sebelum menyambar. Habis berubah/balik ada jeda 3 detik.
- Atau pakai perintah `/shazam form black_adam` (dan `/shazam form shazam` untuk balik), untuk juara yang sudah didapat. Bisa untuk pemain lain juga: `/shazam form black_adam @a`.
- Pilihannya tersimpan di save, ikut terkirim ke pemain lain (mereka lihat dewa Mesir saat kamu berubah), dan di HUD kiri atas ada tulisan juara yang dipilih.

### Ritual berubah: dewa-dewa Mesir

Black Adam berdiri tegak seperti patung firaun dengan **kedua lengan menyilang di dada (pose Osiris)**, lalu lengan pelan-pelan terbuka menerima kekuatan. Di tanah menyala **lingkaran hieroglif emas membara** dengan pasir berputar di tepinya dan asap hitam tipis merayap di kaki. Dewa-dewanya datang satu per satu, masing-masing dengan cara masuknya sendiri:

- **Shu** (dewa udara): pusaran angin bercampur pasir berputar naik, tubuhnya terbentuk dari kaki ke kepala sambil berputar melambat. Bulu burung unta tegak di kepalanya, dan kedua tangannya **menyangga langit berbintang** (tubuh dewi Nut) di atas kepala.
- **Heru** (dewa elang): **menukik dari langit seperti elang** dengan sayap terbentang, bulu-bulu cahaya gugur di belakangnya, lalu mendarat menghantam tanah. Berkepala elang dengan garis mata Wedjat, **mahkota ganda merah-putih**, sayap lebar, tongkat was dan ankh.
- **Amon** ("Yang Tersembunyi"): asap bayangan pekat menggumpal, lalu tubuhnya **tersingkap dari mahkota ke kaki**. Kulit biru, **mahkota dua bulu tinggi bergaris**, janggut dewa, tongkat was dan ankh.
- **Zehuti** (dewa kebijaksanaan): lingkaran hieroglif di tanah, tubuhnya **"dituliskan" huruf-huruf cahaya** dari bawah ke atas. Berkepala ibis berparuh panjang melengkung, **cakram bulan di atas bulan sabit**, palet juru tulis & pena buluh, dan **cincin hieroglif yang berputar** mengelilingi badannya.
- **Aton** (cakram matahari): tanah retak membara keemasan, lalu **matahari terbit dari balik tanah** sampai menyilaukan. Wujudnya cakram matahari dengan kobra uraeus, dan **sinar-sinarnya berujung tangan terbuka**, satu menyodorkan ankh (tanda kehidupan). Korona di sekelilingnya berputar pelan.
- **Mehen** (ular pelindung): tanah merekah, pasir & batu menyembur, lalu **ular raksasa bergelang emas-merah menyeruak** dari pasir, melingkar berlapis-lapis, dan menegakkan leher serta **tudung kobra**-nya sambil mendesis.

Lalu kepalan kanan diangkat ke langit (tangan kiri tetap di dada), tiap dewa mengalirkan sinar energinya lewat pusakanya (telapak Shu, tongkat Heru & Amon, pena Zehuti, ankh Aton, taring Mehen), dan **petir emas-jingga membara** turun. Saat menyambar: ledakan cahaya, pilar petir, dan **cincin asap hitam** menyapu tanah. Black Adam terangkat dengan lengan terentang, lalu turun dan berdiri buas: kepalan mengepal di samping, kepala sedikit tertunduk menatap tajam.

### Tampilan Black Adam

- **Hood, jubah, dan mantel hitam legam** (bentuk & fisika kainnya sama dengan Shazam), lapisan dalam **merah marun tua**, list & pelat bahu **emas antik** yang lebih jingga, permata **pirus** seperti perhiasan firaun.
- **Lambang petir emas** tajam di dada (3D, berkilau) dan di punggung jubah, dengan kilau emas membara.
- Kilau kostum saat terbentuk, butiran saat kostum luruh, dan semua petirnya berwarna **emas-jingga membara** (petir Shazam tetap emas cerah). Jejak terbang, lepas landas, dan hero landing juga ikut warna Black Adam.
- Mata menyala **emas membara** saat Murka Kahndaq, dan **hijau pirus** sesaat sesudah Segel Zehuti.
- HUD: bar energi & kotak skill berwarna emas membara di atas kotak gelap, huruf S-H-A-Z-A-M yang sama, dan kotak terakhir bertanda ☥ (ankh). Kotak M menyala pirus selama ular Mehen melilit.

### Skill Black Adam

Tombolnya sama dengan skill Shazam; yang keluar dewa juara yang sedang dipilih.

| Tombol | Skill | Gerakan & efek | Biaya / cooldown |
|---|---|---|---|
| Z | **S - Pusaran Shu** | Lengan terentang lalu terangkat menyangga langit. Badai pasir & angin berpilin mengelilingi badan 2,5 detik: musuh dalam 9 blok tersedot ke cincin pusaran, berputar, dan terangkat (3 damage tiap 0,5 detik), lalu pusaran **meledak ke luar** (16 damage, terhempas jauh). Stamina Shu: darah langsung pulih 30 dan dapat hati emas 16 darah (absorption) selama 30 detik. | 40 / 15 detik |
| X | **H - Sambaran Heru** | Merunduk, lalu **menerjang lurus secepat elang** sampai 18 blok ke arah pandangan (di tanah: mendatar; di udara: boleh menukik), dengan **sayap elang dari cahaya** di punggung, jejak & bayangan emas membara. Musuh di lintasan kena 24 damage dan tersibak; di titik akhir hempasan 10 damage. Berhenti sendiri sebelum menabrak tembok. | 25 / 4 detik |
| C | **A - Tinju Amon** | Melonjak dengan kedua kepalan di atas kepala, lalu **menghantam tanah**. **Tanah terbelah lurus ke depan** sampai 15 blok: celah membara merambat, batu & debu menyembur di sepanjangnya. Musuh di titik hantaman kena 14, musuh di atas celah kena **30 damage** dan terlempar ke atas. | 40 / 8 detik |
| V | **Z - Segel Zehuti** | Dua jari ke pelipis, mata menyala pirus, lalu menunjuk: gelombang hieroglif melesat. Sampai 12 musuh dalam 16 blok yang terlihat **terikat dua cincin hieroglif berputar** selama 8 detik: nyaris nggak bisa bergerak (Slowness V), lemah, lambat menambang, bersinar, dan **menerima +25% damage dari Black Adam**. | 30 / 15 detik |
| B | **A - Sinar Aton** | Telapak kanan ke langit, **cakram matahari** terbentuk di atasnya, lalu menembakkan **sinar membara (berujung tangan terbuka)** ke 6 musuh terdekat dalam 22 blok satu per satu: 20 damage petir dan terbakar 4 detik. Tanpa musuh: satu sinar ke titik yang dibidik. | 35 / 6 detik |
| N | **M - Lilitan Mehen** | Lengan menyilang di dada, lalu **ular cahaya emas-merah membelit badan** selama 8 detik: damage yang diterima tinggal 30%, debuff langsung hilang, dan tiap detik kepala ular **mematuk** 2 musuh terdekat dalam 7 blok (14 damage + racun). Siapa pun yang menyerangmu langsung dipatuk balik. | 70 / 40 detik |
| R | **Murka Kahndaq** | Badan terangkat, kepalan gemetar sementara petir membara terhisap ke badan, lalu meraung: ledakan petir (14 damage dalam 6 blok), mata emas menyala, listrik membara merayap di badan, batu terangkat mengorbit. Selama 12 detik pukulan +60% dan **tiap pukulan meledak** (musuh dekat sasaran kena 8 dan terhempas) lalu petirnya merambat ke 2 musuh lain; tiap detik petir membara memburu 3 musuh dalam 14 blok; lari lebih cepat. | 150 / 60 detik |

### Kekuatan dasar Black Adam

Sama dengan Shazam (darah 300, armor & tahan banting, kebal jatuh/api/petir, terbang, Energi Petir, terlempar balik jadi manusia kalau kena serangan mematikan), dengan sedikit beda khas Black Adam yang lebih buas:

- Pukulan tangan kosong **44** (critical 66), Shazam 40.
- Hempasan pukulan **+0,8** lebih jauh dari Shazam.
- Petir saat berubah wujud **18** damage (Shazam 12), dan menyambar 4 petir kecil di sekeliling.
- Black Adam **nggak punya Mode Kilat Mercury** (tombol M diabaikan); kecepatan Heru-nya ada di Sambaran Heru.

Angka-angkanya ada di bagian atas `AdamSkills.java` (skill) dan `ShazamPowers.java` (`ADAM_*`).

## Yang baru di 0.20: kena serangan mematikan, balik jadi manusia (nggak langsung mati)

Kalau Shazam kena serangan yang mestinya mematikan, kamu **nggak mati**: kekuatan sihirnya tercabut dari tubuh dan kamu terlempar balik jadi manusia biasa.

- **Yang dihitung damage terakhir**, sesudah dikurangi tahan banting, armor, enchantment, dan hati emas (absorption). Kalau sisanya masih menghabisi darah Shazam, damage serangan itu dibatalkan dan kamu balik jadi manusia. Serangan yang nggak mematikan tetap masuk seperti biasa.
- **Darah manusia langsung penuh 20/20**, sama seperti tiap balik jadi manusia. Ini ikut `FULL_HEAL_ON_REVERT`: kalau itu dimatikan, kamu balik dengan darah tinggal sedikit.
- **Belum bisa SHAZAM lagi selama 30 detik.** Tanpa jeda ini Shazam praktis nggak bisa mati: tinggal ucapkan SHAZAM lagi (kebal selama ritual), darah langsung penuh 300 lagi. Sisa waktunya kelihatan di HUD kiri atas (*Belum bisa SHAZAM: 23 detik*), mengucapkan SHAZAM sebelum waktunya cuma memunculkan pesan sisa detiknya, dan ada pesan begitu tubuhmu pulih. Waktu pulih ikut tersimpan, jadi keluar-masuk world nggak mempercepatnya. Kalau kamu mati beneran sebagai manusia, waktu pulihnya hilang saat respawn.
- Kalau sedang terbang, pendaratan pertama nggak sakit, sama seperti balik jadi manusia di udara.
- Totem of Undying yang kamu pegang nggak ikut kepakai (Shazam yang terlempar balik duluan), jadi totemnya tetap ada buat menyelamatkan wujud manusiamu nanti.
- Jatuh ke void dan `/kill` tetap mematikan, sama seperti saat ritual.

**Gerakan & efek:** badan terhentak ke belakang dengan lengan terlempar ke depan, lalu kekuatan tercabut dari dada: lengan terentang, kepala mendongak, gemetar hebat, semburan cahaya emas, empat busur petir lepas dari badan kembali ke langit, gelombang emas dan debu di tanah, percikan, dan kostum luruh jadi butiran cahaya emas. Lalu badan lunglai membungkuk, oleng sebentar, dan pelan-pelan tegak lagi (kaki cuma sedikit melangkah, jadi tetap wajar kalau kamu langsung kabur). Dari matamu sendiri: pandangan menggelap kemerahan, layar berguncang, lalu kilatan emas.

**Cara ngetes:** jadi Shazam, lalu ketik `/damage @s 10000` (butuh cheat). `/shazam unlock` sekalian menghapus waktu pulih, jadi bisa langsung dites ulang.

Pengaturannya ada di bagian atas `ShazamPowers.java`: `REVERT_INSTEAD_OF_DEATH` (`false` = Shazam mati seperti biasa) dan `KNOCKOUT_COOLDOWN_TICKS` (600 = 30 detik, 0 = langsung bisa SHAZAM lagi; 20 tick = 1 detik).

## Yang baru di 0.19: kekuatan mentah Shazam jauh lebih kuat

**Stat Shazam dinaikkan** supaya adu kekuatan mentah dengan Warden (mob terkuat di game) menang telak:

| | Sebelumnya | Sekarang |
|---|---|---|
| Darah | 100 | **300** (150 hati) |
| Pulih | 2 per detik | **3 per detik** |
| Armor & toughness | +10 & +6 | **+20 & +12** (setara full netherite) |
| Pukulan tangan kosong | 20 (critical 30) | **40 (critical 60)** |
| Kecepatan pukulan | penuh tiap 0,25 detik | **penuh tiap 0,2 detik** |
| Pakai senjata | biasa | **damage senjata x2** |
| Terpental | +1,5 | **+2,5** |
| Mode Kilat Mercury ke bos | 40 per pukulan | **60 per pukulan** |

Damage yang diterima tetap tinggal 40% (lalu dikurangi armor). Hitungannya lawan Warden: pukulan Warden (30 di Normal, 45 di Hard) dulu masuk ±9 / ±15 ke darah 100, jadi Shazam tumbang dalam ±11 / ±7 pukulan. Sekarang cuma masuk ±3,5 / ±6 ke darah 300 (butuh ±85 / ±48 pukulan, belum dihitung darah yang pulih), sedangkan Warden (darah 500) tumbang dalam 13 pukulan Shazam. Sonic boom Warden menembus armor, jadi tetap masuk 4 / 6.

**Darah langsung penuh tiap berubah wujud, seperti di komik:**
- Berubah jadi Shazam dengan darah berapa pun: begitu petir menyambar, darah langsung penuh 300/300.
- Balik jadi manusia (termasuk saat sekarat sebagai Shazam, atau saat energi habis): darah langsung penuh 20/20.
- Selama ritual berubah (±5 detik dewa-dewa datang) dan saat ritual balik jadi manusia, badan dilindungi petir sihir: kebal damage, jadi nggak mati di tengah ritual walau mulainya dalam keadaan sekarat. Cuma jatuh ke void dan `/kill` yang tetap kena.

Semua angkanya ada di bagian atas `ShazamPowers.java` (`BONUS_HEALTH`, `PUNCH_MULTIPLIER`, `BONUS_ARMOR`, dan seterusnya). Pulih penuh saat berubah, saat balik, dan kebal selama ritual bisa dimatikan satu per satu (`FULL_HEAL_ON_TRANSFORM`, `FULL_HEAL_ON_REVERT`, `SAFE_DURING_RITUAL`).

## Yang baru di 0.18: Mode Kilat Mercury makin sinematik

**Auto-hit bisa dimatikan (tombol M).** Selama Mode Kilat nyala, tekan **M** untuk mematikan auto-hit: Shazam tetap lari super cepat (dan tetap bisa lari di atas air), tapi monster nggak diserang otomatis lagi. Tekan **M** lagi untuk menyalakannya. Pilihannya diingat sampai game ditutup, termasuk saat Mode Kilat dimatikan lalu dinyalakan lagi. Di HUD, kotak **M** bertuliskan **AUTO** (auto-hit nyala) atau **LARI** (cuma lari). Tombolnya bisa diganti di Controls ("Mode Kilat: auto-hit nyala/mati").

**Bayangan berjejak sekarang pakai jubah.** Tiap bayangan dibekukan persis seperti frame saat dibuat: pose badan, plus jubah, mantel, dan hood yang sedang berkibar saat itu, lengkap dengan list emasnya. Digambar empat lapis: badan tembus pandang yang terang sendiri, kain, list emas, lalu pendar listrik yang paling terang di tepi siluet (seperti energi yang membentuk badan) plus lambang dada yang menyala. Bayangan terbaru biru muda terang, makin tua makin biru listrik pekat lalu memudar. Jaraknya ±1 blok (seperti foto strobo), jadi tiap bayangan terbaca jelas, bukan gumpalan. Bayangan yang terlalu dekat kamera atau yang persis menutupi pelari dari kamera F5 dibuat tipis, jadi pelarinya tetap kelihatan.

**Petir speed force yang tebal.** Empat sambaran petir tebal terseret di belakang pelari, mengikuti lintasan larinya yang sesungguhnya (ikut melengkung saat berbelok). Pangkalnya keluar dari badan, paling tebal sedikit di belakang badan, lalu menipis di ujung ekor. Zig-zag-nya dibentuk ulang tiap tick (berkedip seperti petir sungguhan) sementara liukannya bergerak halus tiap frame, dengan inti putih panas, badan biru, pendar udara terionisasi yang lebar, cabang-cabang, dan sesekali sambaran yang lebih terang. Ditambah busur listrik yang melompat di antara bayangan-bayangan, listrik kecil di badan bayangan terbaru, listrik yang lebih tebal di badan, busur yang lebih tebal saat memukul, jejak listrik di kaki, dan percikan di tiap langkah. Bagian petir yang lewat dekat kamera memudar, jadi kamera F5 nggak tertutup cahaya putih.

**Animasi lari ala sprinter.** Lutut didorong tinggi ke depan dan kaki belakang menolak jauh, lengan memompa kuat (sedikit menyilang di depan badan), bahu ikut berputar mengikuti ayunan lengan, badan naik-turun tiap langkah dan bergoyang sedikit ke kaki tumpuan. Saat menikung, badan condong ke dalam tikungan sesuai kecepatan dan tajamnya belokan, seperti pelari di lintasan melengkung. Saat mengerem dari lari kencang: kaki depan menancap, badan condong ke belakang dan merendah, tangan terentang mengimbangi, sambil tergelincir.

Angka-angka tampilannya ada di bagian atas `client/anim/ShazamPoses.java` (jarak, umur, kepekatan, dan warna bayangan; condong saat menikung) dan `client/fx/SpeedForce.java` (jumlah, tebal, dan panjang petir).

## Yang baru di 0.17: Mode Kilat Mercury

Skill Mercury (tombol **N**) sekarang jadi mode yang bisa dinyalakan terus, bukan terjangan sekali pakai.

**Cara pakai:** tekan **N** sekali untuk menyalakan, tekan lagi untuk mematikan. Nggak ada cooldown. Menyalakannya butuh 15 energi, lalu energi berkurang 3 per detik selama nyala dan 1 per pukulan (energi penuh cukup untuk beberapa menit). Kalau energi menipis, mode mati sendiri. Di HUD, kotak **M** jadi biru selama mode nyala (sejak 0.18 bertuliskan **AUTO** atau **LARI**, lihat di atas).

**Kalau ada musuh di sekitar (auto-hit):**
- Monster dalam 20 blok yang kelihatan (nggak terhalang tembok) otomatis diserang: Shazam melesat ±64 blok/detik ke depan musuh terdekat, memukulnya, tertahan sekejap seperti pukulan yang benar-benar kena, lalu langsung ke musuh terdekat berikutnya. Kerumunan rapat bisa dihajar sampai 10 pukulan per detik.
- Monster biasa langsung mati sekali pukul dan badannya terpental searah pukulan (tendangan paling jauh, hook melambung). Bos (Wither, Ender Dragon, atau monster berdarah 150 ke atas) dipukul bertubi-tubi 40 damage per pukulan (60 sejak 0.19), bukan langsung mati. Kalau mau bos juga langsung mati, ubah `INSTAKILL_BOSSES` di `ShazamMercury.java`.
- Cuma monster yang diserang. Pemain lain, hewan peliharaan, villager, dan hewan biasa aman. Makhluk netral (enderman, zombified piglin) cuma diserang kalau sedang menyerang.
- Musuh yang tiba-tiba muncul atau mendekat langsung ikut diserang. Monster terbang (phantom, ghast, blaze) juga dikejar ke udara.
- Pukulannya bergantian: jab kanan, cross kiri, hook, lalu tendangan, dengan putaran pinggang dan langkah kaki. Rangkaian pukulan menyambung seperti satu kombo.

**Kalau nggak ada musuh (super speed):**
- Lari super cepat sampai ±52 blok/detik dengan fisika yang masuk akal: kecepatan naik dalam ±0,65 detik, belokan makin lebar saat makin kencang (ada inersia), dan saat W dilepas badan tergelincir ±10 blok sebelum berhenti. Melompat sambil lari menjaga momentum, jadi lompatannya jauh melengkung.
- Bisa lari di atas air selama cukup kencang. Begitu melambat, tenggelam dan berenang biasa.
- Tahan **Shift**: semuanya ditahan, jalan biasa (misalnya mau lewat tanpa menyerang atau berjalan pelan).
- Saat sedang terbang, terbangnya tetap terbang Shazam biasa, tapi auto-hit tetap jalan.

**Efek dan animasi:**
- Listrik biru merayap di badan, makin deras saat makin kencang. Petir zig-zag menyambar-nyambar di belakang badan saat lari. Ada juga bayangan berjejak yang tiap bayangannya membeku di pose langkahnya sendiri, seperti foto strobo.
- Pose lari ala speedster: badan condong ke depan (lebih condong saat mempercepat, menegak saat mengerem), langkah makin rapat saat makin kencang, lengan mengayun berlawanan dengan kaki, badan naik-turun tiap langkah, dan kepala tetap menatap ke depan.
- Debu tersibak dan terseret udara di belakang kaki, bongkahan tanah sungguhan terlempar saat sangat kencang, dan percikan listrik di tiap langkah. Di atas air ada cipratan dan riak.
- Mulai melesat dari diam: hentakan udara, debu tersembur ke belakang, dan tanah retak. Mengerem atau berbelok tajam: kaki menggerus tanah dengan percikan dan debu.
- Tiap pukulan: kilatan, gelombang kejut searah pukulan, udara terdorong ke belakang musuh, hujan percikan, dan busur listrik dari kepalan.
- Saat menyala: kuda-kuda rendah sambil gemetar mengumpulkan tenaga, lalu badan menghentak tegak dan listrik meledak dari badan.
- Dari sudut pandang orang pertama, efek yang menempel di badan nggak digambar (supaya layar nggak tertutup). Gantinya garis kecepatan, pandangan yang melebar, suara angin, dan tangan yang ikut memukul.

Angka-angkanya bisa diatur di bagian atas `ShazamMercury.java` (energi, damage, bos) dan `client/flight/MercuryMode.java` (jangkauan, kecepatan menerjang dan lari, percepatan, rem, belokan, lari di atas air).

## Yang baru di 0.16: efek tebal & gerak halus

Efek skill sekarang tebal dan pekat (tetap kelihatan di siang hari dan di depan langit terang), dan semua gerakan lebih halus seperti di dunia nyata.

**Kenapa dulu efeknya terasa tipis:**
- Tiap efek baru langsung dimajukan satu tick saat dibuat, jadi frame pertamanya (yang paling terang) nggak pernah digambar. Busur petir yang umurnya 2 tick cuma kelihatan 1 tick dan sudah setengah pudar; kilatan kehilangan puncak terangnya dan muncul sudah setengah mengembang.
- Semua efek cuma cahaya aditif (ditambahkan ke warna latar), jadi di depan langit terang hampir hilang.
- Garis petir sempit, dan pendarnya cuma titik terang kecil di tengah.
- Kalau jumlah efek penuh, yang dibuang malah efek yang baru dipakai.

**Yang berubah di efek:**
- **Lapisan badan:** tiap efek cahaya punya badan tembus pandang berwarna pekat di bawah cahayanya, jadi tetap tebal di siang hari. Kepekatannya diatur `BODY` di `client/vfx/Draw.java` (0 = seperti 0.15), terangnya `GLOW`.
- Pendar bulat lebih penuh (seperti kurva lonceng). Petir 1,45× lebih tebal dengan pendar udara di sekelilingnya (`THICK` di `client/vfx/Lightning.java`). Petir, berkas, dan jejak digambar sebagai pita tiga lapis (pendar, badan berwarna, inti panas) yang menyambung tanpa celah di tikungan.
- Butiran 1,6× lebih banyak (`DENSITY` di `client/vfx/Vfx.java`, 1 = seperti 0.15). Percikan punya ekor gerak dan kepala yang membara, debu bervolume (atas kena cahaya, bawah berbayang), dan tiap hantaman sekarang mengepulkan **asap tebal** yang menyebar rendah, mengembang, naik pelan, lalu menipis. Gelombang kejut menyapu asap ke luar, jadi tempat pemain berdiri tetap bersih; saat petir transformasi asapnya tipis supaya kostum yang terbentuk tetap kelihatan. Hantaman Atlas dari udara meninggalkan asap seperti meteor, dan petir meninggalkan jelaga.
- Kilatan punya pendar luas, gelombang kejut punya muka gelombang yang terang, dan retakan tanah, lingkaran rune, tanda sasaran, serta aura Achilles lebih tebal.
- **Halus sejak frame pertama:** efek baru mulai dari umur 0, butiran dan pecahan blok langsung bergerak. Jejak cahaya (terjangan Mercury, menukik Atlas, tangan saat terbang) melengkung mulus (kurva Catmull-Rom), tumbuh mulus dari awal, ekornya bergeser halus (dulu meloncat tiap tick), dan ujungnya nggak melipat balik lagi.
- Batas efek 1024 dan butiran 6000. Kalau penuh, yang dibuang yang paling dekat habis, bukan efek baru.
- **Tetap ringan:** tiap bentuk cuma dikirim sisi yang menghadap kamera (dulu dua sisi, separuhnya dibuang GPU), geometrinya dihitung sekali untuk dua lapisan, dan titiknya ditulis lewat jalur cepat. Biaya per titik turun ±36%, jadi walau titiknya ±1,75× lebih banyak, adegan berat (tiga hantaman sekaligus) cuma butuh ±0,15 ms CPU lebih banyak per frame.

**Yang berubah di gerak badan:**
- Pose antar-keyframe dihaluskan seperti otot sungguhan (`SMOOTH` di `client/anim/Clip.java`, 0 = persis keyframe seperti 0.15). Sentakan terbesar per frame (60 FPS) turun dari 120° ke 46° (lengan saat Tepukan Hercules), dari 91° ke 37° (kepala saat Zeus Rage), dan dari 74° ke 30° (kepala saat Kulit Achilles). Waktu kena damage tetap sama.
- Masuk dan keluarnya animasi, serta perpindahan pose terbang (melayang, meluncur, ngebut, mengerem) dan berdiri gagah, sekarang melengkung: mulai dan berhenti pelan, bukan mendadak.
- Ganti gerakan di tengah animasi (misalnya menukik Atlas lalu mendarat) sekarang memudar selama 4 tick (`XFADE` di `client/anim/ShazamPoses.java`), nggak meloncat dari satu pose ke pose lain.

## Yang baru di 0.15: enam dewa datang satu per satu

Begitu SHAZAM diucapkan, enam dewa datang **bergantian** (tiap ±0,65 detik), masing-masing dengan cara masuknya sendiri, lalu berdiri melengkung di seberang kamera dengan urutan S-H-A-Z-A-M dari kiri ke kanan. Rohnya sekarang berwujud dewa sungguhan, bukan model pemain yang diwarnai: tinggi ±3 blok, tembus pandang seperti patung cahaya, tepinya bersinar warna dewanya, mata menyala, dan ada lingkaran suci di belakang kepala.

| Dewa | Wujud | Cara muncul |
|---|---|---|
| **S** Solomon | Raja bijak berjubah ungu panjang, mahkota emas bergerigi, janggut putih panjang, kitab terbuka di tangan kiri | Lingkaran rune ungu menyala di tanah, tubuhnya terbentuk dari kaki ke kepala (garis cahaya naik), kitab terbuka, lalu segel bintang segi enam menyala di telapak kanannya |
| **H** Hercules | Berotot besar, kerudung kepala singa (moncong, taring, surai), cakar singa terikat di dada, kulit singa di punggung, gada kayu berbonggol di bahu | Melompat dari kejauhan seperti bintang jatuh, mendarat bertumpu satu kepalan sambil menghantamkan gada: tanah retak, gelombang kejut, pecahan blok, kamera bergetar |
| **A** Atlas | Raksasa berlutut memanggul bola langit bercincin emas berisi rasi bintang | Tanah retak membara dan batu-batu terlempar, lalu dia bangkit dari dalam bumi bersama bola langitnya |
| **Z** Zeus | Raja dewa berjanggut & berambut putih, mahkota daun salam emas, jubah putih, petir zig-zag di tangan kanan siap dilempar | Badai berkumpul di langit, petir menyambar, dan Zeus berdiri di tempat petir jatuh (silau putih, listrik merayap di badannya) |
| **A** Achilles | Helm Yunani berjambul merah, zirah emas, perisai bundar berlambang matahari, tombak, jubah merah | Cincin api di tanah dan pusaran bara emas berpilin naik; tubuhnya "terbakar muncul" dari kaki ke kepala, lalu perisainya dihentakkan dengan kilatan |
| **M** Mercury | Ramping, topi & sandal bersayap, tongkat caduceus (dua ular, sepasang sayap), jubah pendek berkibar | Melesat secepat kilat mengitari dewa-dewa lain dengan bayangan yang tertinggal, berhenti mendadak (hembusan angin), lalu berjinjit di satu kaki menunjuk langit |

- Tiap dewa tiba disambut denting yang makin tinggi, dan nama + kekuatannya muncul di atas hotbar (misalnya *ZEUS — Kekuasaan*).
- Badanmu ikut bereaksi: tiap kali dewa datang badan sedikit tersentak, lengan makin terbuka, dan kepala makin terangkat menatap mereka.
- Setelah keenamnya hadir, mereka bersinar bersamaan. Saat kepalan diangkat, tiap dewa mengarahkan pusakanya ke kepalanmu (Zeus mengayunkan petirnya, Achilles menodongkan tombak, Mercury menunjuk, ...) dan mengalirkan sinar energinya bergantian. Mereka memudar selama petir turun dan lenyap tepat saat petir menyambar.
- Panggilan dewa sekarang ±4,4 detik (dulu 1,4 detik), jadi sampai petir menyambar total ±7 detik termasuk slow motion. Jadwalnya bisa diubah di `client/fx/GodShow.java` (`ARRIVE`, jarak 13 tick) bersama `SUMMON_TICKS` di `ShazamAnim.java`.
- Dewa-dewa berdiri di seberang kamera: kalau kamera di depanmu (orang pertama otomatis pindah ke kamera sinematik), mereka di belakangmu; kalau kamera di belakang (F5), mereka di depanmu. Pemain lain yang menonton melihat mereka di seberang kameranya sendiri. Dewa berdiri di permukaan tanah masing-masing.
- Bentuk dewa dibangun dari geometri halus di `client/fx/GodFigures.java`, warna & cahayanya di `GodLook.java`, jadwal & gerak masuknya di `GodShow.java`, efek & suara tiap kedatangan di `ShazamSpirits.java`. Nama dewa di file bahasa (`spirit.shazammod.*`); kalau nggak mau namanya muncul, ubah `SHOW_NAMES` di `ShazamSpirits.java`.

## Yang baru di 0.14: fisika kain ditulis ulang

Jubah, mantel, dan hood sekarang memakai mesin kain baru yang cara kerjanya sama dengan cloth di engine game sungguhan. Ini memperbaiki bug hood yang terbuka di belakang (belakang kepala kelihatan, "sayap" di samping, ujung runcing ke atas), mantel yang melorot dari bahu, dan kain yang nyangkut atau molor.

- **Penyebab bug lama:** tabrakan "dorong ke sisi terdekat" mendorong kain yang sudah masuk agak dalam ke kepala atau lengan keluar lewat sisi yang salah, lalu gaya "kembali ke bentuk" menariknya lurus menembus kepala, jadi kainnya nyangkut di posisi salah. Fisikanya juga dihitung di ruang dunia dengan pose kepala dan lengan yang cuma di-update sekali per frame, jadi tiap menoleh cepat kain tertinggal jauh.
- **Fisika di ruang badan + gaya semu yang benar:** tiap kain dihitung di ruang tempat ia dipasang (jubah dan mantel di badan atas, hood di kepala). Gerak badan di dunia (jalan, lompat, terbang 100 blok/detik, berbalik, menoleh) masuk sebagai percepatan bingkai, gaya sentrifugal, Coriolis, dan Euler, persis seperti hukum Newton di kerangka yang bergerak. Kain tetap punya kelembaman, tapi nggak pernah tertinggal, meledak, atau lepas dari badan, dan selalu menempel persis saat digambar.
- **Satuan dunia nyata:** 1 blok = 1 meter, gravitasi 9,81 m/s², udara 1,225 kg/m³, air 1000 kg/m³, kain wol 0,45-0,7 kg/m². Hambatan udara dihitung dari sudut kain terhadap angin.
- **XPBD:** kain nggak bisa molor (tali panjang ke titik paku), tapi gampang melipat saat tertekan, seperti kain sungguhan.
- **Wake di belakang badan:** udara tepat di belakang badan ikut terseret badan, jadi jubah di situ menerima angin yang lebih pelan. Dihitung dengan menelusuri arah datangnya angin dari tiap titik kain.
- **Turbulensi:** pusaran udara yang terbawa aliran (lebih kuat di dalam wake) bikin jubah berkibar alami, bukan gelombang buatan.
- **Tabrakan menerus:** kotak badan, kepala, lengan, dan kaki punya sudut membulat, dan kain selalu didorong ke sisi tempat ia datang. Jubah juga menabrak blok dunia (lantai, dinding, langit-langit).
- **Bentuk pakai:** hood yang dipakai ditahan dekat bentuknya (paling jauh 1,2-4,8 cm), jadi menoleh secepat apa pun tetap membungkus kepala. Mantel ditarik pelan ke bentuknya, dan bagian bahunya ikut terangkat bersama lengan.
- **Hood diturunkan** sekarang benar-benar kain lemas yang tergeletak di atas mantel, dan saat dipakai/dilepas dituntun lewat atas kepala.
- **Jubah menempel di badan atas**, jadi tetap di bahu saat jongkok atau membungkuk (dulu melayang di atas bahu). Pose bawaan Minecraft seperti berenang, merangkak, dan terbang elytra juga diikuti.
- Lebih ringan dari versi lama (±1,8% satu inti CPU per pemain Shazam yang kelihatan).

## Yang baru di 0.13

- **Hood, mantel, dan jubah menyatu.** Hood baru berbentuk kotak dengan sudut membulat (mengikuti kepala Minecraft), bingkai wajah yang menaungi dahi, panel belakang dengan jahitan, dan ujung runcing kecil di ubun-ubun. Mantel bahu baru (kain berfisika) menyambungkan hood dan jubah: tepi bawah hood masuk ke kerah mantel, list emas bingkai wajah bersambung ke tepi depan mantel, dan bagian atas jubah tersembunyi di bawah mantel.
- **Aksesoris bahu:** pelat emas tiga lapis bertumpuk di tiap bahu (dengan paku keling), bros berpermata di kedua tepi depan, dan rantai emas di dada atas. Semuanya menempel di kain dan ikut bergerak.
- **Kain dua lapis:** sisi luar putih, lapisan dalam biru tua keunguan, jadi bagian dalam hood terlihat dalam.
- **Efek skill buatan sendiri:** cahaya lembut, gelombang kejut yang menempel di tanah, cangkang energi, petir bercabang, retakan tanah yang membara, pecahan blok sungguhan, lingkaran rune, tanda sasaran, jejak cahaya, aura api, dan efek layar (garis kecepatan, vinyet). Lihat bagian *Efek visual*.
- **Animasi skill baru** dengan putaran pinggang, condong badan, dan gemetar. Lihat bagian *Animasi skill*.
- Enam penjaga kuil beserta totemnya.

## Yang dibutuhkan

- **JDK 21**, misalnya Eclipse Temurin 21 atau Microsoft Build of OpenJDK 21.
- **Internet** untuk build pertama. Gradle, NeoForge, dan Minecraft diunduh otomatis, totalnya beberapa ratus MB.

## Bikin file .jar

**Windows:** buka folder ini, ketik `cmd` di address bar File Explorer, tekan Enter, lalu jalankan:

    gradlew build

**Mac/Linux:**

    chmod +x gradlew
    ./gradlew build

Hasilnya ada di `build/libs/shazammod-0.30.0.jar`. Taruh di folder `.minecraft/mods`, dengan NeoForge 21.1.228 atau yang lebih baru untuk Minecraft 1.21.1.

Mau ngetes tanpa install? Jalankan `gradlew runClient`.

## Kontrol

Semua tombol bisa diganti di pengaturan Controls, kategori Shazam, Black Adam & Sabbac. Tabel ini untuk Shazam; tombol yang sama memanggil skill Black Adam (lihat *Yang baru di 0.21*) atau Sabbac (lihat *Yang baru di 0.30*) kalau juara itu yang dipilih.

| Tombol | Skill | Gerakan & efek |
|---|---|---|
| G (atau ketik `shazam`) | Transformasi | Lingkaran rune emas menyala di tanah dan enam dewa datang satu per satu (Solomon, Hercules, Atlas, Zeus, Achilles, Mercury), masing-masing dengan cara masuknya sendiri. Lalu kepalan diangkat ke langit sementara listrik dari tanah merambat ke kepalan. Dunia melambat (slow motion) dan petir sihir turun pelan dari langit selama 2 detik, sementara tiap dewa mengalirkan sinar energinya ke kepalan. Petir mengenai kepalan, layar berkilat, dan kostum terbentuk masih dalam slow motion; begitu selesai, dunia kembali normal. Badan jadi 10% lebih besar. |
| Z | S - Kebijaksanaan Solomon | Tangan menyapu di depan mata, dua jari ke pelipis, avatar Solomon membuka kitab, lalu segel segi enam raksasa terproyeksi dan bola pemindai melebar sampai 48 blok. Musuh yang terbaca bersinar, menerima +25% damage, damage dari mereka tinggal 60%, dan sihir pelindung mereka terhapus. |
| X | H - Tepukan Guntur Hercules (Shift: Lemparan Hercules) | Avatar Hercules melompat lalu menghantamkan gada saat kedua tangan ditepuk: gelombang guntur berbentuk kerucut menghempas musuh, membuat mereka limbung, dan menghancurkan proyektil. Sambil Shift: musuh di depan diangkat ke atas kepala lalu dilempar, meledak saat menghantam. |
| C | A - Beban Langit Atlas | Kepalan diangkat menyangga langit bersama avatar Atlas, bola langit berbintang jatuh, musuh tersedot ke tengah, lalu kepalan menghantam: yang di tengah tertekan ke tanah, yang di pinggir terhempas. Dari udara: menukik seperti meteor. |
| V | Z - Petir Berantai Zeus | Avatar Zeus membidikkan petirnya, lalu petir dari ujung jari melompat dari musuh ke musuh (sampai 6), 2x ke musuh basah, dan tiap sasaran disambar guntur dari langit di saat yang sama. |
| B | A - Perisai Achilles | Membungkuk gemetar lalu meraung bersama avatar Achilles: hampir kebal 6 detik, perisai matahari di depan dada, musuh dipancing menyerang Shazam, lalu damage yang tertahan meledak keluar sebagai Ledakan Keberanian. |
| N | M - Mode Kilat Mercury | Tekan sekali nyala, tekan lagi mati (tanpa cooldown). Selama nyala: kalau ada monster dalam 20 blok yang kelihatan, Shazam otomatis melesat ke tiap musuh dan memukulnya sampai mati satu per satu (jab, cross, hook, tendangan); kalau nggak ada musuh, lari super cepat ±52 blok/detik dan bisa lari di atas air. Musuh yang baru muncul langsung ikut diserang. Tahan Shift untuk jalan biasa tanpa menyerang. Lihat *Yang baru di 0.17*. |
| M | Mode Kilat: auto-hit nyala/mati | Selama Mode Kilat nyala, matikan auto-hit supaya cuma lari super cepat tanpa menyerang otomatis; tekan lagi untuk menyalakan. Lihat *Yang baru di 0.18*. **Black Adam:** Panggil Petir Kahndaq (lihat *Yang baru di 0.22*). |
| R | Badai Para Dewa | Membungkuk mengepalkan tinju sementara listrik tertarik ke badan, lalu meraung: enam petir di enam penjuru, awan badai di atas kepala, dan keenam dewa mengelilingi Shazam selama 12 detik, bergiliran menyerang musuh dengan gayanya sendiri. Pukulan +50% dan berpetir. Biaya 150 energi, cooldown 60 detik. |
| H | Hood naik/turun | Kedua tangan meraih ke belakang kepala lalu menarik hood ke depan sampai dahi, atau memegang tepi hood di dahi lalu mendorongnya ke belakang. Statusnya tersimpan dan terlihat oleh pemain lain. |
| K | Ganti juara | Shazam → Black Adam → Sabbac, yang sudah didapat saja (cuma kalau punya paling nggak dua juara, dalam wujud manusia). |
| J | Kekuatan Keluarga (0.26, Shazam) / Tangan Kahndaq (0.27, Black Adam) | Shazam: kepalan ke langit, tautan petir ke keluarga, lalu petir menyambar seluruh keluarga bersamaan, mereka jadi juara kecil 30 detik (lihat *Yang baru di 0.26*). Black Adam: semua proyektil yang tertahan di udara dilempar balik ke penembaknya dengan petir (lihat *Yang baru di 0.27*). |

## Terbang

| Kontrol | Gerakan |
|---|---|
| Spasi 2x | Lepas landas: jongkok sebentar, lalu melesat ke atas. Di udara, tekan lagi 2x untuk berhenti terbang. |
| W | Terbang ke arah pandangan (±28 blok/detik). |
| W + sprint (ditahan) | Makin lama makin ngebut sampai ±100 blok/detik. Saat menembus kecepatan tertentu muncul sonic boom: cincin uap, dentuman, dan musuh di sekitar terhempas. |
| S | Mengerem dengan hambatan udara besar (dari 100 blok/detik ±0,8 detik). Badan menegak, tangan dan kaki terayun ke depan. |
| Spasi / Shift | Naik / turun. |
| A / D | Geser ke samping (hanya di kecepatan rendah). |
| A 2x / D 2x | Barrel roll menghindar ke kiri/kanan. |

### Fisika terbang

Geraknya mengikuti fisika dunia nyata:

- **Dorongan melawan hambatan udara:** makin kencang, makin berat menambah kecepatan. Dari melayang ke 28 blok/detik butuh ±0,5 detik; dengan sprint, sonic boom di ±1,5 detik dan kecepatan puncak di ±3 detik.
- **Belokan dibatasi gaya menyamping:** makin kencang, makin lebar belokannya, dan kecepatan nggak hilang saat berbelok. Putar balik di 28 blok/detik selebar ±10 blok (±0,5 detik); di 100 blok/detik selebar ±125 blok (±2 detik), seperti pesawat jet.
- **Gravitasi:** menukik menambah kecepatan (W sambil menukik lurus sampai ±49 blok/detik), menanjak menguranginya (±23 blok/detik).
- **Meluncur:** lepas W saat kencang, Shazam meluncur dan melambat karena hambatan udara (kecepatan tinggi cepat berkurang, kecepatan rendah meluncur jauh), lalu berhenti dan melayang.

### Pose terbang

Pose badan juga dihitung dari gaya yang bekerja, lalu dihaluskan dengan pegas teredam (ada sedikit ayunan alami):

- **Melayang:** badan condong searah gaya yang dibutuhkan, seperti helikopter. Mulai maju berarti condong ke depan, bergeser berarti miring ke samping, mundur berarti condong ke belakang. Naik-turun pelan tetap tegak.
- **Meluncur:** badan sejajar lintasan dengan "hidung" sedikit naik (sudut serang), yang makin kecil saat makin kencang. Satu kepalan di depan; saat super cepat kedua kepalan di depan seperti peluru. Badan tegak saat menanjak dan kepala di bawah saat menukik.
- **Menikung:** badan miring ke dalam belokan seperti pesawat, dengan sudut sebesar arctan(percepatan menyamping ÷ gravitasi), sampai ±70° di belokan tajam. Kamera ikut miring setengahnya.
- **Arah badan:** badan menghadap arah lintasan, bukan arah kamera, jadi saat berbelok kencang badan menyusul pelan-pelan. Kepala tetap memandang ke arah kamera.
- **Tangan dan kaki:** lembam. Saat dipercepat kaki tertinggal ke belakang, saat mengerem terayun ke depan, dan makin kencang makin bergetar diterpa angin.
- **Menjelang tanah:** sekitar 0,8 detik sebelum menyentuh tanah sambil turun, badan menegak dan kaki maju untuk mendarat.

Pandangan juga melebar sesuai kecepatan. Angka-angka fisika gerak ada di bagian atas `FlightModel.java`, dan angka pose di `FlightPose.java`.

Mendarat atau jatuh dengan kencang memicu hero landing: satu lutut turun, kepalan menghantam tanah, dan gelombang kejut melukai musuh di sekitar. Menabrak dinding dengan kencang juga menimbulkan gelombang kejut.

## Kekuatan saat jadi Shazam

| Bagian | Nilai |
|---|---|
| Darah | 300, naik sampai 400 selama bertarung (Restu Para Dewa, 0.31) (bar darah sendiri menggantikan baris hati), pulih 3 per detik, langsung penuh tiap berubah jadi Shazam dan tiap balik jadi manusia |
| Ketahanan | damage yang diterima tinggal 40%, turun sampai 30% selama bertarung (Restu Para Dewa), ditambah armor +20 dan toughness +12 (setara full netherite); kebal selama ritual berubah/balik |
| Serangan mematikan | nggak mati, tapi terlempar balik jadi manusia (darah 20/20); setelah itu 30 detik belum bisa SHAZAM lagi |
| Kebal | jatuh, petir, api, lava, tenggelam (nggak perlu napas), beku, lapar, kaktus, racun, wither |
| Kelemahan | sihir (+50% damage) |
| Pukulan tangan kosong | 40 (critical 60), naik sampai 50 (critical 75) selama bertarung (Restu Para Dewa), pukulan penuh tiap 0,2 detik, musuh terpental jauh; pakai senjata: damage x2 |
| Lain-lain | badan 10% lebih besar, naik blok tanpa melompat, jangkauan +1, menghancurkan blok 4x lebih cepat |
| Energi Petir | 1000, berkurang 1 per detik saat jadi Shazam (±16 menit) dan terisi 5 per detik sebagai manusia; badai petir mempercepat |

## Tampilan saat jadi Shazam

Skin kamu tetap skin aslinya. Yang muncul saat berubah adalah hood, jubah, dan lambang 3D.

- **Enam dewa:** begitu SHAZAM diucapkan, Solomon, Hercules, Atlas, Zeus, Achilles, dan Mercury datang satu per satu dengan cara masuknya sendiri dan berdiri melengkung di seberang kamera, lalu mengalirkan sinar energinya ke kepalan yang terangkat dan lenyap jadi semburan cahaya enam warna tepat saat petir menyambar. Lihat *Yang baru di 0.15*. Mereka digambar di dunia, jadi tetap kelihatan dari sudut pandang orang pertama.
- **Saat berubah:** kepalan menembus langit, lalu petir sihir menyambar dan Shazam terangkat melayang. Kilau emas menyapu badan dari dada, lengan, kepala, sampai kaki. Di tengah kilau itu lambang muncul memantul di dada dengan kilatan terang. Jubah terbentang ke belakang lalu jatuh ke punggung, dan hood muncul di belakang leher lalu tertarik menutupi kepala.
- **Saat kembali jadi manusia:** lambang mengecil hilang, dan jubah, mantel, serta hood memudar jadi butiran cahaya emas.

### Slow motion saat berubah

Begitu kepalan terangkat ke langit, dunia melambat 4× dan petir sihir turun dari langit dengan ujung yang bercahaya dan memercik, tepat 2 detik sampai mengenai kepalan. Selama petir turun, enam dewa mengalirkan sinar energinya ke kepalan sambil memudar. Setelah petir mengenai, dunia tetap 2× lebih lambat selama kostum terbentuk (kilau emas, lambang, jubah, sampai hood tertarik ke kepala), lalu kembali normal pelan-pelan. Semuanya ikut melambat: gerakan, partikel, jubah, dan nada suara.

- Slow motion memperlambat seluruh dunia (sama seperti `/tick rate`), jadi hanya jalan kalau kamu sendirian di server. Di server dengan pemain lain, transformasinya tetap jalan dengan kecepatan normal.
- Kalau sebelumnya kamu memakai `/tick rate` sendiri, nilai itu yang dikembalikan. Kalau transformasi batal atau kamu keluar di tengah jalan, kecepatan langsung kembali normal.
- Kalau sedang di sudut pandang orang pertama, kamera pindah ke depan (orang ketiga, menghadap wajah) selama transformasi supaya semuanya terlihat jelas, lalu kembali seperti semula.
- Kecepatan dan lamanya bisa diatur di bagian atas `ShazamSlowMo.java`. Slow motion bisa dimatikan lewat `ENABLED` di file itu, dan kamera sinematik lewat `ENABLED` di `ShazamCinematic.java`.

### Jubah, mantel, dan hood (satu pakaian, 3D, berfisika)

Ketiganya kain 3D dengan fisika dunia nyata (XPBD, satuan meter, detik, dan kilogram) yang dihitung dengan langkah kecil tetap (160 kali per detik), jadi gerakannya halus dan sama di FPS berapa pun. Tiap kain dihitung di ruang tempat ia dipasang (jubah dan mantel di badan atas, hood di kepala), dan gerak badan di dunia masuk sebagai gaya semu yang benar secara fisika. Saat digambar, permukaan kain dihaluskan dengan kurva sehingga lipatannya melengkung, bukan bersudut. Urutan hitungnya tiap langkah: jubah, lalu mantel (yang selalu di luar bagian atas jubah), lalu hood (yang saat diturunkan tergeletak di atas mantel).

- **Hood:** bentuknya mengikuti kepala Minecraft yang kotak: penampang kotak dengan sudut atas membulat, sekitar 0,03 blok lebih besar dari kepala plus lapisan topi skin. Bingkai wajahnya lurus di samping pipi dan atas dahi, bagian atasnya sedikit maju menaungi dahi. Panel samping lurus sampai belakang kepala, lalu panel belakang yang rata dengan jahitan di tengah dan ujung runcing kecil di ubun-ubun. Pinggirannya menempel di wajah, sisanya kain yang ditahan dekat bentuknya (paling jauh 1,2-4,8 cm) dan sedikit berayun saat menoleh, menunduk, atau terbang. Hood tetap menjaga bentuknya, nggak pernah menutupi wajah, dan nggak pernah nyangkut di sisi kepala yang salah, secepat apa pun menolehnya.
- **Mantel bahu:** kain pendek yang melingkari pangkal kepala, jatuh menutupi kedua bahu, dada atas, dan punggung atas, dengan ujung lancip di tengah punggung. Mantel inilah yang menyatukan semuanya: tepi bawah hood masuk ke kerah mantel (seperti dijahit), list emas bingkai wajah bersambung ke list tepi depan mantel, dan bagian atas jubah tersembunyi di bawahnya. Mantel ditarik pelan ke bentuk pakainya, bagian di atas bahu ikut terangkat bersama lengan, dan kainnya menabrak badan serta kedua lengan (kotak bersudut bulat yang ikut berputar bersama lengan), jadi saat lengan diangkat atau diayun kainnya meluncur di atas lengan, nggak melorot dan nggak menembus.
- **Jubah:** bagian atasnya dipaku di bahu (di bawah mantel, ikut badan atas saat jongkok atau membungkuk) dan sisanya kain sungguhan: nggak pernah molor, nggak menembus badan, kaki, atau lengan, dan nggak menembus blok (lantai, dinding, langit-langit). Yang menggerakkannya:
  - Gravitasi 9,81 m/s² dan berat kain wol tebal (0,7 kg/m²).
  - Kelembaman: saat badan berbelok, berhenti, atau mendarat, jubah ikut terayun (gaya semu kerangka yang bergerak).
  - Hambatan udara sesuai sudut kain terhadap angin. Tepat di belakang badan udaranya ikut terseret badan (wake), jadi bagian itu menerima angin yang lebih pelan.
  - Turbulensi: pusaran udara yang terbawa aliran, lebih kuat di dalam wake, yang bikin jubah berkibar seperti bendera.

  Hasilnya, saat diam jubah menggantung sampai dekat tanah. Saat jalan terangkat sekitar 33°, saat sprint sekitar 43°, dan saat terbang memanjang di sepanjang badan sambil berkibar. Kalau terlempar ke atas, jubah jatuh lagi dalam ±0,5 detik lalu tenang. Di dalam air (air 800 kali lebih padat dari udara, dan kain hampir melayang) jubah mengambang pelan mengikuti arus gerak.
- **Angin sekitar:** di luar ruangan, jubah, mantel, dan hood bergoyang pelan tertiup angin yang arahnya berubah-ubah dan berembus. Angin lebih kencang saat hujan dan badai, dan tidak ada di dalam ruangan, gua, atau air.
- Tekan **H** untuk memakai atau melepas hood dengan tangan. Saat memakai, kedua tangan meraih ke belakang kepala, memegang tepi hood, lalu menariknya ke depan lewat atas kepala sampai dahi. Saat melepas, tangan memegang tepi hood di dahi lalu mendorongnya ke belakang sampai hood tergeletak di atas mantel di belakang leher. Hood baru bergerak saat tangan sudah memegangnya, dan terdengar gesekan kain. Statusnya tersimpan dan terlihat oleh pemain lain.
- **Saat terbentuk** (berubah jadi Shazam), tiap potong kain muncul bergantian (mantel, jubah, lalu hood) dan disapu pita cahaya emas dari atas ke bawah. **Saat lenyap**, kain memudar tembus pandang sambil melepas butiran cahaya emas.

**Kain dua lapis:** sisi luar putih, lapisan dalam berwarna gelap (biru tua keunguan), jadi bagian dalam hood terlihat dalam dan jubah yang berkibar memperlihatkan lapisan dalamnya. Warnanya diatur di `LINING` di bagian atas `ShazamCape.java` (angka RGB, misalnya `0x2E3458`).

**Hiasan emas:** list emas timbul di semua tepi: bingkai wajah dan tepi bawah hood, kerah, tepi depan, dan ujung bawah mantel, serta tepi kiri, kanan, dan bawah jubah. List itu timbul dari kain di kedua sisi, dengan tepi luar yang berkilau dan tepi dalam yang berbayang, dan sedikit menyala di tempat gelap. Karena menempel di titik-titik kain, list emas ikut berkibar.

**Aksesoris bahu:** di tiap bahu ada pelat emas tiga lapis yang bertumpuk seperti genteng, melengkung mengikuti mantel, dengan paku keling bercahaya di kedua ujungnya. Di kedua tepi depan mantel, tepat di bawah rahang hood, ada bros pengait berpermata, disambung rantai emas yang menjuntai di dada atas (di atas lambang dada). Semuanya menempel di kain mantel, jadi ikut bergerak saat mantel terdorong lengan atau tertiup angin. Letak dan ukurannya ada di `PLATE_COLS`, `PLATE_ROWS`, `CLASP_COL`, dan `CLASP_ROW` di `MantleShape.java`, serta bagian atas `CloakDecor.java`.

**Lambang punggung:** di tengah punggung jubah ada lambang 3D yang timbul dari kain dan ikut melengkung saat jubah berkibar. Lambang ini terang sendiri, dengan cahaya berdenyut, kilatan putih yang menyapu, dan pendar emas di kain sekitarnya. Gambarnya sama dengan lambang dada, kecuali kamu menaruh gambar khusus di `.../textures/entity/shazam_cape_emblem.png` (aturannya sama dengan lambang dada).

Lebar dan ketebalan list emas, serta ukuran, posisi, dan ketebalan lambang punggung, bisa diatur di bagian atas `CapeDecor.java`.

Jubah, mantel, dan hood juga muncul saat memakai Kostum Shazam (armor dada), walaupun tidak sedang jadi Shazam.

Warna dan motif kain ada di `.../textures/entity/shazam_cape_cloth.png`. Gambar itu dibentangkan ke seluruh jubah (kiri-kanan gambar = tepi kiri-kanan jubah, atas = bahu, bawah = ujung), dan bagian atasnya juga dipakai untuk hood dan mantel. Angka-angkanya bisa diatur di bagian atas file masing-masing: fisika umum (langkah per detik, gravitasi, hambatan udara, batas gaya semu, tabrakan) di `Cloak.java`; ukuran, berat, dan kelenturan jubah di `CapeShape.java`; bentuk dan kelenturan mantel di `MantleShape.java`; bentuk hood dan seberapa kuat bentuknya dijaga di `HoodShape.java`; angin sekitar, wake, dan turbulensi di `CapeAir.java`; kehalusan gambar dan warna di `ShazamCape.java`.

### Lambang 3D di dada

Bentuk dan warna lambang diambil dari `.../textures/entity/shazam_emblem.png`. Setiap piksel yang tidak transparan jadi balok kecil yang timbul dari dada, dengan warna piksel itu. Lambang menyala sendiri walaupun di tempat gelap, dan berkilau:

- cahaya emas berdenyut di sekelilingnya,
- kilatan putih yang menyapu permukaannya setiap ±2,5 detik,
- kilat terang saat lambang pertama muncul,
- percikan cahaya kecil yang sesekali keluar.

Lambang bawaannya bintang kilau empat sudut. Untuk memakai desain sendiri, timpa file itu dengan PNG berlatar transparan, maksimal 64×64 piksel (16×16 sampai 32×32 sudah cukup). Lebarnya otomatis disesuaikan ke dada, jadi gambar yang lebih tinggi daripada lebarnya akan memanjang ke bawah. Ukuran, posisi, dan ketebalannya bisa diatur di bagian atas `ShazamEmblemLayer.java`. Setelah mengganti gambar, build ulang (atau tekan F3+T saat `runClient`).

### Mata menyala: Zeus Rage dan Mata Solomon

Saat Zeus Rage menyala, matamu jadi putih terang dengan pendar biru-putih, kilau mendatar, dan kilatan listrik kecil di sekitarnya, lalu padam pelan saat amarahnya habis. Selama Zeus Rage aktif, listrik merayap di seluruh badan, busur listrik kecil keluar dari mata, dan batu-batu kecil (dari jenis tanah di bawahmu) terangkat dan mengorbit pelan di sekeliling badan. Pemain lain yang baru melihatmu di tengah amarah juga melihat semua efek ini.

Sesudah Mata Solomon, matamu menyala ungu selama ±3 detik.

Tiap kali petir Penangkal Petir Hidup menyambar (0.25, tiap 2 detik), mata menyala putih dengan kilatan listrik dan lambang di dada berkilat selama ±0,9 detik.

Letak mata diatur untuk skin standar: baris ke-4 wajah, kolom 1-2 dan 5-6 (wajah 8×8 dihitung dari kiri-atas seperti terlihat dari depan). Kalau mata di skin-mu ada di baris atau kolom lain, ubah `EYE_ROW`, `EYE_HEIGHT`, dan `EYES` di bagian atas `ShazamEyesLayer.java`.

## Efek visual (buatan sendiri, bukan partikel Minecraft)

Semua efek skill, terbang, transformasi, dan petir digambar sendiri oleh mesin efek di `client/vfx`. Bentuknya dibuat dari geometri dengan gradasi warna per titik, jadi cahayanya halus di jarak berapa pun (nggak kotak-kotak seperti partikel bawaan). Tiap efek cahaya digambar dua lapis: badan tembus pandang berwarna pekat (supaya tetap tebal di siang hari), lalu cahayanya di lapisan aditif. Keduanya nggak menulis kedalaman, jadi pendar yang besar nggak pernah "memotong" benda di belakangnya.

| Efek | Isinya |
|---|---|
| Cahaya & kilatan | Pendar bulat lembut dengan inti putih, bintang kilau empat sudut |
| Gelombang kejut | Cincin yang melebar dan menempel di tanah yang tidak rata (tinggi tanah di sekitarnya diukur dulu), cincin debu, cincin yang melesat ke depan |
| Cangkang energi | Bola atau kubah yang tepinya paling terang (seperti gelembung energi), kerucut udara/uap |
| Petir | Jalur zig-zag bercabang yang berganti bentuk tiap 1-2 tick, busur listrik yang mengikuti tangan, listrik yang merayap di badan |
| Tanah | Retakan yang menjalar dari titik hantaman, membara emas-jingga lalu mendingin jadi celah gelap; bekas hangus; pecahan blok sungguhan (tekstur tanahnya) yang terlempar, berputar, jatuh, dan memantul |
| Butiran | Butiran cahaya, percikan berbentuk garis yang jatuh dan memantul, bara yang naik sambil mendingin, kepulan debu berwarna tanah yang bervolume, asap tebal yang naik dan mengembang |
| Sihir | Lingkaran rune berputar (cincin, sisir, busur putus-putus, huruf rune, bintang segi enam), tanda sasaran berputar di musuh |
| Lain-lain | Jejak cahaya (terjangan, menukik, tangan saat terbang), lidah api emas di sekeliling badan, tiang cahaya dari langit |
| Layar (pemain sendiri) | Garis kecepatan ala anime, vinyet berwarna di tepi layar, kilatan layar berwarna, sentakan pandangan |

Setiap skill memakai warna dewanya: ungu untuk Solomon, putih kehijauan untuk Hercules, jingga tanah untuk Atlas, emas untuk petir Zeus, emas untuk Achilles, biru muda untuk Mercury, dan putih kebiruan untuk Zeus Rage. Warna-warna ini ada di bagian atas `client/fx/ShazamFx.java`, dan urutan efek tiap skill ada di file yang sama. Kepekatan dan terangnya diatur `BODY` dan `GLOW` di `Draw.java`, kepadatan butiran `DENSITY` di `Vfx.java`, dan ketebalan petir `THICK` di `Lightning.java`. Jumlah efek dibatasi (`MAX_EFFECTS` di `Vfx.java`, butiran `MAX` di `Particles.java`) supaya tetap ringan; kalau penuh, yang paling dekat habis yang dibuang.

Tekstur khusus efek ada di `.../textures/entity/fx/`: `aegis.png` (perisai sisik Achilles) dan `weave.png` (kilau saat kostum terbentuk). `spirit.png` sudah nggak dipakai sejak 0.15 (dewa sekarang digambar dari geometri). Teksturnya bisa diganti dengan gambar sendiri ukuran 64×64 yang bisa diulang (latar hitam = tembus pandang, karena digambar sebagai cahaya).

## Animasi skill

Gerakan ada di `client/anim/Clips.java` sebagai keyframe. Selain putaran tiap bagian tubuh, condong badan (`tilt`), dan turunnya badan (`drop`), sekarang ada:

- `twist`: pinggang berputar (badan atas dan bahu ikut, kaki tetap), buat ancang-ancang memukul atau mencambuk;
- `lean`: seluruh badan condong ke samping;
- `spin`: seluruh badan berputar;
- `shake`: gemetar (derajat), buat mengumpulkan tenaga atau menahan amarah.

Tiap skill punya ancang-ancang, gerakan utama yang cepat dengan sedikit kebablasan, lalu kembali pelan. Waktu tiap gerakan pas dengan saat damage di server (`ShazamAnim.java`).

Gerak antar-keyframe dihaluskan otomatis (`SMOOTH` di `Clip.java`, dalam tick): kecepatan tangan, kepala, dan badan naik-turun mulus seperti otot sungguhan, tanpa sentakan satu frame, tapi waktunya tetap sama. Masuk/keluar animasi melengkung, dan kalau animasi baru mulai saat animasi lama masih jalan, yang lama memudar selama `XFADE` tick (`ShazamPoses.java`).

## Kostum armor (bisa di-craft)

Empat bagian, pertahanannya setara netherite, dan diperbaiki pakai emas. Teksturnya ada di `.../textures/models/armor/shazam_suit_layer_1.png` dan `_layer_2.png`.

| Bagian | Resep (G = emas batangan, R = wol merah) |
|---|---|
| Kepala Kostum Shazam | `KKK / BHB / _L_`: K = wol hitam, B = pewarna cokelat, H = helm berlian, L = penangkal petir |
| Kostum Shazam | `RLR / GCG / R_R`: L = penangkal petir, C = baju zirah berlian |
| Celana Kostum Shazam | `GYG / RLR / R_R`: Y = balok emas, L = celana berlian |
| Sepatu Kostum Shazam | `G_G / RDR / G_G`: D = sepatu berlian |

(`_` = kotak kosong.) Kostum ini nggak memberi kekuatan; kekuatan Shazam tetap datang dari mengucapkan SHAZAM.

## Perintah tes

Perintah ini butuh cheat aktif.

- `/shazam unlock [shazam|black_adam|sabbac|lintang|all] [pemain]` dan `/shazam lock [shazam|black_adam|sabbac|lintang|all] [pemain]`: membuka atau mencabut juara (tanpa pilihan: `unlock` = Shazam, `lock` = semuanya). `unlock` sekalian mengisi penuh Energi Petir dan menghapus waktu pulih sesudah serangan mematikan.
- `/shazam trial [pemain]`: mulai Ujian Kahndaq di tempat (tanpa syarat gurun & langit terbuka).
- `/shazam energy <0-1000>`: mengatur Energi Petir.
- `/shazam favor <0-20>`: mengatur tumpukan Restu Para Dewa (harus sedang berwujud Shazam).
- `/shazam form <shazam|black_adam|sabbac> [pemain]`: memilih juara yang sudah didapat. Yang sedang berubah wujud balik jadi manusia dulu.
- `/shazam pact [pemain]`: mulai Perjanjian Enam Iblis (Sabbac) di tempat, tanpa mahkota & tanpa syarat matahari.
- `/shazam rite [pemain]`: mulai Penyatuan Bintang (Lintang) di tempat, tanpa kristal & tanpa syarat matahari.
- `/shazam rival <shazam|black_adam|sabbac> [pemain]`: memanggil Rival Juara itu untuk menantang pemain sekarang juga.
- `/shazam summon <solomon|hercules|atlas|zeus|achilles|mercury>`: memunculkan penjaga.

## Kalau build gagal

- **`Plugin [id: 'net.neoforged.moddev', version: '2.0.+'] was not found`:** ganti `2.0.+` di `build.gradle` dengan versi ModDevGradle yang tertulis di MDK NeoForge 1.21.1 resmi.
- **Error soal versi Java:** pastikan `JAVA_HOME` mengarah ke JDK 21.
- **Crash saat game dibuka dengan pesan `Mixin`:** salin pesan error-nya dari `logs/latest.log` untuk diperbaiki.
- **Error kompilasi di `client/vfx`, `ShazamCape.java`, `ShazamFx.java`, `AdamFx.java`, `TrialFx.java`, `AdamGearLayer.java`, `AdamSkills.java`, `KahndaqTrial.java`, `ScarabItem.java`, `EgyptFigures.java`, `ShazamSkills.java`, `ShazamPassives.java`, `ChampionFx.java`, `RodStrikeFx.java`, `AtonFx.java`, `PassiveConditions.java`, `FamilyFx.java`, `ShazamFamily.java`, `AdamCatch.java`, `AdamCatchFx.java`, `ShazamEvents.java`, `Clips.java`, `ShazamPoses.java`, `ShazamEyesLayer.java`, `ShazamEmblemLayer.java`, `ShazamHud.java`, `GodAvatars.java`, `CineFx.java`, `ScreenFx.java`, atau file 0.30 (`Sabbac*.java`, `DemonSoldier.java`, `PassiveConditions.java`, `rival/*.java`, `RivalPuppets.java`, `SabbacFx.java`, `SabbacGearLayer.java`, `DemonFigures.java`, `DemonSpirits.java`, `DemonSoldierRenderer.java`), file 0.31 (`ShazamFavor.java`, `ShazamCommands.java`), file 0.32 (`Lintang*.java`, `LintangFx.java`, `BoltVisual.java`, `Clips.java`), atau file 0.34 (`Hd.java`, `HdKit.java`, `LintangHd.java`, `SabbacHd.java`, `PoseFilter.java`, `Particles.java`, `Draw.java`):** salin pesan error-nya (nama file, nomor baris, dan pesannya) untuk diperbaiki.

## Soal gradle-wrapper.jar

`gradle/wrapper/gradle-wrapper.jar` adalah pengganti ringkas untuk wrapper resmi Gradle. Sumbernya ada di `gradle/wrapper/GradleWrapperMain.java`. Cara kerjanya: mengunduh Gradle 8.14.3 sekali ke `~/.gradle/wrapper/dists`, lalu menjalankannya.

Kalau mau memakai wrapper resmi, ada dua cara:
- Kalau Gradle sudah terpasang, jalankan `gradle wrapper --gradle-version 8.14.3` di folder ini.
- Salin folder `gradle/` dan file `gradlew*` dari MDK resmi.
