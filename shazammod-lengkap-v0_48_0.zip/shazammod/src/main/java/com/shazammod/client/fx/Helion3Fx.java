package com.shazammod.client.fx;

import java.util.HashMap;
import java.util.Map;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamSounds;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Hd;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Vfx;
import com.shazammod.helion3.Helion3;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

/**
 * 0.48 Efek Subjek Tiga (Helion-3): tanah merekah & puing beterbangan saat dia merangkak keluar, gelombang raungan yang
 * menggetarkan udara, kawah hantaman dari udara, debu & batu serudukan, tembok yang remuk, kilat hantaman, kilau adaptasi
 * (cangkang sel mati mengeras dengan warna jenis serangannya), radiasi Cryon yang tersedot ke tubuhnya, kepompong sel mati
 * yang berdenyut seperti jantung lalu pecah saat dia bangkit, dan kehancuran terakhir (sinar cahaya & Cryon meletup dari
 * retakannya bergantian, lalu meledak). Ditambah tulisan SFX komik, narasi, langkah yang menggetarkan tanah, dan asap &
 * percikan dua warna yang terus bocor dari retakannya.
 */
public final class Helion3Fx {
    public static final float BOOST = 1.5f;
    private static final int LIGHT = 0xFFE2A0;
    private static final int CRYON = HelionFx.CRYON;
    private static final int BLOOD = 0xB01818;
    private static final int DUST = 0x8A7A66;
    private static final Vec3 UP = new Vec3(0, 1, 0);

    private static final Map<Integer, Vec3> LAST_POS = new HashMap<>();
    private static final Map<Integer, Integer> STEP = new HashMap<>();

    private Helion3Fx() {}

    public static void clear() {
        LAST_POS.clear();
        STEP.clear();
    }

    private static void schedule(int delay, int duration, ShazamFx.Step step) {
        ShazamFx.schedule(delay, duration, step);
    }

    private static Vec3 chest(Helion3 b) {
        return b.position().add(0, b.getBbHeight() * 0.6, 0);
    }

    private static boolean self(Helion3 b, double range) {
        var p = Minecraft.getInstance().player;
        return p != null && p.distanceToSqr(b) < range * range;
    }

    /** Ledakan di tanah: retakan menyala, puing blok aslinya, semburan tanah, dinding & kepulan debu. */
    private static void ground(ClientLevel level, Vec3 at, double size, int hot) {
        Ground.Map g = ShazamFx.ground(level, at, 2.5 + size * 2.4);
        if (g == null || !g.found) {
            return;
        }
        Vec3 c = g.center(at);
        int dust = g.dustColor(level, at);
        RandomSource r = level.random;
        Vfx.add(new Ground.Cracks(c, g, 7 + (int) (size * 3.5), (float) (1.3 + size * 1.4), 200 + (int) (size * 30),
                60 + (int) (size * 20), hot, r.nextLong()));
        Vfx.add(new Ground.Debris(c, g, 8 + (int) (size * 8.0), 0.16 + size * 0.1, 0.34 + size * 0.14, 0.55 + size * 0.34, 60));
        LintangFilm.dirtSprays(c, (int) (4 + size * 5), 0.22 + size * 0.08, dust);
        Vfx.add(new Fx.Wave(c, UP, 2.2 + size * 2.4, 0.8 + size * 0.35, dust, 30, 0.62f, 0f, g, true));
        ShazamFx.dustPuffs(level, c, dust, (int) (10 + size * 10), 0.7 + size * 0.6, 0.12 + size * 0.05);
        ShazamFx.smokeCloud(level, c, dust, (int) (5 + size * 4), 0.8 + size * 0.8);
    }

    private static void word(Vec3 at, String text, float size) {
        HelionComic.word(at, text, 0xFFFFFF, BLOOD, size);
    }

    // ------------------------------------------------------------------ animasi dari server

    public static void onAnim(Helion3 boss, ShazamAnim anim, Vec3 pos) {
        float old = Vfx.setBoost(BOOST);
        try {
            switch (anim) {
                case HELION3_EMERGE -> emerge(boss);
                case HELION3_ROAR -> schedule(Helion3.ROAR_HIT, 1, (level, t) -> roar(level, boss, 1f));
                case HELION3_LEAP -> leap(boss);
                case HELION3_SLAM -> slam(boss, pos);
                case HELION3_CHARGE -> charge(boss);
                case HELION3_CRASH -> crash(pos);
                case HELION3_SMASH -> smash(pos);
                case HELION3_POUND -> pound(boss, pos);
                case HELION3_ADAPT -> adapt(boss, pos);
                case HELION3_IMMUNE -> immune(boss, pos);
                case HELION3_ABSORB -> absorb(boss, pos);
                case HELION3_FALL -> fall(boss);
                case HELION3_REVIVE -> revive(boss);
                case HELION3_DEATH -> death(boss);
                default -> { }
            }
        } catch (RuntimeException ignored) {
            // efek nggak boleh bikin game crash
        } finally {
            Vfx.setBoost(old);
        }
    }

    /** Merangkak keluar dari tanah: retakan menjalar, tanah terangkat & berhamburan, lalu raungan pertama. */
    private static void emerge(Helion3 boss) {
        Vec3 f = boss.position();
        schedule(0, Helion3.EMERGE_ROAR, (level, t) -> {
            RandomSource r = level.random;
            float k = t / (float) Helion3.EMERGE_ROAR;
            if (t % 8 == 0) {
                Ground.Map g = ShazamFx.ground(level, f, 2.0 + 4.0 * k);
                if (g != null && g.found) {
                    Vfx.add(new Ground.Cracks(g.center(f), g, 4 + (int) (5 * k), (float) (1.5 + 4.0 * k), 160, 60,
                            r.nextBoolean() ? LIGHT : CRYON, r.nextLong()));
                }
            }
            if (t % 3 == 0) {
                for (int i = 0, n = Vfx.count(2 + 4 * k); i < n; i++) {
                    double a = r.nextDouble() * Math.PI * 2.0, d = r.nextDouble() * 2.5;
                    Vfx.dust(f.x + Math.cos(a) * d, f.y + 0.1, f.z + Math.sin(a) * d, Math.cos(a) * 0.04, 0.08 + r.nextDouble() * 0.1,
                            Math.sin(a) * 0.04, DUST, 0.35f + 0.3f * k, 30);
                }
            }
            if (t == 6 || t == 22) {
                ground(level, f, 0.8 + k, r.nextBoolean() ? LIGHT : CRYON);
            }
            if (self(boss, 40)) {
                CameraShake.add(0.03f + 0.06f * k);
            }
        });
        schedule(Helion3.EMERGE_ROAR, 1, (level, t) -> {
            roar(level, boss, 0.8f);
            if (self(boss, 64)) {
                HelionComic.caption(Component.translatable("caption.shazammod.helion3"));
            }
        });
    }

    /** Raungan: udara bergetar (gelombang & kubah tekanan), debu tersapu, layar bergetar. */
    private static void roar(ClientLevel level, Helion3 boss, float k) {
        Vec3 c = boss.position().add(0, boss.getBbHeight() * 0.75, 0);
        Vec3 f = boss.position();
        Vfx.add(new Hd.Pressure(c, UP, 9.0 * k, 1.0, 0xFFD8C8, 18, 0.8f, true));
        for (int i = 0; i < 3; i++) {
            Vfx.add(new Fx.Wave(f.add(0, 0.1, 0), UP, (5.0 + i * 3.0) * k, 0.4 + i * 0.2, i == 0 ? 0xFFFFFF : DUST, 14 + i * 5,
                    0.7f - i * 0.15f, 0.03f, null));
        }
        CineKit.shock(level, f.add(0, 0.1, 0), UP, 10.0 * k, DUST, 0xFFE8D8, 18, 0.8f, true, true);
        ShazamFx.dustPuffs(level, f, DUST, 18, 3.0, 0.3);
        word(c.add(0, 1.2, 0), "GRRAAAHH!", 1.6f);
        ShazamFx.shakeAround(c, 0.55f * k, 36);
        if (self(boss, 20)) {
            ScreenFx.vignette(0.35f, 0x3A0808, 14);
        }
    }

    private static void leap(Helion3 boss) {
        Vec3 f = boss.position();
        schedule(Helion3.LEAP_WINDUP, 1, (level, t) -> {
            ground(level, f, 1.0, DUST);
            CineKit.shock(level, f.add(0, 0.1, 0), UP, 4.0, DUST, 0xFFFFFF, 12, 0.6f, true, true);
            ShazamFx.shakeAround(f, 0.3f, 24);
        });
        schedule(Helion3.LEAP_WINDUP, Helion3.LEAP_TICKS, (level, t) -> {   // debu & bara yang tertinggal di udara
            Vec3 c = chest(boss);
            RandomSource r = level.random;
            Vfx.smoke(c.x + (r.nextDouble() - 0.5), c.y - 0.5, c.z + (r.nextDouble() - 0.5), 0, -0.02, 0, 0x4A4440, 0.5f, 24);
            if (t % 2 == 0) {
                Vfx.ember(c.x, c.y, c.z, (r.nextDouble() - 0.5) * 0.1, 0.02, (r.nextDouble() - 0.5) * 0.1, 0.06f, 14);
            }
        });
    }

    private static void slam(Helion3 boss, Vec3 pos) {
        schedule(0, 1, (level, t) -> {
            Ground.Map g = ShazamFx.ground(level, pos, 9.0);
            Vec3 c = g != null ? g.center(pos) : pos;
            CineKit.burst(c.add(0, 0.6, 0), 2.0f, 0xFFD8B0, 0xFFFFFF, 10, 0.9f);
            for (int i = 0; i < 2; i++) {
                Vfx.add(new Fx.Wave(c, UP, 6.0 + i * 3.5, 0.5 + i * 0.3, i == 0 ? 0xFFFFFF : DUST, 14 + i * 6, 0.85f - i * 0.2f, 0.06f, g));
            }
            CineKit.shock(level, c, UP, 9.0, DUST, 0xFFFFFF, 20, 1f, true);
            ground(level, c, 2.6, level.random.nextBoolean() ? LIGHT : CRYON);
            Vfx.add(new Hd.DustBurst(c, 4.0, DUST, 40, 0.9f, true));
            word(c.add(0, 1.8, 0), "KRAKATHOOM!", 1.8f);
            ShazamFx.shakeAround(c, 0.8f, 40);
            if (self(boss, 16)) {
                HelionComic.impact(c, 0.9f);
            }
        });
    }

    private static void charge(Helion3 boss) {
        schedule(0, 1, (level, t) -> word(chest(boss).add(0, 1.2, 0), "RRRAAAH!", 1.2f));
        schedule(Helion3.CHARGE_WINDUP, Helion3.CHARGE_TICKS, (level, t) -> {   // debu & tanah tersepak sepanjang serudukan
            Vec3 f = boss.position();
            RandomSource r = level.random;
            for (int i = 0, n = Vfx.count(3); i < n; i++) {
                Vfx.dust(f.x + (r.nextDouble() - 0.5) * 1.4, f.y + 0.1, f.z + (r.nextDouble() - 0.5) * 1.4, (r.nextDouble() - 0.5) * 0.1,
                        0.06 + r.nextDouble() * 0.06, (r.nextDouble() - 0.5) * 0.1, DUST, 0.5f, 26);
            }
            if (t % 3 == 0) {
                ShazamFx.shakeAround(f, 0.2f, 24);
                Minecraft.getInstance().level.playLocalSound(f.x, f.y, f.z, ShazamSounds.HELION3_STEP.get(), SoundSource.HOSTILE,
                        1.6f, 1.1f + r.nextFloat() * 0.2f, false);
            }
        });
    }

    private static void crash(Vec3 pos) {
        schedule(0, 1, (level, t) -> {
            Vfx.add(new Fx.Flash(pos, 1.6f, 0xFFE8D0, 5, 0.9f));
            RandomSource r = level.random;
            for (int i = 0, n = Vfx.count(22); i < n; i++) {
                Vec3 v = ShazamFx.randomDir(r).scale(0.2 + r.nextDouble() * 0.3);
                Vfx.shard(pos.x, pos.y, pos.z, v.x, Math.abs(v.y) + 0.12, v.z, 0x6A625A, 0.16f + r.nextFloat() * 0.1f, 30, pos.y - 3.0);
            }
            ShazamFx.dustPuffs(level, pos, DUST, 16, 1.6, 0.2);
            word(pos.add(0, 0.8, 0), "KRUNCH!", 1.3f);
            ShazamFx.shakeAround(pos, 0.6f, 30);
        });
    }

    private static void smash(Vec3 pos) {
        schedule(0, 1, (level, t) -> {
            RandomSource r = level.random;
            Vfx.add(new Fx.Flash(pos, 1.4f, 0xFFE8D0, 4, 0.9f));
            Vfx.add(new Fx.Flash(pos, 2.4f, BLOOD, 8, 0.4f));
            Vfx.add(new Fx.Wave(pos, ShazamFx.randomDir(r), 2.2, 0.16, 0xFFFFFF, 8, 0.7f, 0f, null));
            CineKit.sparks(pos, 14, r.nextBoolean() ? LIGHT : CRYON, 0.4, 0.07f, 10, pos.y - 2.0);
            word(pos.add(0, 0.6, 0), HelionComic.pick(new String[] {"SMASH!", "KRAK!", "WHAM!", "THUD!"}), 1.1f);
            ShazamFx.shakeAround(pos, 0.35f, 20);
        });
    }

    private static void pound(Helion3 boss, Vec3 pos) {
        schedule(0, 1, (level, t) -> {
            ground(level, pos, 1.8, level.random.nextBoolean() ? LIGHT : CRYON);
            CineKit.shock(level, pos.add(0, 0.1, 0), UP, 5.5, DUST, 0xFFFFFF, 16, 0.9f, true);
            word(pos.add(0, 1.6, 0), "BOOM!", 1.4f);
            ShazamFx.shakeAround(pos, 0.6f, 30);
            if (self(boss, 10)) {
                HelionComic.impact(pos, 0.6f);
            }
        });
    }

    /** Adaptasi: cangkang sel mati mengeras dengan warna jenis serangannya (data.y = 1: kebal total). */
    private static void adapt(Helion3 boss, Vec3 data) {
        Helion3.Kind[] kinds = Helion3.Kind.values();
        int i = Mth.clamp((int) Math.round(data.x), 0, kinds.length - 1);
        int rgb = kinds[i].rgb;
        boolean total = data.y > 0.5;
        Vfx.add(new Shell(boss, rgb, total ? 40 : 24, total ? 1f : 0.6f));
        schedule(0, 1, (level, t) -> {
            Vec3 c = chest(boss);
            RandomSource r = level.random;
            for (int n = 0, m = Vfx.count(total ? 20 : 10); n < m; n++) {
                Vec3 v = ShazamFx.randomDir(r).scale(0.1 + r.nextDouble() * 0.2);
                Vfx.shard(c.x, c.y, c.z, v.x, Math.abs(v.y) + 0.1, v.z, 0x7A6E62, 0.12f, 24, boss.getY());
            }
            CineKit.sparks(c, total ? 24 : 12, rgb, 0.35, 0.06f, 12, boss.getY());
            word(c.add(0, 1.4, 0), total ? "KEBAL!" : "KRRRNCH!", total ? 1.5f : 1.1f);
        });
    }

    private static void immune(Helion3 boss, Vec3 data) {
        Helion3.Kind[] kinds = Helion3.Kind.values();
        int rgb = kinds[Mth.clamp((int) Math.round(data.x), 0, kinds.length - 1)].rgb;
        Vfx.add(new Shell(boss, rgb, 8, 0.5f));
        if (Vfx.random().nextInt(3) == 0) {
            HelionComic.word(chest(boss).add(0, 1.0, 0), "TAK MEMPAN!", 0xFFFFFF, 0x404048, 0.9f);
        }
    }

    /** Radiasi Cryon tersedot ke tubuhnya (kebal Cryon): cakar & tulangnya menguat. */
    private static void absorb(Helion3 boss, Vec3 pos) {
        schedule(0, 10, (level, t) -> {
            Vec3 c = chest(boss);
            RandomSource r = level.random;
            for (int n = 0, m = Vfx.count(5); n < m; n++) {
                Vec3 p = c.add(ShazamFx.randomDir(r).scale(1.8 + r.nextDouble() * 1.2));
                Vec3 v = c.subtract(p).scale(0.2);
                Vfx.streak(p.x, p.y, p.z, v.x, v.y, v.z, CRYON, 0.05f, 6);
            }
        });
        HelionComic.word(pos.add(0, 1.0, 0), "SHHLURP!", 0x8CFF6A, 0x1A3A22, 1.0f);
    }

    private static void fall(Helion3 boss) {
        schedule(10, 1, (level, t) -> {
            ground(level, boss.position(), 1.4, DUST);
            word(chest(boss).add(0, 1.0, 0), "THOOOM...", 1.3f);
            ShazamFx.shakeAround(boss.position(), 0.4f, 30);
        });
    }

    /** Kepompong sel mati yang berdenyut seperti jantung, lalu pecah saat dia bangkit. */
    private static void revive(Helion3 boss) {
        Vfx.add(new Cocoon(boss, Helion3.REVIVE_TICKS));
        schedule(0, Helion3.REVIVE_TICKS, (level, t) -> {
            int beat = t < 30 ? 20 : t < 50 ? 12 : 7;   // detak makin cepat
            if (t % beat == 0) {
                Vec3 f = boss.position();
                Vfx.add(new Fx.Wave(f.add(0, 0.08, 0), UP, 3.0 + t * 0.03, 0.25, t % 2 == 0 ? LIGHT : CRYON, 12, 0.55f, 0.05f, null));
                ShazamFx.shakeAround(f, 0.12f + t * 0.003f, 28);
            }
        });
        schedule(Helion3.REVIVE_TICKS - 8, 1, (level, t) -> {
            Vec3 c = chest(boss);
            RandomSource r = level.random;
            for (int n = 0, m = Vfx.count(30); n < m; n++) {
                Vec3 v = ShazamFx.randomDir(r).scale(0.2 + r.nextDouble() * 0.35);
                Vfx.shard(c.x, c.y, c.z, v.x, Math.abs(v.y) + 0.15, v.z, 0x4A3A34, 0.2f + r.nextFloat() * 0.1f, 34, boss.getY());
            }
            Vfx.add(new Hd.Nova(c, 2.6, 0xFFFFFF, LIGHT, CRYON, 0x2A2420, 24, 0.8f, false));
            roar(level, boss, 1f);
            if (self(boss, 64)) {
                HelionComic.caption(Component.translatable("caption.shazammod.helion3_revive"));
            }
        });
    }

    /** Hancur: sinar cahaya & Cryon meletup dari retakannya bergantian, tubuh mengelupas, lalu meledak. */
    private static void death(Helion3 boss) {
        schedule(0, Helion3.DEATH_TICKS, (level, t) -> {
            Vec3 c = chest(boss);
            RandomSource r = level.random;
            if (t % 4 == 0) {
                Vec3 d = ShazamFx.randomDir(r);
                int col = (t / 4) % 2 == 0 ? LIGHT : CRYON;
                Vfx.add(new Hd.Lance(c, c.add(d.scale(3.0 + r.nextDouble() * 4.0)), 0.18f, col, 0xFFFFFF, 3, 10));
                Vfx.add(new Fx.Flash(c.add(d.scale(0.5)), 0.8f, col, 4, 0.8f));
            }
            if (t % 2 == 0) {
                Vec3 v = ShazamFx.randomDir(r).scale(0.12);
                Vfx.shard(c.x, c.y, c.z, v.x, Math.abs(v.y), v.z, 0x3A302C, 0.14f, 30, boss.getY());
            }
            ShazamFx.shakeAround(c, 0.05f + t * 0.004f, 36);
        });
        schedule(Helion3.DEATH_TICKS - 4, 1, (level, t) -> {
            Vec3 c = chest(boss);
            Vfx.add(new Fx.Flash(c, 6f, 0xFFFFFF, 6, 1f));
            Vfx.add(new Hd.Nova(c, 5.0, 0xFFFFFF, LIGHT, CRYON, 0x2A2420, 50, 1f, true));
            CineKit.shock(level, boss.position().add(0, 0.1, 0), UP, 14.0, DUST, 0xFFFFFF, 26, 1f, true);
            ground(level, boss.position(), 3.0, LIGHT);
            word(c.add(0, 2.0, 0), "KA-KRAAASH!", 2.2f);
            ShazamFx.shakeAround(c, 1.0f, 48);
            if (self(boss, 48)) {
                HelionComic.impact(c, 1.2f);
                HelionComic.caption(Component.translatable("caption.shazammod.helion3_dead"));
            }
        });
    }

    // ------------------------------------------------------------------ tiap tick

    /** Langkah yang menggetarkan tanah, asap & percikan dua warna yang bocor dari retakannya. */
    public static void tick(ClientLevel level) {
        float old = Vfx.setBoost(BOOST);
        try {
            Vec3 cam = Minecraft.getInstance().gameRenderer.getMainCamera().getPosition();
            for (Helion3 boss : level.getEntitiesOfClass(Helion3.class, new net.minecraft.world.phys.AABB(cam, cam).inflate(96.0))) {
                ambient(level, boss);
            }
            LAST_POS.keySet().removeIf(id -> level.getEntity(id) == null);
            STEP.keySet().removeIf(id -> level.getEntity(id) == null);
        } catch (RuntimeException ignored) {
            // efek nggak boleh bikin game crash
        } finally {
            Vfx.setBoost(old);
        }
    }

    private static void ambient(ClientLevel level, Helion3 boss) {
        RandomSource r = level.random;
        Vec3 c = chest(boss);
        if (boss.tickCount % 3 == 0 && boss.action() != Helion3.Action.DEATH) {
            Vfx.smoke(c.x + (r.nextDouble() - 0.5) * 0.9, c.y + (r.nextDouble() - 0.3) * 1.2, c.z + (r.nextDouble() - 0.5) * 0.9,
                    0, 0.03, 0, 0x3A3430, 0.35f, 30);
        }
        if (r.nextInt(3) == 0) {
            int col = r.nextBoolean() ? LIGHT : CRYON;
            Vfx.spark(c.x + (r.nextDouble() - 0.5) * 0.8, c.y + (r.nextDouble() - 0.5) * 1.4, c.z + (r.nextDouble() - 0.5) * 0.8,
                    (r.nextDouble() - 0.5) * 0.06, 0.04, (r.nextDouble() - 0.5) * 0.06, col, 0.05f, 10, boss.getY());
        }
        if (boss.claws() > 0 && r.nextInt(2) == 0) {
            Vfx.mote(c.x + (r.nextDouble() - 0.5), c.y + (r.nextDouble() - 0.5) * 1.5, c.z + (r.nextDouble() - 0.5), 0, 0.03, 0,
                    CRYON, 0.08f, 16);
        }
        Vec3 now = boss.position();
        Vec3 last = LAST_POS.put(boss.getId(), now);
        if (last != null && boss.onGround()) {
            double moved = Math.hypot(now.x - last.x, now.z - last.z);
            if (moved > 0.02) {
                int step = STEP.merge(boss.getId(), (int) Math.ceil(moved * 10.0), Integer::sum);
                if (step >= 12) {   // tiap ±1,2 blok: satu langkah berat
                    STEP.put(boss.getId(), 0);
                    ShazamFx.dustPuffs(level, now, DUST, 4, 0.8, 0.08);
                    ShazamFx.shakeAround(now, 0.12f, 22);
                    level.playLocalSound(now.x, now.y, now.z, ShazamSounds.HELION3_STEP.get(), SoundSource.HOSTILE, 1.4f,
                            0.85f + r.nextFloat() * 0.2f, false);
                }
            }
        }
    }

    // ------------------------------------------------------------------ efek

    /** Cangkang sel mati yang mengeras sesaat (adaptasi / kebal) dengan warna jenis serangannya. */
    static final class Shell extends Effect {
        private final Helion3 boss;
        private final int rgb;
        private final float strength;

        Shell(Helion3 boss, int rgb, int life, float strength) {
            super(life);
            this.boss = boss;
            this.rgb = rgb;
            this.strength = strength;
        }

        @Override
        public void renderGlow(Draw d) {
            float t = progress(d.partialTick);
            float a = (1f - t) * strength;
            Vec3 c = boss.getPosition(d.partialTick).add(0, boss.getBbHeight() * 0.5, 0);
            double r = boss.getBbHeight() * 0.48 * (1.0 + 0.08 * t);
            d.shell(c.x, c.y, c.z, r, rgb, 0.45f * a, 2.2, 1.0);
            d.glow(c.x, c.y, c.z, (float) r, rgb, 0.25f * a);
        }
    }

    /** Kepompong sel mati yang berdenyut seperti jantung (gelap, retakan cahaya & Cryon bergantian), pecah di akhir. */
    static final class Cocoon extends Effect {
        private final Helion3 boss;

        Cocoon(Helion3 boss, int life) {
            super(life);
            this.boss = boss;
        }

        private float beat(float t) {
            float period = t < 30f ? 20f : t < 50f ? 12f : 7f;
            float ph = (t % period) / period;
            return (float) Math.exp(-ph * 6.0);
        }

        @Override
        public void renderSoft(Draw d) {
            float t = time(d.partialTick);
            float grow = Mth.clamp(t / 10f, 0f, 1f) * Mth.clamp((life - 6f - t) / 4f, 0f, 1f);
            if (grow <= 0.01f) {
                return;
            }
            Vec3 c = boss.getPosition(d.partialTick).add(0, boss.getBbHeight() * 0.42, 0);
            d.shell(c.x, c.y, c.z, boss.getBbHeight() * 0.46 * grow, 0x1A1210, 0.85f * grow, 1.6, 1.0);
        }

        @Override
        public void renderGlow(Draw d) {
            float t = time(d.partialTick);
            float grow = Mth.clamp(t / 10f, 0f, 1f) * Mth.clamp((life - 6f - t) / 4f, 0f, 1f);
            if (grow <= 0.01f) {
                return;
            }
            Vec3 c = boss.getPosition(d.partialTick).add(0, boss.getBbHeight() * 0.42, 0);
            float b = beat(t);
            int col = ((int) (t / 7f)) % 2 == 0 ? LIGHT : CRYON;
            d.shell(c.x, c.y, c.z, boss.getBbHeight() * 0.48 * grow, col, (0.15f + 0.45f * b) * grow, 3.0, 1.0);
            d.glow(c.x, c.y, c.z, (float) (boss.getBbHeight() * 0.35), col, (0.1f + 0.3f * b) * grow);
        }
    }
}
