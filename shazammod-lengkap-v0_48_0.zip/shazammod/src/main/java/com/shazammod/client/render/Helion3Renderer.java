package com.shazammod.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.ShazamMod;
import com.shazammod.helion3.Helion3;

import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * 0.48 Subjek Tiga (Helion-3): badan pemain dengan tekstur sendiri (kulit hangus, jahitan operasi, tali pengekang, kalung
 * besi III), retakan & mata dua warna yang menyala (lapisan mata), duri sel mati 3D yang mengikuti gerak tubuh (punggung,
 * bahu, lengan bawah, tengkorak, betis; menyala hijau saat cakarnya menyerap Cryon), dan pose sendiri: membungkuk dari
 * pinggul, merangkak keluar dari tanah, meraung, melompat, menyeruduk, kombo hantaman, tumbang, meringkuk di kepompong,
 * bangkit, dan hancur. Ukurannya dari atribut SCALE entity (1,45x).
 */
public class Helion3Renderer extends HumanoidMobRenderer<Helion3, Helion3Renderer.Model> {
    private static final ResourceLocation TEXTURE = ShazamMod.id("textures/entity/helion3/skin.png");
    private static final ResourceLocation GLOW = ShazamMod.id("textures/entity/helion3/glow.png");
    private static final ResourceLocation SPIKE = ShazamMod.id("textures/entity/helion3/spike.png");
    private static final RenderType GLOW_TYPE = RenderType.eyes(GLOW);

    public Helion3Renderer(EntityRendererProvider.Context context) {
        super(context, new Model(context.bakeLayer(ModelLayers.PLAYER)), 0.9f);
        this.addLayer(new EyesLayer<>(this) {
            @Override
            public RenderType renderType() {
                return GLOW_TYPE;
            }
        });
        this.addLayer(new Spikes(this));
    }

    @Override
    public ResourceLocation getTextureLocation(Helion3 entity) {
        return TEXTURE;
    }

    // ------------------------------------------------------------------ model & pose

    public static class Model extends PlayerModel<Helion3> {
        public Model(ModelPart root) {
            super(root, false);
        }

        private static float ease(float t0, float t1, float t) {
            float k = Mth.clamp((t - t0) / Math.max(0.001f, t1 - t0), 0f, 1f);
            return k * k * (3f - 2f * k);
        }

        private static void pose(ModelPart p, float w, float x, float y, float z) {
            p.xRot = Mth.lerp(w, p.xRot, x);
            p.yRot = Mth.lerp(w, p.yRot, y);
            p.zRot = Mth.lerp(w, p.zRot, z);
        }

        /** Membungkuk dari pinggul sebesar theta: badan, kepala, & bahu ikut maju-turun, kaki tetap di tanah. */
        private void lean(float theta) {
            float c = Mth.cos(theta), s = Mth.sin(theta);
            body.xRot = theta;
            body.y = 12f - 12f * c;
            body.z = -12f * s;
            head.y = body.y;
            head.z = body.z;
            head.xRot -= theta * 0.8f;
            rightArm.y = body.y + 2f * c;
            rightArm.z = body.z + 2f * s;
            leftArm.y = body.y + 2f * c;
            leftArm.z = body.z + 2f * s;
        }

        @Override
        public void setupAnim(Helion3 e, float limbSwing, float limbAmount, float age, float headYaw, float headPitch) {
            super.setupAnim(e, limbSwing, limbAmount * 1.2f, age, headYaw, headPitch);
            float pt = Mth.clamp(age - e.tickCount, 0f, 1f);
            float t = e.actionTime(pt);
            float breathe = Mth.sin(age * 0.09f) * 0.04f;
            float theta = 0.32f + breathe;
            // lengan raksasa menggantung ke depan, sedikit terbuka
            rightArm.xRot -= 0.35f;
            leftArm.xRot -= 0.35f;
            rightArm.zRot += 0.22f;
            leftArm.zRot -= 0.22f;
            switch (e.action()) {
                case EMERGE -> {
                    float rise = ease(0f, 40f, t);
                    theta = Mth.lerp(rise, 1.1f, 0.32f);
                    float reach = ease(0f, 20f, t) * (1f - ease(30f, 44f, t));
                    pose(rightArm, reach, -2.2f, 0f, 0.3f);
                    pose(leftArm, reach, -2.2f, 0f, -0.3f);
                    float roar = ease(44f, 50f, t) * (1f - ease(56f, 60f, t));
                    theta = Mth.lerp(roar, theta, -0.1f);
                    pose(rightArm, roar, -0.3f, 0f, 1.3f);
                    pose(leftArm, roar, -0.3f, 0f, -1.3f);
                    head.xRot -= 0.6f * roar;
                }
                case ROAR -> {
                    float wind = ease(0f, 8f, t) * (1f - ease(8f, 10f, t));
                    theta = Mth.lerp(wind, theta, 0.5f);
                    float roar = ease(8f, 11f, t) * (1f - ease(28f, 34f, t));
                    theta = Mth.lerp(roar, theta, -0.15f);
                    pose(rightArm, roar, -0.5f, 0f, 1.4f);
                    pose(leftArm, roar, -0.5f, 0f, -1.4f);
                    head.xRot -= 0.7f * roar;
                    float shake = Mth.sin(age * 2.3f) * 0.04f * roar;
                    body.zRot += shake;
                    head.zRot += shake * 2f;
                }
                case LEAP -> {
                    float crouch = ease(0f, Helion3.LEAP_WINDUP, t) * (1f - ease(Helion3.LEAP_WINDUP, Helion3.LEAP_WINDUP + 2f, t));
                    theta = Mth.lerp(crouch, theta, 0.7f);
                    pose(rightArm, crouch, 0.6f, 0f, 0.2f);
                    pose(leftArm, crouch, 0.6f, 0f, -0.2f);
                    float air = ease(Helion3.LEAP_WINDUP, Helion3.LEAP_WINDUP + 4f, t);
                    theta = Mth.lerp(air, theta, -0.1f);
                    pose(rightArm, air, -3.0f, 0f, 0.25f);
                    pose(leftArm, air, -3.0f, 0f, -0.25f);
                    pose(rightLeg, air, -0.9f, 0f, 0.05f);
                    pose(leftLeg, air, -0.5f, 0f, -0.05f);
                }
                case STAGGER -> {
                    float w = 1f - ease(6f, 16f, t);
                    theta = Mth.lerp(w, theta, 0.75f);
                    pose(rightArm, w, -0.5f, 0f, 0.4f);
                    pose(leftArm, w, -0.5f, 0f, -0.4f);
                    pose(rightLeg, w, -0.5f, 0f, 0.1f);
                    pose(leftLeg, w, 0.4f, 0f, -0.1f);
                }
                case CHARGE -> {
                    float wind = ease(0f, Helion3.CHARGE_WINDUP, t);
                    theta = Mth.lerp(wind, theta, 0.6f);
                    pose(rightArm, wind, 0.6f, 0f, 0.3f);
                    rightLeg.xRot += Mth.sin(age * 0.8f) * 0.4f * wind * (1f - ease(Helion3.CHARGE_WINDUP - 2f, Helion3.CHARGE_WINDUP, t));
                    float run = ease(Helion3.CHARGE_WINDUP, Helion3.CHARGE_WINDUP + 3f, t);
                    theta = Mth.lerp(run, theta, 0.85f);
                    pose(rightArm, run, 0.9f, 0f, 0.3f);
                    pose(leftArm, run, 0.9f, 0f, -0.3f);
                    rightLeg.xRot = Mth.lerp(run, rightLeg.xRot, Mth.sin(age * 1.6f) * 1.1f);
                    leftLeg.xRot = Mth.lerp(run, leftLeg.xRot, -Mth.sin(age * 1.6f) * 1.1f);
                }
                case SMASH -> {
                    float up1 = ease(0f, 7f, t) * (1f - ease(7f, 9f, t));
                    float down1 = ease(7f, 10f, t) * (1f - ease(11f, 14f, t));
                    pose(rightArm, up1, -2.9f, 0f, 0.1f);
                    pose(rightArm, down1, -0.5f, 0f, 0.2f);
                    float up2 = ease(12f, 18f, t) * (1f - ease(18f, 20f, t));
                    float down2 = ease(18f, 21f, t) * (1f - ease(22f, 25f, t));
                    pose(leftArm, up2, -2.9f, 0f, -0.1f);
                    pose(leftArm, down2, -0.5f, 0f, -0.2f);
                    float up3 = ease(24f, 30f, t) * (1f - ease(30f, 32f, t));
                    float down3 = ease(30f, 33f, t) * (1f - ease(35f, 40f, t));
                    pose(rightArm, up3, -3.0f, 0f, 0.2f);
                    pose(leftArm, up3, -3.0f, 0f, -0.2f);
                    pose(rightArm, down3, -0.4f, 0f, 0.3f);
                    pose(leftArm, down3, -0.4f, 0f, -0.3f);
                    theta = Mth.lerp(Math.max(down1, down2) * 0.6f + down3, theta, 0.9f);
                    theta = Mth.lerp(up3, theta, -0.05f);
                }
                case FALL -> {
                    float w = ease(0f, 14f, t);
                    theta = Mth.lerp(w, theta, 1.3f);
                    pose(rightArm, w, 0.2f, 0f, 0.1f);
                    pose(leftArm, w, 0.2f, 0f, -0.1f);
                    head.xRot += 0.4f * w;
                }
                case REVIVE -> {
                    float curl = 1f - ease(52f, 58f, t);
                    float tremble = Mth.sin(age * 3.1f) * 0.03f * (0.4f + ease(0f, 50f, t));
                    theta = Mth.lerp(curl, theta, 1.3f) + tremble;
                    pose(rightArm, curl, -1.2f, -0.6f, 0f);
                    pose(leftArm, curl, -1.2f, 0.6f, 0f);
                    float burst = ease(55f, 60f, t) * (1f - ease(62f, 70f, t));
                    theta = Mth.lerp(burst, theta, -0.2f);
                    pose(rightArm, burst, -0.5f, 0f, 1.5f);
                    pose(leftArm, burst, -0.5f, 0f, -1.5f);
                    head.xRot -= 0.8f * burst;
                }
                case DEATH -> {
                    float sink = ease(0f, 60f, t);
                    float tremble = Mth.sin(age * 3.7f) * 0.06f * sink;
                    theta = Mth.lerp(sink, theta, 1.2f) + tremble;
                    float reach = ease(0f, 10f, t) * (1f - ease(30f, 45f, t));
                    pose(rightArm, reach, -1.6f, 0f, 0.5f);
                    pose(leftArm, reach, -1.4f, 0f, -0.5f);
                    head.xRot -= 0.5f * reach;
                    body.zRot += tremble;
                }
                default -> { }
            }
            lean(theta);
            hat.copyFrom(head);
            jacket.copyFrom(body);
            rightSleeve.copyFrom(rightArm);
            leftSleeve.copyFrom(leftArm);
            rightPants.copyFrom(rightLeg);
            leftPants.copyFrom(leftLeg);
        }
    }

    // ------------------------------------------------------------------ duri sel mati 3D

    /** Duri piramida yang menempel pada bagian badan (ikut gerak & putaran bagian itu). Angka dalam piksel model. */
    static final class Spikes extends RenderLayer<Helion3, Model> {
        // {x, y, z, arahX, arahY, arahZ, panjang, lebar}
        private static final float[][] BODY = {
                {0f, 1.5f, 2.0f, 0f, -0.45f, 1f, 4.8f, 1.3f}, {0f, 3.6f, 2.0f, 0f, -0.45f, 1f, 4.2f, 1.2f},
                {0f, 5.7f, 2.0f, 0f, -0.4f, 1f, 3.6f, 1.1f}, {0f, 7.8f, 2.0f, 0f, -0.35f, 1f, 3.0f, 1.0f},
                {0f, 9.9f, 2.0f, 0f, -0.3f, 1f, 2.4f, 0.9f}, {-2.6f, 2.5f, 2.0f, -0.4f, -0.6f, 1f, 3.0f, 1.0f},
                {2.6f, 2.5f, 2.0f, 0.4f, -0.6f, 1f, 3.0f, 1.0f}};
        private static final float[][] HEAD = {
                {-1.5f, -7.5f, 1.0f, -0.2f, -1f, 0.6f, 2.6f, 0.9f}, {1.5f, -7.5f, 1.0f, 0.2f, -1f, 0.6f, 2.6f, 0.9f},
                {0f, -8.0f, -0.5f, 0f, -1f, 0.3f, 2.0f, 0.8f}};
        private static final float[][] RIGHT_ARM = {
                {-2.0f, -2.0f, -1.0f, -0.5f, -1f, 0f, 3.6f, 1.1f}, {-2.4f, -2.0f, 1.0f, -0.5f, -1f, 0.2f, 3.4f, 1.1f},
                {-3.0f, -0.5f, 0f, -1f, -0.6f, 0f, 3.0f, 1.0f}, {-3.0f, 6.0f, 0.6f, -1f, 0.15f, 0.4f, 2.4f, 0.8f},
                {-3.0f, 8.0f, -0.6f, -1f, 0.15f, 0.4f, 2.2f, 0.8f}};
        private static final float[][] LEG = {{0f, 7.0f, 2.0f, 0f, 0.4f, 1f, 2.4f, 0.9f}};

        Spikes(RenderLayerParent<Helion3, Model> parent) {
            super(parent);
        }

        @Override
        public void render(PoseStack ps, MultiBufferSource buffers, int light, Helion3 e, float limbSwing, float limbAmount,
                           float pt, float age, float headYaw, float headPitch) {
            if (e.isInvisible()) {
                return;
            }
            Model m = getParentModel();
            int overlay = LivingEntityRenderer.getOverlayCoords(e, 0f);
            float claw = e.claws() / 8f;   // cakar & tulang menguat oleh Cryon: duri menghijau
            int r = (int) Mth.lerp(claw, 255f, 170f), g = 255, b = (int) Mth.lerp(claw, 255f, 190f);
            VertexConsumer solid = buffers.getBuffer(RenderType.entityCutoutNoCull(SPIKE));
            all(m, ps, solid, light, overlay, r, g, b);
            if (claw > 0.01f) {
                VertexConsumer glow = buffers.getBuffer(RenderType.eyes(SPIKE));
                int gl = (int) (claw * 200f);
                all(m, ps, glow, 15728880, OverlayTexture.NO_OVERLAY, gl / 4, gl, gl / 3);
            }
        }

        private static void all(Model m, PoseStack ps, VertexConsumer vc, int light, int overlay, int r, int g, int b) {
            group(m.body, BODY, false, ps, vc, light, overlay, r, g, b);
            group(m.head, HEAD, false, ps, vc, light, overlay, r, g, b);
            group(m.rightArm, RIGHT_ARM, false, ps, vc, light, overlay, r, g, b);
            group(m.leftArm, RIGHT_ARM, true, ps, vc, light, overlay, r, g, b);
            group(m.rightLeg, LEG, false, ps, vc, light, overlay, r, g, b);
            group(m.leftLeg, LEG, false, ps, vc, light, overlay, r, g, b);
        }

        private static void group(ModelPart part, float[][] spikes, boolean mirror, PoseStack ps, VertexConsumer vc, int light,
                                  int overlay, int r, int g, int b) {
            if (!part.visible) {
                return;
            }
            ps.pushPose();
            part.translateAndRotate(ps);
            PoseStack.Pose pose = ps.last();
            for (float[] s : spikes) {
                float sx = mirror ? -1f : 1f;
                spike(vc, pose, s[0] * sx / 16f, s[1] / 16f, s[2] / 16f, s[3] * sx, s[4], s[5], s[6] / 16f, s[7] / 32f,
                        light, overlay, r, g, b);
            }
            ps.popPose();
        }

        /** Piramida empat sisi: pangkal persegi di (x,y,z), ujung sejauh len searah (dx,dy,dz). */
        private static void spike(VertexConsumer vc, PoseStack.Pose pose, float x, float y, float z, float dx, float dy, float dz,
                                  float len, float half, int light, int overlay, int r, int g, int b) {
            float dl = Mth.sqrt(dx * dx + dy * dy + dz * dz);
            dx /= dl;
            dy /= dl;
            dz /= dl;
            float ax = Math.abs(dy) < 0.9f ? 0f : 1f, ay = Math.abs(dy) < 0.9f ? 1f : 0f;
            float ux = ay * dz, uy = -ax * dz, uz = ax * dy - ay * dx;   // u = a x d
            float ul = Mth.sqrt(ux * ux + uy * uy + uz * uz);
            ux /= ul;
            uy /= ul;
            uz /= ul;
            float vx = dy * uz - dz * uy, vy = dz * ux - dx * uz, vz = dx * uy - dy * ux;   // v = d x u
            float[] cx = new float[4], cy = new float[4], cz = new float[4];
            for (int i = 0; i < 4; i++) {
                float su = (i == 0 || i == 3) ? -1f : 1f, sv = (i < 2) ? -1f : 1f;
                cx[i] = x + (ux * su + vx * sv) * half;
                cy[i] = y + (uy * su + vy * sv) * half;
                cz[i] = z + (uz * su + vz * sv) * half;
            }
            float tx = x + dx * len, ty = y + dy * len, tz = z + dz * len;
            for (int i = 0; i < 4; i++) {
                int j = (i + 1) % 4;
                float ex1 = cx[j] - cx[i], ey1 = cy[j] - cy[i], ez1 = cz[j] - cz[i];
                float ex2 = tx - cx[i], ey2 = ty - cy[i], ez2 = tz - cz[i];
                float nx = ey1 * ez2 - ez1 * ey2, ny = ez1 * ex2 - ex1 * ez2, nz = ex1 * ey2 - ey1 * ex2;
                float nl = Mth.sqrt(nx * nx + ny * ny + nz * nz) + 1.0E-6f;
                nx /= nl;
                ny /= nl;
                nz /= nl;
                vertex(vc, pose, cx[i], cy[i], cz[i], 0f, 1f, light, overlay, r, g, b, nx, ny, nz);
                vertex(vc, pose, cx[j], cy[j], cz[j], 1f, 1f, light, overlay, r, g, b, nx, ny, nz);
                vertex(vc, pose, tx, ty, tz, 0.5f, 0f, light, overlay, r, g, b, nx, ny, nz);
                vertex(vc, pose, tx, ty, tz, 0.5f, 0f, light, overlay, r, g, b, nx, ny, nz);
            }
        }

        private static void vertex(VertexConsumer vc, PoseStack.Pose pose, float x, float y, float z, float u, float v, int light,
                                   int overlay, int r, int g, int b, float nx, float ny, float nz) {
            vc.addVertex(pose, x, y, z).setColor(r, g, b, 255).setUv(u, v).setOverlay(overlay).setLight(light)
                    .setNormal(pose, nx, ny, nz);
        }
    }
}
