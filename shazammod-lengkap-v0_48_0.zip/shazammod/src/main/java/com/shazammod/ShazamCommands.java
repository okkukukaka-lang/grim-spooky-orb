package com.shazammod;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.shazammod.guardian.GuardianKind;
import com.shazammod.guardian.ShazamGuardian;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.phys.Vec3;

/** Perintah buat ngetes (butuh cheat). Jalan sungguhannya: enam totem penjaga (Shazam) dan Ujian Kahndaq (Black Adam). */
public final class ShazamCommands {
    private ShazamCommands() {}

    private static final List<String> FORM_IDS = Arrays.stream(ShazamForm.values()).map(form -> form.id).toList();

    private static final List<String> GUARDIAN_IDS =
            Arrays.stream(GuardianKind.values()).map(kind -> kind.id).toList();

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("shazam")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("unlock")
                        .executes(ctx -> unlock(ctx.getSource(), ShazamForm.SHAZAM, self(ctx.getSource())))
                        .then(champion("shazam", true, ShazamForm.SHAZAM))
                        .then(champion("black_adam", true, ShazamForm.BLACK_ADAM))
                        .then(champion("sabbac", true, ShazamForm.SABBAC))
                        .then(champion("lintang", true, ShazamForm.LINTANG))
                        .then(champion("helion", true, ShazamForm.HELION))
                        .then(champion("all", true, null))
                        .then(Commands.argument("targets", EntityArgument.players())
                                .executes(ctx -> unlock(ctx.getSource(), ShazamForm.SHAZAM,
                                        EntityArgument.getPlayers(ctx, "targets")))))
                .then(Commands.literal("lock")
                        .executes(ctx -> lock(ctx.getSource(), null, self(ctx.getSource())))
                        .then(champion("shazam", false, ShazamForm.SHAZAM))
                        .then(champion("black_adam", false, ShazamForm.BLACK_ADAM))
                        .then(champion("sabbac", false, ShazamForm.SABBAC))
                        .then(champion("lintang", false, ShazamForm.LINTANG))
                        .then(champion("helion", false, ShazamForm.HELION))
                        .then(champion("all", false, null))
                        .then(Commands.argument("targets", EntityArgument.players())
                                .executes(ctx -> lock(ctx.getSource(), null, EntityArgument.getPlayers(ctx, "targets")))))
                .then(Commands.literal("trial")
                        .executes(ctx -> trial(ctx.getSource(), self(ctx.getSource())))
                        .then(Commands.argument("targets", EntityArgument.players())
                                .executes(ctx -> trial(ctx.getSource(), EntityArgument.getPlayers(ctx, "targets")))))
                .then(Commands.literal("pact")
                        .executes(ctx -> pact(ctx.getSource(), self(ctx.getSource())))
                        .then(Commands.argument("targets", EntityArgument.players())
                                .executes(ctx -> pact(ctx.getSource(), EntityArgument.getPlayers(ctx, "targets")))))
                .then(Commands.literal("rite")
                        .executes(ctx -> rite(ctx.getSource(), self(ctx.getSource())))
                        .then(Commands.argument("targets", EntityArgument.players())
                                .executes(ctx -> rite(ctx.getSource(), EntityArgument.getPlayers(ctx, "targets")))))
                .then(Commands.literal("helion3")
                        .executes(ctx -> helion3(ctx.getSource(), self(ctx.getSource())))
                        .then(Commands.argument("targets", EntityArgument.players())
                                .executes(ctx -> helion3(ctx.getSource(), EntityArgument.getPlayers(ctx, "targets")))))
                .then(Commands.literal("duel")
                        .executes(ctx -> duel(ctx.getSource(), self(ctx.getSource())))
                        .then(Commands.argument("targets", EntityArgument.players())
                                .executes(ctx -> duel(ctx.getSource(), EntityArgument.getPlayers(ctx, "targets")))))
                .then(Commands.literal("helion_rite")
                        .executes(ctx -> helionRite(ctx.getSource(), self(ctx.getSource())))
                        .then(Commands.argument("targets", EntityArgument.players())
                                .executes(ctx -> helionRite(ctx.getSource(), EntityArgument.getPlayers(ctx, "targets")))))
                .then(Commands.literal("rival")
                        .then(Commands.argument("champion", StringArgumentType.word())
                                .suggests((ctx, builder) -> SharedSuggestionProvider.suggest(FORM_IDS, builder))
                                .executes(ctx -> rival(ctx.getSource(), StringArgumentType.getString(ctx, "champion"),
                                        self(ctx.getSource())))
                                .then(Commands.argument("targets", EntityArgument.players())
                                        .executes(ctx -> rival(ctx.getSource(), StringArgumentType.getString(ctx, "champion"),
                                                EntityArgument.getPlayers(ctx, "targets"))))))
                .then(Commands.literal("energy")
                        .then(Commands.argument("amount", FloatArgumentType.floatArg(0f, ShazamPowers.MAX_ENERGY))
                                .executes(ctx -> setEnergy(ctx.getSource(), FloatArgumentType.getFloat(ctx, "amount")))))
                .then(Commands.literal("favor")
                        .then(Commands.argument("stacks", IntegerArgumentType.integer(0, ShazamPowers.FAVOR_MAX_STACKS))
                                .executes(ctx -> setFavor(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "stacks")))))
                .then(Commands.literal("form")
                        .then(Commands.argument("champion", StringArgumentType.word())
                                .suggests((ctx, builder) -> SharedSuggestionProvider.suggest(FORM_IDS, builder))
                                .executes(ctx -> setForm(ctx.getSource(), StringArgumentType.getString(ctx, "champion"),
                                        List.of(ctx.getSource().getPlayerOrException())))
                                .then(Commands.argument("targets", EntityArgument.players())
                                        .executes(ctx -> setForm(ctx.getSource(), StringArgumentType.getString(ctx, "champion"),
                                                EntityArgument.getPlayers(ctx, "targets"))))))
                .then(Commands.literal("summon")
                        .then(Commands.argument("guardian", StringArgumentType.word())
                                .suggests((ctx, builder) -> SharedSuggestionProvider.suggest(GUARDIAN_IDS, builder))
                                .executes(ctx -> summon(ctx.getSource(), StringArgumentType.getString(ctx, "guardian"))))));
    }

    private static List<ServerPlayer> self(CommandSourceStack source) throws CommandSyntaxException {
        return List.of(source.getPlayerOrException());
    }

    /** Cabang "shazam" / "black_adam" / "all" (null) di bawah unlock/lock, dengan [pemain] opsional. */
    private static com.mojang.brigadier.builder.LiteralArgumentBuilder<CommandSourceStack> champion(String name, boolean opening,
                                                                                                     ShazamForm form) {
        return Commands.literal(name)
                .executes(ctx -> opening ? unlock(ctx.getSource(), form, self(ctx.getSource()))
                        : lock(ctx.getSource(), form, self(ctx.getSource())))
                .then(Commands.argument("targets", EntityArgument.players())
                        .executes(ctx -> opening ? unlock(ctx.getSource(), form, EntityArgument.getPlayers(ctx, "targets"))
                                : lock(ctx.getSource(), form, EntityArgument.getPlayers(ctx, "targets"))));
    }

    /** form = null: semua juara. */
    private static int unlock(CommandSourceStack source, ShazamForm form, Collection<ServerPlayer> targets) {
        for (ServerPlayer player : targets) {
            if (form == null || form == ShazamForm.HELION) {
                ShazamPowers.unlockHelion(player);
            }
            if (form == null || form == ShazamForm.LINTANG) {
                ShazamPowers.unlockLintang(player);
            }
            if (form == null || form == ShazamForm.SABBAC) {
                ShazamPowers.unlockSabbac(player);
            }
            if (form == null || form == ShazamForm.BLACK_ADAM) {
                ShazamPowers.unlockAdam(player);
            }
            if (form == null || form == ShazamForm.SHAZAM) {
                ShazamPowers.unlock(player);
            }
        }
        Component which = form == null ? Component.translatable("champion.shazammod.all")
                : Component.translatable("champion.shazammod." + form.id);
        source.sendSuccess(() -> Component.translatable("commands.shazammod.unlock", which, targets.size()), true);
        return targets.size();
    }

    private static int lock(CommandSourceStack source, ShazamForm form, Collection<ServerPlayer> targets) {
        for (ServerPlayer player : targets) {
            ShazamPowers.lock(player, form);
        }
        Component which = form == null ? Component.translatable("champion.shazammod.all")
                : Component.translatable("champion.shazammod." + form.id);
        source.sendSuccess(() -> Component.translatable("commands.shazammod.lock", which, targets.size()), true);
        return targets.size();
    }

    /** /shazam trial [pemain]: mulai Ujian Kahndaq di tempat (tanpa syarat gurun & langit terbuka), buat dites. */
    private static int trial(CommandSourceStack source, Collection<ServerPlayer> targets) {
        for (ServerPlayer player : targets) {
            KahndaqTrial.begin(player);
        }
        source.sendSuccess(() -> Component.translatable("commands.shazammod.trial", targets.size()), true);
        return targets.size();
    }

    /** 0.30 /shazam pact [pemain]: mulai Perjanjian Enam Iblis di tempat (tanpa mahkota & tanpa syarat matahari), buat dites. */
    private static int pact(CommandSourceStack source, Collection<ServerPlayer> targets) {
        for (ServerPlayer player : targets) {
            SabbacPact.begin(player, true);
        }
        source.sendSuccess(() -> Component.translatable("commands.shazammod.pact", targets.size()), true);
        return targets.size();
    }

    /** 0.32 /shazam rite [pemain]: mulai Penyatuan Bintang di tempat (tanpa kristal & tanpa matahari), buat dites. */
    private static int rite(CommandSourceStack source, Collection<ServerPlayer> targets) {
        for (ServerPlayer player : targets) {
            LintangRite.begin(player, true);
        }
        source.sendSuccess(() -> Component.translatable("commands.shazammod.rite", targets.size()), true);
        return targets.size();
    }

    /** 0.48 /shazam helion3 [pemain]: Subjek Tiga bangkit di dekat pemain itu, Lintang & Helion-6 datang membantu. */
    private static int helion3(CommandSourceStack source, Collection<ServerPlayer> targets) {
        int count = 0;
        for (ServerPlayer player : targets) {
            if (com.shazammod.rival.RivalSpawner.subjectThree(player, true)) {
                count++;
            }
        }
        int made = count;
        if (made > 0) {
            source.sendSuccess(() -> Component.translatable("commands.shazammod.helion3", made), true);
        } else {
            source.sendFailure(Component.translatable("commands.shazammod.helion3_failed"));
        }
        return made;
    }

    /** 0.47 /shazam duel [pemain]: Rival Lintang & Rival Helion-6 datang dan saling bertarung di dekat pemain itu. */
    private static int duel(CommandSourceStack source, Collection<ServerPlayer> targets) {
        int count = 0;
        for (ServerPlayer player : targets) {
            if (com.shazammod.rival.RivalSpawner.duel(player, true)) {
                count++;
            }
        }
        int made = count;
        if (made > 0) {
            source.sendSuccess(() -> Component.translatable("commands.shazammod.duel", made), true);
        } else {
            source.sendFailure(Component.translatable("commands.shazammod.duel_failed"));
        }
        return made;
    }

    /** 0.43 /shazam helion_rite [pemain]: mulai Eksperimen Proyek Helion-6 di tempat (tanpa serum & syarat gelap), buat dites. */
    private static int helionRite(CommandSourceStack source, Collection<ServerPlayer> targets) {
        for (ServerPlayer player : targets) {
            HelionRite.begin(player, true);
        }
        source.sendSuccess(() -> Component.translatable("commands.shazammod.helion_rite", targets.size()), true);
        return targets.size();
    }

    /** 0.30 /shazam rival shazam|black_adam|sabbac [pemain]: panggil Rival Juara untuk menantang pemain itu. */
    private static int rival(CommandSourceStack source, String id, Collection<ServerPlayer> targets) {
        ShazamForm form = ShazamForm.byName(id);
        if (form == null) {
            source.sendFailure(Component.translatable("commands.shazammod.unknown_form", id));
            return 0;
        }
        int count = 0;
        for (ServerPlayer player : targets) {
            if (com.shazammod.rival.RivalSpawner.summon(player, form, true)) {
                count++;
            }
        }
        int made = count;
        if (made > 0) {
            source.sendSuccess(() -> Component.translatable("commands.shazammod.rival",
                    Component.translatable("champion.shazammod." + form.id), made), true);
        } else {
            source.sendFailure(Component.translatable("commands.shazammod.rival_failed"));
        }
        return made;
    }

    /** /shazam form shazam|black_adam|sabbac [pemain]: pilih juara (yang sedang berubah wujud balik jadi manusia dulu). */
    private static int setForm(CommandSourceStack source, String id, Collection<ServerPlayer> targets) {
        ShazamForm form = ShazamForm.byName(id);
        if (form == null) {
            source.sendFailure(Component.translatable("commands.shazammod.unknown_form", id));
            return 0;
        }
        int changed = 0;
        for (ServerPlayer player : targets) {
            if (!ShazamPowers.data(player).has(form)) {   // juara harus didapat lewat jalannya dulu
                source.sendFailure(Component.translatable("commands.shazammod.form_not_owned", player.getDisplayName(),
                        Component.translatable("champion.shazammod." + form.id)));
                continue;
            }
            ShazamPowers.setForm(player, form, true);
            changed++;
        }
        int count = changed;
        if (count > 0) {
            source.sendSuccess(() -> Component.translatable("commands.shazammod.form",
                    Component.translatable("champion.shazammod." + form.id), count), true);
        }
        return count;
    }

    private static int setEnergy(CommandSourceStack source, float amount) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        ShazamPowers.setData(player, ShazamPowers.data(player).withEnergy(amount));
        source.sendSuccess(() -> Component.translatable("commands.shazammod.energy", Math.round(amount)), true);
        return 1;
    }

    /** 0.31 /shazam favor <0-20>: atur tumpukan Restu Para Dewa (harus sedang berwujud Shazam), buat dites. */
    private static int setFavor(CommandSourceStack source, int stacks) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        if (!ShazamFavor.isShazam(player)) {
            source.sendFailure(Component.translatable("commands.shazammod.favor_not_shazam"));
            return 0;
        }
        ShazamFavor.setForTest(player, stacks);
        source.sendSuccess(() -> Component.translatable("commands.shazammod.favor", stacks, ShazamPowers.FAVOR_MAX_STACKS),
                true);
        return 1;
    }

    /** Munculkan penjaga 5 blok di depan pemain, langsung bangun. */
    private static int summon(CommandSourceStack source, String id) throws CommandSyntaxException {
        GuardianKind kind = GuardianKind.byId(id);
        if (kind == null) {
            source.sendFailure(Component.translatable("commands.shazammod.unknown_guardian", id));
            return 0;
        }
        ServerPlayer player = source.getPlayerOrException();
        ServerLevel level = player.serverLevel();
        Mob mob = kind.entityType().create(level);
        if (mob == null) {
            return 0;
        }
        Vec3 look = player.getLookAngle();
        mob.moveTo(player.getX() + look.x * 5.0, player.getY(), player.getZ() + look.z * 5.0,
                player.getYRot() + 180f, 0f);
        level.addFreshEntity(mob);
        if (mob instanceof ShazamGuardian guardian) {
            guardian.core().wake();
        }
        source.sendSuccess(() -> Component.translatable("commands.shazammod.summon", mob.getDisplayName()), true);
        return 1;
    }
}
