"""Tekstur Subjek Tiga (Helion-3), Sang Penghancur Abadi (0.48, desain orisinal).

Prototipe Proyek Helion yang selnya berulang kali dihancurkan & dipaksa tumbuh lagi dengan radiasi Cryon dan sengatan
cahaya buatan: kulit hangus merah-arang penuh bekas jahitan operasi, retakan yang menyala DUA warna (sisi kanan putih-emas
bekas cahaya, sisi kiri hijau bekas Cryon), pelat sel mati yang mengapur jadi lapisan baju zirah tulang, sisa tali
pengekang lab, dan kalung besi patah bertanda III. Mata kanan putih, mata kiri hijau.

    python3 helion3_textures.py ASSETS_DIR [PREVIEW.png]

Menulis (tata letak UV pemain 64x64, skala 4):
  textures/entity/helion3/skin.png   256x256  kulit (base) + pelat & tali (lapisan luar, alpha)
  textures/entity/helion3/glow.png   256x256  retakan & mata yang menyala (RenderType.eyes, hitam = mati)
  textures/entity/helion3/spike.png  16x16    duri sel mati (pangkal gelap -> ujung pucat)
"""
import os
import sys

import numpy as np
from PIL import Image

S = 4
N = 64 * S
rng = np.random.default_rng(3)

FLESH = np.array([92, 44, 40], float)
FLESH_HI = np.array([138, 70, 58], float)
FLESH_SH = np.array([34, 16, 16], float)
SCAR = np.array([128, 86, 82], float)
PLATE = np.array([124, 110, 94], float)
PLATE_HI = np.array([176, 162, 140], float)
PLATE_SH = np.array([58, 50, 44], float)
LEATHER = np.array([38, 30, 26], float)
STEEL = np.array([96, 98, 104], float)
RUST = np.array([110, 58, 30], float)
LIGHT = np.array([255, 226, 160], float)    # retakan bekas cahaya
CRYON = np.array([70, 255, 140], float)     # retakan bekas Cryon


def noise(h, w, cell, amp):
    gh, gw = h // cell + 2, w // cell + 2
    g = rng.random((gh, gw))
    yy, xx = np.mgrid[0:h, 0:w]
    fy, fx = yy / cell, xx / cell
    y0, x0 = fy.astype(int), fx.astype(int)
    ty, tx = fy - y0, fx - x0
    ty, tx = ty * ty * (3 - 2 * ty), tx * tx * (3 - 2 * tx)
    a = g[y0, x0] * (1 - tx) + g[y0, x0 + 1] * tx
    b = g[y0 + 1, x0] * (1 - tx) + g[y0 + 1, x0 + 1] * tx
    return (a * (1 - ty) + b * ty - 0.5) * 2 * amp


class Face:
    def __init__(self, w, h, glow_rgb):
        self.w, self.h = w, h
        ys, xs = np.mgrid[0:h * S, 0:w * S]
        self.x, self.y = (xs + 0.5) / S, (ys + 0.5) / S
        hh, ww = self.x.shape
        k = 1.0 + noise(hh, ww, 3, 0.10) + noise(hh, ww, 12, 0.14)
        self.rgb = np.clip(FLESH[None, None] * k[..., None], 0, 255)
        hi = np.clip(noise(hh, ww, 9, 1.0), 0, 1)
        self.rgb = self.rgb * (1 - hi[..., None] * 0.35) + FLESH_HI * hi[..., None] * 0.35
        self.alpha = np.full((hh, ww), 255.0)
        self.glow = np.zeros((hh, ww, 3))
        self.glow_rgb = glow_rgb

    def side(self, split):
        """Retakan kanan putih-emas, kiri hijau: split = x model px tempat warnanya berganti (None = satu warna)."""
        self.split = split

    def crack(self, pts, strength=1.0, width=0.17, rgb=None):
        col = self.glow_rgb if rgb is None else rgb
        for (ax, ay), (bx, by) in zip(pts[:-1], pts[1:]):
            dx, dy = bx - ax, by - ay
            L2 = dx * dx + dy * dy + 1e-9
            t = np.clip(((self.x - ax) * dx + (self.y - ay) * dy) / L2, 0, 1)
            d = np.hypot(self.x - (ax + t * dx), self.y - (ay + t * dy))
            m = d < width
            self.rgb = np.where(m[..., None], FLESH_SH, self.rgb)
            self.glow = np.maximum(self.glow, (m[..., None] * col[None, None] * strength))

    def random_cracks(self, n, length, strength=1.0, rgb_left=None, rgb_right=None, split=None):
        for _ in range(n):
            x, y = rng.uniform(0.3, self.w - 0.3), rng.uniform(0.3, self.h - 0.3)
            pts = [(x, y)]
            ang = rng.uniform(0, np.pi * 2)
            for _ in range(int(length)):
                ang += rng.normal(0, 0.7)
                x = float(np.clip(x + np.cos(ang) * 0.9, 0.1, self.w - 0.1))
                y = float(np.clip(y + np.sin(ang) * 0.9, 0.1, self.h - 0.1))
                pts.append((x, y))
            col = None
            if split is not None and rgb_left is not None:
                col = rgb_left if pts[0][0] < split else rgb_right
            self.crack(pts, strength, rgb=col)

    def stitches(self, x0, y0, x1, y1):
        n = int(max(abs(x1 - x0), abs(y1 - y0)) * 2) + 2
        self.crack([(x0, y0), (x1, y1)], 0.0, 0.1)
        dx, dy = x1 - x0, y1 - y0
        L = np.hypot(dx, dy) + 1e-9
        px, py = -dy / L * 0.35, dx / L * 0.35
        for i in range(n):
            t = i / max(1, n - 1)
            cx, cy = x0 + dx * t, y0 + dy * t
            m = (np.abs((self.x - cx) * dx / L + (self.y - cy) * dy / L) < 0.07) & \
                (np.abs((self.x - cx) * px / 0.35 + (self.y - cy) * py / 0.35) < 0.35)
            self.rgb = np.where(m[..., None], SCAR, self.rgb)

    def plate(self, x0, y0, x1, y1, cracked=True, only_alpha=False):
        inside = (self.x >= x0) & (self.x < x1) & (self.y >= y0) & (self.y < y1)
        hh, ww = self.x.shape
        k = 1.0 + noise(hh, ww, 2, 0.12)
        col = PLATE[None, None] * k[..., None]
        e = 0.3
        lit = inside & ((self.y < y0 + e) | (self.x < x0 + e))
        sh = inside & ((self.y >= y1 - e) | (self.x >= x1 - e))
        col = np.where(lit[..., None], PLATE_HI, col)
        col = np.where(sh[..., None], PLATE_SH, col)
        self.rgb = np.where(inside[..., None], col, self.rgb)
        self.alpha = np.where(inside, 255.0, self.alpha if not only_alpha else self.alpha)
        if cracked:   # garis rekahan gelap di pelat
            for _ in range(2):
                ax, ay = rng.uniform(x0, x1), y0
                pts = [(ax, ay)]
                for _ in range(4):
                    ax = float(np.clip(ax + rng.normal(0, 0.5), x0, x1))
                    ay = min(y1, ay + (y1 - y0) / 4)
                    pts.append((ax, ay))
                for (a1, b1), (a2, b2) in zip(pts[:-1], pts[1:]):
                    dx, dy = a2 - a1, b2 - b1
                    L2 = dx * dx + dy * dy + 1e-9
                    t = np.clip(((self.x - a1) * dx + (self.y - b1) * dy) / L2, 0, 1)
                    d = np.hypot(self.x - (a1 + t * dx), self.y - (b1 + t * dy))
                    self.rgb = np.where(((d < 0.09) & inside)[..., None], PLATE_SH, self.rgb)

    def strap(self, x0, y0, x1, y1, buckle=None):
        inside = (self.x >= x0) & (self.x < x1) & (self.y >= y0) & (self.y < y1)
        hh, ww = self.x.shape
        col = LEATHER[None, None] * (1.0 + noise(hh, ww, 2, 0.15))[..., None]
        edge = inside & ((self.y < y0 + 0.2) | (self.y >= y1 - 0.2))
        col = np.where(edge[..., None], LEATHER * 0.6, col)
        self.rgb = np.where(inside[..., None], col, self.rgb)
        self.alpha = np.where(inside, 255.0, self.alpha)
        if buckle is not None:
            bx = buckle
            m = (np.abs(self.x - bx) < 0.55) & (self.y >= y0 - 0.1) & (self.y < y1 + 0.1)
            inner = (np.abs(self.x - bx) < 0.3) & (self.y >= y0 + 0.25) & (self.y < y1 - 0.25)
            self.rgb = np.where(m[..., None], STEEL, self.rgb)
            self.rgb = np.where(inner[..., None], LEATHER * 0.5, self.rgb)
            self.alpha = np.where(m, 255.0, self.alpha)

    def clear(self):
        self.alpha[:] = 0.0


def put(img, glow, u, v, f):
    hh, ww = f.x.shape
    y0, x0 = v * S, u * S
    img[y0:y0 + hh, x0:x0 + ww, :3] = np.clip(f.rgb, 0, 255)
    img[y0:y0 + hh, x0:x0 + ww, 3] = f.alpha
    glow[y0:y0 + hh, x0:x0 + ww] = np.maximum(glow[y0:y0 + hh, x0:x0 + ww], f.glow)


def box(img, glow, u, v, w, h, d, faces):
    top, bottom, right, front, left, back = faces
    put(img, glow, u + d, v, top)
    put(img, glow, u + d + w, v, bottom)
    put(img, glow, u, v + d, right)
    put(img, glow, u + d, v + d, front)
    put(img, glow, u + d + w, v + d, left)
    put(img, glow, u + d + w + d, v + d, back)


def six(w, h, d, rgb):
    return [Face(w, d, rgb), Face(w, d, rgb), Face(d, h, rgb), Face(w, h, rgb), Face(d, h, rgb), Face(w, h, rgb)]


def head_faces(outer):
    f = six(8, 8, 8, LIGHT)
    top, bottom, right, front, left, back = f
    if outer:
        for x in f:
            x.clear()
        top.plate(1.0, 0.5, 7.0, 7.5)            # pelat tengkorak yang mengapur
        back.plate(1.5, 0.3, 6.5, 3.2)
        right.plate(4.5, 0.4, 7.6, 2.4)
        left.plate(0.4, 0.4, 3.5, 2.4)
        return f
    front.rgb = np.where(((front.y > 2.6) & (front.y < 3.4))[..., None], FLESH_SH * 1.2, front.rgb)   # alis tebal
    for ex, col in ((2.5, LIGHT), (5.5, CRYON)):   # rongga mata
        m = (np.abs(front.x - ex) < 0.95) & (np.abs(front.y - 4.0) < 0.55)
        front.rgb = np.where(m[..., None], np.array([10, 6, 6]), front.rgb)
        core = (np.abs(front.x - ex) < 0.5) & (np.abs(front.y - 4.0) < 0.28)
        front.glow = np.where(core[..., None], col[None, None], front.glow)
    m = (np.abs(front.x - 4.0) < 0.35) & (front.y > 3.5) & (front.y < 5.4)   # batang hidung
    front.rgb = np.where(m[..., None], FLESH_SH * 1.4, front.rgb)
    teeth = (front.x > 2.0) & (front.x < 6.0) & (front.y > 6.0) & (front.y < 6.9)   # gigi terkatup
    gaps = teeth & (np.mod(front.x * 2.0, 1.0) < 0.18)
    front.rgb = np.where(teeth[..., None], np.array([196, 184, 150]), front.rgb)
    front.rgb = np.where(gaps[..., None], np.array([30, 16, 14]), front.rgb)
    front.stitches(1.0, 1.2, 3.2, 2.4)
    front.random_cracks(2, 4, 0.9, LIGHT, CRYON, split=4.0)
    for face, col in ((right, LIGHT), (left, CRYON), (back, None), (top, None)):
        face.random_cracks(3, 5, 0.85, LIGHT, CRYON, split=face.w / 2.0)
    return f


def body_faces(outer):
    f = six(8, 12, 4, LIGHT)
    top, bottom, right, front, left, back = f
    if outer:
        for x in f:
            x.clear()
        for face in (front, back, right, left):   # kalung besi patah
            face.strap(0, 0.0, face.w, 1.3)
            m = (face.y < 1.3)
            face.rgb = np.where(m[..., None], STEEL * (1.0 + noise(*face.x.shape, 2, 0.1))[..., None], face.rgb)
            rust = m & (noise(*face.x.shape, 3, 1.0) > 0.25)
            face.rgb = np.where(rust[..., None], RUST, face.rgb)
        for xs in (2.9, 3.6, 4.3):   # stensil III di depan kalung
            m = (np.abs(front.x - xs) < 0.16) & (front.y > 0.25) & (front.y < 1.05)
            front.rgb = np.where(m[..., None], np.array([214, 206, 190]), front.rgb)
        back.plate(0.6, 1.6, 3.6, 6.2)            # pelat tulang belikat
        back.plate(4.4, 1.6, 7.4, 6.2)
        back.plate(3.4, 6.4, 4.6, 10.2)           # ruas tulang punggung
        right.plate(0.4, 2.0, 3.6, 5.0)
        left.plate(0.4, 2.0, 3.6, 5.0)
        for face in (front, back, right, left):   # sabuk pengekang di pinggang
            face.strap(0, 9.6, face.w, 10.9, buckle=face.w / 2.0 if face is front else None)
        return f
    front.stitches(2.0, 2.0, 6.0, 5.0)            # bekas operasi
    front.stitches(4.0, 6.0, 4.0, 9.5)
    m = (np.abs(front.y - (front.x * 0.75 + 0.8)) < 0.55) & (front.y > 1.2) & (front.y < 9.5)   # tali silang dada
    front.rgb = np.where(m[..., None], LEATHER, front.rgb)
    for face in (front, back):
        face.random_cracks(5, 7, 1.0, LIGHT if face is front else CRYON, CRYON if face is front else LIGHT, split=4.0)
    right.random_cracks(3, 6, 0.9, LIGHT, LIGHT, split=0)
    left.random_cracks(3, 6, 0.9, CRYON, CRYON, split=0)
    return f


def limb_faces(outer, glow_rgb, arm):
    f = six(4, 12, 4, glow_rgb)
    top, bottom, right, front, left, back = f
    if outer:
        for x in f:
            x.clear()
        if arm:
            top.plate(0.2, 0.2, 3.8, 3.8)
            for face in (right, left, front, back):
                face.plate(0.0, 0.0, 4.0, 3.4)      # pelindung bahu dari sel mati
            for face in (right, left):
                face.plate(0.6, 5.6, 3.4, 8.6)      # punggung lengan bawah
            for face in (front, back, right, left):
                face.strap(0, 9.0, 4.0, 10.3, buckle=2.0 if face is front else None)   # borgol pergelangan
        else:
            front.plate(0.4, 4.6, 3.6, 6.6)         # lutut
            front.plate(0.5, 7.0, 3.5, 10.6)        # tulang kering
            for face in (front, back, right, left):
                face.strap(0, 2.4, 4.0, 3.6, buckle=2.0 if face is front else None)
        return f
    for face in (front, back, right, left):
        face.random_cracks(3, 6, 0.95)
    front.stitches(1.0, 2.0, 3.0, 5.5)
    if arm:   # tangan & cakar gelap
        for face in (front, back, right, left, bottom):
            m = face.y > 10.6 if face is not bottom else np.ones_like(face.x, bool)
            face.rgb = np.where(m[..., None], FLESH_SH * 1.3, face.rgb)
    return f


def skin(out):
    img = np.zeros((N, N, 4), float)
    glow = np.zeros((N, N, 3), float)
    box(img, glow, 0, 0, 8, 8, 8, head_faces(False))
    box(img, glow, 32, 0, 8, 8, 8, head_faces(True))
    box(img, glow, 16, 16, 8, 12, 4, body_faces(False))
    box(img, glow, 16, 32, 8, 12, 4, body_faces(True))
    box(img, glow, 40, 16, 4, 12, 4, limb_faces(False, LIGHT, True))     # lengan kanan: retakan cahaya
    box(img, glow, 40, 32, 4, 12, 4, limb_faces(True, LIGHT, True))
    box(img, glow, 32, 48, 4, 12, 4, limb_faces(False, CRYON, True))     # lengan kiri: retakan Cryon
    box(img, glow, 48, 48, 4, 12, 4, limb_faces(True, CRYON, True))
    box(img, glow, 0, 16, 4, 12, 4, limb_faces(False, LIGHT, False))
    box(img, glow, 0, 32, 4, 12, 4, limb_faces(True, LIGHT, False))
    box(img, glow, 16, 48, 4, 12, 4, limb_faces(False, CRYON, False))
    box(img, glow, 0, 48, 4, 12, 4, limb_faces(True, CRYON, False))
    from scipy import ndimage
    soft = np.stack([ndimage.gaussian_filter(glow[..., c], 2.0) for c in range(3)], -1) * 1.6
    g = np.clip(glow * 1.0 + soft * 0.7, 0, 255)
    gimg = np.zeros((N, N, 4), np.uint8)
    gimg[..., :3] = g.astype(np.uint8)
    gimg[..., 3] = 255
    os.makedirs(os.path.join(out, "textures/entity/helion3"), exist_ok=True)
    Image.fromarray(np.clip(img, 0, 255).astype(np.uint8), "RGBA").save(os.path.join(out, "textures/entity/helion3/skin.png"))
    Image.fromarray(gimg, "RGBA").save(os.path.join(out, "textures/entity/helion3/glow.png"))


def spike(out):
    n = 16
    ys, xs = np.mgrid[0:n, 0:n]
    v = (ys + 0.5) / n                      # 0 = ujung, 1 = pangkal
    col = PLATE_HI[None, None] * (1 - v[..., None]) ** 1.2 + PLATE_SH[None, None] * (1 - (1 - v[..., None]) ** 1.2)
    streak = ((xs % 5) == 1) | ((xs % 7) == 4)
    col = np.where(streak[..., None], col * 0.78, col)
    img = np.zeros((n, n, 4), np.uint8)
    img[..., :3] = np.clip(col, 0, 255).astype(np.uint8)
    img[..., 3] = 255
    Image.fromarray(img, "RGBA").save(os.path.join(out, "textures/entity/helion3/spike.png"))


if __name__ == "__main__":
    assets = sys.argv[1] if len(sys.argv) > 1 else "."
    skin(assets)
    spike(assets)
    if len(sys.argv) > 2:   # pratinjau: tampak depan (base + luar) dan versi menyala
        s = Image.open(os.path.join(assets, "textures/entity/helion3/skin.png")).convert("RGBA")
        g = Image.open(os.path.join(assets, "textures/entity/helion3/glow.png")).convert("RGB")

        def crop(im, u, v, w, h):
            return im.crop((u * S, v * S, (u + w) * S, (v + h) * S))

        def front(im, outer=False):
            W = Image.new("RGBA", (16 * S, 32 * S), (150, 170, 190, 255))
            o = 16 if outer else 0
            W.alpha_composite(crop(im, 8 + (32 if outer else 0), 8, 8, 8).convert("RGBA"), (4 * S, 0))
            W.alpha_composite(crop(im, 20, 20 + o, 8, 12).convert("RGBA"), (4 * S, 8 * S))
            W.alpha_composite(crop(im, 44, 20 + o, 4, 12).convert("RGBA"), (0, 8 * S))
            W.alpha_composite(crop(im, 36 + (16 if outer else 0), 52, 4, 12).convert("RGBA"), (12 * S, 8 * S))
            W.alpha_composite(crop(im, 4, 20 + o, 4, 12).convert("RGBA"), (4 * S, 20 * S))
            W.alpha_composite(crop(im, 20 - (16 if outer else 0), 52, 4, 12).convert("RGBA"), (8 * S, 20 * S))
            return W

        base = front(s)
        base.alpha_composite(front(s, True))
        lit = Image.fromarray(np.clip(np.asarray(base.convert("RGB"), float) * 0.55 + np.asarray(front(g.convert("RGBA")).convert("RGB"), float), 0, 255).astype(np.uint8))
        sheet = Image.new("RGB", (16 * S * 2 * 3 + 20, 32 * S * 2), (40, 40, 48))
        sheet.paste(base.convert("RGB").resize((16 * S * 2, 32 * S * 2), Image.NEAREST), (0, 0))
        sheet = sheet.resize((sheet.width * 2, sheet.height * 2), Image.NEAREST)
        sheet.paste(lit.resize((16 * S * 2, 32 * S * 2), Image.NEAREST), (16 * S * 2 + 10, 0))
        sheet.paste(Image.open(os.path.join(assets, "textures/entity/helion3/spike.png")).convert("RGB").resize((96, 96), Image.NEAREST),
                    (16 * S * 4 + 20, 0))
        sheet.save(sys.argv[2])
    print("ok")
