"""Tekstur Subjek Tiga (Helion-3), Sang Penghancur Abadi (0.48, desain orisinal).

Prototipe Proyek Helion yang selnya berulang kali dihancurkan & dipaksa tumbuh lagi dengan radiasi Cryon dan sengatan
cahaya buatan: kulit hangus merah-arang penuh bekas jahitan operasi, retakan yang menyala DUA warna (sisi kanan putih-emas
bekas cahaya, sisi kiri hijau bekas Cryon), pelat sel mati yang mengapur jadi lapisan baju zirah tulang, sisa tali
pengekang lab, dan kalung besi patah bertanda III. Mata kanan putih, mata kiri hijau.

    python3 helion3_textures.py ASSETS_DIR [PREVIEW.png]

Menulis (tata letak UV pemain 64x64, skala 4):
  textures/entity/helion3/skin.png   256x256  kulit (base) + pelat & tali (lapisan luar, alpha)
  textures/entity/helion3/glow.png   256x256  retakan & mata yang menyala (RenderType.eyes, hitam = mati)
  textures/entity/helion3/spike.png  32x32    tulang sel mati (pangkal gelap -> ujung pucat, serat & retak halus)
  textures/item/helion3_cell.png     16x16    0.49 ikon barang Sel Subjek Tiga

0.49: kulitnya dibuat bervolume - tepi tiap sisi menggelap seperti badan yang bulat, lekuk otot (dada, perut, belikat,
lengan, paha), bercak hangus arang bertepi bara, wajah bertaring dengan rongga mata dalam, dan rongga kristal inti di
tulang dada (tempat kristal 3D-nya menempel) yang retakannya menyala dua warna.
"""
import os
import sys

import numpy as np
from PIL import Image

S = 4
N = 64 * S
rng = np.random.default_rng(3)

FLESH = np.array([92, 44, 40], float)
FLESH_HI = np.array([138, 70, 58], float)
FLESH_SH = np.array([34, 16, 16], float)
SCAR = np.array([128, 86, 82], float)
PLATE = np.array([124, 110, 94], float)
PLATE_HI = np.array([176, 162, 140], float)
PLATE_SH = np.array([58, 50, 44], float)
LEATHER = np.array([38, 30, 26], float)
STEEL = np.array([96, 98, 104], float)
RUST = np.array([110, 58, 30], float)
LIGHT = np.array([255, 226, 160], float)    # retakan bekas cahaya
CRYON = np.array([70, 255, 140], float)     # retakan bekas Cryon
CHAR = np.array([20, 12, 12], float)        # 0.49 bercak hangus arang
EMBER = np.array([190, 60, 30], float)      # tepi bara
BONE = np.array([206, 194, 164], float)     # taring & tulang yang menyembul


def seg_dist(x, y, ax, ay, bx, by):
    dx, dy = bx - ax, by - ay
    L2 = dx * dx + dy * dy + 1e-9
    t = np.clip(((x - ax) * dx + (y - ay) * dy) / L2, 0, 1)
    return np.hypot(x - (ax + t * dx), y - (ay + t * dy))


def noise(h, w, cell, amp):
    gh, gw = h // cell + 2, w // cell + 2
    g = rng.random((gh, gw))
    yy, xx = np.mgrid[0:h, 0:w]
    fy, fx = yy / cell, xx / cell
    y0, x0 = fy.astype(int), fx.astype(int)
    ty, tx = fy - y0, fx - x0
    ty, tx = ty * ty * (3 - 2 * ty), tx * tx * (3 - 2 * tx)
    a = g[y0, x0] * (1 - tx) + g[y0, x0 + 1] * tx
    b = g[y0 + 1, x0] * (1 - tx) + g[y0 + 1, x0 + 1] * tx
    return (a * (1 - ty) + b * ty - 0.5) * 2 * amp


class Face:
    def __init__(self, w, h, glow_rgb):
        self.w, self.h = w, h
        ys, xs = np.mgrid[0:h * S, 0:w * S]
        self.x, self.y = (xs + 0.5) / S, (ys + 0.5) / S
        hh, ww = self.x.shape
        k = 1.0 + noise(hh, ww, 3, 0.10) + noise(hh, ww, 12, 0.14)
        self.rgb = np.clip(FLESH[None, None] * k[..., None], 0, 255)
        hi = np.clip(noise(hh, ww, 9, 1.0), 0, 1)
        self.rgb = self.rgb * (1 - hi[..., None] * 0.35) + FLESH_HI * hi[..., None] * 0.35
        self.alpha = np.full((hh, ww), 255.0)
        self.glow = np.zeros((hh, ww, 3))
        self.glow_rgb = glow_rgb

    # ---------------------------------------------------------------- 0.49: volume, otot, arang
    def shade(self, edge=0.30, top=0.12):
        """Volume: tepi kiri-kanan menggelap (badan bulat), atas sedikit lebih terang dari bawah."""
        u = (self.x / self.w) * 2 - 1
        v = self.y / self.h
        k = 1.0 - edge * np.abs(u) ** 2.2 + top * (0.5 - v)
        self.rgb = np.clip(self.rgb * k[..., None], 0, 255)

    def groove(self, pts, width=0.34, depth=0.42, hi=14.0):
        """Lekuk otot: garis bayangan lembut dengan pantulan terang tipis di sisi bawahnya."""
        for (ax, ay), (bx, by) in zip(pts[:-1], pts[1:]):
            m = np.clip(1 - seg_dist(self.x, self.y, ax, ay, bx, by) / width, 0, 1)
            self.rgb = self.rgb * (1 - depth * m)[..., None]
            m2 = np.clip(1 - seg_dist(self.x, self.y - 0.42, ax, ay, bx, by) / width, 0, 1) * (1 - m)
            self.rgb = np.clip(self.rgb + hi * m2[..., None], 0, 255)

    def bulge(self, cx, cy, rx, ry, amount=16.0):
        """Tonjolan otot: sorotan lembut berbentuk lonjong."""
        d = np.hypot((self.x - cx) / rx, (self.y - cy) / ry)
        self.rgb = np.clip(self.rgb + amount * np.clip(1 - d, 0, 1)[..., None] ** 1.5, 0, 255)

    def blotch(self, n, r0, r1):
        """Bercak hangus arang dengan tepi bara merah tua."""
        hh, ww = self.x.shape
        for _ in range(n):
            cx, cy = rng.uniform(0, self.w), rng.uniform(0, self.h)
            r = rng.uniform(r0, r1)
            d = np.hypot(self.x - cx, (self.y - cy) * rng.uniform(0.7, 1.3)) + noise(hh, ww, 2, 0.35)
            core = np.clip(1 - d / r, 0, 1) ** 0.7
            self.rgb = self.rgb * (1 - 0.74 * core[..., None]) + CHAR[None, None] * 0.74 * core[..., None]
            rim = np.clip(1 - np.abs(d - r) / 0.2, 0, 1)
            self.rgb = np.clip(self.rgb + EMBER[None, None] * rim[..., None] * 0.22, 0, 255)

    def spot(self, cx, cy, rx, ry, rgb, soft=0.0):
        d = np.hypot((self.x - cx) / rx, (self.y - cy) / ry)
        m = np.clip((1 - d) / max(soft, 1e-6), 0, 1) if soft > 0 else (d < 1).astype(float)
        self.rgb = self.rgb * (1 - m[..., None]) + np.asarray(rgb, float)[None, None] * m[..., None]
        return m

    def glow_spot(self, cx, cy, rx, ry, rgb, strength=1.0):
        d = np.hypot((self.x - cx) / rx, (self.y - cy) / ry)
        m = np.clip(1 - d, 0, 1) ** 0.8 * strength
        self.glow = np.maximum(self.glow, m[..., None] * np.asarray(rgb, float)[None, None])

    def side(self, split):
        """Retakan kanan putih-emas, kiri hijau: split = x model px tempat warnanya berganti (None = satu warna)."""
        self.split = split

    def crack(self, pts, strength=1.0, width=0.17, rgb=None):
        col = self.glow_rgb if rgb is None else rgb
        for (ax, ay), (bx, by) in zip(pts[:-1], pts[1:]):
            dx, dy = bx - ax, by - ay
            L2 = dx * dx + dy * dy + 1e-9
            t = np.clip(((self.x - ax) * dx + (self.y - ay) * dy) / L2, 0, 1)
            d = np.hypot(self.x - (ax + t * dx), self.y - (ay + t * dy))
            m = d < width
            self.rgb = np.where(m[..., None], FLESH_SH, self.rgb)
            self.glow = np.maximum(self.glow, (m[..., None] * col[None, None] * strength))

    def random_cracks(self, n, length, strength=1.0, rgb_left=None, rgb_right=None, split=None):
        for _ in range(n):
            x, y = rng.uniform(0.3, self.w - 0.3), rng.uniform(0.3, self.h - 0.3)
            pts = [(x, y)]
            ang = rng.uniform(0, np.pi * 2)
            for _ in range(int(length)):
                ang += rng.normal(0, 0.7)
                x = float(np.clip(x + np.cos(ang) * 0.9, 0.1, self.w - 0.1))
                y = float(np.clip(y + np.sin(ang) * 0.9, 0.1, self.h - 0.1))
                pts.append((x, y))
            col = None
            if split is not None and rgb_left is not None:
                col = rgb_left if pts[0][0] < split else rgb_right
            self.crack(pts, strength, rgb=col)

    def stitches(self, x0, y0, x1, y1):
        n = int(max(abs(x1 - x0), abs(y1 - y0)) * 2) + 2
        self.crack([(x0, y0), (x1, y1)], 0.0, 0.1)
        dx, dy = x1 - x0, y1 - y0
        L = np.hypot(dx, dy) + 1e-9
        px, py = -dy / L * 0.35, dx / L * 0.35
        for i in range(n):
            t = i / max(1, n - 1)
            cx, cy = x0 + dx * t, y0 + dy * t
            m = (np.abs((self.x - cx) * dx / L + (self.y - cy) * dy / L) < 0.07) & \
                (np.abs((self.x - cx) * px / 0.35 + (self.y - cy) * py / 0.35) < 0.35)
            self.rgb = np.where(m[..., None], SCAR, self.rgb)

    def plate(self, x0, y0, x1, y1, cracked=True, only_alpha=False):
        inside = (self.x >= x0) & (self.x < x1) & (self.y >= y0) & (self.y < y1)
        hh, ww = self.x.shape
        k = 1.0 + noise(hh, ww, 2, 0.12)
        col = PLATE[None, None] * k[..., None]
        e = 0.3
        lit = inside & ((self.y < y0 + e) | (self.x < x0 + e))
        sh = inside & ((self.y >= y1 - e) | (self.x >= x1 - e))
        col = np.where(lit[..., None], PLATE_HI, col)
        col = np.where(sh[..., None], PLATE_SH, col)
        self.rgb = np.where(inside[..., None], col, self.rgb)
        self.alpha = np.where(inside, 255.0, self.alpha if not only_alpha else self.alpha)
        if cracked:   # garis rekahan gelap di pelat
            for _ in range(2):
                ax, ay = rng.uniform(x0, x1), y0
                pts = [(ax, ay)]
                for _ in range(4):
                    ax = float(np.clip(ax + rng.normal(0, 0.5), x0, x1))
                    ay = min(y1, ay + (y1 - y0) / 4)
                    pts.append((ax, ay))
                for (a1, b1), (a2, b2) in zip(pts[:-1], pts[1:]):
                    dx, dy = a2 - a1, b2 - b1
                    L2 = dx * dx + dy * dy + 1e-9
                    t = np.clip(((self.x - a1) * dx + (self.y - b1) * dy) / L2, 0, 1)
                    d = np.hypot(self.x - (a1 + t * dx), self.y - (b1 + t * dy))
                    self.rgb = np.where(((d < 0.09) & inside)[..., None], PLATE_SH, self.rgb)

    def strap(self, x0, y0, x1, y1, buckle=None):
        inside = (self.x >= x0) & (self.x < x1) & (self.y >= y0) & (self.y < y1)
        hh, ww = self.x.shape
        col = LEATHER[None, None] * (1.0 + noise(hh, ww, 2, 0.15))[..., None]
        edge = inside & ((self.y < y0 + 0.2) | (self.y >= y1 - 0.2))
        col = np.where(edge[..., None], LEATHER * 0.6, col)
        self.rgb = np.where(inside[..., None], col, self.rgb)
        self.alpha = np.where(inside, 255.0, self.alpha)
        if buckle is not None:
            bx = buckle
            m = (np.abs(self.x - bx) < 0.55) & (self.y >= y0 - 0.1) & (self.y < y1 + 0.1)
            inner = (np.abs(self.x - bx) < 0.3) & (self.y >= y0 + 0.25) & (self.y < y1 - 0.25)
            self.rgb = np.where(m[..., None], STEEL, self.rgb)
            self.rgb = np.where(inner[..., None], LEATHER * 0.5, self.rgb)
            self.alpha = np.where(m, 255.0, self.alpha)

    def clear(self):
        self.alpha[:] = 0.0


def put(img, glow, u, v, f):
    hh, ww = f.x.shape
    y0, x0 = v * S, u * S
    img[y0:y0 + hh, x0:x0 + ww, :3] = np.clip(f.rgb, 0, 255)
    img[y0:y0 + hh, x0:x0 + ww, 3] = f.alpha
    glow[y0:y0 + hh, x0:x0 + ww] = np.maximum(glow[y0:y0 + hh, x0:x0 + ww], f.glow)


def box(img, glow, u, v, w, h, d, faces):
    top, bottom, right, front, left, back = faces
    put(img, glow, u + d, v, top)
    put(img, glow, u + d + w, v, bottom)
    put(img, glow, u, v + d, right)
    put(img, glow, u + d, v + d, front)
    put(img, glow, u + d + w, v + d, left)
    put(img, glow, u + d + w + d, v + d, back)


def six(w, h, d, rgb):
    return [Face(w, d, rgb), Face(w, d, rgb), Face(d, h, rgb), Face(w, h, rgb), Face(d, h, rgb), Face(w, h, rgb)]


def head_faces(outer):
    f = six(8, 8, 8, LIGHT)
    top, bottom, right, front, left, back = f
    if outer:
        for x in f:
            x.clear()
        top.plate(1.0, 0.5, 7.0, 7.5)            # pelat tengkorak yang mengapur
        back.plate(1.5, 0.3, 6.5, 3.2)
        right.plate(4.5, 0.4, 7.6, 2.4)
        left.plate(0.4, 0.4, 3.5, 2.4)
        return f
    # 0.49 wajah: tengkorak bervolume, tonjolan alis berat, rongga mata dalam yang menyala, lubang hidung, dan rahang
    # lebar bertaring yang saling mengunci (dua taring bawah paling besar, tempat taring 3D-nya menempel)
    for face in f:
        face.shade(0.26, 0.10)
    front.blotch(2, 0.8, 1.5)
    front.groove([(0.6, 2.75), (2.4, 2.45), (4.0, 2.9), (5.6, 2.45), (7.4, 2.75)], 0.5, 0.55, 22.0)   # tonjolan alis
    front.bulge(4.0, 1.4, 3.2, 1.2, 14.0)                                                               # dahi
    for side_x in (1.0, 7.0):                                                                           # pipi cekung
        front.spot(side_x, 5.2, 0.9, 1.4, FLESH_SH * 1.2, 1.0)
    for ex, col in ((2.4, LIGHT), (5.6, CRYON)):   # rongga mata
        front.spot(ex, 3.95, 1.15, 0.72, np.array([8, 4, 5]), 0.35)
        front.glow_spot(ex, 4.0, 0.72, 0.4, col, 1.0)
        front.glow_spot(ex, 4.0, 0.3, 0.2, np.array([255, 255, 255]), 1.0)
        front.glow_spot(ex, 4.9, 0.22, 0.9, col, 0.35)                     # cahaya yang menetes dari mata
    front.groove([(4.0, 3.3), (4.0, 4.9)], 0.3, 0.35, 10.0)                # batang hidung
    for nx in (3.55, 4.45):
        front.spot(nx, 5.15, 0.24, 0.3, np.array([12, 6, 6]))
    mouth = (front.x > 1.2) & (front.x < 6.8) & (front.y > 5.75) & (front.y < 7.35)
    front.rgb = np.where(mouth[..., None], np.array([12, 5, 5]), front.rgb)
    lip = (front.x > 1.0) & (front.x < 7.0) & (front.y > 5.5) & (front.y <= 5.75)             # bibir atas tertarik
    front.rgb = np.where(lip[..., None], FLESH_SH * 1.1, front.rgb)
    front.glow_spot(4.0, 6.6, 1.8, 0.45, np.array([170, 66, 30]), 0.55)                       # bara di tenggorokan
    for tx in (2.1, 3.35, 4.65, 5.9):                                                          # empat taring atas besar
        up = (np.abs(front.x - tx) < 0.52 * (1 - (front.y - 5.75) / 0.95)) & (front.y >= 5.75) & (front.y < 6.7)
        front.rgb = np.where(up[..., None], BONE * (0.9 + 0.1 * (front.x[up].mean() > 4)), front.rgb)
    for tx in (2.72, 4.0, 5.28):                                                               # tiga taring bawah di selanya
        dn = (np.abs(front.x - tx) < 0.46 * (1 - (7.35 - front.y) / 0.85)) & (front.y <= 7.35) & (front.y > 6.5)
        front.rgb = np.where(dn[..., None], BONE * 0.84, front.rgb)
    for tx in (1.45, 6.55):                                                                    # dua taring bawah yang mencuat
        tusk = (np.abs(front.x - tx) < 0.44 * (1 - (7.35 - front.y) / 2.3)) & (front.y <= 7.35) & (front.y > 5.05)
        front.rgb = np.where(tusk[..., None], BONE, front.rgb)
        shade_t = tusk & (front.x > tx + 0.08)
        front.rgb = np.where(shade_t[..., None], BONE * 0.74, front.rgb)
    front.bulge(1.9, 4.9, 1.0, 0.5, 14.0)                                                      # tulang pipi
    front.bulge(6.1, 4.9, 1.0, 0.5, 14.0)
    front.stitches(1.0, 1.2, 3.2, 2.4)
    right.groove([(4.2, 5.6), (6.6, 6.4), (7.6, 6.2)], 0.3, 0.4)            # garis rahang di kedua sisi
    left.groove([(3.8, 5.6), (1.4, 6.4), (0.4, 6.2)], 0.3, 0.4)
    back.blotch(2, 0.9, 1.6)
    top.blotch(1, 1.0, 1.8)
    front.random_cracks(2, 4, 0.9, LIGHT, CRYON, split=4.0)
    for face, col in ((right, LIGHT), (left, CRYON), (back, None), (top, None)):
        face.random_cracks(3, 5, 0.85, LIGHT, CRYON, split=face.w / 2.0)
    return f


def body_faces(outer):
    f = six(8, 12, 4, LIGHT)
    top, bottom, right, front, left, back = f
    if outer:
        for x in f:
            x.clear()
        for face in (front, back, right, left):   # kalung besi patah
            face.strap(0, 0.0, face.w, 1.3)
            m = (face.y < 1.3)
            face.rgb = np.where(m[..., None], STEEL * (1.0 + noise(*face.x.shape, 2, 0.1))[..., None], face.rgb)
            rust = m & (noise(*face.x.shape, 3, 1.0) > 0.25)
            face.rgb = np.where(rust[..., None], RUST, face.rgb)
        for xs in (2.9, 3.6, 4.3):   # stensil III di depan kalung
            m = (np.abs(front.x - xs) < 0.16) & (front.y > 0.25) & (front.y < 1.05)
            front.rgb = np.where(m[..., None], np.array([214, 206, 190]), front.rgb)
        back.plate(0.6, 1.6, 3.6, 6.2)            # pelat tulang belikat
        back.plate(4.4, 1.6, 7.4, 6.2)
        back.plate(3.4, 6.4, 4.6, 10.2)           # ruas tulang punggung
        right.plate(0.4, 2.0, 3.6, 5.0)
        left.plate(0.4, 2.0, 3.6, 5.0)
        for face in (front, back, right, left):   # sabuk pengekang di pinggang
            face.strap(0, 9.6, face.w, 10.9, buckle=face.w / 2.0 if face is front else None)
        return f
    # 0.49 volume & otot: dada, perut enam kotak, tulang selangka, alur tulang punggung, belikat
    for face in f:
        face.shade(0.34, 0.14)
    front.blotch(3, 0.9, 1.8)
    back.blotch(4, 0.9, 2.0)
    front.bulge(2.2, 3.3, 1.9, 1.5, 20.0)
    front.bulge(5.8, 3.3, 1.9, 1.5, 20.0)
    front.groove([(0.5, 4.5), (2.0, 5.25), (3.7, 4.75)], 0.36, 0.55)        # bawah otot dada
    front.groove([(7.5, 4.5), (6.0, 5.25), (4.3, 4.75)], 0.36, 0.55)
    front.groove([(0.7, 1.35), (3.5, 1.95)], 0.26, 0.35)                    # tulang selangka
    front.groove([(7.3, 1.35), (4.5, 1.95)], 0.26, 0.35)
    front.groove([(4.0, 5.2), (4.0, 10.8)], 0.24, 0.5)                      # garis tengah perut
    for ay in (6.5, 7.9, 9.3):
        front.groove([(2.3, ay + 0.15), (4.0, ay), (5.7, ay + 0.15)], 0.24, 0.46)
    front.groove([(1.2, 6.0), (2.1, 10.6)], 0.26, 0.32)                     # otot samping
    front.groove([(6.8, 6.0), (5.9, 10.6)], 0.26, 0.32)
    back.groove([(4.0, 0.8), (4.0, 11.2)], 0.34, 0.5)                       # alur tulang punggung
    back.bulge(2.0, 3.6, 1.7, 2.2, 16.0)
    back.bulge(6.0, 3.6, 1.7, 2.2, 16.0)
    back.groove([(0.8, 5.9), (2.2, 6.6), (3.4, 5.9)], 0.3, 0.4)             # bawah belikat
    back.groove([(7.2, 5.9), (5.8, 6.6), (4.6, 5.9)], 0.3, 0.4)
    back.groove([(1.4, 7.2), (3.2, 10.6)], 0.26, 0.3)
    back.groove([(6.6, 7.2), (4.8, 10.6)], 0.26, 0.3)
    # rongga kristal inti di tulang dada: cekungan gelap, tepinya retak menyala dua warna
    front.spot(4.0, 3.0, 1.35, 1.7, np.array([12, 7, 8]), 0.4)
    for ang in np.linspace(0.3, 6.1, 9):
        ex, ey = 4.0 + np.cos(ang) * 1.25, 3.0 + np.sin(ang) * 1.6
        fx, fy = 4.0 + np.cos(ang + 0.25) * 2.6, 3.0 + np.sin(ang + 0.25) * 2.9
        front.crack([(ex, ey), ((ex + fx) / 2 + 0.2, (ey + fy) / 2), (fx, fy)], 1.0, 0.13, rgb=LIGHT if ex < 4.0 else CRYON)
    front.glow_spot(4.0, 3.0, 1.0, 1.3, (LIGHT + CRYON) / 2, 0.55)
    front.stitches(2.0, 6.2, 5.6, 8.4)            # bekas operasi
    front.stitches(4.0, 8.8, 4.0, 10.6)
    m = (np.abs(front.y - (front.x * 0.75 + 0.8)) < 0.55) & (front.y > 1.2) & (front.y < 9.5)   # tali silang dada
    front.rgb = np.where(m[..., None], LEATHER, front.rgb)
    for face in (front, back):
        face.random_cracks(5, 7, 1.0, LIGHT if face is front else CRYON, CRYON if face is front else LIGHT, split=4.0)
    right.random_cracks(3, 6, 0.9, LIGHT, LIGHT, split=0)
    left.random_cracks(3, 6, 0.9, CRYON, CRYON, split=0)
    return f


def limb_faces(outer, glow_rgb, arm):
    f = six(4, 12, 4, glow_rgb)
    top, bottom, right, front, left, back = f
    if outer:
        for x in f:
            x.clear()
        if arm:
            top.plate(0.2, 0.2, 3.8, 3.8)
            for face in (right, left, front, back):
                face.plate(0.0, 0.0, 4.0, 3.4)      # pelindung bahu dari sel mati
            for face in (right, left):
                face.plate(0.6, 5.6, 3.4, 8.6)      # punggung lengan bawah
            for face in (front, back, right, left):
                face.strap(0, 9.0, 4.0, 10.3, buckle=2.0 if face is front else None)   # borgol pergelangan
        else:
            front.plate(0.4, 4.6, 3.6, 6.6)         # lutut
            front.plate(0.5, 7.0, 3.5, 10.6)        # tulang kering
            for face in (front, back, right, left):
                face.strap(0, 2.4, 4.0, 3.6, buckle=2.0 if face is front else None)
        return f
    # 0.49 volume & otot: tiap sisi menggelap ke tepi, tonjolan otot besar di atas, lekuk siku/lutut di tengah
    for face in f:
        face.shade(0.42, 0.16)
    for face in (front, back, right, left):
        face.blotch(1, 0.6, 1.2)
        if arm:
            face.bulge(2.0, 2.4, 1.7, 2.3, 20.0)                                   # bahu & lengan atas
            face.groove([(0.3, 5.0), (2.0, 5.5), (3.7, 5.0)], 0.28, 0.42)          # lipatan siku
            face.bulge(2.0, 7.4, 1.5, 1.9, 13.0)                                   # lengan bawah
            face.groove([(0.4, 9.6), (3.6, 9.6)], 0.2, 0.3)                        # pergelangan
        else:
            face.bulge(2.0, 2.6, 1.7, 2.6, 18.0)                                   # paha
            face.groove([(0.4, 5.3), (2.0, 5.9), (3.6, 5.3)], 0.28, 0.42)          # lutut
            face.bulge(2.0, 8.2, 1.4, 2.2, 12.0)                                   # betis
            face.groove([(0.3, 11.0), (3.7, 11.0)], 0.22, 0.35)                    # pergelangan kaki
    for face in (front, back, right, left):
        face.random_cracks(3, 6, 0.95)
    front.stitches(1.0, 2.0, 3.0, 5.5)
    if arm:   # tangan & cakar gelap
        for face in (front, back, right, left, bottom):
            m = face.y > 10.6 if face is not bottom else np.ones_like(face.x, bool)
            face.rgb = np.where(m[..., None], FLESH_SH * 1.3, face.rgb)
    return f


def skin(out):
    img = np.zeros((N, N, 4), float)
    glow = np.zeros((N, N, 3), float)
    box(img, glow, 0, 0, 8, 8, 8, head_faces(False))
    box(img, glow, 32, 0, 8, 8, 8, head_faces(True))
    box(img, glow, 16, 16, 8, 12, 4, body_faces(False))
    box(img, glow, 16, 32, 8, 12, 4, body_faces(True))
    box(img, glow, 40, 16, 4, 12, 4, limb_faces(False, LIGHT, True))     # lengan kanan: retakan cahaya
    box(img, glow, 40, 32, 4, 12, 4, limb_faces(True, LIGHT, True))
    box(img, glow, 32, 48, 4, 12, 4, limb_faces(False, CRYON, True))     # lengan kiri: retakan Cryon
    box(img, glow, 48, 48, 4, 12, 4, limb_faces(True, CRYON, True))
    box(img, glow, 0, 16, 4, 12, 4, limb_faces(False, LIGHT, False))
    box(img, glow, 0, 32, 4, 12, 4, limb_faces(True, LIGHT, False))
    box(img, glow, 16, 48, 4, 12, 4, limb_faces(False, CRYON, False))
    box(img, glow, 0, 48, 4, 12, 4, limb_faces(True, CRYON, False))
    from scipy import ndimage
    soft = np.stack([ndimage.gaussian_filter(glow[..., c], 2.0) for c in range(3)], -1) * 1.6
    g = np.clip(glow * 1.0 + soft * 0.7, 0, 255)
    gimg = np.zeros((N, N, 4), np.uint8)
    gimg[..., :3] = g.astype(np.uint8)
    gimg[..., 3] = 255
    os.makedirs(os.path.join(out, "textures/entity/helion3"), exist_ok=True)
    Image.fromarray(np.clip(img, 0, 255).astype(np.uint8), "RGBA").save(os.path.join(out, "textures/entity/helion3/skin.png"))
    Image.fromarray(gimg, "RGBA").save(os.path.join(out, "textures/entity/helion3/glow.png"))


def spike(out):
    """Tulang sel mati 32x32 (v = 0 ujung pucat, v = 1 pangkal gelap): serat memanjang, retak halus, bintik keropos."""
    n = 32
    ys, xs = np.mgrid[0:n, 0:n]
    v = (ys + 0.5) / n
    u = (xs + 0.5) / n
    t = (1 - v) ** 1.15
    col = PLATE_HI[None, None] * 1.12 * t[..., None] + PLATE_SH[None, None] * 1.05 * (1 - t[..., None])
    fibre = 1.0 + noise(n, n, 2, 0.05) + 0.07 * np.sin(u * 38.0 + noise(n, n, 6, 2.0)) + noise(n, n, 9, 0.08)
    col = col * fibre[..., None]
    col = col * (1 - 0.22 * np.abs(u * 2 - 1) ** 2.0)[..., None]          # tepi kiri-kanan menggelap (batang bulat)
    for _ in range(5):                                                    # retak halus memanjang
        x = rng.uniform(3, n - 3)
        y = rng.uniform(4, n - 10)
        for _ in range(int(rng.uniform(6, 14))):
            xi, yi = int(np.clip(x, 0, n - 1)), int(np.clip(y, 0, n - 1))
            col[yi, xi] *= 0.6
            y += 1
            x += rng.normal(0, 0.55)
    pits = noise(n, n, 1, 1.0) > 0.86                                     # bintik keropos
    col = np.where(pits[..., None], col * 0.8, col)
    img = np.zeros((n, n, 4), np.uint8)
    img[..., :3] = np.clip(col, 0, 255).astype(np.uint8)
    img[..., 3] = 255
    Image.fromarray(img, "RGBA").save(os.path.join(out, "textures/entity/helion3/spike.png"))


def cell_item(out):
    """Ikon Sel Subjek Tiga 16x16: gumpalan sel mati hangus yang berdenyut, retakan cahaya & Cryon, serpih tulang."""
    n = 16
    ys, xs = np.mgrid[0:n, 0:n]
    x, y = xs + 0.5, ys + 0.5
    d = np.hypot((x - 8.0) / 5.6, (y - 8.6) / 5.2) + noise(n, n, 3, 0.16)
    body = d < 1.0
    img = np.zeros((n, n, 4), float)
    k = 1.0 + noise(n, n, 2, 0.16)
    flesh = FLESH[None, None] * 1.15 * k[..., None]
    lit = np.clip(1.0 - np.hypot(x - 6.0, y - 6.2) / 6.5, 0, 1)
    flesh = flesh + FLESH_HI[None, None] * 0.55 * lit[..., None]
    flesh = flesh * (1.0 - 0.5 * np.clip(d, 0, 1) ** 3)[..., None]
    img[..., :3] = np.where(body[..., None], flesh, 0)
    img[..., 3] = np.where(body, 255, 0)
    rim = body & (d > 0.86)
    img[..., :3] = np.where(rim[..., None], CHAR + 14, img[..., :3])
    for pts, colr in (([(4.0, 6.5), (6.5, 8.0), (7.0, 10.5), (5.5, 12.0)], LIGHT),
                      ([(11.5, 5.5), (9.8, 7.6), (10.6, 9.8), (9.4, 12.2)], CRYON)):
        for (ax, ay), (bx, by) in zip(pts[:-1], pts[1:]):
            m = (seg_dist(x, y, ax, ay, bx, by) < 0.42) & body
            img[..., :3] = np.where(m[..., None], colr, img[..., :3])
    core = np.hypot(x - 8.2, y - 8.6) < 1.05                              # inti yang masih berdenyut
    img[..., :3] = np.where((core & body)[..., None], (LIGHT + CRYON) / 2 + 20, img[..., :3])
    for bx, by in ((5.0, 4.0), (11.6, 11.6), (12.2, 7.8)):                # serpih tulang yang menyembul
        m = (np.abs(x - bx) + np.abs(y - by) < 1.3)
        img[..., :3] = np.where(m[..., None], BONE, img[..., :3])
        img[..., 3] = np.where(m, 255, img[..., 3])
    os.makedirs(os.path.join(out, "textures/item"), exist_ok=True)
    Image.fromarray(np.clip(img, 0, 255).astype(np.uint8), "RGBA").save(os.path.join(out, "textures/item/helion3_cell.png"))


if __name__ == "__main__":
    assets = sys.argv[1] if len(sys.argv) > 1 else "."
    skin(assets)
    spike(assets)
    cell_item(assets)
    if len(sys.argv) > 2:   # pratinjau: tampak depan (base + luar) dan versi menyala
        s = Image.open(os.path.join(assets, "textures/entity/helion3/skin.png")).convert("RGBA")
        g = Image.open(os.path.join(assets, "textures/entity/helion3/glow.png")).convert("RGB")

        def crop(im, u, v, w, h):
            return im.crop((u * S, v * S, (u + w) * S, (v + h) * S))

        def front(im, outer=False):
            W = Image.new("RGBA", (16 * S, 32 * S), (150, 170, 190, 255))
            o = 16 if outer else 0
            W.alpha_composite(crop(im, 8 + (32 if outer else 0), 8, 8, 8).convert("RGBA"), (4 * S, 0))
            W.alpha_composite(crop(im, 20, 20 + o, 8, 12).convert("RGBA"), (4 * S, 8 * S))
            W.alpha_composite(crop(im, 44, 20 + o, 4, 12).convert("RGBA"), (0, 8 * S))
            W.alpha_composite(crop(im, 36 + (16 if outer else 0), 52, 4, 12).convert("RGBA"), (12 * S, 8 * S))
            W.alpha_composite(crop(im, 4, 20 + o, 4, 12).convert("RGBA"), (4 * S, 20 * S))
            W.alpha_composite(crop(im, 20 - (16 if outer else 0), 52, 4, 12).convert("RGBA"), (8 * S, 20 * S))
            return W

        base = front(s)
        base.alpha_composite(front(s, True))
        lit = Image.fromarray(np.clip(np.asarray(base.convert("RGB"), float) * 0.55 + np.asarray(front(g.convert("RGBA")).convert("RGB"), float), 0, 255).astype(np.uint8))
        sheet = Image.new("RGB", (16 * S * 2 * 3 + 20, 32 * S * 2), (40, 40, 48))
        sheet.paste(base.convert("RGB").resize((16 * S * 2, 32 * S * 2), Image.NEAREST), (0, 0))
        sheet = sheet.resize((sheet.width * 2, sheet.height * 2), Image.NEAREST)
        sheet.paste(lit.resize((16 * S * 2, 32 * S * 2), Image.NEAREST), (16 * S * 2 + 10, 0))
        sheet.paste(Image.open(os.path.join(assets, "textures/entity/helion3/spike.png")).convert("RGB").resize((96, 96), Image.NEAREST),
                    (16 * S * 4 + 20, 0))
        sheet.save(sys.argv[2])
    print("ok")
