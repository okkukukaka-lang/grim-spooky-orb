"""Tekstur bagian 3D tambahan 0.49 (lihat client/render/HeroGeo.java).

    python3 hero_parts.py ASSETS_DIR

Menulis:
  textures/entity/helion/crystal.png  16x16  kristal Cryon Helion-6 (v = 0 ujung terang, v = 1 pangkal hijau tua, faset)
  textures/entity/lintang/gold.png    16x16  cahaya matahari yang memadat (emas pucat tersikat halus) untuk perhiasan Lintang
"""
import os
import sys

import numpy as np
from PIL import Image

rng = np.random.default_rng(49)


def save(path, rgb):
    img = np.zeros(rgb.shape[:2] + (4,), np.uint8)
    img[..., :3] = np.clip(rgb, 0, 255).astype(np.uint8)
    img[..., 3] = 255
    os.makedirs(os.path.dirname(path), exist_ok=True)
    Image.fromarray(img, "RGBA").save(path)


def crystal(out):
    n = 16
    ys, xs = np.mgrid[0:n, 0:n]
    u, v = (xs + 0.5) / n, (ys + 0.5) / n
    tip = np.array([196, 255, 214], float)
    mid = np.array([58, 214, 122], float)
    base = np.array([10, 74, 44], float)
    t = (1 - v)[..., None]
    col = np.where(t > 0.5, mid + (tip - mid) * (t - 0.5) * 2, base + (mid - base) * t * 2)
    facet = 1.0 + 0.22 * (np.abs(u - 0.32) < 0.1) - 0.2 * (u > 0.72) - 0.12 * (u < 0.1)   # satu faset terang, tepi gelap
    col = col * facet[..., None]
    for _ in range(4):                                                                    # retak dalam yang berkilau
        x, y = rng.integers(2, n - 2), rng.integers(3, n - 5)
        for k in range(rng.integers(3, 6)):
            col[min(n - 1, y + k), min(n - 1, max(0, x + (k % 2)))] *= 1.25
    save(os.path.join(out, "textures/entity/helion/crystal.png"), col)


def gold(out):
    n = 16
    ys, xs = np.mgrid[0:n, 0:n]
    u, v = (xs + 0.5) / n, (ys + 0.5) / n
    hot = np.array([255, 250, 226], float)
    warm = np.array([255, 206, 116], float)
    col = warm + (hot - warm) * ((1 - v)[..., None] ** 1.4)
    brushed = 1.0 + 0.05 * np.sin(u * 40.0) + rng.normal(0, 0.02, (n, n))
    col = col * brushed[..., None]
    col = col * (1 - 0.14 * np.abs(u * 2 - 1) ** 2)[..., None]
    save(os.path.join(out, "textures/entity/lintang/gold.png"), col)


if __name__ == "__main__":
    assets = sys.argv[1] if len(sys.argv) > 1 else "."
    crystal(assets)
    gold(assets)
    print("ok")
