"""0.44 Lintang Mode Surya (orisinal, mengikuti video): jubah emas pekat, retakan pijar blok panas, lambang matahari.

    python3 lintang_sun.py CAPE.png CRACKS.png EMBLEM.png

- Jubah 64x128 (u = lebar kiri -> kanan, v = panjang leher -> kelim): kain emas PEKAT (bukan tembus pandang) dengan
  berkas-berkas cahaya tegak yang lebih terang & lebih gelap berselang seperti di video, serat halus, list emas terang di
  tepi kiri-kanan & kelim bawah (juga dipakai dinding tebal kainnya). Diwarnai putih & diterangi penuh di game.
- Retakan pijar 32x32 (bisa diulang tanpa sambungan): garis-garis retak terang di atas hitam (lapisan aditif blok panas,
  diwarnai warna pijar suhunya di game).
- Lambang 32x32: cakram matahari putih panas, cincin emas, 8 sinar runcing panjang + 8 sinar pendek berselang (bintang
  tajam seperti di video). Alpha = tinggi timbul (EmblemImage).
"""
import math
import sys

import numpy as np
from PIL import Image

cape_out, cracks_out, emblem_out = sys.argv[1], sys.argv[2], sys.argv[3]
rng = np.random.default_rng(44)

# ------------------------------------------------------------------ jubah emas
W, H = 64, 128
ys, xs = np.mgrid[0:H, 0:W]
u, v = (xs + 0.5) / W, (ys + 0.5) / H
GOLD = np.array([236, 172, 52], float)
LIGHT = np.array([255, 236, 150], float)
DEEP = np.array([196, 118, 26], float)
TRIM = np.array([255, 246, 196], float)

# berkas cahaya tegak: jumlah beberapa gelombang (lebar berbeda) -> garis terang & gelap berselang yang nggak kaku
stripe = (0.55 * np.sin(u * 2 * math.pi * 7 + 0.6) + 0.3 * np.sin(u * 2 * math.pi * 13 + 2.1)
          + 0.2 * np.sin(u * 2 * math.pi * 23 + 4.0))
stripe = stripe / 1.05
# berkas sedikit melebar ke bawah (jubah mengembang) & memudar pelan
stripe = stripe * (0.75 + 0.25 * v)
fiber = rng.normal(0, 0.035, (H, W)) + np.repeat(rng.normal(0, 0.025, (1, W)), H, axis=0)
k = np.clip(stripe + fiber, -1.2, 1.2)
col = np.where(k[..., None] > 0, GOLD + (LIGHT - GOLD) * np.clip(k, 0, 1)[..., None],
               GOLD + (DEEP - GOLD) * np.clip(-k, 0, 1)[..., None])
# sedikit lebih terang di bahu (dekat sumber cahaya), sedikit lebih jingga di kelim
col = col * (1.06 - 0.12 * v)[..., None] + np.array([0, -10, -12], float) * v[..., None]
# list emas terang di tepi kiri-kanan & kelim bawah (dinding tebal kain memakai kolom tepi ini)
edge = np.minimum(u, 1 - u)
trim = np.clip(1 - (edge - 0.03) / 0.035, 0, 1)
hem = np.clip(1 - ((1 - v) - 0.02) / 0.03, 0, 1)
band = np.maximum(trim, hem)[..., None]
col = col * (1 - band) + TRIM * band
# garis tipis gelap di dalam list (jahitan)
seam = ((np.abs(edge - 0.072) < 0.009) | (np.abs((1 - v) - 0.056) < 0.006))[..., None]
col = np.where(seam, col * 0.82, col)
img = np.dstack([np.clip(col, 0, 255), np.full((H, W), 255.0)]).astype(np.uint8)
Image.fromarray(img, 'RGBA').save(cape_out)

# ------------------------------------------------------------------ retakan pijar (bisa diulang)
N = 32
pts = rng.random((14, 2)) * N
grid = np.zeros((N, N))
best1 = np.full((N, N), 1e9)
best2 = np.full((N, N), 1e9)
gy, gx = np.mgrid[0:N, 0:N] + 0.5
for px, py in pts:
    for ox in (-N, 0, N):
        for oy in (-N, 0, N):
            d = np.hypot(gx - (px + ox), gy - (py + oy))
            nb2 = np.where(d < best1, best1, np.minimum(best2, d))
            best1 = np.minimum(best1, d)
            best2 = nb2
edge = best2 - best1   # 0 tepat di garis retak antar-sel
line = np.clip(1 - edge / 1.25, 0, 1) ** 1.2
# retakan nggak seragam: sebagian lebih terang, ada butiran pijar kecil di dalam sel
wob = 0.8 + 0.2 * np.sin(gx * 0.7 + 1.3) * np.sin(gy * 0.55 + 0.4)
speck = (rng.random((N, N)) > 0.93) * rng.random((N, N)) * 0.45
val = np.clip(line * wob + speck * (best1 > 2.0), 0, 1)
c = np.dstack([val * 255, val * 238, val * 200, np.full((N, N), 255.0)]).astype(np.uint8)
Image.fromarray(c, 'RGBA').save(cracks_out)

# ------------------------------------------------------------------ lambang matahari (bintang tajam)
N = 32
C = (N - 1) / 2.0
ys, xs = np.mgrid[0:N, 0:N]
dx, dy = xs - C, ys - C
r = np.hypot(dx, dy)
ang = np.arctan2(dy, dx)
rgb = np.zeros((N, N, 3), float)
alpha = np.zeros((N, N), float)
WHITE = np.array([255, 252, 236], float)
CORE = np.array([255, 236, 170], float)
RGOLD = np.array([255, 196, 70], float)
RAY = np.array([255, 170, 46], float)
for i in range(16):
    a0 = i * math.pi / 8
    long_ray = i % 2 == 0
    tip = 15.4 if long_ray else 10.8
    base_w = 1.75 if long_ray else 1.25
    d = np.angle(np.exp(1j * (ang - a0)))
    along = r * np.cos(d)
    across = np.abs(r * np.sin(d))
    half = base_w * np.clip(1 - (along - 5.5) / (tip - 5.5), 0, 1)
    m = (along > 5.0) & (across <= half + 0.35) & (along <= tip)
    t = np.clip((along - 5.5) / (tip - 5.5), 0, 1)
    col = RGOLD + (RAY - RGOLD) * t[..., None]
    col = col + (WHITE - col) * (np.clip(1 - across / (half + 0.4), 0, 1) * 0.55 * (1 - t))[..., None]
    rgb = np.where(m[..., None] & (alpha[..., None] == 0), col, rgb)
    alpha = np.where(m & (alpha == 0), 150 + 60 * (1 - t), alpha)
disc = r <= 5.6
glowc = WHITE + (CORE - WHITE) * np.clip(r / 5.6, 0, 1)[..., None] ** 1.5
rgb = np.where(disc[..., None], glowc, rgb)
alpha = np.where(disc, 255 - 40 * np.clip(r / 5.6, 0, 1), alpha)
ring = (r > 5.6) & (r <= 6.6)
rgb = np.where(ring[..., None], RGOLD, rgb)
alpha = np.where(ring, 200, alpha)
img = np.dstack([np.clip(rgb, 0, 255), np.clip(alpha, 0, 255)]).astype(np.uint8)
Image.fromarray(img, 'RGBA').save(emblem_out)
