package com.shazammod.rival;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import com.shazammod.HelionSkills;
import com.shazammod.LintangSkills;
import com.shazammod.PassiveConditions;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamForm;
import com.shazammod.ShazamSounds;

import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * 0.46 Rival Lintang: pahlawan surya yang bertarung dengan kekuatan Lintang pemain (animasi, efek, suara, dan waktunya sama):
 * Lesatan Bintang, Iris Surya (sinar mata yang di-charge 1-2 detik), Napas Salju (lawan membeku jadi patung es),
 * Tepukan Guruh, Amukan Kilat, Gelegar Surya (lalu Mode Surya), Ledakan Surya, dan Serap Surya. Pasifnya: Serapan Cahaya
 * tiap 2 detik, Tinju Fajar (muatan penuh), dan Tepisan Beku.
 *
 * Kekuatannya ikut cahaya: di bawah matahari x1,15; tanpa langit x0,85; Nether x0,7; dan dekat radiasi Cryon (Batu Cryon,
 * atau Helion-6 yang sedang berubah wujud, juga rival Helion-6) cuma x0,6 dan damage yang diterimanya naik 60%.
 *
 * Slot: 0 Lesatan Bintang, 1 Iris Surya, 2 Napas Salju, 3 Tepukan Guruh, 4 Amukan Kilat, 5 Gelegar Surya, 6 Ledakan Surya,
 * 7 Serap Surya.
 */
final class RivalLintang extends RivalKit {
    private static final float SUN_POWER = 1.15f;
    private static final float DARK_POWER = 0.85f;
    private static final float NETHER_POWER = 0.7f;
    private static final float KELAM_POWER = 0.6f;
    private static final float KELAM_TAKEN = 1.6f;
    private static final float RAGE_PUNCH = 1.4f;     // Mode Surya sesudah Gelegar / Ledakan Surya
    private static final float RAGE_TAKEN = 0.8f;
    private static final double KELAM_RADIUS = 6.0;

    private long rageUntil;
    private long novaUntil;
    private long kelamCheck;
    private boolean kelam;
    private final Map<LivingEntity, Long> iced = new HashMap<>();

    RivalLintang(RivalChampion rival) {
        super(rival, 8);
    }

    /** Radiasi Cryon di dekatnya: Batu Cryon yang dipegang / Helion-6 pemain atau rival yang sedang berubah wujud. */
    private boolean kelam() {
        long now = now();
        if (now >= kelamCheck) {
            kelamCheck = now + 10;
            kelam = !r.level().getEntitiesOfClass(LivingEntity.class, r.getBoundingBox().inflate(KELAM_RADIUS),
                    e -> e != r && e.isAlive() && (LintangSkills.holdsKelam(e) || HelionSkills.radiatesRival(e)
                            || (e instanceof Player p && HelionSkills.radiates(p)))).isEmpty();
        }
        return kelam;
    }

    private float scale() {
        Level level = r.level();
        float k;
        if (kelam()) {
            k = KELAM_POWER;
        } else if (PassiveConditions.inferno(level)) {
            k = NETHER_POWER;
        } else if (PassiveConditions.underSun(level, r.blockPosition())) {
            k = SUN_POWER;
        } else {
            k = PassiveConditions.skyLight(level, r.blockPosition()) ? 1f : DARK_POWER;
        }
        return k;
    }

    private void rage(int ticks) {
        rageUntil = now() + ticks;
        r.setFlag(RivalChampion.RAGE, true);
    }

    @Override
    void reset() {
        super.reset();
        rageUntil = 0;
        novaUntil = 0;
        r.setFlag(RivalChampion.RAGE, false);
        iced.clear();
    }

    @Override
    void transformed() {
        for (LivingEntity foe : r.foes(r.position(), 7.0)) {   // udara dari putaran secepat kilat meledak keluar
            if (r.hit(foe, 18f * SKILL)) {
                push(foe, r.position(), 1.6, 0.45);
            }
        }
    }

    // ------------------------------------------------------------------ memilih skill

    @Override
    int[] weights(LivingEntity target, double d, boolean sight, float hp) {
        long now = now();
        int[] w = new int[8];
        w[0] = d > 6 && d < 20 && sight ? 4 : 0;                       // Lesatan Bintang
        w[1] = sight && d < 32 ? 6 : 0;                                // Iris Surya
        w[2] = sight && d < 10 ? 5 : 0;                                // Napas Salju
        w[3] = sight && d < 12 ? 4 : 0;                                // Tepukan Guruh
        w[4] = d < 6 ? 5 : 0;                                          // Amukan Kilat
        w[5] = hp < 0.8f && rageUntil < now ? 5 : 0;                   // Gelegar Surya
        w[6] = hp < 0.45f ? 6 : 0;                                     // Ledakan Surya
        w[7] = hp < 0.6f ? (PassiveConditions.skyLight(r.level(), r.blockPosition()) && !kelam() ? 6 : 3) : 0;   // Serap Surya
        return w;
    }

    @Override
    int cooldown(int slot) {
        return switch (slot) {
            case 0 -> 120;
            case 1 -> 160;
            case 2 -> 200;
            case 3 -> 200;
            case 4 -> 140;
            case 5 -> 700;
            case 6 -> 1100;
            default -> 500;
        };
    }

    @Override
    boolean use(int slot, LivingEntity target) {
        return switch (slot) {
            case 0 -> lesat(target);
            case 1 -> iris(target);
            case 2 -> breath(target);
            case 3 -> clap(target);
            case 4 -> barrage(target);
            case 5 -> flare();
            case 6 -> nova();
            case 7 -> call();
            default -> false;
        };
    }

    // ------------------------------------------------------------------ tinju, pasif, bertahan

    @Override
    void punch(LivingEntity target) {
        float damage = RivalChampion.PUNCH_DAMAGE * scale() * (now() < rageUntil ? RAGE_PUNCH : 1f);
        boolean charged = r.flag(RivalChampion.CHARGED);
        if (charged) {
            damage *= 1.75f;
            r.setFlag(RivalChampion.CHARGED, false);
        }
        Vec3 at = chest(target);
        boolean frozen = iced.remove(target) != null;
        if (frozen) {   // patung es pecah berkeping-keping
            damage *= 1.5f;
            r.anim(ShazamAnim.LINTANG_ICE_BREAK, at);
        }
        if (!r.hit(target, damage)) {
            return;
        }
        r.sound(at, ShazamSounds.PUNCH.get(), 1.2f, ShazamSounds.tune(0.8f));
        push(target, r.position(), charged ? 2.0 : 1.0, charged ? 0.6 : 0.3);
        r.anim(ShazamAnim.LINTANG_PUNCH, at);
        if (!charged) {
            return;
        }
        r.anim(ShazamAnim.LINTANG_DAWNPUNCH, at);   // Tinju Fajar
        r.sound(at, ShazamSounds.DAWN_PUNCH.get(), 2.0f, 1f);
        target.igniteForSeconds(3f);
        List<LivingEntity> near = r.foes(target.position(), 7.0);
        near.remove(target);
        for (int i = 0; i < Math.min(3, near.size()); i++) {
            LivingEntity m = near.get(i);
            m.invulnerableTime = 0;
            if (r.hit(m, 14f * SKILL)) {
                r.anim(ShazamAnim.LINTANG_HIT, chest(m));
            }
        }
    }

    /** Serapan Cahaya tiap 2 detik (padam tanpa langit, lewat PassiveConditions). */
    @Override
    void pulse() {
        r.anim(ShazamAnim.LINTANG_PULSE, r.position());
        r.level().playSound(null, r, ShazamSounds.SOLAR_PULSE.get(), SoundSource.HOSTILE, 1.2f, 1f);
        r.later(1, r::empower);
    }

    @Override
    void passiveChanged(boolean on) {
        r.anim(on ? ShazamAnim.LINTANG_RETURN : ShazamAnim.LINTANG_FADE, r.position());
        if (!on) {
            r.level().playSound(null, r, ShazamSounds.POWER_DOWN.get(), SoundSource.HOSTILE, 0.8f, 1.2f);
        }
    }

    /** Tepisan Beku (tiap 1,8 detik): serangan ditepis secepat kilat, penyerangnya membeku sesaat. */
    @Override
    boolean defend(DamageSource source, boolean ready) {
        Entity attacker = source.getEntity();
        Entity direct = source.getDirectEntity();
        if (!ready || kelam() || (attacker == null && direct == null) || now() < novaUntil) {
            return false;
        }
        Entity from = direct != null ? direct : attacker;
        Vec3 c = chest(r);
        Vec3 toward = from.position().add(0, from.getBbHeight() * 0.6, 0).subtract(c);
        Vec3 hit = toward.lengthSqr() < 1.0E-4 ? c : c.add(toward.normalize().scale(0.55));
        r.anim(ShazamAnim.LINTANG_PARRY, hit);
        r.sound(hit, ShazamSounds.FROST_PARRY.get(), 1.4f, 1f);
        if (attacker instanceof LivingEntity foe && foe.distanceToSqr(r) < 6.0 * 6.0) {
            foe.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 3));
            foe.setTicksFrozen(Math.max(foe.getTicksFrozen(), foe.getTicksRequiredToFreeze() + 40));
        }
        return true;
    }

    @Override
    float damageTakenMultiplier(DamageSource source, float amount) {
        float k = 1f;
        if (kelam()) {
            k *= KELAM_TAKEN;
        }
        if (now() < rageUntil) {
            k *= RAGE_TAKEN;
        }
        if (now() < novaUntil) {
            k *= 0.3f;   // tubuh sekeras baja selama mengumpulkan panas
        }
        if (isChampion(source.getEntity(), ShazamForm.HELION)) {
            k *= 1.5f;   // tinju Helion-6 membawa radiasi Cryon
        }
        if (source.is(DamageTypes.MAGIC) || source.is(DamageTypes.INDIRECT_MAGIC)) {
            k *= 1.25f;
        }
        return k;
    }

    @Override
    void tickExtra(LivingEntity target) {
        long now = now();
        if (rageUntil > 0 && now >= rageUntil) {
            rageUntil = 0;
            r.setFlag(RivalChampion.RAGE, false);
        }
        if (iced.isEmpty()) {
            return;
        }
        Iterator<Map.Entry<LivingEntity, Long>> it = iced.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<LivingEntity, Long> e = it.next();
            LivingEntity foe = e.getKey();
            if (!foe.isAlive() || foe.isRemoved()) {
                it.remove();
            } else if (now >= e.getValue()) {   // es mencair sendiri
                r.anim(ShazamAnim.LINTANG_ICE_BREAK, chest(foe));
                it.remove();
            } else {
                foe.setDeltaMovement(0, Math.min(foe.getDeltaMovement().y, 0), 0);
                foe.setTicksFrozen(Math.max(foe.getTicksFrozen(), foe.getTicksRequiredToFreeze() + 20));
                foe.hurtMarked = true;
            }
        }
    }

    // ------------------------------------------------------------------ skill

    /** Lesatan Bintang: merunduk, lalu melesat lurus menembus lawan (dentum sonik di ujungnya). */
    private boolean lesat(LivingEntity target) {
        Vec3 dir = chest(target).subtract(r.position().add(0, 1.0, 0));
        if (dir.lengthSqr() < 1.0E-4) {
            return false;
        }
        dir = dir.normalize();
        Vec3 end = dashEnd(dir, Math.min(20.0, Math.sqrt(r.distanceToSqr(target)) + 4.0));
        if (end == null) {
            return false;
        }
        Vec3 start = r.position();
        r.anim(ShazamAnim.LINTANG_DASH, end);
        r.sound(start, ShazamSounds.WHOOSH.get(), 1.6f, 0.8f);
        busyFor(ShazamAnim.LESAT_WINDUP + ShazamAnim.LESAT_TICKS + 4);
        r.getNavigation().stop();
        Set<UUID> hit = new HashSet<>();
        float k = scale();
        r.later(ShazamAnim.LESAT_WINDUP, () -> dash(start, end, ShazamAnim.LESAT_TICKS, step -> {
            for (LivingEntity foe : r.foes(r.position(), 2.4)) {
                if (hit.add(foe.getUUID()) && r.hit(foe, 28f * SKILL * k)) {
                    push(foe, r.position(), 1.3, 0.5);
                    r.anim(ShazamAnim.LINTANG_HIT, chest(foe));
                }
            }
        }, () -> r.sound(r.position(), ShazamSounds.SONIC_BOOM.get(), 1.6f, 1.2f)));
        return true;
    }

    /** Iris Surya: mata mengumpulkan panas 1-2 detik (kepala membidik), lalu sinar panas mengikuti sasaran. */
    private boolean iris(LivingEntity target) {
        int chargeTicks = 20 + r.getRandom().nextInt(25);
        float charge = Mth.clamp(chargeTicks / (float) ShazamAnim.IRIS_CHARGE_TICKS, 0f, 1f);
        int fire = LintangSkills.irisTicks(charge);
        double range = LintangSkills.irisRange(charge);
        float damage = (6f + 10f * charge) * SKILL * scale();
        r.anim(ShazamAnim.LINTANG_IRIS_CHARGE);
        busyFor(chargeTicks + fire + 4);
        r.getNavigation().stop();
        r.later(chargeTicks, () -> {
            r.anim(ShazamAnim.LINTANG_IRIS_FIRE, new Vec3(charge, fire, 1.0));
            r.sound(r.getEyePosition(), ShazamSounds.LASER_FIRE.get(), 1.2f + charge, 1.1f - 0.25f * charge);
        });
        r.channel(chargeTicks + fire, step -> {
            if (target.isAlive()) {
                aim(target);
            }
            if (step < chargeTicks || (step - chargeTicks) % 2 != 0) {
                return;
            }
            for (LivingEntity foe : beamFoes(beamEnd(range))) {
                foe.invulnerableTime = 0;
                if (r.hit(foe, damage)) {
                    foe.igniteForSeconds(3f);
                }
            }
        }, null);
        return true;
    }

    /** Napas Salju: hembusan beku 2 detik; lawan yang terlalu lama di dalamnya jadi patung es. */
    private boolean breath(LivingEntity target) {
        int w = ShazamAnim.FROST_WINDUP, len = ShazamAnim.FROST_TICKS;
        r.anim(ShazamAnim.LINTANG_BREATH);
        r.sound(r.position(), ShazamSounds.FROST_BREATH.get(), 2.0f, 1f);
        busyFor(w + len + 4);
        r.getNavigation().stop();
        float k = scale();
        r.channel(w + len, step -> {
            if (target.isAlive()) {
                aim(target);
            }
            if (step < w || (step - w) % 4 != 0) {
                return;
            }
            Vec3 mouth = r.getEyePosition().add(0, -0.15, 0);
            for (LivingEntity foe : coneFoes(mouth, r.getViewVector(1f), 11.0, 0.8)) {
                foe.invulnerableTime = 0;
                if (!r.hit(foe, 3f * SKILL * k)) {
                    continue;
                }
                foe.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 3));
                foe.setTicksFrozen(Math.min(foe.getTicksFrozen() + 30, foe.getTicksRequiredToFreeze() + 120));
                if (foe.getTicksFrozen() >= foe.getTicksRequiredToFreeze() && !iced.containsKey(foe)) {
                    iced.put(foe, now() + ShazamAnim.LINTANG_ICE_TICKS);
                    foe.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, ShazamAnim.LINTANG_ICE_TICKS, 6, false, false));
                    r.anim(ShazamAnim.LINTANG_ICE, chest(foe));
                }
            }
        }, null);
        return true;
    }

    /** Tepukan Guruh: tepukan menggelegar ke depan, lawan terlempar & telinganya berdenging, proyektil hancur. */
    private boolean clap(LivingEntity target) {
        aim(target);
        r.anim(ShazamAnim.LINTANG_CLAP);
        busyFor(ShazamAnim.SONIC_WINDUP + 6);
        r.getNavigation().stop();
        float k = scale();
        r.later(ShazamAnim.SONIC_WINDUP, () -> {
            if (target.isAlive()) {
                aim(target);
            }
            Vec3 origin = r.getEyePosition().add(0, -0.4, 0);
            Vec3 look = r.getViewVector(1f);
            r.sound(origin, ShazamSounds.SONIC_CLAP.get(), 3.0f, 1f);
            for (LivingEntity foe : coneFoes(origin, look, 16.0, 0.55)) {
                double d = chest(foe).distanceTo(origin);
                float fall = (float) Math.max(0.3, 1.0 - d / 16.0);
                if (r.hit(foe, 26f * SKILL * k * fall)) {
                    Vec3 to = chest(foe).subtract(origin);
                    Vec3 push = new Vec3(to.x, 0, to.z).normalize().scale(2.6 * fall);
                    foe.push(push.x, 0.45 * fall, push.z);
                    foe.hurtMarked = true;
                    foe.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 3));
                    foe.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 60, 0));
                }
            }
            destroyProjectiles(10.0);
        });
        return true;
    }

    /** Amukan Kilat: rentetan pukulan secepat kilat sambil mengejar, pukulan penutup melempar jauh. */
    private boolean barrage(LivingEntity target) {
        int w = ShazamAnim.BARRAGE_WINDUP, end = w + ShazamAnim.BARRAGE_TICKS;
        r.anim(ShazamAnim.LINTANG_BARRAGE, target.position());
        r.sound(r.position(), ShazamSounds.BARRAGE.get(), 1.6f, 1f);
        busyFor(end + 4);
        r.getNavigation().stop();
        float k = scale();
        r.channel(end + 1, step -> {
            if (!target.isAlive()) {
                return;
            }
            r.face(target);
            if (target.distanceToSqr(r) > 2.6 * 2.6) {
                Vec3 to = target.position().subtract(r.position());
                Vec3 dir = new Vec3(to.x, 0, to.z).normalize();
                r.setDeltaMovement(dir.x * 0.45, r.getDeltaMovement().y, dir.z * 0.45);
                r.hurtMarked = true;
            }
            if (step < w || (step != end && (step - w) % 6 != 0) || target.distanceToSqr(r) > 4.5 * 4.5) {
                return;
            }
            boolean last = step == end;
            target.invulnerableTime = 0;
            if (r.hit(target, (last ? 18f : 6f) * SKILL * k)) {
                r.anim(ShazamAnim.LINTANG_HIT, chest(target));
                if (last) {
                    push(target, r.position(), 2.2, 0.7);
                    r.sound(target.position(), ShazamSounds.DAWN_PUNCH.get(), 1.4f, ShazamSounds.tune(1.1f));
                } else {
                    push(target, r.position(), 0.25, 0.05);
                }
            }
        }, null);
        return true;
    }

    /** Ledakan panas di sekitar (Gelegar & Ledakan Surya). */
    private void solarBlast(double radius, float damage) {
        Vec3 c = r.position().add(0, 1.0, 0);
        for (LivingEntity foe : r.foes(c, radius)) {
            double d = Math.sqrt(foe.distanceToSqr(c));
            float fall = (float) Math.max(0.3, 1.0 - d / radius * 0.7);
            foe.invulnerableTime = 0;
            if (r.hit(foe, damage * fall)) {
                foe.igniteForSeconds(5f);
                push(foe, c, 1.8 * fall, 0.4 + 0.4 * fall);
            }
            if (iced.remove(foe) != null) {   // patung es mencair kena panasnya
                r.anim(ShazamAnim.LINTANG_ICE_BREAK, chest(foe));
            }
        }
        destroyProjectiles(radius * 0.6);
    }

    /** Gelegar Surya: menyerap cahaya, meledakkannya, lalu Mode Surya (tinju x1,4, damage diterima x0,8). */
    private boolean flare() {
        r.anim(ShazamAnim.LINTANG_FLARE);
        r.sound(r.position(), ShazamSounds.SOLAR_FLARE.get(), 3.0f, 1f);
        busyFor(ShazamAnim.FLARE_WINDUP + 6);
        r.getNavigation().stop();
        float k = scale();
        r.later(ShazamAnim.FLARE_WINDUP, () -> {
            solarBlast(12.0, 40f * SKILL * k);
            rage(ShazamAnim.RAGE_TICKS);
        });
        return true;
    }

    /** Ledakan Surya: 3 detik meringkuk mengumpulkan panas (hampir kebal), lalu meledak raksasa. */
    private boolean nova() {
        int w = ShazamAnim.SOLAR_NOVA_WINDUP;
        r.anim(ShazamAnim.LINTANG_NOVA);
        r.sound(r.position(), ShazamSounds.SOLAR_NOVA.get(), 4.0f, 1f);
        busyFor(w + 10);
        r.getNavigation().stop();
        novaUntil = now() + w;
        float k = scale();
        r.later(w, () -> {
            novaUntil = 0;
            solarBlast(20.0, 90f * SKILL * k);
            rage(ShazamAnim.RAGE_TICKS);
        });
        return true;
    }

    /** Serap Surya: menyerap sinar matahari (pulih banyak di bawah langit), panas berlebihnya menghempas keluar. */
    private boolean call() {
        r.anim(ShazamAnim.LINTANG_CALL);
        r.sound(r.position(), ShazamSounds.SUN_CALL.get(), 2.4f, 1f);
        busyFor(ShazamAnim.SUNCALL_WINDUP + 4);
        r.getNavigation().stop();
        r.later(ShazamAnim.SUNCALL_WINDUP, () -> {
            boolean sky = PassiveConditions.skyLight(r.level(), r.blockPosition()) && !kelam();
            r.healRival(sky ? 220f : 90f);
            r.clearFire();
            r.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
            r.removeEffect(MobEffects.WEAKNESS);
            r.removeEffect(MobEffects.POISON);
            r.removeEffect(MobEffects.WITHER);
            for (LivingEntity foe : r.foes(r.position(), 6.0)) {
                if (r.hit(foe, 10f * SKILL)) {
                    push(foe, r.position(), 1.2, 0.35);
                }
            }
        });
        return true;
    }
}
