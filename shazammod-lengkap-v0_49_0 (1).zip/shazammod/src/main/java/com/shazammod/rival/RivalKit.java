package com.shazammod.rival;

import com.shazammod.ShazamForm;
import com.shazammod.ShazamPowers;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * 0.46 Kerangka AI rival untuk juara sains (Lintang & Helion-6): pemilih skill acak berbobot dengan jeda per skill, dan
 * alat bantu bertarung (terjangan lurus, membidik dengan kepala & mata, kerucut di depan, sinar lurus). Turunannya
 * (RivalLintang, RivalHelion) memakai animasi, suara, & waktu yang SAMA dengan skill pemain, jadi semua efeknya langsung
 * diputar di pemain boneka rival (client.RivalPuppets). Damage-nya kekuatan juara (RivalChampion.clash) dikali SKILL.
 */
abstract class RivalKit {
    /** Damage skill rival = angka skill pemain x ini (sama dengan RivalMoves.SKILL_DAMAGE). */
    static final float SKILL = RivalMoves.SKILL_DAMAGE;
    private static final int GAP = 40;              // jeda minimal antar-skill (tick)
    private static final int GAP_RANDOM = 30;
    private static final int MIN_COOLDOWN = 110;

    protected final RivalChampion r;
    private final long[] readyAt;
    private long nextSkill;
    private long busyUntil;

    RivalKit(RivalChampion rival, int slots) {
        this.r = rival;
        this.readyAt = new long[slots];
    }

    // ------------------------------------------------------------------ dipanggil RivalMoves

    abstract int[] weights(LivingEntity target, double distance, boolean sight, float health);

    abstract boolean use(int slot, LivingEntity target);

    abstract int cooldown(int slot);

    abstract void punch(LivingEntity target);

    abstract void pulse();

    abstract void passiveChanged(boolean on);

    abstract boolean defend(DamageSource source, boolean ready);

    abstract float damageTakenMultiplier(DamageSource source, float amount);

    /** Tiap tick selama duel, sebelum memilih skill (efek yang berjalan, kurungan, orbit). */
    void tickExtra(LivingEntity target) {
    }

    /** Sesaat sesudah rival berubah wujud. */
    void transformed() {
    }

    float damageBonus(LivingEntity target) {
        return 1f;
    }

    void reset() {
        busyUntil = 0;
    }

    void startFight() {
        nextSkill = now() + 40;
    }

    boolean busy() {
        return now() < busyUntil;
    }

    void tick(LivingEntity target) {
        tickExtra(target);
        long now = now();
        if (busy() || now < nextSkill || target == null) {
            return;
        }
        double d = Math.sqrt(r.distanceToSqr(target));
        int[] weight = weights(target, d, r.hasLineOfSight(target), r.getHealth() / r.getMaxHealth());
        int total = 0;
        for (int i = 0; i < weight.length && i < readyAt.length; i++) {
            if (readyAt[i] > now) {
                weight[i] = 0;
            }
            total += Math.max(0, weight[i]);
        }
        if (total <= 0) {
            nextSkill = now + 10;
            return;
        }
        int roll = r.getRandom().nextInt(total), slot = -1;
        for (int i = 0; i < weight.length && i < readyAt.length; i++) {
            roll -= Math.max(0, weight[i]);
            if (roll < 0) {
                slot = i;
                break;
            }
        }
        if (slot < 0) {
            nextSkill = now + 10;
            return;
        }
        if (use(slot, target)) {
            readyAt[slot] = now + Math.max(MIN_COOLDOWN, cooldown(slot));
            nextSkill = now + GAP + r.getRandom().nextInt(GAP_RANDOM);
        } else {
            readyAt[slot] = now + 40;
            nextSkill = now + 10;
        }
    }

    // ------------------------------------------------------------------ alat bantu

    long now() {
        return r.level().getGameTime();
    }

    void busyFor(int ticks) {
        busyUntil = Math.max(busyUntil, now() + ticks);
    }

    static Vec3 chest(LivingEntity e) {
        return e.position().add(0, e.getBbHeight() * 0.6, 0);
    }

    static Vec3 away(Vec3 from, LivingEntity e) {
        Vec3 a = new Vec3(e.getX() - from.x, 0, e.getZ() - from.z);
        return a.lengthSqr() < 1.0E-4 ? Vec3.ZERO : a.normalize();
    }

    static void push(LivingEntity target, Vec3 from, double strength, double up) {
        Vec3 a = away(from, target);
        target.push(a.x * strength, up, a.z * strength);
        target.hurtMarked = true;
    }

    /** Radiasi Cryon: lemah & lambat. */
    static void sicken(LivingEntity target, int ticks) {
        target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, ticks, 1));
        target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, Math.max(20, ticks / 2), 1));
    }

    static double segmentDistance(Vec3 p, Vec3 a, Vec3 b) {
        Vec3 ab = b.subtract(a);
        double len2 = ab.lengthSqr();
        double t = len2 < 1.0E-8 ? 0.0 : Mth.clamp(p.subtract(a).dot(ab) / len2, 0.0, 1.0);
        return p.distanceTo(a.add(ab.scale(t)));
    }

    Vec3 flatTo(LivingEntity target) {
        Vec3 to = new Vec3(target.getX() - r.getX(), 0, target.getZ() - r.getZ());
        if (to.lengthSqr() < 1.0E-4) {
            float yaw = r.getYRot() * Mth.DEG_TO_RAD;
            to = new Vec3(-Mth.sin(yaw), 0, Mth.cos(yaw));
        }
        return to.normalize();
    }

    /** Menghadap sasaran dan mengarahkan pandangan (kepala & mata) tepat ke dadanya: sinar mata di client ikut arah ini. */
    void aim(LivingEntity target) {
        r.face(target);
        Vec3 to = chest(target).subtract(r.getEyePosition());
        double flat = Math.sqrt(to.x * to.x + to.z * to.z);
        float pitch = (float) (-Mth.atan2(to.y, flat) * Mth.RAD_TO_DEG);
        r.setXRot(pitch);
        r.xRotO = pitch;
    }

    /** Ujung terjangan: dari posisi rival ke arah dir sejauh range, berhenti sebelum tembok (null = terlalu pendek). */
    Vec3 dashEnd(Vec3 dir, double range) {
        Vec3 start = r.position();
        Vec3 from = start.add(0, 1.0, 0);
        BlockHitResult hit = r.level().clip(new ClipContext(from, from.add(dir.scale(range)), ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, r));
        double distance = hit.getType() == HitResult.Type.MISS ? range : hit.getLocation().distanceTo(from) - 0.9;
        Vec3 end = start.add(dir.scale(distance));
        while (distance >= 2.0 && !r.level().noCollision(r, r.getBoundingBox().move(end.subtract(start)))) {
            distance -= 0.5;
            end = start.add(dir.scale(distance));
        }
        return distance < 2.0 ? null : end;
    }

    /** Gerakkan rival lurus dari start ke end selama ticks tick (cepat di awal, mengerem di ujung). */
    void dash(Vec3 start, Vec3 end, int ticks, RivalChampion.Step onStep, Runnable onEnd) {
        r.getNavigation().stop();
        r.setNoGravity(true);
        r.channel(ticks, k -> {
            double u = (k + 1) / (double) ticks;
            double e = 1.0 - Math.pow(1.0 - Math.min(1.0, u), 2.2);
            r.setDeltaMovement(start.lerp(end, e).subtract(r.position()));
            r.hurtMarked = true;
            onStep.run(k);
        }, () -> {
            r.setNoGravity(r.flag(RivalChampion.FLYING));
            Vec3 d = end.subtract(start);
            r.setDeltaMovement(d.lengthSqr() < 1.0E-4 ? Vec3.ZERO : d.normalize().scale(0.2));
            if (onEnd != null) {
                onEnd.run();
            }
        });
    }

    /** Sinar lurus dari mata searah pandangan: ujungnya di blok pertama. */
    Vec3 beamEnd(double range) {
        Vec3 eye = r.getEyePosition();
        Vec3 far = eye.add(r.getViewVector(1f).scale(range));
        BlockHitResult hit = r.level().clip(new ClipContext(eye, far, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, r));
        return hit.getType() == HitResult.Type.MISS ? far : hit.getLocation();
    }

    /** Lawan yang tersorot sinar dari mata ke end. */
    java.util.List<LivingEntity> beamFoes(Vec3 end) {
        Vec3 eye = r.getEyePosition();
        java.util.List<LivingEntity> out = new java.util.ArrayList<>();
        for (LivingEntity foe : r.foes(eye.add(end).scale(0.5), eye.distanceTo(end) * 0.5 + 2.0)) {
            if (segmentDistance(chest(foe), eye, end) <= 0.9 + foe.getBbWidth() * 0.5) {
                out.add(foe);
            }
        }
        return out;
    }

    /** Lawan di kerucut depan (cos = batas sudut), dengan jaraknya ke origin. */
    java.util.List<LivingEntity> coneFoes(Vec3 origin, Vec3 look, double range, double cos) {
        java.util.List<LivingEntity> out = new java.util.ArrayList<>();
        for (LivingEntity foe : r.foes(origin, range)) {
            Vec3 to = chest(foe).subtract(origin);
            if (to.lengthSqr() > 1.0E-4 && to.normalize().dot(look) >= cos && r.hasLineOfSight(foe)) {
                out.add(foe);
            }
        }
        return out;
    }

    /** Proyektil lawan di sekitar rival dihancurkan (perisai). */
    int destroyProjectiles(double radius) {
        int n = 0;
        for (Projectile shot : r.level().getEntitiesOfClass(Projectile.class, r.getBoundingBox().inflate(radius),
                p -> p.isAlive() && p.getOwner() != r)) {
            shot.discard();
            n++;
        }
        return n;
    }

    /** Pemain juara ini yang sedang berubah wujud? */
    static boolean isChampion(Object entity, ShazamForm form) {
        if (entity instanceof RivalChampion rival) {   // 0.47 duel: rival seteru juga dihitung
            return rival.form() == form && rival.isTransformedRival();
        }
        return entity instanceof ServerPlayer p && ShazamPowers.isTransformed(p) && ShazamPowers.data(p).champion() == form;
    }
}
