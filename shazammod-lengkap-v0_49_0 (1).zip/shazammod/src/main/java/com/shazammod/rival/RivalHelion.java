package com.shazammod.rival;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import com.shazammod.HelionSkills;
import com.shazammod.PassiveConditions;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamForm;
import com.shazammod.ShazamPowers;
import com.shazammod.ShazamSounds;

import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * 0.46 Rival Projek Helion-6: penjahat radiasi yang bertarung dengan SEMUA senjata Helion-6 pemain (animasi, efek, suara, dan
 * waktunya sama), plus kelemahan & taktiknya sendiri:
 * - Di bawah matahari sel Cryon-nya terbakar: damage-nya tinggal 60%, damage yang diterima naik 30%, Kulit Cryon padam,
 *   kulitnya berasap (efek otomatis di boneka). Begitu terbakar dia hampir pasti memanggil GERHANA BUATAN (matahari padam di
 *   wilayah itu, kelemahannya hilang, dan juara surya seperti Lintang ikut kehilangan tenaganya), atau menghirup Cryon.
 * - Musuh bebuyutan Lintang: tinjunya dihitung radiasi Cryon (lihat HelionSkills.radiatesRival & LintangSkills), dan
 *   pukulan Lintang membakarnya x1,4.
 * - Mengejek lewat balon kata komik di atas kepalanya (HELION_TAUNT).
 *
 * Slot: 0 Hempasan Lesat, 1 Emisi Cryon (sinar mata), 2 Lahap Radiasi, 3 Injakan Cryon, 4 Orbit Cryon, 5 Nisan Kristal,
 * 6 Supernova-6, 7 Hirup Cryon, 8 Gerhana Buatan.
 */
final class RivalHelion extends RivalKit {
    private static final float WEAK_POWER = 0.6f;     // di bawah matahari
    private static final float WEAK_TAKEN = 1.3f;
    private static final float SURGE_POWER = 1.3f;    // Lonjakan Cryon sesudah Hirup Cryon
    private static final float SURGE_TAKEN = 0.8f;
    private static final float NOVA_TAKEN = 0.3f;     // selama menyerap Supernova
    private static final float PUNCH = 1.1f;          // tinju Helion-6 sedikit lebih sakit dari rival lain

    private long surgeUntil;
    private long novaUntil;
    private long tauntReady;
    private long orbitStart = -1;
    private int orbitFired;
    private final Map<LivingEntity, Long> tombs = new HashMap<>();

    RivalHelion(RivalChampion rival) {
        super(rival, 9);
    }

    /** Sel Cryon sedang terbakar matahari (gerhana menutupnya: PassiveConditions.underSun sudah ikut gerhana). */
    private boolean weakened() {
        return PassiveConditions.underSun(r.level(), r.blockPosition());
    }

    private float scale() {
        return (weakened() ? WEAK_POWER : 1f) * (now() < surgeUntil ? SURGE_POWER : 1f);
    }

    private void taunt(HelionSkills.Taunt taunt, boolean always) {
        if (!always && now() < tauntReady) {
            return;
        }
        tauntReady = now() + 140;
        r.anim(ShazamAnim.HELION_TAUNT, new Vec3(taunt.ordinal(), r.getRandom().nextInt(taunt.lines), 0));
    }

    @Override
    void reset() {
        super.reset();
        surgeUntil = 0;
        novaUntil = 0;
        orbitStart = -1;
        tombs.clear();
    }

    @Override
    void transformed() {
        taunt(HelionSkills.Taunt.TRANSFORM, true);
        for (LivingEntity foe : r.foes(r.position(), 7.0)) {   // radiasi meledak dari tubuh saat berubah
            if (r.hit(foe, 26f * SKILL)) {
                push(foe, r.position(), 1.6, 0.5);
                sicken(foe, 100);
            }
        }
    }

    // ------------------------------------------------------------------ memilih skill

    @Override
    int[] weights(LivingEntity target, double d, boolean sight, float hp) {
        boolean weak = weakened();
        boolean eclipse = HelionSkills.eclipsed(r.level(), r.position());
        int[] w = new int[9];
        w[0] = d > 5 && d < 20 && sight ? 5 : 0;                        // Hempasan Lesat
        w[1] = sight && d > 3 && d < 30 ? 6 : 0;                        // Emisi Cryon
        w[2] = d < 11 ? 4 : 0;                                          // Lahap Radiasi
        w[3] = d < 10 && r.onGround() ? 4 : 0;                          // Injakan Cryon
        w[4] = sight && d < 26 && orbitStart < 0 ? 4 : 0;               // Orbit Cryon
        w[5] = sight && d < 16 && r.onGround() ? 4 : 0;                 // Nisan Kristal
        w[6] = hp < 0.5f ? 6 : 0;                                       // Supernova-6
        w[7] = (hp < 0.65f || weak) && now() >= surgeUntil ? (weak ? 6 : 4) : 0;   // Hirup Cryon
        w[8] = weak && !eclipse ? 12 : 0;                               // Gerhana Buatan: begitu terbakar matahari
        return w;
    }

    @Override
    int cooldown(int slot) {
        return switch (slot) {
            case 7 -> HelionSkills.INHALE_COOLDOWN_TICKS;
            case 8 -> 1800;
            default -> HelionSkills.Skill.values()[slot].cooldownTicks;
        };
    }

    @Override
    boolean use(int slot, LivingEntity target) {
        return switch (slot) {
            case 0 -> hempas(target);
            case 1 -> emisi(target);
            case 2 -> lahap();
            case 3 -> injak();
            case 4 -> orbit();
            case 5 -> nisan(target);
            case 6 -> supernova();
            case 7 -> inhale();
            case 8 -> eclipse();
            default -> false;
        };
    }

    // ------------------------------------------------------------------ tinju, pasif, bertahan

    @Override
    void punch(LivingEntity target) {
        float damage = RivalChampion.PUNCH_DAMAGE * PUNCH * scale();
        boolean charged = r.flag(RivalChampion.CHARGED);
        if (charged) {
            damage *= 1.75f;
            r.setFlag(RivalChampion.CHARGED, false);
        }
        Vec3 at = chest(target);
        if (!r.hit(target, damage)) {
            return;
        }
        r.sound(at, ShazamSounds.HELION_PUNCH.get(), 1.0f, 0.95f + r.getRandom().nextFloat() * 0.1f);
        push(target, r.position(), charged ? 2.2 : 1.0, charged ? 0.6 : 0.3);
        r.anim(ShazamAnim.HELION_PUNCH, at);
        if (r.getRandom().nextInt(3) == 0) {
            sicken(target, 40);
        }
        if (!charged) {
            return;
        }
        r.anim(ShazamAnim.HELION_CRYON_PUNCH, at);   // Tinju Cryon: radiasi meledak & menyambar 3 lawan lain
        r.sound(at, ShazamSounds.HELION_CRYON_PUNCH.get(), 2.0f, 1f);
        sicken(target, 160);
        List<LivingEntity> near = r.foes(target.position(), 7.0);
        near.remove(target);
        near.sort(Comparator.comparingDouble(m -> m.distanceToSqr(target)));
        for (int i = 0; i < Math.min(3, near.size()); i++) {
            LivingEntity m = near.get(i);
            m.invulnerableTime = 0;
            if (r.hit(m, 16f * SKILL)) {
                sicken(m, 80);
                r.anim(ShazamAnim.HELION_DASH_HIT, chest(m));
            }
        }
    }

    /** Denyut Cryon tiap 2 detik (padam di bawah matahari lewat PassiveConditions). */
    @Override
    void pulse() {
        r.anim(ShazamAnim.HELION_PULSE, r.position());
        r.level().playSound(null, r, ShazamSounds.HELION_PULSE.get(), SoundSource.HOSTILE, 1.2f, 1f);
        r.later(1, r::empower);
        for (LivingEntity foe : r.foes(r.position(), 3.5)) {
            if (r.hit(foe, 5f * SKILL)) {
                sicken(foe, 40);
            }
        }
    }

    @Override
    void passiveChanged(boolean on) {
        r.anim(on ? ShazamAnim.HELION_SUN_CLEAR : ShazamAnim.HELION_SUN_BURN, r.position());
        r.level().playSound(null, r, (on ? ShazamSounds.HELION_PULSE : ShazamSounds.HELION_SUN_BURN).get(),
                SoundSource.HOSTILE, 1.3f, 1f);
        if (!on) {
            taunt(HelionSkills.Taunt.SUN, true);
        }
    }

    /** Kulit Cryon (tiap 1,8 detik, padam di bawah matahari): serangan ditepis radiasi, penyerangnya terpapar. */
    @Override
    boolean defend(DamageSource source, boolean ready) {
        Entity attacker = source.getEntity();
        Entity direct = source.getDirectEntity();
        if (!ready || weakened() || (attacker == null && direct == null) || now() < novaUntil) {
            return false;
        }
        Entity from = direct != null ? direct : attacker;
        Vec3 c = chest(r);
        Vec3 toward = from.position().add(0, from.getBbHeight() * 0.6, 0).subtract(c);
        Vec3 hit = toward.lengthSqr() < 1.0E-4 ? c : c.add(toward.normalize().scale(0.55));
        r.anim(ShazamAnim.HELION_DEFLECT, hit);
        r.sound(hit, ShazamSounds.DEFLECT.get(), 1.0f, ShazamSounds.tune(1.3f));
        if (attacker instanceof LivingEntity foe && foe.distanceToSqr(r) < 6.0 * 6.0) {
            r.later(1, () -> {
                if (foe.isAlive() && r.hit(foe, 6f * SKILL)) {
                    sicken(foe, 60);
                }
            });
        }
        return true;
    }

    @Override
    float damageTakenMultiplier(DamageSource source, float amount) {
        float k = 1f;
        if (weakened()) {
            k *= WEAK_TAKEN;
        }
        if (now() < surgeUntil) {
            k *= SURGE_TAKEN;
        }
        if (now() < novaUntil) {
            k *= NOVA_TAKEN;
        }
        if (isChampion(source.getEntity(), ShazamForm.LINTANG)) {
            k *= ShazamPowers.HELION_SOLAR_HIT_MULTIPLIER;   // tenaga matahari Lintang membakar sel Cryon
        }
        if (source.is(DamageTypes.MAGIC) || source.is(DamageTypes.INDIRECT_MAGIC)) {
            k *= ShazamPowers.HELION_MAGIC_MULTIPLIER;
        }
        return k;
    }

    // ------------------------------------------------------------------ efek yang berjalan

    @Override
    void tickExtra(LivingEntity target) {
        long now = now();
        if (orbitStart >= 0) {
            int t = (int) (now - orbitStart);
            if (t >= ShazamAnim.HELION_ORBIT_TICKS || orbitFired >= HelionSkills.ORBIT_SHARDS) {
                orbitStart = -1;
            } else {
                if (t >= HelionSkills.ORBIT_SUMMON && destroyProjectiles(2.8) > 0) {
                    r.anim(ShazamAnim.HELION_DEFLECT, chest(r));
                }
                if (t >= 18 && (t - 18) % 4 == 0) {
                    List<LivingEntity> foes = r.foes(r.position(), 28.0);
                    foes.removeIf(m -> !r.hasLineOfSight(m));
                    if (!foes.isEmpty()) {
                        foes.sort(Comparator.comparingDouble(m -> m.distanceToSqr(r)));
                        fireShard(foes.get(orbitFired % foes.size()));
                        orbitFired++;
                    }
                }
            }
        }
        if (!tombs.isEmpty()) {
            List<LivingEntity> shattered = new ArrayList<>();
            Iterator<Map.Entry<LivingEntity, Long>> it = tombs.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<LivingEntity, Long> e = it.next();
                LivingEntity foe = e.getKey();
                if (!foe.isAlive() || foe.isRemoved()) {
                    it.remove();
                } else if (now >= e.getValue()) {
                    shattered.add(foe);
                    it.remove();
                } else {
                    foe.setDeltaMovement(0, Math.min(foe.getDeltaMovement().y, 0), 0);
                    foe.hurtMarked = true;
                }
            }
            float k = scale();
            for (LivingEntity foe : shattered) {
                Vec3 at = chest(foe);
                foe.invulnerableTime = 0;
                r.hit(foe, 18f * SKILL * k);
                push(foe, r.position(), 0.9, 0.5);
                r.anim(ShazamAnim.HELION_TOMB_SHATTER, at);
                r.sound(at, ShazamSounds.HELION_TOMB_SHATTER.get(), 1.4f, 0.9f + r.getRandom().nextFloat() * 0.2f);
            }
        }
    }

    // ------------------------------------------------------------------ skill

    private boolean hempas(LivingEntity target) {
        Vec3 dir = chest(target).subtract(r.position().add(0, 1.0, 0));
        if (dir.lengthSqr() < 1.0E-4) {
            return false;
        }
        dir = dir.normalize();
        Vec3 end = dashEnd(dir, Math.min(22.0, Math.sqrt(r.distanceToSqr(target)) + 4.0));
        if (end == null) {
            return false;
        }
        Vec3 start = r.position();
        r.anim(ShazamAnim.HELION_DASH, end);
        r.sound(start, ShazamSounds.HELION_DASH.get(), 1.6f, 1f);
        busyFor(ShazamAnim.HELION_DASH_WINDUP + ShazamAnim.HELION_DASH_TICKS + 4);
        r.getNavigation().stop();
        Set<UUID> hit = new HashSet<>();
        float k = scale();
        r.later(ShazamAnim.HELION_DASH_WINDUP, () -> dash(start, end, ShazamAnim.HELION_DASH_TICKS, step -> {
            for (LivingEntity foe : r.foes(r.position(), 2.4)) {
                if (hit.add(foe.getUUID()) && r.hit(foe, 34f * SKILL * k)) {
                    push(foe, r.position(), 1.4, 0.55);
                    sicken(foe, 60);
                    r.anim(ShazamAnim.HELION_DASH_HIT, chest(foe));
                }
            }
        }, () -> {
            for (LivingEntity foe : r.foes(r.position(), 4.5)) {
                if (!hit.contains(foe.getUUID()) && r.hit(foe, 14f * SKILL * k)) {
                    push(foe, r.position(), 0.9, 0.35);
                }
            }
            r.sound(r.position(), ShazamSounds.SHOCKWAVE.get(), 1.2f, ShazamSounds.tune(1.2f));
        }));
        return true;
    }

    /** Emisi Cryon: kepala & mata terus membidik sasaran, sinar dari mata (efeknya ikut arah pandang boneka). */
    private boolean emisi(LivingEntity target) {
        int w = ShazamAnim.HELION_EYES_WINDUP, len = ShazamAnim.HELION_EYES_TICKS;
        r.anim(ShazamAnim.HELION_EYES);
        r.sound(r.getEyePosition(), ShazamSounds.HELION_BEAM_CHARGE.get(), 1.2f, 1f);
        taunt(HelionSkills.Taunt.EYES, false);
        busyFor(w + len + 4);
        r.getNavigation().stop();
        float k = scale();
        r.later(w, () -> r.sound(r.getEyePosition(), ShazamSounds.HELION_BEAM_FIRE.get(), 1.8f, 1f));
        r.channel(w + len, step -> {
            if (target.isAlive()) {
                aim(target);
            }
            if (step < w || (step - w) % 2 != 0) {
                return;
            }
            for (LivingEntity foe : beamFoes(beamEnd(HelionSkills.BEAM_RANGE))) {
                foe.invulnerableTime = 0;
                if (r.hit(foe, 8f * SKILL * k)) {
                    foe.igniteForSeconds(2f);
                    sicken(foe, 30);
                }
            }
        }, null);
        return true;
    }

    /** Lahap Radiasi: menghisap radiasi & nyawa sampai 6 lawan dalam 12 blok, rival pulih per lawan. */
    private boolean lahap() {
        if (r.foes(r.position(), 12.0).isEmpty()) {
            return false;
        }
        int len = ShazamAnim.HELION_LAHAP_TICKS;
        r.anim(ShazamAnim.HELION_LAHAP);
        r.sound(r.position(), ShazamSounds.HELION_LAHAP.get(), 1.8f, 1f);
        taunt(HelionSkills.Taunt.LAHAP, false);
        busyFor(len + 4);
        r.getNavigation().stop();
        float k = scale();
        r.channel(len, step -> {
            if (step % 5 != 4) {
                return;
            }
            List<LivingEntity> near = r.foes(r.position(), 12.0);
            near.sort(Comparator.comparingDouble(m -> m.distanceToSqr(r)));
            int fed = 0;
            Vec3 c = chest(r);
            for (LivingEntity m : near) {
                if (fed >= 6) {
                    break;
                }
                m.invulnerableTime = 0;
                if (r.hit(m, 5f * SKILL * k)) {
                    m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20, 1, false, false));
                    Vec3 pull = c.subtract(m.position());
                    if (pull.lengthSqr() > 4.0) {
                        pull = pull.normalize().scale(0.12);
                        m.push(pull.x, 0.02, pull.z);
                        m.hurtMarked = true;
                    }
                    fed++;
                }
            }
            if (fed > 0) {
                r.healRival(4f * fed);
            }
        }, null);
        return true;
    }

    private boolean injak() {
        Vec3 c0 = r.position();
        r.anim(ShazamAnim.HELION_QUAKE, c0);
        r.sound(c0, ShazamSounds.HELION_QUAKE.get(), 2.6f, 1f);
        taunt(HelionSkills.Taunt.QUAKE, false);
        busyFor(ShazamAnim.HELION_QUAKE_WINDUP + 10);
        r.getNavigation().stop();
        float k = scale();
        r.later(ShazamAnim.HELION_QUAKE_WINDUP, () -> {
            Vec3 c = r.position();
            for (LivingEntity foe : r.foes(c, 13.0)) {
                double d = Math.sqrt(foe.distanceToSqr(c));
                float fall = d <= 3.5 ? 1f : (float) (3.5 / d);
                foe.invulnerableTime = 0;
                if (r.hit(foe, 48f * SKILL * k * fall)) {
                    Vec3 a = away(c, foe);
                    double kk = 0.35 + 0.65 * fall;
                    foe.push(a.x * 1.6 * kk, 0.95 * kk, a.z * 1.6 * kk);
                    foe.hurtMarked = true;
                    sicken(foe, 60);
                }
            }
            r.later(8, () -> {   // gempa susulan: cuma yang berpijak di tanah
                for (LivingEntity foe : r.foes(c, 19.0)) {
                    if (foe.onGround() && r.hit(foe, 12f * SKILL * k)) {
                        push(foe, c, 0.5, 0.45);
                    }
                }
            });
        });
        return true;
    }

    private boolean orbit() {
        orbitStart = now();
        orbitFired = 0;
        r.anim(ShazamAnim.HELION_ORBIT);
        r.sound(r.position(), ShazamSounds.HELION_ORBIT.get(), 1.6f, 1f);
        taunt(HelionSkills.Taunt.ORBIT, false);
        busyFor(12);
        return true;
    }

    /** Satu kristal melesat; kena sesudah jarak / SHARD_SPEED tick, sama dengan lintasan yang digambar client. */
    private void fireShard(LivingEntity target) {
        Vec3 aim = chest(target);
        Vec3 from = r.position().add(0, r.getBbHeight() * 0.55, 0);
        int travel = Math.max(2, (int) Math.ceil(aim.distanceTo(from) / HelionSkills.SHARD_SPEED));
        r.anim(ShazamAnim.HELION_SHARD, aim);
        r.sound(from, ShazamSounds.HELION_SHARD.get(), 1.0f, 0.9f + r.getRandom().nextFloat() * 0.2f);
        float k = scale();
        Vec3 dir = aim.subtract(from).lengthSqr() < 1.0E-4 ? Vec3.ZERO : aim.subtract(from).normalize();
        r.later(travel, () -> {
            if (!target.isAlive()) {
                return;
            }
            target.invulnerableTime = 0;
            if (r.hit(target, 18f * SKILL * k)) {
                sicken(target, 80);
                target.push(dir.x * 0.6, 0.25, dir.z * 0.6);
                target.hurtMarked = true;
            }
        });
    }

    /** Nisan Kristal: kristal meletus berderet ke arah sasaran, lawan yang kena terkurung lalu kurungannya pecah. */
    private boolean nisan(LivingEntity target) {
        Vec3 dir = flatTo(target);
        Vec3 origin = r.position().add(dir.scale(1.2));
        r.face(target);
        r.anim(ShazamAnim.HELION_NISAN, dir);
        r.sound(origin, ShazamSounds.HELION_NISAN.get(), 2.2f, 1f);
        taunt(HelionSkills.Taunt.NISAN, false);
        int w = ShazamAnim.HELION_NISAN_WINDUP;
        busyFor(w + 14);
        r.getNavigation().stop();
        float k = scale();
        boolean[] stop = {false};
        Set<UUID> caught = new HashSet<>();
        r.later(w, () -> r.channel(HelionSkills.TOMB_STEPS, step -> {
            if (stop[0]) {
                return;
            }
            Vec3 p = origin.add(dir.scale(step * HelionSkills.TOMB_STEP));
            BlockHitResult g = r.level().clip(new ClipContext(p.add(0, 2.5, 0), p.add(0, -5.0, 0), ClipContext.Block.COLLIDER,
                    ClipContext.Fluid.NONE, r));
            if (g.getType() == HitResult.Type.MISS) {
                stop[0] = true;
                return;
            }
            Vec3 gp = g.getLocation();
            for (LivingEntity foe : r.foes(gp, 2.6)) {
                if (Math.abs(foe.getY() - gp.y) > 3.0 || !caught.add(foe.getUUID())) {
                    continue;
                }
                foe.invulnerableTime = 0;
                if (r.hit(foe, 24f * SKILL * k)) {
                    sicken(foe, 80);
                    tombs.put(foe, now() + HelionSkills.TOMB_TICKS);
                    foe.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, HelionSkills.TOMB_TICKS, 6, false, false));
                    r.anim(ShazamAnim.HELION_TOMB_LOCK, new Vec3(foe.getId(), HelionSkills.TOMB_TICKS, 0));
                }
            }
        }, null));
        return true;
    }

    private boolean supernova() {
        int w = ShazamAnim.HELION_NOVA_WINDUP;
        r.anim(ShazamAnim.HELION_NOVA);
        r.sound(r.position(), ShazamSounds.HELION_NOVA.get(), 3.5f, 1f);
        taunt(HelionSkills.Taunt.NOVA, true);
        busyFor(w + 10);
        r.getNavigation().stop();
        novaUntil = now() + w;
        r.channel(w, step -> {
            if (step % 5 != 4) {
                return;
            }
            Vec3 c = r.position();
            for (LivingEntity foe : r.foes(c, 16.0)) {   // lawan tersedot pelan & terpapar
                Vec3 pull = c.subtract(foe.position());
                if (pull.lengthSqr() > 4.0) {
                    pull = pull.normalize().scale(0.35);
                    foe.push(pull.x, 0.04, pull.z);
                    foe.hurtMarked = true;
                }
            }
        }, this::novaBlast);
        return true;
    }

    private void novaBlast() {
        novaUntil = 0;
        float k = scale();
        double radius = 22.0;
        Vec3 c = r.position().add(0, 1.0, 0);
        r.anim(ShazamAnim.HELION_NOVA_BLAST, new Vec3(radius, 0.8, 0));
        for (LivingEntity foe : r.foes(c, radius)) {
            double d = Math.sqrt(foe.distanceToSqr(c));
            float fall = d <= 6.0 ? 1f : (float) Math.max(0.25, 6.0 / d);
            foe.invulnerableTime = 0;
            if (r.hit(foe, 150f * SKILL * k * fall)) {
                foe.igniteForSeconds(6f);
                sicken(foe, 160);
                Vec3 a = away(c, foe);
                foe.push(a.x * 2.4 * fall, 0.2 + 0.8 * fall, a.z * 2.4 * fall);
                foe.hurtMarked = true;
            }
        }
        destroyProjectiles(radius);
    }

    private boolean inhale() {
        r.anim(ShazamAnim.HELION_INHALE);
        r.sound(r.getEyePosition(), ShazamSounds.HELION_INHALE.get(), 1.6f, 1f);
        taunt(HelionSkills.Taunt.INHALE, false);
        busyFor(ShazamAnim.HELION_INHALE_WINDUP + 6);
        r.getNavigation().stop();
        r.later(ShazamAnim.HELION_INHALE_WINDUP, () -> {
            surgeUntil = now() + HelionSkills.SURGE_TICKS;
            r.healRival(150f);
            for (LivingEntity foe : r.foes(r.position(), 6.0)) {
                if (r.hit(foe, 10f * SKILL)) {
                    push(foe, r.position(), 1.1, 0.35);
                    sicken(foe, 60);
                }
            }
        });
        return true;
    }

    /** Gerhana Buatan: matahari padam di wilayah ini (kelemahannya hilang, juara surya kehilangan tenaga). */
    private boolean eclipse() {
        if (HelionSkills.eclipsed(r.level(), r.position())) {
            return false;
        }
        Vec3 c = r.position();
        r.anim(ShazamAnim.HELION_ECLIPSE, c);
        r.sound(c, ShazamSounds.HELION_ECLIPSE.get(), 4.0f, 1f);
        taunt(HelionSkills.Taunt.ECLIPSE, true);
        busyFor(ShazamAnim.HELION_ECLIPSE_WINDUP + 6);
        r.getNavigation().stop();
        r.later(ShazamAnim.HELION_ECLIPSE_WINDUP, () -> HelionSkills.addEclipse(r.level(), c, HelionSkills.ECLIPSE_RADIUS,
                now() + HelionSkills.ECLIPSE_TICKS));
        return true;
    }
}
