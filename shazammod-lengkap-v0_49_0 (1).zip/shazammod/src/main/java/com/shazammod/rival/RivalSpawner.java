package com.shazammod.rival;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.shazammod.AdamItems;
import com.shazammod.KahndaqTrial;
import com.shazammod.PassiveConditions;
import com.shazammod.SabbacItems;
import com.shazammod.SabbacPact;
import com.shazammod.ShazamData;
import com.shazammod.ShazamEntities;
import com.shazammod.ShazamForm;
import com.shazammod.ShazamItems;
import com.shazammod.ShazamPowers;
import com.shazammod.ShazamTotems;

import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

/**
 * 0.30 Kapan & di mana Rival Juara datang menantang. Rival cuma datang ke pemain yang sudah punya juara (dan bukan mode
 * Creative / Peaceful), satu rival per pemain, dan datang di tempat & waktu sumber kekuatannya sendiri:
 *
 * Black Adam : gurun atau badlands, siang hari, di bawah langit terbuka (matahari Kahndaq).
 * Shazam     : saat badai petir, di bawah langit terbuka.
 * Sabbac     : malam hari, atau di Nether (kegelapan neraka).
 * Lintang    : 0.46 siang hari di bawah langit terbuka (sumber kekuatannya matahari).
 * Helion-6   : 0.46 malam hari di Overworld, atau di bawah tanah tanpa langit (jauh dari matahari).
 *
 * Kalau beberapa cocok sekaligus, dipilih acak. Sesudah satu rival (kalah, menang, atau pergi), rival berikutnya baru bisa
 * datang ke pemain itu sesudah COOLDOWN_TICKS. Buat ngetes: /shazam rival shazam|black_adam|sabbac.
 */
public final class RivalSpawner {
    private RivalSpawner() {}

    // ================= Angka-angka yang gampang diutak-atik =================
    public static final boolean ENABLED = true;             // false = rival cuma datang lewat perintah
    public static final int CHECK_TICKS = 600;              // tiap 30 detik dicek
    public static final float CHANCE = 0.05f;               // 5% tiap pengecekan (rata-rata ±10 menit di tempat yang cocok)
    public static final int COOLDOWN_TICKS = 20 * 60 * 20;  // 20 menit sesudah rival terakhir
    public static final int FIRST_GRACE_TICKS = 20 * 60 * 5; // 5 menit pertama sesudah masuk world: belum ada rival
    public static final double MIN_DISTANCE = 14.0;
    public static final double MAX_DISTANCE = 20.0;
    public static final float DUEL_SHARE = 0.5f;            // 0.47: separuh kedatangan rival saat senja/fajar jadi duel Lintang vs Helion-6
    public static final double DUEL_GAP = 7.0;              // jarak tiap petarung dari titik tengah duel
    // =========================================================================

    private static final Map<UUID, Long> NEXT_CHECK = new HashMap<>();

    public static void clear() {
        NEXT_CHECK.clear();
        RivalChampion.ACTIVE.clear();
    }

    /** Dipanggil RivalChampion saat pergi: rival berikutnya baru datang sesudah cooldown. */
    static void cooldown(UUID player, long now) {
        NEXT_CHECK.put(player, now + COOLDOWN_TICKS);
    }

    public static void tick(MinecraftServer server) {
        if (!ENABLED || server.getTickCount() % 20 != 7) {
            return;
        }
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            ServerLevel level = player.serverLevel();
            long now = level.getGameTime();
            Long next = NEXT_CHECK.get(player.getUUID());
            if (next == null) {
                NEXT_CHECK.put(player.getUUID(), now + FIRST_GRACE_TICKS);
                continue;
            }
            if (now < next) {
                continue;
            }
            NEXT_CHECK.put(player.getUUID(), now + CHECK_TICKS);
            if (!eligible(player) || level.random.nextFloat() >= CHANCE) {
                continue;
            }
            if (com.shazammod.helion3.Helion3.naturalTime(player) && level.random.nextFloat() < com.shazammod.helion3.Helion3.SPAWN_SHARE
                    && subjectThree(player, false)) {
                continue;   // 0.48 Subjek Tiga mencium jejak serum Helion
            }
            if (duelTime(player) && level.random.nextFloat() < DUEL_SHARE && duel(player, false)) {
                continue;   // 0.47 saat matahari & kegelapan bertemu, Lintang & Helion-6 bertarung di dekatmu
            }
            List<ShazamForm> options = choices(player);
            if (!options.isEmpty()) {
                summon(player, options.get(level.random.nextInt(options.size())), false);
            }
        }
    }

    private static boolean eligible(ServerPlayer player) {
        ShazamData data = ShazamPowers.data(player);
        return data.anyUnlocked() && !player.isCreative() && !player.isSpectator() && player.isAlive()
                && player.level().getDifficulty() != Difficulty.PEACEFUL && !RivalChampion.ACTIVE.contains(player.getUUID())
                && !KahndaqTrial.isRunning(player) && !SabbacPact.isAwakening(player) && !ShazamTotems.isAwakening(player)
                && !com.shazammod.LintangRite.isAwakening(player);
    }

    /** Rival yang cocok dengan tempat & waktu pemain sekarang. */
    static List<ShazamForm> choices(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        BlockPos pos = player.blockPosition();
        List<ShazamForm> out = new ArrayList<>();
        boolean sky = level.canSeeSky(pos.above());
        if (PassiveConditions.sunUp(level) && sky && KahndaqTrial.isKahndaq(level, pos) && !level.isRaining()) {
            out.add(ShazamForm.BLACK_ADAM);
        }
        if (level.isThundering() && sky) {
            out.add(ShazamForm.SHAZAM);
        }
        if (level.dimension() == Level.NETHER || (level.dimension() == Level.OVERWORLD && !PassiveConditions.sunUp(level))) {
            out.add(ShazamForm.SABBAC);
        }
        if (PassiveConditions.underSun(level, pos)) {   // 0.46 Lintang datang saat matahari bersinar
            out.add(ShazamForm.LINTANG);
        }
        if (level.dimension() == Level.OVERWORLD && (!PassiveConditions.sunUp(level) || !sky)) {   // 0.46 Helion-6: jauh dari matahari
            out.add(ShazamForm.HELION);
        }
        return out;
    }

    /**
     * 0.48 Subjek Tiga merangkak keluar dari tanah 16-21 blok dari pemain ini (forced = dari perintah: rival & Subjek Tiga
     * lama disingkirkan). 3,5 detik kemudian Lintang & Helion-6 datang sebagai sekutu (allies).
     */
    public static boolean subjectThree(ServerPlayer witness, boolean forced) {
        ServerLevel level = witness.serverLevel();
        if (RivalChampion.ACTIVE.contains(witness.getUUID())) {
            if (!forced) {
                return false;
            }
            for (RivalChampion old : level.getEntitiesOfClass(RivalChampion.class, witness.getBoundingBox().inflate(160.0),
                    r -> witness.getUUID().equals(r.challengerId()))) {
                old.discard();
            }
            RivalChampion.ACTIVE.remove(witness.getUUID());
        }
        List<com.shazammod.helion3.Helion3> existing = level.getEntitiesOfClass(com.shazammod.helion3.Helion3.class,
                witness.getBoundingBox().inflate(160.0), b -> true);
        if (!existing.isEmpty()) {
            if (!forced) {
                return false;
            }
            for (com.shazammod.helion3.Helion3 old : existing) {
                old.discard();
            }
        }
        com.shazammod.helion3.Helion3 boss = ShazamEntities.HELION3.get().create(level);
        if (boss == null) {
            return false;
        }
        double angle = level.random.nextDouble() * Math.PI * 2.0;
        double dist = 16.0 + level.random.nextDouble() * 5.0;
        Vec3 at = surface(level, witness.position().add(Math.cos(angle) * dist, 0, Math.sin(angle) * dist), witness.getY());
        float yaw = (float) Math.toDegrees(Math.atan2(witness.getZ() - at.z, witness.getX() - at.x)) - 90f;
        boss.moveTo(at.x, at.y, at.z, yaw, 0f);
        boss.setup(witness, true);
        if (!level.addFreshEntity(boss)) {
            return false;
        }
        com.shazammod.helion3.Helion3.cooldown(witness);
        NEXT_CHECK.put(witness.getUUID(), level.getGameTime() + COOLDOWN_TICKS);
        return true;
    }

    /** 0.48 Lintang & Helion-6 menghentikan permusuhan dan datang di sisi pemain ini untuk melawan boss bersama. */
    public static void allies(ServerPlayer witness, LivingEntity boss) {
        ServerLevel level = witness.serverLevel();
        RivalChampion lintang = ShazamEntities.RIVAL.get().create(level);
        RivalChampion helion = ShazamEntities.RIVAL.get().create(level);
        if (lintang == null || helion == null) {
            return;
        }
        Vec3 base = witness.position();
        Vec3 to = new Vec3(boss.getX() - base.x, 0, boss.getZ() - base.z);
        Vec3 side = to.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : new Vec3(-to.z, 0, to.x).normalize();
        Vec3 a = surface(level, base.add(side.scale(4.0)), base.y);
        Vec3 b = surface(level, base.subtract(side.scale(4.0)), base.y);
        float yaw = (float) Math.toDegrees(Math.atan2(boss.getZ() - base.z, boss.getX() - base.x)) - 90f;
        lintang.moveTo(a.x, a.y, a.z, yaw, 0f);
        helion.moveTo(b.x, b.y, b.z, yaw, 0f);
        lintang.setupAlly(ShazamForm.LINTANG, witness, boss.getUUID(), true);
        helion.setupAlly(ShazamForm.HELION, witness, boss.getUUID(), false);
        level.addFreshEntity(lintang);
        level.addFreshEntity(helion);
    }

    /** 0.47 Senja atau fajar di Overworld, di bawah langit terbuka: matahari & kegelapan bertemu. */
    static boolean duelTime(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        if (level.dimension() != Level.OVERWORLD || !level.canSeeSky(player.blockPosition().above())) {
            return false;
        }
        long t = Math.floorMod(level.getDayTime(), 24000L);
        return (t >= 11800L && t <= 13400L) || t >= 22600L || t <= 400L;
    }

    /**
     * 0.47 Duel Lintang vs Helion-6 di dekat pemain ini (forced = dari perintah: rival lama disingkirkan dulu). Keduanya
     * datang berhadapan, berubah wujud, lalu saling bertarung sampai salah satu tumbang; pemainnya cuma saksi (kecuali ikut
     * campur sebagai juara), dan hadiah yang kalah tertinggal di tanah.
     */
    public static boolean duel(ServerPlayer witness, boolean forced) {
        if (RivalChampion.ACTIVE.contains(witness.getUUID())) {
            if (!forced) {
                return false;
            }
            for (RivalChampion old : witness.serverLevel().getEntitiesOfClass(RivalChampion.class,
                    witness.getBoundingBox().inflate(160.0), r -> witness.getUUID().equals(r.challengerId()))) {
                old.discard();
            }
            RivalChampion.ACTIVE.remove(witness.getUUID());
        }
        ServerLevel level = witness.serverLevel();
        RivalChampion lintang = ShazamEntities.RIVAL.get().create(level);
        RivalChampion helion = ShazamEntities.RIVAL.get().create(level);
        if (lintang == null || helion == null) {
            return false;
        }
        Vec3 center = spawnPoint(witness, level.random);
        Vec3 to = new Vec3(center.x - witness.getX(), 0, center.z - witness.getZ());
        Vec3 side = to.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : new Vec3(-to.z, 0, to.x).normalize();
        Vec3 a = surface(level, center.add(side.scale(DUEL_GAP)), center.y);
        Vec3 b = surface(level, center.subtract(side.scale(DUEL_GAP)), center.y);
        float yawA = (float) Math.toDegrees(Math.atan2(b.z - a.z, b.x - a.x)) - 90f;
        lintang.moveTo(a.x, a.y, a.z, yawA, 0f);
        helion.moveTo(b.x, b.y, b.z, yawA + 180f, 0f);
        lintang.setupDuel(ShazamForm.LINTANG, witness, true);
        helion.setupDuel(ShazamForm.HELION, witness, false);
        lintang.setNemesis(helion.getUUID());
        helion.setNemesis(lintang.getUUID());
        if (!level.addFreshEntity(lintang)) {
            RivalChampion.ACTIVE.remove(witness.getUUID());
            return false;
        }
        if (!level.addFreshEntity(helion)) {
            lintang.discard();
            return false;
        }
        NEXT_CHECK.put(witness.getUUID(), level.getGameTime() + COOLDOWN_TICKS);
        return true;
    }

    /** Permukaan tanah di (x, z) dekat ketinggian nearY (di Nether / tanpa permukaan dekat: tetap di nearY). */
    private static Vec3 surface(ServerLevel level, Vec3 p, double nearY) {
        if (level.dimension() != Level.NETHER && !level.dimensionType().hasCeiling()) {
            BlockPos top = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, BlockPos.containing(p.x, nearY, p.z));
            if (Math.abs(top.getY() - nearY) <= 12.0) {
                return new Vec3(p.x, top.getY(), p.z);
            }
        }
        return new Vec3(p.x, nearY, p.z);
    }

    /** Panggil rival untuk menantang pemain ini (forced = dari perintah: syarat tempat & cooldown dilewati). */
    public static boolean summon(ServerPlayer player, ShazamForm form, boolean forced) {
        if (RivalChampion.ACTIVE.contains(player.getUUID())) {
            if (!forced) {
                return false;
            }
            // perintah: rival lama untuk pemain ini disingkirkan dulu
            for (RivalChampion old : player.serverLevel().getEntitiesOfClass(RivalChampion.class,
                    player.getBoundingBox().inflate(160.0), r -> player.getUUID().equals(r.challengerId()))) {
                old.discard();
            }
            RivalChampion.ACTIVE.remove(player.getUUID());
        }
        ServerLevel level = player.serverLevel();
        RivalChampion rival = ShazamEntities.RIVAL.get().create(level);
        if (rival == null) {
            return false;
        }
        Vec3 at = spawnPoint(player, level.random);
        rival.moveTo(at.x, at.y, at.z, level.random.nextFloat() * 360f, 0f);
        rival.setup(form, player);
        if (!level.addFreshEntity(rival)) {
            RivalChampion.ACTIVE.remove(player.getUUID());
            return false;
        }
        NEXT_CHECK.put(player.getUUID(), level.getGameTime() + COOLDOWN_TICKS);
        return true;
    }

    /** Titik datang di cincin sekitar pemain: di permukaan tanah, atau melayang kalau nggak ada pijakan. */
    private static Vec3 spawnPoint(ServerPlayer player, RandomSource random) {
        ServerLevel level = player.serverLevel();
        for (int attempt = 0; attempt < 10; attempt++) {
            double angle = random.nextDouble() * Math.PI * 2.0;
            double distance = MIN_DISTANCE + random.nextDouble() * (MAX_DISTANCE - MIN_DISTANCE);
            double x = player.getX() + Math.cos(angle) * distance, z = player.getZ() + Math.sin(angle) * distance;
            if (level.dimension() != Level.NETHER && !level.dimensionType().hasCeiling()) {
                BlockPos top = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                        BlockPos.containing(x, player.getY(), z));
                if (Math.abs(top.getY() - player.getY()) <= 12.0) {
                    return new Vec3(x, top.getY(), z);
                }
                continue;
            }
            // Nether: cari lantai dengan dua blok udara di atasnya, dekat ketinggian pemain
            BlockPos column = BlockPos.containing(x, player.getY() + 5, z);
            for (int dy = 0; dy < 12; dy++) {
                BlockPos feet = column.below(dy);
                if (level.getBlockState(feet).isAir() && level.getBlockState(feet.above()).isAir()
                        && level.getBlockState(feet.below()).isSolid()) {
                    return new Vec3(x, feet.getY(), z);
                }
            }
        }
        // nggak ada pijakan yang cocok: datang melayang di dekat pemain
        Vec3 look = player.getLookAngle();
        return player.position().add(look.x * 8.0, 3.0, look.z * 8.0);
    }

    /** Hadiah saat rival kalah: jalan menuju juara itu (kalau belum punya) dan tanda kemenangan. */
    static List<ItemStack> rewards(ShazamForm form, RandomSource random) {
        List<ItemStack> out = new ArrayList<>();
        switch (form) {
            case BLACK_ADAM -> out.add(new ItemStack(AdamItems.SCARAB.get()));
            case SABBAC -> out.add(new ItemStack(SabbacItems.ETERNIUM_INGOT.get(), 3));
            case LINTANG -> out.add(new ItemStack(com.shazammod.LintangItems.STAR_CRYSTAL.get()));   // 0.46 Serum Helion-7
            case HELION -> {                                                                         // 0.46 Serum Helion-6 + Cryon
                out.add(new ItemStack(com.shazammod.HelionItems.SERUM.get()));
                out.add(new ItemStack(com.shazammod.LintangItems.KELAM_SHARD.get(), 4));
            }
            default -> {
                var totems = List.of(ShazamItems.TOTEM_SOLOMON, ShazamItems.TOTEM_HERCULES, ShazamItems.TOTEM_ATLAS,
                        ShazamItems.TOTEM_ZEUS, ShazamItems.TOTEM_ACHILLES, ShazamItems.TOTEM_MERCURY);
                out.add(new ItemStack(totems.get(random.nextInt(totems.size())).get()));
            }
        }
        return out;
    }
}
