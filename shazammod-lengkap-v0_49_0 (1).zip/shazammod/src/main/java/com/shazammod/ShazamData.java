package com.shazammod;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import net.minecraft.util.Mth;

/**
 * unlocked        = layak jadi Shazam: enam totem penjaga kuil sudah menyatu (ucapkan SHAZAM sambil membawa keenamnya),
 *                   atau lewat /shazam unlock
 * transformed     = sedang dalam wujud juara (Shazam, Black Adam, Sabbac, Lintang, Helion-6, atau Helion-3)
 * energy          = Energi Petir, 0 sampai MAX_ENERGY
 * hoodUp          = hood jubah sedang dipakai di kepala
 * knockoutUntil   = game time sampai kapan belum bisa berubah lagi, sesudah terlempar balik jadi manusia
 *                   karena serangan mematikan (0 = nggak sedang pulih)
 * form            = juara yang dipilih (lihat ShazamForm): 0 Shazam, 1 Black Adam, 2 Sabbac, 3 Lintang, 4 Helion-6, 5 Helion-3
 * adamUnlocked    = layak jadi Black Adam: lulus Ujian Kahndaq dengan Skarabe Teth-Adam (lihat KahndaqTrial), atau lewat
 *                   /shazam unlock black_adam. Jalan yang beda total dari Shazam.
 * sabbacUnlocked  = 0.30: layak jadi Sabbac: Mahkota Sabbac dari Eternium dipakai untuk Perjanjian Enam Iblis (lihat
 *                   SabbacPact), atau lewat /shazam unlock sabbac.
 * lintangUnlocked = 0.32: Eksperimen Evolusi Surya berhasil (lihat LintangRite), atau lewat /shazam unlock lintang.
 * helionUnlocked  = 0.43: Eksperimen Proyek Helion-6 berhasil (lihat HelionRite), atau lewat /shazam unlock helion.
 *                   Kolom baru di paling belakang & opsional, jadi save lama tetap terbaca (nilainya false).
 * helion3Unlocked = 0.49: Infeksi Sel Subjek Tiga berhasil (lihat Helion3Rite), atau lewat /shazam unlock helion3.
 */
public record ShazamData(boolean unlocked, boolean transformed, float energy, boolean hoodUp, long knockoutUntil, int form,
                         boolean adamUnlocked, boolean sabbacUnlocked, boolean lintangUnlocked, boolean helionUnlocked,
                         boolean helion3Unlocked) {
    public static final ShazamData DEFAULT = new ShazamData(false, false, ShazamPowers.MAX_ENERGY, true, 0L, 0, false, false,
            false, false, false);

    public static final Codec<ShazamData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.BOOL.optionalFieldOf("unlocked", false).forGetter(ShazamData::unlocked),
            Codec.BOOL.optionalFieldOf("transformed", false).forGetter(ShazamData::transformed),
            Codec.FLOAT.optionalFieldOf("energy", ShazamPowers.MAX_ENERGY).forGetter(ShazamData::energy),
            Codec.BOOL.optionalFieldOf("hood_up", true).forGetter(ShazamData::hoodUp),
            Codec.LONG.optionalFieldOf("knockout_until", 0L).forGetter(ShazamData::knockoutUntil),
            Codec.INT.optionalFieldOf("form", 0).forGetter(ShazamData::form),
            Codec.BOOL.optionalFieldOf("adam_unlocked", false).forGetter(ShazamData::adamUnlocked),
            Codec.BOOL.optionalFieldOf("sabbac_unlocked", false).forGetter(ShazamData::sabbacUnlocked),
            Codec.BOOL.optionalFieldOf("lintang_unlocked", false).forGetter(ShazamData::lintangUnlocked),
            Codec.BOOL.optionalFieldOf("helion_unlocked", false).forGetter(ShazamData::helionUnlocked),
            Codec.BOOL.optionalFieldOf("helion3_unlocked", false).forGetter(ShazamData::helion3Unlocked)
    ).apply(instance, ShazamData::new));

    public ShazamData withUnlocked(boolean value) {
        return new ShazamData(value, transformed, energy, hoodUp, knockoutUntil, form, adamUnlocked, sabbacUnlocked,
                lintangUnlocked, helionUnlocked, helion3Unlocked);
    }

    public ShazamData withAdamUnlocked(boolean value) {
        return new ShazamData(unlocked, transformed, energy, hoodUp, knockoutUntil, form, value, sabbacUnlocked,
                lintangUnlocked, helionUnlocked, helion3Unlocked);
    }

    public ShazamData withSabbacUnlocked(boolean value) {
        return new ShazamData(unlocked, transformed, energy, hoodUp, knockoutUntil, form, adamUnlocked, value,
                lintangUnlocked, helionUnlocked, helion3Unlocked);
    }

    /** 0.32 */
    public ShazamData withLintangUnlocked(boolean value) {
        return new ShazamData(unlocked, transformed, energy, hoodUp, knockoutUntil, form, adamUnlocked, sabbacUnlocked,
                value, helionUnlocked, helion3Unlocked);
    }

    /** 0.43 */
    public ShazamData withHelionUnlocked(boolean value) {
        return new ShazamData(unlocked, transformed, energy, hoodUp, knockoutUntil, form, adamUnlocked, sabbacUnlocked,
                lintangUnlocked, value, helion3Unlocked);
    }

    /** 0.49 */
    public ShazamData withHelion3Unlocked(boolean value) {
        return new ShazamData(unlocked, transformed, energy, hoodUp, knockoutUntil, form, adamUnlocked, sabbacUnlocked,
                lintangUnlocked, helionUnlocked, value);
    }

    public ShazamData withTransformed(boolean value) {
        return new ShazamData(unlocked, value, energy, hoodUp, knockoutUntil, form, adamUnlocked, sabbacUnlocked,
                lintangUnlocked, helionUnlocked, helion3Unlocked);
    }

    public ShazamData withEnergy(float value) {
        return new ShazamData(unlocked, transformed, Mth.clamp(value, 0f, ShazamPowers.MAX_ENERGY), hoodUp, knockoutUntil, form,
                adamUnlocked, sabbacUnlocked, lintangUnlocked, helionUnlocked, helion3Unlocked);
    }

    public ShazamData withHoodUp(boolean value) {
        return new ShazamData(unlocked, transformed, energy, value, knockoutUntil, form, adamUnlocked, sabbacUnlocked,
                lintangUnlocked, helionUnlocked, helion3Unlocked);
    }

    public ShazamData withKnockoutUntil(long value) {
        return new ShazamData(unlocked, transformed, energy, hoodUp, value, form, adamUnlocked, sabbacUnlocked,
                lintangUnlocked, helionUnlocked, helion3Unlocked);
    }

    public ShazamData withForm(ShazamForm value) {
        return new ShazamData(unlocked, transformed, energy, hoodUp, knockoutUntil, value.ordinal(), adamUnlocked,
                sabbacUnlocked, lintangUnlocked, helionUnlocked, helion3Unlocked);
    }

    /** Juara ini sudah didapat (lewat jalannya masing-masing). */
    public boolean has(ShazamForm champion) {
        return switch (champion) {
            case BLACK_ADAM -> adamUnlocked;
            case SABBAC -> sabbacUnlocked;
            case LINTANG -> lintangUnlocked;
            case HELION -> helionUnlocked;
            case HELION3 -> helion3Unlocked;
            default -> unlocked;
        };
    }

    /** Sudah punya paling nggak satu juara. */
    public boolean anyUnlocked() {
        return unlocked || adamUnlocked || sabbacUnlocked || lintangUnlocked || helionUnlocked || helion3Unlocked;
    }

    /** Jumlah juara yang sudah didapat. */
    public int ownedCount() {
        return (unlocked ? 1 : 0) + (adamUnlocked ? 1 : 0) + (sabbacUnlocked ? 1 : 0) + (lintangUnlocked ? 1 : 0)
                + (helionUnlocked ? 1 : 0) + (helion3Unlocked ? 1 : 0);
    }

    /** Punya paling nggak dua juara (baru boleh ganti juara dengan tombol K). */
    public boolean hasBoth() {
        return ownedCount() >= 2;
    }

    /**
     * Juara yang dipakai saat berubah. Pilihan yang belum didapat (misalnya save lama yang memilih Black Adam sebelum
     * ada Ujian Kahndaq) jatuh ke juara yang memang sudah dimiliki. Nilai tak dikenal dianggap Shazam.
     */
    public ShazamForm champion() {
        ShazamForm chosen = ShazamForm.byId(form);
        if (!has(chosen)) {
            for (ShazamForm other : ShazamForm.values()) {
                if (has(other)) {
                    return other;
                }
            }
        }
        return chosen;
    }

    /** Juara berikutnya yang sudah dimiliki (tombol K). */
    public ShazamForm nextOwned() {
        ShazamForm current = champion();
        ShazamForm next = current.next();
        while (next != current) {
            if (has(next)) {
                return next;
            }
            next = next.next();
        }
        return current;
    }

    public boolean isBlackAdam() {
        return champion() == ShazamForm.BLACK_ADAM;
    }

    public boolean isSabbac() {
        return champion() == ShazamForm.SABBAC;
    }

    /** 0.32 */
    public boolean isLintang() {
        return champion() == ShazamForm.LINTANG;
    }

    /** 0.43 */
    public boolean isHelion() {
        return champion() == ShazamForm.HELION;
    }

    /** 0.49 Subjek Tiga yang bisa dimainkan. */
    public boolean isHelion3() {
        return champion() == ShazamForm.HELION3;
    }

    public boolean isShazam() {
        return champion() == ShazamForm.SHAZAM;
    }
}
