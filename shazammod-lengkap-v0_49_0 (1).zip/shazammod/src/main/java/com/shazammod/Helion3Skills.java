package com.shazammod;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;

import com.shazammod.helion3.Helion3;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/**
 * 0.49 Subjek Tiga (Helion-3) yang bisa dimainkan: monster sel mati dari Proyek Helion. Bukan penyihir dan bukan penerbang:
 * dia petarung jarak dekat yang lambat tapi nyaris nggak bisa dibunuh. Tombol Z X C V B N R = H-E-L-I-O-N-3:
 *
 *   H - Hantam (Z)          kepalan kanan, kiri, lalu kedua kepalan menghantam tanah
 *   E - Erangan (X)         raungan: musuh terpental, melambat & melemah, proyektil di udara hancur
 *   L - Lompat (C)          melompat ke titik bidik lalu menghantam tanah (pengganti terbang)
 *   I - Inkubasi (V)        meringkuk di kepompong sel mati: damage diterima tinggal 15%, darah pulih, lalu pecah meledak
 *   O - Onak Tulang (B)     duri tulang meletus melingkar dari tanah; sesudahnya duri di badan lebih tajam
 *   N - Nyeruduk (N)        menyeruduk lurus; menabrak tembok = gelombang kejut
 *   3 - Evolusi Ketiga (R)  mengamuk: lebih besar, lebih cepat, damage naik, damage diterima turun, adaptasi 2x lebih cepat
 *   M - Serap Cryon         satu Pecahan Cryon diremukkan di dada: darah & energi pulih, cakar makin tajam (menumpuk)
 *   J - Terobos Tanah       menyelam ke tanah lalu meletus keluar di titik bidik
 *
 * Pasif:
 *   Adaptasi       tiap jenis serangan yang mengenainya makin nggak mempan (sampai ADAPT_MAX), sama seperti bosnya
 *   Bangkit Lagi   serangan mematikan nggak langsung melemparnya jadi manusia: dia tumbang, dibungkus kepompong, lalu
 *                  bangkit dan kebal total terhadap jenis serangan yang membunuhnya (LIVES kali, tumbuh lagi pelan-pelan)
 *   Duri Sel Mati  penyerang jarak dekat ikut tertusuk
 *   Tanpa terbang  lompatannya saja yang raksasa
 */
public final class Helion3Skills {
    private Helion3Skills() {}

    public enum Skill {
        HANTAM(20f, 70),      // H - Hantam (Z)
        ERANGAN(25f, 180),    // E - Erangan (X)
        LOMPAT(25f, 110),     // L - Lompat (C)
        INKUBASI(60f, 600),   // I - Inkubasi (V)
        ONAK(35f, 240),       // O - Onak Tulang (B)
        NYERUDUK(30f, 150),   // N - Nyeruduk (N)
        EVOLUSI(200f, 1500);  // 3 - Evolusi Ketiga (R)

        public final float cost;
        public final int cooldownTicks;

        Skill(float cost, int cooldownTicks) {
            this.cost = cost;
            this.cooldownTicks = cooldownTicks;
        }
    }

    // ================= Angka-angka yang gampang diutak-atik =================
    // H - Hantam
    private static final float SMASH_DAMAGE = 40f;         // tiap kepalan
    private static final double SMASH_REACH = 2.4;         // pusat hantaman di depan badan
    private static final double SMASH_RADIUS = 2.8;
    private static final float POUND_DAMAGE = 52f;
    public static final double POUND_RADIUS = 5.0;
    // E - Erangan
    private static final float ROAR_DAMAGE = 14f;
    public static final double ROAR_RADIUS = 11.0;
    private static final int ROAR_FEAR_TICKS = 100;        // Lambat & Lemah
    // L - Lompat
    private static final double LEAP_RANGE = 26.0;
    private static final float SLAM_DAMAGE = 60f;
    public static final double SLAM_RADIUS = 6.5;
    // I - Inkubasi
    private static final float COCOON_TAKEN = 0.15f;
    private static final float COCOON_HEAL = 0.5f;         // bagian darah maksimal yang pulih selama di kepompong
    private static final float COCOON_BURST_DAMAGE = 36f;
    public static final double COCOON_BURST_RADIUS = 6.0;
    // O - Onak Tulang
    private static final float SPIKE_DAMAGE = 44f;
    public static final double SPIKE_RADIUS = 7.0;
    private static final int SPIKE_THORN_TICKS = 200;      // duri di badan lebih tajam selama ini
    private static final float SPIKE_THORNS = 18f;
    private static final float THORNS = 8f;                // Duri Sel Mati (pasif)
    // N - Nyeruduk
    private static final double CHARGE_RANGE = 18.0;
    private static final double CHARGE_WIDTH = 1.7;
    private static final float CHARGE_DAMAGE = 54f;
    private static final float CRASH_DAMAGE = 36f;
    public static final double CRASH_RADIUS = 5.0;
    // 3 - Evolusi Ketiga
    public static final int RAGE_TICKS = 400;              // 20 detik
    public static final float RAGE_DAMAGE = 1.5f;
    public static final float RAGE_TAKEN = 0.6f;
    private static final double RAGE_SPEED = 0.35;
    private static final double RAGE_GROWTH = 0.2;
    private static final float RAGE_ROAR_DAMAGE = 30f;
    public static final double RAGE_ROAR_RADIUS = 9.0;
    // M - Serap Cryon
    public static final int ABSORB_COOLDOWN_TICKS = 200;
    private static final float ABSORB_HEAL = 120f;
    private static final float ABSORB_ENERGY = 250f;
    public static final int CLAW_MAX = 8;
    private static final int CLAW_GAIN = 2;
    public static final float CLAW_STEP = 0.06f;           // tiap tumpukan cakar: damage +6%
    private static final int CLAW_TICKS = 1200;            // satu tumpukan meluruh tiap menit
    // J - Terobos Tanah
    public static final int BURROW_COOLDOWN_TICKS = 300;
    private static final double BURROW_RANGE = 22.0;
    private static final float EMERGE_DAMAGE = 46f;
    public static final double EMERGE_RADIUS = 5.0;
    // Adaptasi
    public static final float ADAPT_STEP = 0.05f;          // tiap kena satu jenis serangan
    public static final float ADAPT_MAX = 0.6f;            // paling banyak 60% lebih kebal
    // Bangkit Lagi
    public static final int LIVES = 2;
    private static final float REVIVE_HEALTH = 0.6f;       // bangkit dengan 60% darah
    public static final float REVIVE_BUFF = 0.1f;          // tiap nyawa yang sudah terpakai: damage +10%
    private static final int IMMUNE_TICKS = 300;           // kebal total terhadap jenis yang membunuhnya, 15 detik
    private static final int LIFE_REGROW_TICKS = 2400;     // satu nyawa tumbuh lagi tiap 2 menit
    // Sel mati
    public static final float REGEN_PER_SECOND = 6f;       // x2 selama Evolusi Ketiga
    public static final float DRAIN_PER_SECOND = 1.2f;     // sel mati selalu lapar
    public static final float RECHARGE_PER_SECOND = 5f;    // wujud manusia
    private static final float PUNCH_ENERGY = 3f;          // tiap cakaran yang kena memberi makan sel mati
    // =========================================================================

    private static final ResourceLocation RAGE_SPEED_ID = ShazamMod.id("helion3_rage_speed");
    private static final ResourceLocation RAGE_GROWTH_ID = ShazamMod.id("helion3_rage_growth");
    private static final ResourceLocation ROOT_ID = ShazamMod.id("helion3_rooted");

    private static final Map<UUID, long[]> READY_AT = new HashMap<>();
    private static final Map<UUID, Long> ABSORB_READY_AT = new HashMap<>();
    private static final Map<UUID, Long> BURROW_READY_AT = new HashMap<>();
    private static final Map<UUID, State> STATES = new HashMap<>();

    /** Keadaan tubuh Subjek Tiga satu pemain (hilang saat keluar dari server). */
    private static final class State {
        final float[] adapt = new float[Helion3.Kind.values().length];
        int lastKind = -1;
        int lives = LIVES;
        long lifeRegrowAt;
        int claws;
        long clawDecayAt;
        long rageUntil;
        long cocoonUntil;     // Inkubasi
        long downUntil;       // tumbang + bangkit: nggak tersentuh, nggak bisa bertindak
        long burrowUntil;     // di bawah tanah
        long busyUntil;       // skill gerak sedang berjalan
        long thornUntil;      // Onak Tulang: duri lebih tajam
        long immuneUntil;
        int immuneKind = -1;
        long nextImmuneFx;
        long nextThornFx;
        long rootUntil;       // tertahan di tempat: lompatannya dimatikan (gerak mendatarnya ditahan client)
    }

    private static State state(ServerPlayer player) {
        return STATES.computeIfAbsent(player.getUUID(), id -> new State());
    }

    // ----------------------------------------------------------- Pakai skill

    public static void use(ServerPlayer player, Skill skill) {
        if (!ShazamPowers.isHelion3(player)) {
            if (ShazamPowers.data(player).anyUnlocked()) {
                player.displayClientMessage(Component.translatable("message.shazammod.subjek.not_transformed")
                        .withStyle(ChatFormatting.GRAY), true);
            }
            return;
        }
        if (cannotAct(player) || cooldownTicks(player, skill) > 0) {
            return;
        }
        if (ShazamPowers.data(player).energy() < skill.cost) {
            player.displayClientMessage(Component.translatable("message.shazammod.skill_no_energy", Math.round(skill.cost))
                    .withStyle(ChatFormatting.RED), true);
            return;
        }
        boolean used = switch (skill) {
            case HANTAM -> hantam(player);
            case ERANGAN -> erangan(player);
            case LOMPAT -> lompat(player);
            case INKUBASI -> inkubasi(player);
            case ONAK -> onak(player);
            case NYERUDUK -> nyeruduk(player);
            case EVOLUSI -> evolusi(player);
        };
        if (!used) {
            player.displayClientMessage(Component.translatable("message.shazammod.subjek.blocked").withStyle(ChatFormatting.GRAY),
                    true);
            return;
        }
        ShazamData data = ShazamPowers.data(player);
        ShazamPowers.setData(player, data.withEnergy(data.energy() - skill.cost));
        READY_AT.computeIfAbsent(player.getUUID(), id -> new long[Skill.values().length])[skill.ordinal()] =
                player.level().getGameTime() + skill.cooldownTicks;
        ShazamNetwork.sync(player);
    }

    public static int cooldownTicks(ServerPlayer player, Skill skill) {
        long[] readyAt = READY_AT.get(player.getUUID());
        if (readyAt == null) {
            return 0;
        }
        long left = readyAt[skill.ordinal()] - player.level().getGameTime();
        return left > 0 ? (int) left : 0;
    }

    public static int absorbCooldownTicks(ServerPlayer player) {
        return left(ABSORB_READY_AT.get(player.getUUID()), player);
    }

    public static int burrowCooldownTicks(ServerPlayer player) {
        return left(BURROW_READY_AT.get(player.getUUID()), player);
    }

    private static int left(Long ready, ServerPlayer player) {
        if (ready == null) {
            return 0;
        }
        long left = ready - player.level().getGameTime();
        return left > 0 ? (int) left : 0;
    }

    /** Efek dijalankan beberapa tick lagi, dan dibatalkan kalau pemain keburu balik jadi manusia. */
    private static void later(ServerPlayer player, int delay, Consumer<ServerPlayer> action) {
        ShazamPowers.schedule(player, delay, p -> {
            if (ShazamPowers.isHelion3(p)) {
                action.accept(p);
            }
        });
    }

    /** Sedang tumbang, di kepompong, di bawah tanah, atau di tengah skill gerak: belum bisa memakai skill lain. */
    private static boolean cannotAct(ServerPlayer player) {
        State s = STATES.get(player.getUUID());
        if (s == null) {
            return false;
        }
        long now = player.level().getGameTime();
        return now < s.downUntil || now < s.cocoonUntil || now < s.burrowUntil || now < s.busyUntil;
    }

    private static void busy(ServerPlayer player, int ticks) {
        state(player).busyUntil = player.level().getGameTime() + ticks;
    }

    /** Tertahan di tempat selama ticks (kepompong, tumbang, mengumpulkan amukan): lompatannya dimatikan. */
    private static void root(ServerPlayer player, int ticks) {
        State s = state(player);
        s.rootUntil = Math.max(s.rootUntil, player.level().getGameTime() + ticks);
        AttributeInstance jump = player.getAttribute(Attributes.JUMP_STRENGTH);
        if (jump != null && !jump.hasModifier(ROOT_ID)) {
            jump.addTransientModifier(new AttributeModifier(ROOT_ID, -1.0, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        }
    }

    private static void unroot(ServerPlayer player, State s) {
        s.rootUntil = 0L;
        AttributeInstance jump = player.getAttribute(Attributes.JUMP_STRENGTH);
        if (jump != null) {
            jump.removeModifier(ROOT_ID);
        }
    }

    // ----------------------------------------------------------- Angka buat HUD & ShazamPowers

    /** Pengali damage semua serangannya: cakar Cryon, nyawa yang sudah terpakai, dan Evolusi Ketiga. */
    public static float power(ServerPlayer player) {
        State s = STATES.get(player.getUUID());
        if (s == null) {
            return 1f;
        }
        float k = (1f + CLAW_STEP * s.claws) * (1f + REVIVE_BUFF * Math.max(0, LIVES - s.lives));
        return player.level().getGameTime() < s.rageUntil ? k * RAGE_DAMAGE : k;
    }

    public static float punchMultiplier(ServerPlayer attacker) {
        return ShazamPowers.HELION3_PUNCH_MULTIPLIER * power(attacker);
    }

    public static float regenPerSecond(ServerPlayer player) {
        return isRageActive(player) ? REGEN_PER_SECOND * 2f : REGEN_PER_SECOND;
    }

    public static float energyPerSecond(ServerPlayer player, boolean transformed) {
        return transformed ? -DRAIN_PER_SECOND : RECHARGE_PER_SECOND;
    }

    public static boolean isRageActive(ServerPlayer player) {
        State s = STATES.get(player.getUUID());
        return s != null && ShazamPowers.isHelion3(player) && player.level().getGameTime() < s.rageUntil;
    }

    public static int rageTicks(ServerPlayer player) {
        State s = STATES.get(player.getUUID());
        if (s == null) {
            return 0;
        }
        long left = s.rageUntil - player.level().getGameTime();
        return left > 0 ? (int) left : 0;
    }

    public static int livesLeft(ServerPlayer player) {
        State s = state(player);
        regrow(s, player.level().getGameTime());
        return s.lives;
    }

    public static int claws(ServerPlayer player) {
        State s = STATES.get(player.getUUID());
        return s == null ? 0 : s.claws;
    }

    /** Jenis serangan yang terakhir diadaptasi (urutan Helion3.Kind + 1; 0 = belum ada). */
    public static int adaptKind(ServerPlayer player) {
        State s = STATES.get(player.getUUID());
        return s == null ? 0 : s.lastKind + 1;
    }

    public static int adaptPercent(ServerPlayer player) {
        State s = STATES.get(player.getUUID());
        if (s == null || s.lastKind < 0) {
            return 0;
        }
        return Math.round(s.adapt[s.lastKind] / ADAPT_MAX * 100f);
    }

    public static int immuneTicks(ServerPlayer player) {
        State s = STATES.get(player.getUUID());
        if (s == null || s.immuneKind < 0) {
            return 0;
        }
        long left = s.immuneUntil - player.level().getGameTime();
        return left > 0 ? (int) left : 0;
    }

    /** Tumbang / bangkit / di bawah tanah: nggak ada serangan yang sampai. */
    public static boolean untouchable(ServerPlayer player) {
        State s = STATES.get(player.getUUID());
        if (s == null) {
            return false;
        }
        long now = player.level().getGameTime();
        return now < s.downUntil || now < s.burrowUntil;
    }

    private static void regrow(State s, long now) {
        if (s.lives >= LIVES) {
            return;
        }
        while (s.lives < LIVES && now >= s.lifeRegrowAt) {
            s.lives++;
            s.lifeRegrowAt += LIFE_REGROW_TICKS;
        }
    }

    // ----------------------------------------------------------- Tiap tick

    public static void tick(ServerPlayer player) {
        State s = state(player);
        long now = player.level().getGameTime();
        int before = s.lives;
        regrow(s, now);
        if (s.lives > before) {
            player.displayClientMessage(Component.translatable("message.shazammod.subjek.life_back", s.lives, LIVES)
                    .withStyle(ChatFormatting.LIGHT_PURPLE), true);
        }
        if (s.rageUntil != 0L && now >= s.rageUntil) {
            endRage(player, s);
            ShazamNetwork.playAnim(player, ShazamAnim.SUBJEK_RAGE_END, player.position());
            player.displayClientMessage(Component.translatable("message.shazammod.subjek.rage_end")
                    .withStyle(ChatFormatting.GRAY), true);
            ShazamNetwork.broadcastState(player);
        }
        if (now < s.cocoonUntil && player.tickCount % 10 == 0 && player.getHealth() < player.getMaxHealth()) {
            float perStep = player.getMaxHealth() * COCOON_HEAL / (ShazamAnim.SUBJEK_COCOON_TICKS / 10f);
            player.heal(perStep * ShazamPowers.healScale(player));
        }
        if (s.claws > 0 && now >= s.clawDecayAt) {
            s.claws--;
            s.clawDecayAt = now + CLAW_TICKS;
        }
        if (s.immuneKind >= 0 && now >= s.immuneUntil) {
            s.immuneKind = -1;
        }
        if (s.rootUntil != 0L && now >= s.rootUntil) {
            unroot(player, s);
        }
        // tanpa terbang: sel mati terlalu berat (lompatannya saja yang raksasa)
        if (!player.isCreative() && !player.isSpectator()
                && (player.getAbilities().mayfly || player.getAbilities().flying)) {
            player.getAbilities().flying = false;
            player.getAbilities().mayfly = false;
            player.onUpdateAbilities();
        }
        ShazamPassives.tick(player);   // Regenerasi Sel Mati tiap 2 detik, Cakar Maut, Hati Pahlawan
    }

    /** Hentikan skill yang sedang berjalan (balik jadi manusia, respawn). Cooldown & nyawa cadangan tetap. */
    public static void cancelActive(ServerPlayer player) {
        State s = STATES.get(player.getUUID());
        if (s == null) {
            return;
        }
        endRage(player, s);
        unroot(player, s);
        Arrays.fill(s.adapt, 0f);
        s.lastKind = -1;
        s.claws = 0;
        s.cocoonUntil = 0L;
        s.downUntil = 0L;
        s.burrowUntil = 0L;
        s.busyUntil = 0L;
        s.thornUntil = 0L;
        s.immuneUntil = 0L;
        s.immuneKind = -1;
    }

    public static void forget(UUID id) {
        READY_AT.remove(id);
        ABSORB_READY_AT.remove(id);
        BURROW_READY_AT.remove(id);
        STATES.remove(id);
    }

    // ----------------------------------------------------------- Alat bantu

    private static List<LivingEntity> enemies(ServerPlayer player, Vec3 center, double radius) {
        return player.serverLevel().getEntitiesOfClass(LivingEntity.class, new AABB(center, center).inflate(radius),
                m -> m.isAlive() && m instanceof Enemy && !DemonSoldier.isFriendly(m)
                        && m.distanceToSqr(center) <= radius * radius);
    }

    private static void sound(ServerPlayer player, Vec3 at, SoundEvent sound, float volume, float pitch) {
        player.serverLevel().playSound(null, at.x, at.y, at.z, sound, SoundSource.PLAYERS, volume, pitch);
    }

    private static Vec3 flat(Vec3 v) {
        Vec3 f = new Vec3(v.x, 0, v.z);
        return f.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : f.normalize();
    }

    private static Vec3 away(Vec3 center, LivingEntity entity) {
        Vec3 a = new Vec3(entity.getX() - center.x, 0, entity.getZ() - center.z);
        return a.lengthSqr() < 1.0E-4 ? Vec3.ZERO : a.normalize();
    }

    private static Vec3 chest(LivingEntity entity) {
        return entity.position().add(0, entity.getBbHeight() * 0.55, 0);
    }

    /** Jarak titik p ke ruas garis a-b. */
    private static double segmentDistance(Vec3 p, Vec3 a, Vec3 b) {
        Vec3 ab = b.subtract(a);
        double len2 = ab.lengthSqr();
        double t = len2 < 1.0E-8 ? 0.0 : Mth.clamp(p.subtract(a).dot(ab) / len2, 0.0, 1.0);
        return p.distanceTo(a.add(ab.scale(t)));
    }

    /** Gelombang kejut melingkar: damage penuh di tengah, turun sampai 40% di tepi. Mengembalikan jumlah yang kena. */
    private static int shock(ServerPlayer player, Vec3 c, double radius, float damage, double push, double lift) {
        float power = power(player);
        DamageSource source = ShazamPowers.forceSource(player);
        int hits = 0;
        for (LivingEntity m : enemies(player, c, radius)) {
            double d = Math.sqrt(m.distanceToSqr(c));
            float k = (float) Mth.clamp(1.25 - d / radius, 0.4, 1.0);
            m.invulnerableTime = 0;
            m.hurt(source, damage * power * k);
            Vec3 a = away(c, m);
            m.push(a.x * push * k, lift * k, a.z * push * k);
            m.hurtMarked = true;
            hits++;
        }
        return hits;
    }

    /** Titik di tanah di bawah p (paling jauh 24 blok ke bawah); p sendiri kalau nggak ada tanah. */
    private static Vec3 ground(ServerPlayer player, Vec3 p) {
        BlockHitResult down = player.serverLevel().clip(new ClipContext(p, p.add(0, -24.0, 0), ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, player));
        return down.getType() == HitResult.Type.MISS ? p : down.getLocation();
    }

    /** Titik yang dibidik (blok pertama yang kena, mundur sedikit), dijatuhkan ke tanah. */
    private static Vec3 aimPoint(ServerPlayer player, double range) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getViewVector(1f).normalize();
        BlockHitResult hit = player.serverLevel().clip(new ClipContext(eye, eye.add(look.scale(range)),
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        Vec3 aim = hit.getType() == HitResult.Type.MISS ? eye.add(look.scale(range))
                : hit.getLocation().subtract(look.scale(0.7));
        return ground(player, aim.add(0, 0.4, 0));
    }

    // ----------------------------------------------------------- H - Hantam

    private static boolean hantam(ServerPlayer player) {
        ShazamNetwork.playAnim(player, ShazamAnim.SUBJEK_SMASH);
        busy(player, ShazamAnim.SUBJEK_SMASH_POUND + 2);
        later(player, ShazamAnim.SUBJEK_SMASH_HIT1, p -> smashHit(p, 1.0));
        later(player, ShazamAnim.SUBJEK_SMASH_HIT2, p -> smashHit(p, -1.0));
        later(player, ShazamAnim.SUBJEK_SMASH_POUND, Helion3Skills::pound);
        return true;
    }

    private static void smashHit(ServerPlayer player, double side) {
        Vec3 dir = flat(player.getViewVector(1f));
        Vec3 front = player.position().add(dir.scale(SMASH_REACH)).add(0, 1.0, 0);
        float power = power(player);
        DamageSource source = ShazamPowers.forceSource(player);
        boolean any = false;
        for (LivingEntity m : enemies(player, front, SMASH_RADIUS)) {
            m.invulnerableTime = 0;
            m.hurt(source, SMASH_DAMAGE * power);
            m.push(dir.x * 0.9 - dir.z * 0.5 * side, 0.3, dir.z * 0.9 + dir.x * 0.5 * side);
            m.hurtMarked = true;
            ShazamNetwork.playAnim(player, ShazamAnim.SUBJEK_HIT, chest(m));
            any = true;
        }
        if (any) {
            sound(player, front, ShazamSounds.HELION3_SMASH.get(), 1.8f, 0.95f + player.getRandom().nextFloat() * 0.15f);
        } else {
            sound(player, front, ShazamSounds.WHOOSH_HEAVY.get(), 1.0f, ShazamSounds.tune(0.7f));
        }
    }

    private static void pound(ServerPlayer player) {
        Vec3 dir = flat(player.getViewVector(1f));
        Vec3 c = ground(player, player.position().add(dir.scale(1.6)).add(0, 0.6, 0));
        ShazamNetwork.playAnim(player, ShazamAnim.SUBJEK_POUND, c);
        sound(player, c, ShazamSounds.HELION3_SLAM.get(), 2.4f, 1.15f);
        shock(player, c, POUND_RADIUS, POUND_DAMAGE, 1.1, 0.7);
    }

    // ----------------------------------------------------------- E - Erangan

    private static boolean erangan(ServerPlayer player) {
        ShazamNetwork.playAnim(player, ShazamAnim.SUBJEK_ROAR);
        sound(player, player.position(), ShazamSounds.HELION3_ROAR.get(), 3.0f, 1.05f + player.getRandom().nextFloat() * 0.1f);
        later(player, ShazamAnim.SUBJEK_ROAR_HIT, p -> roarBlast(p, ROAR_RADIUS, ROAR_DAMAGE));
        return true;
    }

    /** Gelombang raungan: musuh terpental, melambat & melemah, lupa sasarannya; proyektil di udara hancur. */
    private static void roarBlast(ServerPlayer player, double radius, float damage) {
        Vec3 c = player.position();
        float power = power(player);
        DamageSource source = ShazamPowers.forceSource(player);
        for (LivingEntity m : enemies(player, c, radius)) {
            m.hurt(source, damage * power);
            Vec3 a = away(c, m);
            m.push(a.x * 1.5, 0.45, a.z * 1.5);
            m.hurtMarked = true;
            m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, ROAR_FEAR_TICKS, 2), player);
            m.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, ROAR_FEAR_TICKS, 1), player);
            if (m instanceof Mob mob) {
                mob.getNavigation().stop();
                mob.setTarget(null);
            }
        }
        for (Projectile shot : player.serverLevel().getEntitiesOfClass(Projectile.class, new AABB(c, c).inflate(radius),
                e -> e.getOwner() != player)) {
            shot.discard();
        }
    }

    // ----------------------------------------------------------- L - Lompat

    private static boolean lompat(ServerPlayer player) {
        Vec3 land = aimPoint(player, LEAP_RANGE);
        if (player.distanceToSqr(land) < 9.0) {
            return false;   // terlalu dekat: nggak ada yang bisa dilompati
        }
        ShazamNetwork.playAnim(player, ShazamAnim.SUBJEK_LEAP, land);
        sound(player, player.position(), ShazamSounds.HELION3_STEP.get(), 2.0f, 0.7f);
        busy(player, ShazamAnim.SUBJEK_LEAP_WINDUP + ShazamAnim.SUBJEK_LEAP_TICKS + 2);
        later(player, ShazamAnim.SUBJEK_LEAP_WINDUP + ShazamAnim.SUBJEK_LEAP_TICKS, p -> slam(p, land));
        return true;
    }

    private static void slam(ServerPlayer player, Vec3 land) {
        // badannya digerakkan client; kalau dia tersangkut di jalan, hantamannya tetap di tempat dia benar-benar mendarat
        Vec3 c = player.distanceToSqr(land) < 49.0 ? player.position() : land;
        player.fallDistance = 0f;
        ShazamNetwork.playAnim(player, ShazamAnim.SUBJEK_SLAM, c);
        sound(player, c, ShazamSounds.HELION3_SLAM.get(), 3.0f, 1f);
        shock(player, c, SLAM_RADIUS, SLAM_DAMAGE, 1.5, 0.85);
    }

    // ----------------------------------------------------------- I - Inkubasi

    private static boolean inkubasi(ServerPlayer player) {
        State s = state(player);
        s.cocoonUntil = player.level().getGameTime() + ShazamAnim.SUBJEK_COCOON_TICKS;
        root(player, ShazamAnim.SUBJEK_COCOON_TICKS);
        ShazamNetwork.playAnim(player, ShazamAnim.SUBJEK_COCOON);
        // suara bangkit bosnya (meledak di tick 62) cuma dipercepat sedikit supaya pas dengan kepompong 60 tick
        sound(player, player.position(), ShazamSounds.HELION3_REVIVE.get(), 2.2f, 62f / ShazamAnim.SUBJEK_COCOON_TICKS);
        later(player, ShazamAnim.SUBJEK_COCOON_TICKS, Helion3Skills::cocoonBurst);
        return true;
    }

    private static void cocoonBurst(ServerPlayer player) {
        state(player).cocoonUntil = 0L;
        Vec3 c = player.position();
        ShazamNetwork.playAnim(player, ShazamAnim.SUBJEK_BURST, c);
        sound(player, c, ShazamSounds.HELION3_SMASH.get(), 2.2f, 0.8f);
        shock(player, c, COCOON_BURST_RADIUS, COCOON_BURST_DAMAGE, 1.6, 0.6);
    }

    // ----------------------------------------------------------- O - Onak Tulang

    private static boolean onak(ServerPlayer player) {
        ShazamNetwork.playAnim(player, ShazamAnim.SUBJEK_SPIKES, player.position());
        sound(player, player.position(), ShazamSounds.HELION3_ADAPT.get(), 1.8f, 0.8f);
        busy(player, ShazamAnim.SUBJEK_SPIKES_WINDUP + 2);
        later(player, ShazamAnim.SUBJEK_SPIKES_WINDUP, p -> {
            Vec3 c = p.position();
            float power = power(p);
            DamageSource source = ShazamPowers.forceSource(p);
            for (LivingEntity m : enemies(p, c, SPIKE_RADIUS)) {
                if (Math.abs(m.getY() - c.y) > 3.5) {
                    continue;   // duri tumbuh dari tanah: yang terbang tinggi nggak kena
                }
                m.invulnerableTime = 0;
                m.hurt(source, SPIKE_DAMAGE * power);
                m.push(0, 0.75, 0);   // tertusuk & terangkat
                m.hurtMarked = true;
                m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 3), p);
            }
            state(p).thornUntil = p.level().getGameTime() + SPIKE_THORN_TICKS;
            sound(p, c, ShazamSounds.EARTH_CRACK.get(), 2.0f, ShazamSounds.tune(0.8f));
            sound(p, c, ShazamSounds.HELION3_SMASH.get(), 1.6f, 1.3f);
        });
        return true;
    }

    // ----------------------------------------------------------- N - Nyeruduk

    private static boolean nyeruduk(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        Vec3 dir = flat(player.getViewVector(1f));
        Vec3 start = player.position();
        Vec3 from = start.add(0, 1.1, 0);
        BlockHitResult hit = level.clip(new ClipContext(from, from.add(dir.scale(CHARGE_RANGE)), ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, player));
        boolean wall = hit.getType() != HitResult.Type.MISS;
        double dist = wall ? Math.max(0.0, hit.getLocation().distanceTo(from) - 1.0) : CHARGE_RANGE;
        if (dist < 2.0) {
            return false;   // terhalang dinding
        }
        Vec3 end = start.add(dir.scale(dist));
        ShazamNetwork.playAnim(player, ShazamAnim.SUBJEK_CHARGE, end);
        sound(player, start, ShazamSounds.HELION3_CHARGE.get(), 2.6f, 1.15f);
        int run = ShazamAnim.SUBJEK_CHARGE_WINDUP + ShazamAnim.SUBJEK_CHARGE_TICKS;
        busy(player, run + 2);
        later(player, ShazamAnim.SUBJEK_CHARGE_WINDUP + ShazamAnim.SUBJEK_CHARGE_TICKS / 2, p -> chargeHit(p, start, end, dir));
        later(player, run, p -> chargeEnd(p, end, wall));
        return true;
    }

    private static void chargeHit(ServerPlayer player, Vec3 a, Vec3 b, Vec3 dir) {
        float power = power(player);
        DamageSource source = ShazamPowers.forceSource(player);
        Vec3 a1 = a.add(0, 1.0, 0), b1 = b.add(0, 1.0, 0);
        AABB box = new AABB(a1, b1).inflate(CHARGE_WIDTH + 1.5);
        boolean any = false;
        for (LivingEntity m : player.serverLevel().getEntitiesOfClass(LivingEntity.class, box,
                e -> e.isAlive() && e instanceof Enemy && !DemonSoldier.isFriendly(e))) {
            Vec3 c = chest(m);
            if (segmentDistance(c, a1, b1) > CHARGE_WIDTH + m.getBbWidth() * 0.5) {
                continue;
            }
            m.invulnerableTime = 0;
            m.hurt(source, CHARGE_DAMAGE * power);
            m.push(dir.x * 2.0, 0.55, dir.z * 2.0);   // terbawa serudukan
            m.hurtMarked = true;
            ShazamNetwork.playAnim(player, ShazamAnim.SUBJEK_HIT, c);
            any = true;
        }
        if (any) {
            sound(player, player.position(), ShazamSounds.HELION3_SMASH.get(), 2.0f, 1f);
        }
    }

    private static void chargeEnd(ServerPlayer player, Vec3 end, boolean wall) {
        Vec3 c = player.distanceToSqr(end) < 36.0 ? player.position() : end;
        if (wall) {   // menabrak tembok: gelombang kejut
            ShazamNetwork.playAnim(player, ShazamAnim.SUBJEK_CRASH, c);
            sound(player, c, ShazamSounds.HELION3_SLAM.get(), 3.0f, 1.2f);
            shock(player, c, CRASH_RADIUS, CRASH_DAMAGE, 1.3, 0.6);
        } else {
            sound(player, c, ShazamSounds.HELION3_STEP.get(), 2.0f, 0.8f);
        }
    }

    // ----------------------------------------------------------- 3 - Evolusi Ketiga

    private static boolean evolusi(ServerPlayer player) {
        ShazamNetwork.playAnim(player, ShazamAnim.SUBJEK_RAGE);
        sound(player, player.position(), ShazamSounds.HELION3_ADAPT.get(), 2.4f, 0.7f);
        sound(player, player.position(), ShazamSounds.HEARTBEAT.get(), 2.0f, ShazamSounds.tune(0.8f));
        busy(player, ShazamAnim.SUBJEK_RAGE_WINDUP + 4);
        root(player, ShazamAnim.SUBJEK_RAGE_WINDUP);
        // raungannya dimulai lebih dulu supaya gelombangnya (tick ROAR_HIT di suaranya) pas dengan ledakan amukan
        later(player, Math.max(0, ShazamAnim.SUBJEK_RAGE_WINDUP - ShazamAnim.SUBJEK_ROAR_HIT),
                p -> sound(p, p.position(), ShazamSounds.HELION3_ROAR.get(), 4.0f, 0.85f));
        later(player, ShazamAnim.SUBJEK_RAGE_WINDUP, p -> {
            State s = state(p);
            s.rageUntil = p.level().getGameTime() + RAGE_TICKS;
            AttributeInstance speed = p.getAttribute(Attributes.MOVEMENT_SPEED);
            if (speed != null && !speed.hasModifier(RAGE_SPEED_ID)) {
                speed.addTransientModifier(new AttributeModifier(RAGE_SPEED_ID, RAGE_SPEED,
                        AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
            }
            AttributeInstance scale = p.getAttribute(Attributes.SCALE);
            if (scale != null && !scale.hasModifier(RAGE_GROWTH_ID)) {
                scale.addTransientModifier(new AttributeModifier(RAGE_GROWTH_ID, RAGE_GROWTH,
                        AttributeModifier.Operation.ADD_VALUE));
            }
            roarBlast(p, RAGE_ROAR_RADIUS, RAGE_ROAR_DAMAGE);
            p.displayClientMessage(Component.translatable("message.shazammod.subjek.rage")
                    .withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD), true);
            ShazamNetwork.broadcastState(p);
            ShazamNetwork.sync(p);
        });
        return true;
    }

    private static void endRage(ServerPlayer player, State s) {
        s.rageUntil = 0L;
        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null) {
            speed.removeModifier(RAGE_SPEED_ID);
        }
        AttributeInstance scale = player.getAttribute(Attributes.SCALE);
        if (scale != null) {
            scale.removeModifier(RAGE_GROWTH_ID);
        }
    }

    // ----------------------------------------------------------- M - Serap Cryon

    public static void absorb(ServerPlayer player) {
        if (!ShazamPowers.isHelion3(player)) {
            player.displayClientMessage(Component.translatable("message.shazammod.subjek.not_transformed")
                    .withStyle(ChatFormatting.GRAY), true);
            return;
        }
        if (absorbCooldownTicks(player) > 0 || cannotAct(player)) {
            return;
        }
        if (!player.isCreative() && !hasCryon(player)) {
            player.displayClientMessage(Component.translatable("message.shazammod.subjek.need_cryon")
                    .withStyle(ChatFormatting.GRAY), true);
            return;
        }
        ABSORB_READY_AT.put(player.getUUID(), player.level().getGameTime() + ABSORB_COOLDOWN_TICKS);
        ShazamNetwork.playAnim(player, ShazamAnim.SUBJEK_ABSORB);
        later(player, ShazamAnim.SUBJEK_ABSORB_WINDUP, p -> {
            if (!p.isCreative() && !consumeCryon(p)) {
                return;
            }
            State s = state(p);
            long now = p.level().getGameTime();
            ShazamData d = ShazamPowers.data(p);
            ShazamPowers.setData(p, d.withEnergy(Math.min(ShazamPowers.MAX_ENERGY, d.energy() + ABSORB_ENERGY)));
            p.heal(ABSORB_HEAL * ShazamPowers.healScale(p));
            s.claws = Math.min(CLAW_MAX, s.claws + CLAW_GAIN);
            s.clawDecayAt = now + CLAW_TICKS;
            int cryon = Helion3.Kind.CRYON.ordinal();
            s.adapt[cryon] = ADAPT_MAX;   // radiasi yang sudah dimakannya nggak lagi melukai
            s.lastKind = cryon;
            sound(p, chest(p), ShazamSounds.HELION3_ABSORB.get(), 1.8f, 1f);
            p.displayClientMessage(Component.translatable("message.shazammod.subjek.claws", s.claws, CLAW_MAX)
                    .withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD), true);
            ShazamNetwork.sync(p);
        });
        ShazamNetwork.sync(player);
    }

    private static boolean hasCryon(ServerPlayer player) {
        Inventory inventory = player.getInventory();
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack stack = inventory.getItem(i);
            if (!stack.isEmpty() && (stack.is(LintangItems.KELAM_SHARD.get()) || LintangSkills.isKelam(stack))) {
                return true;
            }
        }
        return false;
    }

    /** Pecahan Cryon dulu; kalau nggak ada, bijih / bongkahannya. */
    private static boolean consumeCryon(ServerPlayer player) {
        Inventory inventory = player.getInventory();
        int ore = -1;
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack stack = inventory.getItem(i);
            if (stack.isEmpty()) {
                continue;
            }
            if (stack.is(LintangItems.KELAM_SHARD.get())) {
                stack.shrink(1);
                return true;
            }
            if (ore < 0 && LintangSkills.isKelam(stack)) {
                ore = i;
            }
        }
        if (ore >= 0) {
            inventory.getItem(ore).shrink(1);
            return true;
        }
        return false;
    }

    // ----------------------------------------------------------- J - Terobos Tanah

    public static void burrow(ServerPlayer player) {
        if (!ShazamPowers.isHelion3(player)) {
            player.displayClientMessage(Component.translatable("message.shazammod.subjek.not_transformed")
                    .withStyle(ChatFormatting.GRAY), true);
            return;
        }
        if (burrowCooldownTicks(player) > 0 || cannotAct(player)) {
            return;
        }
        if (!player.onGround()) {
            player.displayClientMessage(Component.translatable("message.shazammod.subjek.need_ground")
                    .withStyle(ChatFormatting.GRAY), true);
            return;
        }
        Vec3 out = aimPoint(player, BURROW_RANGE);
        if (player.distanceToSqr(out) < 9.0) {
            player.displayClientMessage(Component.translatable("message.shazammod.subjek.blocked").withStyle(ChatFormatting.GRAY),
                    true);
            return;
        }
        long now = player.level().getGameTime();
        int total = ShazamAnim.SUBJEK_BURROW_DIVE + ShazamAnim.SUBJEK_BURROW_TICKS;
        State s = state(player);
        s.burrowUntil = now + total;
        s.busyUntil = now + total + 4;
        root(player, total);
        BURROW_READY_AT.put(player.getUUID(), now + BURROW_COOLDOWN_TICKS);
        ShazamNetwork.playAnim(player, ShazamAnim.SUBJEK_BURROW, out);
        sound(player, player.position(), ShazamSounds.EARTH_CRACK.get(), 2.0f, ShazamSounds.tune(0.7f));
        later(player, total, p -> {
            p.teleportTo(out.x, out.y, out.z);
            p.fallDistance = 0f;
            state(p).burrowUntil = 0L;
            ShazamNetwork.playAnim(p, ShazamAnim.SUBJEK_EMERGE, out);
            sound(p, out, ShazamSounds.HELION3_SLAM.get(), 3.0f, 1.1f);
            shock(p, out, EMERGE_RADIUS, EMERGE_DAMAGE, 0.9, 1.1);   // yang berdiri di atasnya terlempar ke atas
        });
        ShazamNetwork.sync(player);
    }

    // ----------------------------------------------------------- Berubah wujud & cakaran

    /** Kepompong sel mati pecah saat berubah wujud: serpihannya menghantam monster di sekitar. */
    public static void transformBurst(ServerPlayer caster, Vec3 pos, float damage, double radius) {
        ServerLevel level = caster.serverLevel();
        level.playSound(null, pos.x, pos.y, pos.z, ShazamSounds.HELION3_SMASH.get(), SoundSource.PLAYERS, 3.0f, 0.75f);
        State s = state(caster);
        regrow(s, level.getGameTime());
        if (damage <= 0f) {
            return;
        }
        DamageSource source = ShazamPowers.forceSource(caster);
        for (LivingEntity target : enemies(caster, pos, radius)) {
            target.hurt(source, damage);
            Vec3 a = away(pos, target);
            target.push(a.x * 1.7, 0.5, a.z * 1.7);
            target.hurtMarked = true;
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 1), caster);
        }
    }

    /** Cakaran tangan kosong mengenai (dipanggil di tengah event damage-nya): serpihan sel mati, sel mati ikut makan. */
    public static void onPunch(ServerPlayer attacker, LivingEntity hit) {
        Vec3 at = hit.position().add(0, hit.getBbHeight() * 0.6, 0);
        ShazamNetwork.playAnim(attacker, ShazamAnim.SUBJEK_PUNCH, at);
        sound(attacker, at, ShazamSounds.HELION3_SMASH.get(), 0.9f, 1.25f + attacker.getRandom().nextFloat() * 0.2f);
        ShazamData d = ShazamPowers.data(attacker);
        if (d.energy() < ShazamPowers.MAX_ENERGY) {
            ShazamPowers.setData(attacker, d.withEnergy(Math.min(ShazamPowers.MAX_ENERGY, d.energy() + PUNCH_ENERGY)));
        }
    }

    /**
     * Cakar Maut (muatan penuh, padanan Pukulan Guntur; damage-nya sudah dikali di event yang sama): sasaran terlempar jauh
     * dan musuh di sekitarnya terhempas gelombang hantamannya.
     */
    public static void rendPunch(ServerPlayer player, LivingEntity target) {
        Vec3 at = target.position().add(0, target.getBbHeight() * 0.6, 0);
        ShazamNetwork.playAnim(player, ShazamAnim.SUBJEK_POUND, target.position());
        sound(player, at, ShazamSounds.HELION3_SLAM.get(), 2.2f, 1.3f);
        ShazamPowers.schedule(player, 1, p -> {
            if (target.isAlive()) {
                Vec3 dir = new Vec3(target.getX() - p.getX(), 0, target.getZ() - p.getZ());
                dir = dir.lengthSqr() < 1.0E-4 ? Vec3.ZERO : dir.normalize();
                target.push(dir.x * 2.4, 0.6, dir.z * 2.4);
                target.hurtMarked = true;
            }
            DamageSource source = ShazamPowers.forceSource(p);
            for (LivingEntity m : enemies(p, target.position(), 5.0)) {
                if (m == target) {
                    continue;
                }
                m.hurt(source, 18f * power(p));
                Vec3 a = away(target.position(), m);
                m.push(a.x * 1.2, 0.4, a.z * 1.2);
                m.hurtMarked = true;
            }
        });
    }

    // ----------------------------------------------------------- Adaptasi & Duri Sel Mati

    /**
     * Serangan yang masuk (sesudah tahan banting dasarnya dihitung): makin sering kena satu jenis serangan, makin nggak
     * mempan. true = serangannya dibatalkan (kebal total sesudah Bangkit Lagi).
     */
    public static boolean onIncoming(ServerPlayer victim, DamageSource source, LivingIncomingDamageEvent event) {
        if (source.is(DamageTypeTags.BYPASSES_RESISTANCE)) {
            return false;
        }
        State s = state(victim);
        long now = victim.level().getGameTime();
        boolean rage = now < s.rageUntil;
        Helion3.Kind kind = Helion3.kindOf(source);
        float k = 1f;
        if (kind != null) {
            int i = kind.ordinal();
            if (s.immuneKind == i && now < s.immuneUntil) {
                if (now >= s.nextImmuneFx) {
                    s.nextImmuneFx = now + 8;
                    ShazamNetwork.playAnim(victim, ShazamAnim.SUBJEK_IMMUNE, new Vec3(i, 0, 0));
                }
                return true;
            }
            k *= 1f - s.adapt[i];
            float before = s.adapt[i];
            s.adapt[i] = Math.min(ADAPT_MAX, before + (rage ? ADAPT_STEP * 2f : ADAPT_STEP));
            s.lastKind = i;
            if (before < ADAPT_MAX && s.adapt[i] >= ADAPT_MAX) {
                adapted(victim, kind, false);
            }
        }
        if (now < s.cocoonUntil) {
            k *= COCOON_TAKEN;
        }
        if (rage) {
            k *= RAGE_TAKEN;
        }
        event.setAmount(event.getAmount() * k);
        Entity attacker = source.getEntity();
        if (attacker instanceof LivingEntity att && att != victim && att.isAlive() && source.getDirectEntity() == attacker
                && att.distanceToSqr(victim) < 30.0) {
            // Duri Sel Mati menusuk penyerang jarak dekat
            reflect(att, victim.damageSources().thorns(victim), (now < s.thornUntil ? SPIKE_THORNS : THORNS) * power(victim));
            if (now >= s.nextThornFx) {
                s.nextThornFx = now + 6;
                ShazamNetwork.playAnim(victim, ShazamAnim.SUBJEK_THORN, chest(att));
            }
        }
        return false;
    }

    /** Sedang ada duri yang menusuk balik (lihat reflect). */
    private static boolean reflecting;

    /**
     * Duri menusuk balik penyerangnya. Tusukan duri nggak boleh memicu duri lawannya lagi: dua Subjek Tiga yang saling
     * pukul (pemain lawan bosnya, atau dua pemain) bakal saling menusuk balik tanpa akhir. Dipakai juga oleh bosnya.
     */
    public static void reflect(LivingEntity attacker, DamageSource thorns, float amount) {
        if (reflecting) {
            return;
        }
        reflecting = true;
        try {
            attacker.hurt(thorns, amount);
        } finally {
            reflecting = false;
        }
    }

    private static void adapted(ServerPlayer player, Helion3.Kind kind, boolean total) {
        ShazamNetwork.playAnim(player, ShazamAnim.SUBJEK_ADAPT, new Vec3(kind.ordinal(), total ? 1 : 0, 0));
        sound(player, player.position(), ShazamSounds.HELION3_ADAPT.get(), 1.8f, total ? 0.8f : 1f);
        player.displayClientMessage(Component.translatable(total ? "message.shazammod.subjek.immune"
                : "message.shazammod.subjek.adapted", Helion3.kindName(kind)).withStyle(ChatFormatting.LIGHT_PURPLE), true);
    }

    // ----------------------------------------------------------- Bangkit Lagi

    /**
     * Serangan yang mestinya mematikan. Kalau masih ada nyawa cadangan: dia tumbang, kepompong sel mati membungkusnya,
     * lalu bangkit dengan REVIVE_HEALTH darah dan kebal total terhadap jenis serangan yang membunuhnya.
     * true = sudah ditangani (jangan dilempar balik jadi manusia).
     */
    public static boolean tryRevive(ServerPlayer player, DamageSource source) {
        State s = state(player);
        long now = player.level().getGameTime();
        if (now < s.downUntil) {
            return true;   // sedang tumbang: nggak bisa dibunuh dua kali
        }
        regrow(s, now);
        if (s.lives <= 0) {
            return false;
        }
        if (s.lives >= LIVES) {
            s.lifeRegrowAt = now + LIFE_REGROW_TICKS;
        }
        s.lives--;
        int down = ShazamAnim.SUBJEK_FALL_TICKS + ShazamAnim.SUBJEK_REVIVE_TICKS;
        s.downUntil = now + down;
        s.busyUntil = now + down;
        root(player, down);
        s.cocoonUntil = 0L;
        s.burrowUntil = 0L;
        final Helion3.Kind killer = Helion3.kindOf(source);
        if (killer != null) {
            s.immuneKind = killer.ordinal();
            s.immuneUntil = now + down + IMMUNE_TICKS;
            s.adapt[killer.ordinal()] = ADAPT_MAX;
            s.lastKind = killer.ordinal();
        }
        player.setHealth(1f);
        ShazamNetwork.playAnim(player, ShazamAnim.SUBJEK_FALL);
        sound(player, player.position(), ShazamSounds.HELION3_FALL.get(), 2.6f, 1.1f);
        player.displayClientMessage(Component.translatable("message.shazammod.subjek.fallen", s.lives)
                .withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD), true);
        later(player, ShazamAnim.SUBJEK_FALL_TICKS, p -> {
            ShazamNetwork.playAnim(p, ShazamAnim.SUBJEK_REVIVE);
            // suara bangkit bosnya meledak di tick 62; dipercepat supaya pas dengan SUBJEK_REVIVE_BURST
            sound(p, p.position(), ShazamSounds.HELION3_REVIVE.get(), 3.0f, 62f / ShazamAnim.SUBJEK_REVIVE_BURST);
        });
        later(player, ShazamAnim.SUBJEK_FALL_TICKS + ShazamAnim.SUBJEK_REVIVE_BURST, p -> {
            p.setHealth(Math.max(p.getHealth(), p.getMaxHealth() * REVIVE_HEALTH));
            Vec3 c = p.position();
            ShazamNetwork.playAnim(p, ShazamAnim.SUBJEK_BURST, c);
            shock(p, c, COCOON_BURST_RADIUS, COCOON_BURST_DAMAGE, 1.6, 0.6);
            if (killer != null) {
                adapted(p, killer, true);
            }
            ShazamNetwork.sync(p);
        });
        ShazamNetwork.sync(player);
        return true;
    }
}
