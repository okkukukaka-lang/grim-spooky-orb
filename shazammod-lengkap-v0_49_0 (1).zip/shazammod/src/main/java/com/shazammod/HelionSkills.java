package com.shazammod;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.WeakHashMap;
import java.util.function.Consumer;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * 0.43 PROJEK HELION-6, juara kelima (orisinal). Eksperimen Helion sebelum Lintang: serumnya disuntikkan di bawah radiasi
 * Batu Cryon, bukan matahari, jadi sel tubuhnya jadi Sel Cryon yang HIDUP dari radiasi Cryon. Kebalikan Lintang:
 * - Sumber tenaga: dekat bijih/pecahan Cryon terisi deras, membawa Cryon terisi pelan, Nether (penuh Cryon) & tempat gelap
 *   terisi sedikit. Tombol M (Hirup Cryon) meremukkan sebutir Pecahan Cryon lalu menghirup radiasinya: energi & darah
 *   melonjak, lalu Lonjakan Cryon 12 detik (tinju & ketahanan naik, aura radiasi melukai musuh di dekatnya).
 * - Kelemahan: MATAHARI. Siang di bawah langit terbuka (nggak hujan) radiasinya terbakar habis: energi terkuras (makin terik
 *   makin cepat), daya tinggal 60%, lari melambat, darah nggak pulih, Kulit Cryon nggak jalan, dan kalau radiasinya tinggal
 *   sedikit nggak bisa terbang. Habis = terlempar balik jadi manusia. Batu Cryon di dekatnya menetralkan kelemahan ini.
 * - Musuh bebuyutan Lintang: tinju Helion-6 membawa radiasi Cryon (menembus Kulit Baja Lintang & menghisap cahayanya), dan
 *   Helion-6 yang sedang berubah wujud membuat Lintang di dekatnya melemah. Sebaliknya tinju Lintang membakar sel Cryon.
 *
 * Skill (huruf H-E-L-I-O-N-6 di HUD, tombol sama dengan juara lain):
 * Z  H - Hempasan Lesat  : melesat lurus sejauh 22 blok, menghantam & melempar semua musuh di jalurnya, gelombang di ujung.
 * X  E - Emisi Cryon     : mata mengumpulkan radiasi, lalu dua sinar Cryon 2,5 detik mengikuti arah pandang: menembus 5
 *                          musuh, membakar & melemahkan (radiasi), menyulut permukaan yang disorot.
 * V  I - Injakan Cryon   : melompat kecil lalu berlutut menghantam tanah: gelombang radiasi 13 blok melambungkan musuh,
 *                          tanah retak bercahaya, gempa susulan 19 blok.
 * R  6 - Supernova-6     : 3 detik meringkuk menyerap radiasi (musuh tersedot, badan hampir kebal), lalu SEMUA radiasi
 *                          di atas 60 diledakkan: makin penuh makin luas & sakit; sisa zona radiasi beberapa detik.
 * C  L - Lahap Radiasi   : (0.45) 2,5 detik menghisap radiasi & nyawa sampai 6 musuh dalam 12 blok: mereka terluka,
 *                          melambat, tertarik pelan, berpendar; Helion-6 pulih & terisi per musuh.
 * B  O - Orbit Cryon     : (0.45) enam kristal Cryon mengorbit (menghancurkan proyektil & menyayat yang terlalu dekat),
 *                          lalu satu per satu melesat memburu musuh terdekat.
 * N  N - Nisan Kristal   : (0.45) telapak menghantam tanah, kristal Cryon meletus berderet ke depan: musuh yang kena
 *                          terkurung kristal 3 detik lalu kurungannya pecah; ladang kristalnya mengisi radiasi Helion-6.
 * J  Gerhana Buatan      : (0.45) kepalan diangkat ke matahari dan gerhana menutupnya: 45 detik di wilayah 48 blok
 *                          nggak ada matahari (kelemahan Helion-6 hilang, Lintang & Black Adam kehilangan tenaga surya).
 * M  Hirup Cryon         : (butuh Pecahan Cryon) lihat di atas.
 * Pasif: Denyut Cryon tiap 2 detik (padam di bawah matahari), Tinju Cryon (muatan penuh), Kulit Cryon (serangan lemah
 * memantul), dan radiasi yang melemahkan musuh yang kena (Lemah & Lambat).
 */
public final class HelionSkills {
    private HelionSkills() {}

    public enum Skill {
        HEMPAS(18f, 50, true),      // H - Hempasan Lesat (Z)
        EMISI(25f, 120, true),      // E - Emisi Cryon: sinar mata (X)
        LAHAP(20f, 280, true),      // L - Lahap Radiasi (C): menghisap radiasi & nyawa musuh di sekitar
        INJAK(30f, 160, true),      // I - Injakan Cryon (V)
        ORBIT(28f, 240, true),      // O - Orbit Cryon (B): kristal mengorbit (perisai), lalu melesat memburu musuh
        NISAN(30f, 220, true),      // N - Nisan Kristal (N): kristal meletus berderet, mengurung musuh
        SUPERNOVA(0f, 900, true);   // 6 - Supernova-6 (R): butuh NOVA_MIN_ENERGY, membakar hampir semua radiasi

        public final float cost;
        public final int cooldownTicks;
        public final boolean ready;

        Skill(float cost, int cooldownTicks, boolean ready) {
            this.cost = cost;
            this.cooldownTicks = cooldownTicks;
            this.ready = ready;
        }
    }

    // ================= Angka-angka yang gampang diutak-atik =================
    // Daya Cryon (kekuatan ikut radiasi tersimpan)
    public static final float FULL_POWER_ENERGY = 400f;   // radiasi segini ke atas: kekuatan penuh
    public static final float MIN_POWER = 0.8f;           // radiasi habis: masih 80%
    public static final float SUN_POWER = 0.6f;           // di bawah matahari: daya tinggal 60%
    public static final float WEAK_TAKEN_BONUS = 0.3f;    // damage diterima naik (1 - daya) x ini
    public static final float SURGE_POWER = 1.3f;         // Lonjakan Cryon: daya x1,3
    public static final float SURGE_TAKEN = 0.8f;         // ... dan damage diterima x0,8
    // Radiasi (energi) per detik
    public static final float CRYON_CHARGE = 25f;         // dekat bijih / pecahan Cryon di dunia
    public static final float CARRY_CHARGE = 6f;          // membawa Cryon di inventori
    public static final float NETHER_CHARGE = 4f;         // Nether penuh Cryon
    public static final float DARK_CHARGE = 1.5f;         // malam / di bawah tanah / di dalam ruangan
    public static final float SHADE_DRAIN = 0.5f;         // siang tapi teduh atau hujan
    public static final float SUN_DRAIN_MIN = 6f;         // di bawah matahari: 6 + 16 x terik matahari (tengah hari ±22/detik)
    public static final float SUN_DRAIN = 16f;
    public static final float HUMAN_RECHARGE = 6f;        // wujud manusia (bukan di bawah matahari)
    public static final float REGEN_PER_SECOND = 4f;      // x2,5 dekat Cryon, x1,5 di kegelapan, 0 di bawah matahari
    // Kelemahan matahari
    private static final double SUN_SLOW = -0.25;
    public static final float SUN_GROUND_ENERGY = 150f;   // di bawah matahari & radiasi di bawah segini: nggak bisa terbang
    private static final int SCAN_TICKS = 10;
    private static final int CRYON_BLOCK_RADIUS = 4;
    private static final double CRYON_ENTITY_RADIUS = 6.0;
    // Kulit Cryon (serangan di bawah segini memantul; 0 = mati)
    public static final float TOUGH_SKIN = 10f;
    // H - Hempasan Lesat
    private static final double DASH_RANGE = 22.0;
    private static final double DASH_WIDTH = 2.2;
    private static final float DASH_DAMAGE = 34f;
    private static final double DASH_IMPULSE = 1.9;
    private static final double DASH_END_RADIUS = 4.5;
    private static final float DASH_END_DAMAGE = 14f;
    // E - Emisi Cryon
    public static final double BEAM_RANGE = 56.0;
    private static final float BEAM_DAMAGE = 8f;           // tiap 2 tick, dikali daya
    private static final int BEAM_PIERCE = 5;
    private static final float BEAM_FIRE_SECONDS = 3f;
    private static final boolean BEAM_BURNS_BLOCKS = true; // false = sinar nggak pernah menyulut blok
    // I - Injakan Cryon
    private static final double QUAKE_RADIUS = 13.0;
    private static final double QUAKE_CORE = 3.5;          // di dalam sini damage penuh, di luarnya turun ~1/jarak
    private static final float QUAKE_DAMAGE = 48f;
    private static final double QUAKE_LIFT = 0.95;
    private static final double QUAKE_PUSH = 1.6;
    private static final int AFTERSHOCK_DELAY = 8;
    private static final double AFTERSHOCK_RADIUS = 19.0;
    private static final float AFTERSHOCK_DAMAGE = 12f;
    // 6 - Supernova-6
    public static final float NOVA_MIN_ENERGY = 300f;
    private static final float NOVA_KEEP_ENERGY = 60f;
    private static final double NOVA_RADIUS_MIN = 14.0;
    private static final double NOVA_RADIUS_PER_ENERGY = 0.019;   // radiasi 1000 -> ±32 blok
    private static final double NOVA_CORE = 6.0;
    private static final float NOVA_MIN_DAMAGE = 80f;
    private static final float NOVA_DAMAGE_PER_ENERGY = 0.14f;   // radiasi 1000 -> ±210
    private static final double NOVA_PULL_RADIUS = 16.0;
    private static final float NOVA_CHARGE_TAKEN = 0.3f;         // selama menyerap radiasi: damage diterima x0,3
    private static final int NOVA_ZONE_PULSES = 5;
    private static final float NOVA_ZONE_DAMAGE = 6f;
    // M - Hirup Cryon
    public static final int INHALE_COOLDOWN_TICKS = 400;
    private static final float INHALE_ENERGY = 450f;
    private static final float INHALE_HEAL = 150f;
    public static final int SURGE_TICKS = 240;
    private static final double SURGE_SPEED = 0.15;
    private static final double SURGE_AURA_RADIUS = 5.0;
    private static final float SURGE_AURA_DAMAGE = 4f;
    // Denyut Cryon (tiap 2 detik) & Tinju Cryon (muatan penuh)
    private static final double PULSE_SPLASH_RADIUS = 3.5;
    private static final float PULSE_SPLASH_DAMAGE = 5f;
    private static final float CRYON_PUNCH_CHAIN_DAMAGE = 16f;
    private static final double CRYON_PUNCH_RADIUS = 7.0;
    private static final int CRYON_PUNCH_TARGETS = 3;
    private static final double CRYON_PUNCH_KNOCKBACK = 2.2;
    private static final int SICK_TICKS = 80;                     // radiasi: musuh Lemah & Lambat
    // =========================================================================

    private static final ResourceLocation SUN_SLOW_ID = ShazamMod.id("helion_sun_slow");
    private static final ResourceLocation SURGE_SPEED_ID = ShazamMod.id("helion_surge_speed");

    private static final Map<UUID, long[]> READY_AT = new HashMap<>();
    private static final Map<UUID, Long> INHALE_READY_AT = new HashMap<>();
    private static final Map<UUID, Long> BEAM_START = new HashMap<>();
    private static final Map<UUID, Long> BEAM_UNTIL = new HashMap<>();
    private static final Map<UUID, Long> NOVA_AT = new HashMap<>();      // tick Supernova meledak (selama menyerap)
    private static final Map<UUID, Long> SURGE_UNTIL = new HashMap<>();
    private static final Map<UUID, Long> CRYON_UNTIL = new HashMap<>();  // bijih/pecahan Cryon di dunia sekitar
    private static final Map<UUID, Long> CARRY_UNTIL = new HashMap<>();  // membawa Cryon di inventori
    private static final Set<UUID> SUN_ON = new HashSet<>();             // sedang terbakar matahari
    private static final Map<UUID, Long> QUIET_UNTIL = new HashMap<>();

    // ----------------------------------------------------------- Pakai skill

    public static void use(ServerPlayer player, Skill skill) {
        if (!ShazamPowers.isHelion(player)) {
            if (ShazamPowers.data(player).anyUnlocked()) {
                player.displayClientMessage(Component.translatable("message.shazammod.not_transformed_helion")
                        .withStyle(ChatFormatting.GRAY), true);
            }
            return;
        }
        if (!skill.ready) {
            player.displayClientMessage(Component.translatable("message.shazammod.helion_soon",
                    Component.translatable("skill.shazammod.helion." + skill.name().toLowerCase(Locale.ROOT)))
                    .withStyle(ChatFormatting.DARK_GREEN), true);
            return;
        }
        if (isNovaCharging(player) || cooldownTicks(player, skill) > 0) {
            return;
        }
        float cost = skill == Skill.SUPERNOVA ? NOVA_MIN_ENERGY : skill.cost;
        if (ShazamPowers.data(player).energy() < cost) {
            player.displayClientMessage(Component.translatable("message.shazammod.skill_no_energy", Math.round(cost))
                    .withStyle(ChatFormatting.RED), true);
            return;
        }
        boolean used = switch (skill) {
            case HEMPAS -> hempas(player);
            case EMISI -> emisi(player);
            case INJAK -> injak(player);
            case LAHAP -> lahap(player);
            case ORBIT -> orbit(player);
            case NISAN -> nisan(player);
            case SUPERNOVA -> supernova(player);
            default -> false;
        };
        if (!used) {
            player.displayClientMessage(Component.translatable("message.shazammod.no_target").withStyle(ChatFormatting.GRAY), true);
            return;
        }
        if (skill != Skill.SUPERNOVA) {   // Supernova membakar radiasinya saat meledak
            ShazamData data = ShazamPowers.data(player);
            ShazamPowers.setData(player, data.withEnergy(data.energy() - skill.cost));
        }
        READY_AT.computeIfAbsent(player.getUUID(), id -> new long[Skill.values().length])[skill.ordinal()] =
                player.level().getGameTime() + skill.cooldownTicks;
        ShazamNetwork.sync(player);
    }

    public static int cooldownTicks(ServerPlayer player, Skill skill) {
        long[] readyAt = READY_AT.get(player.getUUID());
        if (readyAt == null) {
            return 0;
        }
        long left = readyAt[skill.ordinal()] - player.level().getGameTime();
        return left > 0 ? (int) left : 0;
    }

    public static int inhaleCooldownTicks(ServerPlayer player) {
        Long ready = INHALE_READY_AT.get(player.getUUID());
        if (ready == null) {
            return 0;
        }
        long left = ready - player.level().getGameTime();
        return left > 0 ? (int) left : 0;
    }

    /** Efek dijalankan beberapa tick lagi, dan dibatalkan kalau pemain keburu balik jadi manusia. */
    private static void later(ServerPlayer player, int delay, Consumer<ServerPlayer> action) {
        ShazamPowers.schedule(player, delay, p -> {
            if (ShazamPowers.isHelion(p)) {
                action.accept(p);
            }
        });
    }

    // ----------------------------------------------------------- Daya Cryon

    /** 0..1,3: kekuatan Helion-6 dari radiasi tersimpan, dikali SUN_POWER di bawah matahari dan SURGE_POWER saat Lonjakan. */
    public static float powerAt(float energy, boolean sun, boolean surge) {
        float k = energy >= FULL_POWER_ENERGY ? 1f : MIN_POWER + (1f - MIN_POWER) * Math.max(0f, energy) / FULL_POWER_ENERGY;
        if (sun) {
            k *= SUN_POWER;
        }
        if (surge) {
            k *= SURGE_POWER;
        }
        return k;
    }

    public static float power(ServerPlayer player) {
        return powerAt(ShazamPowers.data(player).energy(), weakened(player), isSurging(player));
    }

    /** Persen Daya Cryon buat HUD. */
    public static int powerPercent(ServerPlayer player) {
        return Math.round(power(player) * 100f);
    }

    /** Damage yang diterima pada daya ini (tanpa Lonjakan & Supernova). */
    public static float takenAt(float power) {
        return ShazamPowers.HELION_DAMAGE_TAKEN_MULTIPLIER + Math.max(0f, 1f - power) * WEAK_TAKEN_BONUS;
    }

    /** Tinju tangan kosong pada daya ini. */
    public static float punchAt(float power) {
        return ShazamPowers.HELION_PUNCH_MULTIPLIER * power;
    }

    public static float damageTakenMultiplier(ServerPlayer player) {
        float taken = takenAt(Math.min(1f, power(player)));
        if (isSurging(player)) {
            taken *= SURGE_TAKEN;
        }
        if (isNovaCharging(player)) {
            taken *= NOVA_CHARGE_TAKEN;
        }
        return taken;
    }

    public static float punchMultiplier(ServerPlayer player) {
        return punchAt(power(player));
    }

    /** Siang di bawah langit terbuka (nggak hujan). */
    public static boolean sunExposed(ServerPlayer player) {
        return ShazamPowers.isInSun(player);
    }

    /** Sel Cryon sedang terbakar matahari (di bawah matahari tanpa Batu Cryon di dekatnya). */
    public static boolean weakened(ServerPlayer player) {
        return SUN_ON.contains(player.getUUID());
    }

    /** Bijih / pecahan Cryon di dunia sekitar (sumber tenaga yang deras). */
    public static boolean cryonWorld(ServerPlayer player) {
        Long until = CRYON_UNTIL.get(player.getUUID());
        return until != null && until > player.level().getGameTime();
    }

    public static boolean carrying(ServerPlayer player) {
        Long until = CARRY_UNTIL.get(player.getUUID());
        return until != null && until > player.level().getGameTime();
    }

    /** Ada Cryon di dekatnya (dunia atau inventori): buat HUD. */
    public static boolean cryonNear(ServerPlayer player) {
        return cryonWorld(player) || carrying(player);
    }

    /** Di bawah matahari dengan radiasi tinggal sedikit: nggak bisa terbang. */
    public static boolean grounded(ServerPlayer player) {
        return weakened(player) && ShazamPowers.data(player).energy() < SUN_GROUND_ENERGY;
    }

    public static boolean isSurging(ServerPlayer player) {
        Long until = SURGE_UNTIL.get(player.getUUID());
        return until != null && until > player.level().getGameTime();
    }

    public static boolean isNovaCharging(ServerPlayer player) {
        return NOVA_AT.containsKey(player.getUUID());
    }

    /** Energi per detik (ShazamPowers.tick): Cryon mengisi, matahari membakar. */
    public static float energyPerSecond(ServerPlayer player, boolean transformed) {
        if (player.tickCount % SCAN_TICKS == 0) {
            scanCryon(player);
        }
        boolean world = cryonWorld(player);
        boolean carry = carrying(player);
        boolean sun = ShazamPowers.isInSun(player);
        Level level = player.level();
        if (transformed) {
            if (world) {
                return CRYON_CHARGE;
            }
            if (sun) {   // makin terik makin cepat terbakar (sinus ketinggian matahari, cuaca)
                return -(SUN_DRAIN_MIN + SUN_DRAIN * LintangPhysics.solarIrradiance(player)) + (carry ? CARRY_CHARGE : 0f);
            }
            float base = PassiveConditions.inferno(level) ? NETHER_CHARGE
                    : PassiveConditions.darkness(level) || !level.canSeeSky(player.blockPosition().above()) ? DARK_CHARGE
                    : eclipsed(level, player.position()) ? ECLIPSE_CHARGE : -SHADE_DRAIN;   // 0.45 di bawah gerhana
            return base + (carry ? CARRY_CHARGE : 0f);
        }
        if (world) {
            return CRYON_CHARGE * 1.2f;
        }
        if (sun) {
            return carry ? CARRY_CHARGE * 0.5f : 0f;
        }
        return HUMAN_RECHARGE * (PassiveConditions.inferno(level) ? 1.5f : 1f) + (carry ? CARRY_CHARGE : 0f);
    }

    /** Darah pulih per detik: 0 di bawah matahari, lebih cepat dekat Cryon & di kegelapan, x2 saat Lonjakan. */
    public static float regenPerSecond(ServerPlayer player) {
        if (weakened(player)) {
            return 0f;
        }
        float r = REGEN_PER_SECOND;
        if (cryonWorld(player)) {
            r *= 2.5f;
        } else if (PassiveConditions.darkness(player.level())) {
            r *= 1.5f;
        }
        return isSurging(player) ? r * 2f : r;
    }

    // ----------------------------------------------------------- Tiap tick

    public static void tick(ServerPlayer player) {
        UUID id = player.getUUID();
        long now = player.level().getGameTime();
        if (player.tickCount % SCAN_TICKS == 0) {
            sunScan(player, now);
        }
        Long beamEnd = BEAM_UNTIL.get(id);
        if (beamEnd != null) {
            Long beamStart = BEAM_START.get(id);
            if (now >= beamEnd) {
                BEAM_UNTIL.remove(id);
                BEAM_START.remove(id);
            } else if (beamStart != null && now >= beamStart && (now - beamStart) % 2 == 0) {
                beamStep(player);
            }
        }
        Long nova = NOVA_AT.get(id);
        if (nova != null && now < nova && (nova - now) % 5 == 0) {
            novaPull(player);
        }
        Long surge = SURGE_UNTIL.get(id);
        if (surge != null) {
            if (now >= surge) {
                endSurge(player);
                player.displayClientMessage(Component.translatable("message.shazammod.helion_surge_end")
                        .withStyle(ChatFormatting.DARK_GREEN), true);
            } else if ((surge - now) % 20 == 0) {
                surgeAura(player);
            }
        }
        lahapTick(player, now);   // 0.45
        orbitTick(player, now);
        nisanTick(player, now);
        ShazamPassives.tick(player);   // Denyut Cryon tiap 2 detik, Muatan Cryon, Hati Pahlawan
    }

    /** Hentikan skill yang sedang berjalan (balik jadi manusia, respawn). Cooldown tetap jalan. */
    public static void cancelActive(ServerPlayer player) {
        UUID id = player.getUUID();
        BEAM_START.remove(id);
        BEAM_UNTIL.remove(id);
        NOVA_AT.remove(id);
        endSurge(player);
        LAHAP_UNTIL.remove(id);   // 0.45
        ORBITS.remove(id);
        NISANS.remove(id);
        TOMBS.entrySet().removeIf(entry -> entry.getValue().owner().equals(id));
        SUN_ON.remove(id);
        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null) {
            speed.removeModifier(SUN_SLOW_ID);
        }
    }

    public static void forget(UUID id) {
        READY_AT.remove(id);
        INHALE_READY_AT.remove(id);
        BEAM_START.remove(id);
        BEAM_UNTIL.remove(id);
        NOVA_AT.remove(id);
        SURGE_UNTIL.remove(id);
        CRYON_UNTIL.remove(id);
        CARRY_UNTIL.remove(id);
        SUN_ON.remove(id);
        QUIET_UNTIL.remove(id);
        LAHAP_UNTIL.remove(id);   // 0.45
        ORBITS.remove(id);
        NISANS.remove(id);
        ECLIPSE_READY_AT.remove(id);
        TAUNT_READY_AT.remove(id);
    }

    private static void endSurge(ServerPlayer player) {
        SURGE_UNTIL.remove(player.getUUID());
        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null) {
            speed.removeModifier(SURGE_SPEED_ID);
        }
    }

    // ----------------------------------------------------------- bantu

    private static List<LivingEntity> enemies(ServerPlayer player, Vec3 center, double radius) {
        return player.serverLevel().getEntitiesOfClass(LivingEntity.class, new AABB(center, center).inflate(radius),
                m -> m.isAlive() && m instanceof Enemy && !DemonSoldier.isFriendly(m)
                        && m.distanceToSqr(center) <= radius * radius);
    }

    private static void sound(ServerPlayer player, Vec3 at, SoundEvent sound, float volume, float pitch) {
        player.serverLevel().playSound(null, at.x, at.y, at.z, sound, SoundSource.PLAYERS, volume, pitch);
    }

    private static Vec3 flat(Vec3 v) {
        Vec3 f = new Vec3(v.x, 0, v.z);
        return f.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : f.normalize();
    }

    private static Vec3 away(Vec3 center, LivingEntity entity) {
        Vec3 a = new Vec3(entity.getX() - center.x, 0, entity.getZ() - center.z);
        return a.lengthSqr() < 1.0E-4 ? Vec3.ZERO : a.normalize();
    }

    private static Vec3 chest(LivingEntity entity) {
        return entity.position().add(0, entity.getBbHeight() * 0.55, 0);
    }

    /** Jarak titik p ke ruas garis a-b. */
    private static double segmentDistance(Vec3 p, Vec3 a, Vec3 b) {
        Vec3 ab = b.subtract(a);
        double len2 = ab.lengthSqr();
        double t = len2 < 1.0E-8 ? 0.0 : Mth.clamp(p.subtract(a).dot(ab) / len2, 0.0, 1.0);
        return p.distanceTo(a.add(ab.scale(t)));
    }

    /** Radiasi Cryon: musuh yang kena melemah & melambat. */
    static void sicken(LivingEntity target, int ticks) {
        target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, ticks, 1));
        target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, Math.max(20, ticks / 2), 1));
    }

    private static boolean quiet(ServerPlayer player, int ticks) {
        long now = player.level().getGameTime();
        Long until = QUIET_UNTIL.get(player.getUUID());
        if (until != null && now < until) {
            return false;
        }
        QUIET_UNTIL.put(player.getUUID(), now + ticks);
        return true;
    }

    /**
     * Pemain ini sedang berwujud Helion-6 (memancarkan radiasi Cryon)? Dipakai server & client (kelemahan Lintang di dekatnya),
     * jadi di client dibaca dari status juara yang dikirim server.
     */
    public static boolean radiates(Player player) {
        if (player.level().isClientSide()) {
            return ShazamClientState.isTransformed(player.getId()) && ShazamClientState.isHelion(player.getId());
        }
        return ShazamPowers.isHelion(player);
    }

    /** 0.46 Rival Helion-6 yang sedang berubah wujud juga memancarkan radiasi Cryon (melemahkan Lintang di dekatnya). */
    public static boolean radiatesRival(Entity entity) {
        return entity instanceof com.shazammod.rival.RivalChampion rival && rival.form() == ShazamForm.HELION
                && rival.isTransformedRival();
    }

    // ----------------------------------------------------------- Cryon & matahari

    private static boolean carries(Player player) {
        Inventory inventory = player.getInventory();
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            if (LintangSkills.isKelam(inventory.getItem(i))) {
                return true;
            }
        }
        return false;
    }

    private static boolean cryonAround(Level level, Player player) {
        if (nearCrystalField(level, player.position())) {
            return true;   // 0.45 ladang kristal Nisan Kristal memancarkan radiasi Cryon
        }
        AABB area = player.getBoundingBox().inflate(CRYON_ENTITY_RADIUS);
        if (!level.getEntitiesOfClass(ItemEntity.class, area, item -> LintangSkills.isKelam(item.getItem())).isEmpty()
                || !level.getEntitiesOfClass(LivingEntity.class, area, e -> e != player && e.isAlive()
                && LintangSkills.holdsKelam(e)).isEmpty()) {
            return true;
        }
        BlockPos c = player.blockPosition();
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        int r = CRYON_BLOCK_RADIUS;
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r + 1; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    p.set(c.getX() + dx, c.getY() + dy, c.getZ() + dz);
                    if (level.getBlockState(p).is(LintangItems.KELAM_ORE.get())) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private static void scanCryon(ServerPlayer player) {
        long now = player.level().getGameTime();
        UUID id = player.getUUID();
        if (cryonAround(player.serverLevel(), player)) {
            CRYON_UNTIL.put(id, now + SCAN_TICKS + 2);
        }
        if (carries(player)) {
            CARRY_UNTIL.put(id, now + SCAN_TICKS + 2);
        }
    }

    /** Tiap SCAN_TICKS saat berwujud Helion-6: matahari membakar sel Cryon (lambat, nggak bisa terbang kalau radiasi tipis). */
    private static void sunScan(ServerPlayer player, long now) {
        UUID id = player.getUUID();
        boolean burning = ShazamPowers.isInSun(player) && !cryonWorld(player);
        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (burning) {
            if (SUN_ON.add(id) && speed != null && !speed.hasModifier(SUN_SLOW_ID)) {
                speed.addTransientModifier(new AttributeModifier(SUN_SLOW_ID, SUN_SLOW, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
            }
            if (ShazamPowers.data(player).energy() < SUN_GROUND_ENERGY && !player.isCreative() && !player.isSpectator()
                    && (player.getAbilities().mayfly || player.getAbilities().flying)) {
                player.getAbilities().flying = false;
                player.getAbilities().mayfly = false;
                player.onUpdateAbilities();
                player.displayClientMessage(Component.translatable("message.shazammod.helion_grounded")
                        .withStyle(ChatFormatting.GOLD), true);
            }
            if ((now / SCAN_TICKS) % 4 == 0) {   // kulit mendesis & berasap (asapnya digambar client)
                sound(player, player.position().add(0, 1.0, 0), ShazamSounds.HELION_SUN_BURN.get(), 0.45f,
                        0.9f + player.getRandom().nextFloat() * 0.2f);
            }
        } else if (SUN_ON.remove(id) && speed != null) {
            speed.removeModifier(SUN_SLOW_ID);
        }
    }

    public static boolean hasCryon(ServerPlayer player) {
        return carries(player);
    }

    /** Ambil sebutir Pecahan Cryon (atau bijihnya kalau nggak ada pecahan) dari inventori. */
    private static boolean consumeCryon(ServerPlayer player) {
        Inventory inventory = player.getInventory();
        int ore = -1;
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack stack = inventory.getItem(i);
            if (stack.isEmpty()) {
                continue;
            }
            if (stack.is(LintangItems.KELAM_SHARD.get())) {
                stack.shrink(1);
                return true;
            }
            if (ore < 0 && LintangSkills.isKelam(stack)) {
                ore = i;
            }
        }
        if (ore >= 0) {
            inventory.getItem(ore).shrink(1);
            return true;
        }
        return false;
    }

    // ----------------------------------------------------------- Kulit Cryon

    /** Serangan lemah dari makhluk memantul (bukan sihir, bukan saat terbakar matahari). */
    public static boolean bounces(ServerPlayer victim, DamageSource source, float amount) {
        if (TOUGH_SKIN <= 0f || amount >= TOUGH_SKIN || weakened(victim)) {
            return false;
        }
        if (source.getEntity() == null && source.getDirectEntity() == null) {
            return false;
        }
        return !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY) && !source.is(DamageTypes.MAGIC)
                && !source.is(DamageTypes.INDIRECT_MAGIC);
    }

    public static void bounce(ServerPlayer victim, DamageSource source) {
        if (!quiet(victim, 6)) {
            return;
        }
        Entity from = source.getDirectEntity() != null ? source.getDirectEntity() : source.getEntity();
        Vec3 chest = chest(victim);
        Vec3 hit = chest;
        if (from != null) {
            Vec3 toward = from.position().add(0, from.getBbHeight() * 0.6, 0).subtract(chest);
            hit = toward.lengthSqr() < 1.0E-4 ? chest : chest.add(toward.normalize().scale(0.55));
        }
        ShazamNetwork.playAnim(victim, ShazamAnim.HELION_DEFLECT, hit);
        sound(victim, hit, ShazamSounds.DEFLECT.get(), 0.9f, ShazamSounds.tune(1.3f + victim.getRandom().nextFloat() * 0.3f));
    }

    // ----------------------------------------------------------- Tinju

    /** Tinju biasa Helion-6 mengenai: kilat radiasi di titik kena, kadang musuhnya terpapar radiasi. */
    public static void onPunch(ServerPlayer attacker, LivingEntity hit) {
        Vec3 at = hit.position().add(0, hit.getBbHeight() * 0.6, 0);
        ShazamNetwork.playAnim(attacker, ShazamAnim.HELION_PUNCH, at);
        sound(attacker, at, ShazamSounds.HELION_PUNCH.get(), 1.0f, 0.95f + attacker.getRandom().nextFloat() * 0.1f);
        if (attacker.getRandom().nextInt(3) == 0) {
            sicken(hit, 40);
        }
    }

    /**
     * Tinju Cryon (Muatan Cryon penuh, padanan Pukulan Guntur; damage-nya sudah dikali di event yang sama): radiasi meledak
     * di sasaran, sasaran terlempar jauh, lalu sampai 3 musuh lain disambar radiasi.
     */
    public static void cryonPunch(ServerPlayer player, LivingEntity target) {
        Vec3 at = target.position().add(0, target.getBbHeight() * 0.6, 0);
        ShazamNetwork.playAnim(player, ShazamAnim.HELION_CRYON_PUNCH, at);
        sound(player, at, ShazamSounds.HELION_CRYON_PUNCH.get(), 2.0f, 1f);
        sicken(target, SICK_TICKS * 2);
        ShazamPowers.schedule(player, 1, p -> {
            if (target.isAlive()) {
                Vec3 dir = new Vec3(target.getX() - p.getX(), 0, target.getZ() - p.getZ());
                dir = dir.lengthSqr() < 1.0E-4 ? Vec3.ZERO : dir.normalize();
                target.push(dir.x * CRYON_PUNCH_KNOCKBACK, 0.6, dir.z * CRYON_PUNCH_KNOCKBACK);
                target.hurtMarked = true;
            }
            List<LivingEntity> near = enemies(p, target.position(), CRYON_PUNCH_RADIUS);
            near.remove(target);
            near.sort(Comparator.comparingDouble(m -> m.distanceToSqr(target)));
            DamageSource force = ShazamPowers.forceSource(p);
            for (int i = 0; i < Math.min(CRYON_PUNCH_TARGETS, near.size()); i++) {
                LivingEntity m = near.get(i);
                m.invulnerableTime = 0;
                m.hurt(force, CRYON_PUNCH_CHAIN_DAMAGE);
                sicken(m, SICK_TICKS);
                ShazamNetwork.playAnim(p, ShazamAnim.HELION_DASH_HIT, chest(m));
            }
        });
    }

    // ----------------------------------------------------------- Pasif

    /** Pengali Denyut Cryon tiap 2 detik: x2 dekat Cryon, x1,5 di Nether. */
    public static float pulseScale(ServerPlayer player) {
        return cryonWorld(player) ? 2f : PassiveConditions.inferno(player.level()) ? 1.5f : 1f;
    }

    /** Denyut Cryon ikut membakar musuh yang terlalu dekat. */
    public static void pulseSplash(ServerPlayer player) {
        DamageSource force = ShazamPowers.forceSource(player);
        for (LivingEntity m : enemies(player, player.position(), PULSE_SPLASH_RADIUS)) {
            m.hurt(force, PULSE_SPLASH_DAMAGE);
            sicken(m, 40);
        }
    }

    /** Berubah wujud: radiasi meledak dari tubuh (pengganti petir), musuh di sekitar terlempar & terpapar. */
    public static void transformBlast(ServerPlayer caster, Vec3 pos, float damage, double radius) {
        ServerLevel level = caster.serverLevel();
        level.playSound(null, pos.x, pos.y, pos.z, ShazamSounds.HELION_BURST.get(), SoundSource.PLAYERS, 3.0f, 1f);
        taunt(caster, Taunt.TRANSFORM, true);   // 0.45 balon kata
        if (damage <= 0f) {
            return;
        }
        DamageSource source = ShazamPowers.forceSource(caster);
        for (LivingEntity target : enemies(caster, pos, radius)) {
            target.hurt(source, damage);
            Vec3 a = away(pos, target);
            target.push(a.x * 1.6, 0.5, a.z * 1.6);
            target.hurtMarked = true;
            sicken(target, 100);
        }
    }

    /** Radiasi habis di bawah matahari: jatuh berlutut (ShazamPowers lalu mengembalikannya jadi manusia). */
    public static void burnout(ServerPlayer player) {
        ShazamNetwork.playAnim(player, ShazamAnim.HELION_COLLAPSE, player.position());
        taunt(player, Taunt.BURNOUT, true);
    }

    // ----------------------------------------------------------- H - Hempasan Lesat

    private static boolean hempas(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        Vec3 look = player.getViewVector(1f);
        Vec3 dir = player.onGround() && Math.abs(look.y) < 0.55 ? flat(look) : look.normalize();
        Vec3 start = player.position();
        Vec3 from = start.add(0, 0.9, 0);
        BlockHitResult hit = level.clip(new ClipContext(from, from.add(dir.scale(DASH_RANGE)), ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, player));
        double dist = hit.getType() == HitResult.Type.MISS ? DASH_RANGE : Math.max(0.0, hit.getLocation().distanceTo(from) - 0.9);
        if (dist < 2.0) {
            return false;   // terhalang dinding
        }
        Vec3 end = start.add(dir.scale(dist));
        ShazamNetwork.playAnim(player, ShazamAnim.HELION_DASH, end);
        sound(player, start, ShazamSounds.HELION_DASH.get(), 1.6f, 1f);
        later(player, ShazamAnim.HELION_DASH_WINDUP + ShazamAnim.HELION_DASH_TICKS, p -> dashImpact(p, start, end, dir));
        return true;
    }

    private static void dashImpact(ServerPlayer player, Vec3 a, Vec3 b, Vec3 dir) {
        float power = power(player);
        DamageSource source = ShazamPowers.forceSource(player);
        Vec3 a1 = a.add(0, 0.9, 0), b1 = b.add(0, 0.9, 0);
        AABB box = new AABB(a1, b1).inflate(DASH_WIDTH + 1.0);
        for (LivingEntity m : player.serverLevel().getEntitiesOfClass(LivingEntity.class, box,
                e -> e.isAlive() && e instanceof Enemy && !DemonSoldier.isFriendly(e))) {
            Vec3 c = chest(m);
            if (segmentDistance(c, a1, b1) > DASH_WIDTH + m.getBbWidth() * 0.5) {
                continue;
            }
            m.invulnerableTime = 0;
            m.hurt(source, DASH_DAMAGE * power);
            Vec3 side = new Vec3(c.x - a.x, 0, c.z - a.z);
            Vec3 across = side.subtract(dir.scale(side.dot(dir)));
            Vec3 push = (across.lengthSqr() < 1.0E-4 ? Vec3.ZERO : across.normalize().scale(0.8)).add(dir.scale(DASH_IMPULSE));
            m.push(push.x, 0.55, push.z);
            m.hurtMarked = true;
            sicken(m, SICK_TICKS);
            ShazamNetwork.playAnim(player, ShazamAnim.HELION_DASH_HIT, c);
        }
        for (LivingEntity m : enemies(player, b, DASH_END_RADIUS)) {   // radiasi yang terbawa menghempas di ujung lesatan
            m.hurt(source, DASH_END_DAMAGE * power);
            Vec3 aw = away(b, m);
            m.push(aw.x * 0.9, 0.35, aw.z * 0.9);
            m.hurtMarked = true;
        }
        sound(player, b, ShazamSounds.SHOCKWAVE.get(), 1.2f, ShazamSounds.tune(1.2f));
    }

    // ----------------------------------------------------------- E - Emisi Cryon

    private static boolean emisi(ServerPlayer player) {
        UUID id = player.getUUID();
        long now = player.level().getGameTime();
        BEAM_START.put(id, now + ShazamAnim.HELION_EYES_WINDUP);
        BEAM_UNTIL.put(id, now + ShazamAnim.HELION_EYES_WINDUP + ShazamAnim.HELION_EYES_TICKS);
        ShazamNetwork.playAnim(player, ShazamAnim.HELION_EYES);
        taunt(player, Taunt.EYES, false);
        sound(player, player.getEyePosition(), ShazamSounds.HELION_BEAM_CHARGE.get(), 1.2f, 1f);
        later(player, ShazamAnim.HELION_EYES_WINDUP, p -> sound(p, p.getEyePosition(), ShazamSounds.HELION_BEAM_FIRE.get(), 1.8f, 1f));
        return true;
    }

    /** Satu denyut sinar (tiap 2 tick): dari mata lurus ke arah pandang, menembus musuh, berhenti di blok. */
    private static void beamStep(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getViewVector(1f);
        Vec3 far = eye.add(look.scale(BEAM_RANGE));
        BlockHitResult hit = level.clip(new ClipContext(eye, far, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        Vec3 end = hit.getType() == HitResult.Type.MISS ? far : hit.getLocation();
        float power = power(player);
        DamageSource source = ShazamPowers.forceSource(player);
        List<LivingEntity> hits = new ArrayList<>();
        for (LivingEntity m : level.getEntitiesOfClass(LivingEntity.class, new AABB(eye, end).inflate(1.5),
                e -> e.isAlive() && e instanceof Enemy && !DemonSoldier.isFriendly(e))) {
            double reach = Math.max(0.6, m.getBbWidth() * 0.6) + m.getBbHeight() * 0.25;
            if (segmentDistance(m.position().add(0, m.getBbHeight() * 0.5, 0), eye, end) <= reach) {
                hits.add(m);
            }
        }
        hits.sort(Comparator.comparingDouble(m -> m.distanceToSqr(eye)));
        for (int i = 0; i < Math.min(BEAM_PIERCE, hits.size()); i++) {
            LivingEntity m = hits.get(i);
            m.invulnerableTime = 0;
            m.hurt(source, BEAM_DAMAGE * power);
            m.igniteForSeconds(BEAM_FIRE_SECONDS);
            sicken(m, 40);
        }
        if (BEAM_BURNS_BLOCKS && hit.getType() == HitResult.Type.BLOCK && level.random.nextInt(6) == 0) {
            BlockPos firePos = hit.getBlockPos().relative(hit.getDirection());
            if (level.getBlockState(firePos).isAir() && LintangPhysics.canChange(player, level, firePos)) {
                level.setBlockAndUpdate(firePos, BaseFireBlock.getState(level, firePos));
            }
        }
    }

    // ----------------------------------------------------------- I - Injakan Cryon

    private static boolean injak(ServerPlayer player) {
        ShazamNetwork.playAnim(player, ShazamAnim.HELION_QUAKE, player.position());
        taunt(player, Taunt.QUAKE, false);
        sound(player, player.position(), ShazamSounds.HELION_QUAKE.get(), 2.6f, 1f);
        later(player, ShazamAnim.HELION_QUAKE_WINDUP, HelionSkills::quakeImpact);
        return true;
    }

    private static void quakeImpact(ServerPlayer player) {
        Vec3 c = player.position();
        float power = power(player);
        DamageSource source = ShazamPowers.forceSource(player);
        for (LivingEntity m : enemies(player, c, QUAKE_RADIUS)) {
            double d = Math.sqrt(m.distanceToSqr(c));
            float fall = d <= QUAKE_CORE ? 1f : (float) (QUAKE_CORE / d);
            m.invulnerableTime = 0;
            m.hurt(source, QUAKE_DAMAGE * power * fall);
            Vec3 a = away(c, m);
            double k = 0.35 + 0.65 * fall;
            m.push(a.x * QUAKE_PUSH * k, QUAKE_LIFT * k, a.z * QUAKE_PUSH * k);
            m.hurtMarked = true;
            sicken(m, SICK_TICKS);
        }
        for (Projectile shot : player.serverLevel().getEntitiesOfClass(Projectile.class, new AABB(c, c).inflate(QUAKE_RADIUS * 0.6),
                e -> e.getOwner() != player)) {   // proyektil di dekatnya terlempar ke atas
            shot.setDeltaMovement(shot.getDeltaMovement().scale(0.2).add(0, 0.8, 0));
            shot.hurtMarked = true;
        }
        later(player, AFTERSHOCK_DELAY, p -> {   // gempa susulan: cuma yang berpijak di tanah
            DamageSource force = ShazamPowers.forceSource(p);
            for (LivingEntity m : enemies(p, c, AFTERSHOCK_RADIUS)) {
                if (!m.onGround()) {
                    continue;
                }
                m.invulnerableTime = 0;
                m.hurt(force, AFTERSHOCK_DAMAGE * power(p));
                Vec3 a = away(c, m);
                m.push(a.x * 0.5, 0.45, a.z * 0.5);
                m.hurtMarked = true;
            }
        });
    }

    // ----------------------------------------------------------- 6 - Supernova-6

    private static boolean supernova(ServerPlayer player) {
        long now = player.level().getGameTime();
        NOVA_AT.put(player.getUUID(), now + ShazamAnim.HELION_NOVA_WINDUP);
        ShazamNetwork.playAnim(player, ShazamAnim.HELION_NOVA);
        taunt(player, Taunt.NOVA, true);
        sound(player, player.position(), ShazamSounds.HELION_NOVA.get(), 3.5f, 1f);
        later(player, ShazamAnim.HELION_NOVA_WINDUP, HelionSkills::novaBlast);
        return true;
    }

    /** Selama menyerap radiasi: musuh di sekitar tersedot pelan ke arahnya & terpapar. */
    private static void novaPull(ServerPlayer player) {
        Vec3 c = player.position();
        for (LivingEntity m : enemies(player, c, NOVA_PULL_RADIUS)) {
            Vec3 pull = c.subtract(m.position());
            if (pull.lengthSqr() > 4.0) {
                pull = pull.normalize().scale(0.35);
                m.push(pull.x, 0.04, pull.z);
                m.hurtMarked = true;
            }
            if (m.distanceToSqr(c) < 36.0) {
                sicken(m, 30);
            }
        }
    }

    private static void novaBlast(ServerPlayer player) {
        UUID id = player.getUUID();
        NOVA_AT.remove(id);
        float k = (weakened(player) ? SUN_POWER : 1f) * (isSurging(player) ? SURGE_POWER : 1f);
        ShazamData data = ShazamPowers.data(player);
        float burned = Math.max(0f, data.energy() - NOVA_KEEP_ENERGY);
        ShazamPowers.setData(player, data.withEnergy(Math.min(data.energy(), NOVA_KEEP_ENERGY)));
        double radius = NOVA_RADIUS_MIN + burned * NOVA_RADIUS_PER_ENERGY;
        float damage = (NOVA_MIN_DAMAGE + burned * NOVA_DAMAGE_PER_ENERGY) * k;
        Vec3 c = player.position().add(0, 1.0, 0);
        DamageSource source = ShazamPowers.forceSource(player);
        for (LivingEntity m : enemies(player, c, radius)) {
            double d = Math.sqrt(m.distanceToSqr(c));
            float fall = d <= NOVA_CORE ? 1f : (float) Math.max(0.25, NOVA_CORE / d);
            m.invulnerableTime = 0;
            m.hurt(source, damage * fall);
            m.igniteForSeconds(6f);
            sicken(m, 200);
            Vec3 a = away(c, m);
            m.push(a.x * 2.4 * fall, 0.2 + 0.8 * fall, a.z * 2.4 * fall);
            m.hurtMarked = true;
        }
        for (Projectile shot : player.serverLevel().getEntitiesOfClass(Projectile.class, new AABB(c, c).inflate(radius),
                e -> e.getOwner() != player)) {
            shot.discard();
        }
        // x = jari-jari ledakan, y = kekuatan 0-1 (efek di client mengikuti radiasi yang dibakar)
        ShazamNetwork.playAnim(player, ShazamAnim.HELION_NOVA_BLAST,
                new Vec3(radius, Mth.clamp(burned / (ShazamPowers.MAX_ENERGY - NOVA_KEEP_ENERGY), 0.2f, 1f), 0));
        double zone = radius * 0.4;
        for (int i = 1; i <= NOVA_ZONE_PULSES; i++) {   // sisa zona radiasi
            ShazamPowers.schedule(player, i * 20, p -> {
                DamageSource force = ShazamPowers.forceSource(p);
                for (LivingEntity m : p.serverLevel().getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(zone),
                        e -> e.isAlive() && e instanceof Enemy && !DemonSoldier.isFriendly(e) && e.distanceToSqr(c) <= zone * zone)) {
                    m.invulnerableTime = 0;
                    m.hurt(force, NOVA_ZONE_DAMAGE);
                    sicken(m, 40);
                }
            });
        }
        player.displayClientMessage(Component.translatable("message.shazammod.helion_nova", Math.round(burned))
                .withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD), true);
        ShazamNetwork.sync(player);
    }

    // ----------------------------------------------------------- M - Hirup Cryon

    public static void inhale(ServerPlayer player) {
        if (!ShazamPowers.isHelion(player)) {
            player.displayClientMessage(Component.translatable("message.shazammod.not_transformed_helion")
                    .withStyle(ChatFormatting.GRAY), true);
            return;
        }
        if (inhaleCooldownTicks(player) > 0 || isNovaCharging(player)) {
            return;
        }
        if (!player.isCreative() && !hasCryon(player)) {
            player.displayClientMessage(Component.translatable("message.shazammod.helion_need_cryon")
                    .withStyle(ChatFormatting.GRAY), true);
            return;
        }
        INHALE_READY_AT.put(player.getUUID(), player.level().getGameTime() + INHALE_COOLDOWN_TICKS);
        ShazamNetwork.playAnim(player, ShazamAnim.HELION_INHALE);
        taunt(player, Taunt.INHALE, false);
        sound(player, player.getEyePosition(), ShazamSounds.HELION_INHALE.get(), 1.6f, 1f);
        later(player, ShazamAnim.HELION_INHALE_WINDUP, p -> {
            if (!p.isCreative() && !consumeCryon(p)) {
                return;
            }
            ShazamData d = ShazamPowers.data(p);
            ShazamPowers.setData(p, d.withEnergy(d.energy() + INHALE_ENERGY));
            p.heal(INHALE_HEAL * ShazamPowers.healScale(p));
            SURGE_UNTIL.put(p.getUUID(), p.level().getGameTime() + SURGE_TICKS);
            AttributeInstance speed = p.getAttribute(Attributes.MOVEMENT_SPEED);
            if (speed != null && !speed.hasModifier(SURGE_SPEED_ID)) {
                speed.addTransientModifier(new AttributeModifier(SURGE_SPEED_ID, SURGE_SPEED, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
            }
            DamageSource force = ShazamPowers.forceSource(p);
            for (LivingEntity m : enemies(p, p.position(), 6.0)) {   // radiasinya meledak keluar sekali
                m.hurt(force, 10f);
                Vec3 a = away(p.position(), m);
                m.push(a.x * 1.1, 0.35, a.z * 1.1);
                m.hurtMarked = true;
                sicken(m, SICK_TICKS);
            }
            p.displayClientMessage(Component.translatable("message.shazammod.helion_surge")
                    .withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD), true);
            ShazamNetwork.sync(p);
        });
        ShazamNetwork.sync(player);
    }

    // ======================================================================= 0.45 sisa skill, Gerhana Buatan, ejekan
    // L - Lahap Radiasi: menghisap radiasi & nyawa sampai 6 musuh terdekat selama HELION_LAHAP_TICKS
    private static final double LAHAP_RADIUS = 12.0;
    private static final int LAHAP_TARGETS = 6;
    private static final float LAHAP_DAMAGE = 5f;        // tiap 5 tick per musuh (x daya)
    private static final float LAHAP_HEAL = 2.5f;        // darah per musuh per denyut
    private static final float LAHAP_ENERGY = 6f;        // radiasi per musuh per denyut
    private static final double LAHAP_PULL = 0.12;
    // O - Orbit Cryon: enam kristal mengorbit (perisai proyektil), lalu melesat memburu musuh satu per satu
    public static final int ORBIT_SHARDS = 6;
    public static final int ORBIT_SUMMON = 10;           // kristal terbentuk & masuk orbit
    private static final int ORBIT_FIRE_START = 18;
    private static final int ORBIT_FIRE_EVERY = 4;
    private static final double ORBIT_RANGE = 28.0;
    public static final double SHARD_SPEED = 1.6;        // blok/tick
    private static final float SHARD_DAMAGE = 18f;
    private static final double ORBIT_SHIELD_RADIUS = 2.8;
    private static final float ORBIT_CUT_DAMAGE = 6f;
    // N - Nisan Kristal: kristal Cryon meletus berderet TOMB_STEPS x TOMB_STEP blok, musuh terkurung TOMB_TICKS
    public static final int TOMB_STEPS = 11;
    public static final double TOMB_STEP = 1.6;
    private static final double TOMB_WIDTH = 1.9;
    private static final float TOMB_DAMAGE = 24f;
    public static final int TOMB_TICKS = 60;
    private static final float TOMB_SHATTER_DAMAGE = 18f;
    private static final int CRYSTAL_FIELD_TICKS = 120;   // ladang kristal memancarkan radiasi (Helion-6 terisi di dekatnya)
    private static final double CRYSTAL_FIELD_RADIUS = 5.0;
    // J - Gerhana Buatan: matahari ditutup di wilayah ECLIPSE_RADIUS blok selama ECLIPSE_TICKS
    public static final float ECLIPSE_COST = 200f;
    private static final int ECLIPSE_COOLDOWN_TICKS = 1800;
    public static final int ECLIPSE_TICKS = 900;
    public static final double ECLIPSE_RADIUS = 48.0;
    private static final float ECLIPSE_CHARGE = 3f;      // radiasi per detik di bawah gerhana (kegelapan buatan)
    private static final int TAUNT_GAP = 140;            // jeda antar-ejekan biasa (teriakan selalu muncul)

    /** Kalimat ejekan khas komik per kejadian (lines = jumlah variasi di file bahasa, shout = balon teriakan). */
    public enum Taunt {
        TRANSFORM(4, false), LAHAP(3, false), ORBIT(2, false), NISAN(2, false), NOVA(3, true), ECLIPSE(3, true),
        INHALE(3, false), SUN(3, false), BURNOUT(2, false), EYES(2, false), QUAKE(2, true);

        public final int lines;
        public final boolean shout;

        Taunt(int lines, boolean shout) {
            this.lines = lines;
            this.shout = shout;
        }
    }

    /** Wilayah gerhana (pusat, jari-jari, sampai game time). */
    public record Eclipse(Vec3 center, double radius, long until) {}

    private record Tomb(UUID owner, float yaw, long until) {}

    private record Field(Level level, Vec3 pos, long until) {}

    private static final class Orbit {
        final long start;
        int fired;

        Orbit(long start) {
            this.start = start;
        }
    }

    private static final class Nisan {
        final long start;
        final Vec3 origin;
        final Vec3 dir;

        Nisan(long start, Vec3 origin, Vec3 dir) {
            this.start = start;
            this.origin = origin;
            this.dir = dir;
        }
    }

    private static final Map<UUID, Long> LAHAP_UNTIL = new HashMap<>();
    private static final Map<UUID, Orbit> ORBITS = new HashMap<>();
    private static final Map<UUID, Nisan> NISANS = new HashMap<>();
    private static final Map<LivingEntity, Tomb> TOMBS = new HashMap<>();
    private static final List<Field> FIELDS = new ArrayList<>();
    private static final Map<UUID, Long> ECLIPSE_READY_AT = new HashMap<>();
    private static final Map<UUID, Long> TAUNT_READY_AT = new HashMap<>();
    /** Gerhana per dunia: server & client punya objek Level sendiri, jadi daftar mereka nggak tercampur. */
    private static final Map<Level, List<Eclipse>> ECLIPSES = new WeakHashMap<>();

    // ----------------------------------------------------------- ejekan

    /** Balon kata ejekan di atas kepala (dilihat semua pemain di dekatnya). always = abaikan jeda (momen besar). */
    public static void taunt(ServerPlayer player, Taunt taunt, boolean always) {
        long now = player.level().getGameTime();
        Long ready = TAUNT_READY_AT.get(player.getUUID());
        if (!always && ready != null && now < ready) {
            return;
        }
        TAUNT_READY_AT.put(player.getUUID(), now + TAUNT_GAP);
        ShazamNetwork.playAnim(player, ShazamAnim.HELION_TAUNT, new Vec3(taunt.ordinal(), player.getRandom().nextInt(taunt.lines), 0));
    }

    // ----------------------------------------------------------- L - Lahap Radiasi

    private static boolean lahap(ServerPlayer player) {
        if (enemies(player, player.position(), LAHAP_RADIUS).isEmpty()) {
            return false;
        }
        LAHAP_UNTIL.put(player.getUUID(), player.level().getGameTime() + ShazamAnim.HELION_LAHAP_TICKS);
        ShazamNetwork.playAnim(player, ShazamAnim.HELION_LAHAP);
        sound(player, player.position(), ShazamSounds.HELION_LAHAP.get(), 1.8f, 1f);
        taunt(player, Taunt.LAHAP, false);
        return true;
    }

    private static void lahapTick(ServerPlayer player, long now) {
        Long until = LAHAP_UNTIL.get(player.getUUID());
        if (until == null) {
            return;
        }
        if (now >= until) {
            LAHAP_UNTIL.remove(player.getUUID());
            return;
        }
        if ((until - now) % 5 != 0) {
            return;
        }
        List<LivingEntity> near = enemies(player, player.position(), LAHAP_RADIUS);
        near.sort(Comparator.comparingDouble(m -> m.distanceToSqr(player)));
        float power = power(player);
        DamageSource force = ShazamPowers.forceSource(player);
        Vec3 c = chest(player);
        int fed = 0;
        for (LivingEntity m : near) {
            if (fed >= LAHAP_TARGETS) {
                break;
            }
            m.invulnerableTime = 0;
            m.hurt(force, LAHAP_DAMAGE * power);
            m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20, 1, false, false));
            m.addEffect(new MobEffectInstance(MobEffects.GLOWING, 12, 0, false, false));
            Vec3 pull = c.subtract(m.position());
            if (pull.lengthSqr() > 4.0) {
                pull = pull.normalize().scale(LAHAP_PULL);
                m.push(pull.x, 0.02, pull.z);
                m.hurtMarked = true;
            }
            fed++;
        }
        if (fed > 0) {
            player.heal(LAHAP_HEAL * fed * ShazamPowers.healScale(player));
            ShazamData d = ShazamPowers.data(player);
            ShazamPowers.setData(player, d.withEnergy(d.energy() + LAHAP_ENERGY * fed));
        }
    }

    // ----------------------------------------------------------- O - Orbit Cryon

    private static boolean orbit(ServerPlayer player) {
        ORBITS.put(player.getUUID(), new Orbit(player.level().getGameTime()));
        ShazamNetwork.playAnim(player, ShazamAnim.HELION_ORBIT);
        sound(player, player.position(), ShazamSounds.HELION_ORBIT.get(), 1.6f, 1f);
        taunt(player, Taunt.ORBIT, false);
        return true;
    }

    private static void orbitTick(ServerPlayer player, long now) {
        Orbit orbit = ORBITS.get(player.getUUID());
        if (orbit == null) {
            return;
        }
        int t = (int) (now - orbit.start);
        if (t >= ShazamAnim.HELION_ORBIT_TICKS || orbit.fired >= ORBIT_SHARDS) {
            ORBITS.remove(player.getUUID());
            return;
        }
        Vec3 c = chest(player);
        if (t >= ORBIT_SUMMON) {
            for (Projectile shot : player.serverLevel().getEntitiesOfClass(Projectile.class,
                    player.getBoundingBox().inflate(ORBIT_SHIELD_RADIUS), e -> e.getOwner() != player)) {
                ShazamNetwork.playAnim(player, ShazamAnim.HELION_DEFLECT, shot.position());   // kristal menghancurkan proyektil
                shot.discard();
            }
            if (t % 10 == 0) {   // kristal yang berputar menyayat yang terlalu dekat
                DamageSource force = ShazamPowers.forceSource(player);
                for (LivingEntity m : enemies(player, c, ORBIT_SHIELD_RADIUS)) {
                    m.hurt(force, ORBIT_CUT_DAMAGE);
                }
            }
        }
        if (t >= ORBIT_FIRE_START && (t - ORBIT_FIRE_START) % ORBIT_FIRE_EVERY == 0) {
            List<LivingEntity> targets = enemies(player, c, ORBIT_RANGE);
            targets.removeIf(m -> !player.hasLineOfSight(m));
            if (!targets.isEmpty()) {
                targets.sort(Comparator.comparingDouble(m -> m.distanceToSqr(player)));
                fireShard(player, targets.get(orbit.fired % targets.size()));
                orbit.fired++;
            }
        }
    }

    /** Satu kristal melesat ke sasaran; kena sesudah jarak / SHARD_SPEED tick (client menggambar lintasan yang sama). */
    private static void fireShard(ServerPlayer player, LivingEntity target) {
        Vec3 aim = chest(target);
        Vec3 from = chest(player);
        int travel = Math.max(2, (int) Math.ceil(aim.distanceTo(from) / SHARD_SPEED));
        ShazamNetwork.playAnim(player, ShazamAnim.HELION_SHARD, aim);
        sound(player, from, ShazamSounds.HELION_SHARD.get(), 1.0f, 0.9f + player.getRandom().nextFloat() * 0.2f);
        float power = power(player);
        Vec3 dir = aim.subtract(from).lengthSqr() < 1.0E-4 ? Vec3.ZERO : aim.subtract(from).normalize();
        ShazamPowers.schedule(player, travel, p -> {
            if (!target.isAlive()) {
                return;
            }
            target.invulnerableTime = 0;
            target.hurt(ShazamPowers.forceSource(p), SHARD_DAMAGE * power);
            sicken(target, SICK_TICKS);
            target.push(dir.x * 0.6, 0.25, dir.z * 0.6);
            target.hurtMarked = true;
        });
    }

    // ----------------------------------------------------------- N - Nisan Kristal

    private static boolean nisan(ServerPlayer player) {
        Vec3 dir = flat(player.getViewVector(1f));
        Vec3 origin = player.position().add(dir.scale(1.2));
        NISANS.put(player.getUUID(), new Nisan(player.level().getGameTime(), origin, dir));
        ShazamNetwork.playAnim(player, ShazamAnim.HELION_NISAN, dir);   // pos = arah datar deretan kristal
        sound(player, origin, ShazamSounds.HELION_NISAN.get(), 2.2f, 1f);
        taunt(player, Taunt.NISAN, false);
        return true;
    }

    private static void nisanTick(ServerPlayer player, long now) {
        Nisan n = NISANS.get(player.getUUID());
        if (n != null) {
            int step = (int) (now - n.start) - ShazamAnim.HELION_NISAN_WINDUP;
            if (step >= TOMB_STEPS) {
                NISANS.remove(player.getUUID());
            } else if (step >= 0) {
                nisanStep(player, n, step, now);
            }
        }
        tombTick(player, now);
    }

    private static void nisanStep(ServerPlayer player, Nisan n, int step, long now) {
        ServerLevel level = player.serverLevel();
        Vec3 p = n.origin.add(n.dir.scale(step * TOMB_STEP));
        BlockHitResult ground = level.clip(new ClipContext(p.add(0, 2.5, 0), p.add(0, -5.0, 0), ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, player));
        if (ground.getType() == HitResult.Type.MISS) {
            NISANS.remove(player.getUUID());   // jurang: deretan kristal berhenti
            return;
        }
        Vec3 g = ground.getLocation();
        synchronized (FIELDS) {
            FIELDS.add(new Field(level, g, now + CRYSTAL_FIELD_TICKS));
            while (FIELDS.size() > 256) {
                FIELDS.remove(0);
            }
        }
        float power = power(player);
        DamageSource force = ShazamPowers.forceSource(player);
        for (LivingEntity m : level.getEntitiesOfClass(LivingEntity.class, new AABB(g, g).inflate(TOMB_WIDTH, 3.0, TOMB_WIDTH),
                e -> e.isAlive() && e instanceof Enemy && !DemonSoldier.isFriendly(e) && !TOMBS.containsKey(e))) {
            m.invulnerableTime = 0;
            m.hurt(force, TOMB_DAMAGE * power);
            sicken(m, SICK_TICKS);
            TOMBS.put(m, new Tomb(player.getUUID(), m.getYRot(), now + TOMB_TICKS));
            ShazamNetwork.playAnim(player, ShazamAnim.HELION_TOMB_LOCK, new Vec3(m.getId(), TOMB_TICKS, 0));
        }
    }

    /** Musuh yang terkurung kristal diam di tempat (seperti patung es Lintang), lalu kurungannya pecah. */
    private static void tombTick(ServerPlayer player, long now) {
        if (TOMBS.isEmpty()) {
            return;
        }
        List<LivingEntity> shattered = new ArrayList<>();
        TOMBS.entrySet().removeIf(entry -> {
            Tomb tomb = entry.getValue();
            if (!tomb.owner().equals(player.getUUID())) {
                return false;
            }
            LivingEntity mob = entry.getKey();
            if (!mob.isAlive() || mob.isRemoved()) {
                return true;
            }
            if (now >= tomb.until()) {
                shattered.add(mob);
                return true;
            }
            mob.setDeltaMovement(0, Math.min(mob.getDeltaMovement().y, 0), 0);
            mob.setYRot(tomb.yaw());
            mob.setYHeadRot(tomb.yaw());
            mob.yBodyRot = tomb.yaw();
            mob.hurtMarked = true;
            if (mob instanceof Mob m) {
                m.getNavigation().stop();
                m.setTarget(null);
            }
            if (mob instanceof Creeper creeper) {
                creeper.setSwellDir(-1);   // creeper terkurung nggak bisa meledak
            }
            mob.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 10, 6, false, false));
            return false;
        });
        if (shattered.isEmpty()) {
            return;
        }
        float power = power(player);
        DamageSource force = ShazamPowers.forceSource(player);
        for (LivingEntity mob : shattered) {
            Vec3 at = chest(mob);
            mob.invulnerableTime = 0;
            mob.hurt(force, TOMB_SHATTER_DAMAGE * power);
            Vec3 a = away(player.position(), mob);
            mob.push(a.x * 0.9, 0.5, a.z * 0.9);
            mob.hurtMarked = true;
            ShazamNetwork.playAnim(player, ShazamAnim.HELION_TOMB_SHATTER, at);
            sound(player, at, ShazamSounds.HELION_TOMB_SHATTER.get(), 1.4f, 0.9f + player.getRandom().nextFloat() * 0.2f);
        }
    }

    private static boolean nearCrystalField(Level level, Vec3 pos) {
        synchronized (FIELDS) {
            if (FIELDS.isEmpty()) {
                return false;
            }
            long now = level.getGameTime();
            FIELDS.removeIf(f -> f.level() == level && now > f.until());
            for (Field f : FIELDS) {
                if (f.level() == level && f.pos().distanceToSqr(pos) < CRYSTAL_FIELD_RADIUS * CRYSTAL_FIELD_RADIUS) {
                    return true;
                }
            }
            return false;
        }
    }

    // ----------------------------------------------------------- J - Gerhana Buatan

    /** Tombol J Helion-6. */
    public static void eclipse(ServerPlayer player) {
        if (!ShazamPowers.isHelion(player)) {
            if (ShazamPowers.data(player).anyUnlocked()) {
                player.displayClientMessage(Component.translatable("message.shazammod.not_transformed_helion")
                        .withStyle(ChatFormatting.GRAY), true);
            }
            return;
        }
        if (isNovaCharging(player) || eclipseCooldownTicks(player) > 0) {
            return;
        }
        ShazamData data = ShazamPowers.data(player);
        if (data.energy() < ECLIPSE_COST) {
            player.displayClientMessage(Component.translatable("message.shazammod.skill_no_energy", Math.round(ECLIPSE_COST))
                    .withStyle(ChatFormatting.RED), true);
            return;
        }
        ShazamPowers.setData(player, data.withEnergy(data.energy() - ECLIPSE_COST));
        ECLIPSE_READY_AT.put(player.getUUID(), player.level().getGameTime() + ECLIPSE_COOLDOWN_TICKS);
        Vec3 center = player.position();
        ShazamNetwork.playAnim(player, ShazamAnim.HELION_ECLIPSE, center);
        sound(player, center, ShazamSounds.HELION_ECLIPSE.get(), 4.0f, 1f);
        taunt(player, Taunt.ECLIPSE, true);
        later(player, ShazamAnim.HELION_ECLIPSE_WINDUP, p -> {
            addEclipse(p.level(), center, ECLIPSE_RADIUS, p.level().getGameTime() + ECLIPSE_TICKS);
            p.displayClientMessage(Component.translatable("message.shazammod.helion_eclipse", ECLIPSE_TICKS / 20)
                    .withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD), true);
            ShazamNetwork.sync(p);
        });
        ShazamNetwork.sync(player);
    }

    public static int eclipseCooldownTicks(ServerPlayer player) {
        Long ready = ECLIPSE_READY_AT.get(player.getUUID());
        if (ready == null) {
            return 0;
        }
        long left = ready - player.level().getGameTime();
        return left > 0 ? (int) left : 0;
    }

    /** Daftarkan gerhana di dunia ini (server saat aktif; client saat animasinya datang). */
    public static void addEclipse(Level level, Vec3 center, double radius, long until) {
        synchronized (ECLIPSES) {
            ECLIPSES.computeIfAbsent(level, l -> new ArrayList<>()).add(new Eclipse(center, radius, until));
        }
    }

    /** Sisa waktu gerhana (tick) yang menaungi titik ini, 0 kalau nggak ada. Dipakai server & client. */
    public static int eclipseLeft(Level level, Vec3 pos) {
        if (level == null) {
            return 0;
        }
        synchronized (ECLIPSES) {
            List<Eclipse> list = ECLIPSES.get(level);
            if (list == null || list.isEmpty()) {
                return 0;
            }
            long now = level.getGameTime();
            list.removeIf(e -> now >= e.until());
            int best = 0;
            for (Eclipse e : list) {
                if (e.center().distanceToSqr(pos) <= e.radius() * e.radius()) {
                    best = Math.max(best, (int) (e.until() - now));
                }
            }
            return best;
        }
    }

    /** Titik ini sedang di bawah Gerhana Buatan (matahari tertutup). */
    public static boolean eclipsed(Level level, Vec3 pos) {
        return eclipseLeft(level, pos) > 0;
    }

    /** Lonjakan Cryon: tiap detik radiasi dari tubuh melukai musuh yang terlalu dekat. */
    private static void surgeAura(ServerPlayer player) {
        DamageSource force = ShazamPowers.forceSource(player);
        for (LivingEntity m : enemies(player, player.position(), SURGE_AURA_RADIUS)) {
            m.hurt(force, SURGE_AURA_DAMAGE);
            sicken(m, 40);
        }
    }
}
