package com.shazammod.helion3;

import com.shazammod.ShazamMod;

import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/**
 * 0.48 Damage ke Subjek Tiga. Prioritas rendah: pengali tinju juara penyerang (ShazamPowers) sudah dihitung dulu, baru
 * adaptasi, pelat sel mati, kekebalan, & serapan Cryon-nya diterapkan; damage terakhir yang bakal menghabisinya diubah jadi
 * tumbang & bangkit lagi (atau hancur di nyawa terakhir).
 */
@EventBusSubscriber(modid = ShazamMod.MODID)
public final class Helion3Events {
    private Helion3Events() {}

    @SubscribeEvent(priority = EventPriority.LOW)
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        if (event.getEntity() instanceof Helion3 boss) {
            boss.onIncomingDamage(event);
        }
    }

    @SubscribeEvent(priority = EventPriority.LOW)
    public static void onDamagePre(LivingDamageEvent.Pre event) {
        if (event.getEntity() instanceof Helion3 boss) {
            boss.onDamagePre(event);
        }
    }
}
