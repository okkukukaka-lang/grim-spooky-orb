package com.shazammod.client.fx;

import java.util.HashMap;
import java.util.Map;

import com.shazammod.ShazamClientState;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

/**
 * 0.49 Efek yang selalu ada untuk Lintang, Helion-6, dan Subjek Tiga (di luar efek skill mereka), supaya gerak biasa pun
 * terasa "juara":
 *
 *   jejak kaki menyala   tiap langkah meninggalkan tapak cahaya yang memudar: emas hangat (Lintang), hijau radiasi
 *                        (Helion-6), dua warna cahaya & Cryon berselang (Subjek Tiga, lebih besar)
 *   busur pukulan        tiap ayunan tangan menggores udara: busur lebar putih-emas / hijau, atau tiga garis cakar
 *   gores cahaya         saat bergerak kencang: gores keemasan dari kedua matahari bahu (Lintang), gores hijau dari
 *                        kedua mata (Helion-6)
 *   mendarat             cincin tekanan berwarna juaranya + debu saat mendarat dari lompatan (bukan pendaratan terbang,
 *                        itu punya efeknya sendiri)
 *   berlari              debu tersepak & butiran cahaya di kaki saat berlari kencang di tanah
 *
 * Langkah berat, getaran, dan suara Subjek Tiga tetap diurus SubjekFx.
 */
public final class HeroAmbient {
    private HeroAmbient() {}

    private static final int LINTANG = 1, HELION = 2, SUBJEK = 3;
    private static final int GOLD = 0xFFDFA0, GOLD_HOT = 0xFFF6E0;
    private static final int CRYON = HelionFx.CRYON, CRYON_HOT = 0xD6FFE4;
    private static final int DUST = 0x8A7A66;
    private static final Vec3 UP = new Vec3(0, 1, 0);

    private static final class State {
        Vec3 last;
        double walked;
        boolean leftFoot;
        boolean air;
    }

    private static final Map<Integer, State> STATES = new HashMap<>();

    public static void clear() {
        STATES.clear();
    }

    private static int kind(int id) {
        if (!ShazamClientState.isTransformed(id)) {
            return 0;
        }
        return ShazamClientState.isHelion3(id) ? SUBJEK : ShazamClientState.isHelion(id) ? HELION
                : ShazamClientState.isLintang(id) ? LINTANG : 0;
    }

    public static void tick(ClientLevel level) {
        try {
            Minecraft mc = Minecraft.getInstance();
            for (AbstractClientPlayer p : level.players()) {
                int id = p.getId();
                int kind = kind(id);
                if (kind == 0 || p.isInvisible() || p.isPassenger() || p.isSleeping()) {
                    STATES.remove(id);
                    continue;
                }
                State s = STATES.get(id);
                if (s == null) {
                    if (STATES.size() > 64) {
                        STATES.clear();
                    }
                    s = new State();
                    STATES.put(id, s);
                }
                boolean firstPerson = p == mc.player && mc.options.getCameraType().isFirstPerson();
                float old = Vfx.setBoost(1.5f);
                try {
                    ambient(level, p, kind, s, firstPerson);
                } finally {
                    Vfx.setBoost(old);
                }
            }
            STATES.keySet().removeIf(id -> level.getEntity(id) == null);
        } catch (RuntimeException ignored) {
            // efek nggak boleh bikin game crash
        }
    }

    private static void ambient(ClientLevel level, AbstractClientPlayer p, int kind, State s, boolean firstPerson) {
        RandomSource r = level.random;
        int id = p.getId();
        double scale = p.getBbHeight() / 1.8;
        float yaw = p.yBodyRot * Mth.DEG_TO_RAD;
        Vec3 fwd = new Vec3(-Mth.sin(yaw), 0, Mth.cos(yaw));
        Vec3 right = new Vec3(-fwd.z, 0, fwd.x);
        Vec3 now = p.position();
        Vec3 last = s.last;
        s.last = now;
        boolean ground = p.onGround();
        boolean wasAir = s.air;
        s.air = !ground;
        boolean flying = ShazamClientState.isFlying(id);
        int rgb = kind == LINTANG ? GOLD : CRYON;
        int hot = kind == LINTANG ? GOLD_HOT : CRYON_HOT;

        // busur pukulan: tepat saat ayunan dimulai
        if (p.swinging && p.swingTime == 0 && !firstPerson) {
            Vec3 at = now.add(0, p.getBbHeight() * 0.68, 0).add(fwd.scale(0.95 * scale));
            if (kind == SUBJEK) {
                Vfx.add(new SubjekFx.ClawSlash(at, fwd, (float) (1.05 * scale), 0xFFF0E0, 7, r));
            } else {
                Vfx.add(new SubjekFx.ClawSlash(at, fwd, (float) (0.95 * scale), hot, rgb, 1, 6, r));
            }
        }
        if (last == null) {
            return;
        }
        double dx = now.x - last.x, dy = now.y - last.y, dz = now.z - last.z;
        double speed = Math.sqrt(dx * dx + dz * dz);

        // mendarat dari lompatan (pendaratan terbang punya efeknya sendiri; Subjek Tiga diurus SubjekFx)
        if (kind != SUBJEK && ground && wasAir && !flying && -dy > 0.5) {
            float k = (float) Mth.clamp(-dy, 0.5, 1.5);
            Vec3 f = now.add(0, 0.08, 0);
            Vfx.add(new Fx.Wave(f, UP, 1.4 + k * 1.2, 0.2, rgb, 10, 0.5f, 0.04f, null));
            Vfx.add(new Fx.Wave(f, UP, 0.9 + k * 0.8, 0.14, hot, 7, 0.6f, 0f, null));
            ShazamFx.dustPuffs(level, now, DUST, 6, 0.8, 0.1);
        }

        // jejak kaki menyala
        if (ground && !flying && speed > 0.03) {
            s.walked += speed;
            double stride = (kind == SUBJEK ? 1.25 : 0.95) * scale;
            if (s.walked >= stride) {
                s.walked = 0.0;
                s.leftFoot = !s.leftFoot;
                double side = (s.leftFoot ? -1.0 : 1.0) * 0.15 * scale;
                Vec3 at = now.add(right.scale(side));
                int print = kind == SUBJEK ? (s.leftFoot ? CRYON : 0xFFE2A0) : rgb;
                Vfx.add(new Footprint(at, fwd, print, (float) (kind == SUBJEK ? 1.5 * scale : scale), kind == SUBJEK ? 70 : 50));
                if (kind != SUBJEK && r.nextInt(2) == 0) {
                    Vfx.glint(at.x, at.y + 0.1, at.z, hot, 0.1f, 10);
                }
            }
        } else if (!ground) {
            s.walked = 0.0;
        }

        // berlari kencang di tanah: debu tersepak & butiran cahaya
        if (kind != SUBJEK && ground && !flying && speed > 0.3 && p.tickCount % 3 == 0) {
            Vfx.dust(now.x - fwd.x * 0.3, now.y + 0.1, now.z - fwd.z * 0.3, -dx * 0.2 + (r.nextDouble() - 0.5) * 0.04, 0.05,
                    -dz * 0.2 + (r.nextDouble() - 0.5) * 0.04, DUST, 0.3f, 18);
            Vfx.mote(now.x + (r.nextDouble() - 0.5) * 0.5, now.y + 0.15, now.z + (r.nextDouble() - 0.5) * 0.5, 0, 0.04, 0, rgb, 0.06f, 14);
        }

        // gores cahaya saat bergerak kencang
        double fast = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (kind != SUBJEK && fast > 0.28 && !firstPerson) {
            double h = p.getBbHeight();
            for (int k = -1; k <= 1; k += 2) {
                double x, y, z;
                if (kind == LINTANG) {   // dari kedua matahari bahu
                    x = now.x + right.x * 0.4 * scale * k;
                    y = now.y + h * 0.86;
                    z = now.z + right.z * 0.4 * scale * k;
                } else {                 // dari kedua mata
                    Vec3 eye = p.getEyePosition(1f).add(p.getViewVector(1f).scale(0.22 * scale));
                    x = eye.x + right.x * 0.13 * scale * k;
                    y = eye.y;
                    z = eye.z + right.z * 0.13 * scale * k;
                }
                Vfx.streak(x, y, z, -dx * 0.35, -dy * 0.35, -dz * 0.35, kind == LINTANG ? GOLD : CRYON,
                        kind == LINTANG ? 0.07f : 0.045f, 7);
            }
        }
    }

    /** Tapak kaki dari cahaya yang memudar (bola kaki + tumit), menghadap arah langkahnya. */
    static final class Footprint extends Effect {
        private final Vec3 at, fwd;
        private final int rgb;
        private final float size;

        Footprint(Vec3 at, Vec3 fwd, int rgb, float size, int life) {
            super(life);
            this.at = at;
            this.fwd = fwd;
            this.rgb = rgb;
            this.size = size;
        }

        @Override
        public void renderGlow(Draw d) {
            float t = progress(d.partialTick);
            float a = (1f - t) * (1f - t) * 0.55f;
            if (a <= 0.01f) {
                return;
            }
            double y = at.y + 0.03;
            d.disc(at.x + fwd.x * 0.09 * size, y, at.z + fwd.z * 0.09 * size, 0, 1, 0, 0.115 * size, rgb, a, a * 0.15f, null);
            d.disc(at.x - fwd.x * 0.1 * size, y, at.z - fwd.z * 0.1 * size, 0, 1, 0, 0.08 * size, rgb, a * 0.9f, a * 0.1f, null);
            if (t < 0.25f) {   // baru diinjak: pendar sesaat
                d.glow(at.x, y + 0.05, at.z, 0.3f * size, rgb, (0.25f - t) * 1.2f);
            }
        }
    }
}
