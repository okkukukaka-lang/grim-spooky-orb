package com.shazammod.client.fx;

import java.util.HashMap;
import java.util.Map;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.Helion3Rite;
import com.shazammod.Helion3Skills;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamSounds;
import com.shazammod.client.render.Helion3Geo;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Hd;
import com.shazammod.client.vfx.Vfx;
import com.shazammod.helion3.Helion3;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * 0.49 Efek Subjek Tiga (Helion-3) yang bisa dimainkan: kepompong sel mati yang membungkus badan lalu pecah saat berubah
 * wujud, garis cakaran tiga jari, hantaman yang meretakkan tanah, raungan yang menggetarkan udara, kawah lompatan, duri
 * tulang 3D yang meletus melingkar dari tanah (Onak Tulang), debu serudukan, gundukan tanah yang berjalan saat Terobos
 * Tanah, amukan Evolusi Ketiga (api merah darah dari punggung, retakan memerah), radiasi Cryon yang tersedot ke dada,
 * cangkang adaptasi berwarna jenis serangannya, dan tumbang-bangkit di dalam kepompong. Ditambah yang selalu ada: jantung
 * sel mati yang berdenyut di dada (cahaya dua warna), asap & percikan dari retakan, langkah & pendaratan yang berat.
 * Bentuk yang sama (garis cakaran, duri tulang, jantung) dipakai juga oleh bosnya (Helion3Fx).
 */
public final class SubjekFx {
    public static final float BOOST = 1.5f;
    static final int LIGHT = 0xFFE2A0;
    static final int CRYON = HelionFx.CRYON;
    static final int BLOOD = 0xB01818;
    static final int RAGE = 0xFF5030;
    static final int DUST = 0x8A7A66;
    static final int FLESH = 0x4A2A28;
    private static final Vec3 UP = new Vec3(0, 1, 0);

    private static final Map<Integer, Long> FLARE = new HashMap<>();      // id -> waktu kilatan retakan terakhir
    private static final Map<Integer, Long> RITE = new HashMap<>();       // id -> awal Inkubasi Subjek Tiga
    private static final Map<Integer, int[]> CLAWS = new HashMap<>();     // id -> {tumpukan, sisa tick sebelum meluruh}
    private static final Map<Integer, Vec3> LAST_POS = new HashMap<>();
    private static final Map<Integer, Integer> STEP = new HashMap<>();
    private static final Map<Integer, Boolean> AIR = new HashMap<>();
    private static final Map<Integer, Heart> HEARTS = new HashMap<>();
    private static int rootTicks;      // pemain sendiri: tertahan di tempat (kepompong, tumbang, bangkit, inkubasi)
    private static Vec3 rootAt;

    private SubjekFx() {}

    public static void clear() {
        FLARE.clear();
        RITE.clear();
        CLAWS.clear();
        LAST_POS.clear();
        STEP.clear();
        AIR.clear();
        HEARTS.clear();
        rootTicks = 0;
        rootAt = null;
    }

    /** Animasi ini diurus SubjekFx (ShazamFx & ChampionFx melewatinya). */
    public static boolean handles(AbstractClientPlayer caster, ShazamAnim anim) {
        return switch (anim) {
            case SUMMON, TRANSFORM, REVERT, KNOCKOUT, LAUNCH, LAND_HERO, CRASH, SONIC_BOOM, HERO_CALL ->
                    ShazamClientState.isHelion3(caster.getId());
            default -> anim.name().startsWith("SUBJEK_");
        };
    }

    // ------------------------------------------------------------------ angka buat lapisan badan & gerak

    /** Kilatan tambahan di retakan badannya sesudah skill (0..0,6, turun dalam 14 tick). */
    public static float flare(AbstractClientPlayer p, float pt) {
        Long at = FLARE.get(p.getId());
        if (at == null) {
            return 0f;
        }
        float t = p.level().getGameTime() - at + pt;
        return t < 0f || t >= 14f ? 0f : 0.6f * (1f - t / 14f);
    }

    private static void flash(AbstractClientPlayer p) {
        FLARE.put(p.getId(), p.level().getGameTime());
    }

    /** 0..1: urat sel mati yang menjalar di tubuh manusia selama Inkubasi Subjek Tiga. */
    public static float riteVeins(AbstractClientPlayer p, float pt) {
        Long start = RITE.get(p.getId());
        if (start == null) {
            return 0f;
        }
        float t = p.level().getGameTime() - start + pt;
        if (t < 0f || t > Helion3Rite.LENGTH) {
            return 0f;
        }
        return Mth.clamp((t - 4f) / (Helion3Rite.INFECT - 4f), 0f, 1f)
                * Mth.clamp((Helion3Rite.LENGTH - t) / 10f, 0f, 1f);
    }

    /** 0..1: cakar yang menguat oleh Cryon. Pemain sendiri: angka pasti dari server; pemain lain: perkiraan dari animasinya. */
    public static float claws(AbstractClientPlayer p) {
        if (p == Minecraft.getInstance().player) {
            return ShazamClientState.subjekClaws() / (float) Helion3Skills.CLAW_MAX;
        }
        int[] c = CLAWS.get(p.getId());
        return c == null ? 0f : c[0] / (float) Helion3Skills.CLAW_MAX;
    }

    /** Sebelum gerak pemain sendiri dihitung: selama tertahan, badannya ditarik balik ke titik semula. */
    public static void preTick(LocalPlayer player) {
        if (rootTicks <= 0 || rootAt == null) {
            return;
        }
        double ox = rootAt.x - player.getX(), oz = rootAt.z - player.getZ();
        if (ox * ox + oz * oz > 6.25) {
            // sudah dipindahkan server (muncul dari tanah di titik lain, teleport, terlempar jauh): jangan ditarik balik,
            // nanti badannya melesat ke titik lama dan ditolak server
            rootTicks = 0;
            return;
        }
        rootTicks--;
        Vec3 v = player.getDeltaMovement();
        player.setDeltaMovement(ox * 0.6, Math.min(v.y, 0.0), oz * 0.6);
    }

    private static void root(AbstractClientPlayer p, int ticks) {
        if (p == Minecraft.getInstance().player) {
            rootTicks = ticks;
            rootAt = p.position();
        }
    }

    // ------------------------------------------------------------------ alat bantu

    private static void schedule(int delay, int duration, ShazamFx.Step step) {
        ShazamFx.schedule(delay, duration, step);
    }

    private static Vec3 chest(LivingEntity e) {
        return e.position().add(0, e.getBbHeight() * 0.62, 0);
    }

    private static Vec3 forward(LivingEntity e) {
        float yaw = e.yBodyRot * Mth.DEG_TO_RAD;
        return new Vec3(-Mth.sin(yaw), 0, Mth.cos(yaw));
    }

    private static void word(Vec3 at, String text, float size) {
        HelionComic.word(at, text, 0xFFFFFF, BLOOD, size);
    }

    private static int twoTone(RandomSource r) {
        return r.nextBoolean() ? LIGHT : CRYON;
    }

    /** Serpihan sel mati beterbangan dari satu titik. */
    private static void fleshBurst(ClientLevel level, Vec3 c, int count, double speed, double floorY) {
        RandomSource r = level.random;
        for (int i = 0, n = Vfx.count(count); i < n; i++) {
            Vec3 v = ShazamFx.randomDir(r).scale(speed * (0.5 + r.nextDouble()));
            Vfx.shard(c.x, c.y, c.z, v.x, Math.abs(v.y) + speed * 0.5, v.z, r.nextInt(3) == 0 ? 0x7A6E62 : FLESH,
                    0.14f + r.nextFloat() * 0.12f, 30 + r.nextInt(10), floorY);
        }
    }

    /** Garis cakaran + kilat + percikan dua warna di titik kena. */
    static void slashHit(ClientLevel level, Vec3 at, Vec3 facing, float size) {
        RandomSource r = level.random;
        Vfx.add(new ClawSlash(at, facing, 1.1f * size, 0xFFF4E0, 9, r));
        Vfx.add(new Fx.Flash(at, 1.2f * size, 0xFFE8D0, 4, 0.85f));
        Vfx.add(new Fx.Flash(at, 2.0f * size, BLOOD, 7, 0.35f));
        CineKit.sparks(at, (int) (10 * size), twoTone(r), 0.38, 0.065f, 10, at.y - 2.0);
    }

    // ------------------------------------------------------------------ animasi dari server

    public static void onAnim(AbstractClientPlayer caster, ShazamAnim anim, Vec3 pos) {
        if (!handles(caster, anim)) {
            return;
        }
        float old = Vfx.setBoost(BOOST);
        try {
            onAnim0(caster, anim, pos);
        } catch (RuntimeException ignored) {
            // efek nggak boleh bikin game crash
        } finally {
            Vfx.setBoost(old);
        }
    }

    private static void onAnim0(AbstractClientPlayer caster, ShazamAnim anim, Vec3 pos) {
        boolean self = caster == Minecraft.getInstance().player;
        switch (anim) {
            case TRANSFORM -> transform(caster, self);
            case REVERT -> revert(caster);
            case KNOCKOUT -> knockout(caster, self);
            case HERO_CALL -> heroCall(pos);
            case SUBJEK_RITE -> rite(caster, self);
            case SUBJEK_SMASH -> smash(caster);
            case SUBJEK_HIT -> hit(caster, pos, 1f);
            case SUBJEK_PUNCH -> punch(caster, pos);
            case SUBJEK_POUND -> pound(caster, pos, self);
            case SUBJEK_ROAR -> schedule(ShazamAnim.SUBJEK_ROAR_HIT, 1, (level, t) -> {
                Helion3Fx.roar(level, caster, 1.1f);
                flash(caster);
            });
            case SUBJEK_LEAP -> leap(caster, self);
            case SUBJEK_SLAM -> slam(caster, pos, self);
            case SUBJEK_COCOON -> cocoon(caster, self);
            case SUBJEK_BURST -> burst(caster, pos, self);
            case SUBJEK_SPIKES -> spikes(caster, self);
            case SUBJEK_CHARGE -> charge(caster, self);
            case SUBJEK_CRASH -> crash(pos);
            case SUBJEK_RAGE -> rage(caster, self);
            case SUBJEK_RAGE_END -> rageEnd(caster);
            case SUBJEK_ABSORB -> absorb(caster);
            case SUBJEK_BURROW -> burrow(caster, pos);
            case SUBJEK_EMERGE -> emerge(caster, pos, self);
            case SUBJEK_FALL -> fall(caster, self);
            case SUBJEK_REVIVE -> revive(caster, self);
            case SUBJEK_ADAPT -> adapt(caster, pos);
            case SUBJEK_IMMUNE -> immune(caster, pos);
            case SUBJEK_THORN -> thorn(caster, pos);
            case SUBJEK_PULSE -> pulse(caster);
            default -> { }
        }
    }

    /** Detak jantung di tanah: cincin dua warna yang makin cepat (interval dari umur efeknya). */
    private static void heartbeat(ClientLevel level, LivingEntity e, int t, int total) {
        int beat = t < total / 2 ? 14 : t < total * 4 / 5 ? 9 : 5;
        if (t % beat == 0) {
            Vec3 f = e.position();
            Vfx.add(new Fx.Wave(f.add(0, 0.08, 0), UP, 2.0 + t * 0.03, 0.22, t % 2 == 0 ? LIGHT : CRYON, 12, 0.5f, 0.05f, null));
            ShazamFx.shakeAround(f, 0.08f + t * 0.003f, 20);
        }
    }

    /** Serpihan sel mati hitam merayap naik mengelilingi badan. */
    private static void crawl(ClientLevel level, LivingEntity e, float strength) {
        RandomSource r = level.random;
        for (int i = 0, n = Vfx.count(2 + 3 * strength); i < n; i++) {
            double a = r.nextDouble() * Math.PI * 2.0, d = 0.35 + r.nextDouble() * 0.5;
            Vfx.cinder(e.getX() + Math.cos(a) * d, e.getY() + r.nextDouble() * e.getBbHeight() * 0.6, e.getZ() + Math.sin(a) * d,
                    -Math.sin(a) * 0.04, 0.05 + r.nextDouble() * 0.05, Math.cos(a) * 0.04, r.nextInt(4) == 0 ? 0x6A2A2A : 0x1E1416,
                    0.1f + r.nextFloat() * 0.08f, 22, -0.02f);
        }
    }

    /** Berubah wujud: sel mati membungkus badan jadi kepompong, lalu pecah & monsternya meraung. */
    private static void transform(AbstractClientPlayer caster, boolean self) {
        int burst = ShazamAnim.SUBJEK_MORPH_BURST;
        Vfx.add(new Helion3Fx.Cocoon(caster, burst, 9));
        root(caster, burst);
        schedule(0, burst, (level, t) -> {
            crawl(level, caster, t / (float) burst);
            heartbeat(level, caster, t, burst);
        });
        schedule(burst, 1, (level, t) -> {
            Vec3 c = chest(caster);
            fleshBurst(level, c, 34, 0.3, caster.getY());
            Vfx.add(new Hd.Nova(c, 2.4, 0xFFFFFF, LIGHT, CRYON, 0x2A2420, 22, 0.8f, false));
            Helion3Fx.ground(level, caster.position(), 1.4, twoTone(level.random));
            Helion3Fx.roar(level, caster, 0.85f);
            flash(caster);
            if (self) {
                FovKick.punch(0.2f);
                HelionComic.caption(Component.translatable("caption.shazammod.subjek"));
            }
        });
    }

    /** Balik jadi manusia: sel mati mengelupas & luruh jadi abu. */
    private static void revert(AbstractClientPlayer caster) {
        schedule(0, 10, (level, t) -> {
            Vec3 c = chest(caster);
            HdKit.cinders(c, 8, 0.5, 0.01, FLESH, 0.12f, 30, 0.03f);
            if (t % 3 == 0) {
                ShazamFx.smokeCloud(level, c, 0x2A2224, 2, 0.5);
            }
        });
        CLAWS.remove(caster.getId());
    }

    private static void knockout(AbstractClientPlayer caster, boolean self) {
        CLAWS.remove(caster.getId());
        schedule(0, 1, (level, t) -> {
            Vec3 c = chest(caster);
            fleshBurst(level, c, 40, 0.28, caster.getY());
            HdKit.cinders(c, 30, 0.8, 0.03, FLESH, 0.14f, 40, 0.03f);
            Helion3Fx.ground(level, caster.position(), 1.0, DUST);
            word(c.add(0, 1.2, 0), "THOOOM...", 1.3f);
            ShazamFx.shakeAround(c, 0.5f, 30);
            if (self) {
                ScreenFx.vignette(0.5f, 0x3A0808, 30);
            }
        });
    }

    private static void heroCall(Vec3 pos) {
        Vfx.add(new Fx.Wave(pos, UP, 1.3, 0.2, 0xFFFFFF, 14, 0.6f, 0f, null));
        HelionComic.word(pos.add(0, 0.9, 0), "!", 0xFFFFFF, BLOOD, 1.1f);
    }

    /** Inkubasi Subjek Tiga (wujud manusia): urat menghitam, kepompong tumbuh menutup, jantungnya makin cepat, lalu pecah. */
    private static void rite(AbstractClientPlayer caster, boolean self) {
        RITE.put(caster.getId(), caster.level().getGameTime());
        root(caster, Helion3Rite.EMERGE);
        schedule(0, Helion3Rite.EMERGE, (level, t) -> {
            if (t < Helion3Rite.COCOON) {
                crawl(level, caster, t / (float) Helion3Rite.COCOON);
            }
            if (t == Helion3Rite.INFECT) {
                Vfx.add(new Helion3Fx.Cocoon(caster, Helion3Rite.EMERGE - Helion3Rite.INFECT, Helion3Rite.COCOON - Helion3Rite.INFECT));
            }
            heartbeat(level, caster, t, Helion3Rite.EMERGE);
            if (self && t % 20 == 0) {
                ScreenFx.vignette(0.25f + 0.3f * t / Helion3Rite.EMERGE, 0x2A0A10, 22);
            }
        });
        schedule(Helion3Rite.EMERGE, 1, (level, t) -> {
            Vec3 c = chest(caster);
            fleshBurst(level, c, 44, 0.32, caster.getY());
            Vfx.add(new Hd.Nova(c, 3.0, 0xFFFFFF, LIGHT, CRYON, 0x2A2420, 28, 0.9f, false));
            Helion3Fx.ground(level, caster.position(), 1.8, twoTone(level.random));
            Helion3Fx.roar(level, caster, 0.8f);
            if (self) {
                FovKick.punch(0.25f);
                ScreenFlash.flash(0.35f, 0xFFE8D0);
                HelionComic.caption(Component.translatable("caption.shazammod.subjek_rite"));
            }
        });
    }

    /** Hantam: ayunan cakar kanan lalu kiri di depan badan (kenanya sendiri lewat SUBJEK_HIT / SUBJEK_POUND). */
    private static void smash(AbstractClientPlayer caster) {
        for (int k = 0; k < 2; k++) {
            int at = k == 0 ? ShazamAnim.SUBJEK_SMASH_HIT1 : ShazamAnim.SUBJEK_SMASH_HIT2;
            schedule(Math.max(0, at - 1), 1, (level, t) -> {
                Vec3 f = forward(caster);
                Vfx.add(new ClawSlash(chest(caster).add(f.scale(1.5)), f, 1.3f, 0xFFF0E0, 7, level.random));
            });
        }
    }

    private static void hit(AbstractClientPlayer caster, Vec3 pos, float size) {
        schedule(0, 1, (level, t) -> {
            Vec3 f = pos.subtract(caster.position());
            slashHit(level, pos, new Vec3(f.x, 0, f.z), size);
            Vfx.add(new Fx.Wave(pos, ShazamFx.randomDir(level.random), 2.0 * size, 0.16, 0xFFFFFF, 8, 0.7f, 0f, null));
            word(pos.add(0, 0.6, 0), HelionComic.pick(new String[] {"SMASH!", "KRAK!", "WHAM!", "KRESH!"}), 1.1f * size);
            ShazamFx.shakeAround(pos, 0.3f * size, 18);
        });
    }

    private static void punch(AbstractClientPlayer caster, Vec3 pos) {
        schedule(0, 1, (level, t) -> {
            Vec3 f = pos.subtract(caster.position());
            slashHit(level, pos, new Vec3(f.x, 0, f.z), 0.75f);
            if (level.random.nextInt(3) == 0) {
                word(pos.add(0, 0.5, 0), HelionComic.pick(new String[] {"SRAK!", "KRAK!", "SLASH!"}), 0.85f);
            }
            ShazamFx.shakeAround(pos, 0.15f, 12);
        });
    }

    private static void pound(AbstractClientPlayer caster, Vec3 pos, boolean self) {
        schedule(0, 1, (level, t) -> {
            Helion3Fx.ground(level, pos, 1.8, twoTone(level.random));
            CineKit.shock(level, pos.add(0, 0.1, 0), UP, Helion3Skills.POUND_RADIUS, DUST, 0xFFFFFF, 16, 0.9f, true);
            Vfx.add(new BoneSpikes(level, pos, 1.2, Helion3Skills.POUND_RADIUS * 0.75, 12, 46, 3, level.random));
            word(pos.add(0, 1.6, 0), "BOOM!", 1.4f);
            ShazamFx.shakeAround(pos, 0.6f, 30);
            flash(caster);
            if (self) {
                HelionComic.impact(pos, 0.6f);
            }
        });
    }

    private static void leap(AbstractClientPlayer caster, boolean self) {
        Vec3 f = caster.position();
        schedule(ShazamAnim.SUBJEK_LEAP_WINDUP, 1, (level, t) -> {
            Helion3Fx.ground(level, f, 1.0, DUST);
            CineKit.shock(level, f.add(0, 0.1, 0), UP, 4.0, DUST, 0xFFFFFF, 12, 0.6f, true, true);
            ShazamFx.shakeAround(f, 0.3f, 24);
        });
        schedule(ShazamAnim.SUBJEK_LEAP_WINDUP, ShazamAnim.SUBJEK_LEAP_TICKS, (level, t) -> {   // asap & bara tertinggal di udara
            Vec3 c = chest(caster);
            RandomSource r = level.random;
            Vfx.smoke(c.x + (r.nextDouble() - 0.5), c.y - 0.5, c.z + (r.nextDouble() - 0.5), 0, -0.02, 0, 0x4A4440, 0.5f, 24);
            if (t % 2 == 0) {
                Vfx.ember(c.x, c.y, c.z, (r.nextDouble() - 0.5) * 0.1, 0.02, (r.nextDouble() - 0.5) * 0.1, 0.06f, 14);
            }
            if (self) {
                ScreenFx.speedLines(0.5f);
            }
        });
    }

    private static void slam(AbstractClientPlayer caster, Vec3 pos, boolean self) {
        schedule(0, 1, (level, t) -> {
            Ground.Map g = ShazamFx.ground(level, pos, 9.0);
            Vec3 c = g != null ? g.center(pos) : pos;
            CineKit.burst(c.add(0, 0.6, 0), 2.0f, 0xFFD8B0, 0xFFFFFF, 10, 0.9f);
            for (int i = 0; i < 2; i++) {
                Vfx.add(new Fx.Wave(c, UP, 5.0 + i * 3.0, 0.5 + i * 0.3, i == 0 ? 0xFFFFFF : DUST, 14 + i * 6, 0.85f - i * 0.2f,
                        0.06f, g));
            }
            CineKit.shock(level, c, UP, Helion3Skills.SLAM_RADIUS + 1.5, DUST, 0xFFFFFF, 20, 1f, true);
            Helion3Fx.ground(level, c, 2.4, twoTone(level.random));
            Vfx.add(new Hd.DustBurst(c, 3.6, DUST, 40, 0.9f, true));
            Vfx.add(new BoneSpikes(level, c, 1.6, Helion3Skills.SLAM_RADIUS * 0.7, 16, 56, 2, level.random));
            word(c.add(0, 1.8, 0), "KRAKATHOOM!", 1.7f);
            ShazamFx.shakeAround(c, 0.8f, 40);
            flash(caster);
            if (self) {
                HelionComic.impact(c, 0.9f);
                FovKick.punch(0.18f);
            }
        });
    }

    /** Inkubasi: kepompong sel mati, jantungnya makin cepat, butiran penyembuh naik dari tanah. */
    private static void cocoon(AbstractClientPlayer caster, boolean self) {
        int life = ShazamAnim.SUBJEK_COCOON_TICKS;
        Vfx.add(new Helion3Fx.Cocoon(caster, life, 10));
        root(caster, life);
        schedule(0, life, (level, t) -> {
            heartbeat(level, caster, t, life);
            if (t % 3 == 0) {
                RandomSource r = level.random;
                double a = r.nextDouble() * Math.PI * 2.0, d = 0.9 + r.nextDouble() * 0.9;
                Vfx.mote(caster.getX() + Math.cos(a) * d, caster.getY() + 0.1, caster.getZ() + Math.sin(a) * d,
                        -Math.cos(a) * 0.03, 0.05, -Math.sin(a) * 0.03, twoTone(r), 0.09f, 20);
            }
        });
        if (self) {
            ScreenFx.vignette(0.4f, 0x200A0E, life);
        }
    }

    /** Kepompong pecah (Inkubasi selesai / bangkit lagi). */
    private static void burst(AbstractClientPlayer caster, Vec3 pos, boolean self) {
        schedule(0, 1, (level, t) -> {
            Vec3 c = chest(caster);
            fleshBurst(level, c, 36, 0.32, caster.getY());
            Vfx.add(new Hd.Nova(c, 2.8, 0xFFFFFF, LIGHT, CRYON, 0x2A2420, 24, 0.85f, false));
            CineKit.shock(level, pos.add(0, 0.1, 0), UP, Helion3Skills.COCOON_BURST_RADIUS, DUST, 0xFFE8D8, 16, 0.9f, true);
            Helion3Fx.ground(level, pos, 1.3, twoTone(level.random));
            word(c.add(0, 1.4, 0), "KRRAKK!", 1.4f);
            ShazamFx.shakeAround(c, 0.6f, 32);
            flash(caster);
            if (self) {
                FovKick.punch(0.15f);
            }
        });
    }

    /** Onak Tulang: kedua cakar menancap, retakan menjalar, lalu duri tulang meletus melingkar dari tanah. */
    private static void spikes(AbstractClientPlayer caster, boolean self) {
        Vec3 f = caster.position();
        schedule(2, 1, (level, t) -> {
            Ground.Map g = ShazamFx.ground(level, f, 4.0);
            if (g != null && g.found) {
                Vfx.add(new Ground.Cracks(g.center(f), g, 9, (float) Helion3Skills.SPIKE_RADIUS * 0.8f, 150, 40,
                        twoTone(level.random), level.random.nextLong()));
            }
        });
        schedule(ShazamAnim.SUBJEK_SPIKES_WINDUP, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vfx.add(new BoneSpikes(level, c, 1.5, Helion3Skills.SPIKE_RADIUS, 46, 74, 5, level.random));
            Helion3Fx.ground(level, c, 1.6, twoTone(level.random));
            CineKit.shock(level, c.add(0, 0.1, 0), UP, Helion3Skills.SPIKE_RADIUS + 0.5, DUST, 0xFFFFFF, 16, 0.85f, true);
            ShazamFx.dustPuffs(level, c, DUST, 26, Helion3Skills.SPIKE_RADIUS * 0.6, 0.22);
            word(c.add(0, 2.2, 0), "SHRRAKK!", 1.5f);
            ShazamFx.shakeAround(c, 0.6f, 32);
            flash(caster);
            if (self) {
                HelionComic.impact(c, 0.5f);
            }
        });
    }

    private static void charge(AbstractClientPlayer caster, boolean self) {
        schedule(0, 1, (level, t) -> word(chest(caster).add(0, 1.2, 0), "RRRAAAH!", 1.2f));
        schedule(ShazamAnim.SUBJEK_CHARGE_WINDUP, ShazamAnim.SUBJEK_CHARGE_TICKS, (level, t) -> {   // debu & tanah tersepak
            Vec3 f = caster.position();
            RandomSource r = level.random;
            for (int i = 0, n = Vfx.count(3); i < n; i++) {
                Vfx.dust(f.x + (r.nextDouble() - 0.5) * 1.4, f.y + 0.1, f.z + (r.nextDouble() - 0.5) * 1.4, (r.nextDouble() - 0.5) * 0.1,
                        0.06 + r.nextDouble() * 0.06, (r.nextDouble() - 0.5) * 0.1, DUST, 0.5f, 26);
            }
            if (t % 3 == 0) {
                ShazamFx.shakeAround(f, 0.2f, 24);
                level.playLocalSound(f.x, f.y, f.z, ShazamSounds.HELION3_STEP.get(), SoundSource.PLAYERS, 1.4f,
                        1.1f + r.nextFloat() * 0.2f, false);
            }
            if (self) {
                ScreenFx.speedLines(0.7f);
            }
        });
    }

    private static void crash(Vec3 pos) {
        schedule(0, 1, (level, t) -> {
            Vfx.add(new Fx.Flash(pos, 1.6f, 0xFFE8D0, 5, 0.9f));
            RandomSource r = level.random;
            for (int i = 0, n = Vfx.count(22); i < n; i++) {
                Vec3 v = ShazamFx.randomDir(r).scale(0.2 + r.nextDouble() * 0.3);
                Vfx.shard(pos.x, pos.y + 0.8, pos.z, v.x, Math.abs(v.y) + 0.12, v.z, 0x6A625A, 0.16f + r.nextFloat() * 0.1f, 30, pos.y - 1.0);
            }
            Helion3Fx.ground(level, pos, 1.5, DUST);
            CineKit.shock(level, pos.add(0, 0.1, 0), UP, Helion3Skills.CRASH_RADIUS, DUST, 0xFFFFFF, 14, 0.8f, true);
            word(pos.add(0, 1.4, 0), "KRUNCH!", 1.3f);
            ShazamFx.shakeAround(pos, 0.6f, 30);
        });
    }

    /** Evolusi Ketiga: cahaya & Cryon tersedot ke dada, jantungnya menggila, lalu amukannya meledak. */
    private static void rage(AbstractClientPlayer caster, boolean self) {
        int wind = ShazamAnim.SUBJEK_RAGE_WINDUP;
        root(caster, wind);
        schedule(0, wind, (level, t) -> {
            Vec3 c = chest(caster);
            HdKit.streaksIn(c, 4, 3.0, t % 2 == 0 ? LIGHT : CRYON, 0.05f, 8);
            heartbeat(level, caster, t, wind);
            crawl(level, caster, 0.6f);
        });
        schedule(wind, 1, (level, t) -> {
            Vec3 c = chest(caster);
            Vec3 f = caster.position();
            Helion3Fx.roar(level, caster, 1.3f);
            Vfx.add(new Hd.Nova(c, 3.4, 0xFFFFFF, RAGE, BLOOD, 0x2A1410, 30, 1f, false));
            Vfx.add(new Fx.Pillar(f, 7.0, 1.6f, RAGE, 18));
            Helion3Fx.ground(level, f, 2.2, RAGE);
            word(c.add(0, 2.2, 0), "EVOLUSI!", 1.9f);
            flash(caster);
            if (self) {
                ScreenFlash.flash(0.45f, 0xFF4030);
                ScreenFx.vignette(0.5f, 0x5A0808, 40);
                FovKick.punch(0.25f);
                HelionComic.caption(Component.translatable("caption.shazammod.subjek_rage"));
            }
        });
    }

    private static void rageEnd(AbstractClientPlayer caster) {
        schedule(0, 8, (level, t) -> {
            Vec3 c = chest(caster);
            ShazamFx.smokeCloud(level, c, 0x3A3030, 2, 0.6);
            HdKit.cinders(c, 4, 0.5, 0.04, 0x5A2A22, 0.1f, 26, -0.01f);
        });
    }

    /** Serap Cryon: pecahan diremukkan di dada, radiasinya tersedot masuk, cakarnya menghijau. */
    private static void absorb(AbstractClientPlayer caster) {
        schedule(0, ShazamAnim.SUBJEK_ABSORB_WINDUP, (level, t) -> {
            Vec3 c = chest(caster).add(forward(caster).scale(0.35));
            HdKit.streaksIn(c, 5, 2.2, CRYON, 0.05f, 6);
            if (t == 4) {
                CineKit.sparks(c, 16, CRYON, 0.3, 0.06f, 12, caster.getY());
                HdKit.shards(c, 10, 0.2, 0x2FAE6A, 0.1f, 22, caster.getY());
            }
        });
        schedule(ShazamAnim.SUBJEK_ABSORB_WINDUP, 1, (level, t) -> {
            Vec3 c = chest(caster);
            Vfx.add(new Fx.Flash(c, 2.2f, CRYON, 8, 0.8f));
            Vfx.add(new Helion3Fx.Shell(caster, CRYON, 18, 0.7f));
            HelionComic.word(c.add(0, 1.2, 0), "SHHLURP!", 0x8CFF6A, 0x1A3A22, 1.1f);
            int[] claw = CLAWS.computeIfAbsent(caster.getId(), id -> new int[2]);
            claw[0] = Math.min(Helion3Skills.CLAW_MAX, claw[0] + 2);
            claw[1] = 1200;
            flash(caster);
        });
    }

    /** Terobos Tanah: menyelam (tanah menyembur), gundukan retak berjalan ke titik bidik. */
    private static void burrow(AbstractClientPlayer caster, Vec3 out) {
        Vec3 from = caster.position();
        int dive = ShazamAnim.SUBJEK_BURROW_DIVE, travel = ShazamAnim.SUBJEK_BURROW_TICKS;
        root(caster, dive + travel);
        schedule(0, dive, (level, t) -> {
            Ground.Map g = ShazamFx.ground(level, from, 3.0);
            int dust = g != null && g.found ? g.dustColor(level, from) : DUST;
            LintangFilm.dirtSprays(from.add(0, 0.05, 0), 4, 0.24, dust);
            ShazamFx.dustPuffs(level, from, dust, 5, 0.9, 0.12);
            if (t == 0 && g != null && g.found) {
                Vfx.add(new Ground.Debris(g.center(from), g, 12, 0.2, 0.36, 0.7, 50));
                Vfx.add(new Fx.Scorch(g.center(from), 1.3, 160, 1, g));
            }
            ShazamFx.shakeAround(from, 0.25f, 20);
        });
        schedule(dive, travel, (level, t) -> {
            Vec3 p = from.lerp(out, (t + 1) / (double) travel);
            Ground.Map g = ShazamFx.ground(level, p, 2.0);
            Vec3 c = g != null && g.found ? g.center(p) : p;
            int dust = g != null && g.found ? g.dustColor(level, p) : DUST;
            LintangFilm.dirtSprays(c, 3, 0.2, dust);
            ShazamFx.dustPuffs(level, c, dust, 4, 0.7, 0.1);
            if (t % 3 == 0 && g != null && g.found) {
                Vfx.add(new Ground.Cracks(c, g, 4, 1.6f, 90, 1, DUST, level.random.nextLong()));
            }
            ShazamFx.shakeAround(c, 0.18f, 18);
        });
    }

    private static void emerge(AbstractClientPlayer caster, Vec3 pos, boolean self) {
        schedule(0, 1, (level, t) -> {
            Helion3Fx.ground(level, pos, 2.2, twoTone(level.random));
            CineKit.shock(level, pos.add(0, 0.1, 0), UP, Helion3Skills.EMERGE_RADIUS + 1.0, DUST, 0xFFFFFF, 18, 0.95f, true);
            Vfx.add(new Hd.DustBurst(pos, 3.2, DUST, 36, 0.9f, true));
            Vfx.add(new BoneSpikes(level, pos, 1.4, Helion3Skills.EMERGE_RADIUS * 0.7, 12, 50, 2, level.random));
            word(pos.add(0, 2.0, 0), "GRAAKK-OOM!", 1.6f);
            ShazamFx.shakeAround(pos, 0.75f, 36);
            flash(caster);
            if (self) {
                rootTicks = 0;
                HelionComic.impact(pos, 0.7f);
            }
        });
    }

    private static void fall(AbstractClientPlayer caster, boolean self) {
        root(caster, ShazamAnim.SUBJEK_FALL_TICKS + ShazamAnim.SUBJEK_REVIVE_TICKS);
        schedule(10, 1, (level, t) -> {
            Helion3Fx.ground(level, caster.position(), 1.2, DUST);
            word(chest(caster).add(0, 1.0, 0), "THOOOM...", 1.3f);
            ShazamFx.shakeAround(caster.position(), 0.4f, 30);
        });
        if (self) {
            ScreenFx.vignette(0.6f, 0x300608, ShazamAnim.SUBJEK_FALL_TICKS + ShazamAnim.SUBJEK_REVIVE_BURST);
        }
    }

    private static void revive(AbstractClientPlayer caster, boolean self) {
        int life = ShazamAnim.SUBJEK_REVIVE_BURST;
        Vfx.add(new Helion3Fx.Cocoon(caster, life, 12));
        schedule(0, life, (level, t) -> heartbeat(level, caster, t, life));
        schedule(life, 1, (level, t) -> {
            Helion3Fx.roar(level, caster, 1f);
            if (self) {
                HelionComic.caption(Component.translatable("caption.shazammod.subjek_revive"));
            }
        });
    }

    /** Adaptasi: cangkang sel mati mengeras dengan warna jenis serangannya (data.y = 1: kebal total). */
    private static void adapt(AbstractClientPlayer caster, Vec3 data) {
        Helion3.Kind[] kinds = Helion3.Kind.values();
        int rgb = kinds[Mth.clamp((int) Math.round(data.x), 0, kinds.length - 1)].rgb;
        boolean total = data.y > 0.5;
        Vfx.add(new Helion3Fx.Shell(caster, rgb, total ? 40 : 24, total ? 1f : 0.6f));
        flash(caster);
        schedule(0, 1, (level, t) -> {
            Vec3 c = chest(caster);
            fleshBurst(level, c, total ? 18 : 9, 0.16, caster.getY());
            CineKit.sparks(c, total ? 24 : 12, rgb, 0.35, 0.06f, 12, caster.getY());
            word(c.add(0, 1.4, 0), total ? "KEBAL!" : "ADAPTASI!", total ? 1.5f : 1.1f);
        });
    }

    private static void immune(AbstractClientPlayer caster, Vec3 data) {
        Helion3.Kind[] kinds = Helion3.Kind.values();
        int rgb = kinds[Mth.clamp((int) Math.round(data.x), 0, kinds.length - 1)].rgb;
        Vfx.add(new Helion3Fx.Shell(caster, rgb, 8, 0.5f));
        if (Vfx.random().nextInt(3) == 0) {
            HelionComic.word(chest(caster).add(0, 1.0, 0), "TAK MEMPAN!", 0xFFFFFF, 0x404048, 0.9f);
        }
    }

    /** Duri Sel Mati menusuk penyerang: serpihan tulang & kilat merah di badan penyerangnya. */
    private static void thorn(AbstractClientPlayer caster, Vec3 pos) {
        schedule(0, 1, (level, t) -> {
            RandomSource r = level.random;
            Vfx.add(new Fx.Flash(pos, 1.0f, BLOOD, 5, 0.7f));
            for (int i = 0, n = Vfx.count(8); i < n; i++) {
                Vec3 v = ShazamFx.randomDir(r).scale(0.18 + r.nextDouble() * 0.15);
                Vfx.shard(pos.x, pos.y, pos.z, v.x, Math.abs(v.y) + 0.06, v.z, 0xC8BCA6, 0.09f, 18, pos.y - 1.5);
            }
            if (r.nextInt(4) == 0) {
                word(pos.add(0, 0.5, 0), "JLEB!", 0.8f);
            }
        });
    }

    /** Regenerasi Sel Mati: satu detak jantung terlihat di tanah. */
    private static void pulse(AbstractClientPlayer caster) {
        if (caster.isInvisible()) {
            return;
        }
        Vec3 f = caster.position();
        RandomSource r = Vfx.random();
        Vfx.add(new Fx.Wave(f.add(0, 0.08, 0), UP, 1.7, 0.18, twoTone(r), 12, 0.35f, 0.03f, null));
        for (int i = 0; i < 3; i++) {
            double a = r.nextDouble() * Math.PI * 2.0;
            Vfx.mote(f.x + Math.cos(a) * 0.6, f.y + 0.2, f.z + Math.sin(a) * 0.6, 0, 0.05, 0, twoTone(r), 0.07f, 16);
        }
    }

    // ------------------------------------------------------------------ tiap tick

    /** Muatan penuh (Cakar Maut siap): percikan dua warna menetes dari kedua cakar. */
    public static void chargedFists(ClientLevel level, AbstractClientPlayer p) {
        RandomSource r = level.random;
        if (r.nextInt(2) != 0) {
            return;
        }
        Vec3 f = forward(p);
        double side = r.nextBoolean() ? 0.55 : -0.55;
        double h = p.getBbHeight();
        Vfx.spark(p.getX() - f.z * side * h / 1.8, p.getY() + h * 0.42, p.getZ() + f.x * side * h / 1.8,
                (r.nextDouble() - 0.5) * 0.05, -0.02, (r.nextDouble() - 0.5) * 0.05, twoTone(r), 0.06f, 12, p.getY());
    }

    public static void tick(ClientLevel level) {
        float old = Vfx.setBoost(BOOST);
        try {
            Minecraft mc = Minecraft.getInstance();
            for (AbstractClientPlayer p : level.players()) {
                int id = p.getId();
                int[] claw = CLAWS.get(id);
                if (claw != null && --claw[1] <= 0) {   // satu tumpukan cakar meluruh tiap menit (perkiraan untuk pemain lain)
                    claw[0]--;
                    claw[1] = 1200;
                    if (claw[0] <= 0) {
                        CLAWS.remove(id);
                    }
                }
                if (!ShazamClientState.isTransformed(id) || !ShazamClientState.isHelion3(id) || p.isInvisible()) {
                    LAST_POS.remove(id);
                    continue;
                }
                boolean firstPerson = p == mc.player && mc.options.getCameraType().isFirstPerson();
                ambient(level, p, firstPerson);
            }
            LAST_POS.keySet().removeIf(id -> level.getEntity(id) == null);
            STEP.keySet().removeIf(id -> level.getEntity(id) == null);
            AIR.keySet().removeIf(id -> level.getEntity(id) == null);
            RITE.entrySet().removeIf(e -> level.getGameTime() - e.getValue() > Helion3Rite.LENGTH + 40);
            HEARTS.values().removeIf(h -> h.done);
        } catch (RuntimeException ignored) {
            // efek nggak boleh bikin game crash
        } finally {
            Vfx.setBoost(old);
        }
    }

    /** Jantung sel mati di dada (dipakai juga bosnya): dibuat sekali per makhluk, padam sendiri. */
    static void heart(LivingEntity e, boolean player) {
        Heart h = HEARTS.get(e.getId());
        if (h == null || h.done || h.owner != e) {
            h = new Heart(e, player);
            HEARTS.put(e.getId(), h);
            Vfx.add(h);
        }
    }

    private static void ambient(ClientLevel level, AbstractClientPlayer p, boolean firstPerson) {
        RandomSource r = level.random;
        int id = p.getId();
        Vec3 c = chest(p);
        double h = p.getBbHeight();
        boolean raging = ShazamClientState.isRaging(id);
        heart(p, true);
        if (!firstPerson) {
            if (p.tickCount % 4 == 0) {   // asap tipis bocor dari retakannya
                Vfx.smoke(c.x + (r.nextDouble() - 0.5) * 0.7, c.y + (r.nextDouble() - 0.4) * h * 0.5, c.z + (r.nextDouble() - 0.5) * 0.7,
                        0, 0.03, 0, 0x3A3430, 0.3f, 26);
            }
            if (r.nextInt(4) == 0) {
                Vfx.spark(c.x + (r.nextDouble() - 0.5) * 0.7, c.y + (r.nextDouble() - 0.5) * h * 0.6, c.z + (r.nextDouble() - 0.5) * 0.7,
                        (r.nextDouble() - 0.5) * 0.06, 0.04, (r.nextDouble() - 0.5) * 0.06, twoTone(r), 0.05f, 10, p.getY());
            }
            if (claws(p) > 0.01f && r.nextInt(3) == 0) {
                Vfx.mote(c.x + (r.nextDouble() - 0.5) * 0.9, c.y - h * 0.2 + (r.nextDouble() - 0.5) * 0.5, c.z + (r.nextDouble() - 0.5) * 0.9,
                        0, 0.03, 0, CRYON, 0.08f, 16);
            }
            if (raging) {   // Evolusi Ketiga: api merah darah menjilat dari punggung & bahu, bara naik
                Vec3 back = c.subtract(forward(p).scale(0.3)).add(0, h * 0.12, 0);
                HdKit.flames(back, 2, 0.45, 0.07, RAGE, 0.3f, 14);
                if (p.tickCount % 2 == 0) {
                    Vfx.ember(c.x + (r.nextDouble() - 0.5) * 0.8, c.y + r.nextDouble() * 0.6, c.z + (r.nextDouble() - 0.5) * 0.8,
                            (r.nextDouble() - 0.5) * 0.04, 0.06 + r.nextDouble() * 0.05, (r.nextDouble() - 0.5) * 0.04, 0.07f, 18);
                }
            }
        }
        if (raging && p.tickCount % 12 == 0) {
            Vfx.add(new Fx.Wave(p.position().add(0, 0.08, 0), UP, 2.4, 0.2, RAGE, 12, 0.4f, 0.04f, null));
        }
        // langkah berat & pendaratan dari lompatan raksasanya
        Vec3 now = p.position();
        Vec3 last = LAST_POS.put(id, now);
        boolean ground = p.onGround();
        Boolean wasAir = AIR.put(id, !ground);
        if (last == null) {
            return;
        }
        double fallen = last.y - now.y;
        if (ground && wasAir != null && wasAir && fallen > 0.45) {   // mendarat keras
            float k = (float) Mth.clamp(fallen, 0.5, 1.6);
            Helion3Fx.ground(level, now, 0.5 + k * 0.5, DUST);
            CineKit.shock(level, now.add(0, 0.1, 0), UP, 2.0 + k * 1.5, DUST, 0xFFFFFF, 12, 0.6f, true, true);
            ShazamFx.shakeAround(now, 0.25f * k, 24);
            level.playLocalSound(now.x, now.y, now.z, ShazamSounds.HELION3_STEP.get(), SoundSource.PLAYERS, 1.6f, 0.7f, false);
            STEP.put(id, 0);
            return;
        }
        if (ground) {
            double moved = Math.hypot(now.x - last.x, now.z - last.z);
            if (moved > 0.02) {
                int step = STEP.merge(id, (int) Math.ceil(moved * 10.0), Integer::sum);
                if (step >= 14) {   // tiap ±1,4 blok: satu langkah berat
                    STEP.put(id, 0);
                    ShazamFx.dustPuffs(level, now, DUST, raging ? 5 : 3, 0.7, 0.07);
                    ShazamFx.shakeAround(now, raging ? 0.12f : 0.07f, 16);
                    level.playLocalSound(now.x, now.y, now.z, ShazamSounds.HELION3_STEP.get(), SoundSource.PLAYERS,
                            raging ? 1.1f : 0.8f, 0.95f + r.nextFloat() * 0.2f, false);
                }
            }
        }
    }

    // ------------------------------------------------------------------ efek

    /**
     * Garis ayunan yang menyapu miring lalu memudar: tiga garis cakaran (Subjek Tiga), atau satu busur lebar berwarna
     * juaranya (pukulan Lintang & Helion-6, lihat HeroAmbient).
     */
    static final class ClawSlash extends Effect {
        private final Vec3 at, face, sweep, gap;
        private final float size;
        private final int rgb, halo, lines;

        ClawSlash(Vec3 at, Vec3 facing, float size, int rgb, int life, RandomSource r) {
            this(at, facing, size, rgb, BLOOD, 3, life, r);
        }

        ClawSlash(Vec3 at, Vec3 facing, float size, int rgb, int halo, int lines, int life, RandomSource r) {
            super(life);
            this.at = at;
            this.size = size;
            this.rgb = rgb;
            this.halo = halo;
            this.lines = lines;
            Vec3 f = new Vec3(facing.x, 0, facing.z);
            this.face = f.lengthSqr() < 1.0E-6 ? new Vec3(0, 0, 1) : f.normalize();
            Vec3 side = new Vec3(-face.z, 0, face.x);
            double a = (r.nextBoolean() ? 1.0 : -1.0) * (0.55 + r.nextDouble() * 0.5);   // miring 30-60 derajat, kiri atau kanan
            this.sweep = side.scale(Math.cos(a)).add(0, Math.sin(a), 0).normalize();
            this.gap = face.cross(sweep).normalize();
        }

        @Override
        public void renderGlow(Draw d) {
            float t = progress(d.partialTick);
            float head = Math.min(1f, t * 3.2f);                              // goresannya tergambar cepat
            float fade = 1f - Mth.clamp((t - 0.3f) / 0.7f, 0f, 1f);           // lalu memudar
            if (fade <= 0.01f) {
                return;
            }
            final int n = 10;
            int half = lines >= 3 ? 1 : 0;
            float wide = lines >= 3 ? 1f : 1.7f;                              // satu busur: lebih lebar
            for (int c = -half; c <= half; c++) {
                double len = (c == 0 ? 1.0 : 0.8) * size;
                double ox = gap.x * c * size * 0.3, oy = gap.y * c * size * 0.3, oz = gap.z * c * size * 0.3;
                double lx = 0, ly = 0, lz = 0;
                float lw = 0f, la = 0f;
                for (int i = 0; i <= n; i++) {
                    double s = i / (double) n * head;
                    double along = (s - 0.5) * 2.0 * len;
                    double bow = Math.sin(Math.PI * s) * size * 0.3;          // melengkung ke arah pemukulnya
                    double x = at.x + sweep.x * along + ox - face.x * bow;
                    double y = at.y + sweep.y * along + oy;
                    double z = at.z + sweep.z * along + oz - face.z * bow;
                    float w = (float) (0.02 + Math.sin(Math.PI * s) * 0.16 * size) * wide;
                    float a = fade * (float) Math.sin(Math.PI * Math.min(1.0, s + 0.08));
                    if (i > 0) {
                        d.line(lx, ly, lz, x, y, z, lw, w, rgb, la, a);
                        d.line(lx, ly, lz, x, y, z, lw * 2.6f, w * 2.6f, halo, la * 0.35f, a * 0.35f);
                    }
                    lx = x;
                    ly = y;
                    lz = z;
                    lw = w;
                    la = a;
                }
            }
        }
    }

    /**
     * Duri tulang yang meletus dari tanah: menjalar keluar dari pusat (makin jauh makin telat), tumbuh cepat dengan sedikit
     * lebih, bertahan, lalu tenggelam lagi. Benda padat bertekstur tulang (bukan cahaya), miring keluar.
     */
    static final class BoneSpikes extends Effect {
        private final int n;
        private final double[] x, y, z;
        private final float[] dx, dz, len, half;
        private final int[] delay;

        BoneSpikes(ClientLevel level, Vec3 center, double r0, double r1, int count, int life, int wave, RandomSource r) {
            super(life);
            this.n = Math.max(1, count);
            x = new double[n];
            y = new double[n];
            z = new double[n];
            dx = new float[n];
            dz = new float[n];
            len = new float[n];
            half = new float[n];
            delay = new int[n];
            Ground.Map g = ShazamFx.ground(level, center, r1 + 0.5);
            double baseY = g != null && g.found ? g.centerY : center.y;
            for (int i = 0; i < n; i++) {
                double a = Math.PI * 2.0 * (i + r.nextDouble() * 0.7) / n * (n > 20 ? 3.0 : 1.0);
                double k = n > 20 ? (i % 3 + r.nextDouble()) / 3.0 : r.nextDouble();   // banyak duri: tiga lingkaran
                double rad = r0 + (r1 - r0) * k;
                x[i] = center.x + Math.cos(a) * rad;
                z[i] = center.z + Math.sin(a) * rad;
                y[i] = baseY + (g != null && g.found ? g.at(a, rad) : 0.0);
                float lean = 0.25f + r.nextFloat() * 0.35f;                           // miring keluar
                dx[i] = (float) Math.cos(a) * lean + (r.nextFloat() - 0.5f) * 0.2f;
                dz[i] = (float) Math.sin(a) * lean + (r.nextFloat() - 0.5f) * 0.2f;
                len[i] = (float) (0.9 + r.nextDouble() * 1.3) * (float) (1.25 - 0.45 * k);
                half[i] = 0.16f + r.nextFloat() * 0.12f;
                delay[i] = (int) (k * wave) + r.nextInt(2);
            }
        }

        private float grow(int i, float t) {
            float u = (t - delay[i]) / 4f;
            if (u <= 0f) {
                return 0f;
            }
            float up = u >= 1f ? 1f : 1f + 0.18f * Mth.sin(u * (float) Math.PI) - (1f - u) * (1f - u);   // muncul dengan sedikit lebih
            float down = Mth.clamp((life - t) / 12f, 0f, 1f);                                           // tenggelam lagi
            return Math.max(0f, up) * down;
        }

        @Override
        public void renderSolid(PoseStack poseStack, MultiBufferSource buffers, double camX, double camY, double camZ,
                                float partialTick) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.level == null) {
                return;
            }
            float t = time(partialTick);
            VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(Helion3Geo.BONE));
            for (int i = 0; i < n; i++) {
                float gr = grow(i, t);
                if (gr <= 0.01f) {
                    continue;
                }
                poseStack.pushPose();
                poseStack.translate(x[i] - camX, y[i] - camY, z[i] - camZ);
                int light = LevelRenderer.getLightColor(mc.level, BlockPos.containing(x[i], y[i] + 0.6, z[i]));
                Helion3Geo.worldSpike(poseStack.last(), vc, light, dx[i], 1f, dz[i], len[i] * gr, half[i] * (0.6f + 0.4f * gr),
                        255, 250, 240);
                poseStack.popPose();
            }
        }

        @Override
        public boolean tick(ClientLevel level) {
            RandomSource r = level.random;
            for (int i = 0; i < n; i++) {
                if (age == delay[i]) {   // saat duri ini menembus tanah: debu & kerikil
                    Vfx.dust(x[i], y[i] + 0.1, z[i], dx[i] * 0.1, 0.08, dz[i] * 0.1, DUST, 0.35f, 22);
                    if (r.nextInt(2) == 0) {
                        Vfx.shard(x[i], y[i] + 0.2, z[i], dx[i] * 0.2, 0.2 + r.nextDouble() * 0.1, dz[i] * 0.2, 0x6A625A, 0.1f, 22, y[i]);
                    }
                }
            }
            return super.tick(level);
        }
    }

    /**
     * Jantung sel mati: cahaya dua warna yang berdenyut di tulang dada dan genangan cahaya tipis di kakinya. Hidup selama
     * makhluknya masih Subjek Tiga (pemain: selama berwujud; bos: selama hidup).
     */
    static final class Heart extends Effect {
        final LivingEntity owner;
        private final boolean player;
        boolean done;

        Heart(LivingEntity owner, boolean player) {
            super(Integer.MAX_VALUE);
            this.owner = owner;
            this.player = player;
        }

        @Override
        public boolean tick(ClientLevel level) {
            age++;
            boolean alive = owner.isAlive() && !owner.isRemoved() && level.getEntity(owner.getId()) == owner;
            if (alive && player) {
                alive = ShazamClientState.isTransformed(owner.getId()) && ShazamClientState.isHelion3(owner.getId());
            }
            if (!alive) {
                done = true;
            }
            return alive;
        }

        @Override
        public void renderGlow(Draw d) {
            if (owner.isInvisible()) {
                return;
            }
            Minecraft mc = Minecraft.getInstance();
            boolean firstPerson = owner == mc.player && mc.options.getCameraType().isFirstPerson();
            boolean fast = player && ShazamClientState.isRaging(owner.getId());
            float beat = Helion3Geo.beat(owner.tickCount + d.partialTick + owner.getId() * 3f, fast);
            double h = owner.getBbHeight();
            Vec3 p = owner.getPosition(d.partialTick);
            int rgb = Draw.mix(LIGHT, CRYON, 0.5 + 0.5 * Math.sin(age * 0.05));
            if (fast) {
                rgb = Draw.mix(rgb, RAGE, 0.6);
            }
            d.disc(p.x, p.y + 0.06, p.z, 0, 1, 0, 0.75 * h, rgb, 0.05f + 0.1f * beat, 0f, null);
            if (firstPerson) {
                return;
            }
            float yaw = owner.yBodyRot * Mth.DEG_TO_RAD;
            double fx = -Mth.sin(yaw), fz = Mth.cos(yaw);
            d.glow(p.x + fx * 0.2 * h / 1.8, p.y + h * 0.7, p.z + fz * 0.2 * h / 1.8, (float) (0.32 * h / 1.8 * (1.0 + 0.5 * beat)),
                    rgb, 0.12f + 0.3f * beat);
        }
    }
}
