package com.shazammod.client.vfx;

import java.util.ArrayList;
import java.util.List;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Mesin efek visual Shazam: semua efek skill digambar sendiri di dunia (cahaya lembut, gelombang kejut,
 * petir bercabang, retakan tanah, pecahan blok, lingkaran rune, asap, dan lain-lain), bukan partikel Minecraft.
 * Efek berumur pendek, dihitung tiap tick, digambar tiap frame dengan interpolasi supaya halus.
 *
 * Efek yang baru dibuat mulai dari umur 0 di frame berikutnya (dulu langsung dimajukan satu tick saat dibuat,
 * jadi detik pertamanya hilang: kilatan kehilangan puncak terangnya dan busur petir yang umurnya 1-2 tick
 * hampir nggak kelihatan).
 */
public final class Vfx {
    private Vfx() {}

    // ======= Angka yang gampang diutak-atik =======
    /** Kepadatan butiran (percikan, bara, debu, asap, ...) semua skill. 1 = seperti versi 0.15. */
    public static final float DENSITY = 1.6f;

    // ======= 0.33: penguat sinematik per juara =======
    // Lintang & Sabbac memasang penguat saat membuat efeknya (LintangFx.BOOST, SabbacFx.BOOST): butiran lebih padat,
    // lebih besar & lebih lama, dan tiap efek cahaya mendapat lapisan bloom lebar (lihat render). 1 = biasa.
    private static float boost = 1f;

    public static float boost() {
        return boost;
    }

    /** Pasang penguat baru dan kembalikan yang lama (pakai try/finally supaya selalu dikembalikan). */
    public static float setBoost(float value) {
        float old = boost;
        boost = value;
        return old;
    }

    private static float grow() {
        return 1f + 0.5f * (boost - 1f);
    }

    private static int stretch(int life) {
        return boost == 1f ? life : Math.round(life * (1f + 0.6f * (boost - 1f)));
    }
    /** Batas jumlah efek sekaligus. Kalau penuh, yang paling dekat habis yang dibuang (bukan efek baru). */
    private static final int MAX_EFFECTS = 1024;

    private static final List<Effect> EFFECTS = new ArrayList<>();
    private static final List<Effect> PENDING = new ArrayList<>();
    private static final Particles PARTICLES = new Particles();
    private static final RandomSource RANDOM = RandomSource.create();
    private static final Draw.Batch SOFT = new Draw.Batch();
    private static final Draw.Batch GLOW = new Draw.Batch();

    public static RandomSource random() {
        return RANDOM;
    }

    /** Jumlah butiran dikali kepadatan efek. */
    public static int count(double base) {
        return (int) Math.max(0L, Math.round(base * DENSITY * (1f + 1.3f * (boost - 1f))));
    }

    public static void add(Effect effect) {
        if (PENDING.size() < MAX_EFFECTS) {
            PENDING.add(effect);
        }
    }

    public static void clear() {
        EFFECTS.clear();
        PENDING.clear();
        PARTICLES.clear();
        tint = 0f;
        tintO = 0f;
        tintNext = 0f;
    }

    // ======= 0.44 warna dunia: Lintas Detik memucatkan dunia jadi abu-abu saat waktu "berhenti" =======
    private static int tintRgb = 0x9EA6AE;
    private static float tint, tintO, tintNext;

    /**
     * Pucatkan dunia (semua yang sudah digambar sebelum efek) ke warna rgb sebanyak amount (0-1) di tick ini. Harus
     * dipanggil tiap tick selama dibutuhkan; efek yang digambar sesudahnya (jejak, bayangan, cincin) tetap berwarna.
     */
    public static void worldTint(int rgb, float amount) {
        if (amount > tintNext) {
            tintNext = amount;
            tintRgb = rgb;
        }
    }

    public static void tick(ClientLevel level) {
        PARTICLES.tick();                                     // butiran lama maju selangkah
        EFFECTS.removeIf(effect -> !effect.tick(level));      // efek lama maju selangkah
        for (Effect effect : PENDING) {                       // efek baru: mulai umur 0, digambar mulai frame ini
            if (EFFECTS.size() >= MAX_EFFECTS) {
                evictOldest();
            }
            EFFECTS.add(effect);
        }
        PENDING.clear();
        PARTICLES.endTick();
        tintO = tint;
        tint = tintNext > tint ? tint + (tintNext - tint) * 0.55f : Math.max(tintNext, tint - 0.2f);   // masuk halus, keluar cepat
        if (tint < 0.004f) {
            tint = 0f;
        }
        tintNext = 0f;
    }

    /** Buang efek yang paling dekat habis (efek yang baru dipicu pemain selalu dapat tempat). */
    private static void evictOldest() {
        int worst = -1;
        float most = -1f;
        for (int i = 0; i < EFFECTS.size(); i++) {
            Effect e = EFFECTS.get(i);
            float p = e.age / (float) e.life;
            if (p > most) {
                most = p;
                worst = i;
            }
        }
        if (worst >= 0) {
            EFFECTS.remove(worst);
        }
    }

    // ------------------------------------------------------------------ butiran

    /** Butiran cahaya lembut yang melayang. */
    public static void mote(double x, double y, double z, double vx, double vy, double vz, int rgb, float size, int life) {
        PARTICLES.spawn(Particles.MOTE, x, y, z, vx, vy, vz, rgb, size * grow(), stretch(life), 0f, 0.04f, Double.NaN, RANDOM.nextFloat());
    }

    /** Percikan memanjang searah gerak; jatuh dan memantul di tanah (floorY, atau NaN = tanpa tanah). */
    public static void spark(double x, double y, double z, double vx, double vy, double vz, int rgb, float size, int life,
                             double floorY) {
        PARTICLES.spawn(Particles.SPARK, x, y, z, vx, vy, vz, rgb, size * grow(), stretch(life), 0.035f, 0.05f, floorY, RANDOM.nextFloat());
    }

    /** Bara yang naik sambil mendingin. */
    public static void ember(double x, double y, double z, double vx, double vy, double vz, float size, int life) {
        PARTICLES.spawn(Particles.EMBER, x, y, z, vx, vy, vz, 0xFFE0A0, size * grow(), stretch(life), -0.002f, 0.06f, Double.NaN, RANDOM.nextFloat());
    }

    /** Bintang kilau empat sudut. */
    public static void glint(double x, double y, double z, int rgb, float size, int life) {
        PARTICLES.spawn(Particles.GLINT, x, y, z, 0, 0, 0, rgb, size * grow(), stretch(life), 0f, 0f, Double.NaN, RANDOM.nextFloat());
    }

    /** Kepulan debu lembut (warna tanah), bervolume: atas terang, bawah berbayang. */
    public static void dust(double x, double y, double z, double vx, double vy, double vz, int rgb, float size, int life) {
        PARTICLES.spawn(Particles.DUST, x, y, z, vx, vy, vz, rgb, size * grow(), stretch(life), -0.001f, 0.12f, Double.NaN, RANDOM.nextFloat());
    }

    /**
     * Asap tebal: naik pelan karena lebih hangat dari udara, melambat karena hambatan udara, mengembang, berkelok
     * terbawa udara, lalu menipis. Tembus pandang biasa (bukan cahaya), bervolume.
     */
    public static void smoke(double x, double y, double z, double vx, double vy, double vz, int rgb, float size, int life) {
        PARTICLES.spawn(Particles.SMOKE, x, y, z, vx, vy, vz, rgb, size * grow(), stretch(life), -0.0035f, 0.075f, Double.NaN, RANDOM.nextFloat());
    }

    // ------------------------------------------------------------------ 0.34 butiran HD (Lintang & Sabbac)

    /**
     * Lidah api: naik karena panas, berkelok, meruncing; warnanya mendingin dari putih-kuning panas ke warna rgb lalu
     * ke merah gelap (rgb = warna api utama, misalnya api neraka atau plasma surya).
     */
    public static void flame(double x, double y, double z, double vx, double vy, double vz, int rgb, float size, int life) {
        PARTICLES.spawn(Particles.FLAME, x, y, z, vx, vy, vz, rgb, size * grow(), stretch(life), -0.0045f, 0.075f, Double.NaN, RANDOM.nextFloat());
    }

    /** Kristal/serpihan berputar yang berkilau (es, obsidian, kaca): jatuh dan memantul di tanah (floorY, atau NaN). */
    public static void shard(double x, double y, double z, double vx, double vy, double vz, int rgb, float size, int life,
                             double floorY) {
        PARTICLES.spawn(Particles.SHARD, x, y, z, vx, vy, vz, rgb, size * grow(), stretch(life), 0.03f, 0.035f, floorY, RANDOM.nextFloat());
    }

    /** Abu/arang melayang (tembus pandang biasa): berputar pelan, turun (fall > 0) atau naik terbawa panas (fall < 0). */
    public static void cinder(double x, double y, double z, double vx, double vy, double vz, int rgb, float size, int life,
                              float fall) {
        PARTICLES.spawn(Particles.CINDER, x, y, z, vx, vy, vz, rgb, size * grow(), stretch(life), fall, 0.05f, Double.NaN, RANDOM.nextFloat());
    }

    /** Gores cahaya panjang & tipis (garis kecepatan, hujan foton): tanpa gravitasi, ekornya memanjang searah gerak. */
    public static void streak(double x, double y, double z, double vx, double vy, double vz, int rgb, float size, int life) {
        PARTICLES.spawn(Particles.STREAK, x, y, z, vx, vy, vz, rgb, size * grow(), stretch(life), 0f, 0.02f, Double.NaN, RANDOM.nextFloat());
    }

    // ------------------------------------------------------------------ gambar

    /** Dipanggil dari RenderLevelStageEvent. */
    public static void render(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES || (EFFECTS.isEmpty() && PARTICLES.isEmpty())) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            return;
        }
        float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        Vec3 cam = event.getCamera().getPosition();
        PoseStack poseStack = event.getPoseStack();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        poseStack.pushPose();
        // 0) 0.44 dunia memucat (Lintas Detik): selapis warna tepat di depan kamera menutup semua yang sudah digambar
        float worldTint = tintO + (tint - tintO) * partialTick;
        if (worldTint > 0.003f) {
            Draw cover = new Draw(poseStack.last(), cam, partialTick);
            cover.begin(buffers.getBuffer(Draw.softType()), false);
            cover.cover(event.getCamera().getYRot(), event.getCamera().getXRot(), tintRgb, Math.min(0.85f, worldTint));
            buffers.endBatch();
        }
        // 1) benda padat (pecahan blok)
        for (Effect effect : EFFECTS) {
            effect.renderSolid(poseStack, buffers, cam.x, cam.y, cam.z, partialTick);
        }
        buffers.endBatch();
        // 2) catat semua bentuk (geometrinya dihitung sekali)
        Draw draw = new Draw(poseStack.last(), cam, partialTick);
        SOFT.clear();
        GLOW.clear();
        draw.record(SOFT, false);
        PARTICLES.renderSoft(draw);
        for (Effect effect : EFFECTS) {
            draw.hd(effect.boost > 1.001f);   // 0.34: efek Lintang & Sabbac digambar HD
            effect.renderSoft(draw);
        }
        draw.hd(false);
        draw.record(GLOW, true);
        PARTICLES.renderGlow(draw);
        for (Effect effect : EFFECTS) {
            draw.hd(effect.boost > 1.001f);
            effect.renderGlow(draw);
        }
        draw.hd(false);
        // 0.33: lapisan bloom untuk efek yang dibuat dengan penguat (Lintang & Sabbac): tiap cahaya digambar sekali lagi
        // lebih lebar dan lembut, jadi pendarnya tebal seperti di film. Efek Shazam & Black Adam (boost 1) nggak berubah.
        boolean bloomed = false;
        for (Effect effect : EFFECTS) {
            if (effect.boost > 1.001f && !(effect instanceof Fx.Trail)) {
                float k = effect.boost - 1f;
                draw.bloom(1f + 2.4f * k, 0.42f * k);
                draw.hd(true);
                effect.renderGlow(draw);
                bloomed = true;
            }
        }
        if (bloomed) {
            draw.bloom(1f, 1f);
        }
        draw.hd(false);
        // 3) badan efek cahaya + debu/asap (tembus pandang biasa), lalu cahayanya (aditif) di atas semuanya
        if (!SOFT.isEmpty() || !GLOW.isEmpty()) {
            VertexConsumer soft = buffers.getBuffer(Draw.softType());
            GLOW.emitBody(soft, Draw.BODY);
            SOFT.emitSoft(soft);
        }
        if (!GLOW.isEmpty()) {
            GLOW.emitGlow(buffers.getBuffer(Draw.additiveType()), Draw.GLOW);
        }
        buffers.endBatch();
        poseStack.popPose();
    }
}
