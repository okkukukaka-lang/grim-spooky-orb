package com.shazammod.client.flight;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;

/**
 * Sambaran Heru (Black Adam) di client pemain sendiri: sesudah merunduk (HERU_WINDUP), badan digerakkan lurus ke
 * titik akhir yang sudah dihitung server dalam HERU_TICKS tick. Geraknya lewat kecepatan biasa (bukan teleport),
 * jadi tetap halus di layar, tetap bertabrakan dengan blok, dan tetap terkirim ke server seperti gerak biasa.
 * Kecepatannya cepat di awal lalu mengerem di akhir, seperti elang yang menyambar mangsanya.
 *
 * 0.30: dipakai juga Tanduk Setan (Sabbac): menggaruk tanah HORN_WINDUP tick, lalu menyeruduk lurus HORN_TICKS tick.
 */
public final class HeruDash {
    private HeruDash() {}

    private static Vec3 start;
    private static Vec3 end;
    private static int wait = -1;
    private static int step;
    private static int ticks = ShazamAnim.HERU_TICKS;
    private static double ease = 2.2;
    private static double arc;   // 0.49: tinggi lambungan di tengah lintasan (blok); 0 = lurus

    public static void start(LocalPlayer player, Vec3 target) {
        start(player, target, ShazamAnim.HERU_WINDUP, ShazamAnim.HERU_TICKS, 2.2);
    }

    /** Terjangan umum: tertahan windup tick, lalu melesat ke target dalam length tick (ease: makin besar makin mengerem). */
    public static void start(LocalPlayer player, Vec3 target, int windup, int length, double easePower) {
        start(player, target, windup, length, easePower, 0.0);
    }

    /** 0.49 Sama, tapi lintasannya melambung setinggi arcHeight blok di tengah (Lompat Subjek Tiga). */
    public static void start(LocalPlayer player, Vec3 target, int windup, int length, double easePower, double arcHeight) {
        arc = arcHeight;
        end = target;
        start = null;
        wait = windup;
        step = 0;
        ticks = Math.max(1, length);
        ease = easePower;
    }

    public static void reset() {
        end = null;
        start = null;
        wait = -1;
    }

    public static boolean active() {
        return end != null;
    }

    /** Sebelum gerak pemain dihitung (sesudah kendali terbang & Mode Kilat, jadi kecepatannya menang). */
    public static void preTick(LocalPlayer player) {
        if (end == null) {
            return;
        }
        if (!ShazamClientState.isTransformed(player.getId()) || player.isPassenger()) {
            reset();
            return;
        }
        if (wait > 0) {   // merunduk: badan tertahan, siap melesat
            wait--;
            Vec3 v = player.getDeltaMovement();
            player.setDeltaMovement(v.x * 0.2, Math.min(v.y, 0.0) * 0.3, v.z * 0.2);
            if (wait == 0) {
                start = player.position();
            }
            return;
        }
        if (start == null) {
            start = player.position();
        }
        step++;
        double u = step / (double) ticks;
        double e = 1.0 - Math.pow(1.0 - Math.min(1.0, u), ease);   // cepat di awal, mengerem di ujung
        Vec3 want = start.lerp(end, e);
        if (arc != 0.0) {
            want = want.add(0, arc * Math.sin(Math.PI * Math.min(1.0, u)), 0);
        }
        Vec3 move = want.subtract(player.position());
        if (step >= ticks) {
            // sampai: sisa laju sedikit ke depan, lalu kendali kembali normal
            Vec3 dir = end.subtract(start);
            Vec3 carry = dir.lengthSqr() < 1.0E-6 ? Vec3.ZERO : dir.normalize().scale(0.25);
            player.setDeltaMovement(move.add(carry));
            player.fallDistance = 0f;
            reset();
            return;
        }
        player.setDeltaMovement(move);
        player.fallDistance = 0f;
    }
}
