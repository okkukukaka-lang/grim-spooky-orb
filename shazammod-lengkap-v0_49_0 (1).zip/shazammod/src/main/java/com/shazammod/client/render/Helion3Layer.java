package com.shazammod.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamMod;
import com.shazammod.client.fx.ShazamRage;
import com.shazammod.client.fx.SubjekFx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;

/**
 * 0.49 Subjek Tiga (Helion-3) yang bisa dimainkan: seluruh tubuh pemain ditutup daging sel mati bosnya (tekstur 256 px di
 * tata letak UV kulit, dibuat tools/textures/helion3_textures.py), termasuk kepalanya:
 *
 *   1) daging hangus digambar tepat di atas kulit asli (bagian dasar model), ikut memerah saat terluka;
 *   2) pelat tulang, kalung besi & tali pengekang di lapisan luar (lapisan luar kulit asli pemain disembunyikan di pre());
 *   3) retakan & mata dua warna yang menyala dan berdenyut seperti jantung (makin terang saat Evolusi Ketiga & skill);
 *   4) bentuk 3D dari Helion3Geo: tanduk, taring, rusuk, kristal inti, karapas bahu, cakar, duri punggung.
 *
 * Selama Inkubasi Subjek Tiga (masih manusia), urat sel mati yang menghitam menjalar di kulitnya. Tangan orang pertama
 * ikut jadi lengan monster bercakar.
 */
public class Helion3Layer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation SKIN = ShazamMod.id("textures/entity/helion3/skin.png");
    private static final ResourceLocation GLOW = ShazamMod.id("textures/entity/helion3/glow.png");
    private static final ResourceLocation VEINS = ShazamMod.id("textures/entity/lintang/cryon_veins.png");
    private static final int FULLBRIGHT = 15728880;
    /** Lengan monster di sudut pandang orang pertama dibuat sedikit lebih besar dari lengan kulit, jadi menutupinya. */
    private static final float ARM_INFLATE = 1.08f;

    public Helion3Layer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    public static boolean active(AbstractClientPlayer player) {
        return !player.isInvisible() && ShazamClientState.isTransformed(player.getId())
                && ShazamClientState.isHelion3(player.getId());
    }

    /**
     * Dipanggil di RenderPlayerEvent.Pre (sesudah bagian model diatur, sebelum digambar): lapisan luar kulit asli pemain
     * (rambut, jaket, lengan baju, celana) disembunyikan supaya nggak menyembul dari balik daging monsternya.
     */
    public static void pre(AbstractClientPlayer player, PlayerModel<AbstractClientPlayer> m) {
        try {
            if (!active(player)) {
                return;
            }
            m.hat.visible = false;
            m.jacket.visible = false;
            m.rightSleeve.visible = false;
            m.leftSleeve.visible = false;
            m.rightPants.visible = false;
            m.leftPants.visible = false;
        } catch (Throwable ignored) {
            // lapisan kostum nggak boleh bikin game crash
        }
    }

    /** Terang retakan & matanya: denyut jantung + amukan + kilatan skill. */
    private static float glow(AbstractClientPlayer p, float beat, float rage, float pt) {
        float k = 0.5f + 0.38f * beat + 0.4f * rage + SubjekFx.flare(p, pt);
        float reveal = ShazamCape.revealTime(p, pt);
        if (reveal >= 0f && reveal < 14f) {   // baru keluar dari kepompong: menyala penuh lalu turun
            k = Math.max(k, 1.4f * (1f - reveal / 14f));
        }
        return k;
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buffers, int light, AbstractClientPlayer p, float limbSwing,
                       float limbAmount, float pt, float ageInTicks, float netHeadYaw, float headPitch) {
        try {
            if (p.isInvisible() || !ShazamClientState.isHelion3(p.getId())) {
                return;
            }
            PlayerModel<AbstractClientPlayer> m = getParentModel();
            if (!ShazamClientState.isTransformed(p.getId())) {
                float rite = SubjekFx.riteVeins(p, pt);   // inkubasi di tubuh manusia: urat sel mati menghitam & menjalar
                if (rite > 0.02f) {
                    VertexConsumer veins = buffers.getBuffer(RenderType.entityTranslucent(VEINS));
                    int c = ((int) (Mth.clamp(rite, 0f, 1f) * 235f) << 24) | 0x2A1420;
                    one(m.hat, m.head, ps, veins, light, c);
                    for (ModelPart[] pair : body(m)) {
                        one(pair[0], pair[1], ps, veins, light, c);
                    }
                }
                return;
            }
            int overlay = LivingEntityRenderer.getOverlayCoords(p, 0f);
            float rage = ShazamRage.glow(p, pt);
            float beat = Helion3Geo.beat(ageInTicks + p.getId() * 3f, rage > 0.3f);
            // 1) daging sel mati tepat di atas kulit asli (bagian dasar), lalu 2) pelat & pengekang di lapisan luar
            VertexConsumer skin = buffers.getBuffer(RenderType.entityCutoutNoCull(SKIN));
            base(m.head, ps, skin, light, overlay, 0xFFFFFFFF);
            for (ModelPart[] pair : body(m)) {
                base(pair[1], ps, skin, light, overlay, 0xFFFFFFFF);
            }
            shell(m.hat, m.head, ps, skin, light, overlay, 0xFFFFFFFF, 1f);
            for (ModelPart[] pair : body(m)) {
                shell(pair[0], pair[1], ps, skin, light, overlay, 0xFFFFFFFF, 1f);
            }
            // 3) retakan & mata yang menyala
            float glow = glow(p, beat, rage, pt);
            if (glow > 0.02f) {
                VertexConsumer lines = buffers.getBuffer(RenderType.eyes(GLOW));
                int c = color(rage > 0.01f ? mixHot(rage) : 0xFFFFFF, glow);
                base(m.head, ps, lines, FULLBRIGHT, OverlayTexture.NO_OVERLAY, c);
                for (ModelPart[] pair : body(m)) {
                    base(pair[1], ps, lines, FULLBRIGHT, OverlayTexture.NO_OVERLAY, c);
                }
            }
            // 4) tanduk, taring, rusuk, inti, karapas, cakar, duri
            Helion3Geo.render(m.head, m.body, m.rightArm, m.leftArm, m.rightLeg, m.leftLeg, ps, buffers, light, overlay,
                    SubjekFx.claws(p), rage, beat);
        } catch (Throwable ignored) {
            // lapisan kostum nggak boleh bikin game crash
        }
    }

    /**
     * Tangan orang pertama (RenderArmEvent, sebelum lengan kulit digambar): lengan monster dengan retakan menyala, pelat
     * tulang, dan cakarnya, sedikit lebih besar dari lengan kulit supaya menutupinya.
     */
    public static void firstPersonArm(PoseStack ps, MultiBufferSource buffers, int light, AbstractClientPlayer p, HumanoidArm arm) {
        try {
            if (!active(p)) {
                return;
            }
            Minecraft mc = Minecraft.getInstance();
            if (!(mc.getEntityRenderDispatcher().getRenderer(p) instanceof PlayerRenderer renderer)) {
                return;
            }
            PlayerModel<AbstractClientPlayer> m = renderer.getModel();
            boolean right = arm == HumanoidArm.RIGHT;
            ModelPart base = right ? m.rightArm : m.leftArm;
            ModelPart sleeve = right ? m.rightSleeve : m.leftSleeve;
            m.attackTime = 0f;
            m.crouching = false;
            m.swimAmount = 0f;
            m.setupAnim(p, 0f, 0f, 0f, 0f, 0f);
            base.xRot = 0f;
            sleeve.xRot = 0f;
            float pt = mc.getTimer().getGameTimeDeltaPartialTick(false);
            float rage = ShazamRage.glow(p, pt);
            float beat = Helion3Geo.beat(p.tickCount + pt + p.getId() * 3f, rage > 0.3f);
            VertexConsumer skin = buffers.getBuffer(RenderType.entityCutoutNoCull(SKIN));
            scaled(base, ps, skin, light, 0xFFFFFFFF, ARM_INFLATE);
            scaled(sleeve, ps, skin, light, 0xFFFFFFFF, ARM_INFLATE * 1.02f);
            scaled(base, ps, buffers.getBuffer(RenderType.eyes(GLOW)), FULLBRIGHT,
                    color(rage > 0.01f ? mixHot(rage) : 0xFFFFFF, glow(p, beat, rage, pt)), ARM_INFLATE);
            base.xScale = ARM_INFLATE;
            base.yScale = ARM_INFLATE;
            base.zScale = ARM_INFLATE;
            Helion3Geo.renderArm(base, !right, ps, buffers, light, SubjekFx.claws(p), rage, beat);
            base.xScale = 1f;
            base.yScale = 1f;
            base.zScale = 1f;
        } catch (Throwable ignored) {
            // tangan orang pertama nggak boleh bikin game crash
        }
    }

    /** Badan, lengan, kaki: {lapisan luar, bagian dasar}. */
    private static ModelPart[][] body(PlayerModel<AbstractClientPlayer> m) {
        return new ModelPart[][] {{m.jacket, m.body}, {m.rightSleeve, m.rightArm}, {m.leftSleeve, m.leftArm},
                {m.rightPants, m.rightLeg}, {m.leftPants, m.leftLeg}};
    }

    private static void base(ModelPart part, PoseStack ps, VertexConsumer vc, int light, int overlay, int color) {
        if (part != null && part.visible) {
            part.render(ps, vc, light, overlay, color);
        }
    }

    /** Lapisan luar dipaksa terlihat (di pre() disembunyikan supaya kulit asli pemain nggak ikut digambar). */
    private static void shell(ModelPart outer, ModelPart base, PoseStack ps, VertexConsumer vc, int light, int overlay, int color,
                              float scale) {
        if (outer == null || base == null || !base.visible) {
            return;
        }
        boolean visible = outer.visible;
        outer.visible = true;
        if (scale != 1f) {
            outer.xScale = scale;
            outer.yScale = scale;
            outer.zScale = scale;
        }
        outer.render(ps, vc, light, overlay, color);
        if (scale != 1f) {
            outer.xScale = 1f;
            outer.yScale = 1f;
            outer.zScale = 1f;
        }
        outer.visible = visible;
    }

    /** Satu bagian digambar sedikit lebih besar (lengan orang pertama), terlihat atau nggak. */
    private static void scaled(ModelPart part, PoseStack ps, VertexConsumer vc, int light, int color, float scale) {
        if (part == null) {
            return;
        }
        boolean visible = part.visible;
        part.visible = true;
        part.xScale = scale;
        part.yScale = scale;
        part.zScale = scale;
        part.render(ps, vc, light, OverlayTexture.NO_OVERLAY, color);
        part.xScale = 1f;
        part.yScale = 1f;
        part.zScale = 1f;
        part.visible = visible;
    }

    /** Lapisan luar kalau terlihat, kalau nggak bagian dasarnya (urat inkubasi di tubuh manusia). */
    private static void one(ModelPart outer, ModelPart base, PoseStack ps, VertexConsumer vc, int light, int color) {
        if (base == null || !base.visible) {
            return;
        }
        ModelPart part = outer != null && outer.visible ? outer : base;
        part.render(ps, vc, light, OverlayTexture.NO_OVERLAY, color);
    }

    /** Retakan memerah-panas saat Evolusi Ketiga. */
    private static int mixHot(float rage) {
        float k = Mth.clamp(rage, 0f, 1f) * 0.45f;
        int g = (int) Mth.lerp(k, 255f, 150f), b = (int) Mth.lerp(k, 255f, 120f);
        return 0xFF0000 | (g << 8) | b;
    }

    /** Warna cahaya aditif: kekuatan dikalikan ke RGB (jenis render "eyes" mengabaikan alpha). */
    private static int color(int rgb, float k) {
        k = Mth.clamp(k, 0f, 1f);
        int r = (int) (((rgb >> 16) & 255) * k);
        int g = (int) (((rgb >> 8) & 255) * k);
        int b = (int) ((rgb & 255) * k);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }
}
