package com.shazammod.client.fx;

import java.util.HashMap;
import java.util.Map;

import com.shazammod.LintangSkills;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamSounds;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Molten;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Sinar mata Lintang yang di-charge (Iris Surya, X). 0.44: digambar ulang mengikuti video.
 *
 * Charge (X ditahan): mata menyala merah membara, lalu memutih menyilaukan (di HUD: cincin persen); bara jingga melayang
 * & tersedot ke mata, udara di atas kepala beriak panas, dengungnya naik.
 * Tembak (X dilepas): berkas dari kedua mata dengan inti PUTIH tebal yang pekat (tetap terlihat jelas di siang hari),
 * pendar jingga-persik lebar yang melebar di dekat kepala, rona merah di pangkal mata, dan denyut energi yang mengalir
 * ke sasaran. Titik kena: bintang putih panas, pijar suhu blok, percikan memancar, lelehan menetes, asap; yang kena
 * langsung terbakar, blok memerah lalu menguning dan meleleh jadi lahar (LintangHeat, LintangBurn).
 * Di kamera orang ketiga, kamera bergeser ke bahu selama sinar dipakai (LintangShoulderCam), jadi sinarnya terlihat utuh.
 */
final class LintangLaser {
    private LintangLaser() {}

    // warna sinar gaya video
    static final int WHITE_HOT = 0xFFFBF2;
    static final int AMBER = 0xFFC890;
    static final int HAZE = 0xFF9A55;
    static final int EMBER_RED = 0xFF3A18;

    private static final Map<Integer, Charge> CHARGES = new HashMap<>();
    private static final Map<Integer, Beam> BEAMS = new HashMap<>();

    static void clear() {
        CHARGES.clear();
        BEAMS.clear();
    }

    /** Mata mulai mengumpulkan panas (X ditahan; untuk diri sendiri langsung dari tombol, pemain lain dari server). */
    static void charge(AbstractClientPlayer p) {
        Charge c = CHARGES.get(p.getId());
        if (c != null && c.live()) {
            return;
        }
        c = new Charge(p);
        CHARGES.put(p.getId(), c);
        Vfx.add(c);
    }

    /** X dilepas di client sendiri: kalau jawaban server nggak datang, charge padam sendiri. */
    static void release(AbstractClientPlayer p) {
        Charge c = CHARGES.get(p.getId());
        if (c != null) {
            c.released();
        }
    }

    /** Sinar ditembakkan (data dari server: x = charge, y = lama tick, z = daya). Sinar lama langsung diganti. */
    static void fire(AbstractClientPlayer p, Vec3 data, boolean self) {
        float charge = Mth.clamp((float) data.x, 0f, 1f);
        int ticks = Math.max(4, (int) Math.round(data.y));
        float power = Mth.clamp((float) data.z, 0.2f, 1f);
        Charge c = CHARGES.remove(p.getId());
        if (c != null) {
            c.finish();
        }
        Beam old = BEAMS.get(p.getId());
        if (old != null) {
            old.stop();
        }
        Beam b = new Beam(p, charge, ticks, power);
        BEAMS.put(p.getId(), b);
        Vfx.add(b);
        if (!LintangHeat.firstPerson(p)) {   // kilatan saat sinar keluar dari mata
            for (Vec3 eye : LintangHeat.eyes(p, 1f)) {
                Vfx.add(new Fx.Flash(eye, 0.5f + 0.5f * charge, 0xFFF6E8, 4, 0.9f));
            }
        }
        if (self) {
            FovKick.punch(0.2f + 0.45f * charge);
            CameraShake.add(0.12f + 0.35f * charge);
            if (charge > 0.6f) {
                ScreenFlash.flash(0.12f * charge, 0xFF8A4A);
            }
        }
    }

    /** 0-1: seberapa penuh charge pemain ini sekarang (HUD, lapisan mata). */
    static float chargeLevel(AbstractClientPlayer p, float pt) {
        Charge c = CHARGES.get(p.getId());
        return c == null || !c.live() ? 0f : c.level(pt);
    }

    /** 0.44: sinar mata sedang dipakai (charge atau menyala) - kamera bahu. */
    static boolean active(AbstractClientPlayer p) {
        Charge c = CHARGES.get(p.getId());
        if (c != null && c.live()) {
            return true;
        }
        Beam b = BEAMS.get(p.getId());
        return b != null && b.alive() && b.firing(b.clock(0f));
    }

    /** 0-1: mata menyala (charge atau sinar yang sedang menyala), buat ShazamEyesLayer. */
    static float eyeHeat(AbstractClientPlayer p, float pt) {
        float k = chargeLevel(p, pt) > 0f ? 0.55f + 0.45f * chargeLevel(p, pt) : 0f;
        Beam b = BEAMS.get(p.getId());
        if (b != null && b.alive()) {
            k = Math.max(k, b.strength(b.clock(pt)));
        }
        return Mth.clamp(k, 0f, 1f);
    }

    /** 0.44 0-1: seberapa putih mata menyala (merah membara di awal charge, putih menyilaukan saat penuh & menembak). */
    static float eyeWhite(AbstractClientPlayer p, float pt) {
        float k = chargeLevel(p, pt);
        float w = k <= 0f ? 0f : Mth.clamp((k - 0.2f) / 0.55f, 0f, 1f);
        Beam b = BEAMS.get(p.getId());
        if (b != null && b.alive()) {
            w = Math.max(w, Math.min(1f, b.strength(b.clock(pt)) * (0.75f + 0.35f * b.charge)));
        }
        return w;
    }

    /** 0-1: seberapa tembus pandang kepala Lintang perlu dibuat (charge sampai 60%, sinar menyala penuh). */
    static float headFade(AbstractClientPlayer p, float pt) {
        float k = chargeLevel(p, pt) * 0.6f;
        Beam b = BEAMS.get(p.getId());
        if (b != null && b.alive()) {
            k = Math.max(k, Math.min(1f, b.strength(b.clock(pt)) * 1.4f));
        }
        return Mth.clamp(k, 0f, 1f);
    }

    static void tick() {
        CHARGES.values().removeIf(c -> !c.live());
        BEAMS.values().removeIf(b -> !b.alive());
    }

    // ------------------------------------------------------------------ gambar berkas

    /**
     * 0.44 Satu berkas gaya video (dari mata ke ujung): pendar jingga-persik lebar yang melebar di dekat kepala, rona merah
     * di pangkal mata, badan jingga muda, inti putih tebal yang pekat, garis paling panas, dan denyut energi yang
     * mengalir ke sasaran. w = lebar inti, a = kekuatan, fp = dari mata sendiri (orang pertama: pangkalnya memudar).
     */
    static void beam(Draw d, Vec3 from, Vec3 to, float w, float a, float t, int seed, float charge, boolean fp) {
        Vec3 path = to.subtract(from);
        double len = path.length();
        if (len < 0.05 || a <= 0.01f) {
            return;
        }
        int n = Mth.clamp((int) (len * 1.4) + 4, 5, 56);
        float[] pts = new float[n * 3], core = new float[n], haze = new float[n];
        float[] ca = new float[n], ha = new float[n], ra = new float[n];
        for (int i = 0; i < n; i++) {
            double u = i / (double) (n - 1), s = u * len;
            Vec3 q = from.add(path.scale(u));
            pts[i * 3] = (float) q.x;
            pts[i * 3 + 1] = (float) q.y;
            pts[i * 3 + 2] = (float) q.z;
            // energi panas yang nggak tenang: lebar bergetar halus merambat dari mata ke ujung (tetap lurus seperti video)
            float wob = 0.97f + 0.03f * Mth.sin((float) (s * 2.7) - t * 2.9f + seed) + 0.012f * Mth.sin((float) (s * 9.1) + t * 5.3f + seed * 2.3f);
            float grow = (float) Math.min(1.0, 0.35 + s * 1.8);   // tepat di mata masih ramping lalu cepat menebal
            float near = fp ? (float) Mth.clamp((s - 0.12) / 0.7, 0.0, 1.0) : 1f;
            core[i] = w * wob * grow;
            haze[i] = w * (2.6f + 1.4f * (float) Math.exp(-s * 0.25)) * grow;
            ca[i] = a * near;
            ha[i] = a * near * (0.85f + 0.15f * wob);
            ra[i] = a * near * (float) Math.exp(-s * 0.7);
        }
        boolean bloom = d.blooming();   // lapisan bloom: pendar lebarnya nggak perlu dilebarkan lagi
        float old = d.body(0.5f);
        if (!bloom) {
            d.strip(pts, n, haze, 1f, ha, 0.3f + 0.08f * charge, HAZE);   // pendar persik lebar
            d.body(0.3f);
            d.strip(pts, n, haze, 0.6f, ra, 0.45f, EMBER_RED);             // rona merah di pangkal mata
        }
        d.body(0.85f);
        d.strip(pts, n, core, 1.8f, ca, 0.55f, AMBER);                 // badan jingga muda
        d.body(1.25f);
        d.strip(pts, n, core, 1f, ca, 1f, WHITE_HOT);                  // inti putih pekat
        d.body(old);
        d.strip(pts, n, core, 0.42f, ca, 1f, 0xFFFFFF);                // garis paling panas
        // denyut energi: gumpalan terang yang mengalir dari mata ke sasaran
        double speed = 1.5 + 0.9 * charge, spacing = 3.4;
        double phase = ((t * speed + seed * 1.37) % spacing + spacing) % spacing;
        for (double s = phase; s < len; s += spacing) {
            Vec3 q = from.add(path.scale(s / len));
            float k = (float) Math.min(1.0, s) * (fp ? (float) Mth.clamp((s - 0.5) / 1.2, 0.0, 1.0) : 1f);
            d.glow(q.x, q.y, q.z, w * 2.0f, 0xFFF4E0, a * 0.3f * k);
        }
    }

    /** 0.44 Mata yang menyala: merah membara (white 0) sampai putih menyilaukan (white 1), pendar & kilau lensa mendatar. */
    static void eyeFlare(Draw d, Vec3 e, AbstractClientPlayer p, float pt, float a, float white, float t) {
        if (a <= 0.01f || LintangHeat.firstPerson(p)) {
            return;
        }
        float sc = (float) p.getScale();
        float flick = 0.92f + 0.08f * Mth.sin(t * 1.7f);
        int halo = Draw.mix(0xFF2A10, 0xFF9A50, white);
        int hot = Draw.mix(0xFF5A28, 0xFFFFFF, white);
        boolean bloom = d.blooming();
        d.glow(e.x, e.y, e.z, (0.2f + 0.1f * white) * sc * flick, halo, a * (bloom ? 0.35f : 0.6f));
        d.glow(e.x, e.y, e.z, (0.07f + 0.04f * white) * sc, hot, a);
        d.glow(e.x, e.y, e.z, 0.035f * sc, 0xFFFFFF, a * (0.4f + 0.6f * white));
        if (bloom) {
            return;
        }
        float yaw = p.getViewYRot(pt) * Mth.DEG_TO_RAD;
        double len = (0.3 + 0.25 * white) * sc, rx = -Math.cos(yaw) * len, rz = -Math.sin(yaw) * len;
        int streak = Draw.mix(0xFF4A20, 0xFFD8A8, white);
        d.line(e.x, e.y, e.z, e.x + rx, e.y, e.z + rz, 0.02f * sc, 0f, streak, a * 0.55f, 0f);
        d.line(e.x, e.y, e.z, e.x - rx, e.y, e.z - rz, 0.02f * sc, 0f, streak, a * 0.55f, 0f);
    }

    // ------------------------------------------------------------------ charge

    static final class Charge extends Effect {
        private final AbstractClientPlayer owner;
        private final LoopSound hum;
        private int releasedAt = -1;
        private boolean done;
        private boolean pinged;
        private boolean half;

        Charge(AbstractClientPlayer owner) {
            super(ShazamAnim.IRIS_CHARGE_TICKS * 8);
            this.owner = owner;
            this.hum = LoopSound.play(ShazamSounds.LASER_CHARGE.get(), owner::getEyePosition, () -> !done && owner.isAlive(),
                    0.25f, 0.6f);
        }

        float level(float pt) {
            return Mth.clamp((age + pt) / ShazamAnim.IRIS_CHARGE_TICKS, 0f, 1f);
        }

        void released() {
            if (releasedAt < 0) {
                releasedAt = age;
            }
        }

        void finish() {
            done = true;
        }

        boolean live() {
            return !done;
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (done || !owner.isAlive() || !ShazamClientState.isTransformed(owner.getId())
                    || (releasedAt >= 0 && age - releasedAt > 16) || age >= life) {
                done = true;
                return false;
            }
            age++;
            float k = level(0f);
            hum.setTarget(0.25f + 0.6f * k, 0.6f + 1.0f * k);
            boolean self = owner == Minecraft.getInstance().player;
            boolean fp = LintangHeat.firstPerson(owner);
            RandomSource r = level.random;
            Vec3[] e = LintangHeat.eyes(owner, 1f);
            Vec3 mid = e[0].add(e[1]).scale(0.5);
            double sc = owner.getScale();
            if (!fp && r.nextFloat() < 0.35f + 0.65f * k) {   // bara & panas tersedot ke mata
                Vec3 off = ShazamFx.randomDir(r).scale((0.9 + r.nextDouble() * 0.7) * sc);
                Vec3 p = mid.add(off);
                Vec3 v = off.scale(-0.11 - 0.08 * k);
                Vfx.mote(p.x, p.y, p.z, v.x, v.y, v.z, k > 0.6f ? 0xFFE6B8 : 0xFF6A2A, 0.05f + 0.04f * k, 8);
            }
            if (r.nextFloat() < 0.25f + 0.45f * k) {   // bara jingga melayang naik di sekitar kepala & bahu (video)
                double ang = r.nextDouble() * Math.PI * 2.0, rad = (0.4 + r.nextDouble() * 0.9) * sc;
                Vec3 p = owner.position().add(Math.cos(ang) * rad, (1.0 + r.nextDouble() * 1.1) * sc, Math.sin(ang) * rad);
                if (!fp || p.distanceTo(owner.getEyePosition()) > 0.8) {
                    Vfx.ember(p.x, p.y, p.z, (r.nextDouble() - 0.5) * 0.02, 0.015 + r.nextDouble() * 0.025, (r.nextDouble() - 0.5) * 0.02,
                            0.03f + 0.02f * k, 14 + r.nextInt(10));
                }
            }
            if (fp && r.nextFloat() < 0.25f + 0.5f * k) {   // POV: bara kecil melayang dari mata ke depan
                Vec3 look = owner.getViewVector(1f);
                Vec3 p = mid.add(look.scale(0.6 + r.nextDouble() * 0.6)).add(ShazamFx.randomDir(r).scale(0.25));
                Vfx.ember(p.x, p.y, p.z, look.x * 0.03, 0.01, look.z * 0.03, 0.02f + 0.02f * k, 8);
            }
            if (k >= 0.5f && !half) {   // separuh: mata mulai memutih
                half = true;
                if (!fp) {
                    for (Vec3 eye : e) {
                        Vfx.add(new Fx.Flash(eye, 0.35f, 0xFFD2A0, 3, 0.7f));
                    }
                }
            }
            if (k >= 1f && !pinged) {   // charge penuh: mata menyala putih sesaat
                pinged = true;
                if (!fp) {
                    for (Vec3 eye : e) {
                        Vfx.add(new Fx.Flash(eye, 0.7f, 0xFFF4E0, 5, 0.95f));
                    }
                }
                if (self) {
                    CameraShake.add(0.12f);
                }
            }
            if (self) {
                if (age % 3 == 0) {
                    ScreenFx.vignette(0.1f + 0.3f * k, 0x5A1206, 5);
                }
                if (k > 0.7f && age % 4 == 0) {
                    CameraShake.add(0.02f + 0.04f * k);
                }
            }
            return true;
        }

        @Override
        public void renderGlow(Draw d) {
            if (done || LintangHeat.firstPerson(owner)) {
                return;
            }
            float pt = d.partialTick;
            float k = level(pt);
            float t = age + pt;
            Vec3[] e = LintangHeat.eyes(owner, pt);
            float sc = (float) owner.getScale();
            float white = Mth.clamp((k - 0.2f) / 0.55f, 0f, 1f);
            float a = 0.55f + 0.45f * k;
            for (int i = 0; i < 2; i++) {
                Vec3 eye = e[i];
                eyeFlare(d, eye, owner, pt, a, white, t + i * 3f);
                if (k > 0.45f && !d.blooming()) {   // sinar mulai bocor dari mata: kilau bintang & berkas pendek berkedip ke depan
                    float kk = (k - 0.45f) / 0.55f;
                    d.glint(eye.x, eye.y, eye.z, (0.1f + 0.2f * kk) * sc, t * 0.05f + i, 0xFFF4E0, kk * 0.7f);
                    Vec3 look = owner.getViewVector(pt);
                    float flick = 0.5f + 0.5f * Mth.sin(t * 2.3f + i * 2f);
                    Vec3 tip = eye.add(look.scale((0.25 + 0.45 * kk * flick) * sc));
                    d.line(eye.x, eye.y, eye.z, tip.x, tip.y, tip.z, 0.05f * sc * kk, 0.01f, 0xFFE8C8, kk * 0.7f * flick, 0f);
                }
            }
        }

        @Override
        public void renderSoft(Draw d) {   // udara di atas kepala beriak panas
            if (done || LintangHeat.firstPerson(owner)) {
                return;
            }
            float pt = d.partialTick, k = level(pt), t = age + pt;
            if (k < 0.15f) {
                return;
            }
            Vec3[] e = LintangHeat.eyes(owner, pt);
            Vec3 mid = e[0].add(e[1]).scale(0.5);
            for (int s = 0; s < 3; s++) {
                Vec3 prev = null;
                for (int i = 0; i <= 6; i++) {
                    double u = i / 6.0;
                    double wob = Math.sin(u * 9.0 - t * 0.5 + s * 2.0) * 0.05;
                    Vec3 q = mid.add((s - 1) * 0.16 + wob, u * 0.7, wob * 0.5);
                    if (prev != null) {
                        d.line(prev.x, prev.y, prev.z, q.x, q.y, q.z, 0.03f, 0.03f, 0xFFF4EC, 0.1f * k, 0.1f * k * (float) (1.0 - u));
                    }
                    prev = q;
                }
            }
        }
    }

    // ------------------------------------------------------------------ sinar

    static final class Beam extends Effect {
        private final AbstractClientPlayer owner;
        final float charge;
        private final float power;
        private final int ticks;
        private final double range;
        private final long seed;
        private boolean stopped;
        private int stopAt;
        private double enemyDist = Double.MAX_VALUE;
        private Vec3 lastEnd;
        private Vec3 lastNormal = new Vec3(0, 1, 0);
        private float spotTemp = 20f;
        private int scorchCooldown;
        private boolean done;

        Beam(AbstractClientPlayer owner, float charge, int ticks, float power) {
            super(ticks + 6);
            this.owner = owner;
            this.charge = charge;
            this.ticks = ticks;
            this.power = power;
            this.range = LintangSkills.irisRange(charge);
            this.seed = Vfx.random().nextLong();
            LoopSound.play(ShazamSounds.LASER_LOOP.get(), owner::getEyePosition, () -> !done && firing(age) && owner.isAlive(),
                    0.45f + 0.5f * charge, 1.05f - 0.25f * charge);
        }

        void stop() {
            if (!stopped) {
                stopped = true;
                stopAt = age;
            }
        }

        boolean alive() {
            return !done;
        }

        float clock(float pt) {
            return age + pt;
        }

        boolean firing(float t) {
            return !stopped && t < ticks;
        }

        float strength(float t) {
            float in = Mth.clamp(t / 1.5f, 0f, 1f);
            float out = stopped ? Mth.clamp(1f - (t - stopAt) / 2f, 0f, 1f) : Mth.clamp((ticks - t) / 4f, 0f, 1f);
            return in * out * (0.6f + 0.4f * power);
        }

        /** 0.44 lebar inti putih (blok): jauh lebih tebal dari 0.42, makin di-charge makin tebal. */
        private float width(boolean fp) {
            return (fp ? 0.04f : 0.085f) * (1f + 0.9f * charge) * (float) owner.getScale();
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (!owner.isAlive() || owner.isRemoved() || !ShazamClientState.isTransformed(owner.getId())
                    || (stopped && age - stopAt > 3)) {
                done = true;
                return false;
            }
            if (firing(age)) {
                double[] dist = new double[1];
                LivingEntity mob = LintangHeat.enemyAt(owner, range, dist);
                enemyDist = mob == null ? Double.MAX_VALUE : dist[0];
                boolean[] block = new boolean[1];
                Direction[] face = new Direction[1];
                Vec3 end = LintangHeat.aimEnd(owner, 1f, range, enemyDist, block, face);
                Vec3 look = owner.getViewVector(1f);
                boolean onBlock = block[0] && face[0] != null;
                Vec3 n = onBlock ? new Vec3(face[0].getStepX(), face[0].getStepY(), face[0].getStepZ()) : look.scale(-1.0);
                lastEnd = end;
                lastNormal = n;
                if (onBlock) {   // suhu titik kena naik terus (cermin server: panas per denyut dibagi 2 tick)
                    Vec3 in = end.subtract(n.scale(0.05));
                    float q = Mth.lerp(charge, 120f, 300f) * power * 0.5f;
                    spotTemp = LintangHeat.heat(level, BlockPos.containing(in), face[0], q);
                    LintangBurn.beamHit(level, end, face[0], charge, spotTemp);
                } else {
                    spotTemp = 20f;
                }
                if (mob != null) {   // makhluk yang kena langsung terbakar
                    LintangBurn.igniteEntity(mob);
                }
                impact(level, end, n, onBlock, face[0]);
                trailEmbers(level, end);
                if (owner == Minecraft.getInstance().player && age % 3 == 0) {
                    ScreenFx.vignette(0.18f + 0.22f * charge, 0x5A1206, 5);
                    CameraShake.add(0.02f + 0.04f * charge);
                }
            }
            boolean more = super.tick(level);
            done = !more;
            return more;
        }

        /** Garis percikan memancar di permukaan, lelehan menetes jatuh, asap, bekas hangus di tanah. */
        private void impact(ClientLevel level, Vec3 end, Vec3 n, boolean block, Direction face) {
            RandomSource r = level.random;
            double[] e = new double[6];
            Draw.plane(n.x, n.y, n.z, e);
            for (int i = 0, k = Vfx.count(3 + 5 * charge); i < k; i++) {   // garis percikan putih-jingga memancar (video)
                double ang = r.nextDouble() * Math.PI * 2.0;
                Vec3 dir = new Vec3(e[0] * Math.cos(ang) + e[3] * Math.sin(ang), e[1] * Math.cos(ang) + e[4] * Math.sin(ang),
                        e[2] * Math.cos(ang) + e[5] * Math.sin(ang)).add(n.scale(0.15 + 0.5 * r.nextDouble())).add(0, 0.15, 0).normalize();
                Vec3 v = dir.scale((0.28 + 0.5 * r.nextDouble()) * (0.8 + 0.6 * charge));
                Vfx.streak(end.x, end.y, end.z, v.x, v.y, v.z, i % 3 == 0 ? 0xFFFFFF : i % 3 == 1 ? 0xFFE2B0 : 0xFF9A50,
                        0.045f + 0.03f * charge, 5 + r.nextInt(5));
            }
            for (int i = 0, k = Vfx.count(3 + 4 * charge); i < k; i++) {   // lelehan berpijar yang menetes & jatuh memantul
                Vec3 v = n.scale(0.08 + 0.1 * r.nextDouble()).add(ShazamFx.randomDir(r).scale(0.09)).add(0, 0.05, 0);
                Vfx.spark(end.x, end.y, end.z, v.x, v.y, v.z, i % 3 == 0 ? LintangHeat.CORE : i % 3 == 1 ? LintangHeat.HOT
                        : LintangHeat.ORANGE, 0.04f + 0.03f * r.nextFloat(), 12 + r.nextInt(10), end.y - 3.0);
            }
            if (age % 2 == 0) {   // asap gelap yang membubung
                Vfx.smoke(end.x + n.x * 0.15, end.y + n.y * 0.15 + 0.1, end.z + n.z * 0.15, (r.nextDouble() - 0.5) * 0.02, 0.05,
                        (r.nextDouble() - 0.5) * 0.02, 0x2A2420, 0.3f + 0.25f * charge + r.nextFloat() * 0.2f, 30);
            }
            if (block && face == Direction.UP && --scorchCooldown <= 0) {   // jejak hangus menyambung di tanah
                scorchCooldown = 2;
                Ground.Map map = ShazamFx.ground(level, end, 1.0);
                if (map != null && map.found && Math.abs(map.centerY - end.y) < 0.8) {
                    Vfx.add(new Fx.Scorch(map.center(end), 0.4 + 0.3 * charge, 160, 60, map));
                }
            }
        }

        /** Bara kecil yang sesekali terlepas dari berkas dan melayang naik. */
        private void trailEmbers(ClientLevel level, Vec3 end) {
            if (age % 2 != 0 || LintangHeat.firstPerson(owner)) {
                return;
            }
            RandomSource r = level.random;
            Vec3[] e = LintangHeat.eyes(owner, 1f);
            Vec3 a = e[r.nextInt(2)];
            Vec3 q = a.lerp(end, 0.1 + r.nextDouble() * 0.85);
            Vfx.ember(q.x, q.y, q.z, (r.nextDouble() - 0.5) * 0.02, 0.02 + r.nextDouble() * 0.02, (r.nextDouble() - 0.5) * 0.02,
                    0.04f + 0.02f * charge, 10 + r.nextInt(8));
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float t = age + pt;
            float a = strength(t);
            if (a <= 0.01f) {
                return;
            }
            boolean fp = LintangHeat.firstPerson(owner);
            Vec3[] e = LintangHeat.eyes(owner, pt);
            Vec3 end = firing(t) ? LintangHeat.aimEnd(owner, pt, range, enemyDist, null, null) : lastEnd;
            if (end == null) {
                return;
            }
            float bw = width(fp);
            beam(d, e[0], end, bw, a, t, 1, charge, fp);
            beam(d, e[1], end, bw, a, t, 7, charge, fp);
            float white = Math.min(1f, 0.8f + 0.3f * charge);
            eyeFlare(d, e[0], owner, pt, Math.min(1f, a * 1.2f), white, t);
            eyeFlare(d, e[1], owner, pt, Math.min(1f, a * 1.2f), white, t + 3f);
            // titik kena (video): kilatan putih-kuning besar, bintang panas berduri, pijar suhu blok
            float flick = 0.88f + 0.12f * Mth.sin(t * 3.3f) + 0.06f * Mth.sin(t * 8.1f);
            float size = (0.24f + 0.36f * charge) * (0.6f + 0.4f * power);
            float old = d.body(0.35f);
            if (!d.blooming()) {
                d.glow(end.x, end.y, end.z, (1.2f + 0.8f * charge) * flick, HAZE, a * 0.36f);
            }
            d.body(old);
            d.glow(end.x, end.y, end.z, (0.45f + 0.35f * charge) * flick, 0xFFF0C8, a * 0.85f);
            Molten.heatStar(d, end, lastNormal, size, a, t, seed);
            if (spotTemp > 450f) {   // titik kena berpijar sesuai suhunya (merah -> jingga -> kuning -> putih)
                d.glow(end.x, end.y, end.z, 0.9f + 0.6f * charge, LintangHeat.blackbody(spotTemp),
                        a * Mth.clamp((spotTemp - 450f) / 700f, 0f, 1f));
            }
        }

        /** Riak udara panas di sekeliling sinar (garis bergelombang tipis tembus pandang yang merambat). */
        @Override
        public void renderSoft(Draw d) {
            float pt = d.partialTick, t = age + pt;
            if (!firing(t) || LintangHeat.firstPerson(owner)) {
                return;
            }
            Vec3[] e = LintangHeat.eyes(owner, pt);
            Vec3 end = LintangHeat.aimEnd(owner, pt, range, enemyDist, null, null);
            Vec3 mid = e[0].add(e[1]).scale(0.5);
            Vec3 dir = end.subtract(mid);
            double len = dir.length();
            if (len < 0.8) {
                return;
            }
            dir = dir.scale(1.0 / len);
            Vec3 side = dir.cross(new Vec3(0, 1, 0));
            side = side.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : side.normalize();
            Vec3 up = side.cross(dir).normalize();
            int segs = Mth.clamp((int) (len * 1.2), 6, 40);
            float a = strength(t) * (0.12f + 0.08f * charge);
            double spread = 1.4 + 1.6 * charge;
            for (int k = 0; k < 3; k++) {
                double phase = t * 0.9 + k * 2.1, amp = (0.07 + 0.03 * k) * spread;
                Vec3 axis = k == 1 ? up : side;
                double off = (k == 0 ? 0.16 : k == 1 ? -0.15 : -0.17) * spread;
                Vec3 prev = null;
                for (int i = 0; i <= segs; i++) {
                    double u = i / (double) segs, s0 = u * len;
                    double wob = Math.sin(u * 22.0 - phase * 3.0) * amp * Math.min(1.0, s0 / 1.5);
                    Vec3 q = mid.add(dir.scale(s0)).add(axis.scale(wob + off));
                    if (prev != null) {
                        d.line(prev.x, prev.y, prev.z, q.x, q.y, q.z, 0.03f, 0.03f, 0xFFF4EC, a, a);
                    }
                    prev = q;
                }
            }
        }
    }
}
