package com.shazammod.client.fx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.shazammod.ShazamAnim;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Molten;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * 0.42 Lintas Detik (Z), efek di client. 0.44 dibuat ulang mengikuti video: begitu waktu "berhenti" dunia memucat jadi
 * abu-abu (semua yang beku ikut pucat), riak pucat menyebar dari Lintang; tiap sambaran meninggalkan bayangan Lintang yang
 * bercahaya (diam di udara dalam pose memukul), cincin putih tegas yang membeku di sekeliling musuh, dan garis cahaya
 * putih-emas yang melesat lurus dari musuh ke musuh. Ada jeda sesaat untuk menikmati semuanya, lalu waktu jalan lagi:
 * kilatan putih, warna dunia kembali, semua cincin meledak melebar bersamaan, gelombang kejut & debu di tiap musuh, dan
 * bayangan serta jejaknya memudar.
 */
final class LintangBlitz {
    private LintangBlitz() {}

    private static final Vec3 UP = new Vec3(0, 1, 0);

    /** Warna dunia saat waktu berhenti (abu-abu dingin) & seberapa pucat. */
    private static final int FROZEN_GRAY = 0x9EA6AE;
    private static final float FROZEN_TINT = 0.62f;

    private static final class State {
        final Molten.LightTrail trail;
        final Freeze freeze;
        final List<Molten.FrozenRing> rings = new ArrayList<>();
        final List<Afterimage> ghosts = new ArrayList<>();
        Vec3 last;
        int hits;

        State(AbstractClientPlayer caster, Vec3 start) {
            trail = new Molten.LightTrail(start);
            freeze = new Freeze(caster);
            last = start;
        }
    }

    /**
     * Dunia memucat abu-abu selama waktu berhenti (diperbarui tiap tick sampai dilepas, paling lama 6 detik). Pemain lain
     * yang dekat ikut melihat dunianya berhenti; makin jauh dari Lintang makin samar (lewat 48 blok nggak terasa).
     */
    private static final class Freeze extends Effect {
        private final AbstractClientPlayer caster;
        private boolean over;

        Freeze(AbstractClientPlayer caster) {
            super(120);
            this.caster = caster;
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (over) {
                return false;
            }
            float in = Mth.clamp((age + 1) / 3f, 0f, 1f);
            Minecraft mc = Minecraft.getInstance();
            float near = 1f;
            if (caster != mc.player && mc.gameRenderer != null) {
                double dist = mc.gameRenderer.getMainCamera().getPosition().distanceTo(caster.position());
                near = Mth.clamp((float) (48.0 - dist) / 24f, 0f, 1f);
            }
            if (near > 0f) {
                Vfx.worldTint(FROZEN_GRAY, FROZEN_TINT * in * near);
            }
            return super.tick(level);
        }

        void end() {
            over = true;
        }
    }

    private static final Map<Integer, State> STATES = new HashMap<>();

    static void clear() {
        STATES.clear();
    }

    private static Vec3 chest(AbstractClientPlayer p) {
        return p.position().add(0, 0.9 * p.getScale(), 0);
    }

    private static State state(AbstractClientPlayer caster) {
        return STATES.computeIfAbsent(caster.getId(), id -> {
            State s = new State(caster, chest(caster));
            Vfx.add(s.trail);
            Vfx.add(s.freeze);
            return s;
        });
    }

    static void start(AbstractClientPlayer caster, boolean self) {
        Vec3 c = chest(caster);
        State old = STATES.remove(caster.getId());
        if (old != null) {
            old.freeze.end();
        }
        State st = state(caster);
        Vfx.add(new Fx.Ripple(c, UP, 0.0, 0.5, 22.0, 0.6, 0xE8F0FF, 16, 0.5f, true));   // "waktu berhenti" menyebar
        Vfx.add(new Molten.FrozenRing(c, UP, 1.2));
        LintangFilm.shockwave(c, UP, 5.0, 10, 0.5f);
        ShazamPoses.ghostBurst(caster, ShazamAnim.BLITZ_WINDUP + 2);
        if (self) {
            ScreenFlash.flash(0.3f, 0xE8F0FF);
            ScreenFx.vignette(0.5f, 0x7A8AA0, ShazamAnim.BLITZ_WINDUP + 8 * ShazamAnim.BLITZ_STEP + ShazamAnim.BLITZ_RESUME);
            FovKick.kick(0.35f);
        }
        st.last = c;
    }

    static void hit(AbstractClientPlayer caster, Vec3 pos) {
        State st = state(caster);
        Vec3 d = pos.subtract(st.last);
        Vec3 flat = new Vec3(d.x, 0, d.z);
        if (flat.lengthSqr() < 1.0E-4) {
            Vec3 look = caster.getViewVector(1f);
            flat = new Vec3(look.x, 0, look.z);
        }
        flat = flat.lengthSqr() < 1.0E-4 ? new Vec3(0, 0, 1) : flat.normalize();
        // bayangan Lintang berdiri di tanah tepat di depan musuh, menghadap musuhnya
        Vec3 stand = pos.subtract(flat.scale(0.85));
        BlockHitResult ground = caster.level().clip(new ClipContext(stand, stand.subtract(0, 4.0, 0), ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, caster));
        double fy = ground.getType() == HitResult.Type.MISS ? pos.y - 1.2 : ground.getLocation().y;
        float yaw = (float) (Mth.atan2(-flat.x, flat.z) * Mth.RAD_TO_DEG);
        Afterimage ghost = new Afterimage(caster, new Vec3(stand.x, fy, stand.z), yaw, st.hits % 3);
        st.ghosts.add(ghost);
        Vfx.add(ghost);
        st.trail.add(pos);
        Molten.FrozenRing ring = new Molten.FrozenRing(pos, flat, 0.62);
        st.rings.add(ring);
        Vfx.add(ring);
        Vfx.add(new Fx.Flash(pos, 0.8f, 0xFFF6E8, 3, 0.85f));
        st.last = pos;
        st.hits++;
    }

    static void end(AbstractClientPlayer caster, Vec3 pos, boolean self) {
        State st = STATES.remove(caster.getId());
        if (st == null) {
            return;
        }
        st.freeze.end();   // warna dunia kembali
        st.trail.add(chest(caster));
        st.trail.end();
        for (Molten.FrozenRing ring : st.rings) {   // semua pukulan mendarat bersamaan
            ring.release();
            Vec3 c = ring.center();
            LintangFilm.impactFlash(c, 0.9f);
            LintangFilm.shockwave(c, UP, 3.5, 12, 0.85f);
            Vfx.add(new Fx.Flash(c, 2.2f, 0xFFFFFF, 6, 0.9f));
            ShazamFx.dustPuffs(caster.clientLevel, c.subtract(0, 0.8, 0), LintangFilm.DUST, 6, 0.6, 0.14);
        }
        for (Afterimage ghost : st.ghosts) {
            ghost.fade();
        }
        ShazamFx.shakeAround(chest(caster), 0.6f, 30);
        if (self) {
            CameraShake.add(0.45f);
            ScreenFlash.flash(0.55f, 0xFFFFFF);
            FovKick.punch(0.45f);
        }
    }

    /**
     * Bayangan Lintang yang memukul, membeku di tempat sambarannya: model pemain dengan kulitnya sendiri, tembus pandang
     * & sedikit bercahaya keemasan, dalam salah satu dari tiga pose pukulan. Digambar sendiri di dunia (bukan lewat
     * render pemain), jadi juga terlihat dari POV.
     */
    static final class Afterimage extends Effect {
        private final AbstractClientPlayer owner;
        private final Vec3 feet;
        private final float yaw;
        private final int pose;
        private int fadeAt = -1;

        Afterimage(AbstractClientPlayer owner, Vec3 feet, float yaw, int pose) {
            super(260);
            this.owner = owner;
            this.feet = feet;
            this.yaw = yaw;
            this.pose = pose;
        }

        void fade() {
            if (fadeAt < 0) {
                fadeAt = age;
            }
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (fadeAt < 0 && age > 220) {
                fade();
            }
            return super.tick(level) && (fadeAt < 0 || age - fadeAt < 10);
        }

        private float alpha(float pt) {
            float in = Mth.clamp((age + pt) / 2f, 0f, 1f);
            float out = fadeAt < 0 ? 1f : Mth.clamp(1f - (age + pt - fadeAt) / 10f, 0f, 1f);
            return in * out;
        }

        @Override
        public void renderSolid(PoseStack ps, MultiBufferSource buffers, double camX, double camY, double camZ, float pt) {
            float a = alpha(pt);
            if (a <= 0.02f || owner.isRemoved()) {
                return;
            }
            Minecraft mc = Minecraft.getInstance();
            if (!(mc.getEntityRenderDispatcher().getRenderer(owner) instanceof PlayerRenderer renderer)) {
                return;
            }
            PlayerModel<AbstractClientPlayer> m = renderer.getModel();
            ModelPart[] parts = {m.head, m.hat, m.body, m.jacket, m.rightArm, m.rightSleeve, m.leftArm, m.leftSleeve,
                    m.rightLeg, m.rightPants, m.leftLeg, m.leftPants};
            PartPose[] saved = new PartPose[parts.length];
            boolean[] visible = new boolean[parts.length];
            for (int i = 0; i < parts.length; i++) {
                saved[i] = parts[i].storePose();
                visible[i] = parts[i].visible;
                parts[i].resetPose();
            }
            try {
                punchPose(m, pose);
                m.head.visible = true;
                m.body.visible = true;
                m.rightArm.visible = true;
                m.leftArm.visible = true;
                m.rightLeg.visible = true;
                m.leftLeg.visible = true;
                m.hat.copyFrom(m.head);
                m.jacket.copyFrom(m.body);
                m.rightSleeve.copyFrom(m.rightArm);
                m.leftSleeve.copyFrom(m.leftArm);
                m.rightPants.copyFrom(m.rightLeg);
                m.leftPants.copyFrom(m.leftLeg);
                ps.pushPose();
                ps.translate(feet.x - camX, feet.y - camY, feet.z - camZ);
                float s = owner.getScale();
                ps.scale(s, s, s);
                ps.mulPose(Axis.YP.rotationDegrees(180f - yaw));
                ps.scale(-1f, -1f, 1f);
                ps.scale(0.9375f, 0.9375f, 0.9375f);
                ps.translate(0f, -1.501f, 0f);
                ResourceLocation skin = owner.getSkin().texture();
                m.renderToBuffer(ps, buffers.getBuffer(RenderType.entityTranslucent(skin)), LightTexture.FULL_BRIGHT,
                        OverlayTexture.NO_OVERLAY, ((int) (a * 165f) << 24) | 0xFFF4E2);
                m.renderToBuffer(ps, buffers.getBuffer(RenderType.entityTranslucentEmissive(skin)), LightTexture.FULL_BRIGHT,
                        OverlayTexture.NO_OVERLAY, ((int) (a * 110f) << 24) | 0xFFD070);
                ps.popPose();
            } finally {
                for (int i = 0; i < parts.length; i++) {
                    parts[i].loadPose(saved[i]);
                    parts[i].visible = visible[i];
                }
            }
        }

        /** 0.44 bayangannya bercahaya: pendar keemasan lembut di sekeliling badan (video). */
        @Override
        public void renderGlow(com.shazammod.client.vfx.Draw d) {
            float a = alpha(d.partialTick);
            if (a <= 0.02f) {
                return;
            }
            double s = owner.getScale();
            float t = age + d.partialTick;
            float pulse = 0.9f + 0.1f * Mth.sin(t * 0.5f + pose);
            d.glow(feet.x, feet.y + 1.0 * s, feet.z, (float) (1.15 * s) * pulse, 0xFFD890, a * 0.28f);
            d.glow(feet.x, feet.y + 1.2 * s, feet.z, (float) (0.5 * s), 0xFFF8EC, a * 0.2f);
        }

        /** 0 = tinju kanan lurus, 1 = tinju kiri lurus, 2 = uppercut kanan. Satuan model (radian). */
        private static void punchPose(PlayerModel<?> m, int variant) {
            float r = Mth.DEG_TO_RAD;
            if (variant == 2) {
                m.rightArm.xRot = -150f * r;
                m.rightArm.zRot = -8f * r;
                m.leftArm.xRot = -35f * r;
                m.leftArm.zRot = 18f * r;
                m.head.xRot = -12f * r;
                m.rightLeg.xRot = -18f * r;
                m.leftLeg.xRot = 26f * r;
                return;
            }
            boolean left = variant == 1;
            ModelPart punch = left ? m.leftArm : m.rightArm, guard = left ? m.rightArm : m.leftArm;
            float side = left ? -1f : 1f;
            punch.xRot = -90f * r;
            punch.yRot = 8f * r * side;
            guard.xRot = -62f * r;
            guard.zRot = 22f * r * side;
            m.head.xRot = 6f * r;
            m.rightLeg.xRot = (left ? 24f : -30f) * r;
            m.leftLeg.xRot = (left ? -30f : 24f) * r;
        }
    }
}
