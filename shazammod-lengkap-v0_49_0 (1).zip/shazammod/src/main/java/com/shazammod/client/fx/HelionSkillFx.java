package com.shazammod.client.fx;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.shazammod.HelionSkills;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.client.RivalPuppets;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Hd;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * 0.45 Efek sisa skill Projek Helion-6 (dipanggil HelionFx), semuanya radiasi & kristal Cryon:
 * L - Lahap Radiasi : aliran radiasi hijau melengkung dari tiap musuh ke dada Helion-6 dengan denyut terang yang mengalir
 *                     ke arahnya, musuhnya berpendar sakit, korona di dada.
 * O - Orbit Cryon   : enam kristal Cryon (oktahedron memanjang: sisi hijau tembus pandang, rusuk menyala) terbentuk &
 *                     mengorbit, lalu satu per satu melesat melengkung memburu musuh dan meledak di sasaran.
 * N - Nisan Kristal : telapak menghantam tanah, duri kristal Cryon meletus berderet menjauh, musuh yang kena terkurung
 *                     kristal, lalu kurungannya pecah berhamburan.
 * J - Gerhana Buatan: kepalan diangkat ke matahari, berkas radiasi ke langit, lalu piringan gelap bergeser menutup matahari
 *                     sungguhan dengan korona hijau pucat; dunia di sekitarnya menggelap selama gerhana.
 */
public final class HelionSkillFx {
    private HelionSkillFx() {}

    private static final int CRYON = HelionFx.CRYON;
    private static final int CRYON_HOT = HelionFx.CRYON_HOT;
    private static final int CRYON_MID = HelionFx.CRYON_MID;
    private static final int CRYON_DEEP = HelionFx.CRYON_DEEP;
    private static final int CRYON_DARK = HelionFx.CRYON_DARK;
    private static final int CORONA = 0xC8FFDC;
    private static final Vec3 UP = new Vec3(0, 1, 0);
    /** Jarak piringan gerhana dari kamera (blok): cukup jauh supaya tertutup gunung, cukup dekat supaya nggak hilang di kabut. */
    private static final double SKY_DIST = 64.0;
    private static final double LAHAP_RANGE = 12.0;

    private static final Map<Integer, Orbit> ORBITS = new HashMap<>();
    private static final List<EclipseSky> SKIES = new ArrayList<>();

    public static void clear() {
        ORBITS.clear();
        SKIES.clear();
    }

    /** Tiap tick: dunia di bawah gerhana menggelap (lapisan warna Vfx), kristal orbit yang selesai dibuang. */
    public static void tick(ClientLevel level) {
        ORBITS.values().removeIf(Orbit::expired);
        SKIES.removeIf(EclipseSky::expired);
        if (SKIES.isEmpty()) {
            return;
        }
        Vec3 cam = Minecraft.getInstance().gameRenderer.getMainCamera().getPosition();
        float dark = 0f;
        for (EclipseSky sky : SKIES) {
            dark = Math.max(dark, sky.darkness(cam.x, cam.z));
        }
        if (dark > 0.01f) {
            Vfx.worldTint(0x050F0A, 0.45f * dark);
        }
    }

    static Vec3 chestOf(Entity e, float pt) {
        return new Vec3(Mth.lerp(pt, e.xo, e.getX()), Mth.lerp(pt, e.yo, e.getY()) + e.getBbHeight() * 0.6, Mth.lerp(pt, e.zo, e.getZ()));
    }

    /**
     * 0.46 Sasaran efek Helion-6 (sinar berhenti, aliran Lahap Radiasi): monster untuk pemain; untuk rival (pemain boneka)
     * pemain sungguhan, sama dengan lawan rival di server.
     */
    static boolean foeOf(AbstractClientPlayer caster, Entity e) {
        if (caster instanceof RivalPuppets.Puppet) {
            return e instanceof Player && !(e instanceof RivalPuppets.Puppet);
        }
        return e instanceof Enemy;
    }

    static Vec3 sunDir(Level level, float pt) {
        float a = level.getTimeOfDay(pt) * (float) (Math.PI * 2.0);
        return new Vec3(-Mth.sin(a), Mth.cos(a), 0);
    }

    /**
     * Kristal Cryon (oktahedron memanjang searah axis): sisi tembus pandang hijau di lapisan soft (glow = false), rusuk
     * putih kehijauan & inti yang berpendar di lapisan cahaya (glow = true).
     */
    static void crystal(Draw d, boolean glow, Vec3 p, Vec3 axis, double len, double width, float a) {
        Vec3 ax = axis.lengthSqr() < 1.0E-6 ? UP : axis.normalize();
        Vec3 b = ax.cross(Math.abs(ax.y) < 0.9 ? UP : new Vec3(1, 0, 0)).normalize();
        Vec3 c = ax.cross(b).normalize();
        Vec3 top = p.add(ax.scale(len)), bottom = p.subtract(ax.scale(len * 0.55));
        Vec3[] e = new Vec3[4];
        for (int k = 0; k < 4; k++) {
            double ang = k * Math.PI * 0.5 + 0.4;
            e[k] = p.add(b.scale(Math.cos(ang) * width)).add(c.scale(Math.sin(ang) * width));
        }
        for (int k = 0; k < 4; k++) {
            Vec3 e0 = e[k], e1 = e[(k + 1) % 4];
            if (glow) {
                d.line(top.x, top.y, top.z, e0.x, e0.y, e0.z, 0.022f, 0.022f, CRYON_HOT, 0.75f * a, 0.5f * a);
                d.line(bottom.x, bottom.y, bottom.z, e0.x, e0.y, e0.z, 0.02f, 0.02f, CRYON, 0.55f * a, 0.4f * a);
                d.line(e0.x, e0.y, e0.z, e1.x, e1.y, e1.z, 0.02f, 0.02f, CRYON, 0.45f * a, 0.45f * a);
            } else {
                d.quad(top.x, top.y, top.z, e0.x, e0.y, e0.z, e1.x, e1.y, e1.z, e1.x, e1.y, e1.z,
                        k % 2 == 0 ? CRYON_DEEP : CRYON_MID, 0.8f * a, 0.7f * a, 0.7f * a, 0.7f * a);
                d.quad(bottom.x, bottom.y, bottom.z, e1.x, e1.y, e1.z, e0.x, e0.y, e0.z, e0.x, e0.y, e0.z,
                        CRYON_DARK, 0.75f * a, 0.7f * a, 0.7f * a, 0.7f * a);
            }
        }
        if (glow) {
            d.glow(p.x, p.y, p.z, (float) (width * 2.6), CRYON, 0.55f * a);
        }
    }

    // ------------------------------------------------------------------ L - Lahap Radiasi

    static void lahap(AbstractClientPlayer caster, boolean self) {
        int life = ShazamAnim.HELION_LAHAP_TICKS;
        Vfx.add(new Leech(caster, life));
        Vfx.add(new Hd.Corona(CineKit.chestAnchor(caster), 0.4, 2.0, 12, CRYON, CRYON_HOT, life, 0.5f, null));
        HelionComic.word(chestOf(caster, 1f).add(0, 1.2, 0), "SHLRRRP!", 1.1f);
        if (self) {
            ScreenFx.vignette(0.35f, 0x02200E, life);
        }
    }

    /** Aliran radiasi dari musuh-musuh terdekat (dicari sendiri tiap 4 tick, sama dengan server) ke dada Helion-6. */
    static final class Leech extends Effect {
        private final AbstractClientPlayer p;
        private final List<LivingEntity> targets = new ArrayList<>();

        Leech(AbstractClientPlayer p, int life) {
            super(life);
            this.p = p;
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (!p.isAlive()) {
                return false;
            }
            if (age % 4 == 0) {
                targets.clear();
                List<LivingEntity> near = level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(LAHAP_RANGE),
                        e -> e != p && e.isAlive() && foeOf(p, e) && e.distanceToSqr(p) <= LAHAP_RANGE * LAHAP_RANGE);
                near.sort(Comparator.comparingDouble(e -> e.distanceToSqr(p)));
                for (int i = 0; i < Math.min(6, near.size()); i++) {
                    targets.add(near.get(i));
                }
            }
            RandomSource r = level.random;
            Vec3 c = chestOf(p, 1f);
            for (LivingEntity m : targets) {
                if (!m.isAlive()) {
                    continue;
                }
                Vec3 s = chestOf(m, 1f);
                if (age % 2 == 0) {
                    Vec3 v = c.subtract(s).scale(0.09);
                    Vfx.mote(s.x + (r.nextDouble() - 0.5) * 0.5, s.y + (r.nextDouble() - 0.5) * 0.5, s.z + (r.nextDouble() - 0.5) * 0.5,
                            v.x, v.y, v.z, CRYON, 0.08f, 10);
                }
                if (age % 8 == 0) {
                    Vfx.add(new Fx.Flash(s, 0.5f, CRYON, 4, 0.5f));
                }
            }
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float t = time(pt);
            float s = Mth.clamp(t / 5f, 0f, 1f) * Mth.clamp((life - t) / 6f, 0f, 1f);
            if (s <= 0.01f) {
                return;
            }
            Vec3 c = chestOf(p, pt);
            int idx = 0;
            int n = 18;
            for (LivingEntity m : targets) {
                idx++;
                if (!m.isAlive()) {
                    continue;
                }
                Vec3 a = chestOf(m, pt);
                Vec3 mid = a.add(c).scale(0.5).add(0, 0.9 + 0.3 * Math.sin(t * 0.2 + idx), 0);
                float[] pts = new float[n * 3];
                for (int k = 0; k < n; k++) {
                    double u = k / (double) (n - 1);
                    double x = (1 - u) * (1 - u) * a.x + 2 * (1 - u) * u * mid.x + u * u * c.x;
                    double y = (1 - u) * (1 - u) * a.y + 2 * (1 - u) * u * mid.y + u * u * c.y;
                    double z = (1 - u) * (1 - u) * a.z + 2 * (1 - u) * u * mid.z + u * u * c.z;
                    double wob = Math.sin(u * 9.0 - t * 0.6 + idx) * 0.08 * Math.sin(u * Math.PI);
                    pts[k * 3] = (float) (x + wob);
                    pts[k * 3 + 1] = (float) (y + wob * 0.6);
                    pts[k * 3 + 2] = (float) (z - wob);
                }
                d.strip(pts, n, 0.16f, 0.06f, CRYON, 0.25f * s, 0.55f * s);
                d.strip(pts, n, 0.05f, 0.025f, CRYON_HOT, 0.4f * s, 0.7f * s);
                for (int q = 0; q < 3; q++) {   // denyut yang mengalir ke Helion-6
                    double u = (t * 0.07 + q / 3.0 + idx * 0.21) % 1.0;
                    int k = Math.min(n - 1, (int) (u * (n - 1)));
                    d.glow(pts[k * 3], pts[k * 3 + 1], pts[k * 3 + 2], 0.22f, CRYON_HOT, 0.8f * s);
                }
                d.glow(a.x, a.y, a.z, 0.7f, CRYON, 0.35f * s);
            }
            d.glow(c.x, c.y, c.z, 0.9f, CRYON, 0.45f * s);
        }
    }

    // ------------------------------------------------------------------ O - Orbit Cryon

    static void orbit(AbstractClientPlayer caster, boolean self) {
        Orbit orbit = new Orbit(caster);
        ORBITS.put(caster.getId(), orbit);
        Vfx.add(orbit);
        Vec3 c = chestOf(caster, 1f);
        Vfx.add(new Fx.Flash(c, 1.4f, CRYON, 6, 0.7f));
        CineKit.motesOut(c, 18, CRYON, 0.08, 0.1f, 14);
        HelionComic.word(c.add(0, 1.3, 0), "KRRZZING!", 1.0f);
        if (self) {
            CameraShake.add(0.15f);
        }
    }

    /** Enam kristal Cryon yang mengorbit dada Helion-6; yang sudah melesat nggak digambar lagi. */
    static final class Orbit extends Effect {
        final AbstractClientPlayer p;
        int remaining = HelionSkills.ORBIT_SHARDS;

        Orbit(AbstractClientPlayer p) {
            super(ShazamAnim.HELION_ORBIT_TICKS + 12);
            this.p = p;
        }

        boolean expired() {
            return age >= life || !p.isAlive();
        }

        private double radius(float t) {
            return 1.55 * Mth.clamp(t / HelionSkills.ORBIT_SUMMON, 0f, 1f);
        }

        Vec3 shardPos(int i, float pt) {
            float t = time(pt);
            Vec3 c = chestOf(p, pt);
            double ang = t * 0.21 + i * Math.PI * 2.0 / HelionSkills.ORBIT_SHARDS;
            double r = radius(t);
            return c.add(Math.cos(ang) * r, Math.sin(t * 0.15 + i) * 0.18 - (1.55 - r) * 0.4, Math.sin(ang) * r);
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (!p.isAlive() || !ShazamClientState.isTransformed(p.getId()) || (remaining <= 0 && age > 2)) {
                return false;
            }
            if (age % 3 == 0 && remaining > 0) {
                Vec3 s = shardPos(HelionSkills.ORBIT_SHARDS - remaining + level.random.nextInt(remaining), 0f);
                Vfx.glint(s.x, s.y, s.z, CRYON_HOT, 0.16f, 5);
            }
            return super.tick(level);
        }

        @Override
        public void renderSoft(Draw d) {
            draw(d, false);
        }

        @Override
        public void renderGlow(Draw d) {
            draw(d, true);
        }

        private void draw(Draw d, boolean glow) {
            float pt = d.partialTick;
            float t = time(pt);
            float a = Mth.clamp(t / 6f, 0f, 1f) * Mth.clamp((life - t) / 8f, 0f, 1f);
            if (a <= 0.01f) {
                return;
            }
            Vec3 c = chestOf(p, pt);
            for (int i = HelionSkills.ORBIT_SHARDS - remaining; i < HelionSkills.ORBIT_SHARDS; i++) {
                Vec3 s = shardPos(i, pt);
                Vec3 out = s.subtract(c);
                Vec3 axis = out.lengthSqr() < 1.0E-4 ? UP : out.normalize().add(0, 0.6, 0);
                crystal(d, glow, s, axis, 0.34, 0.11, a);
            }
            if (glow) {
                d.ring(c.x, c.y, c.z, 0, 1, 0, radius(t), 0.03, CRYON, 0.25f * a, 0f, null);
            }
        }
    }

    /** Satu kristal dilepas dari orbit (HELION_SHARD, pos = titik sasaran). Lama terbangnya sama dengan di server. */
    static void shard(AbstractClientPlayer caster, Vec3 aim) {
        Orbit orbit = ORBITS.get(caster.getId());
        Vec3 from;
        if (orbit != null && orbit.remaining > 0) {
            from = orbit.shardPos(HelionSkills.ORBIT_SHARDS - orbit.remaining, 0f);
            orbit.remaining--;
        } else {
            from = chestOf(caster, 1f);
        }
        Vec3 chest = caster.position().add(0, caster.getBbHeight() * 0.55, 0);
        int travel = Math.max(2, (int) Math.ceil(aim.distanceTo(chest) / HelionSkills.SHARD_SPEED));
        Vfx.add(new Missile(from, aim, travel));
        Vfx.add(new Fx.Flash(from, 0.5f, CRYON_HOT, 3, 0.8f));
    }

    /** Kristal yang melesat melengkung ke sasaran dengan jejak hijau, lalu meledak. */
    static final class Missile extends Effect {
        private final Vec3 a, b, side;
        private final int travel;
        private final double arc;
        private boolean hit;

        Missile(Vec3 a, Vec3 b, int travel) {
            super(travel + 1);
            this.a = a;
            this.b = b;
            this.travel = travel;
            RandomSource r = Vfx.random();
            this.arc = 0.6 + r.nextDouble() * 1.2;
            Vec3 dir = b.subtract(a);
            Vec3 s = dir.cross(UP);
            s = s.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : s.normalize();
            this.side = r.nextBoolean() ? s : s.scale(-1);
        }

        private Vec3 at(float t) {
            double u = Mth.clamp(t / travel, 0.0, 1.0);
            double bump = Math.sin(u * Math.PI) * arc;
            return a.lerp(b, u).add(side.scale(bump)).add(0, bump * 0.5, 0);
        }

        @Override
        public boolean tick(ClientLevel level) {
            Vec3 p = at(age);
            Vfx.mote(p.x, p.y, p.z, 0, 0.01, 0, CRYON, 0.09f, 8);
            if (!hit && age + 1 >= travel) {
                hit = true;
                Vfx.add(new Fx.Flash(b, 1.2f, CRYON_HOT, 4, 0.9f));
                Vfx.add(new Fx.Flash(b, 2.2f, CRYON, 8, 0.4f));
                CineKit.sparks(b, 14, CRYON, 0.35, 0.06f, 10, b.y - 2.0);
                RandomSource r = level.random;
                for (int i = 0, n = Vfx.count(8); i < n; i++) {
                    Vec3 v = ShazamFx.randomDir(r).scale(0.15 + r.nextDouble() * 0.2);
                    Vfx.shard(b.x, b.y, b.z, v.x, v.y + 0.12, v.z, CRYON, 0.1f, 18, b.y - 2.0);
                }
                if (r.nextInt(2) == 0) {
                    HelionComic.word(b.add(0, 0.6, 0), HelionComic.pick(HelionComic.SHARD_WORDS), 0.75f);
                }
            }
            return super.tick(level);
        }

        @Override
        public void renderSoft(Draw d) {
            float t = time(d.partialTick);
            if (t > travel) {
                return;
            }
            Vec3 p = at(t);
            crystal(d, false, p, at(t + 0.3f).subtract(p), 0.3, 0.1, 1f);
        }

        @Override
        public void renderGlow(Draw d) {
            float t = time(d.partialTick);
            if (t > travel) {
                return;
            }
            Vec3 p = at(t);
            crystal(d, true, p, at(t + 0.3f).subtract(p), 0.3, 0.1, 1f);
            int n = 10;
            float[] pts = new float[n * 3];
            for (int k = 0; k < n; k++) {
                Vec3 q = at(Math.max(0f, t - (n - 1 - k) * 0.35f));
                pts[k * 3] = (float) q.x;
                pts[k * 3 + 1] = (float) q.y;
                pts[k * 3 + 2] = (float) q.z;
            }
            d.strip(pts, n, 0.02f, 0.14f, CRYON, 0.05f, 0.7f);
        }
    }

    // ------------------------------------------------------------------ N - Nisan Kristal

    /** dir = arah datar deretan kristal (dari server). Jalurnya dihitung sama persis dengan server. */
    static void nisan(AbstractClientPlayer caster, Vec3 dir, boolean self) {
        Vec3 flat = new Vec3(dir.x, 0, dir.z);
        if (flat.lengthSqr() < 1.0E-4) {
            Vec3 look = caster.getViewVector(1f);
            flat = new Vec3(look.x, 0, look.z);
        }
        final Vec3 d = flat.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : flat.normalize();
        final Vec3 origin = caster.position().add(d.scale(1.2));
        final boolean[] stopped = {false};
        int w = ShazamAnim.HELION_NISAN_WINDUP;
        ShazamFx.schedule(w - 1, 1, (level, t) -> {   // telapak menghantam tanah
            Vec3 f = caster.position();
            CineKit.shock(level, f.add(0, 0.1, 0), UP, 4.0, CRYON, CRYON_HOT, 12, 0.8f, true);
            Vfx.add(new Fx.Flash(f.add(d.scale(0.8)).add(0, 0.3, 0), 1.2f, CRYON_HOT, 4, 0.8f));
            if (self) {
                CameraShake.add(0.3f);
                FovKick.punch(0.2f);
            }
        });
        ShazamFx.schedule(w, HelionSkills.TOMB_STEPS, (level, t) -> {
            if (stopped[0]) {
                return;
            }
            Vec3 p = origin.add(d.scale(t * HelionSkills.TOMB_STEP));
            BlockHitResult hit = level.clip(new ClipContext(p.add(0, 2.5, 0), p.add(0, -5.0, 0), ClipContext.Block.COLLIDER,
                    ClipContext.Fluid.NONE, caster));
            if (hit.getType() == HitResult.Type.MISS) {
                stopped[0] = true;
                return;
            }
            Vec3 g = hit.getLocation();
            RandomSource r = level.random;
            Ground.Map map = ShazamFx.ground(level, g, 2.2);
            Vfx.add(new Hd.Frost(g, 1.5, CRYON, 5, 120, 0.95f, map));
            Vfx.add(new Fx.Pillar(g, 1.6 + r.nextDouble(), 0.35f, CRYON, 10));
            for (int i = 0, n = Vfx.count(6); i < n; i++) {
                Vfx.shard(g.x, g.y + 0.3, g.z, (r.nextDouble() - 0.5) * 0.2, 0.15 + r.nextDouble() * 0.2, (r.nextDouble() - 0.5) * 0.2,
                        CRYON, 0.14f, 22, g.y);
            }
            ShazamFx.dustPuffs(level, g, 0x8C8274, 4, 0.6, 0.12);
            if (self) {
                CameraShake.add(0.06f);
            } else if (t % 3 == 0) {
                ShazamFx.shakeAround(g, 0.12f, 16);
            }
            if (t == HelionSkills.TOMB_STEPS - 1) {
                HelionComic.word(g.add(0, 1.6, 0), "KRRSSHH!", 1.2f);
            }
        });
    }

    /** Musuh terkurung kristal (HELION_TOMB_LOCK: x = id makhluk, y = lama kurungan). */
    static void tomb(AbstractClientPlayer caster, Vec3 data) {
        Entity m = caster.level().getEntity((int) Math.round(data.x));
        if (m == null) {
            return;
        }
        Vfx.add(new Tomb(m, Math.max(10, (int) Math.round(data.y))));
        Vfx.add(new Fx.Flash(chestOf(m, 1f), 1.0f, CRYON_HOT, 4, 0.8f));
    }

    static void shatter(Vec3 pos, boolean self) {
        Vfx.add(new Fx.Flash(pos, 1.4f, CRYON_HOT, 4, 0.9f));
        Vfx.add(new Fx.Flash(pos, 2.4f, CRYON, 8, 0.4f));
        RandomSource r = Vfx.random();
        for (int i = 0, n = Vfx.count(22); i < n; i++) {
            Vec3 v = ShazamFx.randomDir(r).scale(0.12 + r.nextDouble() * 0.28);
            Vfx.shard(pos.x, pos.y, pos.z, v.x, Math.abs(v.y) + 0.1, v.z, i % 3 == 0 ? CRYON_HOT : CRYON, 0.12f + r.nextFloat() * 0.08f,
                    24, pos.y - 2.0);
        }
        CineKit.sparks(pos, 16, CRYON, 0.35, 0.06f, 10, pos.y - 2.0);
        HelionComic.word(pos.add(0, 0.8, 0), HelionComic.pick(HelionComic.SHATTER_WORDS), 1.0f);
        if (self) {
            CameraShake.add(0.12f);
        }
    }

    /** Kurungan: kristal-kristal yang tumbuh miring keluar di sekeliling badan, cangkang hijau tipis di dalamnya. */
    static final class Tomb extends Effect {
        private final Entity m;
        private final long seed;

        Tomb(Entity m, int life) {
            super(life + 2);
            this.m = m;
            this.seed = Vfx.random().nextLong();
        }

        @Override
        public boolean tick(ClientLevel level) {
            return m.isAlive() && super.tick(level);
        }

        @Override
        public void renderSoft(Draw d) {
            draw(d, false);
        }

        @Override
        public void renderGlow(Draw d) {
            draw(d, true);
        }

        private void draw(Draw d, boolean glow) {
            float pt = d.partialTick;
            float t = time(pt);
            float grow = Mth.clamp(t / 5f, 0f, 1f);
            float a = Mth.clamp((life - t) / 3f, 0f, 1f);
            if (a <= 0.01f) {
                return;
            }
            Vec3 base = new Vec3(Mth.lerp(pt, m.xo, m.getX()), Mth.lerp(pt, m.yo, m.getY()), Mth.lerp(pt, m.zo, m.getZ()));
            double h = m.getBbHeight(), r = m.getBbWidth() * 0.6 + 0.25;
            RandomSource rnd = RandomSource.create(seed);
            for (int i = 0; i < 9; i++) {
                double ang = i * Math.PI * 2.0 / 9 + rnd.nextDouble() * 0.5;
                double y = h * (0.1 + rnd.nextDouble() * 0.8);
                Vec3 p = base.add(Math.cos(ang) * r, y, Math.sin(ang) * r);
                Vec3 axis = new Vec3(Math.cos(ang), 0.8 + rnd.nextDouble() * 0.8, Math.sin(ang));
                double len = (0.3 + rnd.nextDouble() * 0.35) * Math.max(0.8, h * 0.5) * grow;
                crystal(d, glow, p, axis, len, 0.12 + rnd.nextDouble() * 0.06, a);
            }
            if (glow) {
                Vec3 c = base.add(0, h * 0.5, 0);
                d.shell(c.x, c.y, c.z, Math.max(h * 0.55, r) * grow, CRYON, 0.22f * a, 2.0, 1.0);
            }
        }
    }

    // ------------------------------------------------------------------ J - Gerhana Buatan

    static void eclipse(AbstractClientPlayer caster, Vec3 center, boolean self) {
        Level level = caster.level();
        int w = ShazamAnim.HELION_ECLIPSE_WINDUP;
        HelionSkills.addEclipse(level, center, HelionSkills.ECLIPSE_RADIUS, level.getGameTime() + w + HelionSkills.ECLIPSE_TICKS);
        EclipseSky sky = new EclipseSky(center, HelionSkills.ECLIPSE_RADIUS, w, HelionSkills.ECLIPSE_TICKS);
        SKIES.add(sky);
        Vfx.add(sky);
        ShazamFx.schedule(5, 1, (lvl, t) -> {   // berkas radiasi dari kepalan ke matahari
            Vec3 hand = ShazamPoses.handPos(caster, true, 1f);
            Vfx.add(new Hd.Lance(hand, hand.add(sunDir(lvl, 1f).scale(90.0)), 0.35f, CRYON, CRYON_HOT, 6, w - 5));
            Vfx.add(new Fx.Flash(hand, 0.9f, CRYON_HOT, 6, 0.9f));
        });
        ShazamFx.schedule(5, w - 5, (lvl, t) -> {
            Vec3 hand = ShazamPoses.handPos(caster, true, 1f);
            RandomSource r = lvl.random;
            Vfx.mote(hand.x + (r.nextDouble() - 0.5) * 0.4, hand.y, hand.z + (r.nextDouble() - 0.5) * 0.4, 0, 0.12 + r.nextDouble() * 0.1, 0,
                    CRYON, 0.1f, 18);
            if (self) {
                CameraShake.add(0.02f);
            }
        });
        if (self) {
            ScreenFx.cinema(60);
            ScreenFx.titleKey("title.shazammod.eclipse", HelionFx.CRYON, 70, w);
            HelionComic.caption(Component.translatable("caption.shazammod.helion.eclipse"));
        }
    }

    /**
     * Gerhana di langit: piringan gelap tepat di arah matahari sungguhan (ikut waktu), bergeser menutupnya selama ancang-
     * ancang, korona hijau pucat & sinar halus di sekelilingnya, kilau "cincin berlian" di tepinya. Cuma terlihat di dalam
     * & sekitar wilayah gerhana.
     */
    static final class EclipseSky extends Effect {
        private final Vec3 center;
        private final double radius;
        private final int windup;

        EclipseSky(Vec3 center, double radius, int windup, int ticks) {
            super(windup + ticks);
            this.center = center;
            this.radius = radius;
            this.windup = windup;
        }

        boolean expired() {
            return age >= life;
        }

        /** 0-1: seberapa gelap dunia di titik ini sekarang (piringan menutup x memudar di akhir x dekat wilayahnya). */
        float darkness(double x, double z) {
            return cover(age) * fade(age) * near(x, z);
        }

        float cover(float t) {
            float k = Mth.clamp((t - windup * 0.3f) / (windup * 1.2f), 0f, 1f);
            return k * k * (3f - 2f * k);
        }

        float fade(float t) {
            return Mth.clamp((life - t) / 60f, 0f, 1f);
        }

        float near(double x, double z) {
            double dx = x - center.x, dz = z - center.z;
            return (float) Mth.clamp(1.0 - (Math.sqrt(dx * dx + dz * dz) - radius) / 40.0, 0.0, 1.0);
        }

        /** Pusat piringan (dunia) & arah ke kamera, atau null kalau matahari di bawah cakrawala / terlalu jauh. */
        private Vec3[] place(Draw d, float t, float k) {
            ClientLevel level = Minecraft.getInstance().level;
            if (level == null || k <= 0.01f) {
                return null;
            }
            Vec3 sun = sunDir(level, d.partialTick);
            if (sun.y < -0.12) {
                return null;
            }
            Vec3 side = sun.cross(new Vec3(0, 0, 1));
            side = side.lengthSqr() < 1.0E-4 ? new Vec3(0, 0, 1) : side.normalize();
            double slide = (1.0 - cover(t)) * 24.0;
            Vec3 c = new Vec3(d.camX, d.camY, d.camZ).add(sun.scale(SKY_DIST)).add(side.scale(slide));
            return new Vec3[] {c, sun, side};
        }

        @Override
        public void renderSoft(Draw d) {
            float t = time(d.partialTick);
            float k = Math.min(1f, cover(t) * 1.6f) * fade(t) * near(d.camX, d.camZ);
            Vec3[] p = place(d, t, k);
            if (p == null) {
                return;
            }
            Vec3 c = p[0], n = p[1].scale(-1);
            d.disc(c.x, c.y, c.z, n.x, n.y, n.z, 10.5, 0x020604, 0.97f * k, 0.97f * k, null);
        }

        @Override
        public void renderGlow(Draw d) {
            float t = time(d.partialTick);
            float k = cover(t) * fade(t) * near(d.camX, d.camZ);
            Vec3[] p = place(d, t, k);
            if (p == null) {
                return;
            }
            Vec3 c = p[0], sun = p[1], side = p[2];
            Vec3 n = sun.scale(-1);
            float pulse = 0.85f + 0.15f * Mth.sin(t * 0.07f);
            d.ring(c.x, c.y, c.z, n.x, n.y, n.z, 11.5, 2.6, CORONA, 0.6f * k * pulse, 0f, null);
            d.ring(c.x, c.y, c.z, n.x, n.y, n.z, 14.5, 7.0, CRYON, 0.22f * k, 0f, null);
            Vec3 up2 = side.cross(sun).normalize();
            for (int i = 0; i < 14; i++) {   // sinar korona yang halus
                double ang = i * Math.PI * 2.0 / 14 + t * 0.002;
                Vec3 dir = side.scale(Math.cos(ang)).add(up2.scale(Math.sin(ang)));
                double len = 18.0 + 6.0 * Math.sin(i * 1.7 + t * 0.05);
                Vec3 a0 = c.add(dir.scale(11.0)), a1 = c.add(dir.scale(len));
                d.line(a0.x, a0.y, a0.z, a1.x, a1.y, a1.z, 0.5f, 0.05f, CORONA, 0.3f * k, 0f);
            }
            float ring = Mth.clamp((t - windup) / 20f, 0f, 1f) * Mth.clamp((windup + 60 - t) / 30f, 0f, 1f);
            if (ring > 0.01f) {   // "cincin berlian": kilau di satu titik tepi saat gerhana baru menutup
                Vec3 g = c.add(side.scale(10.6));
                d.glint(g.x, g.y, g.z, 9f, t * 0.01f, 0xFFFFFF, 0.9f * ring * k);
                d.glow(g.x, g.y, g.z, 4f, CORONA, 0.7f * ring * k);
            }
        }
    }
}
