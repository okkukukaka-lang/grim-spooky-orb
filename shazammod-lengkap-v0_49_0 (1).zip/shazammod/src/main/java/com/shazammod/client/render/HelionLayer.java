package com.shazammod.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamMod;
import com.shazammod.client.fx.HelionFx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;

/**
 * 0.43 Projek Helion-6: kostum tempur (tekstur 256 px di tata letak UV kulit, dibuat tools/textures/helion_textures.py) yang
 * digambar di lapisan luar kulit (jaket, lengan baju, celana) supaya menutup kulit asli; jalur radiasi hijau yang menyala
 * (RenderType.eyes, terangnya dari HelionFx.veinGlow: redup & berkedip di bawah matahari, membara saat Lonjakan / skill);
 * urat Cryon di wajah; kulit pucat terbakar saat di bawah matahari; dan urat radiasi yang menjalar di tubuh manusia selama
 * Eksperimen Proyek Helion-6. Kepala tetap kulit asli pemain. Lambang reaktor di dada digambar ShazamEmblemLayer.
 * 0.49: kristal Cryon 3D tumbuh menembus kostumnya (gugus kristal di bahu, bilah di lengan bawah, simpul di tulang
 * punggung, kristal lutut; lihat HeroGeo), terangnya mengikuti jalur radiasi. Bilah lengannya ikut di tangan orang pertama.
 */
public class HelionLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation SUIT = ShazamMod.id("textures/entity/helion/suit.png");
    private static final ResourceLocation GLOW = ShazamMod.id("textures/entity/helion/suit_glow.png");
    private static final ResourceLocation VEINS = ShazamMod.id("textures/entity/lintang/cryon_veins.png");
    private static final ResourceLocation PALE = ShazamMod.id("textures/entity/lintang/cryon_pale.png");
    private static final int FULLBRIGHT = 15728880;
    private static final int CRYON = 0x3CFF86;
    /** Lengan kostum di sudut pandang orang pertama dibuat sedikit lebih besar dari lengan kulit, jadi menutupinya. */
    private static final float ARM_INFLATE = 1.07f;

    public HelionLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    public static boolean active(AbstractClientPlayer player) {
        return !player.isInvisible() && ShazamClientState.isTransformed(player.getId()) && ShazamClientState.isHelion(player.getId());
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buffers, int light, AbstractClientPlayer p, float limbSwing,
                       float limbAmount, float pt, float ageInTicks, float netHeadYaw, float headPitch) {
        try {
            if (p.isInvisible() || !ShazamClientState.isHelion(p.getId())) {
                return;
            }
            PlayerModel<AbstractClientPlayer> m = getParentModel();
            if (!ShazamClientState.isTransformed(p.getId())) {
                float rite = HelionFx.riteVeins(p, pt);   // eksperimen di tubuh manusia: urat radiasi menjalar
                if (rite > 0.02f) {
                    VertexConsumer veins = buffers.getBuffer(RenderType.eyes(VEINS));
                    int c = color(CRYON, rite);
                    one(m.hat, m.head, ps, veins, FULLBRIGHT, c);
                    for (ModelPart[] pair : body(m)) {
                        one(pair[0], pair[1], ps, veins, FULLBRIGHT, c);
                    }
                }
                return;
            }
            // 1) kostum tempur (ikut memerah saat terluka)
            int overlay = LivingEntityRenderer.getOverlayCoords(p, 0f);
            VertexConsumer suit = buffers.getBuffer(RenderType.entityCutoutNoCull(SUIT));
            for (ModelPart[] pair : body(m)) {
                shell(pair[0], pair[1], ps, suit, light, overlay, 0xFFFFFFFF, 1f);
            }
            // 2) jalur radiasi yang menyala (saat kostum baru terbentuk: menyala penuh lalu turun)
            float glow = HelionFx.veinGlow(p, pt);
            float reveal = ShazamCape.revealTime(p, pt);
            if (reveal >= 0f && reveal < 12f) {
                glow = Math.max(glow, 1.3f * (1f - reveal / 12f));
            }
            if (glow > 0.02f) {
                VertexConsumer lines = buffers.getBuffer(RenderType.eyes(GLOW));
                int c = color(0xFFFFFF, glow);
                for (ModelPart[] pair : body(m)) {
                    shell(pair[0], pair[1], ps, lines, FULLBRIGHT, OverlayTexture.NO_OVERLAY, c, 1f);
                }
            }
            // 2b) 0.49 kristal Cryon 3D: bahu, lengan bawah, tulang punggung, lutut
            HeroGeo.helion(m.body, m.rightArm, m.leftArm, m.rightLeg, m.leftLeg, ps, buffers, light, overlay, glow, ageInTicks);
            // 3) wajah: pucat terbakar matahari, lalu urat Cryon yang berpendar
            float pale = HelionFx.sunPale(p, pt);
            if (pale > 0.02f) {
                VertexConsumer skin = buffers.getBuffer(RenderType.entityTranslucent(PALE));
                one(m.hat, m.head, ps, skin, light, ((int) (Mth.clamp(pale, 0f, 1f) * 0.6f * 255f) << 24) | 0xFFFFFF);
            }
            float face = HelionFx.faceVeins(p, pt);
            if (face > 0.02f) {
                VertexConsumer veins = buffers.getBuffer(RenderType.eyes(VEINS));
                one(m.hat, m.head, ps, veins, FULLBRIGHT, color(CRYON, face));
            }
        } catch (Throwable ignored) {
            // lapisan kostum nggak boleh bikin game crash
        }
    }

    /**
     * Tangan orang pertama (RenderArmEvent, sebelum lengan kulit digambar): lengan & sarung tangan kostum dengan jalur
     * radiasinya, sedikit lebih besar dari lengan kulit supaya menutupinya.
     */
    public static void firstPersonArm(PoseStack ps, MultiBufferSource buffers, int light, AbstractClientPlayer p, HumanoidArm arm) {
        try {
            if (!active(p)) {
                return;
            }
            Minecraft mc = Minecraft.getInstance();
            if (!(mc.getEntityRenderDispatcher().getRenderer(p) instanceof PlayerRenderer renderer)) {
                return;
            }
            PlayerModel<AbstractClientPlayer> m = renderer.getModel();
            boolean right = arm == HumanoidArm.RIGHT;
            ModelPart base = right ? m.rightArm : m.leftArm;
            ModelPart sleeve = right ? m.rightSleeve : m.leftSleeve;
            m.attackTime = 0f;
            m.crouching = false;
            m.swimAmount = 0f;
            m.setupAnim(p, 0f, 0f, 0f, 0f, 0f);
            base.xRot = 0f;
            sleeve.xRot = 0f;
            shell(sleeve, base, ps, buffers.getBuffer(RenderType.entityCutoutNoCull(SUIT)), light, OverlayTexture.NO_OVERLAY,
                    0xFFFFFFFF, ARM_INFLATE);
            float glow = HelionFx.veinGlow(p, mc.getTimer().getGameTimeDeltaPartialTick(false));
            shell(sleeve, base, ps, buffers.getBuffer(RenderType.eyes(GLOW)), FULLBRIGHT, OverlayTexture.NO_OVERLAY,
                    color(0xFFFFFF, glow), ARM_INFLATE);
            HeroGeo.helionArm(base, !right, ps, buffers, light, glow);   // 0.49 bilah kristal lengan bawah
        } catch (Throwable ignored) {
            // tangan orang pertama nggak boleh bikin game crash
        }
    }

    /** Badan, lengan, kaki: {lapisan luar, bagian dasar}. */
    private static ModelPart[][] body(PlayerModel<AbstractClientPlayer> m) {
        return new ModelPart[][] {{m.jacket, m.body}, {m.rightSleeve, m.rightArm}, {m.leftSleeve, m.leftArm},
                {m.rightPants, m.rightLeg}, {m.leftPants, m.leftLeg}};
    }

    /** Gambar kostum di lapisan luar (dipaksa terlihat walau lapisan luar kulit pemain dimatikan), kalau bagian dasarnya terlihat. */
    private static void shell(ModelPart outer, ModelPart base, PoseStack ps, VertexConsumer vc, int light, int overlay, int color,
                              float scale) {
        if (outer == null || base == null || !base.visible) {
            return;
        }
        boolean visible = outer.visible;
        outer.visible = true;
        if (scale != 1f) {
            outer.xScale = scale;
            outer.yScale = scale;
            outer.zScale = scale;
        }
        outer.render(ps, vc, light, overlay, color);
        if (scale != 1f) {
            outer.xScale = 1f;
            outer.yScale = 1f;
            outer.zScale = 1f;
        }
        outer.visible = visible;
    }

    /** Lapisan luar kalau terlihat, kalau nggak bagian dasarnya (seperti CryonSkinLayer). */
    private static void one(ModelPart outer, ModelPart base, PoseStack ps, VertexConsumer vc, int light, int color) {
        if (base == null || !base.visible) {
            return;
        }
        ModelPart part = outer != null && outer.visible ? outer : base;
        part.render(ps, vc, light, OverlayTexture.NO_OVERLAY, color);
    }

    /** Warna cahaya aditif: kekuatan dikalikan ke RGB (jenis render "eyes" mengabaikan alpha). */
    private static int color(int rgb, float k) {
        k = Mth.clamp(k, 0f, 1f);
        int r = (int) (((rgb >> 16) & 255) * k);
        int g = (int) (((rgb >> 8) & 255) * k);
        int b = (int) ((rgb & 255) * k);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }
}
