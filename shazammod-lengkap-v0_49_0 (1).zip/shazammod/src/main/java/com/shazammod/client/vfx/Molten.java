package com.shazammod.client.vfx;

import java.util.function.Consumer;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

/**
 * 0.42 Efek "benda nyata" untuk sinar mata & matahari mini Lintang: api 3D, lahar 3D (genangan, lelehan di dinding,
 * gumpalan yang terlempar), titik kena putih panas, matahari mini, pusaran api, cincin kejut yang membeku, dan jejak
 * cahaya. Semua bentuknya geometri sungguhan lewat Draw: lapisan soft = badan padat yang diberi cahaya palsu supaya
 * terlihat bervolume, lapisan cahaya = pijarnya. Kelas ini nggak membaca dunia Minecraft sama sekali (lantai, posisi
 * makhluk, dll. diberikan pemanggilnya), jadi bisa dipratinjau di luar game.
 */
public final class Molten {
    private Molten() {}

    // ======= Warna =======
    public static final int FIRE_WHITE = 0xFFF6D8;
    public static final int FIRE_YELLOW = 0xFFC650;
    public static final int FIRE_ORANGE = 0xFF6E1E;
    public static final int FIRE_RED = 0xC02A0C;
    public static final int FIRE_DARK = 0x5A1206;
    public static final int LAVA_HOT = 0xFFE27A;
    public static final int LAVA_MID = 0xFF7A1C;
    public static final int LAVA_DEEP = 0xC2300C;
    public static final int CRUST = 0x2B1710;
    public static final int SUN_WHITE = 0xFFF4C8;
    public static final int SUN_GOLD = 0xFFB238;
    public static final int SUN_DEEP = 0xFF6A18;

    // cahaya palsu: matahari dari atas-depan (buat badan padat lahar & matahari mini)
    private static final double LX = 0.36, LY = 0.86, LZ = 0.36;

    static int shade(int rgb, double nx, double ny, double nz, double ambient) {
        double l = nx * LX + ny * LY + nz * LZ;
        return Draw.scale(rgb, (float) (ambient + (1.0 - ambient) * Math.max(0.0, l)));
    }

    /** Angka 0..1 yang selalu sama untuk (seed, i): bentuk acak yang nggak berkedip tiap frame. */
    public static float hash(long seed, int i) {
        long h = seed * 0x9E3779B97F4A7C15L + i * 0xC2B2AE3D27D4EB4FL;
        h ^= h >>> 31;
        h *= 0xBF58476D1CE4E5B9L;
        h ^= h >>> 29;
        return ((h >>> 11) & 0xFFFFFF) / (float) 0x1000000;
    }

    /** Warna api menurut ketinggian lidah api u (0 = dasar putih panas, 1 = ujung merah gelap). */
    static int fireColor(double u) {
        if (u < 0.22) {
            return Draw.mix(FIRE_WHITE, FIRE_YELLOW, u / 0.22);
        }
        if (u < 0.5) {
            return Draw.mix(FIRE_YELLOW, FIRE_ORANGE, (u - 0.22) / 0.28);
        }
        if (u < 0.8) {
            return Draw.mix(FIRE_ORANGE, FIRE_RED, (u - 0.5) / 0.3);
        }
        return Draw.mix(FIRE_RED, FIRE_DARK, Math.min(1.0, (u - 0.8) / 0.2));
    }

    /** Warna lahar menurut panasnya (0 = merah tua redup, 1 = kuning putih). */
    static int lavaColor(double k) {
        k = Mth.clamp(k, 0.0, 1.0);
        if (k < 0.55) {
            return Draw.mix(LAVA_DEEP, LAVA_MID, k / 0.55);
        }
        return Draw.mix(LAVA_MID, LAVA_HOT, (k - 0.55) / 0.45);
    }

    private static double smooth(double k) {
        k = Mth.clamp(k, 0.0, 1.0);
        return k * k * (3.0 - 2.0 * k);
    }

    // ------------------------------------------------------------------ bola

    /**
     * Bola padat kecil (lat x lon ruas). lit/dark = warna sisi atas/bawah; shaded = diberi cahaya palsu (badan padat) atau
     * cuma gradasi atas-bawah (benda pijar).
     */
    static void ball(Draw d, double x, double y, double z, double r, int lit, int dark, float a, int lat, int lon,
                     boolean shaded) {
        if (a <= 0.003f || r <= 0.0) {
            return;
        }
        for (int i = 0; i < lat; i++) {
            double t0 = Math.PI * i / lat, t1 = Math.PI * (i + 1) / lat;
            double y0 = Math.cos(t0), y1 = Math.cos(t1), s0 = Math.sin(t0), s1 = Math.sin(t1);
            for (int j = 0; j < lon; j++) {
                double p0 = Math.PI * 2.0 * j / lon, p1 = Math.PI * 2.0 * (j + 1) / lon;
                double c0 = Math.cos(p0), n0 = Math.sin(p0), c1 = Math.cos(p1), n1 = Math.sin(p1);
                double ax = s0 * c0, az = s0 * n0, bx = s0 * c1, bz = s0 * n1;
                double cx = s1 * c1, cz = s1 * n1, ex = s1 * c0, ez = s1 * n0;
                int ca = tone(lit, dark, ax, y0, az, shaded), cb = tone(lit, dark, bx, y0, bz, shaded);
                int cc = tone(lit, dark, cx, y1, cz, shaded), ce = tone(lit, dark, ex, y1, ez, shaded);
                d.quad4(x + ax * r, y + y0 * r, z + az * r, x + bx * r, y + y0 * r, z + bz * r,
                        x + cx * r, y + y1 * r, z + cz * r, x + ex * r, y + y1 * r, z + ez * r, ca, cb, cc, ce, a, a, a, a);
            }
        }
    }

    private static int tone(int lit, int dark, double nx, double ny, double nz, boolean shaded) {
        int c = Draw.mix(dark, lit, 0.5 + 0.5 * ny);
        return shaded ? shade(c, nx, ny, nz, 0.5) : c;
    }

    // ------------------------------------------------------------------ api 3D

    /**
     * Api 3D: beberapa lidah api berbentuk tabung meruncing yang berkelok, memanjang-memendek, dan berkedip. Dari arah mana
     * pun tetap bervolume: dinding tabung yang menghadap kamera paling terang, tepi siluetnya menipis lembut, dan bagian
     * tengah tempat dua dinding bertumpuk jadi inti yang menyala. Tiap lidah punya inti putih-kuning yang lebih kecil.
     * Api naik ke atas dari permukaan apa pun (dasarnya sedikit keluar dari permukaan yang terbakar). body = api yang
     * membungkus makhluk: dasar lidahnya tersebar di seluruh badan.
     */
    public static final class Fire3D extends Effect {
        private static final int RINGS = 6, SEGS = 6, FADE = 14;
        private final Lightning.Anchor base;
        private final double nx, ny, nz;
        private final double radius, height;
        private final int n;
        private final float[] ox, oy, oz, hh, ww, ph;
        private float strength;
        private int keep;
        private final double[] rx = new double[(RINGS + 1) * (SEGS + 1)];
        private final double[] ry = new double[rx.length], rz = new double[rx.length];
        private final float[] ra = new float[rx.length];
        private final int[] rc = new int[RINGS + 1];

        public Fire3D(Lightning.Anchor base, Vec3 normal, double radius, double height, int keep, float strength, boolean body) {
            super(1000000);
            this.base = base;
            this.nx = normal.x;
            this.ny = normal.y;
            this.nz = normal.z;
            this.radius = radius;
            this.height = height;
            this.keep = keep;
            this.strength = strength;
            RandomSource r = Vfx.random();
            n = body ? 7 : Mth.clamp((int) Math.round(3 + radius * 7), 3, 8);
            ox = new float[n];
            oy = new float[n];
            oz = new float[n];
            hh = new float[n];
            ww = new float[n];
            ph = new float[n];
            double[] e = new double[6];
            Draw.plane(nx, ny, nz, e);
            for (int i = 0; i < n; i++) {
                double a = r.nextDouble() * Math.PI * 2.0, rr = radius * Math.sqrt(r.nextDouble()) * 0.85;
                if (body) {
                    ox[i] = (float) (Math.cos(a) * rr);
                    oz[i] = (float) (Math.sin(a) * rr);
                    oy[i] = (float) (r.nextDouble() * height * 0.5);
                } else {
                    ox[i] = (float) ((e[0] * Math.cos(a) + e[3] * Math.sin(a)) * rr);
                    oy[i] = (float) ((e[1] * Math.cos(a) + e[4] * Math.sin(a)) * rr);
                    oz[i] = (float) ((e[2] * Math.cos(a) + e[5] * Math.sin(a)) * rr);
                }
                hh[i] = (float) (height * (0.55 + 0.45 * r.nextDouble()));
                ww[i] = (float) (radius * (0.32 + 0.3 * r.nextDouble()) + 0.05);
                ph[i] = (float) (r.nextDouble() * Math.PI * 2.0);
            }
        }

        /** Disorot lagi / masih terbakar: nyala diperpanjang (ticks) dan dibesarkan sampai strength. */
        public void refresh(int ticks, float strength) {
            keep = Math.max(keep, ticks);
            this.strength = Math.max(this.strength, strength);
        }

        /** Padamkan pelan (misalnya makhluknya masuk air). */
        public void douse() {
            keep = Math.min(keep, 0);
        }

        public boolean burning() {
            return keep > -FADE;
        }

        public Vec3 at(float pt) {
            return base.at(pt);
        }

        private float level(float pt) {
            float k = keep - pt;
            float f = k >= 0f ? 1f : Mth.clamp(1f + k / FADE, 0f, 1f);
            return f * Mth.clamp((age + pt) / 3f, 0f, 1f) * strength;
        }

        @Override
        public boolean tick(ClientLevel level) {
            age++;
            keep--;
            if (keep < -FADE) {
                return false;
            }
            float a = level(0f);
            if (a < 0.05f) {
                return true;
            }
            RandomSource r = Vfx.random();
            Vec3 b = base.at(1f);
            if (r.nextFloat() < 0.35f * a) {   // bara yang naik terbawa panas
                double q = radius * (r.nextDouble() - 0.5) * 1.6, w = radius * (r.nextDouble() - 0.5) * 1.6;
                Vfx.ember(b.x + q, b.y + height * 0.6 * r.nextDouble(), b.z + w, (r.nextDouble() - 0.5) * 0.03,
                        0.04 + r.nextDouble() * 0.04, (r.nextDouble() - 0.5) * 0.03, 0.035f + r.nextFloat() * 0.03f,
                        14 + r.nextInt(10));
            }
            if (age % 3 == 0 && r.nextFloat() < 0.8f * a) {   // asap gelap di atas ujung api
                Vfx.smoke(b.x + (r.nextDouble() - 0.5) * radius, b.y + height * (0.9 + 0.3 * r.nextDouble()),
                        b.z + (r.nextDouble() - 0.5) * radius, (r.nextDouble() - 0.5) * 0.02, 0.045, (r.nextDouble() - 0.5) * 0.02,
                        0x2A2420, (float) (0.22 + radius * 0.5) * (0.8f + r.nextFloat() * 0.5f), 26 + r.nextInt(14));
            }
            return true;
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float a = level(pt);
            if (a <= 0.01f) {
                return;
            }
            Vec3 b = base.at(pt);
            float t = age + pt;
            double bx = b.x + nx * 0.03, by = b.y + ny * 0.03, bz = b.z + nz * 0.03;
            float old = d.body(0.2f);   // api punya badan tipis (tetap kelihatan di siang hari), tapi nggak seperti kertas
            for (int i = 0; i < n; i++) {
                tongue(d, bx + ox[i], by + oy[i], bz + oz[i], hh[i], ww[i], ph[i], t, a, false);
            }
            for (int i = 0; i < Math.min(3, n); i++) {   // inti putih-kuning
                tongue(d, bx + ox[i], by + oy[i], bz + oz[i], hh[i] * 0.6, ww[i] * 0.45, ph[i] + 1.3f, t, a, true);
            }
            d.body(old);
            float flick = 0.8f + 0.2f * Mth.sin(t * 1.3f) + 0.1f * Mth.sin(t * 3.7f);
            d.glow(bx, by + height * 0.25, bz, (float) (radius * 2.2 + 0.3), FIRE_ORANGE, a * 0.32f * flick);
        }

        private void tongue(Draw d, double x0, double y0, double z0, double h, double w, float ph, float t, float a,
                            boolean core) {
            double hEff = h * (0.78 + 0.16 * Math.sin(t * 0.61 + ph) + 0.08 * Math.sin(t * 1.73 + ph * 2.0));
            for (int j = 0; j <= RINGS; j++) {
                double u = j / (double) RINGS;
                double sway = h * 0.18 * u * u;
                double cx = x0 + sway * Math.sin(t * 0.33 + ph + u * 2.8);
                double cz = z0 + sway * Math.cos(t * 0.29 + ph * 1.3 + u * 2.3);
                double cy = y0 + hEff * u;
                double r = j == RINGS ? 0.0 : w * Math.pow(1.0 - u, 0.75) * (0.84 + 0.16 * Math.sin(t * 0.95 + ph + u * 7.0));
                rc[j] = fireColor(Mth.clamp(u * 0.92 + (core ? -0.15 : 0.07), 0.0, 1.0));
                float au = (float) (a * Math.pow(1.0 - u, 1.25)) * (core ? 0.85f : 0.55f);
                double vx = d.camX - cx, vz = d.camZ - cz;
                double vl = Math.sqrt(vx * vx + vz * vz);
                if (vl < 1.0E-6) {
                    vx = 1.0;
                    vz = 0.0;
                } else {
                    vx /= vl;
                    vz /= vl;
                }
                for (int k = 0; k <= SEGS; k++) {
                    double ang = Math.PI * 2.0 * k / SEGS + ph;
                    double cs = Math.cos(ang), sn = Math.sin(ang);
                    int o = j * (SEGS + 1) + k;
                    rx[o] = cx + cs * r;
                    ry[o] = cy;
                    rz[o] = cz + sn * r;
                    double facing = Math.abs(cs * vx + sn * vz);   // 1 = menghadap kamera, 0 = tepi siluet
                    ra[o] = au * (float) (0.2 + 0.8 * facing);
                }
            }
            for (int j = 0; j < RINGS; j++) {
                for (int k = 0; k < SEGS; k++) {
                    int p = j * (SEGS + 1) + k, q = p + 1, s = p + SEGS + 1, u = s + 1;
                    d.quad2(rx[p], ry[p], rz[p], rx[q], ry[q], rz[q], rx[u], ry[u], rz[u], rx[s], ry[s], rz[s],
                            rc[j], rc[j + 1], ra[p], ra[q], ra[u], ra[s]);
                }
            }
        }
    }

    // ------------------------------------------------------------------ titik kena sinar (rujukan film)

    /**
     * Titik kena sinar panas: inti putih panas berduri tajam yang bentuknya berganti tiap 2 tick (seperti cipratan cahaya
     * di film), duri-duri merah muda di bawahnya, pendar merah luas yang membasahi permukaan, dan pendar jingga-putih di
     * tengah. size = jari-jari inti (blok), normal = arah keluar permukaan (atau arah balik sinar kalau kena makhluk).
     */
    public static void heatStar(Draw d, Vec3 at, Vec3 normal, float size, float a, float t, long seed) {
        if (a <= 0.01f) {
            return;
        }
        double[] e = new double[6];
        Draw.plane(normal.x, normal.y, normal.z, e);
        long s = seed + (long) (t / 2f) * 7919L;
        double px = at.x + normal.x * 0.03, py = at.y + normal.y * 0.03, pz = at.z + normal.z * 0.03;
        float old = d.body(0.25f);
        d.disc(px, py, pz, normal.x, normal.y, normal.z, size * 4.4, 0xFF2410, a * 0.5f, 0f, null);
        d.disc(px, py, pz, normal.x, normal.y, normal.z, size * 2.3, 0xFF5A30, a * 0.45f, 0f, null);
        d.body(old);
        int spikes = 18;
        for (int i = 0; i < spikes; i++) {
            float h1 = hash(s, i), h2 = hash(s, i + 101), h3 = hash(s, i + 211);
            double ang = (i + h1 * 0.8) / spikes * Math.PI * 2.0;
            double out = i % 3 == 0 ? 0.35 + h3 * 0.6 : 0.05 + h3 * 0.15;   // sebagian mencuat dari permukaan
            double dx = e[0] * Math.cos(ang) + e[3] * Math.sin(ang) + normal.x * out;
            double dy = e[1] * Math.cos(ang) + e[4] * Math.sin(ang) + normal.y * out;
            double dz = e[2] * Math.cos(ang) + e[5] * Math.sin(ang) + normal.z * out;
            double l = Math.sqrt(dx * dx + dy * dy + dz * dz);
            dx /= l;
            dy /= l;
            dz /= l;
            double len = size * (0.9 + h2 * 1.9);
            float w = size * (0.24f + 0.2f * h1);
            d.line(px, py, pz, px + dx * len * 1.3, py + dy * len * 1.3, pz + dz * len * 1.3, w * 2.3f, 0f, 0xFF6E52, a * 0.45f, 0f);
            d.line(px, py, pz, px + dx * len, py + dy * len, pz + dz * len, w, 0f, 0xFFF2DA, a, 0f);
        }
        d.glow(px, py, pz, size * 1.2f, 0xFFF8EC, a);
        d.glow(px, py, pz, size * 2.3f, 0xFFC890, a * 0.65f);
        d.glow(px, py, pz, size * 4.2f, 0xFF4A20, a * 0.4f);
    }

    // ------------------------------------------------------------------ lahar

    /** Lantai di bawah satu titik (y), atau NaN kalau nggak ada lantai dekat (jurang). Diisi pemanggil dari dunia. */
    public interface Floor {
        double below(double x, double y, double z);
    }

    /**
     * Genangan lahar 3D: kubah pipih bertepi membulat dengan garis tepi tak beraturan, berpijar kuning-jingga dengan arus
     * yang mengalir pelan. Saat mendingin, kerak gelap tumbuh dari tepi dan menutup permukaan (retakan pijarnya menipis),
     * gelembung muncul lalu pecah selama masih panas, dan asap tipis mengepul. feed() = lahar baru masuk (melebar, panas lagi).
     */
    public static final class LavaPool extends Effect {
        private static final int RINGS = 8, SEGS = 28;
        public final Vec3 c;
        private double radius, target;
        private final double maxRadius;
        private float heat = 1f;
        private int hold;
        private int frozen = -1;
        private final float s1, s2, s3;
        private final float[] bubble = new float[4 * 5];   // {sudut, jarak (0-1), lahir, umur, ukuran}
        private final double[] gx = new double[(RINGS + 1) * (SEGS + 1)];
        private final double[] gy = new double[gx.length], gz = new double[gx.length];
        private final int[] gc = new int[gx.length];
        private final float[] gk = new float[gx.length];
        private final float[] gr = new float[gx.length];   // retakan pijar di antara lempeng kerak

        public LavaPool(Vec3 c, double radius, double maxRadius, int hold) {
            super(1000000);
            this.c = c;
            this.radius = radius * 0.3;
            this.target = radius;
            this.maxRadius = maxRadius;
            this.hold = hold;
            RandomSource r = Vfx.random();
            s1 = r.nextFloat() * 6.28f;
            s2 = r.nextFloat() * 6.28f;
            s3 = r.nextFloat() * 6.28f;
        }

        public void feed(double amount, int holdTicks) {
            target = Math.min(maxRadius, Math.max(target, radius) + amount);
            heat = Math.min(1f, heat + 0.4f);
            hold = Math.max(hold, holdTicks);
            frozen = -1;
        }

        public boolean near(Vec3 p, double extra) {
            double dx = p.x - c.x, dz = p.z - c.z;
            return Math.abs(p.y - c.y) < 0.45 && dx * dx + dz * dz < (radius + extra) * (radius + extra);
        }

        public double radius() {
            return radius;
        }

        public float heat() {
            return heat;
        }

        /** Sudah membeku dan memudar habis. */
        public boolean gone() {
            return frozen >= 0 && age - frozen >= 120;
        }

        @Override
        public boolean tick(ClientLevel level) {
            age++;
            radius += (target - radius) * 0.15;
            if (hold > 0) {
                hold--;
            } else {
                heat = Math.max(0f, heat - 0.0055f);   // ±9 detik dari cair penuh sampai membeku
            }
            if (heat <= 0f) {
                if (frozen < 0) {
                    frozen = age;
                }
                return age - frozen < 120;   // kerak beku memudar pelan
            }
            RandomSource r = Vfx.random();
            if (heat > 0.3f && r.nextFloat() < 0.1f * heat * (float) (radius / 0.6)) {   // gelembung baru
                for (int i = 0; i < 4; i++) {
                    int o = i * 5;
                    if (age > bubble[o + 2] + bubble[o + 3]) {
                        bubble[o] = r.nextFloat() * 6.28f;
                        bubble[o + 1] = 0.15f + r.nextFloat() * 0.6f;
                        bubble[o + 2] = age;
                        bubble[o + 3] = 10 + r.nextInt(14);
                        bubble[o + 4] = (float) (radius * (0.1 + 0.12 * r.nextDouble()));
                        break;
                    }
                }
            }
            for (int i = 0; i < 4; i++) {   // gelembung yang pecah: cipratan kecil
                int o = i * 5;
                if (bubble[o + 3] > 0 && age == (int) (bubble[o + 2] + bubble[o + 3])) {
                    Vec3 p = surface(bubble[o], bubble[o + 1]);
                    for (int k = 0; k < 4; k++) {
                        Vfx.spark(p.x, p.y + 0.02, p.z, (r.nextDouble() - 0.5) * 0.1, 0.08 + r.nextDouble() * 0.08,
                                (r.nextDouble() - 0.5) * 0.1, k % 2 == 0 ? LAVA_HOT : LAVA_MID, 0.04f, 10 + r.nextInt(6), c.y);
                    }
                }
            }
            if (age % 4 == 0 && r.nextFloat() < 0.6f) {   // asap tipis
                double a = r.nextDouble() * 6.28, rr = radius * r.nextDouble() * 0.8;
                Vfx.smoke(c.x + Math.cos(a) * rr, c.y + 0.1, c.z + Math.sin(a) * rr, 0, 0.03, 0,
                        heat > 0.5f ? 0x3A302A : 0x5A5650, (float) (0.18 + radius * 0.3), 30 + r.nextInt(12));
            }
            return true;
        }

        private double outline(double ang) {
            return 1.0 + 0.16 * Math.sin(3.0 * ang + s1) + 0.09 * Math.sin(5.0 * ang + s2) + 0.05 * Math.sin(9.0 * ang + s3);
        }

        private double height() {
            return 0.02 + 0.035 * Math.min(1.0, radius / 0.9);
        }

        private Vec3 surface(double ang, double rho) {
            double rr = radius * outline(ang) * rho;
            return new Vec3(c.x + Math.cos(ang) * rr, c.y + 0.012 + height() * (1.0 - Math.pow(rho, 4.0)), c.z + Math.sin(ang) * rr);
        }

        /** Pola lempeng kerak di permukaan (koordinat datar relatif pusat, blok): 0..1. */
        private double plates(double dx, double dz) {
            return 0.5 + 0.22 * Math.sin(dx * 9.1 + s1 + Math.sin(dz * 4.0)) + 0.22 * Math.sin(dz * 8.3 + s2 + Math.sin(dx * 3.7))
                    + 0.12 * Math.sin((dx - dz) * 14.0 + s3);
        }

        private double threshold(double rho) {
            return 0.92 - (1.0 - heat) * 1.25 - rho * 0.28;
        }

        private float crust(double ang, double rho) {
            double rr = radius * outline(ang) * rho;
            return (float) smooth((plates(Math.cos(ang) * rr, Math.sin(ang) * rr) - threshold(rho)) / 0.08);
        }

        private float fade(float pt) {
            float in = Mth.clamp((age + pt) / 4f, 0f, 1f);
            return frozen < 0 ? in : in * Mth.clamp(1f - (age + pt - frozen) / 120f, 0f, 1f);
        }

        /** Isi grid permukaan: posisi, warna badan (kerak diberi cahaya palsu, lahar pijar tanpa bayangan), kerak 0-1. */
        private void build(float t) {
            double h = height();
            for (int j = 0; j <= RINGS; j++) {
                double rho = j / (double) RINGS;
                for (int k = 0; k <= SEGS; k++) {
                    double ang = Math.PI * 2.0 * k / SEGS;
                    double out = outline(ang);
                    double rr = radius * out * rho;
                    int o = j * (SEGS + 1) + k;
                    gx[o] = c.x + Math.cos(ang) * rr;
                    gz[o] = c.z + Math.sin(ang) * rr;
                    gy[o] = c.y + 0.012 + h * (1.0 - Math.pow(rho, 4.0));
                    double slope = 4.0 * h * Math.pow(rho, 3.0) / Math.max(0.05, radius * out);
                    double nl = Math.sqrt(1.0 + slope * slope);
                    double dx = Math.cos(ang) * rr, dz = Math.sin(ang) * rr;
                    double n = plates(dx, dz), th = threshold(rho);
                    float cr = (float) smooth((n - th) / 0.08);
                    float crack = (float) ((1.0 - smooth(Math.abs(n - th) / 0.05)) * Math.min(1.0, heat * 1.6));
                    double flow = 0.5 + 0.5 * Math.sin(dx * 6.0 + dz * 4.0 - t * 0.06 + s3);
                    int hot = Draw.mix(lavaColor(heat * (0.55 - 0.25 * rho) + 0.05), LAVA_HOT, 0.3 * flow * flow * heat);
                    int crustCol = shade(Draw.mix(CRUST, 0x553024, 0.25 * (1.0 - rho)), -slope * Math.cos(ang) / nl, 1.0 / nl,
                            -slope * Math.sin(ang) / nl, 0.55);
                    gc[o] = Draw.mix(Draw.mix(hot, crustCol, cr), LAVA_MID, crack * 0.85);
                    gk[o] = cr;
                    gr[o] = crack;
                }
            }
        }

        @Override
        public void renderSoft(Draw d) {
            float pt = d.partialTick;
            float f = fade(pt);
            if (f <= 0.01f || radius < 0.03) {
                return;
            }
            build(age + pt);
            float a = 0.97f * f;
            for (int j = 0; j < RINGS; j++) {
                for (int k = 0; k < SEGS; k++) {
                    int p = j * (SEGS + 1) + k, q = p + 1, s = p + SEGS + 1, u = s + 1;
                    d.quad4(gx[p], gy[p], gz[p], gx[q], gy[q], gz[q], gx[u], gy[u], gz[u], gx[s], gy[s], gz[s],
                            gc[p], gc[q], gc[u], gc[s], a, a, a, a);
                }
            }
            float t = age + pt;
            for (int i = 0; i < 4; i++) {   // gelembung: kubah kecil yang membengkak
                int o = i * 5;
                float life = bubble[o + 3], k = (t - bubble[o + 2]) / Math.max(1f, life);
                if (life <= 0f || k < 0f || k >= 1f) {
                    continue;
                }
                Vec3 p = surface(bubble[o], bubble[o + 1]);
                double r = bubble[o + 4] * Math.sin(k * Math.PI * 0.5);
                ball(d, p.x, p.y, p.z, r, lavaColor(heat), LAVA_DEEP, a, 3, 8, false);
            }
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float f = fade(pt);
            if (f <= 0.01f || heat <= 0.01f || radius < 0.03) {
                return;
            }
            build(age + pt);   // grid yang sama (dihitung ulang: lapisan soft & cahaya digambar terpisah)
            float old = d.body(0f);
            for (int j = 0; j < RINGS; j++) {
                for (int k = 0; k < SEGS; k++) {
                    int p = j * (SEGS + 1) + k, q = p + 1, s = p + SEGS + 1, u = s + 1;
                    float ap = ((1f - gk[p]) * 0.5f + gr[p] * 0.9f) * heat * f, aq = ((1f - gk[q]) * 0.5f + gr[q] * 0.9f) * heat * f;
                    float au = ((1f - gk[u]) * 0.5f + gr[u] * 0.9f) * heat * f, as = ((1f - gk[s]) * 0.5f + gr[s] * 0.9f) * heat * f;
                    if (ap + aq + au + as < 0.01f) {
                        continue;
                    }
                    d.quad4(gx[p], gy[p] + 0.004, gz[p], gx[q], gy[q] + 0.004, gz[q], gx[u], gy[u] + 0.004, gz[u],
                            gx[s], gy[s] + 0.004, gz[s], gc[p], gc[q], gc[u], gc[s], ap, aq, au, as);
                }
            }
            d.body(old);
            d.glow(c.x, c.y + 0.15, c.z, (float) (radius * 1.7 + 0.2), LAVA_MID, heat * 0.33f * f);
        }
    }

    /** 0.44 Lantai yang bisa dialiri lahar di titik ini (x, z) setinggi y: ada lantai rata di bawahnya & ruang kosong di atasnya. */
    public interface Surface {
        boolean ok(double x, double y, double z);
    }

    /**
     * 0.44 Genangan lahar gaya Minecraft (seperti di video), tapi hidup: petak-petak 1/4 blok yang benar-benar mengalir keluar
     * dari titik leleh mengikuti lantai (nggak menembus dinding, berhenti di tepi jurang, menjulur tak beraturan), tiap
     * petak berwarna kuning-jingga sendiri dengan arus terang yang merambat, sisi tebalnya kelihatan di tepi genangan,
     * tepinya mendingin duluan jadi kerak gelap dengan retakan pijar, gelembung meletup, asap & bara naik, dan seluruh
     * genangan berpendar ke udara di atasnya. Lama-lama membeku jadi kerak, lalu memudar. feed() = lahar baru masuk.
     */
    public static final class LavaSheet extends Effect {
        public static final double CELL = 0.25;
        private static final int N = 29, MID = N / 2;
        private static final float VISC = 0.06f;      // beda tebal minimal supaya lahar masih mau mengalir (kental)
        private final double ox, oz, y;
        private final Surface surface;
        private final long seed;
        private final float[] amt = new float[N * N], heat = new float[N * N], nAmt = new float[N * N], nHeat = new float[N * N];
        private final byte[] state = new byte[N * N];   // 0 belum dicek, 1 bisa dialiri, 2 tertutup
        private final float[] noise = new float[N * N];
        private float budget;
        private int feedAt = MID * N + MID;
        private int hold;
        private int frozen = -1;
        private int live;
        private float glowSum;
        private double cxSum, czSum;

        public LavaSheet(Vec3 at, Surface surface, float amount, int hold) {
            super(1000000);
            this.y = at.y;
            this.ox = at.x - (MID + 0.5) * CELL;
            this.oz = at.z - (MID + 0.5) * CELL;
            this.surface = surface;
            this.seed = Vfx.random().nextLong();
            for (int i = 0; i < noise.length; i++) {
                noise[i] = hash(seed, i);
            }
            state[feedAt] = 1;
            feed(at, amount, hold);
        }

        /** Lahar baru masuk di titik ini (petak terdekat), panas lagi. */
        public void feed(Vec3 at, float amount, int holdTicks) {
            int i = (int) Math.floor((at.x - ox) / CELL), j = (int) Math.floor((at.z - oz) / CELL);
            if (i >= 0 && j >= 0 && i < N && j < N) {
                int k = j * N + i;
                if (state[k] == 0) {
                    state[k] = (byte) (surface.ok(ox + (i + 0.5) * CELL, y, oz + (j + 0.5) * CELL) ? 1 : 2);
                }
                feedAt = state[k] == 1 ? k : feedAt;
            }
            budget += amount * 20f;
            hold = Math.max(hold, holdTicks);
            frozen = -1;
        }

        /** Titik ini masuk wilayah genangan ini (lantai yang sama, di dalam grid). */
        public boolean near(Vec3 p) {
            return Math.abs(p.y - y) < 0.3 && p.x > ox + CELL && p.z > oz + CELL && p.x < ox + (N - 1) * CELL && p.z < oz + (N - 1) * CELL;
        }

        public boolean gone() {
            return frozen >= 0 && age - frozen >= 100;
        }

        private boolean open(int i, int j) {
            if (i < 0 || j < 0 || i >= N || j >= N) {
                return false;
            }
            int k = j * N + i;
            if (state[k] == 0) {
                state[k] = (byte) (surface.ok(ox + (i + 0.5) * CELL, y, oz + (j + 0.5) * CELL) ? 1 : 2);
            }
            return state[k] == 1;
        }

        @Override
        public boolean tick(ClientLevel level) {
            age++;
            if (budget > 0f) {   // lahar dari titik leleh masuk pelan-pelan, panas penuh
                float in = Math.min(budget, 0.45f);
                budget -= in;
                float a0 = amt[feedAt];
                amt[feedAt] += in;
                heat[feedAt] = (heat[feedAt] * a0 + in) / Math.max(1.0E-4f, amt[feedAt]);
            }
            if (hold > 0) {
                hold--;
            }
            System.arraycopy(amt, 0, nAmt, 0, amt.length);
            System.arraycopy(heat, 0, nHeat, 0, heat.length);
            int[] di = {1, -1, 0, 0, 1, 1, -1, -1}, dj = {0, 0, 1, -1, 1, -1, 1, -1};
            for (int j = 0; j < N; j++) {
                for (int i = 0; i < N; i++) {
                    int k = j * N + i;
                    float a = amt[k];
                    if (a < 0.04f || heat[k] < 0.16f) {
                        continue;   // terlalu tipis atau sudah berkerak: diam
                    }
                    for (int d = 0; d < 8; d++) {
                        int ni = i + di[d], nj = j + dj[d];
                        if (!open(ni, nj) || (d >= 4 && (!open(ni, j) || !open(i, nj)))) {
                            continue;   // serong cuma kalau kedua sisinya juga terbuka (nggak menembus sudut dinding)
                        }
                        int nk = nj * N + ni;
                        // jalur yang lebih licin: genangan menjulur tak beraturan (serong sedikit lebih lambat, bentuknya membulat)
                        float w = (0.3f + 1.4f * hash(seed + 7, k * 8 + d)) * (d >= 4 ? 0.6f : 1f);
                        float f = (a - amt[nk] - VISC) * 0.11f * w * Math.min(1f, heat[k] * 1.6f);
                        if (f <= 0f) {
                            continue;
                        }
                        f = Math.min(f, nAmt[k] * 0.24f);
                        float before = nAmt[nk];
                        nAmt[k] -= f;
                        nAmt[nk] += f;
                        nHeat[nk] = (nHeat[nk] * before + heat[k] * f) / Math.max(1.0E-4f, nAmt[nk]);
                    }
                }
            }
            System.arraycopy(nAmt, 0, amt, 0, amt.length);
            System.arraycopy(nHeat, 0, heat, 0, heat.length);
            // mendingin: tepi tipis lebih cepat, petak sumber tetap panas selama masih disorot
            live = 0;
            glowSum = 0f;
            cxSum = 0;
            czSum = 0;
            for (int k = 0; k < amt.length; k++) {
                if (amt[k] < 0.03f) {
                    continue;
                }
                float thin = 1f - Math.min(1f, amt[k] / 0.5f);
                float rate = (hold > 0 ? 0.0012f : 0.0034f) + 0.004f * thin;
                if (hold > 0 && k == feedAt) {
                    rate = 0f;
                }
                heat[k] = Math.max(0f, heat[k] - rate);
                if (heat[k] > 0.02f) {
                    live++;
                    glowSum += heat[k];
                    cxSum += (k % N) * heat[k];
                    czSum += (k / N) * heat[k];
                }
            }
            RandomSource r = Vfx.random();
            if (live > 0) {   // gelembung meletup, asap & bara dari petak yang masih panas
                for (int n = 0; n < 2; n++) {
                    int k = r.nextInt(amt.length);
                    if (amt[k] < 0.06f || heat[k] < 0.45f) {
                        continue;
                    }
                    double x = ox + (k % N + 0.5) * CELL, z = oz + (k / N + 0.5) * CELL, top = y + thick(amt[k]);
                    if (r.nextFloat() < 0.35f) {
                        for (int q = 0; q < 4; q++) {
                            Vfx.spark(x, top + 0.02, z, (r.nextDouble() - 0.5) * 0.1, 0.07 + r.nextDouble() * 0.09,
                                    (r.nextDouble() - 0.5) * 0.1, q % 2 == 0 ? LAVA_HOT : LAVA_MID, 0.035f, 9 + r.nextInt(6), y);
                        }
                    } else if (r.nextFloat() < 0.5f) {
                        Vfx.ember(x, top + 0.05, z, (r.nextDouble() - 0.5) * 0.02, 0.03 + r.nextDouble() * 0.03,
                                (r.nextDouble() - 0.5) * 0.02, 0.03f, 16 + r.nextInt(10));
                    } else if (age % 2 == 0) {
                        Vfx.smoke(x, top + 0.1, z, 0, 0.035, 0, heat[k] > 0.6f ? 0x3A302A : 0x5A5650, 0.22f + 0.2f * heat[k],
                                28 + r.nextInt(10));
                    }
                }
                return true;
            }
            if (budget > 0f) {
                return true;
            }
            if (frozen < 0) {
                frozen = age;
            }
            return age - frozen < 100;
        }

        private static double thick(float a) {
            return 0.014 + 0.05 * Math.min(1.0, a / 0.8);
        }

        private float fade(float pt) {
            float in = Mth.clamp((age + pt) / 3f, 0f, 1f);
            return frozen < 0 ? in : in * Mth.clamp(1f - (age + pt - frozen) / 100f, 0f, 1f);
        }

        /** 0..1 kerak di petak ini (dari suhu & pola acak tetap per petak: tepi & petak "dingin" duluan). */
        private float crust(int k) {
            return (float) smooth((0.36 - heat[k] + (noise[k] - 0.5) * 0.24) / 0.1);
        }

        /** Warna permukaan petak (rata satu warna per petak: gaya piksel Minecraft), dengan arus terang yang merambat. */
        private int color(int k, float t) {
            int i = k % N, j = k / N;
            double flow = 0.5 + 0.5 * Math.sin(i * 0.9 + j * 0.7 - t * 0.12 + noise[k] * 5.0);
            double hk = heat[k] * (0.5 + 0.38 * noise[k]) + 0.12 * flow * heat[k];   // jingga dengan petak-petak kuning (video)
            int hot = lavaColor(hk);
            if (heat[k] > 0.85f && noise[k] > 0.86f) {
                hot = Draw.mix(hot, 0xFFF4C0, 0.4 * (heat[k] - 0.85f) / 0.15f);   // petak paling panas nyaris putih
            }
            int crustCol = Draw.mix(CRUST, 0x4A2A1E, noise[k] * 0.6);
            return Draw.mix(hot, crustCol, crust(k));
        }

        @Override
        public void renderSoft(Draw d) {
            float pt = d.partialTick;
            float f = fade(pt);
            if (f <= 0.01f) {
                return;
            }
            float t = age + pt, a = 0.98f * f;
            for (int k = 0; k < amt.length; k++) {
                float am = amt[k];
                if (am < 0.03f) {
                    continue;
                }
                int i = k % N, j = k / N;
                double x0 = ox + i * CELL, z0 = oz + j * CELL, x1 = x0 + CELL, z1 = z0 + CELL, top = y + thick(am);
                int c = color(k, t);
                d.quad(x0, top, z0, x0, top, z1, x1, top, z1, x1, top, z0, c, a, a, a, a);
                int side = Draw.scale(c, 0.62f);
                // sisi tebal di tepi genangan & tangga ke petak tetangga yang lebih tipis (nggak ada celah tembus)
                double bx = i + 1 < N && amt[k + 1] >= 0.03f ? y + thick(amt[k + 1]) : y + 0.002;
                double bw = i - 1 >= 0 && amt[k - 1] >= 0.03f ? y + thick(amt[k - 1]) : y + 0.002;
                double bs = j + 1 < N && amt[k + N] >= 0.03f ? y + thick(amt[k + N]) : y + 0.002;
                double bn = j - 1 >= 0 && amt[k - N] >= 0.03f ? y + thick(amt[k - N]) : y + 0.002;
                if (bx < top - 0.001) {
                    d.quad(x1, top, z0, x1, top, z1, x1, bx, z1, x1, bx, z0, side, a, a, a, a);
                }
                if (bw < top - 0.001) {
                    d.quad(x0, top, z1, x0, top, z0, x0, bw, z0, x0, bw, z1, side, a, a, a, a);
                }
                if (bs < top - 0.001) {
                    d.quad(x1, top, z1, x0, top, z1, x0, bs, z1, x1, bs, z1, side, a, a, a, a);
                }
                if (bn < top - 0.001) {
                    d.quad(x0, top, z0, x1, top, z0, x1, bn, z0, x0, bn, z0, side, a, a, a, a);
                }
            }
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float f = fade(pt);
            if (f <= 0.01f || live == 0) {
                return;
            }
            float t = age + pt;
            float old = d.body(0f);
            for (int k = 0; k < amt.length; k++) {
                float am = amt[k];
                if (am < 0.03f || heat[k] < 0.03f) {
                    continue;
                }
                float cr = crust(k);
                float g = ((1f - cr) * (0.3f + 0.4f * heat[k]) + cr * 0.1f * heat[k]) * f;
                if (g <= 0.01f) {
                    continue;
                }
                int i = k % N, j = k / N;
                double x0 = ox + i * CELL, z0 = oz + j * CELL, x1 = x0 + CELL, z1 = z0 + CELL, top = y + thick(am) + 0.003;
                int c = color(k, t);
                d.quad(x0, top, z0, x0, top, z1, x1, top, z1, x1, top, z0, c, g, g, g, g);
                if (cr > 0.2f && cr < 0.95f) {   // retakan pijar di sela kerak: garis tipis di tepi petak
                    float cg = (1f - Math.abs(cr - 0.55f) / 0.4f) * heat[k] * 0.9f * f;
                    d.flatLine(x0, top + 0.002, z0, x1, top + 0.002, z0, 0, 1, 0, 0.035f, LAVA_MID, cg, cg);
                    d.flatLine(x0, top + 0.002, z0, x0, top + 0.002, z1, 0, 1, 0, 0.035f, LAVA_MID, cg, cg);
                }
            }
            d.body(old);
            if (glowSum > 0.01f) {   // seluruh genangan berpendar ke udara di atasnya
                double cx = ox + (cxSum / glowSum + 0.5) * CELL, cz = oz + (czSum / glowSum + 0.5) * CELL;
                double rad = Math.sqrt(live) * CELL * 0.75;
                float k = Math.min(1f, glowSum / Math.max(1, live));
                d.glow(cx, y + 0.25, cz, (float) (rad * 1.5 + 0.4), LAVA_MID, 0.32f * k * f);
                d.glow(cx, y + 0.1, cz, (float) (rad * 0.8 + 0.2), LAVA_HOT, 0.25f * k * f);
            }
        }
    }

    /**
     * Lelehan lahar yang mengalir turun di dinding: kepala lelehan yang menggembung meluncur makin cepat (sampai batas
     * kekentalannya), meninggalkan jejak setengah tabung yang mendingin dari kuning ke merah lalu kerak gelap. Begitu
     * sampai lantai, onLand dipanggil sekali (biasanya jadi genangan).
     */
    public static final class LavaDrip extends Effect {
        private static final int MAX = 48;
        private final double x, z, top, floor, nx, nz, width;
        private double head, v;
        private final float[] born = new float[MAX + 1];
        private final Consumer<Vec3> onLand;
        private int landed = -1;

        public LavaDrip(Vec3 start, Vec3 out, double floorY, double width, Consumer<Vec3> onLand) {
            super(1000000);
            double l = Math.sqrt(out.x * out.x + out.z * out.z);
            this.nx = l < 1.0E-4 ? 1.0 : out.x / l;
            this.nz = l < 1.0E-4 ? 0.0 : out.z / l;
            this.x = start.x + nx * 0.02;
            this.z = start.z + nz * 0.02;
            this.top = start.y;
            this.floor = Math.min(floorY, start.y - 0.1);
            this.width = width;
            this.onLand = onLand;
            java.util.Arrays.fill(born, -1f);
            born[0] = 0f;
        }

        private double length() {
            return top - floor;
        }

        @Override
        public boolean tick(ClientLevel level) {
            age++;
            if (landed < 0) {
                v = Math.min(0.085, v + 0.006);
                head = Math.min(length(), head + v);
                int seg = (int) Math.min(MAX, head / length() * MAX);
                for (int i = 1; i <= seg; i++) {
                    if (born[i] < 0f) {
                        born[i] = age;
                    }
                }
                RandomSource r = Vfx.random();
                if (r.nextFloat() < 0.3f) {
                    Vfx.ember(x + nx * 0.05, top - head, z + nz * 0.05, nx * 0.01, 0.02, nz * 0.01, 0.03f, 10);
                }
                if (head >= length()) {
                    landed = age;
                    if (onLand != null) {
                        onLand.accept(new Vec3(x + nx * 0.18, floor, z + nz * 0.18));
                    }
                }
            }
            return landed < 0 || age - landed < 170;
        }

        private float segHeat(int i, float t) {
            if (born[i] < 0f) {
                return -1f;
            }
            return (float) Math.exp(-(t - born[i]) / 70.0);
        }

        private void render(Draw d, boolean glow) {
            float t = age + d.partialTick;
            double len = length();
            int seg = (int) Math.min(MAX, Math.ceil(head / len * MAX));
            if (seg < 1) {
                return;
            }
            double sx = -nz, sz = nx;   // arah samping (sejajar dinding)
            int cuts = 5;
            double[] px = new double[cuts], py = new double[cuts], pz = new double[cuts];
            double[] qx = new double[cuts], qy = new double[cuts], qz = new double[cuts];
            int[] pc = new int[cuts], qc = new int[cuts];
            float[] pa = new float[cuts], qa = new float[cuts];
            for (int i = 0; i < seg; i++) {
                float h0 = segHeat(i, t), h1 = segHeat(i + 1, t);
                if (h1 < 0f) {
                    h1 = 1f;
                }
                double y0 = top - len * i / MAX, y1 = Math.max(top - head, top - len * (i + 1) / MAX);
                boolean last = i == seg - 1;
                double w0 = width * (0.65 + 0.35 * h0), w1 = width * (0.65 + 0.35 * h1) * (last && landed < 0 ? 1.5 : 1.0);
                for (int k = 0; k < cuts; k++) {
                    double phi = -Math.PI * 0.5 + Math.PI * k / (cuts - 1);
                    double cs = Math.cos(phi), sn = Math.sin(phi);
                    px[k] = x + (nx * cs + sx * sn) * w0;
                    pz[k] = z + (nz * cs + sz * sn) * w0;
                    py[k] = y0;
                    qx[k] = x + (nx * cs + sx * sn) * w1;
                    qz[k] = z + (nz * cs + sz * sn) * w1;
                    qy[k] = y1;
                    int hot0 = lavaColor(h0), hot1 = lavaColor(h1);
                    double crust0 = smooth((0.35 - h0) / 0.25), crust1 = smooth((0.35 - h1) / 0.25);
                    if (glow) {
                        pc[k] = hot0;
                        qc[k] = hot1;
                        pa[k] = (float) ((1.0 - crust0) * h0 * 0.85);
                        qa[k] = (float) ((1.0 - crust1) * h1 * 0.85);
                    } else {
                        int cr = shade(CRUST, nx * cs + sx * sn, 0.2, nz * cs + sz * sn, 0.5);
                        pc[k] = Draw.mix(hot0, cr, crust0);
                        qc[k] = Draw.mix(hot1, cr, crust1);
                        pa[k] = 0.96f;
                        qa[k] = 0.96f;
                    }
                }
                for (int k = 0; k + 1 < cuts; k++) {
                    d.quad4(px[k], py[k], pz[k], px[k + 1], py[k + 1], pz[k + 1], qx[k + 1], qy[k + 1], qz[k + 1],
                            qx[k], qy[k], qz[k], pc[k], pc[k + 1], qc[k + 1], qc[k], pa[k], pa[k + 1], qa[k + 1], qa[k]);
                }
            }
            if (landed < 0) {   // kepala lelehan
                double hy = top - head;
                if (glow) {
                    d.glow(x + nx * 0.05, hy, z + nz * 0.05, (float) (width * 4.0), LAVA_MID, 0.5f);
                } else {
                    ball(d, x + nx * width * 0.3, hy, z + nz * width * 0.3, width * 1.35, LAVA_HOT, LAVA_MID, 0.97f, 3, 7, false);
                }
            }
        }

        @Override
        public void renderSoft(Draw d) {
            render(d, false);
        }

        @Override
        public void renderGlow(Draw d) {
            float old = d.body(0f);
            render(d, true);
            d.body(old);
        }
    }

    /**
     * Gumpalan lahar yang terlempar dari titik leleh: bola pijar kecil yang jatuh melengkung (gravitasi & hambatan udara),
     * meninggalkan jejak bara. Menyentuh lantai: onLand (biasanya genangan kecil) + cipratan.
     */
    public static final class LavaBlob extends Effect {
        private double x, y, z, ox, oy, oz, vx, vy, vz;
        private final float size;
        private final Floor floor;
        private final Consumer<Vec3> onLand;

        public LavaBlob(Vec3 p, Vec3 v, float size, Floor floor, Consumer<Vec3> onLand) {
            super(70);
            x = ox = p.x;
            y = oy = p.y;
            z = oz = p.z;
            vx = v.x;
            vy = v.y;
            vz = v.z;
            this.size = size;
            this.floor = floor;
            this.onLand = onLand;
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (!super.tick(level)) {
                return false;
            }
            ox = x;
            oy = y;
            oz = z;
            vy -= 0.045;
            vx *= 0.985;
            vz *= 0.985;
            x += vx;
            y += vy;
            z += vz;
            RandomSource r = Vfx.random();
            if (r.nextFloat() < 0.6f) {
                Vfx.ember(x, y, z, 0, 0.01, 0, size * 0.5f, 8 + r.nextInt(5));
            }
            double f = floor == null ? Double.NaN : floor.below(x, y + 0.4, z);
            if (!Double.isNaN(f) && y <= f && vy < 0) {
                Vec3 at = new Vec3(x, f, z);
                for (int k = 0; k < 5; k++) {
                    Vfx.spark(x, f + 0.03, z, (r.nextDouble() - 0.5) * 0.14, 0.06 + r.nextDouble() * 0.08, (r.nextDouble() - 0.5) * 0.14,
                            k % 2 == 0 ? LAVA_HOT : LAVA_MID, 0.045f, 10 + r.nextInt(6), f);
                }
                if (onLand != null) {
                    onLand.accept(at);
                }
                return false;
            }
            return true;
        }

        @Override
        public void renderSoft(Draw d) {
            float pt = d.partialTick;
            double px = Mth.lerp(pt, ox, x), py = Mth.lerp(pt, oy, y), pz = Mth.lerp(pt, oz, z);
            ball(d, px, py, pz, size, LAVA_HOT, LAVA_MID, 0.97f, 4, 6, false);
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            double px = Mth.lerp(pt, ox, x), py = Mth.lerp(pt, oy, y), pz = Mth.lerp(pt, oz, z);
            d.glow(px, py, pz, size * 3.2f, LAVA_MID, 0.55f);
            d.line(px, py, pz, px - vx * 2.0, py - vy * 2.0, pz - vz * 2.0, size * 1.4f, 0f, LAVA_HOT, 0.6f, 0f);
        }
    }

    // ------------------------------------------------------------------ matahari mini

    /**
     * Matahari mini: bola plasma padat dengan permukaan bergranula yang bergolak (sel terang-gelap yang bergerak), tepi
     * lebih gelap & jingga (penggelapan tepi seperti matahari asli), korona berlapis, sinar tipis yang berputar pelan, dan
     * lidah plasma (prominensa) melengkung yang naik-turun di permukaannya. soft = lapisan badan padat (true) atau
     * lapisan cahaya (false). unstable 0-1 = menjelang runtuh (berdenyut & berkedip).
     */
    public static void sunOrb(Draw d, boolean soft, Vec3 c, double r, float t, float a, float unstable, long seed) {
        if (a <= 0.01f || r <= 0.01) {
            return;
        }
        double rr = r * (1.0 + unstable * 0.12 * Math.sin(t * 2.3) + 0.02 * Math.sin(t * 0.7));
        int lat = 10, lon = 18;
        float body = soft ? 0.98f * a : 0.55f * a;
        for (int i = 0; i < lat; i++) {
            double t0 = Math.PI * i / lat, t1 = Math.PI * (i + 1) / lat;
            for (int j = 0; j < lon; j++) {
                double p0 = Math.PI * 2.0 * j / lon + t * 0.01, p1 = Math.PI * 2.0 * (j + 1) / lon + t * 0.01;
                double[] q = {t0, p0, t0, p1, t1, p1, t1, p0};
                double[] vx = new double[4], vy = new double[4], vz = new double[4];
                int[] col = new int[4];
                for (int k = 0; k < 4; k++) {
                    double th = q[k * 2], ph = q[k * 2 + 1];
                    double nx = Math.sin(th) * Math.cos(ph), ny = Math.cos(th), nz = Math.sin(th) * Math.sin(ph);
                    vx[k] = c.x + nx * rr;
                    vy[k] = c.y + ny * rr;
                    vz[k] = c.z + nz * rr;
                    double ex = d.camX - vx[k], ey = d.camY - vy[k], ez = d.camZ - vz[k];
                    double el = Math.sqrt(ex * ex + ey * ey + ez * ez);
                    double facing = el < 1.0E-6 ? 1.0 : Math.max(0.0, (nx * ex + ny * ey + nz * ez) / el);
                    double gran = Math.sin(nx * 9.0 + t * 0.06 + seed) * Math.sin(ny * 8.0 - t * 0.05) * Math.sin(nz * 10.0 + t * 0.04)
                            + 0.5 * Math.sin(nx * 17.0 - ny * 13.0 + t * 0.09) * Math.sin(nz * 15.0 + nx * 7.0);
                    double bright = (0.74 + 0.26 * gran) * (0.55 + 0.45 * facing);
                    col[k] = bright > 0.62 ? Draw.mix(SUN_GOLD, SUN_WHITE, (bright - 0.62) / 0.38) : Draw.mix(SUN_DEEP, SUN_GOLD, bright / 0.62);
                }
                d.quad4(vx[0], vy[0], vz[0], vx[1], vy[1], vz[1], vx[2], vy[2], vz[2], vx[3], vy[3], vz[3],
                        col[0], col[1], col[2], col[3], body, body, body, body);
            }
        }
        if (soft) {
            return;
        }
        float flick = 1f - unstable * 0.35f * (0.5f + 0.5f * Mth.sin(t * 3.1f));
        d.glow(c.x, c.y, c.z, (float) (rr * 1.8), SUN_GOLD, a * 0.7f * flick);
        d.glow(c.x, c.y, c.z, (float) (rr * 3.1), SUN_DEEP, a * 0.32f * flick);
        d.glow(c.x, c.y, c.z, (float) (rr * 5.6), 0xFF5010, a * 0.12f);
        for (int i = 0; i < 14; i++) {   // sinar tipis yang berputar pelan
            double ang = hash(seed, i) * Math.PI * 2.0 + t * 0.006 * (i % 2 == 0 ? 1 : -1);
            double el = (hash(seed, i + 50) - 0.5) * 2.2;
            double dx = Math.cos(ang) * Math.cos(el), dy = Math.sin(el), dz = Math.sin(ang) * Math.cos(el);
            double len = rr * (2.1 + 1.4 * hash(seed, i + 90)) * (0.85 + 0.15 * Math.sin(t * 0.2 + i));
            d.line(c.x + dx * rr, c.y + dy * rr, c.z + dz * rr, c.x + dx * len, c.y + dy * len, c.z + dz * len,
                    (float) (rr * 0.2), 0f, 0xFFE8B0, a * 0.22f, 0f);
        }
        for (int k = 0; k < 4; k++) {   // prominensa: lengkung plasma
            double base = hash(seed, k + 300) * Math.PI * 2.0 + t * 0.004;
            double tilt = (hash(seed, k + 310) - 0.5) * 1.6;
            double span = 0.45 + 0.25 * hash(seed, k + 320);
            double lift = 0.3 + 0.28 * (0.5 + 0.5 * Math.sin(t * 0.05 + k * 1.7));
            int n = 12;
            float[] pts = new float[n * 3];
            for (int i = 0; i < n; i++) {
                double u = i / (double) (n - 1);
                double ang = base - span * 0.5 + span * u;
                double el = tilt + Math.sin(u * Math.PI) * 0.15;
                double dist = rr * (1.0 + lift * Math.sin(u * Math.PI));
                pts[i * 3] = (float) (c.x + Math.cos(ang) * Math.cos(el) * dist);
                pts[i * 3 + 1] = (float) (c.y + Math.sin(el) * dist);
                pts[i * 3 + 2] = (float) (c.z + Math.sin(ang) * Math.cos(el) * dist);
            }
            d.polyline(pts, n, (float) (rr * 0.14), (float) (rr * 0.14), 0xFF5A1A, 0xFFD890, a * 0.8f, a * 0.8f);
        }
    }

    /**
     * Pusaran api: udara panas yang naik ke matahari mini menyeret api & debu jadi tiga pita spiral dari tanah ke atas,
     * makin ke atas makin rapat ke porosnya.
     */
    public static void fireSwirl(Draw d, Vec3 top, double groundY, double radius, float t, float a) {
        double hgt = top.y - groundY;
        if (a <= 0.01f || hgt < 0.5) {
            return;
        }
        int n = 18;
        float[] pts = new float[n * 3], w = new float[n], al = new float[n];
        for (int k = 0; k < 3; k++) {
            for (int i = 0; i < n; i++) {
                double u = i / (double) (n - 1);
                double rho = radius * (1.0 - 0.85 * u) + 0.15;
                double th = k * Math.PI * 2.0 / 3.0 + t * 0.22 + u * 7.0;
                pts[i * 3] = (float) (top.x + Math.cos(th) * rho);
                pts[i * 3 + 1] = (float) (groundY + 0.1 + hgt * 0.85 * u);
                pts[i * 3 + 2] = (float) (top.z + Math.sin(th) * rho);
                w[i] = (float) (0.55 * (1.0 - 0.6 * u));
                al[i] = (float) (a * (0.15 + 0.45 * u) * Math.min(1.0, u / 0.12));
            }
            d.strip(pts, n, w, 1f, al, 0.7f, FIRE_ORANGE);
            d.strip(pts, n, w, 0.4f, al, 1f, FIRE_YELLOW);
        }
    }

    // ------------------------------------------------------------------ Lintas Detik

    /**
     * Cincin kejut yang membeku di udara: saat dunia "berhenti" gelombang pukulannya cuma menggantung (bergetar halus),
     * lalu begitu waktu jalan lagi (release) melebar cepat dan memudar. 0.44 (video): cincin putih tegas yang menyala
     * dengan pendar lembut & isian tipis, muncul dengan hentakan kecil.
     */
    public static final class FrozenRing extends Effect {
        private final Vec3 c, n;
        private final double radius;
        private int released = -1;

        public FrozenRing(Vec3 c, Vec3 n, double radius) {
            super(400);
            this.c = c;
            this.n = n;
            this.radius = radius;
        }

        public void release() {
            if (released < 0) {
                released = age;
            }
        }

        public Vec3 center() {
            return c;
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (released < 0 && age > 300) {
                release();
            }
            return super.tick(level) && (released < 0 || age - released < 12);
        }

        private float burst(float pt) {
            return released < 0 ? -1f : Mth.clamp((age + pt - released) / 12f, 0f, 1f);
        }

        /** Jari-jari sekarang: hentakan kecil saat muncul, bergetar halus selama beku, melebar cepat saat dilepas. */
        private double r(float pt) {
            float k = burst(pt), t = age + pt;
            if (k >= 0f) {
                return radius * (1.0 + 4.5 * Math.sqrt(k));
            }
            double pop = t < 4f ? 1.0 - 0.45 * (1.0 - t / 4.0) * (1.0 - t / 4.0) + 0.14 * Math.sin(t / 4.0 * Math.PI) : 1.0;
            return radius * pop * (0.97 + 0.025 * Math.sin(t * 1.7));
        }

        @Override
        public void renderSoft(Draw d) {
            float k = burst(d.partialTick);
            double r = r(d.partialTick);
            float a = k < 0f ? 0.42f : 0.5f * (1f - k);
            d.ring(c.x, c.y, c.z, n.x, n.y, n.z, r, radius * 0.18, 0xF4F8FF, a, 0.1f, null);
        }

        @Override
        public void renderGlow(Draw d) {
            float k = burst(d.partialTick);
            double r = r(d.partialTick);
            float a = k < 0f ? 0.95f : (1f - k) * (1f - k);
            d.ring(c.x, c.y, c.z, n.x, n.y, n.z, r, radius * 0.07, 0xFFFFFF, a, 0f, null);           // garis putih tegas
            d.ring(c.x, c.y, c.z, n.x, n.y, n.z, r, radius * 0.36, 0xFFE8B8, a * 0.3f, 0.04f, null); // pendar keemasan
            if (k < 0f) {
                d.glow(c.x, c.y, c.z, (float) radius * 0.6f, 0xFFF6E0, 0.18f);
            }
        }
    }

    /**
     * Jejak cahaya keemasan jalur Lintang saat dunia berhenti (0.44, video): garis lurus putih-emas dari satu musuh ke
     * musuh berikutnya, tiap ruas melesat cepat dari titik sebelumnya saat sambarannya terjadi, berkilau selama beku, lalu
     * menyala terang sesaat dan memudar setelah waktu jalan lagi (end).
     */
    public static final class LightTrail extends Effect {
        private static final int MAX = 24;
        private final double[] xs = new double[MAX], ys = new double[MAX], zs = new double[MAX];
        private final int[] born = new int[MAX];
        private int count;
        private int ended = -1;

        public LightTrail(Vec3 start) {
            super(600);
            add(start);
        }

        public void add(Vec3 p) {
            if (count < MAX) {
                xs[count] = p.x;
                ys[count] = p.y;
                zs[count] = p.z;
                born[count] = age;
                count++;
            }
        }

        public void end() {
            if (ended < 0) {
                ended = age;
            }
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (ended < 0 && age > 200) {
                end();
            }
            if (ended < 0 && count >= 2 && age % 2 == 0) {   // butiran cahaya kecil yang menggantung di sepanjang jejak
                RandomSource r = Vfx.random();
                int i = r.nextInt(count - 1);
                double u = r.nextDouble();
                Vfx.mote(Mth.lerp(u, xs[i], xs[i + 1]) + (r.nextDouble() - 0.5) * 0.2, Mth.lerp(u, ys[i], ys[i + 1]) + (r.nextDouble() - 0.5) * 0.2,
                        Mth.lerp(u, zs[i], zs[i + 1]) + (r.nextDouble() - 0.5) * 0.2, 0, 0.002, 0, 0xFFE6A8, 0.05f, 14);
            }
            return super.tick(level) && (ended < 0 || age - ended < 16);
        }

        @Override
        public void renderGlow(Draw d) {
            if (count < 2) {
                return;
            }
            float t = age + d.partialTick;
            float k = ended < 0 ? 0f : Mth.clamp((t - ended) / 16f, 0f, 1f);
            float a = ended < 0 ? 0.9f : (k < 0.15f ? 1f : (1f - k) / 0.85f);
            for (int i = 0; i + 1 < count; i++) {
                float grow = Mth.clamp((t - born[i + 1] + 1f) / 2f, 0f, 1f);   // ruas melesat dari titik sebelumnya
                if (grow <= 0f) {
                    continue;
                }
                double bx = Mth.lerp(grow, xs[i], xs[i + 1]), by = Mth.lerp(grow, ys[i], ys[i + 1]), bz = Mth.lerp(grow, zs[i], zs[i + 1]);
                float shimmer = 0.9f + 0.1f * Mth.sin(t * 1.3f + i * 2.1f);
                d.line(xs[i], ys[i], zs[i], bx, by, bz, 0.5f, 0.5f, 0xFFB84A, a * 0.35f * shimmer, a * 0.35f * shimmer);
                float old = d.body(1.1f);
                d.line(xs[i], ys[i], zs[i], bx, by, bz, 0.17f, 0.17f, 0xFFE2A0, a * shimmer, a * shimmer);
                d.body(old);
                d.line(xs[i], ys[i], zs[i], bx, by, bz, 0.07f, 0.07f, 0xFFFFFF, a, a);
                if (grow < 1f) {   // kepala ruas yang sedang melesat
                    d.glow(bx, by, bz, 0.45f, 0xFFF4DC, a * (1f - grow));
                }
            }
        }
    }
}
