package com.shazammod.client;

import java.lang.reflect.Method;

import com.shazammod.ShazamClientState;
import com.shazammod.client.fx.LintangFx;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * 0.44 Kamera bahu Iris Surya. Di kamera orang ketiga dari belakang, sinar mata keluar lurus searah pandangan kamera:
 * dari situ sinarnya cuma terlihat sebagai satu titik yang tertutup kepala sendiri (itulah kenapa sinar laser "nggak
 * tampak"). Selama X ditahan (charge) dan selama sinar menyala, kamera bergeser halus ke atas bahu kanan Lintang seperti
 * di video, jadi sinar dari kedua mata terlihat utuh sebagai garis panjang dari kepala sampai titik kenanya. Begitu sinar
 * padam kamera kembali pelan ke tempat biasa. Kamera orang pertama nggak diubah.
 */
public final class LintangShoulderCam {
    private LintangShoulderCam() {}

    // ======= Angka yang gampang diutak-atik =======
    /** false = kamera nggak pernah digeser. */
    public static boolean ENABLED = true;
    /** Geser ke kanan (blok, x skala badan). */
    private static final double SIDE = 1.15;
    /** Geser ke atas (blok). */
    private static final double UP = 0.28;
    /** Maju mendekati kepala (blok): kamera bahu lebih dekat dari kamera biasa (4 blok). */
    private static final double IN = 1.1;

    private static float level, levelO;
    private static Method setPosition;
    private static boolean broken;

    /** Tiap tick client: kamera bahu naik saat charge / sinar menyala, turun pelan sesudahnya. */
    public static void tick(Minecraft mc) {
        levelO = level;
        boolean want = ENABLED && mc.player != null && ShazamClientState.isLintang() && ShazamClientState.transformed
                && LintangFx.laserActive(mc.player);
        level = want ? Math.min(1f, level + 0.22f) : Math.max(0f, level - 0.1f);
    }

    public static void clear() {
        level = 0f;
        levelO = 0f;
    }

    /**
     * Dipanggil di ViewportEvent.ComputeCameraAngles (tepat sesudah Camera.setup, sebelum dunia digambar): geser posisi
     * kamera orang ketiga ke atas bahu kanan.
     */
    public static void apply(Camera cam, float partialTick) {
        if (broken || (level <= 0f && levelO <= 0f) || !cam.isDetached()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        Entity e = cam.getEntity();
        if (e == null || e != mc.player || mc.level == null) {
            return;
        }
        float k = Mth.lerp(partialTick, levelO, level);
        k = k * k * (3f - 2f * k);
        if (k <= 0.001f) {
            return;
        }
        boolean mirrored = mc.options.getCameraType().isMirrored();
        double yaw = cam.getYRot() * Mth.DEG_TO_RAD, pitch = cam.getXRot() * Mth.DEG_TO_RAD;
        Vec3 fwd = new Vec3(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
        Vec3 right = new Vec3(-Math.cos(yaw), 0, -Math.sin(yaw));
        Vec3 up = right.cross(fwd);
        double sc = e instanceof net.minecraft.world.entity.LivingEntity le ? le.getScale() : 1.0;
        // kamera depan (cermin) menghadap wajah: kanan kamera = kiri pemain, jadi geser ke arah sebaliknya
        double side = SIDE * sc * k * (mirrored ? -1.0 : 1.0);
        Vec3 from = cam.getPosition();
        // maju mendekat cuma kalau kameranya memang jauh (di lorong sempit kamera sudah mepet: jangan masuk ke kepala)
        double room = from.distanceTo(e.getEyePosition(partialTick)) - 2.6 * sc;
        double in = Mth.clamp(room, 0.0, IN * sc) * k;
        Vec3 to = from.add(right.scale(side)).add(up.scale(UP * sc * k)).add(fwd.scale(in));
        BlockHitResult hit = mc.level.clip(new ClipContext(from, to, ClipContext.Block.VISUAL, ClipContext.Fluid.NONE, e));
        if (hit.getType() != HitResult.Type.MISS) {   // jangan masuk dinding: berhenti sedikit sebelum blok
            Vec3 d = to.subtract(from);
            double len = d.length();
            double keep = Math.max(0.0, hit.getLocation().distanceTo(from) - 0.2);
            to = len < 1.0E-4 ? from : from.add(d.scale(keep / len));
        }
        move(cam, to);
    }

    /** Camera.setPosition(Vec3) dilindungi (protected): dipanggil lewat refleksi; kalau gagal, fitur ini mati sendiri. */
    private static void move(Camera cam, Vec3 to) {
        try {
            if (setPosition == null) {
                setPosition = Camera.class.getDeclaredMethod("setPosition", Vec3.class);
                setPosition.setAccessible(true);
            }
            setPosition.invoke(cam, to);
        } catch (Throwable t) {
            broken = true;
        }
    }
}
