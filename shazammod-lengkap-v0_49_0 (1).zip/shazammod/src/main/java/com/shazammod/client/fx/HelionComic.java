package com.shazammod.client.fx;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import com.mojang.math.Axis;
import com.shazammod.HelionSkills;

import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * 0.45 Gaya komik khusus Projek Helion-6, digambar di layar (di atas HUD) supaya terasa seperti panel buku komik:
 * - Tulisan SFX ("KA-BOOOOM!", "THOOOOM!", "WHAM!") yang meletup di titik hantaman: huruf bergaris tinta hitam tebal di
 *   atas ledakan bergerigi, membesar memantul, sedikit miring, naik pelan lalu memudar.
 * - Balon kata: ejekan Helion-6 di atas kepalanya (kotak putih bergaris tinta dengan ekor), muncul huruf demi huruf;
 *   teriakan (Supernova, Gerhana, Injakan) memakai balon bergerigi kekuningan. Terlihat oleh semua pemain di dekatnya.
 * - Kotak narasi kuning di pojok kanan atas (cuma di layar sendiri), seperti narasi panel komik.
 * - Impact frame (cuma di layar sendiri): garis aksi tinta yang memusat ke titik hantaman, titik halftone di tepi layar,
 *   dan bingkai panel tebal selama beberapa frame.
 * Titik dunia diproyeksikan ke layar dari posisi & arah kamera (FOV dari pengaturan), jadi nggak butuh matriks render.
 */
public final class HelionComic {
    /** false = semua efek komik Helion-6 mati. */
    public static final boolean ENABLED = true;
    /** Jarak terjauh tulisan SFX & balon kata masih digambar (blok). */
    private static final float WORD_RANGE = 64f;
    private static final float BUBBLE_RANGE = 48f;

    public static final String[] HIT_WORDS = {"WHAM!", "KRAK!", "THWAK!", "BAM!"};
    public static final String[] SHARD_WORDS = {"TZAK!", "KZZT!", "SHNK!"};
    public static final String[] SHATTER_WORDS = {"KRSSH!", "SHKRAK!", "KRANG!"};

    private static final int INK = 0x0C0F0D;
    private static final RandomSource RANDOM = RandomSource.create();
    private static final List<Word> WORDS = new ArrayList<>();
    private static final List<Bubble> BUBBLES = new ArrayList<>();
    private static final List<Caption> CAPTIONS = new ArrayList<>();
    private static final List<Impact> IMPACTS = new ArrayList<>();
    private static boolean introShown;

    private HelionComic() {}

    private static final class Word {
        final Vec3 at;
        final String text;
        final int color, burst;
        final float size, rot, spin;
        final int[] len;
        final int life = 26;
        int age;

        Word(Vec3 at, String text, int color, int burst, float size) {
            this.at = at;
            this.text = text;
            this.color = color;
            this.burst = burst;
            this.size = size;
            this.rot = (RANDOM.nextFloat() - 0.5f) * 24f;
            this.spin = RANDOM.nextFloat() * 30f;
            int n = 12 + RANDOM.nextInt(5);
            this.len = new int[n];
            for (int i = 0; i < n; i++) {
                len[i] = 9 + RANDOM.nextInt(8) + (i % 2 == 0 ? 6 : 0);
            }
        }
    }

    private static final class Bubble {
        final Entity speaker;
        final String text;
        final boolean shout;
        final long seed;
        final int life;
        int age;

        Bubble(Entity speaker, String text, boolean shout) {
            this.speaker = speaker;
            this.text = text;
            this.shout = shout;
            this.seed = RANDOM.nextLong();
            this.life = Math.min(120, 50 + text.length() * 2);
        }
    }

    private static final class Caption {
        final String text;
        final int life = 100;
        int age;

        Caption(String text) {
            this.text = text;
        }
    }

    private static final class Impact {
        final Vec3 at;
        final float strength;
        final long seed;
        final int life = 9;
        int age;

        Impact(Vec3 at, float strength) {
            this.at = at;
            this.strength = strength;
            this.seed = RANDOM.nextLong();
        }
    }

    // ------------------------------------------------------------------ pemicu

    public static String pick(String[] words) {
        return words[RANDOM.nextInt(words.length)];
    }

    /** Tulisan SFX meletup di titik dunia. size 1 = sedang, 2 = raksasa (ledakan besar: huruf putih di ledakan hijau). */
    public static void word(Vec3 at, String text, float size) {
        boolean big = size >= 1.4f;
        word(at, text, big ? 0xFFFFFF : 0x8CFF6A, big ? 0x2BD86A : 0xFFE45C, size);
    }

    public static void word(Vec3 at, String text, int color, int burst, float size) {
        if (!ENABLED || at == null) {
            return;
        }
        WORDS.add(new Word(at, text, color, burst, size));
        while (WORDS.size() > 24) {
            WORDS.remove(0);
        }
    }

    /** Balon kata di atas kepala speaker (yang lama diganti). */
    public static void speech(Entity speaker, Component text, boolean shout) {
        if (!ENABLED || speaker == null) {
            return;
        }
        BUBBLES.removeIf(b -> b.speaker == speaker);
        BUBBLES.add(new Bubble(speaker, text.getString(), shout));
        while (BUBBLES.size() > 8) {
            BUBBLES.remove(0);
        }
    }

    /** Kotak narasi kuning (layar sendiri). */
    public static void caption(Component text) {
        if (!ENABLED) {
            return;
        }
        CAPTIONS.add(new Caption(text.getString().toUpperCase(Locale.ROOT)));
        while (CAPTIONS.size() > 2) {
            CAPTIONS.remove(0);
        }
    }

    /** Narasi pembuka, sekali per sesi (berubah wujud pertama kali). */
    public static void intro() {
        if (!introShown) {
            introShown = true;
            caption(Component.translatable("caption.shazammod.helion.transform"));
        }
    }

    /** Impact frame di layar sendiri (strength 0.5-1.2). */
    public static void impact(Vec3 at, float strength) {
        if (!ENABLED) {
            return;
        }
        IMPACTS.add(new Impact(at, strength));
        while (IMPACTS.size() > 2) {
            IMPACTS.remove(0);
        }
    }

    /** Ejekan dari server (HELION_TAUNT): x = jenis (HelionSkills.Taunt), y = nomor kalimat. */
    public static void taunt(AbstractClientPlayer caster, Vec3 data) {
        HelionSkills.Taunt[] all = HelionSkills.Taunt.values();
        int kind = (int) Math.round(data.x);
        if (kind < 0 || kind >= all.length) {
            return;
        }
        HelionSkills.Taunt taunt = all[kind];
        int line = Mth.clamp((int) Math.round(data.y), 0, taunt.lines - 1);
        speech(caster, Component.translatable("taunt.shazammod.helion." + taunt.name().toLowerCase(Locale.ROOT) + "." + line),
                taunt.shout);
    }

    /**
     * 0.47 Dialog duel Lintang vs Helion-6 (HELION_DUEL_LINE dari rival mana pun): x = nomor kalimat, y = kategori (0 datang,
     * 1 mulai, 2 di tengah, 3 menang, 4 kalah), z = teriakan. Kalimat pembuka Lintang juga memunculkan narasi duel.
     */
    public static void duelLine(AbstractClientPlayer caster, Vec3 data) {
        boolean team = data.z > 1.5;   // 0.48 bersekutu melawan Subjek Tiga
        String[] categories = team ? new String[] {"arrive", "fight", "mid", "victory", "defeat", "adapt", "revive", "farewell"}
                : new String[] {"arrive", "fight", "mid", "victory", "defeat"};
        int category = Mth.clamp((int) Math.round(data.y), 0, categories.length - 1);
        String form = com.shazammod.ShazamClientState.form(caster.getId()).id;
        int line = Math.max(0, (int) Math.round(data.x));
        boolean shout = (team ? data.z - 2.0 : data.z) > 0.5;
        speech(caster, Component.translatable((team ? "team" : "duel") + ".shazammod." + form + "." + categories[category] + "." + line),
                shout);
        if (category == 0 && "lintang".equals(form)) {
            caption(Component.translatable(team ? "caption.shazammod.team" : "caption.shazammod.duel"));
        }
    }

    public static void tick() {
        WORDS.removeIf(w -> ++w.age > w.life);
        BUBBLES.removeIf(b -> ++b.age > b.life || b.speaker.isRemoved());
        CAPTIONS.removeIf(c -> ++c.age > c.life);
        IMPACTS.removeIf(i -> ++i.age > i.life);
    }

    public static void clear() {
        WORDS.clear();
        BUBBLES.clear();
        CAPTIONS.clear();
        IMPACTS.clear();
    }

    // ------------------------------------------------------------------ gambar (lapisan GUI)

    public static void renderScreen(GuiGraphics g, DeltaTracker deltaTracker) {
        if (!ENABLED) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.level == null || mc.player == null
                || (WORDS.isEmpty() && BUBBLES.isEmpty() && CAPTIONS.isEmpty() && IMPACTS.isEmpty())) {
            return;
        }
        float pt = deltaTracker.getGameTimeDeltaPartialTick(false);
        int w = g.guiWidth(), h = g.guiHeight();
        try {
            for (Impact impact : IMPACTS) {
                drawImpact(g, mc, impact, pt, w, h);
            }
            for (Word word : WORDS) {
                drawWord(g, mc, word, pt, w, h);
            }
            for (Bubble bubble : BUBBLES) {
                drawBubble(g, mc, bubble, pt, w, h);
            }
            int y = 8;
            for (Caption caption : CAPTIONS) {
                y = drawCaption(g, mc.font, caption, pt, w, y);
            }
        } catch (RuntimeException ignored) {
            // efek komik nggak boleh bikin game crash
        }
    }

    /** Titik dunia -> {x layar, y layar, jarak} di koordinat GUI, atau null kalau di belakang kamera. */
    private static float[] project(Minecraft mc, Vec3 p, int w, int h) {
        Camera cam = mc.gameRenderer.getMainCamera();
        Vec3 c = cam.getPosition();
        double yaw = Math.toRadians(cam.getYRot()), pitch = Math.toRadians(cam.getXRot());
        double fx = -Math.sin(yaw) * Math.cos(pitch), fy = -Math.sin(pitch), fz = Math.cos(yaw) * Math.cos(pitch);
        double rx = -Math.cos(yaw), rz = -Math.sin(yaw);
        double ux = -rz * fy, uy = rz * fx - rx * fz, uz = rx * fy;
        double vx = p.x - c.x, vy = p.y - c.y, vz = p.z - c.z;
        double depth = vx * fx + vy * fy + vz * fz;
        if (depth < 0.25) {
            return null;
        }
        double sx = vx * rx + vz * rz, sy = vx * ux + vy * uy + vz * uz;
        double tan = Math.tan(Math.toRadians(Mth.clamp((double) mc.options.fov().get(), 30.0, 110.0)) * 0.5);
        double half = h * 0.5;
        return new float[] {(float) (w * 0.5 + sx / depth / tan * half), (float) (half - sy / depth / tan * half),
                (float) Math.sqrt(vx * vx + vy * vy + vz * vz)};
    }

    private static void drawWord(GuiGraphics g, Minecraft mc, Word word, float pt, int w, int h) {
        float[] s = project(mc, word.at, w, h);
        if (s == null || s[2] > WORD_RANGE) {
            return;
        }
        float t = word.age + pt;
        float in = Mth.clamp(t / 4f, 0f, 1f);
        float pop = in < 1f ? 0.2f + 1.15f * Mth.sin(in * Mth.PI * 0.5f) : 1.15f - 0.15f * Mth.clamp((t - 4f) / 3f, 0f, 1f);
        float out = Mth.clamp((word.life - t) / 7f, 0f, 1f);
        float scale = 2.2f * word.size * pop * Mth.clamp(14f / Math.max(4f, s[2]), 0.45f, 1.5f) * (0.85f + 0.15f * out);
        int alpha = (int) (255f * Math.max(0.04f, out));
        Font font = mc.font;
        String text = word.text;
        int tw = font.width(text);
        int a = alpha << 24;
        g.pose().pushPose();
        g.pose().translate(s[0], s[1] - t * 0.6f, 0f);
        g.pose().mulPose(Axis.ZP.rotationDegrees(word.rot));
        g.pose().scale(scale, scale, 1f);
        for (int i = 0; i < word.len.length; i++) {   // ledakan bergerigi di belakang tulisan
            g.pose().pushPose();
            g.pose().mulPose(Axis.ZP.rotationDegrees(i * 360f / word.len.length + word.spin));
            int len = word.len[i] + tw / 3;
            g.fill(0, -3, len + 2, 3, a | INK);
            g.fill(0, -2, len, 2, a | (word.burst & 0xFFFFFF));
            g.pose().popPose();
        }
        g.fill(-tw / 2 - 4, -7, tw / 2 + 4, 7, a | INK);
        g.fill(-tw / 2 - 3, -6, tw / 2 + 3, 6, a | (word.burst & 0xFFFFFF));
        int tx = -tw / 2, ty = -4;
        for (int ox = -1; ox <= 1; ox++) {   // garis tinta tebal
            for (int oy = -1; oy <= 1; oy++) {
                if (ox != 0 || oy != 0) {
                    g.drawString(font, text, tx + ox, ty + oy, a | INK, false);
                }
            }
        }
        g.drawString(font, text, tx, ty, a | (word.color & 0xFFFFFF), false);
        g.pose().popPose();
    }

    private static List<String> wrap(Font font, String text, int max) {
        List<String> out = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String part : text.split(" ")) {
            String next = line.length() == 0 ? part : line + " " + part;
            if (font.width(next) > max && line.length() > 0) {
                out.add(line.toString());
                line = new StringBuilder(part);
            } else {
                line = new StringBuilder(next);
            }
        }
        if (line.length() > 0) {
            out.add(line.toString());
        }
        return out;
    }

    private static void drawBubble(GuiGraphics g, Minecraft mc, Bubble b, float pt, int w, int h) {
        Entity e = b.speaker;
        Vec3 head = new Vec3(Mth.lerp(pt, e.xo, e.getX()), Mth.lerp(pt, e.yo, e.getY()) + e.getBbHeight() + 0.45,
                Mth.lerp(pt, e.zo, e.getZ()));
        boolean pov = e == mc.player && mc.options.getCameraType().isFirstPerson();
        float[] s = pov ? new float[] {w * 0.5f, h * 0.3f, 2f} : project(mc, head, w, h);
        if (s == null || s[2] > BUBBLE_RANGE) {
            return;
        }
        Font font = mc.font;
        float t = b.age + pt;
        float in = Mth.clamp(t / 3f, 0f, 1f);
        float out = Mth.clamp((b.life - t) / 6f, 0f, 1f);
        float scale = (0.6f + 0.4f * in) * Mth.clamp(10f / Math.max(2f, s[2]), 0.6f, 1f) * (b.shout ? 1.15f : 1f);
        int a = (int) (255f * Math.max(0.04f, out)) << 24;
        int ink = a | INK, paper = a | (b.shout ? 0xFFF4C2 : 0xFFFFFF);
        List<String> full = wrap(font, b.text, 118);
        int shown = Math.min(b.text.length(), (int) (t * 2.2f) + 1);
        List<String> lines = wrap(font, b.text.substring(0, shown), 118);
        int lh = font.lineHeight + 1;
        int bw = 0;
        for (String l : full) {
            bw = Math.max(bw, font.width(l));
        }
        bw += 10;
        int bh = full.size() * lh + 7;
        int left = -bw / 2, top = -bh - 10;
        g.pose().pushPose();
        g.pose().translate(s[0], s[1], 0f);
        g.pose().scale(scale, scale, 1f);
        if (b.shout) {   // balon teriakan: gerigi di sekeliling kotak
            RandomSource r = RandomSource.create(b.seed);
            float cx = left + bw / 2f, cy = top + bh / 2f;
            for (int k = 0; k < 16; k++) {
                double ang = k * Math.PI * 2.0 / 16 + r.nextFloat() * 0.2;
                float px = cx + (float) Math.cos(ang) * (bw / 2f + 5f), py = cy + (float) Math.sin(ang) * (bh / 2f + 5f);
                g.pose().pushPose();
                g.pose().translate(px, py, 0f);
                g.pose().mulPose(Axis.ZP.rotationDegrees((float) Math.toDegrees(ang) + 45f));
                g.fill(-4, -4, 4, 4, ink);
                g.fill(-3, -3, 3, 3, paper);
                g.pose().popPose();
            }
        }
        g.fill(left - 1, top - 2, left + bw + 1, top + bh + 2, ink);   // garis tepi, sudut membulat
        g.fill(left - 2, top - 1, left + bw + 2, top + bh + 1, ink);
        for (int r = 0; r < 8; r++) {   // ekor ke arah kepala (garis tinta)
            int x0 = -6 + r, x1 = x0 + Math.max(1, 6 - r);
            g.fill(x0 - 1, top + bh + r, x1 + 1, top + bh + r + 1, ink);
        }
        g.fill(left, top - 1, left + bw, top + bh + 1, paper);
        g.fill(left - 1, top, left + bw + 1, top + bh, paper);
        for (int r = 0; r < 7; r++) {
            int x0 = -6 + r, x1 = x0 + Math.max(0, 5 - r);
            if (x1 > x0) {
                g.fill(x0, top + bh + r, x1, top + bh + r + 1, paper);
            }
        }
        for (int i = 0; i < lines.size(); i++) {
            g.drawString(font, lines.get(i), left + 5, top + 4 + i * lh, ink, false);
        }
        g.pose().popPose();
    }

    private static int drawCaption(GuiGraphics g, Font font, Caption c, float pt, int w, int y) {
        float t = c.age + pt;
        float in = Mth.clamp(t / 4f, 0f, 1f), out = Mth.clamp((c.life - t) / 8f, 0f, 1f);
        int a = (int) (255f * Math.max(0.04f, Math.min(in, out))) << 24;
        List<String> full = wrap(font, c.text, 150);
        int shown = Math.min(c.text.length(), (int) (t * 1.6f) + 1);
        List<String> lines = wrap(font, c.text.substring(0, shown), 150);
        int lh = font.lineHeight + 1;
        int bw = 0;
        for (String l : full) {
            bw = Math.max(bw, font.width(l));
        }
        bw += 12;
        int bh = full.size() * lh + 8;
        int x = w - bw - 10 + (int) ((1f - in) * 20f);
        g.fill(x - 2, y - 2, x + bw + 2, y + bh + 2, a | INK);
        g.fill(x, y, x + bw, y + bh, a | 0xF4DC6A);
        for (int i = 0; i < lines.size(); i++) {
            g.drawString(font, lines.get(i), x + 6, y + 5 + i * lh, a | INK, false);
        }
        return y + bh + 8;
    }

    private static void drawImpact(GuiGraphics g, Minecraft mc, Impact im, float pt, int w, int h) {
        float k = Mth.clamp(1f - (im.age + pt) / im.life, 0f, 1f);
        if (k <= 0.02f) {
            return;
        }
        float[] s = project(mc, im.at, w, h);
        float cx = s != null ? Mth.clamp(s[0], w * 0.2f, w * 0.8f) : w * 0.5f;
        float cy = s != null ? Mth.clamp(s[1], h * 0.2f, h * 0.8f) : h * 0.5f;
        RandomSource r = RandomSource.create(im.seed);
        int lineA = Mth.clamp((int) (230f * k * Math.min(1f, im.strength)), 0, 230) << 24;
        float far = (float) Math.hypot(w, h);
        float near = Math.min(w, h) * (0.22f + 0.12f * (1f - k));
        for (int i = 0; i < 44; i++) {   // garis aksi tinta memusat ke titik hantaman
            float ang = i * 360f / 44 + r.nextFloat() * 6f;
            float r0 = near * (0.75f + r.nextFloat() * 0.7f);
            int thick = 1 + r.nextInt(3);
            g.pose().pushPose();
            g.pose().translate(cx, cy, 0f);
            g.pose().mulPose(Axis.ZP.rotationDegrees(ang));
            g.fill((int) r0, -thick, (int) far, thick, lineA | INK);
            g.pose().popPose();
        }
        int dotA = (int) (150f * k) << 24;   // titik halftone di tepi layar
        float maxD = Math.max(w, h) * 0.75f;
        for (int yy = 4; yy < h; yy += 8) {
            for (int xx = 4; xx < w; xx += 8) {
                float d = (float) Math.hypot(xx - cx, yy - cy) / maxD;
                if (d < 0.6f) {
                    continue;
                }
                int sz = Math.min(4, (int) ((d - 0.6f) * 12f) + 1);
                g.fill(xx - sz / 2, yy - sz / 2, xx - sz / 2 + sz, yy - sz / 2 + sz, dotA | INK);
            }
        }
        int frame = (int) (230f * k) << 24 | INK;   // bingkai panel
        int b = 5;
        g.fill(0, 0, w, b, frame);
        g.fill(0, h - b, w, h, frame);
        g.fill(0, b, b, h - b, frame);
        g.fill(w - b, b, w, h - b, frame);
    }
}
