package com.shazammod.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.ShazamMod;
import com.shazammod.helion3.Helion3;

import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * 0.48 Subjek Tiga (Helion-3): badan pemain dengan tekstur sendiri (kulit hangus, jahitan operasi, tali pengekang, kalung
 * besi III), retakan & mata dua warna yang menyala (lapisan mata), duri sel mati 3D yang mengikuti gerak tubuh (punggung,
 * bahu, lengan bawah, tengkorak, betis; menyala hijau saat cakarnya menyerap Cryon), dan pose sendiri: membungkuk dari
 * pinggul, merangkak keluar dari tanah, meraung, melompat, menyeruduk, kombo hantaman, tumbang, meringkuk di kepompong,
 * bangkit, dan hancur. Ukurannya dari atribut SCALE entity (1,45x).
 * 0.49: bentuk 3D-nya sekarang dari Helion3Geo (tanduk, taring, rusuk tulang, kristal inti di dada, karapas bahu, cakar
 * melengkung, pelat lutut), retakan & matanya berdenyut seperti jantung (makin cepat tiap kali dia sudah bangkit), dadanya
 * mengembang saat bernapas, dan langkahnya mengayun berat.
 */
public class Helion3Renderer extends HumanoidMobRenderer<Helion3, Helion3Renderer.Model> {
    private static final ResourceLocation TEXTURE = ShazamMod.id("textures/entity/helion3/skin.png");
    private static final ResourceLocation GLOW = ShazamMod.id("textures/entity/helion3/glow.png");
    private static final ResourceLocation SPIKE = ShazamMod.id("textures/entity/helion3/spike.png");
    private static final RenderType GLOW_TYPE = RenderType.eyes(GLOW);

    public Helion3Renderer(EntityRendererProvider.Context context) {
        super(context, new Model(context.bakeLayer(ModelLayers.PLAYER)), 0.9f);
        this.addLayer(new Glow(this));
        this.addLayer(new Parts(this));
    }

    @Override
    public ResourceLocation getTextureLocation(Helion3 entity) {
        return TEXTURE;
    }

    // ------------------------------------------------------------------ model & pose

    public static class Model extends PlayerModel<Helion3> {
        public Model(ModelPart root) {
            super(root, false);
        }

        private static float ease(float t0, float t1, float t) {
            float k = Mth.clamp((t - t0) / Math.max(0.001f, t1 - t0), 0f, 1f);
            return k * k * (3f - 2f * k);
        }

        private static void pose(ModelPart p, float w, float x, float y, float z) {
            p.xRot = Mth.lerp(w, p.xRot, x);
            p.yRot = Mth.lerp(w, p.yRot, y);
            p.zRot = Mth.lerp(w, p.zRot, z);
        }

        /** Membungkuk dari pinggul sebesar theta: badan, kepala, & bahu ikut maju-turun, kaki tetap di tanah. */
        private void lean(float theta) {
            float c = Mth.cos(theta), s = Mth.sin(theta);
            body.xRot = theta;
            body.y = 12f - 12f * c;
            body.z = -12f * s;
            head.y = body.y;
            head.z = body.z;
            head.xRot -= theta * 0.8f;
            rightArm.y = body.y + 2f * c;
            rightArm.z = body.z + 2f * s;
            leftArm.y = body.y + 2f * c;
            leftArm.z = body.z + 2f * s;
        }

        @Override
        public void setupAnim(Helion3 e, float limbSwing, float limbAmount, float age, float headYaw, float headPitch) {
            super.setupAnim(e, limbSwing, limbAmount * 1.2f, age, headYaw, headPitch);
            float pt = Mth.clamp(age - e.tickCount, 0f, 1f);
            float t = e.actionTime(pt);
            float breathe = Mth.sin(age * 0.09f) * 0.04f;
            float theta = 0.32f + breathe;
            // 0.49: kemiringan badan & kepala nggak pernah diatur ulang oleh model dasarnya, jadi getaran raungan dulu
            // menumpuk. Sekarang selalu mulai dari nol, lalu ditambah ayunan langkah raksasanya.
            body.zRot = 0f;
            head.zRot = 0f;
            float walk = Math.min(1f, limbAmount);
            float stride = Mth.cos(limbSwing * 0.6662f) * walk;
            body.zRot += stride * 0.075f;                  // badan oleng ke kaki yang menapak
            body.yRot += stride * 0.11f;                   // bahu ikut memutar
            head.zRot -= stride * 0.05f;                   // kepala mengimbangi
            head.yRot -= stride * 0.06f;
            theta += Math.abs(Mth.sin(limbSwing * 0.6662f)) * 0.07f * walk;   // tiap langkah: badan menghentak turun
            // napas berat: dada mengembang ke depan-belakang dan sedikit ke samping
            float inhale = Mth.sin(age * 0.09f);
            body.xScale = 1f + 0.03f * inhale;
            body.zScale = 1f + 0.08f * inhale;
            // diam: kepala mengendus kiri-kanan pelan, jari-jari cakarnya gelisah
            float idle = 1f - walk;
            head.yRot += Mth.sin(age * 0.043f) * 0.12f * idle;
            head.xRot += Mth.sin(age * 0.071f + 1.3f) * 0.04f * idle;
            rightArm.zRot += Mth.sin(age * 0.11f) * 0.03f * idle;
            leftArm.zRot -= Mth.sin(age * 0.11f + 0.8f) * 0.03f * idle;
            // lengan raksasa menggantung ke depan, sedikit terbuka
            rightArm.xRot -= 0.35f;
            leftArm.xRot -= 0.35f;
            rightArm.zRot += 0.22f;
            leftArm.zRot -= 0.22f;
            switch (e.action()) {
                case EMERGE -> {
                    float rise = ease(0f, 40f, t);
                    theta = Mth.lerp(rise, 1.1f, 0.32f);
                    float reach = ease(0f, 20f, t) * (1f - ease(30f, 44f, t));
                    pose(rightArm, reach, -2.2f, 0f, 0.3f);
                    pose(leftArm, reach, -2.2f, 0f, -0.3f);
                    float roar = ease(44f, 50f, t) * (1f - ease(56f, 60f, t));
                    theta = Mth.lerp(roar, theta, -0.1f);
                    pose(rightArm, roar, -0.3f, 0f, 1.3f);
                    pose(leftArm, roar, -0.3f, 0f, -1.3f);
                    head.xRot -= 0.6f * roar;
                }
                case ROAR -> {
                    float wind = ease(0f, 8f, t) * (1f - ease(8f, 10f, t));
                    theta = Mth.lerp(wind, theta, 0.5f);
                    float roar = ease(8f, 11f, t) * (1f - ease(28f, 34f, t));
                    theta = Mth.lerp(roar, theta, -0.15f);
                    pose(rightArm, roar, -0.5f, 0f, 1.4f);
                    pose(leftArm, roar, -0.5f, 0f, -1.4f);
                    head.xRot -= 0.7f * roar;
                    float shake = Mth.sin(age * 2.3f) * 0.04f * roar;
                    body.zRot += shake;
                    head.zRot += shake * 2f;
                }
                case LEAP -> {
                    float crouch = ease(0f, Helion3.LEAP_WINDUP, t) * (1f - ease(Helion3.LEAP_WINDUP, Helion3.LEAP_WINDUP + 2f, t));
                    theta = Mth.lerp(crouch, theta, 0.7f);
                    pose(rightArm, crouch, 0.6f, 0f, 0.2f);
                    pose(leftArm, crouch, 0.6f, 0f, -0.2f);
                    float air = ease(Helion3.LEAP_WINDUP, Helion3.LEAP_WINDUP + 4f, t);
                    theta = Mth.lerp(air, theta, -0.1f);
                    pose(rightArm, air, -3.0f, 0f, 0.25f);
                    pose(leftArm, air, -3.0f, 0f, -0.25f);
                    pose(rightLeg, air, -0.9f, 0f, 0.05f);
                    pose(leftLeg, air, -0.5f, 0f, -0.05f);
                }
                case STAGGER -> {
                    float w = 1f - ease(6f, 16f, t);
                    theta = Mth.lerp(w, theta, 0.75f);
                    pose(rightArm, w, -0.5f, 0f, 0.4f);
                    pose(leftArm, w, -0.5f, 0f, -0.4f);
                    pose(rightLeg, w, -0.5f, 0f, 0.1f);
                    pose(leftLeg, w, 0.4f, 0f, -0.1f);
                }
                case CHARGE -> {
                    float wind = ease(0f, Helion3.CHARGE_WINDUP, t);
                    theta = Mth.lerp(wind, theta, 0.6f);
                    pose(rightArm, wind, 0.6f, 0f, 0.3f);
                    rightLeg.xRot += Mth.sin(age * 0.8f) * 0.4f * wind * (1f - ease(Helion3.CHARGE_WINDUP - 2f, Helion3.CHARGE_WINDUP, t));
                    float run = ease(Helion3.CHARGE_WINDUP, Helion3.CHARGE_WINDUP + 3f, t);
                    theta = Mth.lerp(run, theta, 0.85f);
                    pose(rightArm, run, 0.9f, 0f, 0.3f);
                    pose(leftArm, run, 0.9f, 0f, -0.3f);
                    rightLeg.xRot = Mth.lerp(run, rightLeg.xRot, Mth.sin(age * 1.6f) * 1.1f);
                    leftLeg.xRot = Mth.lerp(run, leftLeg.xRot, -Mth.sin(age * 1.6f) * 1.1f);
                }
                case SMASH -> {
                    float up1 = ease(0f, 7f, t) * (1f - ease(7f, 9f, t));
                    float down1 = ease(7f, 10f, t) * (1f - ease(11f, 14f, t));
                    pose(rightArm, up1, -2.9f, 0f, 0.1f);
                    pose(rightArm, down1, -0.5f, 0f, 0.2f);
                    float up2 = ease(12f, 18f, t) * (1f - ease(18f, 20f, t));
                    float down2 = ease(18f, 21f, t) * (1f - ease(22f, 25f, t));
                    pose(leftArm, up2, -2.9f, 0f, -0.1f);
                    pose(leftArm, down2, -0.5f, 0f, -0.2f);
                    float up3 = ease(24f, 30f, t) * (1f - ease(30f, 32f, t));
                    float down3 = ease(30f, 33f, t) * (1f - ease(35f, 40f, t));
                    pose(rightArm, up3, -3.0f, 0f, 0.2f);
                    pose(leftArm, up3, -3.0f, 0f, -0.2f);
                    pose(rightArm, down3, -0.4f, 0f, 0.3f);
                    pose(leftArm, down3, -0.4f, 0f, -0.3f);
                    theta = Mth.lerp(Math.max(down1, down2) * 0.6f + down3, theta, 0.9f);
                    theta = Mth.lerp(up3, theta, -0.05f);
                }
                case FALL -> {
                    float w = ease(0f, 14f, t);
                    theta = Mth.lerp(w, theta, 1.3f);
                    pose(rightArm, w, 0.2f, 0f, 0.1f);
                    pose(leftArm, w, 0.2f, 0f, -0.1f);
                    head.xRot += 0.4f * w;
                }
                case REVIVE -> {
                    float curl = 1f - ease(52f, 58f, t);
                    float tremble = Mth.sin(age * 3.1f) * 0.03f * (0.4f + ease(0f, 50f, t));
                    theta = Mth.lerp(curl, theta, 1.3f) + tremble;
                    pose(rightArm, curl, -1.2f, -0.6f, 0f);
                    pose(leftArm, curl, -1.2f, 0.6f, 0f);
                    float burst = ease(55f, 60f, t) * (1f - ease(62f, 70f, t));
                    theta = Mth.lerp(burst, theta, -0.2f);
                    pose(rightArm, burst, -0.5f, 0f, 1.5f);
                    pose(leftArm, burst, -0.5f, 0f, -1.5f);
                    head.xRot -= 0.8f * burst;
                }
                case DEATH -> {
                    float sink = ease(0f, 60f, t);
                    float tremble = Mth.sin(age * 3.7f) * 0.06f * sink;
                    theta = Mth.lerp(sink, theta, 1.2f) + tremble;
                    float reach = ease(0f, 10f, t) * (1f - ease(30f, 45f, t));
                    pose(rightArm, reach, -1.6f, 0f, 0.5f);
                    pose(leftArm, reach, -1.4f, 0f, -0.5f);
                    head.xRot -= 0.5f * reach;
                    body.zRot += tremble;
                }
                default -> { }
            }
            lean(theta);
            float shrug = Mth.sin(age * 0.09f) * 0.45f;    // bahu naik-turun mengikuti napas
            rightArm.y -= shrug;
            leftArm.y -= shrug;
            hat.copyFrom(head);
            jacket.copyFrom(body);
            rightSleeve.copyFrom(rightArm);
            leftSleeve.copyFrom(leftArm);
            rightPants.copyFrom(rightLeg);
            leftPants.copyFrom(leftLeg);
        }
    }

    // ------------------------------------------------------------------ cahaya & bentuk 3D

    /** 0..1: seberapa "mengamuk" tampilannya (tiap nyawa yang hilang membuatnya makin beringas; raungan = penuh). */
    static float fury(Helion3 e, float pt) {
        float lost = Mth.clamp((Helion3.LIVES - e.livesLeft()) / (float) Math.max(1, Helion3.LIVES - 1), 0f, 1f) * 0.55f;
        if (e.action() == Helion3.Action.ROAR) {
            float t = e.actionTime(pt);
            lost = Math.max(lost, Mth.clamp((t - 6f) / 4f, 0f, 1f) * Mth.clamp((Helion3.ROAR_TICKS - t) / 8f, 0f, 1f));
        }
        return lost;
    }

    /** Retakan & mata dua warna: berdenyut seperti jantung, menyala terang saat meraung & bangkit, meredup saat tumbang. */
    static final class Glow extends RenderLayer<Helion3, Model> {
        Glow(RenderLayerParent<Helion3, Model> parent) {
            super(parent);
        }

        @Override
        public void render(PoseStack ps, MultiBufferSource buffers, int light, Helion3 e, float limbSwing, float limbAmount,
                           float pt, float age, float headYaw, float headPitch) {
            if (e.isInvisible()) {
                return;
            }
            float fury = fury(e, pt);
            float beat = Helion3Geo.beat(age + e.getId() * 3f, fury > 0.3f);
            float k = 0.5f + 0.4f * beat + 0.35f * fury;
            float t = e.actionTime(pt);
            switch (e.action()) {
                case FALL -> k = Mth.lerp(Mth.clamp(t / 14f, 0f, 1f), k, 0.12f);
                case REVIVE -> k = 0.12f + 0.9f * Helion3Geo.beat(t, t > 30f) * Mth.clamp(t / 20f, 0.2f, 1f);
                case DEATH -> k = (0.4f + 0.6f * Math.abs(Mth.sin(age * 1.7f))) * Mth.clamp(1.2f - t / Helion3.DEATH_TICKS, 0f, 1f);
                case EMERGE -> k *= Mth.clamp(t / 30f, 0.15f, 1f);
                default -> { }
            }
            int c = (int) (Mth.clamp(k, 0f, 1f) * 255f);
            getParentModel().renderToBuffer(ps, buffers.getBuffer(GLOW_TYPE), 15728880, OverlayTexture.NO_OVERLAY,
                    0xFF000000 | (c << 16) | (c << 8) | c);
        }
    }

    /** Tanduk, taring, rusuk, kristal inti, karapas, cakar, dan duri sel mati (lihat Helion3Geo). */
    static final class Parts extends RenderLayer<Helion3, Model> {
        Parts(RenderLayerParent<Helion3, Model> parent) {
            super(parent);
        }

        @Override
        public void render(PoseStack ps, MultiBufferSource buffers, int light, Helion3 e, float limbSwing, float limbAmount,
                           float pt, float age, float headYaw, float headPitch) {
            if (e.isInvisible()) {
                return;
            }
            Model m = getParentModel();
            float fury = fury(e, pt);
            float beat = Helion3Geo.beat(age + e.getId() * 3f, fury > 0.3f);
            if (e.action() == Helion3.Action.REVIVE) {
                float t = e.actionTime(pt);
                beat = Helion3Geo.beat(t, t > 30f);
            }
            Helion3Geo.render(m.head, m.body, m.rightArm, m.leftArm, m.rightLeg, m.leftLeg, ps, buffers, light,
                    LivingEntityRenderer.getOverlayCoords(e, 0f), e.claws() / 8f, fury, beat);
        }
    }
}
