package com.shazammod.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.shazammod.ShazamMod;
import com.shazammod.client.vfx.Draw;

import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * 0.49 Bagian 3D tambahan untuk dua juara sains (memakai pembangun bentuk yang sama dengan Subjek Tiga, Helion3Geo):
 *
 *   Helion-6  kristal Cryon yang tumbuh menembus kostumnya: gugus kristal di kedua bahu, dua bilah kristal di tiap lengan
 *             bawah, tiga simpul kristal di sepanjang tulang punggung, dan kristal lutut. Badannya kristal hijau tua yang
 *             ikut cahaya dunia; di atasnya cahaya radiasi yang terangnya mengikuti jalur radiasi kostumnya (redup &
 *             berkedip di bawah matahari, membara saat Lonjakan / skill).
 *   Lintang   perhiasan dari cahaya matahari yang memadat (cuma ada di Mode Surya, sama seperti matahari bahunya):
 *             gelang lengan berbingkai dengan permata matahari bersinar di sisi luarnya, dan sabuk dengan gesper cakram
 *             matahari delapan sinar. Menyala sendiri, membesar dengan hentakan kecil saat berubah wujud.
 *
 * Semua menempel pada bagian badan model (ikut gerak & putarannya). Angka bentuk dalam piksel model.
 */
public final class HeroGeo {
    public static final ResourceLocation CRYSTAL = ShazamMod.id("textures/entity/helion/crystal.png");
    public static final ResourceLocation GOLD = ShazamMod.id("textures/entity/lintang/gold.png");
    private static final int FULLBRIGHT = 15728880;
    private static final int SUN_GOLD = 0xFFD890;

    private HeroGeo() {}

    // ------------------------------------------------------------------ Helion-6: kristal Cryon

    /** Satu kristal: batang yang sedikit mengembang lalu meruncing (obelisk bersisi empat). */
    private static void crystal(Helion3Geo.Out o, float x, float y, float z, float dx, float dy, float dz, float len, float half) {
        float dl = Mth.sqrt(dx * dx + dy * dy + dz * dz) + 1.0E-6f;
        dx /= dl;
        dy /= dl;
        dz /= dl;
        float l1 = len * 0.6f;
        float mx = x + dx * l1, my = y + dy * l1, mz = z + dz * l1;
        o.prism(x, y, z, mx, my, mz, half * 0.78f, half, 1f, 0.42f, false);
        o.prism(mx, my, mz, x + dx * len, y + dy * len, z + dz * len, half, 0f, 0.42f, 0f, false);
    }

    /** Lengan kanan Helion-6 (kubus -3..1, -2..10, -2..2; sisi luar di x = -3). */
    private static void helionShoulder(Helion3Geo.Out o) {
        crystal(o, -2.3f, -1.9f, 0.1f, -0.55f, -1f, 0.1f, 4.4f, 0.9f);       // kristal utama
        crystal(o, -0.9f, -1.9f, -1.1f, -0.12f, -1f, -0.45f, 3.0f, 0.66f);
        crystal(o, -2.7f, -1.1f, 1.0f, -0.85f, -0.7f, 0.5f, 2.9f, 0.62f);
        crystal(o, -0.3f, -1.9f, 1.2f, 0.2f, -1f, 0.55f, 1.9f, 0.46f);
        crystal(o, -3.0f, 0.4f, -0.6f, -1f, -0.35f, -0.3f, 1.7f, 0.44f);
    }

    private static void helionBlades(Helion3Geo.Out o) {
        // dua bilah kristal di punggung lengan bawah, miring ke arah siku
        o.prism(-3.05f, 5.4f, 0.5f, -4.9f, 3.5f, 1.2f, 0.55f, 0f, 1f, 0f, false);
        o.prism(-3.05f, 7.7f, -0.4f, -4.6f, 6.1f, 0.1f, 0.5f, 0f, 1f, 0f, false);
        o.slab(-3.15f, 7.0f, 0f, 0.2f, 0f, 0f, 0f, 2.0f, 0f, 0f, 0f, 0.7f);  // dudukan bilahnya
    }

    private static void helionBody(Helion3Geo.Out o) {
        float k = o.pulse;
        o.gem(0f, 2.7f, 2.35f, 0.75f * k, 0.95f * k, 0.5f * k);              // tiga simpul di tulang punggung
        o.gem(0f, 5.3f, 2.3f, 0.62f * k, 0.8f * k, 0.42f * k);
        o.gem(0f, 7.7f, 2.25f, 0.5f * k, 0.66f * k, 0.36f * k);
        for (int s = -1; s <= 1; s += 2) {                                    // kristal kecil di belikat
            crystal(o, 2.4f * s, 1.6f, 2.0f, 0.5f * s, -0.7f, 1f, 2.2f, 0.5f);
        }
    }

    private static void helionLeg(Helion3Geo.Out o) {
        crystal(o, 0f, 4.7f, -2.1f, 0f, -0.45f, -1f, 1.7f, 0.5f);            // lutut
    }

    /**
     * Semua kristal Cryon Helion-6.
     *
     * @param glow terang radiasinya (HelionFx.veinGlow, 0..1,05)
     */
    public static void helion(ModelPart body, ModelPart rightArm, ModelPart leftArm, ModelPart rightLeg, ModelPart leftLeg,
                              PoseStack ps, MultiBufferSource buffers, int light, int overlay, float glow, float age) {
        Helion3Geo.Out o = new Helion3Geo.Out();
        o.light = light;
        o.overlay = overlay;
        o.pulse = 1f + 0.1f * Mth.sin(age * 0.12f) + 0.15f * Mth.clamp(glow - 0.7f, 0f, 0.4f);
        o.vc = buffers.getBuffer(RenderType.entityCutoutNoCull(CRYSTAL));
        o.r = 255;
        o.g = 255;
        o.b = 255;
        shapes(body, rightArm, leftArm, rightLeg, leftLeg, ps, o);
        // cahaya radiasi di atasnya
        o.vc = buffers.getBuffer(RenderType.eyes(CRYSTAL));
        o.light = FULLBRIGHT;
        o.overlay = OverlayTexture.NO_OVERLAY;
        Helion3Geo.tint(o, 0xFFFFFF, 0.18f + 0.7f * Mth.clamp(glow, 0f, 1.05f));
        shapes(body, rightArm, leftArm, rightLeg, leftLeg, ps, o);
    }

    private static void shapes(ModelPart body, ModelPart rightArm, ModelPart leftArm, ModelPart rightLeg, ModelPart leftLeg,
                               PoseStack ps, Helion3Geo.Out o) {
        Helion3Geo.part(body, ps, o, 1f, HeroGeo::helionBody);
        Helion3Geo.part(rightArm, ps, o, 1f, HeroGeo::helionShoulder);
        Helion3Geo.part(leftArm, ps, o, -1f, HeroGeo::helionShoulder);
        Helion3Geo.part(rightArm, ps, o, 1f, HeroGeo::helionBlades);
        Helion3Geo.part(leftArm, ps, o, -1f, HeroGeo::helionBlades);
        Helion3Geo.part(rightLeg, ps, o, 1f, HeroGeo::helionLeg);
        Helion3Geo.part(leftLeg, ps, o, -1f, HeroGeo::helionLeg);
    }

    /** Lengan orang pertama Helion-6: cuma bilah kristal lengan bawahnya (kristal bahu bakal menutupi layar). */
    public static void helionArm(ModelPart arm, boolean left, PoseStack ps, MultiBufferSource buffers, int light, float glow) {
        Helion3Geo.Out o = new Helion3Geo.Out();
        o.light = light;
        o.overlay = OverlayTexture.NO_OVERLAY;
        o.vc = buffers.getBuffer(RenderType.entityCutoutNoCull(CRYSTAL));
        o.r = 255;
        o.g = 255;
        o.b = 255;
        float sx = left ? -1f : 1f;
        Helion3Geo.part(arm, ps, o, sx, HeroGeo::helionBlades);
        o.vc = buffers.getBuffer(RenderType.eyes(CRYSTAL));
        o.light = FULLBRIGHT;
        Helion3Geo.tint(o, 0xFFFFFF, 0.18f + 0.7f * Mth.clamp(glow, 0f, 1.05f));
        Helion3Geo.part(arm, ps, o, sx, HeroGeo::helionBlades);
    }

    // ------------------------------------------------------------------ Lintang: perhiasan cahaya

    /** Pita persegi yang melingkari kubus bagian badan (pusat cx,cz; setengah lebar hx,hz) di ketinggian y. */
    private static void band(Helion3Geo.Out o, float cx, float cz, float hx, float hz, float y, float hh, float t) {
        float h = t * 0.5f;
        o.slab(cx - hx - h, y, cz, h, 0f, 0f, 0f, hh, 0f, 0f, 0f, hz + t);
        o.slab(cx + hx + h, y, cz, h, 0f, 0f, 0f, hh, 0f, 0f, 0f, hz + t);
        o.slab(cx, y, cz - hz - h, hx + t, 0f, 0f, 0f, hh, 0f, 0f, 0f, h);
        o.slab(cx, y, cz + hz + h, hx + t, 0f, 0f, 0f, hh, 0f, 0f, 0f, h);
    }

    /** Gelang lengan kanan: badan gelang, dua bingkai, permata matahari & enam sinarnya di sisi luar. bristle = lebar lengan. */
    private static void lintangCuff(Helion3Geo.Out o) {
        float k = o.pulse;                 // 0..1: membesar saat berubah wujud
        float hx = o.bristle;              // setengah lebar lengan (2 lebar, 1,5 ramping)
        float cx = 1f - hx;                // pusat lengan kanan di sumbu x
        band(o, cx, 0f, hx, 2f, 7.6f, 1.45f, 0.42f * k);
        band(o, cx, 0f, hx, 2f, 6.15f, 0.2f, 0.72f * k);
        band(o, cx, 0f, hx, 2f, 9.05f, 0.2f, 0.72f * k);
        float gx = cx - hx - 0.62f * k;
        o.gem(gx, 7.6f, 0f, 0.4f * k, 0.78f * k, 0.78f * k);
        for (int i = 0; i < 6; i++) {
            float a = (float) (Math.PI * 2.0) * i / 6f + 0.5f;
            float c = Mth.cos(a), s = Mth.sin(a);
            o.prism(gx, 7.6f + c * 0.7f * k, s * 0.7f * k, gx - 0.15f, 7.6f + c * 1.55f * k, s * 1.55f * k, 0.2f * k, 0f, 1f, 0f, false);
        }
    }

    /** Sabuk di pinggang + gesper cakram matahari delapan sinar. */
    private static void lintangBelt(Helion3Geo.Out o) {
        float k = o.pulse;
        band(o, 0f, 0f, 4f, 2f, 10.45f, 0.72f, 0.4f * k);
        o.gem(0f, 10.45f, -2.55f * (0.6f + 0.4f * k), 1.2f * k, 1.2f * k, 0.42f * k);
        for (int i = 0; i < 8; i++) {
            float a = (float) (Math.PI * 2.0) * i / 8f;
            float c = Mth.cos(a), s = Mth.sin(a);
            float len = (i % 2 == 0 ? 2.15f : 1.7f) * k;
            o.prism(c * 1.0f * k, 10.45f + s * 1.0f * k, -2.6f, c * len, 10.45f + s * len, -2.75f, 0.24f * k, 0f, 1f, 0f, false);
        }
    }

    /**
     * Perhiasan cahaya Lintang.
     *
     * @param size 0..1 (lebih sedikit saat memantul): besar perhiasannya saat berubah wujud
     * @param glow 0..1 tambahan pendar (muatan penuh, Mode Surya membara)
     * @param slim lengan ramping (model Alex)
     */
    public static void lintang(ModelPart body, ModelPart rightArm, ModelPart leftArm, PoseStack ps, MultiBufferSource buffers,
                               float size, float glow, boolean slim, float age) {
        if (size <= 0.05f) {
            return;
        }
        Helion3Geo.Out o = new Helion3Geo.Out();
        o.light = FULLBRIGHT;
        o.overlay = OverlayTexture.NO_OVERLAY;
        o.pulse = size * (1f + 0.03f * Mth.sin(age * 0.18f));
        o.bristle = slim ? 1.5f : 2f;
        o.vc = buffers.getBuffer(RenderType.entityCutoutNoCull(GOLD));
        o.r = 255;
        o.g = 255;
        o.b = 255;
        Helion3Geo.part(body, ps, o, 1f, HeroGeo::lintangBelt);
        Helion3Geo.part(rightArm, ps, o, 1f, HeroGeo::lintangCuff);
        Helion3Geo.part(leftArm, ps, o, -1f, HeroGeo::lintangCuff);
        // pendar keemasan di atasnya (berdenyut pelan; lebih terang saat muatan penuh / membara)
        o.vc = buffers.getBuffer(RenderType.eyes(Draw.WHITE));
        Helion3Geo.tint(o, SUN_GOLD, (0.16f + 0.05f * Mth.sin(age * 0.2f) + 0.45f * Mth.clamp(glow, 0f, 1f)) * Math.min(1f, size));
        Helion3Geo.part(body, ps, o, 1f, HeroGeo::lintangBelt);
        Helion3Geo.part(rightArm, ps, o, 1f, HeroGeo::lintangCuff);
        Helion3Geo.part(leftArm, ps, o, -1f, HeroGeo::lintangCuff);
    }

    /** Lengan orang pertama Lintang: gelang cahayanya. */
    public static void lintangArm(ModelPart arm, boolean left, PoseStack ps, MultiBufferSource buffers, float glow, boolean slim,
                                  float age) {
        Helion3Geo.Out o = new Helion3Geo.Out();
        o.light = FULLBRIGHT;
        o.overlay = OverlayTexture.NO_OVERLAY;
        o.pulse = 1f + 0.03f * Mth.sin(age * 0.18f);
        o.bristle = slim ? 1.5f : 2f;
        o.vc = buffers.getBuffer(RenderType.entityCutoutNoCull(GOLD));
        o.r = 255;
        o.g = 255;
        o.b = 255;
        float sx = left ? -1f : 1f;
        Helion3Geo.part(arm, ps, o, sx, HeroGeo::lintangCuff);
        o.vc = buffers.getBuffer(RenderType.eyes(Draw.WHITE));
        Helion3Geo.tint(o, SUN_GOLD, 0.16f + 0.45f * Mth.clamp(glow, 0f, 1f));
        Helion3Geo.part(arm, ps, o, sx, HeroGeo::lintangCuff);
    }
}
