package com.shazammod.client.render;

import java.util.function.Consumer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.ShazamMod;
import com.shazammod.client.vfx.Draw;

import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * 0.49 Bentuk 3D Subjek Tiga (Helion-3), dipakai bersama oleh bosnya (Helion3Renderer) dan wujud pemainnya (Helion3Layer):
 * semua bagian menempel pada bagian badan model (ikut gerak & putarannya), dihitung titik demi titik tanpa memutar
 * PoseStack.
 *
 *   kepala  : sepasang tanduk melengkung ke belakang, tonjolan alis, taring bawah yang mencuat, rahang tulang, jengger duri
 *   badan   : sirip duri punggung (membesar saat jantungnya berdetak & saat mengamuk), duri belikat, tiga pasang rusuk
 *             tulang di dada, dan kristal inti dua warna di tulang dada yang berdenyut seperti jantung
 *   lengan  : karapas bahu berduri, duri siku, bilah tulang lengan bawah, tiga cakar melengkung + cakar jempol
 *   kaki    : pelat lutut berduri, duri betis, tiga cakar jari kaki
 *
 * Angka bentuk dalam piksel model (1/16 blok), di ruang bagian badannya. Lengan kiri = cermin lengan kanan.
 */
public final class Helion3Geo {
    public static final ResourceLocation BONE = ShazamMod.id("textures/entity/helion3/spike.png");
    private static final int FULLBRIGHT = 15728880;
    private static final int LIGHT_RGB = 0xFFE2A0;   // cahaya (sisi kanan tubuhnya)
    private static final int CRYON_RGB = 0x3CFF86;   // Cryon (sisi kiri)

    private Helion3Geo() {}

    /**
     * Detak jantung sel mati 0..1 (dua hentakan: "dug-dug"), dipakai buat denyut retakan, inti dada, dan duri.
     * fast = sedang mengamuk / bangkit (detaknya jauh lebih cepat).
     */
    public static float beat(float age, boolean fast) {
        float period = fast ? 11f : 30f;
        float ph = (age % period) / period;
        float a = (float) Math.exp(-ph * 9.0);
        float d = ph - 0.22f;
        float b = d < 0f ? 0f : (float) Math.exp(-d * 11.0) * 0.6f;
        return Mth.clamp(a + b, 0f, 1f);
    }

    /** Penampung satu lintasan gambar: tujuan titik, warna, dan pengubah bentuk yang sedang berlaku (dipakai juga HeroGeo). */
    static final class Out {
        VertexConsumer vc;
        PoseStack.Pose pose;
        int light, overlay, r, g, b;
        float sx = 1f;        // -1 = cermin (lengan / kaki kiri)
        float bristle = 1f;   // panjang duri (detak & amukan)
        float pulse = 1f;     // besar inti dada

        void v(float x, float y, float z, float u, float v, float nx, float ny, float nz) {
            vc.addVertex(pose, x * sx / 16f, y / 16f, z / 16f).setColor(r, g, b, 255).setUv(u, v).setOverlay(overlay)
                    .setLight(light).setNormal(pose, nx * sx, ny, nz);
        }

        /** Segi empat a-b-c-d; normalnya dipaksa menjauhi titik tengah bentuknya (mx,my,mz) supaya cahayanya benar. */
        void quad(float ax, float ay, float az, float bx, float by, float bz, float cx, float cy, float cz,
                  float dx, float dy, float dz, float mx, float my, float mz, float u0, float v0, float u1, float v1) {
            float e1x = bx - ax, e1y = by - ay, e1z = bz - az;
            float e2x = dx - ax, e2y = dy - ay, e2z = dz - az;
            if (e1x * e1x + e1y * e1y + e1z * e1z < 1.0E-8f) {   // segitiga (a = b, kutub kepompong): pakai sisi a-c
                e1x = cx - ax;
                e1y = cy - ay;
                e1z = cz - az;
            }
            if (e2x * e2x + e2y * e2y + e2z * e2z < 1.0E-8f) {   // segitiga (a = d): pakai sisi a-c
                e2x = cx - ax;
                e2y = cy - ay;
                e2z = cz - az;
            }
            float nx = e1y * e2z - e1z * e2y, ny = e1z * e2x - e1x * e2z, nz = e1x * e2y - e1y * e2x;
            float nl = Mth.sqrt(nx * nx + ny * ny + nz * nz) + 1.0E-6f;
            nx /= nl;
            ny /= nl;
            nz /= nl;
            float fx = (ax + bx + cx + dx) * 0.25f - mx, fy = (ay + by + cy + dy) * 0.25f - my, fz = (az + bz + cz + dz) * 0.25f - mz;
            boolean inward = nx * fx + ny * fy + nz * fz < 0f;
            if (inward) {
                nx = -nx;
                ny = -ny;
                nz = -nz;
            }
            // Urutan titiknya selalu dibuat berlawanan arah jarum jam dilihat dari luar (sama seperti kubus model vanilla):
            // lapisan cahaya (RenderType.eyes) membuang sisi belakang, jadi sisi yang urutannya terbalik tidak ikut menyala.
            // Cermin (sx = -1, lengan / kaki kiri) membalik arah putarnya sekali lagi.
            if (inward != (sx < 0f)) {
                v(ax, ay, az, u0, v1, nx, ny, nz);
                v(dx, dy, dz, u0, v0, nx, ny, nz);
                v(cx, cy, cz, u1, v0, nx, ny, nz);
                v(bx, by, bz, u1, v1, nx, ny, nz);
            } else {
                v(ax, ay, az, u0, v1, nx, ny, nz);
                v(bx, by, bz, u1, v1, nx, ny, nz);
                v(cx, cy, cz, u1, v0, nx, ny, nz);
                v(dx, dy, dz, u0, v0, nx, ny, nz);
            }
        }

        /**
         * Limas terpancung berpenampang persegi dari a (setengah lebar h0) ke b (h1; 0 = runcing). Tekstur: v0 di a, v1 di b
         * (tekstur tulang: 1 = pangkal gelap, 0 = ujung terang).
         */
        void prism(float ax, float ay, float az, float bx, float by, float bz, float h0, float h1, float v0, float v1, boolean cap) {
            float dx = bx - ax, dy = by - ay, dz = bz - az;
            float dl = Mth.sqrt(dx * dx + dy * dy + dz * dz);
            if (dl < 1.0E-4f) {
                return;
            }
            dx /= dl;
            dy /= dl;
            dz /= dl;
            // u = sumbu bantu x d, w = d x u
            float hx = Math.abs(dy) < 0.9f ? 0f : 1f, hy = Math.abs(dy) < 0.9f ? 1f : 0f;
            float ux = hy * dz, uy = -hx * dz, uz = hx * dy - hy * dx;
            float ul = Mth.sqrt(ux * ux + uy * uy + uz * uz) + 1.0E-6f;
            ux /= ul;
            uy /= ul;
            uz /= ul;
            float wx = dy * uz - dz * uy, wy = dz * ux - dx * uz, wz = dx * uy - dy * ux;
            float mx = (ax + bx) * 0.5f, my = (ay + by) * 0.5f, mz = (az + bz) * 0.5f;
            float[] px = new float[8], py = new float[8], pz = new float[8];
            for (int i = 0; i < 4; i++) {
                float su = (i == 0 || i == 3) ? -1f : 1f, sw = (i < 2) ? -1f : 1f;
                px[i] = ax + (ux * su + wx * sw) * h0;
                py[i] = ay + (uy * su + wy * sw) * h0;
                pz[i] = az + (uz * su + wz * sw) * h0;
                px[i + 4] = bx + (ux * su + wx * sw) * h1;
                py[i + 4] = by + (uy * su + wy * sw) * h1;
                pz[i + 4] = bz + (uz * su + wz * sw) * h1;
            }
            for (int i = 0; i < 4; i++) {
                int j = (i + 1) % 4;
                quad(px[i], py[i], pz[i], px[j], py[j], pz[j], px[j + 4], py[j + 4], pz[j + 4], px[i + 4], py[i + 4], pz[i + 4],
                        mx, my, mz, 0f, v1, 1f, v0);
            }
            if (cap && h1 > 0.02f) {
                quad(px[4], py[4], pz[4], px[5], py[5], pz[5], px[6], py[6], pz[6], px[7], py[7], pz[7], mx, my, mz, 0.2f, v1,
                        0.8f, Math.min(1f, v1 + 0.2f));
            }
        }

        /** Duri: limas runcing dari (x,y,z) searah (dx,dy,dz) sepanjang len (dikali bristle). */
        void spike(float x, float y, float z, float dx, float dy, float dz, float len, float half) {
            float dl = Mth.sqrt(dx * dx + dy * dy + dz * dz) + 1.0E-6f;
            float l = len * bristle / dl;
            prism(x, y, z, x + dx * l, y + dy * l, z + dz * l, half, 0f, 1f, 0f, false);
        }

        /** Balok miring: pusat c dengan tiga setengah-sumbu u, v, w. */
        void slab(float cx, float cy, float cz, float ux, float uy, float uz, float vx, float vy, float vz,
                  float wx, float wy, float wz) {
            float[] px = new float[8], py = new float[8], pz = new float[8];
            for (int i = 0; i < 8; i++) {
                float su = (i & 1) == 0 ? -1f : 1f, sv = (i & 2) == 0 ? -1f : 1f, sw = (i & 4) == 0 ? -1f : 1f;
                px[i] = cx + ux * su + vx * sv + wx * sw;
                py[i] = cy + uy * su + vy * sv + wy * sw;
                pz[i] = cz + uz * su + vz * sv + wz * sw;
            }
            int[][] faces = {{0, 1, 3, 2}, {4, 5, 7, 6}, {0, 1, 5, 4}, {2, 3, 7, 6}, {0, 2, 6, 4}, {1, 3, 7, 5}};
            for (int[] f : faces) {
                quad(px[f[0]], py[f[0]], pz[f[0]], px[f[1]], py[f[1]], pz[f[1]], px[f[2]], py[f[2]], pz[f[2]],
                        px[f[3]], py[f[3]], pz[f[3]], cx, cy, cz, 0f, 0.45f, 1f, 1f);
            }
        }

        /** Tanduk / cakar melengkung: kurva Bezier kuadrat p0 -> p1 -> p2, jari-jari r0 di pangkal mengecil sampai runcing. */
        void curve(float x0, float y0, float z0, float x1, float y1, float z1, float x2, float y2, float z2, float r0, int n) {
            float lx = x0, ly = y0, lz = z0;
            for (int i = 1; i <= n; i++) {
                float t = i / (float) n, s = 1f - t;
                float x = s * s * x0 + 2f * s * t * x1 + t * t * x2;
                float y = s * s * y0 + 2f * s * t * y1 + t * t * y2;
                float z = s * s * z0 + 2f * s * t * z1 + t * t * z2;
                float ta = (i - 1) / (float) n;
                prism(lx, ly, lz, x, y, z, r0 * (1f - ta * 0.85f), i == n ? 0f : r0 * (1f - t * 0.85f), 1f - ta, 1f - t, false);
                lx = x;
                ly = y;
                lz = z;
            }
        }

        /** Kristal oktahedron (inti dada). */
        void gem(float cx, float cy, float cz, float rx, float ry, float rz) {
            float[][] eq = {{cx - rx, cy, cz}, {cx, cy, cz - rz}, {cx + rx, cy, cz}, {cx, cy, cz + rz}};
            for (int i = 0; i < 4; i++) {
                float[] a = eq[i], b = eq[(i + 1) % 4];
                quad(a[0], a[1], a[2], b[0], b[1], b[2], cx, cy - ry, cz, cx, cy - ry, cz, cx, cy, cz, 0f, 0f, 1f, 0.5f);
                quad(a[0], a[1], a[2], b[0], b[1], b[2], cx, cy + ry, cz, cx, cy + ry, cz, cx, cy, cz, 0f, 0f, 1f, 0.5f);
            }
        }
    }

    // ------------------------------------------------------------------ bentuk tiap bagian badan

    /** Kepala (kubus -4..4, -8..0, -4..4; muka di z = -4). */
    private static void head(Out o) {
        for (int s = -1; s <= 1; s += 2) {
            // tanduk: keluar dari pelipis, naik, lalu melengkung ke belakang
            o.curve(3.7f * s, -6.4f, -0.8f, 7.2f * s, -8.2f, -0.6f, 5.6f * s, -12.0f, 3.4f, 1.15f, 5);
            // taring bawah yang mencuat keluar dari sudut rahang
            o.curve(2.5f * s, -0.9f, -4.0f, 3.1f * s, -1.4f, -5.7f, 2.7f * s, -3.9f, -5.3f, 0.5f, 3);
            // duri pipi
            o.spike(4.0f * s, -2.6f, -1.4f, 1f * s, 0.25f, 0.5f, 1.8f, 0.55f);
        }
        // tonjolan alis & rahang tulang
        o.slab(0f, -5.15f, -4.25f, 3.7f, 0f, 0f, 0f, 0.55f, 0.18f, 0f, -0.2f, 0.6f);
        o.slab(0f, -0.55f, -4.15f, 2.9f, 0f, 0f, 0f, 0.6f, 0f, 0f, 0f, 0.55f);
        // jengger duri dari dahi ke tengkuk
        o.spike(0f, -8.0f, -2.4f, 0f, -1f, 0.15f, 2.0f, 0.75f);
        o.spike(0f, -8.0f, -0.3f, 0f, -1f, 0.35f, 2.9f, 0.9f);
        o.spike(0f, -8.0f, 1.9f, 0f, -1f, 0.6f, 2.6f, 0.85f);
        o.spike(0f, -6.6f, 4.0f, 0f, -0.6f, 1f, 2.0f, 0.75f);
        o.spike(-1.9f, -7.9f, 0.9f, -0.35f, -1f, 0.5f, 1.9f, 0.7f);
        o.spike(1.9f, -7.9f, 0.9f, 0.35f, -1f, 0.5f, 1.9f, 0.7f);
    }

    /** Badan (kubus -4..4, 0..12, -2..2; dada di z = -2, punggung di z = +2). */
    private static void body(Out o) {
        // sirip duri punggung: paling besar di antara belikat, mengecil ke pinggang
        float[][] spine = {{1.2f, 5.6f, 1.45f}, {3.3f, 5.0f, 1.35f}, {5.4f, 4.2f, 1.2f}, {7.5f, 3.4f, 1.05f}, {9.6f, 2.6f, 0.9f}};
        for (float[] s : spine) {
            o.spike(0f, s[0], 2.0f, 0f, -0.5f, 1f, s[1], s[2]);
        }
        for (int s = -1; s <= 1; s += 2) {
            o.spike(2.7f * s, 2.3f, 2.0f, 0.45f * s, -0.65f, 1f, 3.6f, 1.1f);     // belikat
            o.spike(3.3f * s, 4.6f, 2.0f, 0.6f * s, -0.4f, 1f, 2.6f, 0.9f);
            o.spike(2.2f * s, 7.2f, 2.0f, 0.4f * s, -0.3f, 1f, 1.9f, 0.75f);
            // tiga pasang rusuk tulang di dada, dari tulang dada melengkung ke rusuk samping
            for (int k = 0; k < 3; k++) {
                float y = 4.9f + k * 1.75f;
                o.prism(0.95f * s, y, -2.35f, 3.95f * s, y + 0.75f, -1.85f, 0.42f, 0.28f, 0.95f, 0.35f, true);
            }
            // tulang selangka
            o.prism(0.6f * s, 0.9f, -2.3f, 3.9f * s, 0.35f, -1.6f, 0.4f, 0.3f, 0.9f, 0.4f, true);
            // duri pinggul
            o.spike(4.0f * s, 10.4f, 0.4f, 1f * s, -0.35f, 0.4f, 1.7f, 0.6f);
        }
    }

    /** Kristal inti di tulang dada (digambar dua kali: badan gelapnya, lalu cahayanya). */
    private static void core(Out o) {
        float k = o.pulse;
        o.gem(0f, 3.0f, -2.3f, 1.25f * k, 1.6f * k, 0.75f * k);
    }

    /** Lengan kanan (kubus -3..1, -2..10, -2..2; sisi luar di x = -3). Lengan kiri: cermin. */
    private static void arm(Out o) {
        // karapas bahu: pelat tulang tebal yang miring naik ke luar, dengan tiga duri
        o.slab(-1.25f, -2.75f, 0f, 2.55f, -0.55f, 0f, 0.2f, 0.75f, 0f, 0f, 0f, 2.65f);
        o.spike(-1.4f, -3.3f, -1.1f, -0.35f, -1f, -0.15f, 3.4f, 1.05f);
        o.spike(-2.2f, -3.5f, 1.0f, -0.5f, -1f, 0.25f, 3.9f, 1.15f);
        o.spike(-3.6f, -2.2f, 0f, -1f, -0.55f, 0f, 3.0f, 1.0f);
        // duri siku & bilah tulang lengan bawah
        o.spike(-2.6f, 4.4f, 1.7f, -0.5f, -0.25f, 1f, 2.8f, 0.8f);
        o.slab(-3.3f, 7.3f, 0f, 0.42f, 0f, 0f, 0f, 2.1f, 0f, 0f, 0f, 1.25f);
        o.spike(-3.5f, 5.6f, 0.2f, -1f, -0.35f, 0.3f, 2.3f, 0.75f);
        o.spike(-3.5f, 8.2f, -0.2f, -1f, 0.1f, 0.3f, 2.0f, 0.7f);
        // buku jari
        o.slab(-1f, 9.75f, -2.2f, 1.7f, 0f, 0f, 0f, 0.55f, 0f, 0f, 0f, 0.4f);
    }

    /** Tiga cakar melengkung + cakar jempol di ujung lengan kanan. */
    private static void claws(Out o) {
        for (int i = 0; i < 3; i++) {
            float z = -1.35f + 1.35f * i;
            o.curve(-1.3f, 9.8f, z, -2.1f, 12.5f, z * 1.1f, -0.1f, 13.9f * (0.94f + 0.03f * (i == 1 ? 2 : 1)), z * 1.25f, 0.62f, 4);
        }
        o.curve(0.5f, 8.9f, -1.7f, 1.2f, 10.4f, -2.8f, 0.4f, 12.0f, -2.5f, 0.5f, 3);
    }

    /** Kaki (kubus -2..2, 0..12, -2..2; lutut di depan z = -2). */
    private static void leg(Out o) {
        o.slab(0f, 5.2f, -2.3f, 1.55f, 0f, 0f, 0f, 1.0f, 0.1f, 0f, -0.1f, 0.42f);       // pelat lutut
        o.spike(0f, 4.5f, -2.5f, 0f, -0.55f, -1f, 2.2f, 0.75f);
        o.spike(0f, 7.0f, 2.0f, 0f, 0.35f, 1f, 2.6f, 0.9f);                              // duri betis
        o.spike(-2.1f, 8.6f, 0.4f, -1f, 0.2f, 0.3f, 1.5f, 0.55f);
        for (int i = -1; i <= 1; i++) {                                                   // cakar jari kaki
            o.spike(1.25f * i, 11.55f, -2.0f, 0.12f * i, 0.22f, -1f, 1.7f, 0.5f);
        }
    }

    // ------------------------------------------------------------------ gambar

    static void part(ModelPart part, PoseStack ps, Out o, float sx, Consumer<Out> shape) {
        if (part == null || !part.visible) {
            return;
        }
        ps.pushPose();
        part.translateAndRotate(ps);
        o.pose = ps.last();
        o.sx = sx;
        shape.accept(o);
        ps.popPose();
        o.sx = 1f;
    }

    static void tint(Out o, int rgb, float k) {
        k = Mth.clamp(k, 0f, 1f);
        o.r = (int) (((rgb >> 16) & 255) * k);
        o.g = (int) (((rgb >> 8) & 255) * k);
        o.b = (int) ((rgb & 255) * k);
    }

    /**
     * Semua bagian 3D di badan.
     *
     * @param claw 0..1 cakar & tulang yang menguat oleh Cryon (menghijau & menyala)
     * @param rage 0..1 sedang mengamuk (duri berdiri, tulang membara)
     * @param beat 0..1 detak jantung (lihat beat())
     */
    public static void render(ModelPart head, ModelPart body, ModelPart rightArm, ModelPart leftArm, ModelPart rightLeg,
                              ModelPart leftLeg, PoseStack ps, MultiBufferSource buffers, int light, int overlay,
                              float claw, float rage, float beat) {
        claw = Mth.clamp(claw, 0f, 1f);
        rage = Mth.clamp(rage, 0f, 1f);
        Out o = new Out();
        o.light = light;
        o.overlay = overlay;
        o.bristle = 1f + 0.1f * beat + 0.4f * rage;
        o.pulse = 1f + 0.16f * beat + 0.2f * rage;
        // 1) tulang (ikut cahaya dunia & memerah saat terluka); menghijau oleh Cryon, memerah saat mengamuk
        o.vc = buffers.getBuffer(RenderType.entityCutoutNoCull(BONE));
        o.r = (int) Mth.lerp(claw, 255f, 176f);
        o.g = (int) Mth.lerp(rage, 255f, 205f);
        o.b = (int) Mth.lerp(Math.max(claw * 0.8f, rage), 255f, 186f);
        part(head, ps, o, 1f, Helion3Geo::head);
        part(body, ps, o, 1f, Helion3Geo::body);
        part(rightArm, ps, o, 1f, Helion3Geo::arm);
        part(leftArm, ps, o, -1f, Helion3Geo::arm);
        part(rightArm, ps, o, 1f, Helion3Geo::claws);
        part(leftArm, ps, o, -1f, Helion3Geo::claws);
        part(rightLeg, ps, o, 1f, Helion3Geo::leg);
        part(leftLeg, ps, o, -1f, Helion3Geo::leg);
        // badan kristal intinya gelap; cahayanya di lintasan berikut
        o.r = 70;
        o.g = 64;
        o.b = 60;
        part(body, ps, o, 1f, Helion3Geo::core);
        // 2) cahaya (aditif, terang sendiri): inti dada berdenyut dua warna, cakar Cryon, tulang membara saat mengamuk
        o.vc = buffers.getBuffer(RenderType.eyes(Draw.WHITE));
        o.light = FULLBRIGHT;
        o.overlay = OverlayTexture.NO_OVERLAY;
        int coreRgb = Draw.mix(LIGHT_RGB, CRYON_RGB, Mth.clamp(0.5f + 0.5f * Mth.sin(beat * 3.1f) + claw * 0.5f, 0f, 1f));
        tint(o, rage > 0.01f ? Draw.mix(coreRgb, 0xFF5030, rage * 0.7f) : coreRgb, 0.45f + 0.55f * beat + 0.3f * rage);
        part(body, ps, o, 1f, Helion3Geo::core);
        if (claw > 0.01f) {
            tint(o, CRYON_RGB, claw * (0.55f + 0.25f * beat));
            part(rightArm, ps, o, 1f, Helion3Geo::claws);
            part(leftArm, ps, o, -1f, Helion3Geo::claws);
        }
        if (rage > 0.01f) {
            tint(o, 0xFF4020, rage * (0.22f + 0.2f * beat));
            part(head, ps, o, 1f, Helion3Geo::head);
            part(body, ps, o, 1f, Helion3Geo::body);
            if (claw <= 0.01f) {
                part(rightArm, ps, o, 1f, Helion3Geo::claws);
                part(leftArm, ps, o, -1f, Helion3Geo::claws);
            }
        }
    }

    /** Lengan orang pertama: karapas, bilah tulang, dan cakar di satu lengan (posisi lengannya sudah diatur pemanggil). */
    public static void renderArm(ModelPart arm, boolean left, PoseStack ps, MultiBufferSource buffers, int light,
                                 float claw, float rage, float beat) {
        claw = Mth.clamp(claw, 0f, 1f);
        rage = Mth.clamp(rage, 0f, 1f);
        Out o = new Out();
        o.light = light;
        o.overlay = OverlayTexture.NO_OVERLAY;
        o.bristle = 1f + 0.1f * beat + 0.4f * rage;
        o.vc = buffers.getBuffer(RenderType.entityCutoutNoCull(BONE));
        o.r = (int) Mth.lerp(claw, 255f, 176f);
        o.g = (int) Mth.lerp(rage, 255f, 205f);
        o.b = (int) Mth.lerp(Math.max(claw * 0.8f, rage), 255f, 186f);
        float sx = left ? -1f : 1f;
        part(arm, ps, o, sx, Helion3Geo::arm);
        part(arm, ps, o, sx, Helion3Geo::claws);
        if (claw > 0.01f || rage > 0.01f) {
            o.vc = buffers.getBuffer(RenderType.eyes(Draw.WHITE));
            o.light = FULLBRIGHT;
            if (claw > 0.01f) {
                tint(o, CRYON_RGB, claw * (0.55f + 0.25f * beat));
            } else {
                tint(o, 0xFF4020, rage * (0.22f + 0.2f * beat));
            }
            part(arm, ps, o, sx, Helion3Geo::claws);
        }
    }

    // ------------------------------------------------------------------ bentuk lepas di dunia (dipakai efek)

    /**
     * Duri tulang yang tumbuh dari tanah (Onak Tulang, hantaman): pose sudah digeser ke pangkalnya, satuan blok.
     * Arah (dx,dy,dz) nggak perlu satuan.
     */
    public static void worldSpike(PoseStack.Pose pose, VertexConsumer vc, int light, float dx, float dy, float dz, float len,
                                  float half, int r, int g, int b) {
        if (len <= 0.01f) {
            return;
        }
        Out o = new Out();
        o.vc = vc;
        o.pose = pose;
        o.light = light;
        o.overlay = OverlayTexture.NO_OVERLAY;
        o.r = r;
        o.g = g;
        o.b = b;
        float dl = Mth.sqrt(dx * dx + dy * dy + dz * dz) + 1.0E-6f;
        float l = len * 16f / dl;
        // pangkal sedikit di bawah tanah supaya nggak terlihat melayang di tanah miring
        o.prism(-dx * 0.2f * 16f / dl, -dy * 0.2f * 16f / dl, -dz * 0.2f * 16f / dl, dx * l, dy * l, dz * l, half * 16f, 0f, 1f, 0f,
                false);
    }

    private static float hash(int a, int b, int seed) {
        int h = a * 374761393 + b * 668265263 + seed * 1274126177;
        h = (h ^ (h >>> 13)) * 1274126177;
        h ^= h >>> 16;
        return (h & 0xFFFF) / 65535f;
    }

    /**
     * Kepompong sel mati: bola lonjong berbenjol-benjol (benjolannya dari seed, berdenyut dengan pulse 0..1). Pose sudah
     * digeser ke pusatnya, jari-jari dalam blok.
     */
    public static void worldBlob(PoseStack.Pose pose, VertexConsumer vc, int light, float rx, float ry, float rz, int seed,
                                 float pulse, int r, int g, int b) {
        if (rx <= 0.01f || ry <= 0.01f) {
            return;
        }
        Out o = new Out();
        o.vc = vc;
        o.pose = pose;
        o.light = light;
        o.overlay = OverlayTexture.NO_OVERLAY;
        o.r = r;
        o.g = g;
        o.b = b;
        final int rings = 9, segs = 12;
        float[][] px = new float[rings + 1][segs], py = new float[rings + 1][segs], pz = new float[rings + 1][segs];
        for (int i = 0; i <= rings; i++) {
            float lat = (float) Math.PI * i / rings;
            float sl = Mth.sin(lat), cl = Mth.cos(lat);
            for (int j = 0; j < segs; j++) {
                float lon = (float) (Math.PI * 2.0) * j / segs;
                float lump = i == 0 || i == rings ? 1f
                        : 0.9f + 0.2f * hash(i, j, seed) + 0.06f * pulse * hash(j, i, seed + 7);
                px[i][j] = Mth.cos(lon) * sl * rx * lump * 16f;
                py[i][j] = -cl * ry * (0.96f + 0.08f * hash(i, 31, seed)) * 16f;
                pz[i][j] = Mth.sin(lon) * sl * rz * lump * 16f;
            }
        }
        for (int i = 0; i < rings; i++) {
            float v0 = i / (float) rings, v1 = (i + 1) / (float) rings;
            for (int j = 0; j < segs; j++) {
                int k = (j + 1) % segs;
                o.quad(px[i][j], py[i][j], pz[i][j], px[i][k], py[i][k], pz[i][k], px[i + 1][k], py[i + 1][k], pz[i + 1][k],
                        px[i + 1][j], py[i + 1][j], pz[i + 1][j], 0f, 0f, 0f, 0f, 0.35f + 0.6f * v0, 1f, 0.35f + 0.6f * v1);
            }
        }
    }
}
