package com.shazammod;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

/**
 * 0.49 Inkubasi Subjek Tiga: Sel Subjek Tiga (gumpalan sel mati dari Subjek Tiga yang dikalahkan) digenggam dalam wujud
 * manusia. Sel mati itu merayap masuk lewat kulit (urat menghitam), membungkus seluruh tubuh jadi kepompong, jantung di
 * dalamnya berdetak makin keras, lalu kepompongnya pecah: tubuhmu sekarang bisa berubah jadi Subjek Tiga.
 * Nggak ada syarat tempat (sel mati hidup di mana saja), tapi selama inkubasi kamu nggak bisa apa-apa.
 */
public final class Helion3Rite {
    public static final int INFECT = 40;      // sel mati menjalar
    public static final int COCOON = 80;      // kepompong menutup
    public static final int EMERGE = ShazamAnim.SUBJEK_RITE_STRIKE;
    public static final int LENGTH = ShazamAnim.SUBJEK_RITE_TICKS;

    private static final Map<UUID, Long> RITES = new HashMap<>();
    private static final Set<UUID> FORCED = new HashSet<>();

    private Helion3Rite() {}

    public static boolean isAwakening(ServerPlayer p) {
        Long t = RITES.get(p.getUUID());
        return t != null && p.level().getGameTime() - t <= LENGTH + 4;
    }

    public static void tryBegin(ServerPlayer p) {
        ShazamData d = ShazamPowers.data(p);
        String err = null;
        if (isAwakening(p) || LintangRite.isAwakening(p) || HelionRite.isAwakening(p)) {
            err = "message.shazammod.subjek_rite.already";
        } else if (d.helion3Unlocked()) {
            err = "message.shazammod.subjek_rite.already_yours";
        } else if (d.transformed()) {
            err = "message.shazammod.subjek_rite.human_only";
        } else if (KahndaqTrial.isRunning(p) || ShazamTotems.isAwakening(p) || SabbacPact.isAwakening(p)) {
            err = "message.shazammod.subjek_rite.busy";
        }
        if (err != null) {
            p.displayClientMessage(Component.translatable(err).withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.ITALIC), true);
            return;
        }
        begin(p, false);
    }

    public static void begin(ServerPlayer p, boolean forced) {
        if (isAwakening(p)) {
            return;
        }
        UUID id = p.getUUID();
        if (forced) {
            FORCED.add(id);
        } else {
            FORCED.remove(id);
        }
        if (ShazamPowers.isTransformed(p)) {
            ShazamPowers.revert(p, false);
        }
        final long start = p.serverLevel().getGameTime();
        RITES.put(id, start);
        ShazamNetwork.playAnim(p, ShazamAnim.SUBJEK_RITE);
        sound(p, ShazamSounds.HELION3_ADAPT.get(), 1.6f, 0.7f);
        log(p, "message.shazammod.subjek_lab.start", ChatFormatting.LIGHT_PURPLE);
        for (int t = 6; t < EMERGE; t += 6) {
            final int tick = t;
            ShazamPowers.schedule(p, t, sp -> progress(sp, start, tick));
        }
        for (int t = 10; t < EMERGE - 12; t += t < COCOON ? 20 : 10) {   // jantung di dalam kepompong: makin cepat
            final float pitch = t < COCOON ? 0.8f : 1.0f;
            ShazamPowers.schedule(p, t, sp -> {
                if (active(sp, start)) {
                    sound(sp, ShazamSounds.HEARTBEAT.get(), 1.4f, ShazamSounds.tune(pitch));
                }
            });
        }
        ShazamPowers.schedule(p, INFECT, sp -> {
            if (active(sp, start)) {
                log(sp, "message.shazammod.subjek_lab.cocoon", ChatFormatting.DARK_PURPLE);
            }
        });
        ShazamPowers.schedule(p, COCOON, sp -> {
            if (active(sp, start)) {
                log(sp, "message.shazammod.subjek_lab.heart", ChatFormatting.RED);
            }
        });
        // suara bangkit bosnya meledak di tick 62: dimulai lebih dulu supaya ledakannya pas dengan kepompong pecah
        ShazamPowers.schedule(p, Math.max(0, EMERGE - 62), sp -> {
            if (active(sp, start)) {
                sound(sp, ShazamSounds.HELION3_REVIVE.get(), 2.4f, 1f);
            }
        });
        ShazamPowers.schedule(p, EMERGE, sp -> finish(sp, start));
    }

    private static boolean active(ServerPlayer p, long start) {
        Long t = RITES.get(p.getUUID());
        return t != null && t.longValue() == start;
    }

    private static void progress(ServerPlayer p, long start, int tick) {
        if (!active(p, start)) {
            return;
        }
        String stage;
        float frac;
        if (tick < INFECT) {
            stage = "message.shazammod.subjek_lab.stage.infect";
            frac = tick / (float) INFECT;
        } else if (tick < COCOON) {
            stage = "message.shazammod.subjek_lab.stage.cocoon";
            frac = (tick - INFECT) / (float) (COCOON - INFECT);
        } else {
            stage = "message.shazammod.subjek_lab.stage.emerge";
            frac = (tick - COCOON) / (float) (EMERGE - COCOON);
        }
        int pct = Math.max(1, Math.min(100, Math.round(frac * 100f)));
        int full = Math.min(10, pct / 10);
        StringBuilder bar = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            bar.append(i < full ? '▮' : '▯');
        }
        ChatFormatting c = tick < INFECT ? ChatFormatting.LIGHT_PURPLE : tick < COCOON ? ChatFormatting.DARK_PURPLE : ChatFormatting.RED;
        p.displayClientMessage(Component.translatable("message.shazammod.subjek_lab.bar",
                Component.translatable(stage), bar.toString(), String.valueOf(pct)).withStyle(c), true);
    }

    private static void finish(ServerPlayer p, long start) {
        if (!active(p, start)) {
            return;
        }
        UUID id = p.getUUID();
        RITES.remove(id);
        boolean forced = FORCED.remove(id);
        if (ShazamPowers.data(p).helion3Unlocked()) {
            return;
        }
        if (!forced && !consumeCell(p)) {
            p.displayClientMessage(Component.translatable("message.shazammod.subjek_rite.no_cell").withStyle(ChatFormatting.GRAY), true);
            return;
        }
        log(p, "message.shazammod.subjek_lab.done", ChatFormatting.LIGHT_PURPLE);
        ShazamPowers.unlockHelion3(p);
    }

    private static boolean consumeCell(ServerPlayer p) {
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (!s.isEmpty() && s.is(HelionItems.CELL.get())) {
                s.shrink(1);
                return true;
            }
        }
        return false;
    }

    private static void log(ServerPlayer p, String key, ChatFormatting color) {
        p.sendSystemMessage(Component.translatable("message.shazammod.subjek_lab.prefix").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD)
                .append(Component.literal(" "))
                .append(Component.translatable(key).withStyle(color)));
    }

    private static void sound(ServerPlayer p, SoundEvent sound, float volume, float pitch) {
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), sound, SoundSource.PLAYERS, volume, pitch);
    }

    public static void forget(UUID id) {
        RITES.remove(id);
        FORCED.remove(id);
    }
}
