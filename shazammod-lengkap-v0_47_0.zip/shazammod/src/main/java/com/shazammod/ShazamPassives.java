package com.shazammod;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Pasif khas Shazam (0.23). Black Adam itu tank yang buas (kulitnya memantulkan proyektil, kekuatannya dari matahari);
 * Shazam pahlawan yang lincah, dilindungi para dewa, dan kekuatannya dari badai:
 *
 * Muatan Petir          : memukul, dipukul, terbang kencang, berlari dengan Mode Kilat, dan berdiri di bawah hujan atau badai
 *                         mengisi listrik di badan. Penuh = kepalan menyala dan pukulan berikutnya jadi Pukulan Guntur
 *                         (petir dari langit, damage x1,75, hempasan jauh, petir merambat ke 3 musuh lain).
 * Refleks Mercury       : sekali tiap 1,8 detik (0.25; dulu 8 detik), satu serangan (pukulan, panah, bola api) dihindari dengan
 *                         kedipan secepat kilat.
 * Hati Pahlawan         : villager, hewan peliharaan, atau pemain lain diserang monster di dekat Shazam: penyerangnya ditandai
 *                         (bersinar, +25% damage dari Shazam) dan Shazam dapat Amarah Pahlawan (pukulan +25% selama 8 detik).
 * Keluarga Shazam       : sekutu (pemain lain, villager, hewan peliharaan) dalam 10 blok dapat Resistance I.
 *
 * 0.28 BLACK ADAM SETARA SHAZAM, 0.28.1 KEKUATANNYA DARI MATAHARI ATON (bukan petir): Black Adam dapat padanan semua pasif
 * di atas dengan angka yang sama persis, tapi bersumber dari matahari:
 * - Cakram Aton (padanan Penangkal Petir Hidup): cakram matahari melayang di atas kepalanya; tiap 2 detik sinar-sinarnya
 *   yang berujung tangan (lambang Aten Mesir) menyentuh badannya dan cakramnya menyembur cahaya & api matahari.
 * - Muatan Surya (padanan Muatan Petir, terisi 2x di bawah matahari) dan Tinju Aton (padanan Pukulan Guntur): sasaran terbakar
 *   dan terhempas, semburan api matahari membakar sampai 3 musuh lain.
 * - Tangkisan Kahndaq (padanan Refleks Mercury): Black Adam nggak menghindar tapi MENAHAN; penyerangnya dibakar balik.
 * Petir alam tetap cuma bikin Black Adam kebal (nggak diserap).
 *
 * 0.30 SABBAC, JUARA ENAM IBLIS: padanan semuanya dengan angka yang sama, tapi bersumber dari api neraka:
 * - Api Neraka (padanan Penangkal Petir Hidup): tiap 2 detik tanah di bawah kaki retak membara dan api & petir neraka
 *   menyembur NAIK menelan badannya. Padam di bawah matahari dan di dalam air; paling kuat di Nether (ikut membakar monster
 *   di sekitar).
 * - Muatan Neraka (terisi 2x saat malam, di Nether, dan di End) dan Tinju Neraka (padanan Pukulan Guntur): sasaran terbakar
 *   dan terhempas, rantai neraka menyambar sampai 3 musuh lain dan menyeret mereka ke sasaran.
 * - Kulit Bara (padanan Refleks Mercury): serangan ditelan bara (0 damage), penyerangnya terbakar dan terseret mendekat.
 * - Amarah Iblis (padanan Hati Pahlawan): siapa pun yang berani menyentuh milik Sabbac ditandai api neraka.
 *
 * Penangkal Petir Hidup : (0.25) tiap 2 detik petir sihir turun dari langit menyambar dada Shazam, di mana pun (siang,
 *                         malam, di dalam ruangan). Tiap sambaran: Energi Petir pulih, darah pulih, armor yang dipakai pulih,
 *                         Perisai Petir (hati emas) terisi lagi, dan Muatan Petir penuh, jadi pukulan berikutnya Pukulan Guntur.
 *                         Petir alam atau trisula Channeling yang menyambar Shazam juga diserap (lebih besar: +150 energi,
 *                         +40 darah) dan menggantikan sambaran berikutnya.
 */
public final class ShazamPassives {
    private ShazamPassives() {}

    // ================= Angka-angka yang gampang diutak-atik =================
    public static final float MAX_CHARGE = 100f;
    public static final float CHARGE_PER_HIT = 9f;            // tiap pukulan tangan kosong ke musuh
    private static final float CHARGE_PER_HURT = 4f;          // tiap kena serangan
    private static final float CHARGE_FLIGHT = 0.3f;          // per tick, dikali kecepatan terbang di atas 0,5 blok/tick
    private static final float CHARGE_MERCURY = 0.35f;        // per tick selama berlari dengan Mode Kilat Mercury
    private static final float CHARGE_STORM = 0.3f;           // per tick di bawah badai petir
    private static final float RAIN_MULTIPLIER = 2f;          // kehujanan: semua muatan masuk 2x
    public static final float THUNDER_PUNCH_MULTIPLIER = 1.75f;
    private static final float THUNDER_CHAIN_DAMAGE = 14f;
    private static final double THUNDER_CHAIN_RADIUS = 7.0;
    private static final int THUNDER_CHAIN_TARGETS = 3;
    private static final double THUNDER_KNOCKBACK = 1.8;
    public static final int DODGE_COOLDOWN_TICKS = 36;        // Refleks Mercury: sekali tiap 1,8 detik (dulu 160 = 8 detik)
    private static final double DODGE_SPEED = 1.15;           // kecepatan mengelak ke samping (blok/tick)
    // 0.28 Black Adam: Tangkisan Kahndaq (jedanya sama dengan Refleks Mercury: DODGE_COOLDOWN_TICKS)
    private static final float BLOCK_SHOCK_DAMAGE = 10f;      // penyerang dibakar balik panas matahari segini
    private static final float BLOCK_FIRE_SECONDS = 3f;       // ... dan terbakar selama ini
    private static final double BLOCK_KNOCKBACK = 1.2;
    private static final float SUN_FIRE_SECONDS = 4f;         // 0.28.1 Tinju Aton: sasaran terbakar selama ini
    // 0.30 Sabbac: Kulit Bara (jedanya sama: DODGE_COOLDOWN_TICKS) & Tinju Neraka
    private static final float ENGULF_BURN_DAMAGE = 10f;      // penyerang dibakar balik api neraka segini
    private static final float ENGULF_FIRE_SECONDS = 3f;
    private static final double ENGULF_PULL = 1.0;            // ... lalu terseret rantai ke arah Sabbac
    private static final float HELL_FIRE_SECONDS = 4f;        // Tinju Neraka: sasaran terbakar selama ini
    private static final double HELL_CHAIN_PULL = 0.9;        // musuh lain terseret rantai ke sasaran
    private static final float INFERNO_SPLASH_DAMAGE = 8f;    // Nether: Api Neraka ikut membakar monster di sekitar
    private static final double INFERNO_SPLASH_RADIUS = 4.5;
    // 0.29: pasif tiap 2 detik padam di tempat/waktu tertentu (aturannya di PassiveConditions)
    private static final int STATE_HOLD = 20;                 // keadaan baru harus bertahan 1 detik dulu (nggak berkedip di batas biome)
    private static final int SUNRISE_DELAY = 20;              // Black Adam: denyut pertama 1 detik sesudah cakram terbit
    // 0.32 Lintang: Tepisan Beku (jedanya sama: DODGE_COOLDOWN_TICKS)
    private static final float PARRY_DAMAGE = 6f;
    private static final double PARRY_COUNTER_RANGE = 6.0;  // 0.35 Refleks Kilat: penyerang sejauh ini dibalas pukulan
    private static final double HERO_RADIUS = 24.0;
    private static final int HERO_TICKS = 160;                // Amarah Pahlawan: 8 detik
    public static final float HERO_MULTIPLIER = 1.25f;
    private static final int HERO_GAP = 40;                   // paling sering tiap 2 detik
    private static final double FAMILY_RADIUS = 10.0;
    private static final int ABSORB_GAP = 30;                 // satu sambaran petir cuma dihitung sekali
    private static final float ABSORB_ENERGY = 150f;
    private static final float ABSORB_HEAL = 40f;
    // Penangkal Petir Hidup (0.25): petir sihir menyambar Shazam tiap 2 detik
    public static final int ROD_INTERVAL_TICKS = 40;          // tiap 2 detik sekali (20 tick = 1 detik)
    private static final float ROD_ENERGY = 100f;             // Energi Petir yang pulih tiap sambaran (penuh 1000)
    private static final float ROD_HEAL = 40f;                // darah yang pulih tiap sambaran (penuh 300)
    private static final float ROD_ARMOR_REPAIR = 1.0f;       // armor yang dipakai: bagian durability yang pulih (1 = penuh, 0 = mati)
    private static final float ROD_SHIELD = 20f;              // Perisai Petir: hati emas diisi lagi sampai segini (20 = 10 hati, 0 = mati)
    private static final float ROD_SPLASH_DAMAGE = 0f;        // > 0: sambarannya ikut melukai monster di sekitar (pemain & sekutu aman)
    private static final double ROD_SPLASH_RADIUS = 3.5;
    private static final float ROD_VOLUME = 1.5f;             // keras suara sambaran (terdengar sampai ±16 blok x angka ini)
    // =========================================================================

    private static final ResourceLocation ROD_SHIELD_ID = ShazamMod.id("rod_shield");
    private static final EquipmentSlot[] ARMOR_SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS,
            EquipmentSlot.FEET};

    private static final Map<UUID, Float> CHARGE = new HashMap<>();
    private static final Map<UUID, Long> DODGE_READY = new HashMap<>();
    private static final Map<UUID, Long> HERO_UNTIL = new HashMap<>();
    private static final Map<UUID, Long> HERO_NEXT = new HashMap<>();
    private static final Map<UUID, Long> ABSORB_NEXT = new HashMap<>();
    private static final Map<UUID, Long> ROD_NEXT = new HashMap<>();
    private static final Map<UUID, Boolean> PASSIVE_ON = new HashMap<>();      // 0.29: pasif tiap 2 detik sedang menyala?
    private static final Map<UUID, Integer> PASSIVE_PENDING = new HashMap<>();

    /** Sedang berwujud Shazam (bukan Black Adam atau Sabbac). */
    public static boolean isShazam(ServerPlayer player) {
        ShazamData data = ShazamPowers.data(player);
        return data.transformed() && data.isShazam();
    }

    /** 0.30: sedang berwujud Sabbac. */
    public static boolean isSabbac(ServerPlayer player) {
        ShazamData data = ShazamPowers.data(player);
        return data.transformed() && data.isSabbac();
    }

    /** 0.43: sedang berwujud Helion-6. */
    public static boolean isHelion(ServerPlayer player) {
        ShazamData data = ShazamPowers.data(player);
        return data.transformed() && data.isHelion();
    }

    /** 0.32: sedang berwujud Lintang. */
    public static boolean isLintang(ServerPlayer player) {
        ShazamData data = ShazamPowers.data(player);
        return data.transformed() && data.isLintang();
    }

    /** 0.30: sumber kekuatan Sabbac sedang dekat: malam, Nether, atau End (Muatan Neraka 2x). */
    public static boolean inDarkness(ServerPlayer player) {
        return PassiveConditions.darkness(player.level());
    }

    /** Sedang berwujud Black Adam. */
    public static boolean isAdam(ServerPlayer player) {
        ShazamData data = ShazamPowers.data(player);
        return data.transformed() && data.isBlackAdam();
    }

    /** 0.28: sedang berwujud juara mana pun (Shazam atau Black Adam): pasif-pasif di kelas ini berlaku untuk keduanya. */
    public static boolean isChampion(ServerPlayer player) {
        return ShazamPowers.data(player).transformed();
    }

    private static void sound(ServerPlayer player, Vec3 at, SoundEvent sound, float volume, float pitch) {
        player.serverLevel().playSound(null, at.x, at.y, at.z, sound, SoundSource.PLAYERS, volume, pitch);
    }

    private static List<LivingEntity> enemies(ServerPlayer player, Vec3 center, double radius) {
        return player.serverLevel().getEntitiesOfClass(LivingEntity.class, new AABB(center, center).inflate(radius),
                m -> m.isAlive() && m instanceof Enemy && !DemonSoldier.isFriendly(m) && m.distanceToSqr(center) <= radius * radius);
    }

    /** Dipanggil tiap tick selama berwujud juara (Shazam: dari ShazamSkills.tick, Black Adam 0.28: dari AdamSkills.tick). */
    public static void tick(ServerPlayer player) {
        ShazamForm form = ShazamPowers.data(player).champion();
        double moved = Math.sqrt(player.distanceToSqr(player.xo, player.yo, player.zo));
        if (player.getAbilities().flying && moved > 0.5) {
            addCharge(player, (float) (moved - 0.5) * CHARGE_FLIGHT);
        }
        if (form == ShazamForm.SHAZAM && ShazamMercury.isActive(player) && moved > 0.3) {
            addCharge(player, CHARGE_MERCURY);
        }
        // sumber kekuatannya sendiri: Shazam dari badai petir, Black Adam dari matahari Kahndaq, Sabbac dari kegelapan neraka
        boolean source = switch (form) {
            case BLACK_ADAM -> ShazamPowers.isInSun(player);
            case SABBAC -> inDarkness(player);
            case LINTANG -> ShazamPowers.isInSun(player);   // 0.32 Muatan Cahaya terisi di bawah matahari
            case HELION -> !ShazamPowers.isInSun(player) || HelionSkills.cryonWorld(player);   // 0.43 jauh dari matahari
            default -> ShazamPowers.isInStorm(player);
        };
        if (source) {
            addCharge(player, CHARGE_STORM);
        }
        rodTick(player);   // Penangkal Petir Hidup: petir menyambar tiap 2 detik
        if (player.tickCount % 40 == 0) {
            family(player);
        }
    }

    public static void reset(ServerPlayer player) {
        UUID id = player.getUUID();
        CHARGE.remove(id);
        HERO_UNTIL.remove(id);
        ROD_NEXT.remove(id);   // berubah lagi nanti: sambaran pertama 2 detik sesudah petir transformasi
        PASSIVE_ON.remove(id);
        PASSIVE_PENDING.remove(id);
        removeShield(player);
    }

    public static void forget(UUID id) {
        CHARGE.remove(id);
        DODGE_READY.remove(id);
        HERO_UNTIL.remove(id);
        HERO_NEXT.remove(id);
        ABSORB_NEXT.remove(id);
        ROD_NEXT.remove(id);
        PASSIVE_ON.remove(id);
        PASSIVE_PENDING.remove(id);
    }

    // ------------------------------------------------------------------ Muatan Petir

    public static int charge(ServerPlayer player) {
        return Math.round(CHARGE.getOrDefault(player.getUUID(), 0f));
    }

    public static boolean isCharged(ServerPlayer player) {
        return CHARGE.getOrDefault(player.getUUID(), 0f) >= MAX_CHARGE;
    }

    public static void addCharge(ServerPlayer player, float amount) {
        if (amount <= 0f || !isChampion(player)) {
            return;
        }
        ShazamForm form = ShazamPowers.data(player).champion();
        boolean doubled = switch (form) {
            case BLACK_ADAM -> ShazamPowers.isInSun(player);
            case SABBAC -> inDarkness(player);
            case LINTANG -> ShazamPowers.isInSun(player);
            case HELION -> HelionSkills.cryonWorld(player);   // 0.43 dekat Batu Cryon: 2x
            default -> player.level().isRainingAt(player.blockPosition());
        };
        if (doubled) {
            amount *= RAIN_MULTIPLIER;   // Shazam: kehujanan 2x, Black Adam: di bawah matahari 2x, Sabbac: di kegelapan 2x
        }
        float old = CHARGE.getOrDefault(player.getUUID(), 0f);
        float now = Math.min(MAX_CHARGE, old + amount);
        CHARGE.put(player.getUUID(), now);
        if (old < MAX_CHARGE && now >= MAX_CHARGE) {
            if (form == ShazamForm.HELION) {   // 0.43 Tinju Cryon siap: detak Geiger & kepalan meretih radiasi
                sound(player, player.position(), ShazamSounds.GEIGER.get(), 1.0f, 1.2f);
                sound(player, player.position(), ShazamSounds.HELION_PUNCH.get(), 0.5f, ShazamSounds.tune(1.3f));
            } else if (form == ShazamForm.LINTANG) {   // 0.35 Tinju Baja siap: kepalan mengepal keras, tanpa denting sihir
                sound(player, player.position(), ShazamSounds.PUNCH.get(), 0.7f, ShazamSounds.tune(0.7f));
                sound(player, player.position(), ShazamSounds.WHOOSH.get(), 0.5f, ShazamSounds.tune(1.3f));
            } else {
                sound(player, player.position(), ShazamSounds.ENERGY_PULSE.get(), 1.0f, ShazamSounds.tune(form == ShazamForm.SABBAC ? 0.8f : 1.8f));
                sound(player, player.position(), ShazamSounds.SHIMMER.get(), 1.2f, ShazamSounds.tune(form == ShazamForm.SABBAC ? 0.7f : 1.6f));
            }
            String key = switch (form) {
                case BLACK_ADAM -> "message.shazammod.charged_adam";
                case SABBAC -> "message.shazammod.charged_sabbac";
                case LINTANG -> "message.shazammod.charged_lintang";
                case HELION -> "message.shazammod.charged_helion";
                default -> "message.shazammod.charged";
            };
            ChatFormatting color = switch (form) {
                case BLACK_ADAM -> ChatFormatting.GOLD;
                case SABBAC -> ChatFormatting.RED;
                case LINTANG -> ChatFormatting.AQUA;
                case HELION -> ChatFormatting.GREEN;
                default -> ChatFormatting.YELLOW;
            };
            player.displayClientMessage(Component.translatable(key).withStyle(color), true);
            ShazamNetwork.broadcastState(player);   // pemain lain melihat kepalannya menyala
        }
    }

    /** Muatan penuh dipakai pukulan ini (jadi Pukulan Guntur). */
    public static boolean consumeCharge(ServerPlayer player) {
        if (!isChampion(player) || !isCharged(player)) {
            return false;
        }
        CHARGE.put(player.getUUID(), 0f);
        ShazamNetwork.broadcastState(player);
        return true;
    }

    /**
     * Pukulan Guntur: dipanggil di tengah event damage pukulannya (damage-nya sudah dikali). Petir dari langit di sasaran;
     * hempasan dan petir yang merambat ke musuh lain menyusul satu tick kemudian, sesudah event ini selesai.
     */
    public static void thunderPunch(ServerPlayer player, LivingEntity target) {
        if (isAdam(player)) {
            sunPunch(player, target);
            return;
        }
        if (isSabbac(player)) {
            hellPunch(player, target);
            return;
        }
        if (isHelion(player)) {   // 0.43 Tinju Cryon
            HelionSkills.cryonPunch(player, target);
            return;
        }
        if (isLintang(player)) {   // 0.32 Tinju Fajar
            LintangSkills.dawnPunch(player, target);
            return;
        }
        ServerLevel level = player.serverLevel();
        Vec3 at = target.position().add(0, target.getBbHeight() * 0.6, 0);
        ShazamNetwork.playAnim(player, ShazamAnim.THUNDER_PUNCH, at);
        ShazamPowers.spawnBolt(level, target.position(), 1.4f, 0);
        level.playSound(null, at.x, at.y, at.z, ShazamSounds.THUNDER_PUNCH.get(), SoundSource.PLAYERS, 2.0f, 1f);
        ShazamPowers.schedule(player, 1, p -> {
            if (target.isAlive()) {
                Vec3 dir = new Vec3(target.getX() - p.getX(), 0, target.getZ() - p.getZ());
                dir = dir.lengthSqr() < 1.0E-4 ? Vec3.ZERO : dir.normalize();
                target.push(dir.x * THUNDER_KNOCKBACK, 0.55, dir.z * THUNDER_KNOCKBACK);
                target.hurtMarked = true;
            }
            List<LivingEntity> near = enemies(p, target.position(), THUNDER_CHAIN_RADIUS);
            near.remove(target);
            near.sort(Comparator.comparingDouble(m -> m.distanceToSqr(target)));
            for (int i = 0; i < Math.min(THUNDER_CHAIN_TARGETS, near.size()); i++) {
                ShazamPowers.strikeLightning(p, near.get(i).position(), THUNDER_CHAIN_DAMAGE, 0.9, 0.7f);
            }
        });
    }

    /**
     * 0.28.1 Black Adam: Tinju Aton, padanan Pukulan Guntur (damage-nya sudah dikali di event yang sama). Panas matahari:
     * sasaran terbakar dan terhempas jauh, lalu semburan api matahari meledak di sekitarnya membakar sampai 3 musuh lain
     * (14 damage). Tanpa petir.
     */
    private static void sunPunch(ServerPlayer player, LivingEntity target) {
        ServerLevel level = player.serverLevel();
        Vec3 at = target.position().add(0, target.getBbHeight() * 0.6, 0);
        ShazamNetwork.playAnim(player, ShazamAnim.ADAM_SUNPUNCH, at);   // client: ledakan cahaya & api matahari
        level.playSound(null, at.x, at.y, at.z, ShazamSounds.ATON_PUNCH.get(), SoundSource.PLAYERS, 2.0f, 1f);
        target.igniteForSeconds(SUN_FIRE_SECONDS);
        ShazamPowers.schedule(player, 1, p -> {
            if (target.isAlive()) {
                Vec3 dir = new Vec3(target.getX() - p.getX(), 0, target.getZ() - p.getZ());
                dir = dir.lengthSqr() < 1.0E-4 ? Vec3.ZERO : dir.normalize();
                target.push(dir.x * THUNDER_KNOCKBACK, 0.55, dir.z * THUNDER_KNOCKBACK);
                target.hurtMarked = true;
            }
            List<LivingEntity> near = enemies(p, target.position(), THUNDER_CHAIN_RADIUS);
            near.remove(target);
            near.sort(Comparator.comparingDouble(m -> m.distanceToSqr(target)));
            DamageSource sun = ShazamPowers.forceSource(p);
            for (int i = 0; i < Math.min(THUNDER_CHAIN_TARGETS, near.size()); i++) {
                LivingEntity m = near.get(i);
                m.hurt(sun, THUNDER_CHAIN_DAMAGE);
                m.igniteForSeconds(SUN_FIRE_SECONDS * 0.5f);
            }
        });
    }

    /**
     * 0.30 Sabbac: Tinju Neraka, padanan Pukulan Guntur (damage-nya sudah dikali di event yang sama). Api neraka: sasaran
     * terbakar dan terhempas, lalu rantai neraka menyambar sampai 3 musuh lain (14 damage) dan menyeret mereka ke sasaran.
     */
    private static void hellPunch(ServerPlayer player, LivingEntity target) {
        ServerLevel level = player.serverLevel();
        Vec3 at = target.position().add(0, target.getBbHeight() * 0.6, 0);
        ShazamNetwork.playAnim(player, ShazamAnim.SABBAC_HELLPUNCH, at);   // client: ledakan api neraka & rantai
        level.playSound(null, at.x, at.y, at.z, ShazamSounds.HELLFIRE_PUNCH.get(), SoundSource.PLAYERS, 2.0f, 1f);
        target.igniteForSeconds(HELL_FIRE_SECONDS);
        ShazamPowers.schedule(player, 1, p -> {
            if (target.isAlive()) {
                Vec3 dir = new Vec3(target.getX() - p.getX(), 0, target.getZ() - p.getZ());
                dir = dir.lengthSqr() < 1.0E-4 ? Vec3.ZERO : dir.normalize();
                target.push(dir.x * THUNDER_KNOCKBACK, 0.55, dir.z * THUNDER_KNOCKBACK);
                target.hurtMarked = true;
            }
            List<LivingEntity> near = enemies(p, target.position(), THUNDER_CHAIN_RADIUS);
            near.remove(target);
            near.sort(Comparator.comparingDouble(m -> m.distanceToSqr(target)));
            DamageSource hell = ShazamPowers.forceSource(p);
            for (int i = 0; i < Math.min(THUNDER_CHAIN_TARGETS, near.size()); i++) {
                LivingEntity m = near.get(i);
                m.hurt(hell, THUNDER_CHAIN_DAMAGE);
                m.igniteForSeconds(HELL_FIRE_SECONDS * 0.5f);
                Vec3 pull = target.position().subtract(m.position());
                if (pull.lengthSqr() > 1.0) {
                    pull = pull.normalize().scale(HELL_CHAIN_PULL);
                    m.push(pull.x, 0.25, pull.z);
                    m.hurtMarked = true;
                }
                ShazamNetwork.playAnim(p, ShazamAnim.SABBAC_CHAIN_BIND, m.position());
            }
        });
    }

    /** Kena serangan juga menambah muatan (dipanggil ShazamPowers). */
    public static void onHurt(ServerPlayer victim) {
        addCharge(victim, CHARGE_PER_HURT);
    }

    // ------------------------------------------------------------------ Refleks Mercury

    public static int dodgeCooldown(ServerPlayer player) {
        Long ready = DODGE_READY.get(player.getUUID());
        if (ready == null) {
            return 0;
        }
        long left = ready - player.level().getGameTime();
        return left > 0 ? (int) left : 0;
    }

    /**
     * Serangan dari makhluk (pukulan, panah, bola api, ...) dihindari kalau refleksnya siap: Shazam melesat ke samping secepat
     * kilat, meninggalkan bayangan. Bukan serangan (jatuh, api, ledakan, void): nggak dihindari.
     */
    public static boolean tryDodge(ServerPlayer victim, DamageSource source) {
        if (!isShazam(victim) || ShazamSkills.isAchillesActive(victim)) {
            return false;   // Perisai Achilles sedang menahan semuanya: refleksnya disimpan
        }
        Entity attacker = source.getEntity();
        Entity direct = source.getDirectEntity();
        if ((attacker == null && direct == null) || attacker == victim
                || source.is(DamageTypeTags.BYPASSES_INVULNERABILITY) || source.is(DamageTypeTags.IS_EXPLOSION)) {
            return false;
        }
        long now = victim.level().getGameTime();
        Long ready = DODGE_READY.get(victim.getUUID());
        if (ready != null && now < ready) {
            return false;
        }
        DODGE_READY.put(victim.getUUID(), now + DODGE_COOLDOWN_TICKS);
        Entity from = direct != null ? direct : attacker;
        Vec3 away = new Vec3(victim.getX() - from.getX(), 0, victim.getZ() - from.getZ());
        if (away.lengthSqr() < 1.0E-4) {
            Vec3 look = victim.getViewVector(1f);
            away = new Vec3(-look.x, 0, -look.z);
        }
        away = away.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : away.normalize();
        Vec3 side = new Vec3(-away.z, 0, away.x).scale(victim.getRandom().nextBoolean() ? 1.0 : -1.0);
        Vec3 velocity = side.scale(DODGE_SPEED).add(away.scale(0.35));
        ShazamNetwork.playAnim(victim, ShazamAnim.MERCURY_DODGE, victim.position());
        victim.setDeltaMovement(velocity.x, 0.12, velocity.z);
        victim.hurtMarked = true;
        sound(victim, victim.position(), ShazamSounds.MERCURY_BLINK.get(), 1.2f, 0.95f + victim.getRandom().nextFloat() * 0.1f);
        return true;
    }

    /**
     * 0.28 Black Adam: Tangkisan Kahndaq, padanan Refleks Mercury dengan jeda yang sama (sekali tiap 1,8 detik). Black Adam
     * nggak menghindar: serangan itu ditahan kulitnya SAMA SEKALI (0 damage), lalu panas matahari menyembur balik: penyerangnya
     * kena 10 damage, terbakar 3 detik, dan terdorong. Menahan serangan juga mengisi Muatan Petir. Ledakan dan damage tanpa penyerang nggak ditahan.
     */
    public static boolean tryBlock(ServerPlayer victim, DamageSource source) {
        if (!isAdam(victim)) {
            return false;
        }
        Entity attacker = source.getEntity();
        Entity direct = source.getDirectEntity();
        if ((attacker == null && direct == null) || attacker == victim
                || source.is(DamageTypeTags.BYPASSES_INVULNERABILITY) || source.is(DamageTypeTags.IS_EXPLOSION)) {
            return false;
        }
        long now = victim.level().getGameTime();
        Long ready = DODGE_READY.get(victim.getUUID());
        if (ready != null && now < ready) {
            return false;
        }
        DODGE_READY.put(victim.getUUID(), now + DODGE_COOLDOWN_TICKS);
        Entity from = direct != null ? direct : attacker;
        Vec3 chest = victim.position().add(0, victim.getBbHeight() * 0.6, 0);
        Vec3 toward = from.position().add(0, from.getBbHeight() * 0.6, 0).subtract(chest);
        Vec3 hit = toward.lengthSqr() < 1.0E-4 ? chest : chest.add(toward.normalize().scale(0.55));
        ShazamNetwork.playAnim(victim, ShazamAnim.ADAM_BLOCK, hit);   // client: kulit berkilat, panas matahari menyembur balik
        sound(victim, hit, ShazamSounds.ADAM_BLOCK.get(), 1.4f, 0.95f + victim.getRandom().nextFloat() * 0.1f);
        if (attacker instanceof LivingEntity foe && foe != victim && foe.isAlive()) {
            ShazamPowers.schedule(victim, 1, p -> {   // tick berikutnya: di luar event damage yang sedang berjalan
                if (foe.isAlive()) {
                    foe.hurt(ShazamPowers.forceSource(p), BLOCK_SHOCK_DAMAGE);
                    foe.igniteForSeconds(BLOCK_FIRE_SECONDS);
                    Vec3 away = new Vec3(foe.getX() - p.getX(), 0, foe.getZ() - p.getZ());
                    away = away.lengthSqr() < 1.0E-4 ? Vec3.ZERO : away.normalize();
                    foe.push(away.x * BLOCK_KNOCKBACK, 0.3, away.z * BLOCK_KNOCKBACK);
                    foe.hurtMarked = true;
                }
            });
        }
        addCharge(victim, CHARGE_PER_HURT);
        return true;
    }

    /**
     * 0.30 Sabbac: Kulit Bara, padanan Refleks Mercury & Tangkisan Kahndaq (jedanya sama, sekali tiap 1,8 detik). Serangan itu
     * DITELAN bara di kulit Sabbac (0 damage), lalu api neraka menyambar balik: penyerangnya kena 10 damage, terbakar 3 detik,
     * dan terseret rantai MENDEKAT (Black Adam mendorong menjauh, Sabbac menarik ke cakarnya). Mengisi Muatan Neraka.
     */
    public static boolean tryEngulf(ServerPlayer victim, DamageSource source) {
        if (!isSabbac(victim) || SabbacSkills.isAymActive(victim)) {
            return false;   // Tubuh Aym sedang menahan semuanya: kulit baranya disimpan
        }
        Entity attacker = source.getEntity();
        Entity direct = source.getDirectEntity();
        if ((attacker == null && direct == null) || attacker == victim
                || source.is(DamageTypeTags.BYPASSES_INVULNERABILITY) || source.is(DamageTypeTags.IS_EXPLOSION)) {
            return false;
        }
        long now = victim.level().getGameTime();
        Long ready = DODGE_READY.get(victim.getUUID());
        if (ready != null && now < ready) {
            return false;
        }
        DODGE_READY.put(victim.getUUID(), now + DODGE_COOLDOWN_TICKS);
        Entity from = direct != null ? direct : attacker;
        Vec3 chest = victim.position().add(0, victim.getBbHeight() * 0.6, 0);
        Vec3 toward = from.position().add(0, from.getBbHeight() * 0.6, 0).subtract(chest);
        Vec3 hit = toward.lengthSqr() < 1.0E-4 ? chest : chest.add(toward.normalize().scale(0.55));
        ShazamNetwork.playAnim(victim, ShazamAnim.SABBAC_ENGULF, hit);   // client: bara menelan serangan, rantai menyambar
        sound(victim, hit, ShazamSounds.SABBAC_ENGULF.get(), 1.4f, 0.95f + victim.getRandom().nextFloat() * 0.1f);
        if (attacker instanceof LivingEntity foe && foe != victim && foe.isAlive()) {
            ShazamPowers.schedule(victim, 1, p -> {
                if (foe.isAlive()) {
                    foe.hurt(ShazamPowers.forceSource(p), ENGULF_BURN_DAMAGE);
                    foe.igniteForSeconds(ENGULF_FIRE_SECONDS);
                    Vec3 pull = new Vec3(p.getX() - foe.getX(), 0, p.getZ() - foe.getZ());
                    if (pull.lengthSqr() > 2.5 * 2.5) {
                        pull = pull.normalize();
                        foe.push(pull.x * ENGULF_PULL, 0.3, pull.z * ENGULF_PULL);
                        foe.hurtMarked = true;
                    }
                }
            });
        }
        addCharge(victim, CHARGE_PER_HURT);
        return true;
    }

    /**
     * 0.35 Lintang: Refleks Kilat (ala Superman, tanpa es/sihir), padanan Refleks Mercury / Tangkisan Kahndaq / Kulit Bara
     * (jedanya sama, tiap 1,8 detik). Serangan ditangkap secepat kilat (0 damage): proyektil (panah, bola api, dll.)
     * ditangkap di udara dan diremukkan, penyerang jarak dekat langsung dibalas pukulan: 6 damage, terhuyung, terdorong.
     * Nggak bisa menangkap Batu Cryon, dan nggak jalan selama Batu Cryon dekat.
     */
    public static boolean tryParry(ServerPlayer victim, DamageSource source) {
        if (!isLintang(victim) || LintangSkills.kelamExposed(victim)) {
            return false;
        }
        Entity attacker = source.getEntity();
        Entity direct = source.getDirectEntity();
        if ((attacker == null && direct == null) || attacker == victim
                || source.is(DamageTypeTags.BYPASSES_INVULNERABILITY) || source.is(DamageTypeTags.IS_EXPLOSION)) {
            return false;
        }
        long now = victim.level().getGameTime();
        Long ready = DODGE_READY.get(victim.getUUID());
        if (ready != null && now < ready) {
            return false;
        }
        DODGE_READY.put(victim.getUUID(), now + DODGE_COOLDOWN_TICKS);
        Entity from = direct != null ? direct : attacker;
        Vec3 chest = victim.position().add(0, victim.getBbHeight() * 0.6, 0);
        Vec3 toward = from.position().add(0, from.getBbHeight() * 0.6, 0).subtract(chest);
        Vec3 hit = toward.lengthSqr() < 1.0E-4 ? chest : chest.add(toward.normalize().scale(0.55));
        ShazamNetwork.playAnim(victim, ShazamAnim.LINTANG_PARRY, hit);
        sound(victim, hit, ShazamSounds.FROST_PARRY.get(), 1.3f, 0.95f + victim.getRandom().nextFloat() * 0.1f);   // tangkapan
        if (direct != null && direct != attacker && !(direct instanceof LivingEntity)) {
            Entity shot = direct;   // proyektil ditangkap di udara lalu diremukkan
            ShazamPowers.schedule(victim, 1, p -> {
                if (shot.isAlive()) {
                    shot.discard();
                }
            });
        }
        if (attacker instanceof LivingEntity foe && foe != victim && foe.isAlive()
                && foe.distanceToSqr(victim) < PARRY_COUNTER_RANGE * PARRY_COUNTER_RANGE) {
            ShazamPowers.schedule(victim, 1, p -> {
                if (foe.isAlive()) {   // pukulan balik secepat kilat: terhuyung & terdorong (tanpa beku)
                    foe.hurt(ShazamPowers.forceSource(p), PARRY_DAMAGE);
                    foe.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 2));
                    Vec3 away = new Vec3(foe.getX() - p.getX(), 0, foe.getZ() - p.getZ());
                    away = away.lengthSqr() < 1.0E-4 ? Vec3.ZERO : away.normalize();
                    foe.push(away.x * 1.4, 0.3, away.z * 1.4);
                    foe.hurtMarked = true;
                }
            });
        }
        addCharge(victim, CHARGE_PER_HURT);
        return true;
    }

    // ------------------------------------------------------------------ Hati Pahlawan & Keluarga Shazam

    private static boolean isAlly(LivingEntity entity) {
        return entity instanceof AbstractVillager || (entity instanceof TamableAnimal pet && pet.isTame())
                || (entity instanceof Player player && !player.isSpectator());
    }

    public static float heroMultiplier(ServerPlayer attacker) {
        Long until = HERO_UNTIL.get(attacker.getUUID());
        return until != null && until > attacker.level().getGameTime() ? HERO_MULTIPLIER : 1f;
    }

    /** Makhluk tak berdosa diserang monster: Shazam di sekitar mendengar panggilannya (dipanggil untuk semua damage). */
    public static void onInnocentHurt(LivingEntity victim, DamageSource source) {
        if (!(victim.level() instanceof ServerLevel level) || !(source.getEntity() instanceof LivingEntity attacker)
                || !(attacker instanceof Enemy) || attacker == victim || !isAlly(victim)
                || (victim instanceof ServerPlayer hurtPlayer && isChampion(hurtPlayer))) {
            return;
        }
        long now = level.getGameTime();
        AABB area = victim.getBoundingBox().inflate(HERO_RADIUS);
        for (ServerPlayer hero : level.getEntitiesOfClass(ServerPlayer.class, area, ShazamPassives::isChampion)) {
            Long next = HERO_NEXT.get(hero.getUUID());
            if (hero == victim || (next != null && now < next)) {
                continue;
            }
            HERO_NEXT.put(hero.getUUID(), now + HERO_GAP);
            HERO_UNTIL.put(hero.getUUID(), now + HERO_TICKS);
            ShazamSkills.expose(attacker, HERO_TICKS);
            attacker.addEffect(new MobEffectInstance(MobEffects.GLOWING, HERO_TICKS, 0, false, false));
            ShazamNetwork.playAnim(hero, ShazamAnim.HERO_CALL, attacker.position().add(0, attacker.getBbHeight() * 0.6, 0));
            String key = isHelion(hero) ? "message.shazammod.hero_call_helion"
                    : isLintang(hero) ? "message.shazammod.hero_call_lintang" : isAdam(hero) ? "message.shazammod.hero_call_adam"
                    : isSabbac(hero) ? "message.shazammod.hero_call_sabbac" : "message.shazammod.hero_call";
            hero.displayClientMessage(Component.translatable(key).withStyle(isSabbac(hero) ? ChatFormatting.RED
                    : ChatFormatting.GOLD), true);
            if (isSabbac(hero)) {
                attacker.igniteForSeconds(2f);   // dicap api neraka
            }
        }
    }

    /** Keluarga Shazam: sekutu di sekitar ikut terlindungi kekuatan petir sihir. */
    private static void family(ServerPlayer player) {
        for (LivingEntity ally : player.serverLevel().getEntitiesOfClass(LivingEntity.class,
                player.getBoundingBox().inflate(FAMILY_RADIUS), e -> e != player && e.isAlive() && isAlly(e))) {
            ally.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 60, 0, true, false, true));
        }
    }

    // ------------------------------------------------------------------ Penangkal Petir Hidup (0.25)

    /** Hitung mundur sambaran berikutnya; dipanggil tiap tick selama berwujud Shazam. */
    private static void rodTick(ServerPlayer player) {
        if (player.isSpectator()) {
            return;
        }
        UUID id = player.getUUID();
        long now = player.level().getGameTime();
        // 0.29: Black Adam butuh matahari, petir Shazam padam di gurun / es & salju / Nether.
        // 0.30: Api Neraka Sabbac padam di bawah matahari & di dalam air.
        ShazamForm form = ShazamPowers.data(player).champion();
        boolean allowed = (PassiveConditions.allowed(player.level(), player.blockPosition(), form, player.isUnderWater())
                || (form == ShazamForm.HELION && HelionSkills.cryonWorld(player)))   // 0.43: Batu Cryon menetralkan matahari
                && !(form == ShazamForm.LINTANG && LintangSkills.kelamExposed(player));   // 0.32 Batu Kelam menghisap cahaya
        Boolean on = PASSIVE_ON.get(id);
        if (on == null) {   // baru berubah wujud: ikut keadaan sekarang tanpa animasi (cuma kabar kalau sedang padam)
            PASSIVE_ON.put(id, allowed);
            on = allowed;
            if (!allowed) {
                player.displayClientMessage(blockedMessage(player, form), true);
            }
        } else if (allowed != on) {
            int held = PASSIVE_PENDING.merge(id, 1, Integer::sum);
            if (held >= STATE_HOLD) {
                PASSIVE_PENDING.remove(id);
                PASSIVE_ON.put(id, allowed);
                on = allowed;
                passiveChanged(player, form, allowed);
                // menyala lagi: Shazam langsung disambar (sambaran itulah animasi kembalinya), Black Adam tunggu cakram terbit,
                // Sabbac tunggu api nerakanya menyala lagi
                int delay = switch (form) {
                    case BLACK_ADAM -> SUNRISE_DELAY;
                    case SABBAC -> ShazamAnim.FIRE_IN_TICKS;
                    default -> 0;
                };
                ROD_NEXT.put(id, allowed ? now + delay : now + ROD_INTERVAL_TICKS);
            }
        } else {
            PASSIVE_PENDING.remove(id);
        }
        if (!on) {
            ROD_NEXT.put(id, now + ROD_INTERVAL_TICKS);   // padam: nggak ada denyut sama sekali
            return;
        }
        Long next = ROD_NEXT.get(id);
        if (next == null) {   // baru berubah: petir transformasi baru saja menyambar, jadi yang pertama 2 detik lagi
            ROD_NEXT.put(id, now + ROD_INTERVAL_TICKS);
            return;
        }
        if (now >= next) {
            ROD_NEXT.put(id, now + ROD_INTERVAL_TICKS);
            rodStrike(player);
        }
    }

    /** 0.29: animasi & kabar saat pasif tiap 2 detik padam atau menyala lagi. */
    private static void passiveChanged(ServerPlayer player, ShazamForm form, boolean on) {
        ServerLevel level = player.serverLevel();
        boolean adam = form == ShazamForm.BLACK_ADAM;
        if (form == ShazamForm.HELION) {   // 0.43 sel Cryon terbakar matahari / radiasi menyala lagi di tempat teduh
            ShazamNetwork.playAnim(player, on ? ShazamAnim.HELION_SUN_CLEAR : ShazamAnim.HELION_SUN_BURN, player.position());
            if (!on) {
                HelionSkills.taunt(player, HelionSkills.Taunt.SUN, false);   // 0.45
            }
            level.playSound(null, player, (on ? ShazamSounds.HELION_PULSE : ShazamSounds.HELION_SUN_BURN).get(), SoundSource.PLAYERS,
                    1.2f, 1f);
            player.displayClientMessage(on ? Component.translatable("message.shazammod.helion_shade")
                    .withStyle(ChatFormatting.GREEN) : blockedMessage(player, form), true);
            return;
        }
        if (form == ShazamForm.LINTANG) {   // 0.32 cahaya Lintang meredup / kembali
            ShazamNetwork.playAnim(player, on ? ShazamAnim.LINTANG_RETURN : ShazamAnim.LINTANG_FADE, player.position());
            level.playSound(null, player, (on ? ShazamSounds.SOLAR_PULSE : ShazamSounds.POWER_DOWN).get(), SoundSource.PLAYERS,
                    on ? 1.1f : 0.8f, on ? 1.2f : 1.3f);
            player.displayClientMessage(on ? Component.translatable("message.shazammod.lintang_light_return")
                    .withStyle(ChatFormatting.AQUA) : blockedMessage(player, form), true);
            return;
        }
        if (form == ShazamForm.SABBAC) {   // 0.30 Api Neraka padam / menyala lagi
            ShazamNetwork.playAnim(player, on ? ShazamAnim.SABBAC_FIRE_IN : ShazamAnim.SABBAC_FIRE_OUT, player.position());
            level.playSound(null, player, (on ? ShazamSounds.HELLFIRE_IN : ShazamSounds.HELLFIRE_OUT).get(), SoundSource.PLAYERS,
                    1.3f, 1f);
            player.displayClientMessage(on ? Component.translatable("message.shazammod.hellfire_return")
                    .withStyle(ChatFormatting.RED) : blockedMessage(player, form), true);
            return;
        }
        if (adam) {   // Cakram Aton terbenam / terbit
            ShazamNetwork.playAnim(player, on ? ShazamAnim.ADAM_SUN_RISE : ShazamAnim.ADAM_SUN_SET, player.position());
            level.playSound(null, player, (on ? ShazamSounds.ATON_RISE : ShazamSounds.ATON_SET).get(), SoundSource.PLAYERS,
                    1.3f, 1f);
            player.displayClientMessage(on ? Component.translatable("message.shazammod.sun_rise").withStyle(ChatFormatting.GOLD)
                    : blockedMessage(player, form), true);
        } else if (!on) {   // petir padam (animasinya ikut tempatnya: gurun berdebu, es berembun beku, Nether berasap)
            ShazamNetwork.playAnim(player, ShazamAnim.ROD_FADE, player.position());
            level.playSound(null, player, ShazamSounds.ROD_FADE.get(), SoundSource.PLAYERS, 1.2f, 1f);
            player.displayClientMessage(blockedMessage(player, form), true);
        } else {   // petir kembali: sambaran pertamanya langsung datang (rodTick)
            player.displayClientMessage(Component.translatable("message.shazammod.rod_return").withStyle(ChatFormatting.YELLOW),
                    true);
        }
    }

    private static Component blockedMessage(ServerPlayer player, ShazamForm form) {
        if (form == ShazamForm.HELION) {   // 0.43: kenapa radiasi Helion-6 padam
            return Component.translatable("message.shazammod.helion_sun").withStyle(ChatFormatting.GOLD);
        }
        if (form == ShazamForm.LINTANG) {   // 0.32: kenapa cahaya Lintang meredup
            String key = LintangSkills.kelamExposed(player) ? "message.shazammod.lintang_dim_kelam"
                    : player.level().dimensionType().hasFixedTime() ? "message.shazammod.lintang_dim_void"
                    : "message.shazammod.lintang_dim_sky";
            return Component.translatable(key).withStyle(ChatFormatting.GRAY);
        }
        if (form == ShazamForm.SABBAC) {
            return Component.translatable(player.isUnderWater() ? "message.shazammod.hellfire_water"
                    : "message.shazammod.hellfire_sun").withStyle(ChatFormatting.GRAY);
        }
        if (form == ShazamForm.BLACK_ADAM) {
            return Component.translatable(player.level().dimensionType().hasFixedTime() ? "message.shazammod.sun_none"
                    : "message.shazammod.sun_set").withStyle(ChatFormatting.GRAY);
        }
        String key = switch (PassiveConditions.lightningBlock(player.level(), player.blockPosition())) {
            case NETHER -> "message.shazammod.rod_fade_nether";
            case ICE -> "message.shazammod.rod_fade_ice";
            default -> "message.shazammod.rod_fade_desert";
        };
        return Component.translatable(key).withStyle(ChatFormatting.GRAY);
    }

    /**
     * Petir sihir dipanggil ke dada Shazam seperti di film: di client petirnya turun dari langit selama ROD_DESCENT tick
     * (badan memancarkan busur listrik ke atas menyambutnya), lalu menghantam dada, badan tersentak, mata & lambang menyala,
     * dan listrik merayap di badan (lihat client.fx.RodStrikeFx). Kekuatannya masuk tepat di tick hantaman.
     */
    private static void rodStrike(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        if (isHelion(player)) {
            // 0.43 Helion-6: Denyut Cryon - radiasi di sel tubuhnya berdenyut (urat menyala, cincin radiasi), x2 dekat Cryon
            ShazamNetwork.playAnim(player, ShazamAnim.HELION_PULSE, player.position());
            level.playSound(null, player, ShazamSounds.HELION_PULSE.get(), SoundSource.PLAYERS, 0.9f,
                    0.95f + player.getRandom().nextFloat() * 0.1f);
            float k = HelionSkills.pulseScale(player);
            empower(player, ROD_ENERGY * k, ROD_HEAL * k);
            HelionSkills.pulseSplash(player);
            return;
        }
        if (isLintang(player)) {
            // 0.35 Lintang: Regenerasi Surya (ala Superman, tanpa sinar dari langit): sel tubuhnya terus menyerap sinar
            // matahari tanpa terlihat dan tanpa suara; malam hari tinggal cadangan sel, jadi separuh. Cuma riak panas tipis.
            boolean sun = ShazamPowers.isInSun(player);
            ShazamNetwork.playAnim(player, ShazamAnim.LINTANG_PULSE, player.position());
            float k = sun ? 1f : LintangSkills.STARLIGHT_PULSE;
            empower(player, ROD_ENERGY * k, ROD_HEAL * k);
            return;
        }
        if (isSabbac(player)) {
            // 0.30 Sabbac: Api Neraka menyembur naik dari tanah (bukan dari langit). Waktunya sama: menyembur di tick ROD_DESCENT
            ShazamNetwork.playAnim(player, ShazamAnim.SABBAC_PULSE, player.position());
            level.playSound(null, player, ShazamSounds.HELLFIRE_PULSE.get(), SoundSource.PLAYERS, ROD_VOLUME,
                    ShazamSlowMo.pitch(level.getServer(), 0.97f + player.getRandom().nextFloat() * 0.06f));
            ShazamPowers.schedule(player, ShazamAnim.ROD_DESCENT, p -> {
                if (!isChampion(p)) {
                    return;
                }
                empower(p, ROD_ENERGY, ROD_HEAL);
                if (PassiveConditions.inferno(p.level())) {   // Nether: kampung halaman iblis, apinya ikut membakar sekeliling
                    DamageSource source = ShazamPowers.forceSource(p);
                    for (LivingEntity foe : enemies(p, p.position(), INFERNO_SPLASH_RADIUS)) {
                        foe.hurt(source, INFERNO_SPLASH_DAMAGE);
                        foe.igniteForSeconds(3f);
                    }
                }
            });
            return;
        }
        if (isAdam(player)) {
            // 0.28.1 Black Adam: Cakram Aton berdenyut (matahari, bukan petir). Waktunya sama: menyembur di tick ROD_DESCENT
            ShazamNetwork.playAnim(player, ShazamAnim.ADAM_SUN, player.position());
            level.playSound(null, player, ShazamSounds.ATON_PULSE.get(), SoundSource.PLAYERS, ROD_VOLUME,
                    ShazamSlowMo.pitch(level.getServer(), 0.97f + player.getRandom().nextFloat() * 0.06f));
            ShazamPowers.schedule(player, ShazamAnim.ROD_DESCENT, p -> {
                if (isChampion(p)) {
                    empower(p, ROD_ENERGY, ROD_HEAL);
                }
            });
            return;
        }
        ShazamNetwork.playAnim(player, ShazamAnim.ROD_STRIKE, player.position());
        // Satu suara yang sudah di-mix (tools/sfx/synth.py: rod_strike): desis petir turun 0,15 detik -> retakan tepat di
        // tick hantaman -> dentum sub -> guntur pendek -> dengung tenaga yang merasuk badan. Menempel ke badan Shazam (ikut
        // terbang), nadanya cuma digeser sedikit supaya retakannya tetap jatuh di tick hantaman.
        level.playSound(null, player, ShazamSounds.ROD_STRIKE.get(), SoundSource.PLAYERS, ROD_VOLUME,
                ShazamSlowMo.pitch(level.getServer(), 0.97f + player.getRandom().nextFloat() * 0.06f));
        ShazamPowers.schedule(player, ShazamAnim.ROD_DESCENT, p -> {
            if (!isChampion(p)) {
                return;   // keburu balik jadi manusia
            }
            empower(p, ROD_ENERGY, ROD_HEAL);
            if (ROD_SPLASH_DAMAGE > 0f) {
                DamageSource source = ShazamPowers.lightningSource(p);
                for (LivingEntity foe : enemies(p, p.position(), ROD_SPLASH_RADIUS)) {
                    foe.hurt(source, ROD_SPLASH_DAMAGE);
                }
            }
        });
    }

    /** Petir menyatu dengan badan: energi, darah, dan armor pulih, Perisai Petir terisi, Pukulan Guntur siap. */
    private static void empower(ServerPlayer player, float energy, float heal) {
        UUID id = player.getUUID();
        ShazamData data = ShazamPowers.data(player);
        ShazamPowers.setData(player, data.withEnergy(data.energy() + energy));
        player.heal(heal * ShazamPowers.healScale(player));   // 0.30: Luka Juara (dihantam juara lain) memulihkan setengahnya
        repairArmor(player);
        refillShield(player);
        boolean wasCharged = isCharged(player);
        CHARGE.put(id, MAX_CHARGE);   // kepalan berlistrik: pukulan tangan kosong berikutnya jadi Pukulan Guntur
        if (!wasCharged) {
            ShazamNetwork.broadcastState(player);   // pemain lain melihat kepalannya menyala
        }
        ShazamNetwork.sync(player);
    }

    /** Armor yang sedang dipakai (kostum Shazam atau armor apa pun) pulih. */
    private static void repairArmor(ServerPlayer player) {
        if (ROD_ARMOR_REPAIR <= 0f) {
            return;
        }
        for (EquipmentSlot slot : ARMOR_SLOTS) {
            ItemStack stack = player.getItemBySlot(slot);
            if (!stack.isEmpty() && stack.isDamageableItem() && stack.isDamaged()) {
                int fix = Math.max(1, Math.round(stack.getMaxDamage() * ROD_ARMOR_REPAIR));
                stack.setDamageValue(Math.max(0, stack.getDamageValue() - fix));
            }
        }
    }

    /**
     * Perisai Petir: armor Shazam (dari Atlas) nggak pernah berkurang, jadi "armor pulih" juga dibuat kelihatan sebagai
     * hati emas (absorption) yang habis kena serangan dan terisi lagi tiap sambaran.
     */
    private static void refillShield(ServerPlayer player) {
        if (ROD_SHIELD <= 0f) {
            return;
        }
        AttributeInstance max = player.getAttribute(Attributes.MAX_ABSORPTION);
        if (max == null) {
            return;
        }
        if (max.getModifier(ROD_SHIELD_ID) == null) {
            max.addTransientModifier(new AttributeModifier(ROD_SHIELD_ID, ROD_SHIELD, AttributeModifier.Operation.ADD_VALUE));
        }
        if (player.getAbsorptionAmount() < ROD_SHIELD) {
            player.setAbsorptionAmount(ROD_SHIELD);
        }
    }

    /** Balik jadi manusia / respawn: Perisai Petir ikut hilang. */
    private static void removeShield(ServerPlayer player) {
        AttributeInstance max = player.getAttribute(Attributes.MAX_ABSORPTION);
        if (max != null && max.getModifier(ROD_SHIELD_ID) != null) {
            max.removeModifier(ROD_SHIELD_ID);
            player.setAbsorptionAmount(player.getAbsorptionAmount());   // dipangkas ke batas yang baru
        }
    }

    /** Petir alam atau trisula Channeling yang menyambar Shazam diserap jadi kekuatan (lebih besar dari sambaran biasa). */
    public static void absorbLightning(ServerPlayer player) {
        if (!isShazam(player)) {
            return;
        }
        UUID id = player.getUUID();
        long now = player.level().getGameTime();
        Long next = ABSORB_NEXT.get(id);
        if (next != null && now < next) {
            return;
        }
        ABSORB_NEXT.put(id, now + ABSORB_GAP);
        ROD_NEXT.put(id, now + ROD_INTERVAL_TICKS);   // petir alam ini menggantikan sambaran berikutnya
        empower(player, ABSORB_ENERGY, ABSORB_HEAL);
        ShazamFavor.onStorm(player);   // 0.31 Restu Para Dewa: +3 tumpukan sekaligus
        ShazamNetwork.playAnim(player, ShazamAnim.STORM_ABSORB, player.position());
        sound(player, player.position(), ShazamSounds.POWER_UP.get(), 1.2f, ShazamSounds.tune(1.6f));
        sound(player, player.position(), ShazamSounds.DIVINE.get(), 0.6f, ShazamSounds.tune(1.6f));
        player.displayClientMessage(Component.translatable("message.shazammod.storm_absorb").withStyle(ChatFormatting.AQUA), true);
    }
}
