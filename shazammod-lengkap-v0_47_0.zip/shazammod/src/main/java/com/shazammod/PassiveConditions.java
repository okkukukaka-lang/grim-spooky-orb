package com.shazammod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;

/**
 * 0.29: pasif tiap 2 detik nggak menyala di mana saja. Dipakai server (ShazamPassives) dan client (HUD, efek padam), jadi
 * isinya cuma fungsi murni atas Level & biome.
 *
 * Black Adam (Cakram Aton) butuh matahari: padam saat malam, juga di Nether & End yang nggak punya matahari.
 * Shazam (Penangkal Petir Hidup) padam di:
 * - gurun & badlands (biome panas yang nggak pernah hujan: udaranya terlalu kering untuk petir),
 * - es & salju (tempat yang turun salju, bukan hujan, termasuk puncak gunung yang dingin),
 * - Nether (langit petir nggak sampai ke sana).
 * 0.30 Sabbac (Api Neraka) justru kebalikan Black Adam: kekuatannya dari kegelapan neraka, jadi padam:
 * - di bawah matahari (siang, langit terbuka, nggak hujan: cahaya matahari mengusir iblis),
 * - di dalam air (api neraka padam kalau tenggelam).
 *   Menyala di malam hari, di dalam gua, saat hujan, di End, dan paling kuat di Nether (kampung halamannya).
 */
public final class PassiveConditions {
    private PassiveConditions() {}

    // ======= Angka yang gampang diutak-atik =======
    /** Matahari di atas cakrawala antara tick 23460 (terbit) dan 12542 (terbenam) dalam satu hari Minecraft. */
    public static final long SUNRISE_TICK = 23460L;
    public static final long SUNSET_TICK = 12542L;
    /** Biome yang nggak pernah hujan dan sepanas ini dianggap gurun (gurun & badlands 2,0; savana 1,2 nggak kena). */
    private static final float DESERT_TEMPERATURE = 1.5f;
    // =========================================================================

    /** Kenapa petir Shazam padam di sini (NONE = boleh menyambar). */
    public enum Block { NONE, DESERT, ICE, NETHER }

    /** 0.30: kenapa Api Neraka Sabbac padam di sini (NONE = menyala). */
    public enum Hellfire { NONE, SUN, WATER }

    /** Black Adam: matahari sedang di atas cakrawala? */
    public static boolean sunUp(Level level) {
        if (level.dimensionType().hasFixedTime()) {
            return false;   // Nether & End: nggak ada siang
        }
        long t = Math.floorMod(level.getDayTime(), 24000L);
        return t < SUNSET_TICK || t >= SUNRISE_TICK;
    }

    /** Shazam: alasan petirnya padam di titik ini. */
    public static Block lightningBlock(Level level, BlockPos pos) {
        if (level.dimension() == Level.NETHER) {
            return Block.NETHER;
        }
        Holder<Biome> holder = level.getBiome(pos);
        Biome biome = holder.value();
        if (biome.coldEnoughToSnow(pos)) {
            return Block.ICE;
        }
        if (holder.is(Biomes.DESERT) || holder.is(Biomes.BADLANDS) || holder.is(Biomes.ERODED_BADLANDS)
                || holder.is(Biomes.WOODED_BADLANDS)
                || (!biome.hasPrecipitation() && biome.getBaseTemperature() >= DESERT_TEMPERATURE)) {
            return Block.DESERT;
        }
        return Block.NONE;
    }

    /** 0.30 Sabbac: di bawah matahari (matahari terbit, langit terbuka, nggak hujan). */
    public static boolean underSun(Level level, BlockPos pos) {
        return sunUp(level) && !level.isRaining() && level.canSeeSky(pos.above())
                && !HelionSkills.eclipsed(level, net.minecraft.world.phys.Vec3.atCenterOf(pos));   // 0.45 Gerhana Buatan
    }

    /** 0.30 Sabbac: alasan Api Neraka padam di titik ini (submerged = kepala di dalam air). */
    public static Hellfire hellfireBlock(Level level, BlockPos pos, boolean submerged) {
        if (submerged) {
            return Hellfire.WATER;
        }
        return underSun(level, pos) ? Hellfire.SUN : Hellfire.NONE;
    }

    /** 0.30 Sabbac: kegelapan neraka (Muatan Neraka 2x, energi terisi): malam, Nether, dan End. */
    public static boolean darkness(Level level) {
        return level.dimensionType().hasFixedTime() || !sunUp(level);
    }

    /** 0.30 Sabbac: Nether = kampung halaman iblis, denyut Api Neraka-nya paling kuat. */
    public static boolean inferno(Level level) {
        return level.dimension() == Level.NETHER;
    }

    /** 0.32 Lintang: langit terlihat di Overworld (siang = cahaya matahari, malam = cahaya bintang). */
    public static boolean skyLight(Level level, BlockPos pos) {
        return !level.dimensionType().hasFixedTime() && level.canSeeSky(pos.above());
    }

    /** Pasif tiap 2 detik juara ini boleh menyala di sini sekarang? */
    public static boolean allowed(Level level, BlockPos pos, ShazamForm form, boolean submerged) {
        return switch (form) {
            case BLACK_ADAM -> sunUp(level);
            case SABBAC -> hellfireBlock(level, pos, submerged) == Hellfire.NONE;
            case LINTANG -> skyLight(level, pos);
            case HELION -> !underSun(level, pos);   // 0.43 Helion-6: padam di bawah matahari
            default -> lightningBlock(level, pos) == Block.NONE;
        };
    }

    /** Versi lama (Shazam / Black Adam saja). */
    public static boolean allowed(Level level, BlockPos pos, boolean adam) {
        return allowed(level, pos, adam ? ShazamForm.BLACK_ADAM : ShazamForm.SHAZAM, false);
    }
}
