package com.shazammod.client;

import org.lwjgl.glfw.GLFW;

import com.shazammod.MagicBolt;
import com.shazammod.ShazamActionPayload;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamAnimPayload;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamEntities;
import com.shazammod.ShazamMod;
import com.shazammod.ShazamNetwork;
import com.shazammod.client.anim.PoseFilter;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.flight.HeruDash;
import com.shazammod.client.flight.MercuryMode;
import com.shazammod.client.flight.ShazamFlight;
import com.shazammod.client.fx.AdamFx;
import com.shazammod.client.fx.ChampionFx;
import com.shazammod.client.fx.GodAvatars;
import com.shazammod.client.fx.TrialFx;
import com.shazammod.client.fx.CameraShake;
import com.shazammod.client.fx.FovKick;
import com.shazammod.client.fx.MercuryFx;
import com.shazammod.client.fx.LintangCine;
import com.shazammod.client.fx.LintangFx;
import com.shazammod.client.fx.HelionFx;
import com.shazammod.client.fx.HelionComic;
import com.shazammod.client.fx.SabbacCine;
import com.shazammod.client.fx.SabbacFx;
import com.shazammod.client.fx.ScreenFlash;
import com.shazammod.client.fx.ScreenFx;
import com.shazammod.client.fx.ShazamCinematic;
import com.shazammod.client.fx.ShazamFx;
import com.shazammod.client.fx.ShazamRage;
import com.shazammod.client.fx.ShazamSpirits;
import com.shazammod.client.render.AchillesAuraLayer;
import com.shazammod.client.render.AdamGearLayer;
import com.shazammod.client.render.CapeDecor;
import com.shazammod.client.render.DemonSoldierRenderer;
import com.shazammod.client.render.MagicBoltRenderer;
import com.shazammod.client.render.SabbacGearLayer;
import com.shazammod.client.render.ShazamCape;
import com.shazammod.client.render.ShazamEmblemLayer;
import com.shazammod.client.render.ShazamEyesLayer;
import com.shazammod.client.render.LintangHeadFade;
import com.shazammod.client.render.LintangLightLayer;
import com.shazammod.client.render.HelionLayer;
import com.shazammod.client.render.SuitRevealLayer;
import com.shazammod.client.render.SuperDogCapeLayer;
import com.shazammod.client.vfx.BoltVisual;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.entity.AllayRenderer;
import net.minecraft.client.renderer.entity.BreezeRenderer;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.IronGolemRenderer;
import net.minecraft.client.renderer.entity.NoopRenderer;
import net.minecraft.client.renderer.entity.RavagerRenderer;
import net.minecraft.client.renderer.entity.WitherSkeletonRenderer;
import net.minecraft.client.renderer.entity.WolfRenderer;
import net.minecraft.client.renderer.entity.ZombieRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.resources.PlayerSkin;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.ComputeFovModifierEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterClientReloadListenersEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RenderFrameEvent;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.client.event.RenderPlayerEvent;
import net.neoforged.neoforge.client.event.RenderArmEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/** Khusus client: keybind, HUD, renderer, animasi, dan efek. */
public final class ShazamClient {
    private ShazamClient() {}

    private static final String CATEGORY = "key.categories.shazammod";

    public static final KeyMapping TRANSFORM = new KeyMapping("key.shazammod.transform", GLFW.GLFW_KEY_G, CATEGORY);
    public static final KeyMapping HOOD = new KeyMapping("key.shazammod.hood", GLFW.GLFW_KEY_H, CATEGORY);
    /**
     * Mode Kilat Mercury: auto-hit nyala/mati (lari super cepatnya tetap). Black Adam: Panggil Petir Kahndaq.
     * 0.30 Sabbac: Panggil Petir Neraka.
     */
    public static final KeyMapping MERCURY_AUTO = new KeyMapping("key.shazammod.mercury_auto", GLFW.GLFW_KEY_M, CATEGORY);
    /** Ganti juara: Shazam -> Black Adam -> Sabbac (yang sudah didapat, cuma dalam wujud manusia). */
    public static final KeyMapping FORM = new KeyMapping("key.shazammod.form", GLFW.GLFW_KEY_K, CATEGORY);
    /** 0.26: Kekuatan Keluarga (Shazam) / Tangan Kahndaq (Black Adam) / 0.30 Pasukan Iblis (Sabbac). */
    public static final KeyMapping FAMILY = new KeyMapping("key.shazammod.family", GLFW.GLFW_KEY_J, CATEGORY);
    /**
     * Urutan S-H-A-Z-A-M lalu amarah, sama dengan ShazamSkills.Skill dan AdamSkills.Skill: tombol yang sama memanggil
     * dewa juara yang sedang dipilih (Solomon/Shu, Hercules/Heru, Atlas/Amon, Zeus/Zehuti, Achilles/Aton, Mercury/Mehen,
     * Zeus Rage/Murka Kahndaq).
     */
    public static final KeyMapping[] SKILL_KEYS = {
            new KeyMapping("key.shazammod.solomon", GLFW.GLFW_KEY_Z, CATEGORY),
            new KeyMapping("key.shazammod.hercules", GLFW.GLFW_KEY_X, CATEGORY),
            new KeyMapping("key.shazammod.atlas", GLFW.GLFW_KEY_C, CATEGORY),
            new KeyMapping("key.shazammod.zeus", GLFW.GLFW_KEY_V, CATEGORY),
            new KeyMapping("key.shazammod.achilles", GLFW.GLFW_KEY_B, CATEGORY),
            new KeyMapping("key.shazammod.mercury", GLFW.GLFW_KEY_N, CATEGORY),
            new KeyMapping("key.shazammod.zeus_rage", GLFW.GLFW_KEY_R, CATEGORY)
    };

    @EventBusSubscriber(modid = ShazamMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class ModEvents {
        private ModEvents() {}

        @SubscribeEvent
        public static void registerKeys(RegisterKeyMappingsEvent event) {
            event.register(TRANSFORM);
            event.register(HOOD);
            for (KeyMapping key : SKILL_KEYS) {
                event.register(key);
            }
            event.register(MERCURY_AUTO);
            event.register(FORM);
            event.register(FAMILY);
            // Petir sihir: digambar mesin efek, dan tiap sambaran meninggalkan efek di tanah (cuma di client)
            MagicBolt.clientSpawn = bolt -> Vfx.add(new BoltVisual(bolt));
            MagicBolt.clientStrike = ShazamFx::boltStrike;
        }

        /** Sementara penjaga memakai tubuh mob vanilla; model khusus bisa menyusul. */
        @SubscribeEvent
        public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
            event.registerEntityRenderer(ShazamEntities.SCHOLAR_ZOMBIE.get(), ZombieRenderer::new);
            event.registerEntityRenderer(ShazamEntities.SCHOLAR_ILLUSION.get(), ZombieRenderer::new);
            event.registerEntityRenderer(ShazamEntities.JUNGLE_BRUTE.get(), RavagerRenderer::new);
            event.registerEntityRenderer(ShazamEntities.EARTH_GOLEM.get(), IronGolemRenderer::new);
            event.registerEntityRenderer(ShazamEntities.STORM_STALKER.get(), BreezeRenderer::new);
            event.registerEntityRenderer(ShazamEntities.UNDEAD_GLADIATOR.get(), WitherSkeletonRenderer::new);
            event.registerEntityRenderer(ShazamEntities.MERCURY_SPIRIT.get(), AllayRenderer::new);
            event.registerEntityRenderer(ShazamEntities.MAGIC_BOLT.get(), MagicBoltRenderer::new);
            // 0.30: prajurit Pasukan Iblis, dan Rival Juara (rival sendiri nggak digambar: bonekanya, lihat RivalPuppets)
            event.registerEntityRenderer(ShazamEntities.DEMON_SOLDIER.get(), DemonSoldierRenderer::new);
            event.registerEntityRenderer(ShazamEntities.RIVAL.get(), NoopRenderer::new);
        }

        /** Kilau saat berubah, lambang 3D, dan aura Achilles dipasang di model pemain (jubah & hood dirender terpisah). */
        @SubscribeEvent
        public static void addLayers(EntityRenderersEvent.AddLayers event) {
            for (PlayerSkin.Model skin : event.getSkins()) {
                if (event.getSkin(skin) instanceof PlayerRenderer renderer) {
                    renderer.addLayer(new LintangLightLayer(renderer));  // 0.42 Lintang tanpa kostum: matahari di kedua bahu
                    renderer.addLayer(new HelionLayer(renderer));        // 0.43 kostum & jalur radiasi Helion-6
                    renderer.addLayer(new SuitRevealLayer(renderer));
                    renderer.addLayer(new ShazamEmblemLayer(renderer));
                    renderer.addLayer(new AdamGearLayer(renderer));
                    renderer.addLayer(new SabbacGearLayer(renderer));
                    renderer.addLayer(new ShazamEyesLayer(renderer));
                    renderer.addLayer(new AchillesAuraLayer(renderer));
                    renderer.addLayer(new LintangHeadFade(renderer));   // 0.42 paling akhir: kepala tembus pandang saat sinar mata
                }
            }
            EntityRenderer<?> wolf = event.getRenderer(EntityType.WOLF);
            if (wolf instanceof WolfRenderer wolfRenderer) {   // 0.36 jubah merah anjing super Lintang
                wolfRenderer.addLayer(new SuperDogCapeLayer(wolfRenderer));
            }
        }

        @SubscribeEvent
        public static void registerHud(RegisterGuiLayersEvent event) {
            event.registerAbove(VanillaGuiLayers.HOTBAR, ShazamMod.id("energy_hud"), ShazamHud::render);
            event.registerAboveAll(ShazamMod.id("screen_fx"), ScreenFx::render);
            event.registerAboveAll(ShazamMod.id("helion_comic"), HelionComic::renderScreen);   // 0.45 balon kata & SFX komik
            event.registerAboveAll(ShazamMod.id("lightning_flash"), ScreenFlash::render);
        }

        @SubscribeEvent
        public static void registerReload(RegisterClientReloadListenersEvent event) {
            event.registerReloadListener((ResourceManagerReloadListener) manager -> {
                ShazamEmblemLayer.reset();
                CapeDecor.reset();
                RivalPuppets.resetSkins();
            });
        }
    }

    @EventBusSubscriber(modid = ShazamMod.MODID, value = Dist.CLIENT)
    public static final class GameEvents {
        private GameEvents() {}

        /** Fisika jubah & hood dihitung tiap frame (langkah kecil tetap) supaya gerakannya halus. */
        @SubscribeEvent
        public static void onRenderFrame(RenderFrameEvent.Pre event) {
            PoseFilter.frameStart();   // 0.34: mulai gambar dunia (penghalus gerak cuma dipakai di sini)
            Minecraft mc = Minecraft.getInstance();
            if (mc.level != null && !mc.isPaused()) {
                ShazamCape.frame(mc.level, event.getPartialTick().getGameTimeDeltaPartialTick(false));
            }
        }

        /** Roh enam dewa dan semua efek skill digambar di dunia, jadi tetap kelihatan dari sudut pandang orang pertama. */
        @SubscribeEvent
        public static void onRenderLevel(RenderLevelStageEvent event) {
            if (event.getStage() == RenderLevelStageEvent.Stage.AFTER_ENTITIES) {
                PoseFilter.entitiesDone();   // 0.34: sesudah ini (layar inventaris dll.) pose nggak dihaluskan
            }
            ShazamSpirits.render(event);
            Vfx.render(event);
        }

        @SubscribeEvent
        public static void onClientTick(ClientTickEvent.Post event) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.level == null) {
                return;
            }
            while (TRANSFORM.consumeClick()) {
                PacketDistributor.sendToServer(new ShazamActionPayload(ShazamNetwork.ACTION_TRANSFORM));
            }
            while (HOOD.consumeClick()) {
                PacketDistributor.sendToServer(new ShazamActionPayload(ShazamNetwork.ACTION_HOOD));
            }
            while (MERCURY_AUTO.consumeClick()) {
                if (ShazamClientState.isAdam() || ShazamClientState.isSabbac() || ShazamClientState.isLintang()
                        || ShazamClientState.isHelion()) {   // 0.43 Hirup Cryon
                    // Panggil Petir Kahndaq / Neraka, 0.32 Serap Surya (Lintang)
                    if (ShazamClientState.transformed) {
                        PacketDistributor.sendToServer(new ShazamActionPayload(ShazamNetwork.ACTION_ADAM_CALL));
                    }
                } else {
                    MercuryMode.toggleAuto(mc.player);
                }
            }
            while (FORM.consumeClick()) {
                PacketDistributor.sendToServer(new ShazamActionPayload(ShazamNetwork.ACTION_FORM));
            }
            while (FAMILY.consumeClick()) {
                PacketDistributor.sendToServer(new ShazamActionPayload(ShazamNetwork.ACTION_FAMILY));
            }
            MercuryMode.flush();   // pukulan Mode Kilat (posisi tick ini sudah terkirim duluan)
            for (int i = 0; i < SKILL_KEYS.length; i++) {
                while (SKILL_KEYS[i].consumeClick()) {
                    if (i == 1 && LintangCharge.wants(mc)) {   // 0.42 Lintang: X ditahan = sinar mata di-charge
                        LintangCharge.press(mc);
                    } else {
                        PacketDistributor.sendToServer(new ShazamActionPayload(i + 1));
                    }
                }
            }
            LintangCharge.tick(mc, SKILL_KEYS[1].isDown());
            if (mc.isPaused()) {
                return;
            }
            RivalPuppets.tick(mc.level);   // 0.30 boneka Rival Juara mengikuti rivalnya dulu, baru animasinya diputar
            ShazamAnimPayload payload;
            while ((payload = ShazamClientState.pollAnim()) != null) {
                ShazamAnim anim = ShazamAnim.byId(payload.anim());
                Entity target = anim == null ? null : mc.level.getEntity(payload.entityId());
                AbstractClientPlayer player = target instanceof AbstractClientPlayer p ? p : RivalPuppets.puppetOf(target);
                if (anim != null && player != null) {
                    Vec3 pos = new Vec3(payload.x(), payload.y(), payload.z());
                    ShazamPoses.start(player, anim);
                    ShazamFx.onAnim(player, anim, pos);
                    AdamFx.onAnim(player, anim, pos);
                    SabbacCine.onAnim(player, anim, pos);    // 0.33: efek asli + lapisan api neraka yang lebih tebal
                    LintangCine.onAnim(player, anim, pos);   // 0.33: efek asli + lapisan sinematik sains (eksperimen, Mode Surya, melemah)
                    HelionFx.onAnim(player, anim, pos);      // 0.43 Projek Helion-6: radiasi Cryon
                    TrialFx.onAnim(player, anim, pos);
                    if (player == mc.player && anim == ShazamAnim.SABBAC_HORNS) {
                        // 0.30 Tanduk Setan: menggaruk tanah, lalu menyeruduk lurus (badan digerakkan client sendiri)
                        HeruDash.start(mc.player, pos, ShazamAnim.HORN_WINDUP, ShazamAnim.HORN_TICKS, 1.6);
                    }
                    if (player == mc.player && anim == ShazamAnim.MERCURY_BLITZ) {
                        ShazamFlight.dash(mc.player); // terjangan tetap jalan walau sedang terbang
                    }
                    if (player == mc.player && anim == ShazamAnim.LINTANG_DASH) {
                        // 0.32 Lesatan Bintang: badan digerakkan client sendiri, lurus secepat cahaya
                        HeruDash.start(mc.player, pos, ShazamAnim.LESAT_WINDUP, ShazamAnim.LESAT_TICKS, 1.4);
                    }
                    if (player == mc.player && anim == ShazamAnim.LINTANG_COMBO) {   // 0.37 Kombo Langit: melesat ke sasaran
                        HeruDash.start(mc.player, pos, ShazamAnim.COMBO_DASH_WINDUP, ShazamAnim.COMBO_DASH_TICKS, 1.4);
                    }
                    if (player == mc.player && anim == ShazamAnim.LINTANG_COMBO_RISE) {   // naik ke atas sasaran
                        HeruDash.start(mc.player, pos, 0, ShazamAnim.COMBO_RISE_TICKS, 1.3);
                    }
                    if (player == mc.player && anim == ShazamAnim.LINTANG_COMBO_SMASH) {  // ikut menukik ke kawah
                        HeruDash.start(mc.player, pos, 1, ShazamAnim.COMBO_SMASH_TICKS, 1.8);
                    }
                    if (player == mc.player && anim == ShazamAnim.HELION_DASH) {   // 0.43 Hempasan Lesat: badan digerakkan client
                        HeruDash.start(mc.player, pos, ShazamAnim.HELION_DASH_WINDUP, ShazamAnim.HELION_DASH_TICKS, 1.6);
                    }
                    if (player == mc.player && anim == ShazamAnim.ADAM_HERU) {
                        HeruDash.start(mc.player, pos);   // terjangan elang Heru: badan digerakkan client sendiri (halus)
                    }
                }
            }
            ShazamPoses.tick(mc.level);
            ShazamCape.tick(mc.level);
            ShazamCinematic.tick(mc);
            ShazamEmblemLayer.tick(mc.level);
            ShazamSpirits.tick(mc.level);
            ShazamRage.tick(mc.level);
            AdamFx.tick(mc.level);
            SabbacCine.tick(mc.level);
            LintangCine.tick(mc.level);
            HelionFx.tick(mc.level);
            GodAvatars.tick(mc.level);
            ChampionFx.tick(mc.level);
            TrialFx.tick(mc.level);
            MercuryFx.tick(mc.level);
            ShazamFx.tick(mc.level);
            CameraShake.tick();
            ScreenFlash.tick();
            ScreenFx.tick();
            FovKick.tick();
            LintangShoulderCam.tick(mc);   // 0.44 kamera bahu selama sinar mata dipakai
        }

        @SubscribeEvent
        public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
            // Bersihkan semua supaya nggak kebawa ke world/server lain
            ShazamFlight.reset(Minecraft.getInstance().player);
            ShazamClientState.reset();
            ShazamPoses.clear();
            ShazamCape.clear();
            ShazamCinematic.restore(Minecraft.getInstance());
            ShazamSpirits.clear();
            ShazamRage.clear();
            AdamFx.clear();
            SabbacCine.clear();
            LintangCine.clear();
            HelionFx.clear();
            RivalPuppets.clear();
            GodAvatars.clear();
            ChampionFx.clear();
            TrialFx.clear();
            HeruDash.reset();
            ShazamFx.clear();
            MercuryMode.reset();
            MercuryFx.clear();
            CameraShake.clear();
            ScreenFlash.clear();
            FovKick.clear();
            LintangShoulderCam.clear();
        }

        /** Kendali terbang: kecepatan diatur sebelum pemain bergerak, lalu cek lepas landas/mendarat. */
        @SubscribeEvent
        public static void onPlayerTickPre(PlayerTickEvent.Pre event) {
            if (event.getEntity() instanceof LocalPlayer player) {
                ShazamFlight.preTick(player);
                MercuryMode.preTick(player);   // Mode Kilat: menerjang musuh / lari super cepat
                HeruDash.preTick(player);      // Sambaran Heru: paling akhir, menimpa kecepatan terbang/lari
            }
        }

        @SubscribeEvent
        public static void onPlayerTickPost(PlayerTickEvent.Post event) {
            if (event.getEntity() instanceof LocalPlayer player) {
                ShazamFlight.postTick(player);
                MercuryMode.postTick(player);
            }
        }

        /** Saat jadi Shazam, baris hati diganti bar darah di HUD. */
        @SubscribeEvent
        public static void onGuiLayer(RenderGuiLayerEvent.Pre event) {
            if (ShazamClientState.transformed && event.getName().equals(VanillaGuiLayers.PLAYER_HEALTH)) {
                event.setCanceled(true);
            }
        }

        @SubscribeEvent
        public static void onCameraAngles(ViewportEvent.ComputeCameraAngles event) {
            LintangShoulderCam.apply(event.getCamera(), (float) event.getPartialTick());   // 0.44 kamera bahu Iris Surya
            CameraShake.apply(event);
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) {
                event.setRoll(event.getRoll() + ShazamPoses.cameraRoll(mc.player, (float) event.getPartialTick()));
            }
        }

        @SubscribeEvent
        public static void onFov(ComputeFovModifierEvent event) {
            FovKick.apply(event);
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) {
                float speed = Math.max(ShazamPoses.flightSpeedFactor(mc.player, mc.getTimer().getGameTimeDeltaPartialTick(false)),
                        MercuryMode.speedFactor() * 0.8f);
                event.setNewFovModifier(event.getNewFovModifier() * (1f + 0.35f * speed)); // pandangan melebar saat ngebut
            }
        }

        /** 0.43 Tangan orang pertama Helion-6: lengan & sarung tangan kostum dengan jalur radiasinya. */
        @SubscribeEvent
        public static void onRenderArm(RenderArmEvent event) {
            HelionLayer.firstPersonArm(event.getPoseStack(), event.getMultiBufferSource(), event.getPackedLight(),
                    event.getPlayer(), event.getArm());
        }

        /** Titik asal render pemain, buat mengambil matriks badan yang benar-benar dipakai model. */
        @SubscribeEvent
        public static void onRenderPlayerPre(RenderPlayerEvent.Pre event) {
            ShazamPoses.beginBodyCapture(event.getPoseStack());
            // 0.42: Lintang nggak memakai kostum lagi (kulit asli pemain terlihat utuh, termasuk lapisan luarnya).
            // Saat sinar mata dipakai & kamera di belakangnya, kepalanya digambar tembus pandang (LintangHeadFade)
            if (event.getEntity() instanceof AbstractClientPlayer player) {
                LintangHeadFade.pre(player, event.getRenderer().getModel(), event.getPartialTick());
            }
        }

        /** Jubah dulu (bentuk kainnya frame ini juga dipakai bayangan Mercury yang baru), lalu bayangan berjejak. */
        @SubscribeEvent
        public static void onRenderPlayer(RenderPlayerEvent.Post event) {
            if (event.getEntity() instanceof AbstractClientPlayer player) {
                ShazamCape.render(player, event.getRenderer(), event.getPoseStack(),
                        event.getMultiBufferSource(), event.getPartialTick(), event.getPackedLight());
                ShazamPoses.renderGhosts(player, event.getRenderer(), event.getPoseStack(),
                        event.getMultiBufferSource(), event.getPartialTick());
            }
        }
    }
}
