package com.shazammod;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/** Jalur komunikasi client <-> server: tombol, data HUD, status juara (Shazam / Black Adam), dan animasi. */
@EventBusSubscriber(modid = ShazamMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public final class ShazamNetwork {
    private ShazamNetwork() {}

    public static final int ACTION_TRANSFORM = 0; // 1-7 = skill S-H-A-Z-A-M + amarah (dewa-dewa juara yang dipilih)
    public static final int ACTION_HOOD = 20;
    public static final int ACTION_FORM = 21;     // ganti juara: Shazam -> Black Adam -> Sabbac (cuma saat wujud manusia)
    public static final int ACTION_ADAM_CALL = 22; // Black Adam (tombol M): Panggil Petir Kahndaq; Sabbac: Panggil Petir Neraka
    public static final int ACTION_FAMILY = 23;    // 0.26 Shazam (tombol J): Kekuatan Keluarga; Sabbac: Pasukan Iblis
    public static final int ACTION_IRIS_CHARGE = 24; // 0.42 Lintang: X mulai ditahan (sinar mata di-charge)
    public static final int ACTION_IRIS_FIRE = 25;   // 0.42 Lintang: X dilepas (sinar ditembakkan sekuat charge-nya)

    @SubscribeEvent
    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("9");   // naikkan tiap format paket berubah
        registrar.playToServer(ShazamActionPayload.TYPE, ShazamActionPayload.STREAM_CODEC, ShazamNetwork::handleAction);
        registrar.playToServer(ShazamFlightPayload.TYPE, ShazamFlightPayload.STREAM_CODEC, ShazamNetwork::handleFlight);
        registrar.playToServer(ShazamMercuryPayload.TYPE, ShazamMercuryPayload.STREAM_CODEC, ShazamNetwork::handleMercury);
        registrar.playToClient(ShazamSyncPayload.TYPE, ShazamSyncPayload.STREAM_CODEC, ShazamNetwork::handleSync);
        registrar.playToClient(ShazamStatePayload.TYPE, ShazamStatePayload.STREAM_CODEC, ShazamNetwork::handleState);
        registrar.playToClient(ShazamAnimPayload.TYPE, ShazamAnimPayload.STREAM_CODEC, ShazamNetwork::handleAnim);
    }

    private static void handleAction(ShazamActionPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            if (!(context.player() instanceof ServerPlayer player)) {
                return;
            }
            int action = payload.action();
            if (action == ACTION_TRANSFORM) {
                ShazamPowers.onSayShazam(player);
            } else if (action >= 1 && action <= SKILL_SLOTS) {
                // tombol yang sama, dewa yang beda: Z X C V B N R = S-H-A-Z-A-M / S-A-B-B-A-C + amarah juara yang dipilih
                ShazamData data = ShazamPowers.data(player);
                if (data.isHelion()) {   // 0.43 H-E-L-I-O-N-6
                    HelionSkills.use(player, HelionSkills.Skill.values()[action - 1]);
                } else if (data.isLintang()) {   // 0.32 L-I-N-T-A-N-G
                    LintangSkills.use(player, LintangSkills.Skill.values()[action - 1]);
                } else if (data.isSabbac()) {
                    SabbacSkills.use(player, SabbacSkills.Skill.values()[action - 1]);
                } else if (data.isBlackAdam()) {
                    AdamSkills.use(player, AdamSkills.Skill.values()[action - 1]);
                } else {
                    ShazamSkills.use(player, ShazamSkills.Skill.values()[action - 1]);
                }
            } else if (action == ACTION_HOOD) {
                ShazamPowers.toggleHood(player);
            } else if (action == ACTION_FORM) {
                ShazamPowers.switchForm(player);
            } else if (action == ACTION_ADAM_CALL) {
                if (ShazamPowers.data(player).isHelion()) {
                    HelionSkills.inhale(player);   // 0.43 Hirup Cryon
                } else if (ShazamPowers.data(player).isLintang()) {
                    LintangSkills.sunCall(player);   // 0.32 Serap Surya
                } else if (ShazamPowers.data(player).isSabbac()) {
                    SabbacSkills.callLightning(player);   // 0.30 Panggil Petir Neraka
                } else {
                    AdamSkills.callLightning(player);
                }
            } else if (action == ACTION_IRIS_CHARGE) {
                LintangSkills.irisCharge(player);   // 0.42
            } else if (action == ACTION_IRIS_FIRE) {
                LintangSkills.irisFire(player);
            } else if (action == ACTION_FAMILY) {
                // tombol J: Shazam = Kekuatan Keluarga, Black Adam = Tangan Kahndaq (lempar balik proyektil yang tertahan),
                // Sabbac = Pasukan Iblis
                ShazamData data = ShazamPowers.data(player);
                if (data.isHelion()) {   // 0.45 Gerhana Buatan
                    HelionSkills.eclipse(player);
                } else if (data.isLintang()) {
                    LintangSkills.rescue(player);   // 0.32 Selamatkan
                } else if (data.isSabbac()) {
                    SabbacSkills.legion(player);
                } else if (data.isBlackAdam()) {
                    AdamCatch.release(player, true);
                } else {
                    ShazamFamily.use(player);
                }
            }
        });
    }

    private static void handleFlight(ShazamFlightPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            if (context.player() instanceof ServerPlayer player) {
                ShazamFlightServer.handle(player, payload.action(), payload.speed());
            }
        });
    }

    private static void handleMercury(ShazamMercuryPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            if (context.player() instanceof ServerPlayer player) {
                ShazamMercury.strike(player, payload.target(), payload.move());
            }
        });
    }

    private static void handleSync(ShazamSyncPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> ShazamClientState.update(payload));
    }

    private static void handleState(ShazamStatePayload payload, IPayloadContext context) {
        context.enqueueWork(() -> ShazamClientState.onState(payload));
    }

    private static void handleAnim(ShazamAnimPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> ShazamClientState.onAnim(payload));
    }

    /** Jumlah tombol skill tiap juara (enam dewa/iblis + amarah); ketiga juara sama banyak, jadi HUD-nya sama. */
    public static final int SKILL_SLOTS = 7;

    /** Data HUD (energi, cooldown skill juara yang dipilih, waktu pulih) untuk pemain itu sendiri. */
    public static void sync(ServerPlayer player) {
        ShazamData data = ShazamPowers.data(player);
        List<Integer> cooldowns = new ArrayList<>();
        boolean sabbac = data.isSabbac();
        boolean lintang = data.isLintang();   // 0.32
        boolean helion = data.isHelion();     // 0.43
        if (helion) {
            for (HelionSkills.Skill skill : HelionSkills.Skill.values()) {
                cooldowns.add(HelionSkills.cooldownTicks(player, skill));
            }
        } else if (lintang) {
            for (LintangSkills.Skill skill : LintangSkills.Skill.values()) {
                cooldowns.add(LintangSkills.cooldownTicks(player, skill));
            }
        } else if (sabbac) {
            for (SabbacSkills.Skill skill : SabbacSkills.Skill.values()) {
                cooldowns.add(SabbacSkills.cooldownTicks(player, skill));
            }
        } else if (data.isBlackAdam()) {
            for (AdamSkills.Skill skill : AdamSkills.Skill.values()) {
                cooldowns.add(AdamSkills.cooldownTicks(player, skill));
            }
        } else {
            for (ShazamSkills.Skill skill : ShazamSkills.Skill.values()) {
                cooldowns.add(ShazamSkills.cooldownTicks(player, skill));
            }
        }
        cooldowns.add(ShazamPowers.recoveryTicks(player));   // sesudah 7 skill: waktu pulih sesudah serangan mematikan
        // Panggil Petir Kahndaq (Black Adam) / 0.30 Panggil Petir Neraka (Sabbac)
        cooldowns.add(helion ? HelionSkills.inhaleCooldownTicks(player) : lintang ? LintangSkills.callCooldownTicks(player)
                : sabbac ? SabbacSkills.callCooldownTicks(player) : AdamSkills.callCooldownTicks(player));
        cooldowns.add(ShazamPassives.charge(player));          // Muatan Petir Shazam (0-100)
        cooldowns.add(ShazamPassives.dodgeCooldown(player));   // Refleks Mercury / Tangkisan Kahndaq / Kulit Bara: sisa jeda
        // 0.26 Kekuatan Keluarga / 0.30 Pasukan Iblis: sisa cooldown (tick)
        cooldowns.add(helion ? HelionSkills.eclipseCooldownTicks(player) : lintang ? LintangSkills.rescueCooldownTicks(player)
                : sabbac ? SabbacSkills.legionCooldownTicks(player) : ShazamFamily.cooldownTicks(player));
        // 0.27 Tangan Kahndaq: jumlah proyektil yang tertahan / 0.30 jumlah prajurit iblis yang masih bertarung
        cooldowns.add(helion ? HelionSkills.eclipseLeft(player.level(), player.position()) : lintang ? 0 : sabbac ? (data.transformed() ? SabbacSkills.legionCount(player) : 0) : AdamCatch.heldCount(player));
        // 0.31 Restu Para Dewa: tumpukan scaling Shazam (selalu 0 untuk Black Adam & Sabbac)
        cooldowns.add(ShazamFavor.stacks(player));
        // 0.32 Lintang: Daya Surya (persen), ikut cahaya tersimpan & Batu Kelam
        cooldowns.add(lintang ? LintangSkills.powerPercent(player) : helion ? HelionSkills.powerPercent(player) : 0);
        int flags = (data.anyUnlocked() ? ShazamSyncPayload.UNLOCKED : 0)
                | (data.transformed() ? ShazamSyncPayload.TRANSFORMED : 0)
                | (ShazamPowers.isInStorm(player) ? ShazamSyncPayload.STORM : 0)
                | ((data.isBlackAdam() || lintang || helion) && ShazamPowers.isInSun(player) ? ShazamSyncPayload.SUN : 0)
                | (data.unlocked() ? ShazamSyncPayload.HAS_SHAZAM : 0)
                | (data.adamUnlocked() ? ShazamSyncPayload.HAS_ADAM : 0)
                | (sabbac && ShazamPowers.isInDarkness(player) ? ShazamSyncPayload.DARK : 0)
                | (data.sabbacUnlocked() ? ShazamSyncPayload.HAS_SABBAC : 0)
                | ((lintang && LintangSkills.kelamExposed(player)) || (helion && HelionSkills.cryonWorld(player))
                        ? ShazamSyncPayload.KELAM : 0)
                | (lintang && LintangSkills.starlit(player) ? ShazamSyncPayload.STARLIGHT : 0)
                | (data.lintangUnlocked() ? ShazamSyncPayload.HAS_LINTANG : 0)
                | (data.helionUnlocked() ? ShazamSyncPayload.HAS_HELION : 0);
        PacketDistributor.sendToPlayer(player, new ShazamSyncPayload(flags, data.energy(), cooldowns,
                data.champion().ordinal()));
    }

    /** Status Shazam pemain ini, ke dirinya dan semua yang melihatnya. */
    public static void broadcastState(ServerPlayer player) {
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, statePayload(player));
    }

    public static void sendStateTo(ServerPlayer target, ServerPlayer viewer) {
        PacketDistributor.sendToPlayer(viewer, statePayload(target));
    }

    private static ShazamStatePayload statePayload(ServerPlayer player) {
        ShazamData data = ShazamPowers.data(player);
        boolean transformed = data.transformed();
        boolean rage = ShazamSkills.isRageActive(player) || AdamSkills.isRageActive(player) || SabbacSkills.isRageActive(player)
                || LintangSkills.isRageActive(player);
        return new ShazamStatePayload(player.getId(), transformed, transformed && player.getAbilities().flying, data.hoodUp(),
                transformed && rage, transformed && ShazamMercury.isActive(player), data.champion().ordinal(),
                transformed && ShazamPassives.isCharged(player));
    }

    /** Animasi untuk pemain lain saja (pemain itu sendiri sudah memutarnya duluan di client-nya). */
    public static void playAnimToOthers(ServerPlayer player, ShazamAnim anim) {
        playAnimToOthers(player, anim, player.position());
    }

    public static void playAnimToOthers(ServerPlayer player, ShazamAnim anim, Vec3 pos) {
        PacketDistributor.sendToPlayersTrackingEntity(player, new ShazamAnimPayload(player.getId(), anim.ordinal(),
                (float) pos.x, (float) pos.y, (float) pos.z));
    }

    public static void playAnim(ServerPlayer player, ShazamAnim anim) {
        playAnim(player, anim, player.position());
    }

    public static void playAnim(ServerPlayer player, ShazamAnim anim, Vec3 pos) {
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(player,
                new ShazamAnimPayload(player.getId(), anim.ordinal(), (float) pos.x, (float) pos.y, (float) pos.z));
    }
}
