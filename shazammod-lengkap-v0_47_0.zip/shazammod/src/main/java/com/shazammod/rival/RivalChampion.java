package com.shazammod.rival;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import com.shazammod.DemonSoldier;
import com.shazammod.MagicBolt;
import com.shazammod.PassiveConditions;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamAnimPayload;
import com.shazammod.ShazamEntities;
import com.shazammod.ShazamForm;
import com.shazammod.ShazamMod;
import com.shazammod.ShazamPowers;
import com.shazammod.ShazamSounds;

import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * 0.30 Rival Juara: Shazam, Black Adam, atau Sabbac versi AI yang datang menantangmu sebagai bos, dan bertarung dengan
 * skill yang sama persis dengan milik pemain: gerakan, efek, suara, dewa/iblis yang datang, dan pasif tiap 2 detiknya
 * (lengkap dengan aturan padam/menyala di PassiveConditions) diputar lewat jalur animasi yang sama (ShazamAnim). Angka
 * damage-nya disetel untuk duel juara (lihat RivalMoves).
 *
 * Alurnya:
 * 1. Datang (petir dari langit, atau semburan api neraka untuk Sabbac) dan menantang lewat judul di layar.
 * 2. Berubah wujud seperti pemain: dewa / iblisnya datang satu per satu, lalu petir menyambar. Selama ritual kebal.
 * 3. Menunggu penantangnya berubah wujud (rival cuma mau melawan juara). Kalau kamu nggak berubah dalam 30 detik, dia pergi.
 * 4. Duel. Kekuatannya setara juara, jadi damage-nya menembus tahan banting juara (ShazamMod.CHAMPION_CLASH) dan yang
 *    terkena kena Luka Juara (pulih tinggal setengah 5 detik). Begitu juga sebaliknya.
 * 5. Kalah: kekuatannya tercabut dari dada (animasi terlempar balik jadi manusia), lalu dia menghilang dan meninggalkan
 *    hadiah. Menang (penantangnya terlempar balik jadi manusia): dia pergi sambil mengejek.
 *
 * Di client rival ini nggak digambar sendiri: client.RivalPuppets membuat pemain boneka yang mengikuti posisinya, jadi
 * semua kode jubah, lambang, pose, dan efek yang sudah ada untuk pemain langsung berlaku.
 */
public class RivalChampion extends Monster {
    // ================= Angka-angka yang gampang diutak-atik =================
    public static final double HEALTH = 1200.0;
    public static final double SPEED = 0.36;
    public static final float PUNCH_DAMAGE = 20f;            // tinju biasa (kekuatan juara, menembus tahan banting)
    public static final int PUNCH_INTERVAL = 14;             // tinju paling sering tiap 0,7 detik
    public static final double PUNCH_REACH = 3.2;
    public static final int WAIT_TICKS = 600;                // menunggu penantang berubah wujud (30 detik)
    public static final int DEFEAT_TICKS = 70;               // tercabut kekuatannya, lalu menghilang
    public static final double LEASH = 72.0;                 // penantang lebih jauh dari ini: rival pergi
    public static final double FLY_SPEED = 0.95;             // blok/tick saat terbang mengejar
    public static final int XP_REWARD = 600;
    // pasif tiap 2 detik (angka sama dengan pemain)
    public static final float PULSE_HEAL = 40f;
    public static final float PULSE_SHIELD = 20f;
    public static final float REGEN_PER_SECOND = 3f;
    public static final int DEFENSE_COOLDOWN = 36;           // Refleks Mercury / Tangkisan Kahndaq / Kulit Bara
    // =========================================================================

    private static final EntityDataAccessor<Integer> DATA_FORM =
            SynchedEntityData.defineId(RivalChampion.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Byte> DATA_FLAGS =
            SynchedEntityData.defineId(RivalChampion.class, EntityDataSerializers.BYTE);
    public static final int TRANSFORMED = 1, FLYING = 2, RAGE = 4, MERCURY = 8, CHARGED = 16, HOOD = 32;

    public enum Phase { ARRIVE, RITUAL, WAIT, FIGHT, VICTORY, DEFEAT, LEAVE }

    /** Penantang yang sedang dilawan rival (satu rival per pemain). */
    static final Set<UUID> ACTIVE = new HashSet<>();

    private final ServerBossEvent bar = new ServerBossEvent(Component.literal(""), BossEvent.BossBarColor.YELLOW,
            BossEvent.BossBarOverlay.NOTCHED_10);
    private final List<Delayed> delayed = new ArrayList<>();
    private final List<Channel> channels = new ArrayList<>();
    final RivalMoves moves = new RivalMoves(this);

    private Phase phase = Phase.ARRIVE;
    private int phaseTicks;
    private UUID challenger;
    private int punchCooldown;
    private long woundUntil;
    private long nextPulse;
    private long defenseReady;
    private Boolean passiveOn;
    private int taunts;
    private boolean announcedFight;
    // 0.47 duel Lintang vs Helion-6: dua rival saling bertarung, penantangnya cuma saksi
    private boolean duel;
    private boolean primary;
    private UUID nemesisId;
    private UUID focusId;
    private long focusUntil;
    private long nextDuelLine;
    private int lonely;
    private final java.util.Map<UUID, Long> intruders = new java.util.HashMap<>();
    /** Jumlah variasi kalimat duel per kategori: datang, mulai, di tengah, menang, kalah (duel.shazammod.* di file bahasa). */
    static final int[] DUEL_LINES = {2, 2, 4, 2, 2};

    private static final class Delayed {
        int ticksLeft;
        final Runnable action;

        Delayed(int ticksLeft, Runnable action) {
            this.ticksLeft = ticksLeft;
            this.action = action;
        }
    }

    /** Efek yang berjalan beberapa tick (pusaran, semburan, rentetan pukulan): dipanggil tiap tick dengan tick ke-k. */
    interface Step {
        void run(int k);
    }

    private static final class Channel {
        final int length;
        final Step step;
        final Runnable end;
        int k;

        Channel(int length, Step step, Runnable end) {
            this.length = length;
            this.step = step;
            this.end = end;
        }
    }

    public RivalChampion(EntityType<? extends RivalChampion> type, Level level) {
        super(type, level);
        this.xpReward = 0;
        this.bar.setVisible(false);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, HEALTH)
                .add(Attributes.MOVEMENT_SPEED, SPEED)
                .add(Attributes.ATTACK_DAMAGE, PUNCH_DAMAGE)
                .add(Attributes.FOLLOW_RANGE, 64.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
                .add(Attributes.STEP_HEIGHT, 1.1)
                .add(Attributes.MAX_ABSORPTION, PULSE_SHIELD)
                .add(Attributes.ARMOR, 0.0);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_FORM, 0);
        builder.define(DATA_FLAGS, (byte) 0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
    }

    // ------------------------------------------------------------------ status (dibaca juga di client)

    public ShazamForm form() {
        return ShazamForm.byId(this.entityData.get(DATA_FORM));
    }

    public boolean flag(int bit) {
        return (this.entityData.get(DATA_FLAGS) & bit) != 0;
    }

    void setFlag(int bit, boolean on) {
        byte flags = this.entityData.get(DATA_FLAGS);
        byte next = (byte) (on ? flags | bit : flags & ~bit);
        if (next != flags) {
            this.entityData.set(DATA_FLAGS, next);
        }
    }

    public boolean isTransformedRival() {
        return flag(TRANSFORMED);
    }

    public Phase phase() {
        return phase;
    }

    /** 0.46 Juara sains (Lintang & Helion-6): datang, berubah, & pergi tanpa sihir (tanpa dewa, iblis, atau petir). */
    public boolean science() {
        ShazamForm form = form();
        return form == ShazamForm.LINTANG || form == ShazamForm.HELION;
    }

    /** Siapkan rival: juaranya dan penantangnya. Dipanggil sebelum masuk dunia. */
    public void setup(ShazamForm form, ServerPlayer target) {
        this.entityData.set(DATA_FORM, form.ordinal());
        this.challenger = target.getUUID();
        setFlag(HOOD, form == ShazamForm.SHAZAM || form == ShazamForm.BLACK_ADAM);   // 0.46 Lintang & Helion-6: tanpa hood
        this.setCustomName(Component.translatable("entity.shazammod.rival." + form.id));
        this.setCustomNameVisible(false);
        this.bar.setName(Component.translatable("bossbar.shazammod.rival", Component.translatable("champion.shazammod." + form.id)));
        this.bar.setColor(switch (form) {
            case BLACK_ADAM -> BossEvent.BossBarColor.YELLOW;
            case SABBAC -> BossEvent.BossBarColor.RED;
            case LINTANG -> BossEvent.BossBarColor.BLUE;    // 0.46
            case HELION -> BossEvent.BossBarColor.GREEN;
            default -> BossEvent.BossBarColor.WHITE;
        });
        ACTIVE.add(target.getUUID());
    }

    public UUID challengerId() {
        return challenger;
    }

    /** 0.47 Siapkan rival untuk duel melawan rival lain; witness = pemain yang menyaksikan (dapat judul & hadiahnya). */
    public void setupDuel(ShazamForm form, ServerPlayer witness, boolean primary) {
        setup(form, witness);
        this.duel = true;
        this.primary = primary;
    }

    public void setNemesis(UUID id) {
        this.nemesisId = id;
    }

    public boolean isDuel() {
        return duel;
    }

    /** Lawan duel rival ini (masih hidup), atau null. */
    RivalChampion nemesis() {
        if (nemesisId == null || !(this.level() instanceof ServerLevel level)) {
            return null;
        }
        return level.getEntity(nemesisId) instanceof RivalChampion rival && rival.isAlive() ? rival : null;
    }

    /** Yang dihadapi saat datang & berubah wujud: lawan duelnya, atau penantangnya. */
    private LivingEntity focus(ServerPlayer target) {
        if (duel) {
            RivalChampion foe = nemesis();
            if (foe != null) {
                return foe;
            }
        }
        return target;
    }

    ServerPlayer challenger() {
        if (challenger == null || !(this.level() instanceof ServerLevel level)) {
            return null;
        }
        ServerPlayer player = level.getServer().getPlayerList().getPlayer(challenger);
        return player != null && player.level() == this.level() ? player : null;
    }

    // ------------------------------------------------------------------ alat bantu untuk RivalMoves

    ServerLevel serverLevel() {
        return (ServerLevel) this.level();
    }

    /** Animasi dari rival ini ke semua pemain yang melihatnya (di client diputar di pemain bonekanya). */
    public void anim(ShazamAnim anim, Vec3 pos) {
        if (this.level().isClientSide) {
            return;
        }
        PacketDistributor.sendToPlayersTrackingEntity(this, new ShazamAnimPayload(this.getId(), anim.ordinal(),
                (float) pos.x, (float) pos.y, (float) pos.z));
    }

    public void anim(ShazamAnim anim) {
        anim(anim, this.position());
    }

    void sound(Vec3 at, SoundEvent sound, float volume, float pitch) {
        this.level().playSound(null, at.x, at.y, at.z, sound, SoundSource.HOSTILE, volume, pitch);
    }

    /** Jalankan beberapa tick lagi (dibatalkan kalau rival kalah / pergi). */
    void later(int ticks, Runnable action) {
        delayed.add(new Delayed(Math.max(1, ticks), action));
    }

    /** Efek berdurasi: step dipanggil tiap tick selama length tick, lalu end. */
    void channel(int length, Step step, Runnable end) {
        channels.add(new Channel(length, step, end));
    }

    /** Damage kekuatan juara: menembus armor & tahan banting juara (lihat ShazamPowers.onIncomingDamage). */
    public static DamageSource clash(Level level, Entity attacker) {
        return new DamageSource(level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE)
                .getHolderOrThrow(ShazamMod.CHAMPION_CLASH), attacker);
    }

    DamageSource clash() {
        return clash(this.level(), this);
    }

    /** Lawan rival: juara (pemain yang sedang berubah wujud), hewan peliharaan, golem besi, dan prajurit iblis sekutu. */
    boolean isFoe(LivingEntity entity) {
        if (entity == this || !entity.isAlive()) {
            return false;
        }
        if (duel) {   // 0.47 duel: lawannya cuma rival seterunya, plus juara yang ikut campur menyerang (sebentar)
            if (entity instanceof RivalChampion other) {
                return other.getUUID().equals(nemesisId) && other.phase == Phase.FIGHT;
            }
            if (entity instanceof ServerPlayer player) {
                Long until = intruders.get(player.getUUID());
                return until != null && until > this.level().getGameTime() && ShazamPowers.isTransformed(player)
                        && !player.isCreative() && !player.isSpectator();
            }
            return false;
        }
        if (entity instanceof ServerPlayer player) {
            return ShazamPowers.isTransformed(player) && !player.isCreative() && !player.isSpectator();
        }
        return (entity instanceof TamableAnimal pet && pet.isTame()) || entity instanceof IronGolem
                || DemonSoldier.isFriendly(entity);
    }

    List<LivingEntity> foes(Vec3 center, double radius) {
        return this.level().getEntitiesOfClass(LivingEntity.class, new AABB(center, center).inflate(radius),
                m -> isFoe(m) && m.distanceToSqr(center) <= radius * radius);
    }

    /** Lukai lawan dengan kekuatan juara (damage sudah dikali skala rival di RivalMoves). */
    boolean hit(LivingEntity target, float damage) {
        if (!isFoe(target)) {
            return false;
        }
        return target.hurt(clash(), damage * moves.damageBonus(target));
    }

    /** Petir sihir juara ini (warna & arahnya ikut juaranya). */
    void bolt(Vec3 at, float size) {
        ShazamPowers.spawnBolt(serverLevel(), at, size, form().boltVariant());
    }

    float healScale() {
        return woundUntil > this.level().getGameTime() ? ShazamPowers.WOUND_HEAL_MULTIPLIER : 1f;
    }

    void healRival(float amount) {
        this.heal(amount * healScale());
    }

    // ------------------------------------------------------------------ tiap tick

    @Override
    public void aiStep() {
        super.aiStep();
        if (!this.level().isClientSide) {
            this.fallDistance = 0f;
            if (this.isOnFire()) {
                this.clearFire();
            }
            // nggak perlu napas seperti juara pemain (canBreatheUnderwater() di LivingEntity final, nggak bisa di-override)
            if (this.getAirSupply() < this.getMaxAirSupply()) {
                this.setAirSupply(this.getMaxAirSupply());
            }
        }
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        runDelayed();
        runChannels();
        bar.setProgress(Mth.clamp(this.getHealth() / this.getMaxHealth(), 0f, 1f));
        phaseTicks++;
        ServerPlayer target = challenger();
        switch (phase) {
            case ARRIVE -> tickArrive(target);
            case RITUAL -> tickRitual(target);
            case WAIT -> tickWait(target);
            case FIGHT -> tickFight(target);
            case VICTORY, LEAVE -> {
                if (phaseTicks >= 50) {
                    depart(false);
                }
                hover(duel ? null : target, 6.0);
            }
            case DEFEAT -> {
                this.getNavigation().stop();
                this.setDeltaMovement(this.getDeltaMovement().multiply(0.6, 1.0, 0.6));
                if (phaseTicks >= DEFEAT_TICKS) {
                    depart(true);
                }
            }
        }
    }

    private void runDelayed() {
        if (delayed.isEmpty()) {
            return;
        }
        List<Delayed> due = new ArrayList<>();
        Iterator<Delayed> it = delayed.iterator();
        while (it.hasNext()) {
            Delayed d = it.next();
            if (--d.ticksLeft <= 0) {
                due.add(d);
                it.remove();
            }
        }
        for (Delayed d : due) {
            if (this.isAlive() && !this.isRemoved()) {
                d.action.run();
            }
        }
    }

    private void runChannels() {
        if (channels.isEmpty()) {
            return;
        }
        List<Channel> done = new ArrayList<>();
        for (Channel c : new ArrayList<>(channels)) {
            if (c.k < c.length) {
                c.step.run(c.k);
            }
            c.k++;
            if (c.k >= c.length) {
                done.add(c);
            }
        }
        channels.removeAll(done);
        for (Channel c : done) {
            if (c.end != null && this.isAlive()) {
                c.end.run();
            }
        }
    }

    private void cancelAll() {
        delayed.clear();
        channels.clear();
        moves.reset();
    }

    private void setPhase(Phase next) {
        phase = next;
        phaseTicks = 0;
    }

    // ------------------------------------------------------------------ 1. datang

    private void tickArrive(ServerPlayer target) {
        if (phaseTicks == 1) {
            Vec3 pos = this.position();
            if (science()) {   // 0.46 Lintang & Helion-6: menukik dari langit & menghantam tanah (kawah, dentum sonik)
                anim(ShazamAnim.CRASH, pos);
                sound(pos, ShazamSounds.HERO_LAND.get(), 3.0f, 0.85f);
                sound(pos, ShazamSounds.SONIC_BOOM.get(), 2.5f, 1f);
                if (form() == ShazamForm.HELION) {
                    sound(pos, ShazamSounds.GEIGER.get(), 2.0f, 1f);
                }
            } else {
                anim(ShazamAnim.RIVAL_ARRIVE, pos);
                bolt(pos, 2.2f);
                sound(pos, ShazamSounds.RIVAL_ARRIVE.get(), 3.0f, 1f);
                sound(pos, ShazamSounds.THUNDER.get(), 3.0f, ShazamSounds.tune(0.6f));
            }
            if (duel) {   // 0.47 duel: judul untuk saksi & balon kata pembuka
                duelArrive(target);
            } else if (target != null) {
                ShazamForm form = form();
                target.connection.send(new ClientboundSetTitlesAnimationPacket(10, 60, 20));
                target.connection.send(new ClientboundSetTitleTextPacket(Component.translatable("champion.shazammod." + form.id)
                        .withStyle(titleColor(), ChatFormatting.BOLD)));
                target.connection.send(new ClientboundSetSubtitleTextPacket(Component.translatable("title.shazammod.rival_challenge")
                        .withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC)));
                speak(target, "arrive");
            }
        }
        face(focus(target));
        if (phaseTicks >= 24) {
            setPhase(Phase.RITUAL);
        }
    }

    ChatFormatting titleColor() {
        return switch (form()) {
            case BLACK_ADAM -> ChatFormatting.GOLD;
            case SABBAC -> ChatFormatting.DARK_RED;
            case LINTANG -> ChatFormatting.AQUA;   // 0.46
            case HELION -> ChatFormatting.GREEN;
            default -> ChatFormatting.YELLOW;
        };
    }

    /** Ucapan rival di chat, untuk penantang dan pemain di sekitar. */
    void speak(ServerPlayer target, String line) {
        Component text = Component.translatable("speaker.shazammod.rival", Component.translatable("champion.shazammod." + form().id))
                .withStyle(titleColor(), ChatFormatting.BOLD).append(Component.literal(" "))
                .append(Component.translatable("rival.shazammod." + form().id + "." + line).withStyle(ChatFormatting.ITALIC));
        for (ServerPlayer player : serverLevel().players()) {
            if (player.distanceToSqr(this) < 48 * 48 || player == target) {
                player.sendSystemMessage(text);
            }
        }
    }

    // ------------------------------------------------------------------ 2. ritual berubah (sama seperti pemain)

    private void tickRitual(ServerPlayer target) {
        this.getNavigation().stop();
        face(focus(target));
        if (science()) {   // 0.46 berubah seperti pemainnya: Lintang ganti kostum secepat kilat, Helion-6 radiasinya meledak
            int suit = form() == ShazamForm.HELION ? ShazamAnim.HELION_SUITUP : ShazamAnim.LINTANG_SUITUP;
            if (phaseTicks == 1) {
                anim(ShazamAnim.TRANSFORM);
                if (form() == ShazamForm.HELION) {
                    sound(this.position(), ShazamSounds.HELION_TRANSFORM.get(), 1.8f, 1f);
                }
            } else if (phaseTicks == 1 + suit) {
                transformNow();
                moves.transformed();
                afterTransform(target);
            }
            return;
        }
        if (phaseTicks == 1) {
            anim(ShazamAnim.SUMMON);
            float pitch = form() == ShazamForm.SABBAC ? 0.45f : form() == ShazamForm.BLACK_ADAM ? 0.55f : 0.8f;
            sound(this.position(), ShazamSounds.AURA_SWELL.get(), 1.4f, ShazamSounds.tune(pitch));
        } else if (phaseTicks == 1 + ShazamAnim.SUMMON_TICKS) {
            anim(ShazamAnim.TRANSFORM);
        } else if (phaseTicks == 1 + ShazamAnim.SUMMON_TICKS + ShazamAnim.TRANSFORM_WINDUP) {
            descendingBolt();
        } else if (phaseTicks == 1 + ShazamAnim.SUMMON_TICKS + ShazamAnim.TRANSFORM_STRIKE) {
            transformNow();
            afterTransform(target);
        }
    }

    /** Petir transformasi turun pelan ke kepalan (Sabbac: menyembur naik dari bawah kaki). */
    private void descendingBolt() {
        MagicBolt bolt = ShazamEntities.MAGIC_BOLT.get().create(this.level());
        Vec3 at = form() == ShazamForm.SABBAC ? this.position()
                : this.position().add(0, ShazamPowers.FIST_HEIGHT * this.getScale(), 0);
        if (bolt != null) {
            bolt.moveTo(at.x, at.y, at.z);
            bolt.setBoltSize(2.4f);
            bolt.setDescent(ShazamAnim.BOLT_DESCENT);
            bolt.setVariant(form().boltVariant());
            this.level().addFreshEntity(bolt);
        }
        sound(at, ShazamSounds.THUNDER.get(), 4.0f, ShazamSounds.tune(0.6f));
        sound(this.position(), ShazamSounds.RISER.get(), 2.0f, 1.3f);
    }

    private void transformNow() {
        setFlag(TRANSFORMED, true);
        AttributeInstance scale = this.getAttribute(Attributes.SCALE);
        if (scale != null) {
            scale.setBaseValue(science() ? 1.0 : form() == ShazamForm.SABBAC ? 1.0 + ShazamPowers.GROWTH + ShazamPowers.SABBAC_GROWTH
                    : 1.0 + ShazamPowers.GROWTH);
        }
        this.setHealth(this.getMaxHealth());
        Vec3 pos = this.position();
        var transformSound = switch (form()) {
            case BLACK_ADAM -> ShazamSounds.TRANSFORM_ADAM;
            case SABBAC -> ShazamSounds.TRANSFORM_SABBAC;
            case LINTANG -> ShazamSounds.TRANSFORM_LINTANG;   // 0.46
            case HELION -> ShazamSounds.HELION_BURST;
            default -> ShazamSounds.TRANSFORM;
        };
        sound(pos, transformSound.get(), 4.0f, 1f);
        for (int i = 0; i < (science() ? 0 : 4); i++) {   // 0.46 juara sains: tanpa petir
            double angle = this.random.nextDouble() * Math.PI * 2.0;
            double distance = 2.0 + this.random.nextDouble() * 2.0;
            bolt(pos.add(Math.cos(angle) * distance, 0, Math.sin(angle) * distance), 0.7f);
        }
        nextPulse = this.level().getGameTime() + 40;
        bar.setVisible(true);
    }

    private void startFight(ServerPlayer target) {
        setPhase(Phase.FIGHT);
        moves.startFight();
        if (!announcedFight) {
            announcedFight = true;
            if (duel) {
                duelLine(1, true);
            } else {
                speak(target, "fight");
            }
        }
    }

    /** Sesudah berubah wujud: duel menunggu lawannya ikut berubah, rival biasa menunggu / langsung melawan penantangnya. */
    private void afterTransform(ServerPlayer target) {
        if (duel) {
            setPhase(Phase.WAIT);
            return;
        }
        if (target != null && ShazamPowers.isTransformed(target)) {
            startFight(target);
        } else {
            setPhase(Phase.WAIT);
            if (target != null) {
                speak(target, "taunt");
            }
        }
    }

    // ------------------------------------------------------------------ 0.47 duel Lintang vs Helion-6

    /** Balon kata duel (dilihat semua yang di dekatnya): kategori 0 datang, 1 mulai, 2 di tengah, 3 menang, 4 kalah. */
    void duelLine(int category, boolean shout) {
        int count = DUEL_LINES[Mth.clamp(category, 0, DUEL_LINES.length - 1)];
        anim(ShazamAnim.HELION_DUEL_LINE, new Vec3(this.random.nextInt(count), category, shout ? 1 : 0));
    }

    private void duelArrive(ServerPlayer witness) {
        if (primary && witness != null) {
            witness.connection.send(new ClientboundSetTitlesAnimationPacket(10, 70, 20));
            witness.connection.send(new ClientboundSetTitleTextPacket(Component.translatable("title.shazammod.duel")
                    .withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD)));
            witness.connection.send(new ClientboundSetSubtitleTextPacket(Component.translatable("title.shazammod.duel_sub")
                    .withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC)));
        }
        later(primary ? 8 : 22, () -> duelLine(0, false));   // saling sapa bergantian
    }

    private void tickDuelWait(ServerPlayer witness) {
        RivalChampion foe = nemesis();
        if (foe == null) {
            leave(witness, "leave");
            return;
        }
        face(foe);
        tickPassive();
        if (foe.isTransformedRival() && (foe.phase == Phase.WAIT || foe.phase == Phase.FIGHT)) {
            startFight(witness);
            nextDuelLine = this.level().getGameTime() + 120 + this.random.nextInt(120);
            return;
        }
        if (phaseTicks > 200) {
            leave(witness, "leave");
        }
    }

    /** Duel: lawan utamanya rival seteru; juara yang ikut campur diladeni sebentar. Sahut-sahutan balon kata di tengahnya. */
    private void tickDuel(ServerPlayer witness) {
        RivalChampion foe = nemesis();
        long now = this.level().getGameTime();
        if (foe == null || foe.phase == Phase.DEFEAT || foe.phase == Phase.LEAVE || foe.phase == Phase.VICTORY) {
            boolean beaten = foe != null && foe.phase == Phase.DEFEAT;
            setPhase(Phase.VICTORY);
            cancelAll();
            if (beaten) {
                duelLine(3, true);
            }
            return;
        }
        if (witness == null || witness.distanceToSqr(this) > 128.0 * 128.0) {   // nggak ada yang menonton: lama-lama bubar
            if (++lonely > 600) {
                leave(witness, "leave");
                return;
            }
        } else {
            lonely = 0;
        }
        tickPassive();
        LivingEntity target = foe;
        if (focusId != null && now < focusUntil) {
            ServerPlayer intruder = serverLevel().getServer().getPlayerList().getPlayer(focusId);
            if (intruder != null && isFoe(intruder)) {
                target = intruder;
            }
        }
        if (now >= nextDuelLine && target == foe) {
            nextDuelLine = now + 200 + this.random.nextInt(160);
            duelLine(2, this.random.nextInt(3) == 0);
        }
        this.setTarget(target);
        face(target);
        moves.tick(target);
        if (moves.busy()) {
            return;
        }
        moveToward(target);
        meleeTick(target);
    }

    // ------------------------------------------------------------------ 3. menunggu penantang berubah wujud

    private void tickWait(ServerPlayer target) {
        if (duel) {
            tickDuelWait(target);
            return;
        }
        if (target == null || !target.isAlive() || target.distanceToSqr(this) > LEASH * LEASH) {
            leave(target, "leave");
            return;
        }
        hover(target, 6.0);
        face(target);
        tickPassive();
        if (ShazamPowers.isTransformed(target)) {
            startFight(target);
            return;
        }
        if (phaseTicks % 120 == 60 && taunts < 4) {
            taunts++;
            target.displayClientMessage(Component.translatable("rival.shazammod.wait", Component.translatable(
                    "champion.shazammod." + form().id), (WAIT_TICKS - phaseTicks) / 20).withStyle(titleColor()), true);
        }
        if (phaseTicks >= WAIT_TICKS) {
            leave(target, "coward");
        }
    }

    /** Berdiri / melayang tak jauh dari penantang (tanpa menyerang). */
    private void hover(ServerPlayer target, double keep) {
        if (target == null) {
            return;
        }
        double d = Math.sqrt(this.distanceToSqr(target));
        if (d > keep + 3.0) {
            this.getNavigation().moveTo(target, 1.0);
        } else {
            this.getNavigation().stop();
        }
    }

    void face(LivingEntity target) {
        if (target != null) {
            this.getLookControl().setLookAt(target, 60f, 60f);
            double dx = target.getX() - this.getX(), dz = target.getZ() - this.getZ();
            if (dx * dx + dz * dz > 1.0E-4) {
                float yaw = (float) (Mth.atan2(dz, dx) * Mth.RAD_TO_DEG) - 90f;
                this.setYRot(yaw);
                this.yBodyRot = yaw;
                this.yHeadRot = yaw;
            }
        }
    }

    // ------------------------------------------------------------------ 4. duel

    private void tickFight(ServerPlayer challengerPlayer) {
        if (duel) {
            tickDuel(challengerPlayer);
            return;
        }
        LivingEntity target = pickTarget(challengerPlayer);
        if (challengerPlayer == null || !challengerPlayer.isAlive()
                || challengerPlayer.distanceToSqr(this) > LEASH * LEASH) {
            if (target == null) {
                leave(challengerPlayer, "leave");
                return;
            }
        } else if (!ShazamPowers.isTransformed(challengerPlayer) && phaseTicks > 20) {
            // penantangnya terlempar balik jadi manusia (atau berhenti jadi juara): rival menang
            setPhase(Phase.VICTORY);
            cancelAll();
            speak(challengerPlayer, "victory");
            anim(ShazamAnim.REVERT);
            return;
        }
        tickPassive();
        if (target == null) {
            hover(challengerPlayer, 5.0);
            return;
        }
        this.setTarget(target);
        face(target);
        moves.tick(target);
        if (moves.busy()) {
            return;
        }
        moveToward(target);
        meleeTick(target);
    }

    /** Sasaran: penantang kalau masih juara di dekat, atau juara terdekat yang terakhir menyerang rival. */
    private LivingEntity pickTarget(ServerPlayer challengerPlayer) {
        if (challengerPlayer != null && isFoe(challengerPlayer) && challengerPlayer.distanceToSqr(this) < LEASH * LEASH) {
            return challengerPlayer;
        }
        LivingEntity last = this.getLastHurtByMob();
        if (last != null && isFoe(last) && last.distanceToSqr(this) < 48 * 48) {
            return last;
        }
        List<LivingEntity> near = foes(this.position(), 32.0);
        near.sort(Comparator.comparingDouble(m -> m.distanceToSqr(this)));
        return near.isEmpty() ? null : near.get(0);
    }

    /** Jalan / lari di tanah, atau terbang kalau sasarannya di udara, jauh, atau nggak terjangkau. */
    private void moveToward(LivingEntity target) {
        double dx = target.getX() - this.getX(), dz = target.getZ() - this.getZ();
        double dy = target.getY() - this.getY();
        double flat = Math.sqrt(dx * dx + dz * dz);
        boolean targetFlying = !target.onGround() && !target.isInWater()
                && ((target instanceof ServerPlayer p && p.getAbilities().flying) || (target instanceof RivalChampion rc && rc.flag(FLYING)));
        boolean fly = dy > 2.5 || targetFlying || flat > 22.0 || (this.getNavigation().isDone() && flat > 4.0
                && this.tickCount % 40 == 0) || flag(FLYING) && (dy > 0.8 || flat > 6.0 || !this.onGround());
        if (fly) {
            startFlying();
            this.getNavigation().stop();
            Vec3 goal = target.position().add(0, target.getBbHeight() * 0.4 + 0.3, 0);
            Vec3 to = goal.subtract(this.position());
            double d = to.length();
            Vec3 want = d < 2.2 ? Vec3.ZERO : to.normalize().scale(Math.min(FLY_SPEED, d * 0.25));
            Vec3 v = this.getDeltaMovement();
            this.setDeltaMovement(v.add(want.subtract(v).scale(0.3)));
            if (!targetFlying && dy < 0.8 && flat < 5.0 && target.onGround()) {
                land();
            }
        } else {
            land();
            if (flat > PUNCH_REACH - 0.6) {
                this.getNavigation().moveTo(target, flat > 10.0 ? 1.35 : 1.15);
            } else {
                this.getNavigation().stop();
            }
        }
    }

    void startFlying() {
        if (!flag(FLYING)) {
            setFlag(FLYING, true);
            this.setNoGravity(true);
            if (this.onGround()) {
                anim(ShazamAnim.LAUNCH);
                this.setDeltaMovement(this.getDeltaMovement().add(0, 0.7, 0));
            }
        }
    }

    void land() {
        if (flag(FLYING)) {
            setFlag(FLYING, false);
            this.setNoGravity(false);
            anim(this.getDeltaMovement().y < -0.6 ? ShazamAnim.LAND_HERO : ShazamAnim.LAND_SOFT);
        }
    }

    private void meleeTick(LivingEntity target) {
        if (punchCooldown > 0) {
            punchCooldown--;
        }
        double reach = PUNCH_REACH * this.getScale();
        if (punchCooldown > 0 || this.distanceToSqr(target) > reach * reach || !this.hasLineOfSight(target)) {
            return;
        }
        punchCooldown = PUNCH_INTERVAL;
        this.swing(InteractionHand.MAIN_HAND);
        moves.punch(target);
    }

    // ------------------------------------------------------------------ pasif tiap 2 detik & pulih

    private void tickPassive() {
        if (!isTransformedRival()) {
            return;
        }
        long now = this.level().getGameTime();
        if (this.tickCount % 10 == 0 && this.getHealth() < this.getMaxHealth()) {
            healRival(REGEN_PER_SECOND / 2f);
        }
        boolean allowed = PassiveConditions.allowed(this.level(), this.blockPosition(), form(), this.isUnderWater());
        if (passiveOn == null) {
            passiveOn = allowed;
        } else if (allowed != passiveOn) {
            passiveOn = allowed;
            moves.passiveChanged(allowed);
            nextPulse = now + (allowed ? ShazamAnim.FIRE_IN_TICKS : 40);
        }
        if (!passiveOn) {
            nextPulse = Math.max(nextPulse, now + 40);
            return;
        }
        if (now >= nextPulse) {
            nextPulse = now + 40;
            moves.pulse();
        }
    }

    /** Hasil denyut tiap 2 detik: darah pulih, perisai hati emas, pukulan berikutnya penuh muatan. */
    void empower() {
        healRival(PULSE_HEAL);
        if (this.getAbsorptionAmount() < PULSE_SHIELD) {
            this.setAbsorptionAmount(PULSE_SHIELD);
        }
        setFlag(CHARGED, true);
    }

    // ------------------------------------------------------------------ damage masuk

    /**
     * Dipanggil dari ShazamPowers.onIncomingDamage (sesudah pengali tinju & skill juara dihitung). Rival kebal selama
     * datang & ritual, pasif bertahannya (menghindar / menahan / menelan) jalan, dan skill bertahannya mengurangi damage.
     */
    public void onIncomingDamage(LivingIncomingDamageEvent event) {
        DamageSource source = event.getSource();
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return;
        }
        Entity attacker = source.getEntity();
        boolean nemesisHit = duel && attacker instanceof RivalChampion other && other.getUUID().equals(nemesisId);   // 0.47 duel
        if ((attacker instanceof RivalChampion && !nemesisHit) || (attacker instanceof DemonSoldier soldier && !soldier.isAlly())) {
            event.setCanceled(true);
            return;
        }
        if (duel && phase == Phase.FIGHT && attacker instanceof ServerPlayer intruder && ShazamPowers.isTransformed(intruder)) {
            intruders.put(intruder.getUUID(), this.level().getGameTime() + 200);   // juara yang ikut campur jadi lawan sebentar
            if (this.random.nextInt(2) == 0) {
                focusId = intruder.getUUID();
                focusUntil = this.level().getGameTime() + 100;
            }
        }
        if (phase != Phase.FIGHT) {
            event.setCanceled(true);
            if (phase == Phase.WAIT && attacker instanceof ServerPlayer player && !ShazamPowers.isTransformed(player)) {
                // manusia biasa berani memukul: didorong menjauh, tanpa dilukai
                Vec3 away = player.position().subtract(this.position());
                away = away.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : away.normalize();
                player.push(away.x * 1.4, 0.4, away.z * 1.4);
                player.hurtMarked = true;
                player.displayClientMessage(Component.translatable("rival.shazammod.human_hit").withStyle(titleColor()), true);
            }
            return;
        }
        // kebal seperti juara: jatuh, api, lava, petir, tenggelam, beku
        if (source.is(DamageTypeTags.IS_FALL) || source.is(DamageTypeTags.IS_FIRE) || source.is(DamageTypeTags.IS_LIGHTNING)
                || source.is(DamageTypeTags.IS_DROWNING) || source.is(DamageTypeTags.IS_FREEZING) || source.is(DamageTypes.CACTUS)
                || source.is(DamageTypes.IN_WALL)) {
            event.setCanceled(true);
            return;
        }
        if (moves.defend(source, defenseReady <= this.level().getGameTime())) {
            defenseReady = this.level().getGameTime() + DEFENSE_COOLDOWN;
            event.setCanceled(true);
            return;
        }
        event.setAmount(event.getAmount() * moves.damageTakenMultiplier(source, event.getAmount()));
        if (attacker instanceof ServerPlayer player && ShazamPowers.isTransformed(player)) {
            woundUntil = this.level().getGameTime() + ShazamPowers.WOUND_TICKS;   // Luka Juara: pulihnya tinggal setengah
            if (challenger == null || !player.getUUID().equals(challenger)) {
                this.setLastHurtByMob(player);
            }
        }
    }

    /** Damage final yang bakal menghabisi rival: dibatalkan, rival kalah (kekuatannya tercabut, lalu menghilang). */
    public void onDamagePre(LivingDamageEvent.Pre event) {
        if (event.getContainer().getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return;
        }
        float toHealth = event.getContainer().getNewDamage() - this.getAbsorptionAmount();
        if (phase != Phase.FIGHT) {
            event.getContainer().setNewDamage(0f);
            return;
        }
        if (toHealth >= this.getHealth()) {
            event.getContainer().setNewDamage(0f);
            defeat();
        }
    }

    private void defeat() {
        cancelAll();
        setPhase(Phase.DEFEAT);
        land();
        anim(ShazamAnim.KNOCKOUT);
        sound(this.position(), ShazamSounds.POWER_DOWN.get(), 1.8f, 0.7f);
        sound(this.position(), ShazamSounds.BODY_HIT.get(), 1.4f, 0.8f);
        setFlag(TRANSFORMED, false);
        setFlag(RAGE, false);
        setFlag(MERCURY, false);
        setFlag(CHARGED, false);
        this.setHealth(Math.max(1f, this.getMaxHealth() * 0.05f));
        AttributeInstance scale = this.getAttribute(Attributes.SCALE);
        if (scale != null) {
            scale.setBaseValue(1.0);
        }
        ServerPlayer target = challenger();
        if (duel) {
            duelLine(4, false);
        } else if (target != null) {
            speak(target, "defeat");
        }
        bar.setProgress(0f);
    }

    // ------------------------------------------------------------------ pergi

    private void leave(ServerPlayer target, String line) {
        if (phase == Phase.LEAVE) {
            return;
        }
        cancelAll();
        setPhase(Phase.LEAVE);
        if (target != null) {
            speak(target, line);
        }
    }

    /** Menghilang dalam petir (atau semburan api neraka). Kalah: hadiahnya tertinggal. */
    private void depart(boolean defeated) {
        Vec3 pos = this.position();
        if (science()) {   // 0.46 melesat ke langit secepat kilat (kerucut uap & dentum sonik)
            anim(ShazamAnim.LAUNCH, pos);
            anim(ShazamAnim.SONIC_BOOM, pos);
            sound(pos, ShazamSounds.SONIC_BOOM.get(), 3.0f, 1f);
        } else {
            anim(ShazamAnim.RIVAL_DEPART, pos);
            bolt(pos, 1.8f);
            sound(pos, ShazamSounds.THUNDER.get(), 3.0f, ShazamSounds.tune(0.7f));
        }
        if (defeated) {
            dropRewards(pos);
            ServerPlayer target = challenger();
            if (duel && target != null) {   // 0.47 duel: saksinya diberi tahu siapa yang menang
                String winner = form() == ShazamForm.LINTANG ? "helion" : "lintang";
                target.displayClientMessage(Component.translatable("duel.shazammod.result",
                        Component.translatable("champion.shazammod." + winner), Component.translatable("champion.shazammod." + form().id))
                        .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), true);
            } else if (target != null) {
                target.displayClientMessage(Component.translatable("rival.shazammod.won",
                        Component.translatable("champion.shazammod." + form().id)).withStyle(ChatFormatting.GOLD,
                        ChatFormatting.BOLD), true);
            }
        }
        this.discard();
    }

    private void dropRewards(Vec3 pos) {
        ServerLevel level = serverLevel();
        ExperienceOrb.award(level, pos, XP_REWARD);
        List<ItemStack> loot = RivalSpawner.rewards(form(), this.random);
        for (ItemStack stack : loot) {
            ItemEntity item = new ItemEntity(level, pos.x, pos.y + 0.8, pos.z, stack);
            item.setDefaultPickUpDelay();
            item.setGlowingTag(true);
            level.addFreshEntity(item);
        }
    }

    // ------------------------------------------------------------------ boss bar & siklus hidup

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bar.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bar.removePlayer(player);
    }

    @Override
    public void remove(RemovalReason reason) {
        super.remove(reason);
        bar.removeAllPlayers();
        if (challenger != null && !this.level().isClientSide) {
            ACTIVE.remove(challenger);
            RivalSpawner.cooldown(challenger, this.level().getGameTime());
        }
        moves.reset();
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        return false;
    }

    @Override
    protected boolean shouldDespawnInPeaceful() {
        return true;
    }

    @Override
    public boolean isPushable() {
        return phase == Phase.FIGHT;
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        return false;   // tinjunya diurus RivalMoves.punch (kekuatan juara)
    }

    // ------------------------------------------------------------------ suara: juara, bukan monster

    @Override
    protected SoundEvent getAmbientSound() {
        return null;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.PLAYER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.PLAYER_DEATH;
    }
}
