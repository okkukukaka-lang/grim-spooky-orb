"""Kain jubah Lintang 0.38: merah tua tebal bertekstur kepar, list jahitan di tepi kiri-kanan & kelim bawah.
u = lebar jubah (kiri -> kanan), v = panjang (leher -> ujung bawah). Warnanya sudah di tekstur (diwarnai putih di game).

    python3 lintang_cape.py OUT.png
"""
import sys

import numpy as np
from PIL import Image

W, H = 64, 128
BASE = np.array([150, 20, 30], float)
DEEP = np.array([96, 10, 18], float)
HI = np.array([186, 40, 48], float)
STITCH = np.array([206, 120, 112], float)

rng = np.random.default_rng(380)
ys, xs = np.mgrid[0:H, 0:W]
u, v = (xs + 0.5) / W, (ys + 0.5) / H

# kepar diagonal + serat halus
twill = ((xs + ys) % 3 == 0) * 0.05 - 0.017
fiber = rng.normal(0, 0.025, (H, W))
weft = np.repeat(rng.normal(0, 0.02, (H, 1)), W, axis=1)
k = 1.0 + twill + fiber + weft
col = BASE * k[..., None]
col = np.where(k[..., None] > 1.03, BASE + (HI - BASE) * np.clip((k[..., None] - 1.03) / 0.08, 0, 1), col)

# tepi kiri-kanan, kelim bawah, pita leher: lebih gelap & tebal
edge = np.minimum(u, 1 - u)
band = (edge < 0.05) | (v > 0.945) | (v < 0.03)
col = np.where(band[..., None], DEEP * (1.0 + twill[..., None] * 0.6 + fiber[..., None]), col)
# lipatan kelim sedikit terang di batasnya
rim = ((edge >= 0.05) & (edge < 0.062)) | ((v <= 0.945) & (v > 0.937))
col = np.where(rim[..., None], col * 1.12, col)
# jahitan putus-putus di tepi & kelim
stitch_side = (np.abs(edge - 0.031) < 0.008) & ((ys // 2) % 2 == 0) & (v > 0.03) & (v < 0.945)
stitch_hem = (np.abs(v - 0.972) < 0.004) & ((xs // 2) % 2 == 0)
col = np.where((stitch_side | stitch_hem)[..., None], STITCH * 0.75 + col * 0.25, col)

img = np.zeros((H, W, 4), np.uint8)
img[..., :3] = np.clip(col, 0, 255).astype(np.uint8)
img[..., 3] = 255
Image.fromarray(img, "RGBA").save(sys.argv[1] if len(sys.argv) > 1 else "cape.png")
