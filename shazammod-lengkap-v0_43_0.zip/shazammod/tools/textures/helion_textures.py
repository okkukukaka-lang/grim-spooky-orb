"""Tekstur Projek Helion-6 (0.43, desain orisinal).

Helion-6 = eksperimen Helion sebelum Lintang: sel tubuhnya hidup dari radiasi Batu Cryon dan terbakar matahari.
Kostumnya baju tempur lab yang gelap (kain hitam kehijauan bertekstur sarang lebah, pelat logam gunmetal) dengan
jalur radiasi hijau yang menyala dari reaktor heksagon di dada. Bukan kostum karakter komik mana pun.

    python3 helion_textures.py ASSETS_DIR [PREVIEW.png]

ASSETS_DIR = src/main/resources/assets/shazammod. Menulis:
  textures/entity/helion/suit.png        256x256, tata letak UV kulit 64x64 (skala 4), base + lapisan luar
  textures/entity/helion/suit_glow.png   256x256, jalur radiasi (dipakai RenderType.eyes, hitam = mati)
  textures/entity/helion/cape_cloth.png  64x128, kain jubah (u = lebar, v = leher -> kelim)
  textures/entity/helion_emblem.png      32x32, reaktor heksagon (alpha 128..255 = tinggi timbul)
  textures/item/helion6_serum.png        32x32, injektor serum Cryon
"""
import os
import sys

import numpy as np
from PIL import Image

S = 4
W = H = 64 * S
rng = np.random.default_rng(43)

FAB = np.array([24, 29, 27], float)
FAB_HI = np.array([46, 55, 51], float)
FAB_SH = np.array([11, 14, 13], float)
PLATE = np.array([62, 69, 74], float)
PLATE_HI = np.array([128, 138, 146], float)
PLATE_SH = np.array([26, 30, 34], float)
DARK = np.array([13, 15, 16], float)
TRIM = np.array([20, 82, 46], float)
GLOW = np.array([70, 255, 140], float)
GLOW_CORE = np.array([215, 255, 228], float)


def noise(h, w, cell, amp):
    gh, gw = h // cell + 2, w // cell + 2
    g = rng.random((gh, gw))
    yy, xx = np.mgrid[0:h, 0:w]
    fy, fx = yy / cell, xx / cell
    y0, x0 = fy.astype(int), fx.astype(int)
    ty, tx = fy - y0, fx - x0
    ty, tx = ty * ty * (3 - 2 * ty), tx * tx * (3 - 2 * tx)
    a = g[y0, x0] * (1 - tx) + g[y0, x0 + 1] * tx
    b = g[y0 + 1, x0] * (1 - tx) + g[y0 + 1, x0 + 1] * tx
    return (a * (1 - ty) + b * ty - 0.5) * 2 * amp


def hexgrid(x, y, size):
    """0 di tengah sel heksagon, 1 di tepinya (pola sarang lebah pada kain)."""
    qx = x / (size * 1.5)
    qy = y / (size * np.sqrt(3))
    best = np.full(x.shape, 9.0)
    for ox in (-1, 0, 1, 2):
        for oy in (-1, 0, 1, 2):
            cx = np.floor(qx) + ox
            cy = np.floor(qy) + oy + np.where(np.mod(cx, 2) == 1, 0.5, 0.0)
            px = cx * size * 1.5
            py = cy * size * np.sqrt(3)
            dx, dy = np.abs(x - px), np.abs(y - py)
            d = np.maximum(dx * 0.866 + dy * 0.5, dy) / (size * 0.866)
            best = np.minimum(best, d)
    return np.clip(best, 0, 1)


def coords(w, h):
    ys, xs = np.mgrid[0:h * S, 0:w * S]
    return (xs + 0.5) / S, (ys + 0.5) / S


def rect_bevel(x, y, x0, y0, x1, y1):
    """Di dalam pelat? + kemiringan: atas/kiri terang, bawah/kanan gelap (cahaya dari atas)."""
    inside = (x >= x0) & (x < x1) & (y >= y0) & (y < y1)
    e = 0.35
    top = inside & (y < y0 + e)
    left = inside & (x < x0 + e)
    bottom = inside & (y >= y1 - e)
    right = inside & (x >= x1 - e)
    return inside, top | left, bottom | right


class Face:
    """Satu sisi kubus: warna (rgb), alpha, dan cahaya radiasi (0..1)."""

    def __init__(self, w, h):
        self.w, self.h = w, h
        self.x, self.y = coords(w, h)
        hh, ww = self.x.shape
        hx = hexgrid(self.x, self.y, 0.62)
        tex = noise(hh, ww, 3, 0.05) + noise(hh, ww, 14, 0.05)
        k = 1.0 + tex - 0.22 * hx ** 6
        self.rgb = np.clip(FAB[None, None] * k[..., None], 0, 255)
        self.rgb = np.where((hx > 0.86)[..., None], FAB_SH + (self.rgb - FAB_SH) * 0.55, self.rgb)
        self.alpha = np.full((hh, ww), 255.0)
        self.glow = np.zeros((hh, ww))

    def plate(self, x0, y0, x1, y1, color=PLATE, hi=PLATE_HI, sh=PLATE_SH, seam_glow=0.0):
        inside, lit, shade = rect_bevel(self.x, self.y, x0, y0, x1, y1)
        hh, ww = self.x.shape
        brushed = np.repeat(rng.random((hh, 1)) * 0.08 - 0.04, ww, axis=1)
        k = 1.0 + brushed + noise(hh, ww, 4, 0.04)
        col = color[None, None] * k[..., None]
        col = np.where(lit[..., None], hi * 0.75 + col * 0.25, col)
        col = np.where(shade[..., None], sh * 0.8 + col * 0.2, col)
        self.rgb = np.where(inside[..., None], col, self.rgb)
        if seam_glow > 0:
            edge = inside & ~((self.x >= x0 + 0.25) & (self.x < x1 - 0.25) & (self.y >= y0 + 0.25) & (self.y < y1 - 0.25))
            self.glow = np.maximum(self.glow, edge * seam_glow)
        return inside

    def fill(self, mask, color, k=1.0):
        self.rgb = np.where(mask[..., None], color[None, None] * k, self.rgb)

    def hline(self, y, x0, x1, strength, width=0.18):
        m = (np.abs(self.y - y) < width) & (self.x >= x0) & (self.x <= x1)
        self.glow = np.maximum(self.glow, m * strength)
        self.rgb = np.where(m[..., None], TRIM, self.rgb)

    def vline(self, x, y0, y1, strength, width=0.18):
        m = (np.abs(self.x - x) < width) & (self.y >= y0) & (self.y <= y1)
        self.glow = np.maximum(self.glow, m * strength)
        self.rgb = np.where(m[..., None], TRIM, self.rgb)

    def path(self, pts, strength, width=0.16):
        """Jalur radiasi berkelok (titik-titik model px)."""
        for (ax, ay), (bx, by) in zip(pts[:-1], pts[1:]):
            dx, dy = bx - ax, by - ay
            L2 = dx * dx + dy * dy + 1e-9
            t = np.clip(((self.x - ax) * dx + (self.y - ay) * dy) / L2, 0, 1)
            d = np.hypot(self.x - (ax + t * dx), self.y - (ay + t * dy))
            m = d < width
            self.glow = np.maximum(self.glow, m * strength)
            self.rgb = np.where(m[..., None], TRIM, self.rgb)

    def dot(self, cx, cy, r, strength):
        m = np.hypot(self.x - cx, self.y - cy) < r
        self.glow = np.maximum(self.glow, m * strength)
        self.rgb = np.where(m[..., None], TRIM, self.rgb)


def put(img, glow, u, v, face):
    hh, ww = face.x.shape
    y0, x0 = v * S, u * S
    img[y0:y0 + hh, x0:x0 + ww, :3] = np.clip(face.rgb, 0, 255)
    img[y0:y0 + hh, x0:x0 + ww, 3] = face.alpha
    glow[y0:y0 + hh, x0:x0 + ww] = np.maximum(glow[y0:y0 + hh, x0:x0 + ww], face.glow)


# ------------------------------------------------------------------ bagian badan

def body_faces():
    w, h, d = 8, 12, 4
    front = Face(w, h)
    # kerah tinggi
    front.plate(0.0, 0.0, 8.0, 1.0, seam_glow=0.55)
    # pelat dada kiri & kanan (tengahnya dibiarkan gelap: tempat reaktor heksagon dari lapisan lambang)
    front.plate(0.3, 1.2, 3.0, 5.4)
    front.plate(5.0, 1.2, 7.7, 5.4)
    recess = (np.abs(front.x - 4) < 1.6) & (front.y > 1.0) & (front.y < 7.6)
    front.fill(recess, DARK)
    # perut beruas 3 x 2
    for row, y in enumerate((5.8, 7.3, 8.8)):
        front.plate(1.2, y, 3.85, y + 1.3)
        front.plate(4.15, y, 6.8, y + 1.3)
    front.vline(4.0, 7.6, 10.2, 0.85, 0.14)
    # jalur radiasi dari reaktor ke bahu & pinggang
    for s in (-1, 1):
        cx = 4 + s * 1.7
        front.path([(cx, 3.2), (4 + s * 2.6, 2.4), (4 + s * 3.4, 1.4), (4 + s * 3.9, 1.1)], 1.0)
        front.path([(cx, 5.0), (4 + s * 2.3, 6.0), (4 + s * 3.25, 6.4), (4 + s * 3.4, 9.6)], 0.9)
        front.path([(4 + s * 1.2, 7.6), (4 + s * 1.2, 8.4)], 0.7)
    # sabuk + gesper heksagon (kristal Cryon)
    belt = (front.y >= 10.2) & (front.y < 11.6)
    front.fill(belt, DARK, 1.0)
    front.hline(10.25, 0, 8, 0.45, 0.1)
    hx = np.abs(front.x - 4.0)
    hy = np.abs(front.y - 10.9)
    buckle = np.maximum(hx * 0.866 + hy * 0.5, hy) < 0.95
    front.fill(buckle, PLATE_HI * 0.8)
    core = np.maximum(hx * 0.866 + hy * 0.5, hy) < 0.55
    front.glow = np.maximum(front.glow, core * 1.0)
    front.fill(core, GLOW * 0.55)
    front.plate(0.0, 11.6, 8.0, 12.0, color=DARK, hi=PLATE, sh=DARK)

    back = Face(w, h)
    back.plate(0.0, 0.0, 8.0, 1.0)
    back.plate(0.6, 1.4, 3.6, 5.8)
    back.plate(4.4, 1.4, 7.4, 5.8)
    back.plate(3.3, 6.2, 4.7, 10.0)
    back.vline(4.0, 1.2, 10.0, 0.75, 0.12)
    for s in (-1, 1):
        back.path([(4.0, 6.0), (4 + s * 2.0, 6.8), (4 + s * 3.4, 8.8)], 0.6)
    back.fill((back.y >= 10.2) & (back.y < 11.6), DARK)
    back.hline(10.25, 0, 8, 0.4, 0.1)

    side = Face(d, h)
    side.plate(0.0, 0.0, 4.0, 1.0)
    side.plate(0.5, 1.6, 3.5, 4.4)
    side.vline(2.0, 4.6, 10.0, 0.7, 0.13)
    side.fill((side.y >= 10.2) & (side.y < 11.6), DARK)

    top = Face(w, d)
    top.plate(0.0, 0.0, 8.0, 4.0, seam_glow=0.35)
    bottom = Face(w, d)
    bottom.fill(np.ones_like(bottom.x, bool), DARK)
    return front, back, side, top, bottom


def arm_faces(w):
    h, d = 12, 4

    def side(width, outer):
        f = Face(width, h)
        f.plate(0.0, 0.0, width, 3.6, seam_glow=0.5 if outer else 0.0)   # pelindung bahu
        f.hline(7.6, 0, width, 0.35, 0.09)                                # siku
        f.plate(0.0, 8.0, width, 11.2, seam_glow=0.0)                     # gauntlet
        for y in (8.9, 9.8, 10.6):
            f.hline(y, 0.25, width - 0.25, 0.0, 0.06)
        f.hline(8.15, 0, width, 1.0, 0.15)                                # cincin radiasi gauntlet
        f.fill(f.y >= 11.2, DARK)                                         # sarung tangan
        if outer:
            f.vline(width / 2.0, 3.8, 7.4, 0.85, 0.13)
            f.vline(width / 2.0, 8.4, 11.0, 0.95, 0.12)
        return f

    front = side(w, False)
    for x in np.linspace(0.6, w - 0.6, max(2, int(w))):                 # buku jari menyala
        front.dot(x, 11.6, 0.22, 0.9)
    back = side(w, False)
    outer = side(d, True)
    inner = side(d, False)
    top = Face(w, d)
    top.plate(0.0, 0.0, w, d, seam_glow=0.45)
    bottom = Face(w, d)
    bottom.fill(np.ones_like(bottom.x, bool), DARK)
    for x in np.linspace(0.6, w - 0.6, max(2, int(w))):
        bottom.dot(x, 1.0, 0.2, 0.6)
    return front, back, outer, inner, top, bottom


def leg_faces():
    w, h, d = 4, 12, 4

    def side(width, front_face, outer):
        f = Face(width, h)
        if front_face:
            f.plate(0.4, 4.8, width - 0.4, 7.0, seam_glow=0.6)           # pelindung lutut
            hx = np.abs(f.x - width / 2.0)
            hy = np.abs(f.y - 5.9)
            gem = np.maximum(hx * 0.866 + hy * 0.5, hy) < 0.45
            f.glow = np.maximum(f.glow, gem * 1.0)
            f.fill(gem, GLOW * 0.5)
            f.plate(0.3, 7.6, width - 0.3, 11.0)                          # pelindung tulang kering
        if outer:
            f.plate(0.6, 0.6, width - 0.6, 4.2)                           # pelat paha luar
            f.vline(width / 2.0, 4.4, 7.0, 0.8, 0.13)
        f.fill(f.y >= 7.4, DARK, 1.15)                                    # sepatu bot
        if front_face:
            f.plate(0.3, 7.6, width - 0.3, 11.0)
        f.hline(7.45, 0, width, 0.9, 0.13)                                # tepi bot menyala
        f.plate(0.0, 11.4, width, 12.0, color=DARK, hi=PLATE, sh=DARK)    # sol
        f.hline(11.45, 0, width, 0.55, 0.08)
        return f

    front = side(w, True, False)
    back = side(w, False, False)
    outer = side(d, False, True)
    inner = side(d, False, False)
    top = Face(w, d)
    top.fill(np.ones_like(top.x, bool), FAB)
    bottom = Face(w, d)
    bottom.fill(np.ones_like(bottom.x, bool), DARK)
    return front, back, outer, inner, top, bottom


def lay_box(img, glow, u, v, w, h, d, faces, right_side_outer):
    """faces = front, back, sideA (luar), sideB (dalam), top, bottom. Tata letak kubus UV Minecraft."""
    front, back, outer, inner, top, bottom = faces
    put(img, glow, u + d, v, top)
    put(img, glow, u + d + w, v, bottom)
    put(img, glow, u, v + d, outer if right_side_outer else inner)
    put(img, glow, u + d, v + d, front)
    put(img, glow, u + d + w, v + d, inner if right_side_outer else outer)
    put(img, glow, u + d + w + d, v + d, back)


def suit(out_dir):
    img = np.zeros((H, W, 4), float)
    glow = np.zeros((H, W))
    bf, bb, bs, bt, bbot = body_faces()
    for (u, v) in ((16, 16), (16, 32)):
        lay_box(img, glow, u, v, 8, 12, 4, (bf, bb, bs, bs, bt, bbot), True)
    arm = arm_faces(4)
    for (u, v), right in (((40, 16), True), ((40, 32), True), ((32, 48), False), ((48, 48), False)):
        lay_box(img, glow, u, v, 4, 12, 4, arm, right)
    leg = leg_faces()
    for (u, v), right in (((0, 16), True), ((0, 32), True), ((16, 48), False), ((0, 48), False)):
        lay_box(img, glow, u, v, 4, 12, 4, leg, right)

    # tekstur cahaya: inti putih kehijauan, pendar hijau yang melebar halus
    from scipy import ndimage
    soft = ndimage.gaussian_filter(glow, 2.2) * 1.7
    wide = ndimage.gaussian_filter(glow, 5.0) * 0.9
    g = np.clip(glow, 0, 1)
    rgb = (GLOW_CORE[None, None] * g[..., None] ** 1.5
           + GLOW[None, None] * np.clip(soft, 0, 1)[..., None] * 0.85
           + np.array([16, 120, 60])[None, None] * np.clip(wide, 0, 1)[..., None])
    rgb = np.where((img[..., 3] > 0)[..., None], rgb, 0)
    gimg = np.zeros((H, W, 4), np.uint8)
    gimg[..., :3] = np.clip(rgb, 0, 255).astype(np.uint8)
    gimg[..., 3] = 255
    os.makedirs(os.path.join(out_dir, "textures/entity/helion"), exist_ok=True)
    Image.fromarray(np.clip(img, 0, 255).astype(np.uint8), "RGBA").save(os.path.join(out_dir, "textures/entity/helion/suit.png"))
    Image.fromarray(gimg, "RGBA").save(os.path.join(out_dir, "textures/entity/helion/suit_glow.png"))


# ------------------------------------------------------------------ jubah

def cape(out_dir):
    w, h = 64, 128
    ys, xs = np.mgrid[0:h, 0:w]
    u, v = (xs + 0.5) / w, (ys + 0.5) / h
    base = np.array([30, 33, 34], float)
    deep = np.array([15, 17, 18], float)
    twill = ((xs + ys) % 3 == 0) * 0.05 - 0.017
    fiber = rng.normal(0, 0.03, (h, w))
    hexk = hexgrid(xs / 4.0, ys / 4.0, 1.4)
    k = 1.0 + twill + fiber - 0.12 * hexk ** 8
    col = base * k[..., None]
    edge = np.minimum(u, 1 - u)
    band = (edge < 0.06) | (v > 0.94) | (v < 0.035)
    col = np.where(band[..., None], deep * (1.0 + twill[..., None] * 0.6 + fiber[..., None]), col)
    stitch_side = (np.abs(edge - 0.034) < 0.008) & ((ys // 2) % 2 == 0) & (v > 0.035) & (v < 0.94)
    stitch_hem = (np.abs(v - 0.968) < 0.005) & ((xs // 2) % 2 == 0)
    glow_line = (np.abs(v - 0.938) < 0.004) | ((np.abs(edge - 0.062) < 0.006) & (v > 0.035))
    col = np.where((stitch_side | stitch_hem)[..., None], np.array([60, 190, 110]) * 0.8 + col * 0.2, col)
    col = np.where(glow_line[..., None], np.array([40, 140, 80]) * 0.9 + col * 0.1, col)
    img = np.zeros((h, w, 4), np.uint8)
    img[..., :3] = np.clip(col, 0, 255).astype(np.uint8)
    img[..., 3] = 255
    Image.fromarray(img, "RGBA").save(os.path.join(out_dir, "textures/entity/helion/cape_cloth.png"))


# ------------------------------------------------------------------ lambang reaktor

def hexdist(x, y):
    return np.maximum(np.abs(x) * 0.866 + np.abs(y) * 0.5, np.abs(y))


def emblem(out_dir):
    n = 32
    ys, xs = np.mgrid[0:n, 0:n]
    x, y = (xs + 0.5 - n / 2) / (n / 2), (ys + 0.5 - n / 2) / (n / 2)
    # heksagon \"berdiri\" (sudut di atas & bawah): tukar x/y
    d = hexdist(y, x)
    img = np.zeros((n, n, 4), float)
    frame = (d < 0.97) & (d >= 0.76)
    recess = d < 0.76
    # pelat bingkai gunmetal dengan bevel
    lit = (y < -0.1) | (x < -0.3)
    col_frame = np.where(lit[..., None], PLATE_HI, PLATE)
    edge_in = (d >= 0.76) & (d < 0.81)
    img[frame, :3] = col_frame[frame]
    img[frame, 3] = 255
    img[edge_in, :3] = np.array([40, 190, 100])
    img[edge_in, 3] = 235
    img[recess, :3] = np.array([10, 26, 18])
    img[recess, 3] = 140
    # kristal Cryon memanjang di tengah, dua faset
    cr = (np.abs(x) * 1.9 + np.abs(y) * 0.95) < 0.62
    facet_l = cr & (x < 0)
    facet_r = cr & (x >= 0)
    img[facet_l, :3] = np.array([150, 255, 190])
    img[facet_r, :3] = np.array([40, 210, 105])
    img[cr, 3] = 250
    core = (np.abs(x) * 1.9 + np.abs(y) * 0.95) < 0.26
    img[core, :3] = np.array([230, 255, 236])
    img[core, 3] = 255
    # tiga jari radiasi ke sudut bawah-kiri, bawah-kanan, atas
    for ang in (90, 210, 330):
        a = np.radians(ang)
        ux, uy = np.cos(a), -np.sin(a)
        t = x * ux + y * uy
        dperp = np.abs(-x * uy + y * ux)
        spoke = (t > 0.5) & (t < 0.72) & (dperp < 0.09 + (t - 0.5) * 0.35) & recess
        img[spoke, :3] = np.array([60, 230, 120])
        img[spoke, 3] = 205
    Image.fromarray(np.clip(img, 0, 255).astype(np.uint8), "RGBA").save(os.path.join(out_dir, "textures/entity/helion_emblem.png"))


# ------------------------------------------------------------------ serum

def serum(out_dir):
    n = 32
    img = np.zeros((n, n, 4), np.uint8)
    ys, xs = np.mgrid[0:n, 0:n]
    cx, cy = xs + 0.5 - 16, ys + 0.5 - 16
    # sumbu injektor dari kiri-bawah ke kanan-atas
    s = np.sqrt(0.5)
    u = (cx - cy) * s        # sepanjang sumbu (ke kanan-atas positif)
    v = (cx + cy) * s        # melintang
    col = np.zeros((n, n, 3))
    a = np.zeros((n, n))

    def seg(mask, c):
        col[mask] = c
        a[mask] = 255

    seg((u > -13) & (u < -9.5) & (np.abs(v) < 1.6), [44, 48, 52])                 # pendorong
    seg((u > -12.6) & (u < -10.2) & (np.abs(v) < 0.8), [96, 104, 110])
    seg((u > -9.5) & (u < -7.5) & (np.abs(v) < 3.6), [30, 33, 36])                 # sayap jari
    seg((u > -7.5) & (u < 7.0) & (np.abs(v) < 3.0), [36, 40, 44])                  # badan tabung
    glass = (u > -6.6) & (u < 6.2) & (np.abs(v) < 2.2)
    seg(glass, [20, 120, 60])
    fluid = (u > -5.0) & (u < 6.2) & (np.abs(v) < 2.2)
    shade = np.clip(0.75 + 0.25 * (-v / 2.2), 0.5, 1.0)
    col[fluid] = (np.array([60, 255, 130])[None] * shade[fluid][:, None])
    hi = fluid & (v < -1.2) & (u > -3) & (u < 4)
    col[hi] = [210, 255, 225]
    bubbles = fluid & (((u + 2.5) ** 2 + (v - 0.6) ** 2 < 0.5) | ((u - 2.0) ** 2 + (v + 0.2) ** 2 < 0.35))
    col[bubbles] = [170, 255, 200]
    for k in (-3.4, -0.4, 2.6):                                                    # garis takaran
        m = glass & (np.abs(u - k) < 0.35) & (v > 0.6)
        col[m] = [16, 60, 32]
    seg((u > 7.0) & (u < 9.0) & (np.abs(v) < 2.6), [62, 69, 74])                   # kepala heksagon
    seg((u > 7.4) & (u < 8.6) & (np.abs(v) < 1.6), [120, 255, 170])
    seg((u > 9.0) & (u < 14.2) & (np.abs(v) < 0.55), [190, 200, 208])              # jarum
    out = np.zeros((n, n, 4), np.uint8)
    out[..., :3] = np.clip(col, 0, 255)
    out[..., 3] = a.astype(np.uint8)
    # garis tepi gelap: piksel isi yang bersebelahan dengan kosong
    filled = out[..., 3] > 0
    pad = np.pad(filled, 1)
    border = filled & ~(pad[:-2, 1:-1] & pad[2:, 1:-1] & pad[1:-1, :-2] & pad[1:-1, 2:])
    out[border, :3] = (out[border, :3] * 0.45).astype(np.uint8)
    Image.fromarray(out, "RGBA").save(os.path.join(out_dir, "textures/item/helion6_serum.png"))


if __name__ == "__main__":
    assets = sys.argv[1] if len(sys.argv) > 1 else "."
    suit(assets)
    cape(assets)
    emblem(assets)
    serum(assets)
    if len(sys.argv) > 2:   # lembar pratinjau
        tiles = []
        for p, scale in (("textures/entity/helion/suit.png", 3), ("textures/entity/helion/suit_glow.png", 3),
                         ("textures/entity/helion/cape_cloth.png", 5), ("textures/entity/helion_emblem.png", 16),
                         ("textures/item/helion6_serum.png", 16)):
            im = Image.open(os.path.join(assets, p)).convert("RGBA")
            im = im.resize((im.width * scale // (4 if "suit" in p else 1) if "suit" in p else im.width * scale,
                            im.height * scale // (4 if "suit" in p else 1) if "suit" in p else im.height * scale), Image.NEAREST)
            bg = Image.new("RGBA", im.size, (70, 70, 80, 255))
            bg.alpha_composite(im)
            tiles.append(bg)
        wsum = sum(t.width for t in tiles) + 10 * len(tiles)
        hmax = max(t.height for t in tiles)
        sheet = Image.new("RGBA", (wsum, hmax), (40, 40, 48, 255))
        x = 0
        for t in tiles:
            sheet.paste(t, (x, 0))
            x += t.width + 10
        sheet.save(sys.argv[2])
    print("ok")
