"""0.42 Lintang tanpa kostum: lambang matahari menyala & tekstur jubah cahaya (orisinal).

    python3 lintang_light.py EMBLEM.png CAPE.png

- Lambang 32x32: cakram matahari putih-emas, cincin emas, 12 sinar meliuk (panjang-pendek berselang). Di luar lambang
  transparan (kulit pemain tetap terlihat). Alpha = tinggi timbul (128 rendah ... 255 paling tinggi), dibaca EmblemImage.
- Jubah 64x64: berkas-berkas cahaya keemasan tegak yang bisa diulang ke bawah tanpa sambungan (teksturnya digeser pelan
  di game supaya sinarnya terlihat mengalir), tepi kiri-kanan memudar lembut.
"""
import math
import sys

import numpy as np
from PIL import Image

emblem_out, cape_out = sys.argv[1], sys.argv[2]

# ------------------------------------------------------------------ lambang matahari
N = 32
C = (N - 1) / 2.0
ys, xs = np.mgrid[0:N, 0:N]
dx, dy = xs - C, ys - C
r = np.hypot(dx, dy)
ang = np.arctan2(dy, dx)
rgb = np.zeros((N, N, 3), float)
alpha = np.zeros((N, N), float)

WHITE = np.array([255, 248, 220], float)
GOLD = np.array([255, 196, 78], float)
DEEP = np.array([255, 128, 36], float)

for i in range(12):
    a0 = i * math.pi / 6 + math.pi / 12
    long_ray = i % 2 == 0
    tip = 15.2 if long_ray else 11.6
    base_w = 1.9 if long_ray else 1.5
    d = np.angle(np.exp(1j * (ang - a0)))
    along = r * np.cos(d)
    across = r * np.sin(d) - 0.3 * np.sin((along - 6.0) * 0.8) * (along > 6.0)   # sinar sedikit meliuk seperti api
    half = base_w * np.clip(1 - (along - 6.0) / (tip - 6.0), 0, 1)
    ray = (along > 5.5) & (along < tip) & (np.abs(across) < half + 0.2) & (np.abs(d) < math.pi / 2)
    k = np.clip((along - 6.0) / (tip - 6.0), 0, 1)
    col = GOLD + (DEEP - GOLD) * k[..., None]
    rgb[ray] = col[ray]
    alpha[ray] = np.maximum(alpha[ray], (215 - 60 * k)[ray])

ring = (r >= 6.0) & (r < 7.6)
rgb[ring] = GOLD * 1.0
alpha[ring] = 232

disc = r < 6.0
kd = np.clip(r / 6.0, 0, 1)
rgb[disc] = (WHITE + (GOLD - WHITE) * (kd ** 2)[..., None] * 0.7)[disc]
alpha[disc] = (255 - 18 * kd)[disc]

img = np.zeros((N, N, 4), np.uint8)
img[..., :3] = np.clip(rgb, 0, 255).astype(np.uint8)
img[..., 3] = np.where(alpha > 0, np.clip(alpha, 128, 255), 0).astype(np.uint8)
Image.fromarray(img, "RGBA").save(emblem_out)

# ------------------------------------------------------------------ jubah cahaya
W, H = 64, 64
rng = np.random.default_rng(42)
u = (np.arange(W) + 0.5) / W
v = (np.arange(H) + 0.5) / H
U, V = np.meshgrid(u, v)
streak = np.zeros((H, W))
for k in range(14):   # berkas cahaya tegak; pola di sepanjang v berulang pas (kelipatan 2*pi) supaya mulus diulang
    cu = rng.uniform(0.04, 0.96)
    w = rng.uniform(0.012, 0.045)
    bright = rng.uniform(0.4, 1.0)
    wave = 0.5 + 0.5 * np.sin(2 * math.pi * (V * rng.integers(1, 4) + rng.uniform(0, 1)))
    streak += bright * np.exp(-((U - cu) / w) ** 2) * (0.55 + 0.45 * wave)
streak = np.clip(streak, 0, 1.4) / 1.4
edge = np.clip(np.minimum(U, 1 - U) / 0.12, 0, 1) ** 1.5   # tepi kiri-kanan memudar
center = 1 - np.abs(U - 0.5) * 1.2
col_white = np.array([255, 244, 214], float)
col_gold = np.array([255, 186, 70], float)
col_deep = np.array([255, 120, 36], float)
mixk = np.clip(1 - streak * 0.9 - center * 0.3, 0, 1)
rgb = col_white + (col_gold - col_white) * np.clip(mixk * 1.6, 0, 1)[..., None]
rgb = rgb + (col_deep - rgb) * np.clip((mixk - 0.6) / 0.4, 0, 1)[..., None]
a = (0.42 + 0.58 * streak) * edge
cape = np.zeros((H, W, 4), np.uint8)
cape[..., :3] = np.clip(rgb, 0, 255).astype(np.uint8)
cape[..., 3] = np.clip(a * 255, 0, 255).astype(np.uint8)
Image.fromarray(cape, "RGBA").save(cape_out)
print("ok", emblem_out, cape_out)
