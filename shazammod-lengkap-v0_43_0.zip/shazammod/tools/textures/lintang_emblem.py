"""Lambang dada Lintang 0.38 (orisinal): medali bundar - cincin perak, pelat merah tua, bintang-matahari delapan sinar
keemasan dengan inti cakram. Alpha = tinggi timbul (128 rendah ... 255 paling tinggi), dibaca EmblemImage.

    python3 lintang_emblem.py OUT.png
"""
import math
import sys

import numpy as np
from PIL import Image

N = 32
C = (N - 1) / 2.0
SILVER = np.array([206, 214, 224], float)
SILVER_SH = np.array([112, 122, 136], float)
GOLD = np.array([232, 182, 74], float)
GOLD_HI = np.array([255, 230, 156], float)
GOLD_SH = np.array([150, 102, 34], float)
PLATE = np.array([128, 22, 30], float)
PLATE_SH = np.array([78, 12, 18], float)

ys, xs = np.mgrid[0:N, 0:N]
dx, dy = xs - C, ys - C
r = np.hypot(dx, dy)
ang = np.arctan2(dy, dx)
light = (-dx - dy) / (np.maximum(r, 1e-6) * math.sqrt(2))   # cahaya dari kiri atas

rgb = np.zeros((N, N, 3), float)
alpha = np.zeros((N, N), float)

# pelat dasar merah tua (paling rendah)
plate = r < 12.9
rgb[plate] = (PLATE + (PLATE_SH - PLATE) * np.clip(r / 12.9, 0, 1)[..., None] * 0.7)[plate]
alpha[plate] = 150

# cincin perak timbul dengan bevel
ring = (r >= 12.4) & (r < 15.3)
bevel = np.clip(0.5 + 0.5 * light, 0, 1)
inner_edge = (r < 13.1)
k = np.where(inner_edge, 1 - bevel, bevel)
rgb[ring] = (SILVER_SH + (SILVER - SILVER_SH) * k[..., None])[ring]
alpha[ring] = 255
groove = (r >= 13.6) & (r < 14.0)   # alur tipis di tengah cincin
rgb[groove] = (rgb[groove] * 0.72)
alpha[groove] = 236

# delapan sinar: empat panjang (atas/bawah/kiri/kanan), empat pendek (diagonal); tiap sinar punya dua sisi (terang/gelap)
for i in range(8):
    a0 = i * math.pi / 4
    long_ray = i % 2 == 0
    tip = 11.9 if long_ray else 9.2
    base_w = 2.1 if long_ray else 1.6
    d = np.angle(np.exp(1j * (ang - a0)))      # selisih sudut -pi..pi
    across = r * np.sin(d)                      # jarak tegak lurus dari sumbu sinar
    along = r * np.cos(d)
    half = base_w * np.clip(1 - (along - 3.6) / (tip - 3.6), 0, 1)
    ray = (along > 3.0) & (along < tip) & (np.abs(across) < half + 0.15) & (np.abs(d) < math.pi / 2)
    side_light = np.where(across * math.cos(a0 + math.pi / 4) > 0, 1.0, 0.35)
    col = GOLD_SH + (GOLD - GOLD_SH) * side_light[..., None]
    ridge = np.abs(across) < 0.45
    col = np.where(ridge[..., None], GOLD_HI * 0.9 + col * 0.1, col)
    rgb[ray] = col[ray]
    alpha[ray] = np.where(ridge, 222, 206)[ray]

# inti cakram matahari (paling tinggi) dengan kilap
core = r < 3.9
shine = np.clip(0.55 + 0.45 * light - 0.15 * r / 3.9, 0, 1)
rgb[core] = (GOLD_SH + (GOLD_HI - GOLD_SH) * shine[..., None])[core]
alpha[core] = 255
rim = (r >= 3.2) & (r < 3.9)
rgb[rim] = (rgb[rim] * 0.8)
alpha[rim] = 242

img = np.zeros((N, N, 4), np.uint8)
img[..., :3] = np.clip(rgb, 0, 255).astype(np.uint8)
img[..., 3] = np.clip(alpha, 0, 255).astype(np.uint8)
Image.fromarray(img, "RGBA").save(sys.argv[1] if len(sys.argv) > 1 else "emblem.png")
