"""Kostum Lintang 0.38 (desain orisinal): tekstur 256x256 dengan tata letak UV kulit 64x64 (skala 4).

Dipakai LintangSuitLayer di atas badan, lengan, dan kaki pemain (kepala tetap kulit asli pemain).
Desain: kain biru minyak tua bertekstur halus, panel samping & sarung tangan & sepatu bot grafit, list perak,
sabuk perak dengan gesper cakram matahari keemasan, kerah tinggi grafit. Bukan kostum Superman: tanpa lambang perisai,
tanpa sepatu merah, tanpa sabuk kuning.

    python3 lintang_suit.py OUT.png
"""
import sys

import numpy as np
from PIL import Image

S = 4                      # texel per piksel model
W = H = 64 * S

SUIT_DARK = np.array([20, 52, 70], float)
SUIT = np.array([34, 84, 108], float)
SUIT_HI = np.array([66, 128, 154], float)
GRAPH = np.array([33, 36, 42], float)
GRAPH_HI = np.array([62, 67, 77], float)
SILVER = np.array([200, 208, 218], float)
SILVER_SH = np.array([120, 130, 142], float)
BELT = np.array([168, 176, 186], float)
BELT_SH = np.array([96, 104, 114], float)
GOLD = np.array([226, 176, 70], float)
GOLD_HI = np.array([255, 224, 146], float)
GOLD_SH = np.array([150, 104, 36], float)

rng = np.random.default_rng(38)
img = np.zeros((H, W, 4), float)


def smooth_noise(h, w, cell, amp):
    gh, gw = h // cell + 2, w // cell + 2
    g = rng.random((gh, gw))
    yy, xx = np.mgrid[0:h, 0:w]
    fy, fx = yy / cell, xx / cell
    y0, x0 = fy.astype(int), fx.astype(int)
    ty, tx = fy - y0, fx - x0
    ty, tx = ty * ty * (3 - 2 * ty), tx * tx * (3 - 2 * tx)
    a = g[y0, x0] * (1 - tx) + g[y0, x0 + 1] * tx
    b = g[y0 + 1, x0] * (1 - tx) + g[y0 + 1, x0 + 1] * tx
    return (a * (1 - ty) + b * ty - 0.5) * 2 * amp


def coords(w, h):
    """Koordinat pusat texel dalam piksel model untuk sisi w x h."""
    ys, xs = np.mgrid[0:h * S, 0:w * S]
    return (xs + 0.5) / S, (ys + 0.5) / S


def ellipse(x, y, cx, cy, rx, ry):
    return ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2


def paint(u, v, w, h, mat, shade):
    """mat: 0 kain, 1 grafit, 2 list perak, 3 sabuk, 4 emas, -1 kosong. shade: pengali terang."""
    hh, ww = h * S, w * S
    out = np.zeros((hh, ww, 4), float)
    twill = (np.add.outer(np.arange(hh), np.arange(ww)) % 4 < 2) * 0.03 - 0.015
    n_fine = smooth_noise(hh, ww, 2, 0.035)
    n_wide = smooth_noise(hh, ww, 12, 0.05)
    brushed = np.repeat(rng.random((hh, 1)), ww, axis=1) * 0.08 - 0.04
    for m, base, hi, tex in (
            (0, SUIT, SUIT_HI, twill + n_fine + n_wide),
            (1, GRAPH, GRAPH_HI, n_fine * 1.3 + n_wide * 0.6),
            (2, SILVER, SILVER_SH, brushed + n_fine * 0.5),
            (3, BELT, BELT_SH, brushed + n_fine * 0.5),
            (4, GOLD, GOLD_HI, n_fine * 0.6)):
        sel = mat == m
        if not sel.any():
            continue
        k = np.clip(shade + tex, 0.35, 1.6)
        col = np.where(k[..., None] > 1.0, base + (hi - base) * np.clip((k[..., None] - 1.0) / 0.4, 0, 1),
                       base * k[..., None])
        if m == 0:   # kain: bayangan dalam lebih biru tua
            col = np.where(k[..., None] < 0.85, SUIT_DARK + (col - SUIT_DARK) * 0.6, col)
        out[sel, :3] = col[sel]
        out[sel, 3] = 255
    img[v * S:(v + h) * S, u * S:(u + w) * S] = out


def face_shade(x, y, w, h):
    """Gradasi atas-bawah + gelap di tepi sisi (oklusi lembut)."""
    k = 1.04 - 0.08 * (y / h)
    edge = np.minimum.reduce([x, w - x, y, h - y])
    return k - 0.07 * np.clip(1 - edge / 0.6, 0, 1)


# ---------------------------------------------------------------- badan (8 x 12 x 4)

def body_face(kind, w, h):
    x, y = coords(w, h)
    mat = np.zeros(x.shape, int)
    shade = face_shade(x, y, w, h)
    if kind in ("front", "back"):
        # panel samping grafit yang melebar ke pinggang: badan terlihat berbentuk V
        xp = 0.35 + 0.95 * np.clip((y - 1.0) / 8.4, 0, 1) ** 1.3
        side = np.minimum(x, w - x)
        mat[side < xp] = 1
        pipe = (side >= xp) & (side < xp + 0.24)
        mat[pipe] = 2                                                           # list perak
        shade = np.where((side >= xp + 0.24) & (side < xp + 0.6), shade - 0.1, shade)   # bayangan panel timbul
        shade = np.where(side < xp, shade + 0.06 * (side / np.maximum(xp, 1e-3)), shade)
        mat[y < 0.8] = 1                                                        # kerah tinggi
        mat[(y >= 0.8) & (y < 1.02) & (side >= xp)] = 2
        shade = np.where((y >= 1.02) & (y < 1.4) & (side >= xp), shade - 0.08, shade)
        if kind == "front":
            # otot dada & perut: terang di atas, lipatan gelap di bawah
            for cx in (2.45, 5.55):
                e = ellipse(x, y, cx, 3.3, 1.75, 1.45)
                shade += np.where(e < 1, 0.2 * (1 - e) * np.clip((3.6 - y) / 1.6 + 0.4, 0, 1), 0)
                shade -= np.where((e > 0.75) & (e < 1.3) & (y > 3.5), 0.2, 0)
            shade -= np.where((np.abs(x - 4) < 0.18) & (y > 1.2) & (y < 9.3), 0.12, 0)   # garis tengah
            for cy in (6.1, 7.3, 8.5):
                shade -= np.where((np.abs(y - cy) < 0.16) & (np.abs(x - 4) > 0.25) & (np.abs(x - 4) < 1.7), 0.14, 0)
                shade += np.where((y - cy > 0.16) & (y - cy < 0.6) & (np.abs(x - 4) > 0.25) & (np.abs(x - 4) < 1.7), 0.05, 0)
            for cx in (3.2, 4.8):
                e = ellipse(x, y, cx, 7.3, 0.7, 1.8)
                shade += np.where(e < 1, 0.05 * (1 - e), 0)
        else:
            for cx in (2.5, 5.5):   # tulang belikat & otot punggung
                e = ellipse(x, y, cx, 3.6, 1.6, 2.0)
                shade += np.where(e < 1, 0.09 * (1 - e), 0)
            shade -= np.where((np.abs(x - 4) < 0.16) & (y > 1.2) & (y < 9.3), 0.11, 0)
    else:   # sisi badan: panel grafit penuh
        mat[:] = 1
        mat[(np.abs(x - w / 2) < 0.14) & (y > 1.0) & (y < 9.4)] = 2               # jahitan perak di tengah
        mat[y < 0.8] = 1
    belt = (y >= 9.45) & (y < 10.95)
    mat[belt] = 3
    shade = np.where(belt & ((y < 9.65) | (y > 10.75)), shade - 0.25, shade)      # tepi sabuk
    shade = np.where(belt, shade + 0.1 * np.sin((x * 9.0)) * 0.3, shade)
    if kind == "front":   # gesper: cakram matahari keemasan dengan delapan alur sinar
        d = np.hypot(x - w / 2, y - 10.2)
        disc = d < 1.05
        mat[disc] = 4
        ang = np.arctan2(y - 10.2, x - w / 2)
        rays = (np.abs(np.sin(ang * 4.0)) < 0.22) & (d > 0.45) & (d < 0.95)
        shade = np.where(disc, 1.05 - 0.25 * (d / 1.05) + np.where(rays, -0.3, 0) + np.where(d < 0.38, 0.25, 0), shade)
        shade = np.where(disc & (d > 0.9), shade - 0.35, shade)
    return mat, shade


def body_top(w, h):
    x, y = coords(w, h)
    mat = np.zeros(x.shape, int)
    mat[(x > 1.6) & (x < w - 1.6) & (y > 0.5) & (y < h - 0.5)] = 1   # pangkal leher (kerah)
    return mat, face_shade(x, y, w, h) + 0.04


def body_bottom(w, h):
    x, y = coords(w, h)
    return np.zeros(x.shape, int), face_shade(x, y, w, h) - 0.12


# ---------------------------------------------------------------- lengan (4 x 12 x 4)

def arm_face(kind, w, h):
    x, y = coords(w, h)
    mat = np.zeros(x.shape, int)
    shade = face_shade(x, y, w, h)
    shade += np.where(y < 3.2, 0.14 * (1 - y / 3.2), 0)          # bahu membulat
    shade -= np.where(np.abs(y - 3.6) < 0.16, 0.12, 0)           # batas otot bahu
    shade += np.where((y > 3.8) & (y < 6.6), 0.05 * np.sin((y - 3.8) / 2.8 * np.pi), 0)   # otot lengan atas
    mat[(y >= 7.7) & (y < 8.15)] = 2                             # manset perak
    mat[y >= 8.15] = 1                                           # sarung tangan grafit
    shade = np.where((y >= 8.15) & (y < 8.4), shade + 0.18, shade)   # tepi manset sarung tangan yang timbul
    shade = np.where(y >= 8.15, shade + 0.06 * np.cos((y - 8.15) * 1.6), shade)
    shade = np.where((y > 10.6) & (y < 10.85), shade - 0.12, shade)   # buku jari
    return mat, shade


def arm_cap(top, w, h):
    x, y = coords(w, h)
    mat = np.zeros(x.shape, int)
    if not top:
        mat[:] = 1   # telapak/kepalan
    return mat, face_shade(x, y, w, h) + (0.05 if top else -0.05)


# ---------------------------------------------------------------- kaki (4 x 12 x 4)

def leg_face(kind, w, h):
    x, y = coords(w, h)
    mat = np.zeros(x.shape, int)
    shade = face_shade(x, y, w, h)
    if kind == "front":
        e = ellipse(x, y, w / 2, 4.6, 1.3, 0.9)                 # lutut
        shade += np.where(e < 1, 0.08 * (1 - e), 0)
        shade -= np.where((e > 0.9) & (e < 1.3) & (y > 4.6), 0.06, 0)
    if kind == "side":   # garis grafit di sisi kaki (dalam & luar)
        mat[(np.abs(x - w / 2) < 0.45) & (y < 7.0)] = 1
    mat[(y >= 6.75) & (y < 7.2)] = 2                            # list perak di atas sepatu bot
    mat[y >= 7.2] = 1                                           # sepatu bot grafit
    shade = np.where((y >= 7.2) & (y < 7.45), shade + 0.18, shade)   # tepi sepatu bot yang timbul
    boot = y >= 7.2
    shade = np.where(boot, shade + 0.07 * np.cos((y - 7.2) * 1.2), shade)
    if kind == "front":
        shade = np.where(boot & (np.abs(x - w / 2) < 0.12), shade + 0.12, shade)   # jahitan depan sepatu
    shade = np.where(y > 11.45, shade - 0.3, shade)            # sol
    return mat, shade


def leg_cap(top, w, h):
    x, y = coords(w, h)
    mat = np.zeros(x.shape, int)
    if not top:
        mat[:] = 1
    return mat, face_shade(x, y, w, h) + (0.0 if top else -0.35)


# ---------------------------------------------------------------- tata letak kotak

def box(u, v, dx, dy, dz, side_fn, cap_fn, front_kinds):
    """Sisi kotak sesuai tata letak UV ModelPart: atas, bawah, kanan, depan, kiri, belakang."""
    faces = [
        ("top", u + dz, v, dx, dz),
        ("bottom", u + dz + dx, v, dx, dz),
        ("side", u, v + dz, dz, dy),
        ("front", u + dz, v + dz, dx, dy),
        ("side", u + dz + dx, v + dz, dz, dy),
        ("back", u + dz + dx + dz, v + dz, dx, dy),
    ]
    for kind, fu, fv, fw, fh in faces:
        if kind in ("top", "bottom"):
            mat, shade = cap_fn(kind == "top", fw, fh)
        else:
            mat, shade = side_fn(front_kinds.get(kind, kind), fw, fh)
        paint(fu, fv, fw, fh, mat, shade)


def body_side(kind, w, h):
    return body_face(kind, w, h)


def body_cap(top, w, h):
    return body_top(w, h) if top else body_bottom(w, h)


for (u, v) in ((16, 16), (16, 32)):                       # badan & lapisan jaket
    box(u, v, 8, 12, 4, body_side, body_cap, {})
for (u, v) in ((40, 16), (40, 32), (32, 48), (48, 48)):   # lengan kanan, lengan baju kanan, lengan kiri, lengan baju kiri
    box(u, v, 4, 12, 4, arm_face, arm_cap, {})
for (u, v) in ((0, 16), (0, 32), (16, 48), (0, 48)):      # kaki kanan, celana kanan, kaki kiri, celana kiri
    box(u, v, 4, 12, 4, leg_face, leg_cap, {})

out = np.clip(img, 0, 255).astype(np.uint8)
Image.fromarray(out, "RGBA").save(sys.argv[1] if len(sys.argv) > 1 else "suit.png")
