"""SFX Projek Helion-6 (0.43): radiasi Cryon, bukan sihir. Dibuat dari nol dengan alat yang sama dengan synth.py.

    python3 tools/sfx/helion_sfx.py src/main/resources/assets/shazammod/sounds [nama ...]

Ciri suaranya: dengung radiasi rendah (saw berdetune lewat lowpass), detak penghitung Geiger yang makin rapat, retakan
kristal Cryon, dan dentuman dengan sub-bass. Waktu puncak dikunci ke tick animasi (lihat ShazamAnim.HELION_*):
helion_transform 0,8 dtk, helion_beam_charge 0,5 dtk, helion_quake meledak di 0,6 dtk, helion_nova di 3,0 dtk,
helion_inhale melonjak di 0,9 dtk, helion_rite meledak di 5,6 dtk.
"""
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
_argv = sys.argv
sys.argv = [sys.argv[0]]          # synth.py membaca sys.argv[1] sebagai folder keluaran saat diimpor
import synth as s                 # noqa: E402
sys.argv = _argv

SR = s.SR


def clicks(dur, rate, rng, amp=1.0):
    """Penghitung Geiger: klik tajam acak; rate = angka atau kurva (klik per detik)."""
    n = int(dur * SR)
    y = np.zeros(n)
    curve = np.full(n, float(rate)) if np.isscalar(rate) else np.interp(np.arange(n), np.linspace(0, n - 1, len(rate)), rate)
    t = 0.0
    kn = int(0.004 * SR)
    while t < dur:
        i = min(int(t * SR), n - 1)
        r = max(curve[i], 0.5)
        k = rng.standard_normal(kn) * s.env_exp(kn, 0.00035 + rng.uniform(0, 0.0003))
        e = min(n, i + kn)
        y[i:e] += k[: e - i] * rng.uniform(0.5, 1.0) * amp
        t += rng.exponential(1.0 / r)
    return s.bp(y, 1400, 9000, 2) + s.bp(y, 2600, 3400, 2) * 0.6


def drone(dur, f0, f1=None, detune=0.012, cutoff=520, flutter=6.0):
    """Dengung radiasi: tiga saw berdetune (akar, kuint, oktaf) lewat lowpass, bergetar halus."""
    fa = float(f0) if f1 is None else np.geomspace(f0, f1, 64)
    y = (s.osc(fa, dur, "saw") + s.osc(fa * (1 + detune), dur, "saw") * 0.8 + s.osc(fa * 1.5 * (1 - detune), dur, "saw") * 0.55
         + s.osc(fa * 2.0 * (1 + detune * 0.5), dur, "saw") * 0.3)
    t = s.t_axis(dur)
    y = s.lp(y, cutoff, 2) * (0.78 + 0.22 * np.sin(2 * np.pi * flutter * t))
    return y


def crystal(dur, rng, f0=2600.0):
    """Retakan kristal Cryon: percikan tinggi + beberapa nada kaca yang pendek."""
    y = s.crackle(dur, 900, rng, 2500, 11000, 0.0015) * 1.2
    t = s.t_axis(dur)
    for k, a in ((1.0, 0.5), (1.73, 0.35), (2.61, 0.25), (3.9, 0.15)):
        y = y + np.sin(2 * np.pi * f0 * k * (1 + rng.uniform(-0.01, 0.01)) * t) * np.exp(-t / (0.05 + rng.uniform(0, 0.04))) * a
    return y


def lubdub(rng, gain=1.0, f=58.0):
    a = s.thump(rng, f, f * 0.62, 0.35, 0.07, 0.25, 0.15)
    b = s.thump(rng, f * 0.9, f * 0.58, 0.35, 0.06, 0.2, 0.1) * 0.7
    return s.mix(a, s.at(b, 0.17)) * gain


def roar(dur, rng, f0=55.0, drop=0.7):
    """Raungan radiasi: akor saw yang terdistorsi, lowpass menyapu turun."""
    y = drone(dur, f0, f0 * drop, 0.02, 2400, 9.0)
    curve = np.concatenate([np.geomspace(2800, 900, 20), np.geomspace(900, 260, 44)])
    y = s.sweep_filter(y + s.pink(len(y), rng) * 0.15, curve, "low", 0.9)
    return s.sat(y * 1.8, 2.4)


def blast(rng, dur=2.6, f0=95.0, f1=28.0, tau=0.55, bright=1.0):
    """Ledakan: dentum sub + semburan noise + retakan + raungan radiasi."""
    th = s.thump(rng, f0, f1, dur, tau, 0.9, 0.5) * 1.1
    n = int(dur * SR)
    noise = s.bp(s.white(n, rng), 180, 7000, 2) * s.env_exp(n, 0.16) * 0.9 * bright
    crack = s.crackle(dur, 380, rng, 1500, 9000, 0.003, curve=np.geomspace(1.0, 0.02, 32)) * 0.6
    r = roar(min(dur, 1.8), rng, 55, 0.6) * 0.55
    return s.mix(th, noise, crack, r)


# ------------------------------------------------------------------ resep

def geiger(rng, v):
    dur = 0.9
    rate = (14.0, 28.0, 55.0)[v % 3]
    return s.reverb(clicks(dur, rate, rng), 0.6, 0.12, rng=rng)


def helion_pulse(rng, v):          # Denyut Cryon tiap 2 detik: dentum lembut, dengung naik-turun, Geiger
    dur = 1.4
    t = s.t_axis(dur)
    hum = drone(dur, 49 * (1 + 0.03 * v), None, 0.012, 380, 5.5) * np.minimum(1, t / 0.08) * np.exp(-t / 0.7) * 0.8
    th = s.thump(rng, 72, 36, 0.9, 0.18, 0.4, 0.2) * 0.6
    g = clicks(dur, np.geomspace(80, 6, 32), rng, 0.5)
    shim = np.sin(2 * np.pi * np.cumsum(np.geomspace(500, 1500, len(t))) / SR) * np.exp(-t / 0.35) * 0.06
    y = s.mix(hum, th, g, shim)
    return s.reverb(y, 1.2, 0.25, rng=rng)


def helion_transform(rng, v):      # 0,8 dtk persis: radiasi membanjiri tubuh, memuncak di tick kostum terbentuk
    dur = 0.8
    t = s.t_axis(dur)
    rise = s.reverse_swell(dur, rng, 300, 9000) * 0.7
    hum = drone(dur, 38, 92, 0.015, 900, 7.0) * (t / dur) ** 1.5
    g = clicks(dur, np.geomspace(6, 220, 40), rng, 0.7)
    beats = s.mix(s.at(lubdub(rng, 0.9), 0.05), s.at(lubdub(rng, 1.1, 64), 0.42))
    fizz = s.electric_field(dur, rng, np.geomspace(2, 160, 16), (0.004, 0.02), 0.25)
    y = s.mix(rise, hum, g, beats, fizz)
    return s.pad(s.sat(y, 1.4), dur)


def helion_burst(rng, v):          # ledakan radiasi saat kostum terbentuk
    y = blast(rng, 3.0, 100 - 10 * v, 30, 0.6)
    t = s.t_axis(3.0)
    glass = crystal(0.6, rng, 2300 + 300 * v) * 0.35
    g = clicks(3.0, np.geomspace(260, 4, 40), rng, 0.45)
    y = s.mix(y, glass, g)
    return s.reverb2(s.master_eq(y), 2.6, 1.0, 0.26, rng=rng)


def helion_dash(rng, v):           # melesat: desing berat, retakan sonik, ekor radiasi
    dur = 1.0
    w = s.air_whoosh(dur, rng, 260, 2400, 380, 1.2, 0.22) * 1.2
    z = s.zip_by(0.18, rng, 5000, 1400, True) * 0.5
    crack = s.transient(0.012, 1200, 0.002, 1.4, rng)
    trail = s.electric_field(dur, rng, np.geomspace(120, 4, 20), (0.004, 0.03), 0.35)
    th = s.thump(rng, 90, 45, 0.5, 0.08, 0.4, 0.4) * 0.6
    y = s.mix(s.at(z, 0.0), s.at(crack, 0.16), w, trail, s.at(th, 0.15))
    return s.reverb(s.sat(y, 1.5), 0.8, 0.18, rng=rng)


def helion_beam_charge(rng, v):    # 0,5 dtk persis: mata mengumpulkan radiasi
    dur = 0.5
    t = s.t_axis(dur)
    f = np.geomspace(260, 1500, len(t)) * (1 + 0.02 * np.sin(2 * np.pi * 31 * t))
    whine = np.sin(2 * np.pi * np.cumsum(f) / SR) * (t / dur) ** 1.4 * 0.5
    hum = drone(dur, 55, 110, 0.02, 1500, 11.0) * (t / dur) ** 1.2 * 0.6
    g = clicks(dur, np.geomspace(30, 400, 24), rng, 0.6)
    y = s.mix(whine, hum, g, s.reverse_swell(dur, rng, 1500, 11000) * 0.4)
    return s.pad(s.sat(y, 1.3), dur)


def helion_beam_fire(rng, v):      # sinar menyembur: desis panas, dentum kecil, akor saw yang menyala
    dur = 1.2
    t = s.t_axis(dur)
    n = len(t)
    hiss = s.bp(s.white(n, rng), 1800, 9000, 2) * s.env_exp(n, 0.12) * 0.8
    chord = drone(dur, 110 * (1 + 0.04 * v), None, 0.018, 3200, 13.0) * np.minimum(1, t / 0.01) * np.exp(-t / 0.5)
    th = s.thump(rng, 120, 60, 0.6, 0.07, 0.5, 0.4) * 0.7
    z = s.electric_field(dur, rng, np.geomspace(140, 6, 20), (0.004, 0.02), 0.4)
    return s.reverb(s.sat(s.mix(hiss, chord, th, z), 1.6), 0.9, 0.2, rng=rng)


def helion_beam_loop(rng, v):      # sinar menyala (diulang): dengung berat berdenyut, desis, letupan
    dur, xf = 2.0, 0.4
    L = dur + xf
    t = s.t_axis(L)
    f0 = 110.0   # 220 putaran dalam 2 detik: sambungannya bulat
    buzz = (s.osc(f0, L, "saw") + s.osc(f0 * 1.01, L, "saw") * 0.7 + s.osc(f0 * 1.5, L, "saw") * 0.45
            + s.osc(f0 * 2, L, "saw") * 0.3)
    buzz = s.lp(buzz, 2600, 2) * (0.75 + 0.25 * np.sin(2 * np.pi * 8 * t))
    hiss = s.bp(s.white(len(t), rng), 2500, 9000, 2) * 0.25 * (0.8 + 0.2 * np.sin(2 * np.pi * 3 * t))
    sub = np.sin(2 * np.pi * 55 * t) * 0.35
    pops = s.crackle(L, 30, rng, 800, 6000, 0.004) * 0.8
    y = s.sat(buzz * 0.8 + hiss + sub + pops, 1.5)
    return s.seamless(y, int(dur * SR), int(xf * SR))


def helion_quake(rng, v):          # Injakan Cryon: 0,6 dtk tenaga terhimpun, lalu tanah dihantam
    wind = 0.6
    up = s.reverse_swell(wind, rng, 120, 3000) * 0.6 + drone(wind, 36, 70, 0.02, 500, 9.0) * np.linspace(0, 0.7, int(wind * SR))
    up = up + clicks(wind, np.geomspace(10, 160, 16), rng, 0.4)
    hit = blast(rng, 2.6, 85 - 8 * v, 26, 0.7)
    crack = s.earth_crack(rng, v) * 0.6
    rattle = s.crackle(2.0, 60, rng, 300, 3000, 0.01, curve=np.geomspace(1.0, 0.05, 24)) * 0.7
    y = s.mix(up, s.at(s.mix(hit, crack, s.at(rattle, 0.2)), wind))
    return s.reverb2(s.master_eq(y), 2.8, 1.1, 0.24, rng=rng)


def helion_nova(rng, v):           # Supernova-6: 3 dtk radiasi terhimpun, hening sesaat, lalu ledakan raksasa tepat di 3 dtk
    wind = 3.0
    t = s.t_axis(wind)
    k = t / wind
    hum = drone(wind, 33, 66, 0.025, 1800, 7.0) * k ** 1.3 * 0.9
    rise = s.reverse_swell(wind, rng, 150, 12000) * 0.6
    g = clicks(wind, np.geomspace(4, 900, 60), rng, 0.55)
    fizz = s.electric_field(wind, rng, np.geomspace(1, 220, 30), (0.004, 0.04), 0.35)
    beats = 0
    for bt in (0.15, 0.85, 1.45, 1.95, 2.32, 2.6, 2.8):
        beats = s.mix(beats, s.at(lubdub(rng, 0.7 + 0.3 * bt / wind, 56 + 10 * bt), bt)) if not np.isscalar(beats) else s.at(lubdub(rng, 0.7, 56), bt)
    charge = s.mix(hum, rise, g, fizz, beats)
    gate = np.ones(len(charge))
    cut = int((wind - 0.12) * SR)
    gate[cut:] = np.linspace(1, 0.05, len(gate) - cut)   # tarikan vakum sekejap sebelum meledak
    charge = s.pad(charge * gate, wind)
    boom = blast(rng, 4.2, 110, 22, 1.0, 1.2)
    brass = s.brass_hit([55, 82.4, 110], 2.6, rng) * 0.55
    glass = crystal(0.9, rng, 1900) * 0.3
    y = s.mix(charge, s.at(s.mix(boom, brass, glass), wind))
    return s.reverb2(s.master_eq(y, 0.3), 3.6, 1.4, 0.3, rng=rng)


def helion_inhale(rng, v):         # Hirup Cryon: kristal diremukkan, dihirup dalam, lalu tenaganya meledak (0,9 dtk)
    crunch = s.mix(crystal(0.35, rng, 2900) * 0.9, s.crackle(0.3, 1500, rng, 600, 6000, 0.002) * 0.6)
    n = int(0.6 * SR)
    tt = np.arange(n) / SR
    breath = s.sweep_filter(s.pink(n, rng), np.geomspace(500, 2600, 32), "band", 1.6) * (tt / 0.6) ** 1.2 * 1.1
    g = clicks(0.6, np.geomspace(20, 300, 20), rng, 0.5)
    surge = s.mix(s.thump(rng, 80, 34, 1.4, 0.3, 0.6, 0.3), roar(1.3, rng, 62, 0.75) * 0.7,
                  clicks(1.3, np.geomspace(240, 8, 24), rng, 0.4))
    y = s.mix(s.at(crunch, 0.12), s.at(s.mix(breath, g), 0.3), s.at(surge, 0.9))
    return s.reverb(s.master_eq(y), 1.4, 0.24, rng=rng)


def helion_sun_burn(rng, v):       # kulit terbakar matahari: desis & letupan, dengung kesakitan yang bergetar
    dur = 1.3
    t = s.t_axis(dur)
    n = len(t)
    sizzle = s.bp(s.white(n, rng), 3000, 10000, 2) * (0.5 + 0.5 * np.abs(np.sin(2 * np.pi * 2.3 * t + v))) * 0.4
    pops = s.crackle(dur, 70, rng, 1200, 7000, 0.002) * 0.8
    f = 62 * (1 + 0.04 * np.sin(2 * np.pi * 5.5 * t))
    moan = s.lp(s.osc(f, dur, "saw") + s.osc(f * 1.5, dur, "saw") * 0.4, 420) * np.sin(np.pi * t / dur) * 0.5
    env = np.minimum(1, t / 0.05) * np.clip((dur - t) / 0.4, 0, 1)
    return s.reverb((sizzle + pops + moan) * env, 0.8, 0.15, rng=rng)


def helion_punch(rng, v):          # tinju radioaktif
    p = s.punch(rng, v)
    z = s.electric_field(0.4, rng, np.geomspace(200, 10, 12), (0.003, 0.015), 0.35)
    th = s.thump(rng, 100, 48, 0.5, 0.08, 0.5, 0.4) * 0.6
    return s.reverb(s.sat(s.mix(p, z, th), 1.5), 0.6, 0.15, rng=rng)


def helion_cryon_punch(rng, v):    # Tinju Cryon (muatan penuh): hantaman + semburan radiasi
    p = s.punch(rng, v, True)
    b = blast(rng, 1.6, 120, 40, 0.3, 0.8) * 0.8
    glass = crystal(0.4, rng, 2500 + 200 * v) * 0.3
    return s.reverb2(s.master_eq(s.mix(p, b, glass)), 1.6, 0.8, 0.2, rng=rng)


def helion_rite(rng, v):           # Eksperimen Proyek Helion-6: suntikan, Geiger, detak jantung memburu, ledakan di 5,6 dtk
    dur, strike = 7.6, 5.6
    t = s.t_axis(dur)
    click = s.transient(0.01, 1500, 0.0015, 1.2, rng)
    hiss_n = int(0.45 * SR)
    hiss = s.bp(s.white(hiss_n, rng), 2500, 9000, 2) * np.linspace(1, 0.2, hiss_n) * 0.5
    g = clicks(strike, np.concatenate([np.geomspace(2, 40, 30), np.geomspace(40, 700, 30)]), rng, 0.5)
    hum = drone(strike, 30, 64, 0.03, 900, 6.0) * np.linspace(0, 1, int(strike * SR)) ** 1.5 * 0.7
    beats = np.zeros(int(strike * SR))
    bt, gap = 0.6, 1.0
    while bt < strike - 0.3:
        beats = s.mix(beats, s.at(lubdub(rng, 0.6 + 0.5 * bt / strike, 54 + 6 * bt / strike), bt))
        bt += gap
        gap = max(0.36, gap * 0.9)
    fizz = s.electric_field(strike, rng, np.concatenate([np.zeros(20), np.geomspace(2, 200, 20)]), (0.004, 0.05), 0.3)
    growl = s.at(roar(1.2, rng, 46, 0.9) * 0.35, 4.2)
    boom = blast(rng, 2.0, 100, 28, 0.6)
    y = s.mix(click, s.at(hiss, 0.05), g, hum, beats, fizz, growl, s.at(boom, strike))
    return s.reverb2(s.master_eq(s.pad(y, dur)), 2.4, 1.0, 0.24, rng=rng)


def helion_power_down(rng, v):     # radiasi padam: dengung turun, Geiger melambat
    dur = 1.6
    t = s.t_axis(dur)
    hum = drone(dur, 82, 26, 0.02, 700, 5.0) * np.exp(-t / 0.7)
    g = clicks(dur, np.geomspace(120, 2, 24), rng, 0.45)
    fizz = s.electric_field(dur, rng, np.geomspace(80, 1, 16), (0.004, 0.02), 0.25)
    th = s.thump(rng, 60, 30, 0.8, 0.2, 0.3, 0.1) * 0.5
    return s.reverb(s.mix(hum, g, fizz, th), 1.2, 0.22, rng=rng)


RECIPES = {
    "helion_transform": (helion_transform, 1, 0.9),
    "helion_burst": (helion_burst, 2, 1.0),
    "helion_pulse": (helion_pulse, 3, 0.75),
    "geiger": (geiger, 3, 0.6),
    "helion_dash": (helion_dash, 2, 0.95),
    "helion_beam_charge": (helion_beam_charge, 1, 0.8),
    "helion_beam_fire": (helion_beam_fire, 2, 0.95),
    "helion_beam_loop": (helion_beam_loop, 1, 0.75),
    "helion_quake": (helion_quake, 2, 1.0),
    "helion_nova": (helion_nova, 1, 1.0),
    "helion_inhale": (helion_inhale, 1, 0.95),
    "helion_sun_burn": (helion_sun_burn, 2, 0.7),
    "helion_punch": (helion_punch, 2, 0.95),
    "helion_cryon_punch": (helion_cryon_punch, 2, 1.0),
    "helion_rite": (helion_rite, 1, 1.0),
    "helion_power_down": (helion_power_down, 1, 0.85),
}
WINDUPS = {"helion_transform", "helion_beam_charge"}
LOOPS = {"helion_beam_loop"}

s.RECIPES.update(RECIPES)
s.WINDUPS.update(WINDUPS)
s.LOOPS.update(LOOPS)

if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "out"
    only = sys.argv[2:] if len(sys.argv) > 2 else None
    os.makedirs(out, exist_ok=True)
    for name, (fn, count, gain) in RECIPES.items():
        if only and name not in only:
            continue
        for v in range(count):
            y = s.render(name, fn, v, gain)
            fname = f"{name}_{v + 1}.ogg"
            s.encode(y, os.path.join(out, fname))
            rms = 20 * np.log10(np.sqrt(np.mean(y ** 2)) + 1e-9)
            print(fname, round(len(y) / SR, 2), "dtk", round(float(rms), 1), "dB", flush=True)
