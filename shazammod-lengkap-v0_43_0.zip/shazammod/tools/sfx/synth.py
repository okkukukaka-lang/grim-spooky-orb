"""
Synth SFX sinematik untuk mod Shazam.
Semua suara dibuat dari nol (numpy/scipy), mono 44.1 kHz (Minecraft butuh mono untuk suara berposisi).
"""
import numpy as np
from scipy import signal
import os, subprocess, json, sys

SR = 44100
OUT = sys.argv[1] if len(sys.argv) > 1 else "out"


# ------------------------------------------------------------------ dasar
def t_axis(dur):
    return np.arange(int(dur * SR)) / SR


def pad(x, dur):
    n = int(dur * SR)
    if len(x) >= n:
        return x[:n]
    return np.concatenate([x, np.zeros(n - len(x))])


def mix(*parts):
    n = max(len(p) for p in parts)
    out = np.zeros(n)
    for p in parts:
        out[:len(p)] += p
    return out


def at(x, sec, total=None):
    """Geser x mulai di detik sec."""
    off = np.zeros(int(sec * SR))
    y = np.concatenate([off, x])
    return pad(y, total) if total else y


def white(n, rng):
    return rng.standard_normal(n)


def pink(n, rng):
    w = rng.standard_normal(n)
    b, a = [0.049922035, -0.095993537, 0.050612699, -0.004408786], [1, -2.494956002, 2.017265875, -0.522189400]
    return signal.lfilter(b, a, w) * 4


def brown(n, rng):
    w = rng.standard_normal(n)
    y = signal.lfilter([1], [1, -0.995], w)
    return y / (np.max(np.abs(y)) + 1e-9)


def sos(kind, f, order=2):
    if kind == "bp":
        return signal.butter(order, [max(f[0], 10) / (SR / 2), min(f[1], SR / 2 - 100) / (SR / 2)], "band", output="sos")
    return signal.butter(order, min(max(f, 10), SR / 2 - 100) / (SR / 2), kind, output="sos")


def lp(x, f, o=2): return signal.sosfilt(sos("low", f, o), x)
def hp(x, f, o=2): return signal.sosfilt(sos("high", f, o), x)
def bp(x, lo, hi, o=2): return signal.sosfilt(sos("bp", (lo, hi), o), x)


def sweep_filter(x, f_curve, kind="low", q=0.9, block=256):
    """Filter yang frekuensinya berubah sepanjang waktu (state-variable filter per-sampel, blok koefisien)."""
    y = np.zeros_like(x)
    low = band = 0.0
    n = len(x)
    fc = np.interp(np.arange(n), np.linspace(0, n - 1, len(f_curve)), f_curve)
    damp = 1.0 / q
    for i in range(0, n, block):
        f = min(fc[i], SR / 6)
        g = 2 * np.sin(np.pi * f / SR)
        seg = x[i:i + block]
        out = np.empty_like(seg)
        for j, s in enumerate(seg):
            high = s - low - damp * band
            band += g * high
            low += g * band
            out[j] = low if kind == "low" else (band if kind == "band" else high)
        y[i:i + block] = out
    return y


def env_exp(n, tau):
    return np.exp(-np.arange(n) / (tau * SR))


def env_adsr(dur, a, d, s, r, curve=2.0):
    n = int(dur * SR)
    na, nd, nr = int(a * SR), int(d * SR), int(r * SR)
    ns = max(n - na - nd - nr, 0)
    e = np.concatenate([
        np.linspace(0, 1, max(na, 1)) ** curve,
        np.linspace(1, s, max(nd, 1)),
        np.full(ns, s),
        np.linspace(s, 0, max(nr, 1)) ** 1.5 if s > 0 else np.zeros(max(nr, 1)),
    ])
    return pad(e, dur)


def osc(freq, dur, kind="sine", phase=0.0):
    """freq bisa angka atau array (sweep)."""
    n = int(dur * SR)
    f = np.full(n, freq) if np.isscalar(freq) else np.interp(np.arange(n), np.linspace(0, n - 1, len(freq)), freq)
    ph = 2 * np.pi * np.cumsum(f) / SR + phase
    if kind == "sine":
        return np.sin(ph)
    if kind == "saw":   # saw band-limited kasar (polyBLEP sederhana)
        p = (ph / (2 * np.pi)) % 1.0
        dt = f / SR
        y = 2 * p - 1
        m1 = p < dt
        y[m1] -= (lambda t: t + t - t * t - 1)(p[m1] / dt[m1])
        m2 = p > 1 - dt
        y[m2] -= (lambda t: t * t + t + t + 1)((p[m2] - 1) / dt[m2])
        return y
    if kind == "tri":
        return 2 / np.pi * np.arcsin(np.sin(ph))
    if kind == "square":
        return np.tanh(4 * np.sin(ph))
    raise ValueError(kind)


def exp_sweep(f0, f1, dur, k=6.0):
    t = np.linspace(0, 1, int(dur * SR))
    return f1 + (f0 - f1) * np.exp(-k * t)


def supersaw(freq, dur, voices=7, detune=0.012, rng=None):
    rng = rng or np.random.default_rng(0)
    y = 0
    for v in range(voices):
        d = 1 + detune * (v - (voices - 1) / 2) / ((voices - 1) / 2)
        f = freq * d if np.isscalar(freq) else np.asarray(freq) * d
        y = y + osc(f, dur, "saw", rng.uniform(0, 2 * np.pi))
    return y / voices


def sat(x, drive=2.0):
    return np.tanh(x * drive) / np.tanh(drive)


def norm(x, peak=0.89):
    m = np.max(np.abs(x))
    return x if m < 1e-9 else x * (peak / m)


def fade(x, fin=0.002, fout=0.05):
    n = len(x)
    a, b = int(fin * SR), int(fout * SR)
    e = np.ones(n)
    if a:
        e[:a] = np.linspace(0, 1, a)
    if b:
        e[-b:] *= np.linspace(1, 0, b) ** 2
    return x * e


def reverb(x, decay=2.0, mix_=0.35, pre=0.012, bright=6000, rng=None, size=1.0):
    """Reverb konvolusi dengan IR buatan (noise yang meluruh, makin gelap di ekornya)."""
    rng = rng or np.random.default_rng(7)
    n = int(decay * 1.4 * SR)
    ir = rng.standard_normal(n) * env_exp(n, decay / 6.9)
    # ekor makin gelap
    w = np.linspace(0, 1, n) ** 0.7
    ir = lp(ir, bright) * (1 - w) + lp(ir, bright * 0.3) * w
    # pantulan awal
    er = np.zeros(int(0.08 * SR * size))
    for k in range(12):
        idx = int(rng.uniform(0.004, 0.075) * SR * size)
        if idx < len(er):
            er[idx] += rng.uniform(-0.6, 0.6)
    ir = mix(er, at(ir, pre))
    ir /= np.sqrt(np.sum(ir ** 2)) + 1e-9
    wet = signal.fftconvolve(x, ir)[: len(x) + len(ir)]
    dry = np.concatenate([x, np.zeros(len(wet) - len(x))])
    return dry * (1 - mix_) + wet * mix_ * 1.6


def trim_tail(x, thresh_db=-62):
    th = 10 ** (thresh_db / 20) * np.max(np.abs(x))
    idx = np.where(np.abs(x) > th)[0]
    end = idx[-1] + int(0.02 * SR) if len(idx) else len(x)
    return x[:end]


def limiter(x, ceiling=0.89, release=0.08):
    """Limiter sederhana dengan look-ahead kecil supaya suara keras tetap tebal tanpa pecah."""
    env = np.abs(x)
    env = signal.lfilter([1], [1, -np.exp(-1 / (release * SR))], env) * (1 - np.exp(-1 / (release * SR)))
    env = np.maximum(env, np.abs(x))
    gain = np.minimum(1.0, ceiling / (env + 1e-9))
    gain = signal.filtfilt([0.02], [1, -0.98], gain)
    return x * np.minimum(gain, 1.0)


def crackle(dur, density, rng, lo=2000, hi=9000, decay=0.003, curve=None):
    """Percikan listrik / retakan: impuls acak tersaring."""
    n = int(dur * SR)
    y = np.zeros(n)
    dens = np.full(n, density) if curve is None else np.interp(np.arange(n), np.linspace(0, n - 1, len(curve)), curve) * density
    p = dens / SR
    hits = np.where(rng.random(n) < p)[0]
    ker_n = int(decay * 6 * SR)
    ker = rng.standard_normal(ker_n) * env_exp(ker_n, decay)
    for h in hits:
        a = rng.uniform(0.3, 1.0) * (1 if rng.random() < 0.5 else -1)
        e = min(n, h + ker_n)
        y[h:e] += a * ker[: e - h]
    return bp(y, lo, hi)


def bell(freq, dur, rng, partials=((1, 1), (2.76, 0.5), (5.4, 0.25), (8.93, 0.12)), tau=0.8, detune=0.0015):
    y = 0
    for r, a in partials:
        f = freq * r * (1 + rng.uniform(-detune, detune))
        if f > 16000:
            continue
        y = y + a * osc(f, dur) * env_exp(int(dur * SR), tau / (r ** 0.5))
    n = int(dur * SR)
    att = np.minimum(1, np.arange(n) / (0.002 * SR))
    rel = np.minimum(1, (n - np.arange(n)) / (min(0.6, dur * 0.4) * SR)) ** 2   # ekor nggak terpotong
    return y * att * rel


def formant(x, vowel="a"):
    F = {"a": [(800, 1.0), (1150, 0.6), (2900, 0.25)], "o": [(450, 1.0), (800, 0.5), (2830, 0.15)],
         "u": [(325, 1.0), (700, 0.35), (2530, 0.1)], "e": [(400, 1.0), (1600, 0.5), (2700, 0.25)]}[vowel]
    y = 0
    for f, a in F:
        y = y + a * bp(x, f * 0.85, f * 1.15, 2)
    return y


def choir(freqs, dur, rng, vowel="a", vib=5.2):
    t = t_axis(dur)
    y = 0
    for f in freqs:
        for v in range(4):
            vf = f * (1 + rng.uniform(-0.006, 0.006)) * (1 + 0.004 * np.sin(2 * np.pi * (vib + rng.uniform(-0.5, 0.5)) * t + rng.uniform(0, 6)))
            y = y + osc(vf, dur, "saw", rng.uniform(0, 6))
    y = formant(y, vowel) + 0.15 * lp(y, 900)
    return y


def reverse_swell(dur, rng, lo=600, hi=12000):
    """'Reverse cymbal' / tarikan napas sebelum hantaman."""
    n = int(dur * SR)
    x = hp(white(n, rng), lo) * env_exp(n, dur / 4)[::-1]
    x = sweep_filter(x, np.linspace(1500, hi, 64), "low", 0.8)
    return x


def sub_drop(f0, f1, dur, tau, k=5.0):
    n = int(dur * SR)
    return osc(exp_sweep(f0, f1, dur, k), dur) * env_exp(n, tau) * np.minimum(1, np.arange(n) / (0.003 * SR))


# ------------------------------------------------------------------ resep suara
def thunder(rng, v):
    dur = 6.0 + v * 0.4
    n = int(dur * SR)
    # retakan awal: beberapa sambaran di 0-200 ms
    crack = crackle(0.35, 900, rng, 1500, 12000, 0.0025, np.linspace(1, 0.05, 50) ** 2) * 1.6
    snap = hp(white(int(0.03 * SR), rng), 900) * env_exp(int(0.03 * SR), 0.006) * 2.5
    # gemuruh: brown noise lowpass yang menutup + gelombang ledakan kecil acak
    rum = brown(n, rng)
    bursts = np.zeros(n)
    tt = 0.15
    while tt < dur * 0.75:
        k = int(tt * SR)
        L = int(rng.uniform(0.3, 1.1) * SR)
        e = env_adsr(L / SR, rng.uniform(0.03, 0.2), 0.1, 0.6, L / SR * 0.6) * rng.uniform(0.4, 1.0) * np.exp(-tt / 2.2)
        bursts[k:k + len(e)] += e[: max(0, min(len(e), n - k))]
        tt += rng.uniform(0.18, 0.55)
    base = env_adsr(dur, 0.06, 0.6, 0.55, dur * 0.7) * 0.6
    rum = sweep_filter(rum, np.geomspace(1400, 110, 80), "low", 0.8) * (base + bursts)
    rum = rum + 0.6 * lp(pink(n, rng), 300) * (bursts * 0.7)
    sub = sub_drop(62, 32, dur, 1.6, 2.0) * 0.55
    y = mix(snap, crack, rum * 1.4, sub)
    y = reverb(sat(y, 1.6), 3.5, 0.3, rng=rng, size=2.0)
    return y


def lightning_strike(rng, v):
    dur = 2.2
    n = int(dur * SR)
    snap = hp(white(int(0.02 * SR), rng), 2000) * env_exp(int(0.02 * SR), 0.004) * 3
    zap_curve = np.concatenate([np.ones(10), np.linspace(1, 0, 40) ** 3])
    zap = crackle(1.1, 2600, rng, 1800, 14000, 0.0015, zap_curve) * 1.5
    # dengung listrik (arc buzz)
    buzzf = 95 + v * 12
    buzz = osc(buzzf * (1 + 0.03 * rng.standard_normal(int(1.0 * SR)).cumsum() / 300), 1.0, "saw")
    buzz = bp(sat(buzz, 3), 300, 4000) * env_exp(int(1.0 * SR), 0.18) * (0.6 + 0.4 * (rng.random(int(1.0 * SR)) > 0.35))
    boom = sub_drop(140, 38, 1.6, 0.35, 7) * 1.3
    body = lp(white(int(0.6 * SR), rng), 500) * env_exp(int(0.6 * SR), 0.09) * 1.2
    y = mix(snap, zap, buzz * 0.45, boom, body)
    return reverb(sat(y, 1.8), 2.2, 0.3, rng=rng)


def impact(rng, v):
    dur = 3.2
    click = hp(white(int(0.008 * SR), rng), 3000) * env_exp(int(0.008 * SR), 0.0015) * 2
    kick = sub_drop(150 - v * 10, 34, 1.8, 0.45, 9) * 1.6
    body = lp(white(int(0.5 * SR), rng), 380) * env_exp(int(0.5 * SR), 0.07) * 2.2
    crunch = bp(white(int(0.25 * SR), rng), 600, 4000) * env_exp(int(0.25 * SR), 0.04) * 0.9
    debris = crackle(1.5, 140, rng, 300, 3500, 0.006, np.linspace(1, 0, 40) ** 2) * 0.7
    rumble = lp(brown(int(dur * SR), rng), 160) * env_adsr(dur, 0.02, 0.3, 0.4, dur * 0.8) * 0.8
    y = mix(click, kick, body, crunch, at(debris, 0.05), rumble)
    y = sat(y, 2.2)
    return reverb(y, 2.6, 0.28, rng=rng, size=1.6)


def impact_ring(rng, v):
    dur = 3.5
    f = [196.0, 174.6, 220.0][v % 3]
    ring = bell(f, dur, rng, ((1, 1), (2.32, 0.6), (3.86, 0.4), (5.12, 0.25), (6.9, 0.15)), tau=1.3, detune=0.004)
    low = bell(f / 2, dur, rng, ((1, 1), (1.5, 0.3)), tau=1.6) * 0.7
    hit = hp(white(int(0.02 * SR), rng), 2500) * env_exp(int(0.02 * SR), 0.004)
    y = mix(ring * 0.6, low * 0.6, hit)
    return reverb(y, 3.0, 0.4, rng=rng, size=1.8)


def body_hit(rng, v):
    dur = 0.9
    thump = sub_drop(110, 45, dur, 0.12, 10) * 1.4
    slap = bp(white(int(0.12 * SR), rng), 250, 2500) * env_exp(int(0.12 * SR), 0.025)
    y = sat(mix(thump, slap), 2.5)
    return reverb(y, 0.9, 0.18, rng=rng)


def whoosh(rng, v, heavy=False):
    dur = (1.35 if heavy else 0.95) + v * 0.06
    n = int(dur * SR)
    x = pink(n, rng) if heavy else white(n, rng)
    peak = rng.uniform(0.45, 0.6)
    shape = np.concatenate([np.linspace(0, 1, int(peak * 64)) ** 2.2, np.linspace(1, 0, 64 - int(peak * 64)) ** 1.4])
    if heavy:
        fcurve = 140 + 1300 * shape
    else:
        fcurve = 350 + 3800 * shape
    y = sweep_filter(x, fcurve, "band", 1.6 if not heavy else 1.2)
    amp = np.interp(np.arange(n), np.linspace(0, n - 1, len(shape)), shape)
    y = y * amp
    if heavy:   # kepakan/flutter berat + sub
        flutter = 1 + 0.35 * np.sin(2 * np.pi * np.linspace(9, 4, n).cumsum() / SR)
        y = y * flutter + osc(exp_sweep(70, 40, dur, 2), dur) * amp ** 2 * 0.35
    return reverb(y, 1.2, 0.2, rng=rng)


def power_up(rng, v):
    rdur, tail = 1.3, 3.0
    f = np.geomspace(110, 440, int(rdur * SR)) * (1 + v * 0.06)
    riser = supersaw(f, rdur, 7, 0.015, rng) + 0.6 * supersaw(f * 1.5, rdur, 5, 0.015, rng)
    riser = sweep_filter(riser, np.geomspace(300, 7000, 64), "low", 1.2) * np.linspace(0.05, 1, int(rdur * SR)) ** 2
    nz = sweep_filter(white(int(rdur * SR), rng), np.geomspace(500, 10000, 64), "band", 2) * np.linspace(0, 1, int(rdur * SR)) ** 3
    hit_t = rdur
    chord = [440, 554.4, 659.3, 880]
    pad_ = sum(supersaw(c * (1 + v * 0.06), tail, 5, 0.01, rng) for c in chord) * env_adsr(tail, 0.005, 0.4, 0.3, tail * 0.7)
    pad_ = lp(pad_, 5000) * 0.5
    shim = sum(bell(rng.choice([1760, 2217, 2637, 3520]), tail, rng, tau=0.6) * 0.3 for _ in range(8))
    boom = sub_drop(90, 40, 1.5, 0.4, 6)
    y = mix(riser * 0.6, nz * 0.25, at(pad_, hit_t), at(shim, hit_t + 0.02), at(boom, hit_t))
    return reverb(sat(y, 1.4), 2.8, 0.38, rng=rng, size=1.5)


def aura_swell(rng, v):
    dur = 3.2
    root = [146.8, 130.8][v % 2]
    ch = choir([root, root * 1.5, root * 2, root * 2.52], dur, rng, "a")
    e = env_adsr(dur, 1.6, 0.4, 0.8, 1.0, 1.6)
    low = supersaw(root / 2, dur, 5, 0.008, rng)
    low = lp(low, 600) * e * 0.6
    air = reverse_swell(dur * 0.6, rng, 1000, 9000) * 0.2
    y = mix(ch * e, low, at(air, dur * 0.35))
    return reverb(y, 3.5, 0.45, rng=rng, size=2.2)


def power_down(rng, v):
    dur = 2.0
    f = np.geomspace(520, 70, int(dur * SR)) * (1 + v * 0.05)
    tone = supersaw(f, dur, 6, 0.02, rng)
    tone = sweep_filter(tone, np.geomspace(6000, 250, 64), "low", 1.4) * env_adsr(dur, 0.01, 0.2, 0.7, 1.3)
    nz = sweep_filter(white(int(dur * SR), rng), np.geomspace(8000, 300, 64), "band", 1.5) * env_exp(int(dur * SR), 0.5) * 0.4
    zap = crackle(0.5, 600, rng, 2000, 9000, 0.002, np.linspace(1, 0, 20)) * 0.5
    y = mix(tone * 0.7, nz, zap)
    return reverb(y, 2.0, 0.35, rng=rng)


def energy_pulse(rng, v):
    dur = 1.3
    f = [523.25, 587.3, 659.3][v % 3]
    n = int(dur * SR)
    mod = osc(f * 2.01, dur) * 3.0 * env_exp(n, 0.15)
    car = np.sin(2 * np.pi * np.cumsum(np.full(n, f)) / SR + mod)
    car = car * env_exp(n, 0.35) * np.minimum(1, np.arange(n) / (0.003 * SR))
    sub = osc(f / 4, dur) * env_exp(n, 0.12) * 0.6
    sh = bell(f * 4, dur, rng, tau=0.4) * 0.25
    y = mix(car * 0.7, sub, sh)
    return reverb(y, 1.8, 0.4, rng=rng)


def charge(rng, v, dur=2.2):
    n = int(dur * SR)
    t = np.linspace(0, 1, n)
    f = 80 * (1 + 5 * t ** 2) * (1 + v * 0.05)
    tone = supersaw(f, dur, 6, 0.02, rng) + 0.5 * supersaw(f * 2, dur, 4, 0.02, rng)
    trem = 0.6 + 0.4 * np.sin(2 * np.pi * np.cumsum(3 + 22 * t ** 2) / SR)
    tone = sweep_filter(tone, np.geomspace(200, 8000, 64), "low", 1.5) * trem * t ** 1.5
    nz = sweep_filter(white(n, rng), np.geomspace(400, 12000, 64), "band", 2.5) * t ** 3
    zap = crackle(dur, 400, rng, 2500, 12000, 0.0015, np.linspace(0, 1, 50) ** 3) * 0.6
    y = mix(tone * 0.7, nz * 0.35, zap)
    y = fade(y, 0.01, 0.015)
    return reverb(y, 1.6, 0.25, rng=rng)


def riser(rng, v):
    """Tarikan sebelum petir transformasi menyambar: berhenti mendadak (hantamannya dari TRANSFORM)."""
    dur = 2.6
    n = int(dur * SR)
    t = np.linspace(0, 1, n)
    rs = reverse_swell(dur, rng, 400, 14000) * 0.6
    f = 55 * 2 ** (3 * t ** 1.6)
    sh = sweep_filter(supersaw(f, dur, 8, 0.02, rng), np.geomspace(200, 9000, 64), "low", 1.6) * t ** 2
    pulse = osc(np.geomspace(2, 16, n), dur, "sine") * 0.5 + 0.5
    hb = sub_drop(60, 40, dur, 10, 1) * pulse * t * 0.6
    y = mix(rs, sh * 0.6, hb)
    y = y * np.concatenate([np.ones(n - int(0.01 * SR)), np.linspace(1, 0, int(0.01 * SR))])
    return reverb(y, 1.2, 0.15, rng=rng)


def shimmer(rng, v):
    dur = 2.4
    scale = [1046.5, 1174.7, 1318.5, 1568, 1760, 2093, 2349.3, 2637, 3136]
    y = np.zeros(int(dur * SR))
    k = 0.0
    for i in range(10 + v * 2):
        b = bell(rng.choice(scale) * (1 if rng.random() > 0.2 else 0.5), dur - k, rng, tau=0.7) * rng.uniform(0.3, 0.8)
        y += at(b, k, dur)
        k += rng.uniform(0.015, 0.07)
    sp = hp(crackle(0.8, 300, rng, 5000, 14000, 0.001, np.linspace(1, 0, 20)), 5000) * 0.2
    y = mix(y, sp)
    return reverb(y, 2.4, 0.5, rng=rng, bright=9000)


def resonance(rng, v):
    dur = 3.0
    f = [220.0, 196.0][v % 2]
    n = int(dur * SR)
    y = 0
    for r, a in ((1, 1), (2.71, 0.5), (5.15, 0.3), (8.4, 0.12)):
        beat = 1 + 0.5 * np.sin(2 * np.pi * rng.uniform(1.5, 4) * t_axis(dur))
        y = y + a * osc(f * r, dur) * beat
    e = env_adsr(dur, 0.25, 0.4, 0.7, 1.8)
    pad_ = lp(supersaw(f / 2, dur, 5, 0.01, rng), 800) * 0.3
    y = (y * 0.4 + pad_) * e
    return reverb(y, 3.0, 0.5, rng=rng)


def spell(rng, v):
    dur = 1.8
    n = int(dur * SR)
    t = t_axis(dur)
    swirl = sweep_filter(white(n, rng), 1500 + 1200 * np.sin(2 * np.pi * 2.5 * np.linspace(0, dur, 64)) + np.linspace(0, 2500, 64), "band", 3)
    swirl *= env_adsr(dur, 0.25, 0.3, 0.5, 1.0) * 0.5
    f0 = [392, 440][v % 2]
    tones = 0
    for i, r in enumerate([1, 1.5, 2, 3]):
        tones = tones + osc(f0 * r * (1 + 0.01 * np.sin(2 * np.pi * 6 * t)), dur) * env_adsr(dur, 0.05 + i * 0.12, 0.3, 0.4, 1.0) * (0.5 / (i + 1))
    sh = shimmer(rng, 0)[: n] * 0.3
    y = mix(swirl, tones, sh)
    return reverb(y, 2.2, 0.45, rng=rng)


def sonic_boom(rng, v):
    dur = 3.0
    pre = reverse_swell(0.35, rng, 800, 9000) * 0.5
    n1 = hp(white(int(0.012 * SR), rng), 400) * env_exp(int(0.012 * SR), 0.003) * 3
    n2 = at(n1 * -0.8, 0.045)
    boom = sub_drop(110, 30, 2.2, 0.55, 5) * 1.7
    air = sweep_filter(white(int(1.5 * SR), rng), np.geomspace(5000, 200, 64), "low", 0.9) * env_exp(int(1.5 * SR), 0.3)
    y = mix(pre, at(mix(n1, n2, boom, air * 0.9), 0.35))
    return reverb(sat(y, 2.0), 2.6, 0.3, rng=rng, size=2.0)


def divine(rng, v):
    dur = 3.6
    root = [261.6, 293.7][v % 2]
    ch = choir([root, root * 1.25, root * 1.5, root * 2], dur, rng, "o" if v else "a")
    e = env_adsr(dur, 0.12, 0.6, 0.6, 2.4)
    bells_ = sum(at(bell(root * m, dur - 0.05 * i, rng, tau=1.2), 0.05 * i, dur) * 0.25 for i, m in enumerate([4, 5, 6, 8]))
    y = mix(ch * e * 0.8, bells_, sub_drop(80, 50, dur, 0.6, 3) * 0.5)
    return reverb(y, 3.6, 0.5, rng=rng, size=2.2, bright=8000)


def punch(rng, v, crit=False):
    dur = 0.9 if not crit else 1.4
    pre = sweep_filter(white(int(0.09 * SR), rng), np.linspace(800, 3000, 16), "band", 1.5) * np.linspace(0, 1, int(0.09 * SR)) ** 2 * 0.5
    k = sub_drop(130 - v * 8, 48, dur, 0.11, 12) * 1.7
    smack = bp(white(int(0.07 * SR), rng), 400, 5000) * env_exp(int(0.07 * SR), 0.012) * 1.5
    y = mix(pre, at(mix(k, smack), 0.09))
    if crit:
        crk = hp(white(int(0.015 * SR), rng), 3000) * env_exp(int(0.015 * SR), 0.002) * 2.5
        ring = bell(880 + v * 60, 1.2, rng, tau=0.5) * 0.25
        y = mix(y, at(crk, 0.09), at(ring, 0.1))
    return reverb(sat(y, 2.4), 1.1, 0.2, rng=rng)


def deflect(rng, v):
    dur = 1.6
    ring = bell(620 + v * 70, dur, rng, ((1, 1), (2.41, 0.6), (3.9, 0.45), (5.6, 0.3), (7.8, 0.2)), tau=0.45, detune=0.006)
    hit = hp(white(int(0.012 * SR), rng), 2000) * env_exp(int(0.012 * SR), 0.003) * 2
    th = sub_drop(100, 60, 0.4, 0.06, 8)
    return reverb(mix(ring * 0.6, hit, th), 1.5, 0.3, rng=rng)


def dark_hiss(rng, v):
    dur = 2.2
    n = int(dur * SR)
    hs = formant(white(n, rng), "u" if v else "o") * 0.7 + hp(white(n, rng), 3500) * 0.25
    hs *= env_adsr(dur, 0.08, 0.3, 0.5, 1.4) * (0.75 + 0.25 * np.sin(2 * np.pi * 11 * t_axis(dur)))
    drone = sat(lp(supersaw(np.linspace(55, 46, n), dur, 5, 0.03, rng), 500), 3) * env_adsr(dur, 0.1, 0.4, 0.6, 1.3) * 0.6
    rev = (lp(white(int(0.5 * SR), rng), 2500) * env_exp(int(0.5 * SR), 0.12))[::-1] * 0.5
    y = mix(rev, at(mix(hs, drone), 0.5))
    return reverb(y, 2.4, 0.4, rng=rng)


def dread(rng, v):
    dur = 4.0
    n = int(dur * SR)
    root = [41.2, 43.65][v % 2]
    cl = 0
    for f in (root, root * 1.06, root * 2, root * 2.12, root * 3):
        cl = cl + supersaw(f, dur, 4, 0.01, rng)
    cl = sweep_filter(cl, np.concatenate([np.geomspace(150, 1400, 20), np.geomspace(1400, 200, 44)]), "low", 1.5)
    cl = sat(cl * env_adsr(dur, 0.04, 0.6, 0.6, 2.6), 2.5)
    rs = reverse_swell(1.0, rng, 300, 8000) * 0.4
    y = mix(rs, at(mix(cl * 0.7, sub_drop(70, 35, dur - 1, 1.2, 3) * 0.8), 1.0))
    return reverb(y, 3.5, 0.4, rng=rng, size=2.0)


def heartbeat(rng, v):
    dur = 1.4
    def beat(a):
        return mix(sub_drop(70, 38, 0.5, 0.08, 6) * a, lp(white(int(0.05 * SR), rng), 200) * env_exp(int(0.05 * SR), 0.015) * a * 0.6)
    y = mix(beat(1.4), at(beat(1.0), 0.24))
    return reverb(sat(y, 2), 1.4, 0.25, rng=rng)


def sand_burst(rng, v):
    dur = 1.8
    n = int(dur * SR)
    gr = crackle(dur, 4000, rng, 1500, 11000, 0.0008, np.concatenate([np.linspace(0.2, 1, 6), np.linspace(1, 0, 40) ** 2])) * 0.7
    body = sweep_filter(pink(n, rng), np.geomspace(3000, 400, 64), "low", 0.8) * env_adsr(dur, 0.02, 0.4, 0.4, 1.2)
    th = sub_drop(90, 45, 0.8, 0.15, 6) * 0.8
    return reverb(mix(gr, body * 0.9, th), 1.6, 0.3, rng=rng)


def earth_crack(rng, v):
    dur = 2.2
    n = int(dur * SR)
    cr = 0
    for lo, hi in ((150, 600), (500, 1800), (1500, 5000)):
        cr = cr + crackle(1.2, 120, rng, lo, hi, 0.008, np.linspace(1, 0, 30) ** 1.5)
    rum = lp(brown(n, rng), 120) * env_adsr(dur, 0.03, 0.5, 0.5, 1.5)
    k = sub_drop(100, 35, 1.5, 0.3, 6)
    return reverb(sat(mix(cr * 1.2, rum, k), 2), 2.0, 0.3, rng=rng)


def fire_blast(rng, v):
    dur = 1.8
    n = int(dur * SR)
    roar = sweep_filter(pink(n, rng), np.concatenate([np.geomspace(300, 2400, 16), np.geomspace(2400, 400, 48)]), "band", 1.0)
    roar *= env_adsr(dur, 0.04, 0.4, 0.5, 1.2) * (0.7 + 0.3 * np.abs(lp(rng.standard_normal(n), 25)) * 6)
    cr = crackle(dur, 250, rng, 1500, 7000, 0.002, np.linspace(1, 0, 20)) * 0.4
    th = sub_drop(80, 40, 1.0, 0.2, 5)
    return reverb(sat(mix(roar * 1.2, cr, th), 1.8), 1.6, 0.25, rng=rng)


def shockwave(rng, v):
    dur = 3.0
    n = int(dur * SR)
    rum = sweep_filter(brown(n, rng), np.geomspace(900, 80, 64), "low", 0.8) * env_adsr(dur, 0.01, 0.5, 0.5, 2.0) * 1.4
    air = sweep_filter(white(n, rng), np.geomspace(6000, 300, 64), "band", 1.2) * env_exp(n, 0.45) * 0.6
    k = sub_drop(75, 28, dur, 0.9, 3) * 1.2
    return reverb(sat(mix(rum, air, k), 1.8), 2.8, 0.3, rng=rng, size=2.0)


def wind_loop(rng, v):
    """Angin terbang yang bisa diputar ulang tanpa sambungan (6 detik)."""
    dur = 6.0
    n = int(dur * SR)
    L = n + int(1.0 * SR)
    x = pink(L, rng)
    # modulasi periodik (kelipatan 1/dur) supaya loop mulus
    tt = np.arange(L) / SR
    mod = 0.6 + 0.25 * np.sin(2 * np.pi * tt / dur * 2) + 0.15 * np.sin(2 * np.pi * tt / dur * 5 + 1)
    fc = 500 + 700 * (0.5 + 0.5 * np.sin(2 * np.pi * np.linspace(0, L / SR, 96) / dur * 3))
    y = sweep_filter(x, fc, "band", 0.9) * mod
    y = y + 0.4 * lp(x, 250) * mod
    y = y + 0.12 * hp(x, 4000) * mod
    # crossfade ujung ke awal
    xf = int(1.0 * SR)
    a = y[:n].copy()
    w = np.linspace(0, 1, xf)
    a[:xf] = a[:xf] * w + y[n:n + xf] * (1 - w)
    return a


def cape_snap(rng, v):
    dur = 0.55
    n = int(dur * SR)
    x = bp(white(n, rng), 700, 4500)
    fl = 0.5 + 0.5 * np.sign(np.sin(2 * np.pi * np.cumsum(np.linspace(28, 14, n)) / SR)) * 0.6
    e = env_adsr(dur, 0.03, 0.08, 0.4, 0.35)
    snap = hp(white(int(0.01 * SR), rng), 1500) * env_exp(int(0.01 * SR), 0.002) * 0.5
    y = mix(x * fl * e * 0.8, at(snap, 0.04))
    return reverb(y, 0.6, 0.12, rng=rng)


def braam(rng, v):
    dur = 4.5
    n = int(dur * SR)
    root = [55.0, 49.0, 51.9][v % 3]
    y = 0
    for f, a in ((root, 1), (root * 1.5, 0.7), (root * 2, 0.6), (root * 3, 0.25)):
        y = y + a * supersaw(f, dur, 7, 0.01, rng)
    fc = np.concatenate([np.geomspace(250, 2200, 6), np.geomspace(2200, 300, 58)])
    y = sweep_filter(y, fc, "low", 2.0)
    y = sat(y * env_adsr(dur, 0.015, 1.0, 0.6, 3.0) * 1.5, 3.0)
    sub = osc(root / 2 if root > 50 else root, dur) * env_adsr(dur, 0.01, 1.0, 0.6, 3.0) * 0.6
    hit = sub_drop(120, 40, 1.2, 0.25, 8) * 0.9
    out = mix(y * 0.8, sub, hit)
    return reverb(out, 4.0, 0.35, rng=rng, size=2.4)


def transform(rng, v):
    """Hantaman SHAZAM!: retakan petir + braam + sub + hujan percikan + paduan suara ilahi di ekornya."""
    dur = 7.0
    crack = mix(hp(white(int(0.03 * SR), rng), 1500) * env_exp(int(0.03 * SR), 0.005) * 3,
                crackle(0.8, 2400, rng, 1500, 14000, 0.002, np.linspace(1, 0, 30) ** 2) * 1.6)
    b = braam(rng, 1 if v else 0)
    kick = sub_drop(160, 30, 2.5, 0.7, 7) * 1.6
    th = thunder(rng, 0) * 0.55
    if v == 0:   # Shazam: ekor ilahi yang terang
        tail = divine(rng, 0) * 0.5
    else:        # Black Adam: ekor gelap
        tail = dread(rng, 0)[int(1.0 * SR):] * 0.6
    y = mix(crack, b * 0.9, kick, at(th, 0.05), at(tail, 0.35))
    y = limiter(sat(y, 1.3), 0.95)
    return y


RECIPES = {
    # nama: (fungsi, jumlah varian, gain relatif)
    "thunder": (thunder, 3, 1.0),
    "lightning_strike": (lightning_strike, 3, 1.0),
    "impact": (impact, 3, 1.0),
    "impact_ring": (impact_ring, 3, 0.75),
    "body_hit": (body_hit, 2, 0.9),
    "whoosh": (lambda r, v: whoosh(r, v, False), 3, 0.85),
    "whoosh_heavy": (lambda r, v: whoosh(r, v, True), 3, 0.9),
    "power_up": (power_up, 2, 0.85),
    "aura_swell": (aura_swell, 2, 0.8),
    "power_down": (power_down, 2, 0.8),
    "energy_pulse": (energy_pulse, 3, 0.7),
    "charge": (charge, 2, 0.8),
    "riser": (riser, 2, 0.85),
    "shimmer": (shimmer, 3, 0.7),
    "resonance": (resonance, 2, 0.7),
    "spell": (spell, 2, 0.75),
    "sonic_boom": (sonic_boom, 2, 1.0),
    "divine": (divine, 2, 0.8),
    "punch": (lambda r, v: punch(r, v, False), 3, 0.95),
    "punch_crit": (lambda r, v: punch(r, v, True), 2, 0.95),
    "deflect": (deflect, 2, 0.8),
    "dark_hiss": (dark_hiss, 2, 0.8),
    "dread": (dread, 2, 0.9),
    "heartbeat": (heartbeat, 1, 1.0),
    "sand_burst": (sand_burst, 2, 0.8),
    "earth_crack": (earth_crack, 2, 0.95),
    "fire_blast": (fire_blast, 2, 0.9),
    "shockwave": (shockwave, 2, 0.95),
    "wind_loop": (wind_loop, 1, 0.8),
    "cape_snap": (cape_snap, 2, 0.6),
    "braam": (braam, 3, 1.0),
    "transform": (transform, 2, 1.0),   # varian 1 = Black Adam (dipilih lewat event terpisah)
}


# ================================================================== SFX khas tiap skill (0.24.2)
# Ancang-ancang (windup) dibuat dengan panjang PERSIS sama dengan tick ancang-ancang di ShazamAnim
# (1 tick = 0.05 dtk), jadi puncaknya jatuh tepat di tick hantaman seperti VFX 0.24.

def cut_at(y, sec, tail=0.025, rise=1.8):
    """Potong tepat di detik sec (= tick hantaman), dengan crescendo yang memuncak di titik itu dan ekor
    pendek yang meluruh cepat supaya nggak 'klik'."""
    n = int(sec * SR)
    y = pad(y, sec + tail).copy()
    y[:n] *= (0.08 + 0.92 * np.linspace(0, 1, n) ** rise)
    y[n:] *= np.exp(-np.arange(len(y) - n) / (tail / 5 * SR))
    return y


def reverse_of(x, dur):
    """Gema yang dibalik: membesar lalu berakhir di titik serangnya (efek 'reverse' film)."""
    r = x[::-1]
    n = int(dur * SR)
    return r[-n:] if len(r) >= n else np.concatenate([np.zeros(n - len(r)), r])


def comb_sweep(x, f0, f1, fb=0.85):
    """Comb filter yang nadanya menyapu: bunyi logam 'shiiing' seperti bilah ditarik."""
    n = len(x)
    f = np.geomspace(f0, f1, n)
    y = np.zeros(n)
    for i in range(n):
        j = i - SR / f[i]
        if j >= 1:
            k = int(j)
            fr = j - k
            d = y[k] * (1 - fr) + y[k + 1] * fr
        else:
            d = 0.0
        y[i] = x[i] + fb * d
    return y


def transient(n_sec, lo, tau, amp, rng):
    n = int(n_sec * SR)
    return hp(white(n, rng), lo) * env_exp(n, tau) * amp


def war_horn(dur, root, rng):
    tt = t_axis(dur)
    bend = 1 - 0.06 * np.exp(-tt / 0.08)                       # nada menyendok naik di awal
    vib = 1 + 0.006 * np.sin(2 * np.pi * 5.5 * tt) * np.minimum(1, tt / 0.5)
    y = 0
    for r, a in ((1, 1), (1.5, 0.6), (2, 0.55), (3, 0.2)):
        y = y + a * supersaw(root * r * bend * vib, dur, 5, 0.006, rng)
    y = sweep_filter(y, np.concatenate([np.geomspace(300, 3500, 8), np.full(40, 3000), np.geomspace(3000, 800, 16)]), "low", 1.4)
    y = formant(y, "o") * 0.7 + y * 0.5
    return sat(y * env_adsr(dur, 0.04, 0.3, 0.8, dur * 0.5), 2.2)


def screech(dur, rng, f0=3000):
    """Pekik elang: nada tinggi yang naik sedikit lalu turun, kasar."""
    n = int(dur * SR)
    t = np.linspace(0, 1, n)
    jit = 1 + 0.01 * lp(rng.standard_normal(n), 60) * 20
    f = f0 * (1.0 + 0.12 * np.sin(np.pi * t)) * (1 - 0.25 * t) * jit
    car = np.sin(2 * np.pi * np.cumsum(f) / SR + osc(f * 0.5, dur) * 1.8)
    rough = bp(white(n, rng), f0 * 0.6, f0 * 1.6) * 0.35
    y = (car * 0.7 + rough) * env_adsr(dur, 0.02, 0.1, 0.7, dur * 0.6)
    return hp(sat(y, 2.0), 900)


def rattle(dur, rng, rate=24.0):
    """Getar ekor ular."""
    n = int(dur * SR)
    gate = lp((np.sin(2 * np.pi * np.cumsum(np.full(n, rate)) / SR) > 0.2).astype(float), 400)
    return bp(white(n, rng), 2500, 9000) * gate


def roar(dur, f0, rng):
    """Raungan buatan: sumber kasar + formant yang bergeser 'aaa' -> 'ooo'."""
    n = int(dur * SR)
    t = np.linspace(0, 1, n)
    jit = 1 + 0.04 * lp(rng.standard_normal(n), 30) * 25
    f = f0 * (1 + 0.25 * np.sin(np.pi * np.minimum(t * 1.4, 1))) * jit
    src = osc(f, dur, "saw") + 0.3 * osc(f * 0.5, dur, "square")
    src = src * (1 + 0.5 * lp(rng.standard_normal(n), 80) * 15)
    x = src + bp(white(n, rng), 300, 4000) * 0.5
    w = np.clip(t * 1.5, 0, 1)
    y = formant(x, "a") * (1 - w) + formant(x, "o") * w + lp(src, 400) * 0.4
    return sat(y * env_adsr(dur, 0.08, 0.3, 0.8, dur * 0.5) * 2.0, 3.0)


def thunder_crack(rng, amp=1.0):
    return mix(transient(0.03, 1500, 0.005, 3.0 * amp, rng),
               crackle(0.7, 2400, rng, 1500, 14000, 0.002, np.linspace(1, 0, 30) ** 2) * 1.4 * amp)


# ---------------------------------------------------------------- Shazam
def solomon_cast(rng, v):            # 5 tick
    d = 0.25
    n = int(d * SR)
    rs = reverse_of(reverb(bell(1318.5, 1.5, rng, tau=0.5), 2.0, 0.3, rng=rng), 0.6)[-n:]
    wh = formant(white(n, rng), "e") * np.linspace(0, 1, n) ** 2 * 0.5      # bisikan ditarik masuk
    tone = osc(np.geomspace(660, 1320, n), d) * np.linspace(0, 1, n) ** 3 * 0.25
    return cut_at(mix(rs, wh, tone), d)


def solomon_sight(rng, v):
    dur = 3.5
    n = int(0.6 * SR)
    shing = sweep_filter(white(n, rng) * env_exp(n, 0.12), np.geomspace(2500, 7000, 32), "band", 12)
    root = [349.2, 392.0][v % 2]
    ch = choir([root, root * 1.25, root * 1.5, root * 2], dur, rng, "a") * env_adsr(dur, 0.03, 0.5, 0.45, 2.5)
    bells_ = mix(*[at(bell(root * m, dur - 0.03 * i, rng, tau=1.0), 0.03 * i, dur) * 0.3 for i, m in enumerate([2, 3, 4, 5, 6])])
    y = mix(shing * 0.8, ch * 0.6, bells_, sub_drop(90, 45, 0.8, 0.15, 6) * 0.9)
    return reverb(y, 3.2, 0.45, rng=rng, size=2.0, bright=9000)


def hercules_windup(rng, v):         # 5 tick
    d = 0.25
    rs = reverse_of(lightning_strike(rng, 0), d) * 0.8
    cr = crackle(d, 1500, rng, 2000, 12000, 0.0015, np.linspace(0.1, 1, 20) ** 2) * 0.6
    return cut_at(mix(rs, cr, reverse_swell(d, rng, 500, 9000) * 0.6), d)


def hercules_clap(rng, v):
    """Tepukan guntur di tick 5, gada avatar Hercules menghantam tanah 2 tick kemudian (sudah di dalam file)."""
    dur = 4.0

    def palm():
        L = int(0.06 * SR)
        return bp(white(L, rng), 900, 5000) * env_exp(L, 0.009)
    clap = mix(palm() * 2.2, at(palm() * 1.6, 0.006), at(palm(), 0.014))
    boom = sub_drop(130 - v * 8, 34, 2.2, 0.5, 7) * 1.5
    mace = mix(sub_drop(110, 32, 1.6, 0.35, 9) * 1.4, lp(white(int(0.4 * SR), rng), 300) * env_exp(int(0.4 * SR), 0.06) * 1.6,
               crackle(1.0, 120, rng, 300, 3000, 0.006, np.linspace(1, 0, 30) ** 2) * 0.6)
    roll = lp(brown(int(dur * SR), rng), 220) * env_adsr(dur, 0.08, 0.6, 0.4, dur * 0.8) * 0.9
    y = mix(clap, thunder_crack(rng, 0.9), boom, at(mace, 0.10), at(roll, 0.05))
    return reverb(sat(y, 2.0), 3.0, 0.32, rng=rng, size=2.0)


def hercules_throw(rng, v):
    dur = 1.4
    n = int(dur * SR)
    pre_n = int(0.05 * SR)
    pre = sweep_filter(white(pre_n, rng), np.geomspace(500, 3500, 8), "band", 2.0) * np.linspace(0, 1, pre_n) ** 2 * 0.8
    away = sweep_filter(pink(n, rng), np.geomspace(3000, 250, 48), "band", 1.3) * env_exp(n, 0.35)
    tumble = 0.65 + 0.35 * np.sin(2 * np.pi * np.cumsum(np.linspace(14, 6, n)) / SR)   # badan musuh berputar
    y = mix(pre, at(mix(transient(0.012, 3000, 0.002, 0.9, rng), away * tumble * 2.0, sub_drop(95, 40, 0.9, 0.18, 6) * 1.3), 0.05))
    return reverb(y, 1.5, 0.25, rng=rng)


def atlas_windup(rng, v):            # 13 tick: langit turun ke kepalan
    d = 0.65
    n = int(d * SR)
    t = np.linspace(0, 1, n)
    wf = 1400 * 2 ** (-1.6 * t) * (1 + 0.006 * np.sin(2 * np.pi * 7 * t * d))
    whistle = osc(wf, d) * t ** 1.5 * 0.35 + bp(white(n, rng), 600, 3000) * t ** 2 * 0.15
    rum = sweep_filter(brown(n, rng), np.geomspace(120, 1200, 32), "low", 0.9) * t ** 2 * 1.4
    sub = osc(np.geomspace(30, 48, n), d) * t ** 2 * 0.7
    return cut_at(sat(mix(whistle, rum, sub, reverse_swell(d, rng, 300, 10000) * 0.5), 1.5), d)


def atlas_slam(rng, v):
    y = mix(sub_drop(170, 28, 2.5, 0.8, 8) * 1.2, impact(rng, v) * 0.9, braam(rng, v) * 0.75,
            at(shockwave(rng, v) * 0.7, 0.02), at(earth_crack(rng, v) * 0.6, 0.05), impact_ring(rng, v) * 0.35)
    return limiter(sat(y, 1.3), 0.95)


def zeus_windup(rng, v):             # 5 tick
    d = 0.25
    n = int(d * SR)
    t = np.linspace(0, 1, n)
    whine = sweep_filter(supersaw(np.geomspace(300, 2400, n), d, 5, 0.02, rng), np.geomspace(800, 9000, 16), "low", 2) * t ** 2 * 0.6
    cr = crackle(d, 3000, rng, 2500, 14000, 0.0012, np.linspace(0.05, 1, 20) ** 2) * 0.8
    return cut_at(mix(whine, cr, reverse_swell(d, rng, 1000, 12000) * 0.5), d)


def zeus_spear(rng, v):
    """Tombak petir dilempar Zeus: lecutan, zap yang menukik, dentuman. Gunturnya dari strikeLightning."""
    whip = mix(transient(0.008, 4000, 0.0012, 3.0, rng), at(transient(0.01, 2000, 0.002, 1.5, rng), 0.004))
    n = int(0.9 * SR)
    zapf = np.geomspace(3200 - v * 300, 180, n)
    zap = np.sin(2 * np.pi * np.cumsum(zapf) / SR + osc(np.geomspace(1800, 120, n), 0.9) * 4 * env_exp(n, 0.25)) * env_exp(n, 0.16) * 0.7
    cr = crackle(1.2, 2600, rng, 1800, 14000, 0.0015, np.concatenate([np.ones(5), np.linspace(1, 0, 40) ** 2])) * 1.2
    y = mix(whip, zap, cr, sub_drop(150, 32, 2.6, 0.6, 7) * 1.6)
    return limiter(reverb(sat(y, 1.8), 2.6, 0.25, rng=rng, size=2.0), 0.95)


def achilles_windup(rng, v):         # 4 tick: tombak ditarik
    d = 0.2
    n = int(d * SR)
    t = np.linspace(0, 1, n)
    shing = hp(comb_sweep(hp(white(n, rng), 1500) * (0.2 + t ** 1.5) * 0.3, 900, 3200, 0.9), 800) * t
    return cut_at(mix(shing * 0.6, reverse_swell(d, rng, 800, 11000) * 0.5), d)


def achilles_warcry(rng, v):
    """Raungan Achilles: tiupan terompet perang + hentakan kaki, tusukan tombak 1 tick kemudian."""
    horn = war_horn(3.0, [110.0, 98.0][v % 2], rng) * 0.8
    stomp = mix(sub_drop(120, 40, 0.9, 0.16, 9) * 1.5, lp(white(int(0.15 * SR), rng), 400) * env_exp(int(0.15 * SR), 0.03) * 1.2)
    n = int(0.5 * SR)
    thrust = sweep_filter(white(n, rng), np.geomspace(6000, 900, 24), "band", 2.5) * env_exp(n, 0.1) * 1.2
    spear = mix(thrust, sub_drop(90, 50, 0.8, 0.14, 5) * 0.9, bell(1318.5, 2.0, rng, tau=0.6) * 0.25)
    y = mix(stomp, horn, at(spear, 0.05), at(shimmer(rng, 2) * 0.35, 0.1))
    return reverb(y, 3.0, 0.35, rng=rng, size=2.0)


def courage_nova(rng, v):
    dur = 4.0
    root = [293.7, 329.6][v % 2]
    ch = choir([root, root * 1.25, root * 1.5, root * 2], dur, rng, "a") * env_adsr(dur, 0.01, 0.4, 0.4, 2.8)
    n = int(0.8 * SR)
    shing = sweep_filter(white(n, rng) * env_exp(n, 0.15), np.geomspace(3000, 9000, 24), "band", 10)
    m = int(1.2 * SR)
    air = sweep_filter(white(m, rng), np.geomspace(7000, 300, 32), "low", 0.9) * env_exp(m, 0.25) * 0.8
    y = mix(transient(0.015, 2000, 0.003, 2.5, rng), sub_drop(140, 36, 2.0, 0.5, 7) * 1.5, air, shing * 0.9, ch * 0.7,
            at(shimmer(rng, 0) * 0.4, 0.05))
    return reverb(sat(y, 1.6), 3.2, 0.35, rng=rng, size=2.0)


def storm_windup(rng, v):            # 9 tick
    d = 0.45
    n = int(d * SR)
    t = np.linspace(0, 1, n)
    wind = sweep_filter(pink(n, rng), np.geomspace(300, 3000, 24), "band", 1.2) * t ** 1.5
    ch = choir([146.8, 220.0, 293.7], 1.5, rng, "a") * env_adsr(1.5, 0.01, 0.3, 0.5, 1.0)
    inhale = reverse_of(reverb(ch, 1.5, 0.6, rng=rng), d) * 0.6                # paduan suara yang 'menarik napas'
    cr = crackle(d, 1800, rng, 2000, 13000, 0.0015, np.linspace(0, 1, 20) ** 3) * 0.7
    sub = osc(np.geomspace(35, 55, n), d) * t ** 2 * 0.6
    return cut_at(sat(mix(wind, inhale, cr, sub), 1.4), d)


def storm_gods(rng, v):
    """Pembuka Badai Para Dewa: braam mayor yang heroik, paduan suara, dan enam lonceng (enam dewa)."""
    dur = 5.0
    root = 73.4
    y = 0
    for f, a in ((root, 1), (root * 1.5, 0.7), (root * 2, 0.6), (root * 2.52, 0.35), (root * 3, 0.25)):
        y = y + a * supersaw(f, dur, 7, 0.01, rng)
    fc = np.concatenate([np.geomspace(250, 2600, 6), np.geomspace(2600, 400, 58)])
    br = sat(sweep_filter(y, fc, "low", 2.0) * env_adsr(dur, 0.015, 1.0, 0.6, 3.2) * 1.5, 2.8)
    ch = choir([293.7, 370.0, 440.0, 587.3, 740.0, 880.0], dur, rng, "a") * env_adsr(dur, 0.05, 0.8, 0.6, 3.0)
    bells_ = mix(*[at(bell(587.3 * m, 3.5, rng, tau=1.2), 0.1 + 0.06 * i) * 0.22 for i, m in enumerate([1, 1.25, 1.5, 2, 2.5, 3])])
    out = mix(thunder_crack(rng), sub_drop(160, 30, 2.6, 0.7, 7) * 1.6, br * 0.8, ch * 0.5, bells_)
    return limiter(reverb(out, 4.0, 0.35, rng=rng, size=2.4), 0.95)


def thunder_punch(rng, v):
    roll = lp(brown(int(3.0 * SR), rng), 200) * env_adsr(3.0, 0.1, 0.5, 0.4, 2.2) * 0.8
    y = mix(punch(rng, v, True), lightning_strike(rng, v) * 0.8, sub_drop(120, 30, 2.5, 0.6, 6) * 1.3, at(roll, 0.08))
    return limiter(sat(y, 1.4), 0.95)


def mercury_blink(rng, v):
    n = int(0.16 * SR)
    zip_ = sweep_filter(white(n, rng), np.geomspace(800, 9000, 16), "band", 2.5) * np.sin(np.linspace(0, np.pi, n)) ** 2
    m = int(0.2 * SR)
    tone = osc(np.geomspace(1800 + v * 200, 3600, m), 0.2) * env_exp(m, 0.05) * 0.25
    tail = mix(transient(0.006, 4000, 0.001, 0.7, rng), crackle(0.25, 2000, rng, 3000, 14000, 0.0008, np.linspace(1, 0, 10)) * 0.6, tone)
    return reverb(mix(zip_ * 0.9, at(tail, 0.12)), 1.2, 0.3, rng=rng, bright=9000)


# ---------------------------------------------------------------- Black Adam
def shu_vortex(rng, v):              # 50 tick pusaran
    dur = 2.7
    n = int(dur * SR)
    rot = 0.5 + 0.5 * np.sin(2 * np.pi * np.cumsum(np.linspace(2.5, 4.5, n)) / SR)
    howl = sweep_filter(pink(n, rng), 350 + 1500 * rot[:: max(1, n // 128)], "band", 3.0)
    grains = crackle(dur, 3500, rng, 2500, 11000, 0.0006) * (0.4 + 0.6 * rot) * 0.5
    y = (howl * 1.1 + lp(pink(n, rng), 300) * 0.6 + grains) * env_adsr(dur, 0.35, 0.3, 0.85, 0.6) * (0.7 + 0.3 * rot)
    return reverb(y, 1.8, 0.25, rng=rng)


def shu_burst(rng, v):
    m = int(2.0 * SR)
    blast = sweep_filter(white(m, rng), np.geomspace(9000, 400, 48), "low", 0.8) * env_exp(m, 0.35) * 1.2
    y = mix(transient(0.02, 1500, 0.004, 2.0, rng), sub_drop(110, 32, 2.0, 0.5, 6) * 1.5, blast, at(sand_burst(rng, v) * 0.9, 0.02))
    return reverb(sat(y, 1.8), 2.4, 0.3, rng=rng, size=1.8)


def heru_dive(rng, v):
    """Merunduk 3 tick (tarikan napas), lalu pekik elang + desing terjangan selama 5 tick."""
    jet_n = int(0.7 * SR)
    arc = np.sin(np.linspace(0, np.pi, jet_n))
    jet = sweep_filter(white(jet_n, rng), np.concatenate([np.geomspace(600, 6000, 10), np.geomspace(6000, 500, 30)]), "band", 1.6) * arc ** 1.5 * 1.1
    sub = osc(np.geomspace(90, 45, jet_n), 0.7) * arc ** 2 * 0.4
    dive = mix(screech(0.42, rng, [2900, 2600][v % 2]) * 0.6, jet, sub)
    return reverb(mix(reverse_swell(0.15, rng, 800, 10000) * 0.6, at(dive, 0.15)), 1.8, 0.3, rng=rng)


def heru_land(rng, v):
    imp = mix(sub_drop(140, 38, 1.4, 0.3, 9) * 1.5, lp(white(int(0.3 * SR), rng), 450) * env_exp(int(0.3 * SR), 0.05) * 1.6,
              transient(0.01, 2500, 0.002, 1.8, rng))
    y = mix(imp, at(sand_burst(rng, v) * 0.8, 0.01), at(whoosh(rng, 2, True) * 0.4, 0.05))
    return reverb(sat(y, 2.0), 1.8, 0.25, rng=rng)


def amon_windup(rng, v):             # 7 tick
    d = 0.35
    n = int(d * SR)
    t = np.linspace(0, 1, n)
    up = sweep_filter(pink(n, rng), np.geomspace(250, 2500, 16), "band", 1.4) * np.sin(np.linspace(0, np.pi * 0.9, n)) * 0.8
    rum = sweep_filter(brown(n, rng), np.geomspace(100, 600, 16), "low", 0.9) * t ** 2 * 1.3
    sub = osc(np.geomspace(32, 50, n), d) * t ** 2 * 0.7
    return cut_at(sat(mix(up, rum, sub, reverse_swell(d, rng, 300, 8000) * 0.4), 1.5), d)


def amon_quake(rng, v):
    dur = 4.5

    def fist():
        return mix(sub_drop(150, 34, 1.6, 0.35, 9) * 1.3, lp(white(int(0.25 * SR), rng), 420) * env_exp(int(0.25 * SR), 0.05) * 1.6,
                   transient(0.008, 2500, 0.0015, 1.6, rng))
    hit = mix(fist(), at(fist() * 0.85, 0.018))                       # dua kepalan
    tear = sweep_filter(brown(int(2.5 * SR), rng), np.geomspace(900, 90, 48), "band", 3.0) * env_adsr(2.5, 0.05, 0.4, 0.6, 1.8) * 1.6
    cr = 0
    for lo, hi in ((150, 700), (500, 2200), (1500, 6000)):
        cr = cr + crackle(1.4, 160, rng, lo, hi, 0.007, np.concatenate([np.linspace(0.3, 1, 8), np.linspace(1, 0, 30) ** 1.5]))
    rum = lp(brown(int(dur * SR), rng), 140) * env_adsr(dur, 0.03, 0.6, 0.5, 3.0)
    return reverb(sat(mix(hit, at(tear, 0.03), at(cr * 1.1, 0.02), rum), 2.0), 3.0, 0.3, rng=rng, size=2.0)


def zehuti_cast(rng, v):             # 5 tick
    d = 0.25
    wh = reverb(formant(white(int(1.0 * SR), rng), "u") * env_exp(int(1.0 * SR), 0.25), 1.5, 0.6, rng=rng)
    low = reverb(bell(98.0, 2.0, rng, ((1, 1), (2.4, 0.5), (3.9, 0.3)), tau=0.8), 1.5, 0.5, rng=rng)
    return cut_at(mix(reverse_of(wh, d), reverse_of(low, d) * 0.7), d, rise=2.6)


def zehuti_seal(rng, v):
    dur = 4.5
    gong = bell([98.0, 87.3][v % 2], dur, rng, ((1, 1), (1.47, 0.6), (2.09, 0.5), (2.56, 0.35), (3.28, 0.25), (4.1, 0.15)),
                tau=1.8, detune=0.004) * 0.8
    ch = choir([146.8, 174.6, 220.0], dur, rng, "u") * env_adsr(dur, 0.06, 0.6, 0.5, 3.0) * 0.6
    hiss = formant(white(int(1.5 * SR), rng), "o") * env_adsr(1.5, 0.2, 0.3, 0.3, 1.0) * 0.25
    y = mix(gong, ch, sub_drop(80, 38, 1.2, 0.3, 5), at(hiss, 0.3))
    return reverb(y, 3.8, 0.45, rng=rng, size=2.2)


def aton_windup(rng, v):             # 8 tick: cakram matahari terbentuk
    d = 0.4
    n = int(d * SR)
    t = np.linspace(0, 1, n)
    chord = mix(*[supersaw(f * np.geomspace(0.85, 1.0, n), d, 5, 0.012, rng) for f in (220.0, 277.2, 329.6, 440.0)])
    chord = sweep_filter(chord, np.geomspace(300, 7000, 16), "low", 1.6) * t ** 1.6 * 0.6
    siz = crackle(d, 3000, rng, 3000, 12000, 0.0008, np.linspace(0.1, 1, 20) ** 2) * 0.5
    roar_ = sweep_filter(pink(n, rng), np.geomspace(300, 2500, 16), "band", 1.0) * t ** 2 * 0.6
    return cut_at(sat(mix(chord, siz, roar_), 1.4), d)


def aton_ray(rng, v):
    dur = 1.6
    n = int(dur * SR)
    f = [880.0, 830.6, 932.3][v % 3]
    k = int(0.05 * SR)
    bf = f * np.concatenate([np.geomspace(1.25, 1.0, k), np.ones(n - k)])
    beam = np.sin(2 * np.pi * np.cumsum(bf) / SR + osc(bf * 1.5, dur) * 2.5 * env_exp(n, 0.2)) * env_exp(n, 0.22)
    beam = lp(beam + 0.5 * supersaw(f / 2, dur, 5, 0.01, rng) * env_exp(n, 0.18), 7000) * 0.6
    siz = crackle(dur, 2500, rng, 2500, 12000, 0.001, np.linspace(1, 0, 30) ** 1.5) * 0.6
    burn = sweep_filter(pink(n, rng), np.geomspace(2500, 400, 32), "band", 1.0) * env_adsr(dur, 0.01, 0.2, 0.4, 1.0) * 0.8
    y = mix(transient(0.01, 2500, 0.002, 1.6, rng), sub_drop(110, 45, 0.6, 0.1, 8) * 0.9, beam, siz, burn)
    return reverb(sat(y, 1.5), 1.6, 0.3, rng=rng)


def mehen_rise(rng, v):              # 6 tick: ular muncul dari bayangan
    d = 0.3
    n = int(d * SR)
    t = np.linspace(0, 1, n)
    sl = sweep_filter(pink(n, rng), np.geomspace(300, 1800, 16), "band", 1.5) * t * 0.6
    dr = sat(lp(supersaw(np.geomspace(41, 55, n), d, 5, 0.03, rng), 400), 3) * t ** 2 * 0.5
    return cut_at(mix(rattle(d, rng, 26) * t ** 1.2 * 0.7, sl, dr, reverse_swell(d, rng, 800, 9000) * 0.3), d)


def mehen_coil(rng, v):
    thump = mix(sub_drop(100, 38, 1.2, 0.25, 7) * 1.3, lp(white(int(0.2 * SR), rng), 350) * env_exp(int(0.2 * SR), 0.05))
    rt = rattle(1.4, rng, 30) * env_adsr(1.4, 0.02, 0.3, 0.5, 0.9) * 0.5
    sq = lp(supersaw(55 * (1 + 0.03 * np.sin(2 * np.pi * 1.7 * t_axis(2.0))), 2.0, 5, 0.02, rng), 700)
    sq = sat(sq * env_adsr(2.0, 0.15, 0.5, 0.6, 1.2), 2.5) * 0.5                 # lilitan yang meremas
    return reverb(mix(thump, at(rt, 0.05), sq, at(dark_hiss(rng, v) * 0.5, 0.1)), 2.5, 0.3, rng=rng)


def mehen_bite(rng, v):
    crunch = crackle(0.25, 900, rng, 600, 5000, 0.004, np.linspace(1, 0, 10) ** 2) * 1.1
    hs = formant(white(int(0.8 * SR), rng), "o") * env_adsr(0.8, 0.02, 0.2, 0.4, 0.5) * 0.4
    y = mix(transient(0.006, 3000, 0.001, 2.2, rng), at(transient(0.008, 1800, 0.0015, 1.6, rng), 0.012), at(crunch, 0.01),
            sub_drop(120, 50, 0.5, 0.08, 9) * 0.9, at(hs, 0.04))
    return reverb(sat(y, 2.0), 1.2, 0.25, rng=rng)


def kahndaq_windup(rng, v):          # 10 tick: amarah tertahan
    d = 0.5
    n = int(d * SR)
    t = np.linspace(0, 1, n)
    beats = mix(*[at(sub_drop(70, 38, 0.3, 0.06, 6) * a, s) for s, a in ((0.0, 0.7), (0.22, 0.85), (0.38, 1.0))])
    growl = sweep_filter(supersaw(np.geomspace(46, 62, n), d, 6, 0.03, rng), np.geomspace(200, 1500, 16), "low", 1.5)
    growl = sat(growl * t ** 1.5 * 1.5, 3.0) * 0.6
    return cut_at(mix(beats * 1.2, growl, reverse_swell(d, rng, 400, 9000) * 0.5), d)


def kahndaq_wrath(rng, v):
    r = reverb(roar(1.8, [82.0, 73.0][v % 2], rng) * 0.6, 2.5, 0.35, rng=rng)
    y = mix(thunder_crack(rng, 0.9), sub_drop(150, 28, 2.6, 0.8, 7) * 1.5, braam(rng, 1) * 0.8, at(r, 0.05),
            at(dread(rng, v)[int(1.0 * SR):] * 0.5, 0.2))
    return limiter(sat(y, 1.3), 0.95)


def call_windup(rng, v):             # 12 tick: langit bergemuruh
    d = 0.6
    n = int(d * SR)
    t = np.linspace(0, 1, n)
    rum = sweep_filter(brown(n, rng), np.geomspace(150, 1000, 16), "low", 0.9) * t ** 2 * 1.2
    tone = sweep_filter(supersaw(np.geomspace(55, 110, n), d, 6, 0.02, rng), np.geomspace(200, 4000, 16), "low", 1.5) * t ** 2 * 0.5
    cr = crackle(d, 1200, rng, 2000, 12000, 0.0015, np.linspace(0, 1, 20) ** 3) * 0.6
    return cut_at(sat(mix(reverse_of(thunder(rng, 2), d), rum, tone, cr), 1.4), d)


# ================================================================== 0.27.1: SFX baru dirombak total
# Pendekatan baru (bukan lagi desis noise + nada sintetis):
# - Guntur dari MODEL FISIKA: kanal petir berliku (jalan acak 3D, rata-rata belok 16 derajat per ruas) dan tiap ruasnya
#   memancarkan gelombang-N yang paling kuat tegak lurus ruasnya. Ruas dekat tiba duluan sebagai retakan tajam; ruas jauh
#   tiba belakangan, gelombangnya lebih panjang (lebih rendah) dan frekuensi tingginya terserap udara = gemuruh alami.
# - Listrik dari PERCIKAN sungguhan: kereta impuls rapat yang tak beraturan + resonansi logam elektroda ("bzzt"), bertebaran
#   pendek-pendek dengan "snap" keras sesekali, bukan desis noise rata.
# - Dentum dari sub yang anjlok + badan + ketukan, angin dari pink noise yang menyapu, peluru dari desing pita sempit.
# - Nada sintetis yang terdengar murah (sine menyapu, lonceng, paduan suara buatan) dibuang. Satu-satunya nada: tiupan
#   kuningan rendah yang samar di Kekuatan Keluarga.
C_SOUND = 343.0


def _rotate(d, axis, ang):
    return d * np.cos(ang) + np.cross(axis, d) * np.sin(ang) + axis * axis.dot(d) * (1 - np.cos(ang))


def lightning_channel(rng, length, start=(0.0, 0.0, 0.0), up=(0.0, 0.0, 1.0), seg=(1.5, 6.0), sigma_deg=16.0, bias=0.08):
    up = np.asarray(up, float)
    up = up / np.linalg.norm(up)
    d = up.copy()
    pts = [np.asarray(start, float)]
    total = 0.0
    while total < length:
        axis = rng.normal(size=3)
        axis -= axis.dot(d) * d
        axis /= np.linalg.norm(axis) + 1e-9
        d = _rotate(d, axis, np.radians(rng.normal(0, sigma_deg))) + up * bias
        d /= np.linalg.norm(d)
        step = rng.uniform(*seg)
        pts.append(pts[-1] + d * step)
        total += step
    return np.array(pts)


def thunder_model(rng, listener=(2.5, 0.0, 1.6), height=400.0, branches=14, tau0=0.0009):
    lis = np.asarray(listener, float)
    main = lightning_channel(rng, height, seg=(0.8, 3.5))
    segs = [(main[i], main[i + 1], 1.0) for i in range(len(main) - 1)]
    for _ in range(branches):   # cabang menjalar ke bawah/samping dari kanal utama, lebih lemah
        i = int(rng.integers(max(1, len(main) // 8), len(main) - 2))
        down = np.array([rng.normal(0, 0.6), rng.normal(0, 0.6), -1.0])
        br = lightning_channel(rng, rng.uniform(15, 120), start=main[i], up=down, bias=0.05)
        w = rng.uniform(0.25, 0.55)
        segs += [(br[k], br[k + 1], w) for k in range(len(br) - 1)]
    far = max(float(np.linalg.norm(b - lis)) for _, b, _ in segs)
    n = int((far / C_SOUND + 0.08) * SR)
    y = np.zeros(n)
    for a, b, w in segs:
        m = (a + b) * 0.5
        L = float(np.linalg.norm(b - a))
        vec = lis - m
        r = max(float(np.linalg.norm(vec)), 0.8)
        u = (b - a) / (L + 1e-9)
        sin_t = np.sqrt(max(0.0, 1.0 - float(u.dot(vec / r)) ** 2))
        amp = w * L * (0.15 + sin_t ** 1.5) / r * rng.uniform(0.7, 1.3)
        tau = tau0 * (1.0 + r / 40.0) ** 0.6 * rng.uniform(0.8, 1.25)
        k = max(2, int(2 * tau * SR))
        i0 = int(r / C_SOUND * SR)
        if i0 >= n:
            continue
        e = min(n, i0 + k)
        y[i0:e] += (np.linspace(1.0, -1.0, k) * amp)[: e - i0]
    # tekstur: tiap gelombang-N diberi butiran noise pendek (gemeretak), lalu gemuruh padat yang mengikuti kerapatan
    # pulsa (guntur sungguhan terdengar rapat karena kanalnya ribuan ruas + gema; model 'jarang' terdengar tipis)
    gn = int(0.007 * SR)
    grain = rng.standard_normal(gn) * np.exp(-np.arange(gn) / (0.0016 * SR))
    crack = signal.fftconvolve(y, grain)[:n] * 0.55
    dens = lp(np.abs(y), 18, 2)
    dens = np.maximum(dens, 0) / (np.max(dens) + 1e-9)
    rumble = lp(brown(n, rng), 1500, 2) * dens ** 0.6
    y = unit(y) + unit(crack) * 0.7 + unit(rumble) * 0.5
    y = y + bp(y, 700, 3200, 2) * 0.6     # 'gigitan' frekuensi tengah: retakannya jelas juga di speaker kecil
    tt = np.linspace(0, n / SR, 64)
    y = sweep_filter(y, np.maximum(15000.0 / (1.0 + (C_SOUND * tt) / 140.0), 300.0), "low", 0.7)   # serapan udara
    dly = int(2 * 1.6 / C_SOUND * SR)   # pantulan tanah
    y[dly:] += y[:-dly] * 0.5
    return y


def compress(x, thresh=0.3, ratio=4.0, attack=0.002, release=0.15):
    a_att, a_rel = np.exp(-1 / (attack * SR)), np.exp(-1 / (release * SR))
    ax = np.abs(x)
    env = np.empty_like(ax)
    e = 0.0
    for i in range(len(ax)):
        v = ax[i]
        e = a_att * e + (1 - a_att) * v if v > e else a_rel * e + (1 - a_rel) * v
        env[i] = e
    gain = np.ones_like(ax)
    over = env > thresh
    gain[over] = (thresh * (env[over] / thresh) ** (1.0 / ratio)) / env[over]
    return x * gain


def spark_train(dur, rng, rate):
    n = int(dur * SR)
    y = np.zeros(n)
    t = rng.exponential(1.0 / rate)
    while t < dur:
        y[min(int(t * SR), n - 1)] += rng.uniform(0.35, 1.0) * (1 if rng.random() < 0.5 else -1)
        t += rng.exponential(1.0 / rate)
    return y


def zap(dur, rng, bright=1.0):
    """Satu 'bzzt' percikan: kereta impuls rapat tak beraturan + resonansi logam elektroda."""
    x = spark_train(dur, rng, rng.uniform(1800, 5200))
    n = len(x)
    if n < 8 or not np.any(x):
        return np.zeros(n)
    f1 = rng.uniform(2200, 3000)
    # badan 350-1400 Hz = 'bzzt' yang padat (bukan desis 'tsss'), resonansi elektroda di atasnya
    y = (bp(x, 350, 1400, 2) * 0.9 + bp(x, f1 * 0.94, f1 * 1.06, 2) * 0.55 + bp(x, 4300, 5600, 2) * 0.3
         + bp(x, 7000, 9000, 2) * 0.12 * bright + bp(x, 1400, 9000, 2) * 0.22)
    return y * np.minimum(1, np.arange(n) / (0.0015 * SR)) * np.exp(-np.arange(n) / (dur * 0.6 * SR))


def electric_field(dur, rng, density, len_range=(0.006, 0.05), gain=1.0, bright=1.0):
    """Listrik merayap: zap pendek-pendek bertebaran (berapa per detik mengikuti kurva), plus snap keras sesekali."""
    n = int(dur * SR)
    y = np.zeros(n)
    curve = np.interp(np.arange(n), np.linspace(0, n - 1, len(density)), np.asarray(density, float))
    t = 0.0
    while t < dur:
        i = min(int(t * SR), n - 1)
        dens = curve[i]
        if dens <= 0.5:
            t += 0.01
            continue
        z = zap(rng.uniform(*len_range), rng, bright) * rng.uniform(0.4, 1.0)
        e = min(n, i + len(z))
        y[i:e] += z[: e - i]
        if rng.random() < 0.12:
            s = transient(0.004, 2500, 0.0008, rng.uniform(1.0, 1.8), rng)
            e2 = min(n, i + len(s))
            y[i:e2] += s[: e2 - i]
        t += rng.exponential(1.0 / dens)
    return y * gain


def thump(rng, f0=60.0, f1=33.0, dur=1.0, tau=0.28, body=0.7, knock=0.35):
    """Dentum: sub yang anjlok + 'dada' 80-200 Hz + badan pink noise 90-450 Hz + ketukan, lalu disaturasi supaya punya
    harmonik (tetap terasa di speaker HP/laptop yang nggak bisa membunyikan sub)."""
    n = int(dur * SR)
    att = np.minimum(1, np.arange(n) / (0.002 * SR))
    sub = osc(exp_sweep(f0, f1, dur, 6.0), dur) * env_exp(n, tau) * att
    chest = osc(exp_sweep(f0 * 2.1, f1 * 2.4, dur, 9.0), dur) * env_exp(n, tau * 0.45) * att * 0.55
    bn = int(0.15 * SR)
    b = bp(pink(bn, rng), 90, 450, 2) * env_exp(bn, 0.045) * body * 1.4
    kn = int(0.08 * SR)
    k = osc(160.0, 0.08) * env_exp(kn, 0.025) * knock
    return sat(mix(sub * 0.8, chest, b, k) * 1.6, 2.2)


def air_whoosh(dur, rng, f0=350.0, fpk=1600.0, f1=450.0, q=1.1, peak_at=0.55):
    """Angin tersibak: pink noise lewat pita yang menyapu naik lalu turun, dengan turbulensi."""
    n = int(dur * SR)
    k = max(2, min(62, int(64 * peak_at)))
    curve = np.concatenate([np.geomspace(f0, fpk, k), np.geomspace(fpk, f1, 64 - k)])
    y = sweep_filter(pink(n, rng), curve, "band", q)
    tt = np.linspace(0, 1, n)
    env = np.where(tt < peak_at, (tt / peak_at) ** 2, ((1 - tt) / max(1e-3, 1 - peak_at)) ** 1.6)
    turb = np.clip(1 + 0.35 * lp(rng.standard_normal(n), 18) * 12, 0.3, 1.8)
    return y * env * turb


def zip_by(dur, rng, f_hi=5200.0, f_lo=1700.0, toward=True):
    """Desing peluru/panah: pita sempit yang menyapu (mendekat naik & mengeras, menjauh turun & meredup)."""
    n = int(dur * SR)
    curve = np.geomspace(f_lo * 1.4, f_hi, 24) if toward else np.geomspace(f_hi, f_lo, 24)
    y = sweep_filter(white(n, rng), curve, "band", 6.0)
    tone = osc(np.geomspace(f_lo, f_hi * 0.7, n) if toward else np.geomspace(f_hi * 0.8, f_lo * 0.8, n), dur) * 0.12
    tt = np.linspace(0, 1, n)
    env = tt ** 2.5 if toward else np.exp(-tt * 5)
    return (y + tone) * env


def brass_hit(freqs, dur, rng):
    """Tiupan kuningan rendah (gaya trailer), nadanya 'menyendok' naik sedikit di awal."""
    n = int(dur * SR)
    tt = np.arange(n) / SR
    bend = 1 - 0.035 * np.exp(-tt / 0.05)
    y = 0
    for f in freqs:
        for _ in range(5):
            y = y + osc(f * (1 + rng.uniform(-0.004, 0.004)) * bend, dur, "saw", rng.uniform(0, 6.28))
    y = sweep_filter(y / (5 * len(freqs)), np.concatenate([np.geomspace(250, 1800, 10), np.geomspace(1800, 500, 40)]), "low", 1.1)
    y = y + bp(rng.standard_normal(n), 300, 2500) * 0.03 * env_exp(n, 0.2)
    return sat(y * np.minimum(1, tt / 0.025) * np.exp(-tt / (dur * 0.35)) * 2.5, 2.2)


def reverb2(x, rt_low=2.2, rt_high=0.9, mix_=0.22, pre=0.015, rng=None):
    """Ruang luas/terbuka: frekuensi rendah bergema lebih lama dari yang tinggi, pantulan awal jarang."""
    rng = rng or np.random.default_rng(11)
    n = int(max(rt_low, rt_high) * 1.2 * SR)
    tt = np.arange(n) / SR
    noise = rng.standard_normal(n)
    ir = lp(noise, 700) * np.exp(-6.9 * tt / rt_low) + hp(noise, 700) * np.exp(-6.9 * tt / rt_high)
    er = np.zeros(int(0.09 * SR))
    for k in range(9):
        er[int(rng.uniform(0.004, 0.085) * SR)] += rng.uniform(-0.5, 0.5) * (1 - k / 12)
    ir = mix(er, at(ir * 0.5, pre))
    ir /= np.sqrt(np.sum(ir ** 2)) + 1e-9
    wet = signal.fftconvolve(x, ir)[: len(x) + len(ir)]
    dry = np.concatenate([x, np.zeros(len(wet) - len(x))])
    return dry * (1 - mix_) + wet * mix_ * 1.4


def unit(x):
    return x / (np.max(np.abs(x)) + 1e-9)


def master_eq(y, sub=0.4, mids=0.5, top=0.45):
    """EQ akhir: sub (<70 Hz) dikurangi, frekuensi tengah 500-2500 Hz dinaikkan, desis >7 kHz diredam. Hasilnya padat
    dan jelas di speaker HP/laptop, nggak cuma 'dum' dan 'tsss'."""
    y = y - lp(y, 70, 2) * sub
    y = y + bp(y, 500, 2500, 2) * mids
    return y * (1 - top) + lp(y, 7000, 2) * top


# ---------------------------------------------------------------- 0.25: Penangkal Petir Hidup (dirombak 0.27.1)
ROD_HIT = 3 * 0.05   # ShazamAnim.ROD_DESCENT: retakan tepat di 0,15 detik


def rod_strike(rng, v):
    """Petir menyambar Shazam tiap 2 detik: gemuruh dibalik + percikan pemandu yang makin rapat (0,15 dtk), RETAKAN guntur
    dari model fisika tepat di tick hantaman, dentum di dada, listrik merayap di badan, lalu tenaga terhisap masuk."""
    hit = ROD_HIT
    th = thunder_model(rng, listener=(rng.uniform(1.8, 3.0), rng.uniform(-1, 1), 1.6), height=rng.uniform(320, 420))
    th = compress(unit(th), 0.18, 5.0, 0.0008, 0.09)
    n0 = int(hit * SR)
    tail = th[int(0.12 * SR):int(0.9 * SR)]
    pre = tail[::-1][-n0:] * np.linspace(0.05, 1, n0) ** 1.6 * 0.7          # gemuruh dibalik: menyedot masuk
    pre = pre + electric_field(hit, rng, np.linspace(40, 700, 16), (0.003, 0.02), 0.4)   # percikan pemandu
    boom = thump(rng, 58, 32, 1.0, 0.16, 0.8, 0.45) * 0.3
    crawl = electric_field(1.1, rng, np.concatenate([np.full(3, 260), np.linspace(260, 6, 24)]), gain=0.35)
    surge = air_whoosh(0.7, rng, 220, 1300, 900, 1.0, 0.8) * 0.18                       # tenaga terhisap ke badan
    y = mix(pre, at(mix(th, boom, at(crawl, 0.04), at(surge, 0.05)), hit))
    y = reverb2(sat(master_eq(y, 0.6), 1.3), 1.1, 0.5, 0.18, rng=rng)
    y = pad(master_eq(y, 0.45, 0.0, 0.0), 1.95)     # gema rendah dirapikan lagi supaya nggak 'mendem' tiap 2 detik
    y[-int(0.45 * SR):] *= np.linspace(1, 0, int(0.45 * SR)) ** 2
    return limiter(y, 0.95)


# ---------------------------------------------------------------- 0.26: Kekuatan Keluarga (dirombak 0.27.1)
FAMILY_HIT = 10 * 0.05   # ShazamAnim.FAMILY_WINDUP


def family_windup(rng, v):           # 10 tick: badai terhisap ke kepalan, memuncak tepat di tick sambaran
    d = FAMILY_HIT
    n = int(d * SR)
    th = compress(unit(thunder_model(rng, listener=(6.0, 0.0, 1.6), height=500.0, branches=8)), 0.2, 4.0, 0.001, 0.1)
    body = th[int(0.05 * SR):int(1.25 * SR)]
    rev = body[::-1][-n:] * np.linspace(0.05, 1, n) ** 1.5                         # guntur dibalik, terhisap masuk
    suck = air_whoosh(d, rng, 250, 1800, 1800, 1.0, 0.97) * 0.6                    # angin tertarik ke kepalan
    sizz = electric_field(d, rng, np.linspace(20, 900, 16), (0.004, 0.03), 0.45)   # listrik makin rapat
    sub = sat(osc(np.geomspace(40, 90, n), d) * 1.8, 2.0) * np.linspace(0, 1, n) ** 2 * 0.22   # tekanan naik
    return cut_at(master_eq(mix(rev * 0.9, suck, sizz, sub), 0.3, 0.5, 0.5), d, rise=1.4)


def family_strike(rng, v):           # petir menyambar kepalan Shazam + 4 anggota keluarga hampir bersamaan
    parts = []
    for dist, off, g in ((2.2, 0.0, 1.0), (4.5, 0.012, 0.75), (6.5, 0.021, 0.7), (8.5, 0.033, 0.6), (11.0, 0.041, 0.5)):
        th = thunder_model(rng, listener=(dist, rng.uniform(-2, 2), 1.6), height=rng.uniform(380, 520))
        parts.append(at(unit(th) * g, off))
    th = compress(unit(mix(*parts)), 0.2, 5.0, 0.0008, 0.12)
    boom = thump(rng, 52, 28, 2.0, 0.32, 0.9, 0.5) * 0.4
    brass = brass_hit([73.4, 110.0, 146.8, 185.0], 2.8, rng) * 0.22                # D mayor rendah, samar di bawah guntur
    sizz = electric_field(2.4, rng, np.concatenate([np.full(4, 300), np.linspace(300, 8, 28)]), gain=0.42)
    y = mix(th, boom, at(brass, 0.03), at(sizz, 0.06))
    y = pad(reverb2(master_eq(y, 0.3), 2.8, 1.0, 0.24, rng=rng), 3.8)
    y[-int(0.6 * SR):] *= np.linspace(1, 0, int(0.6 * SR)) ** 2
    return limiter(sat(y, 1.2), 0.95)


# ---------------------------------------------------------------- 0.27: Tangan Kahndaq (dirombak 0.27.1)
def adam_catch(rng, v):              # peluru mendekat, DIHENTIKAN paksa (dentum pendek + cekat listrik), lalu medan menahan
    stop = 0.085
    zipn = zip_by(stop, rng, rng.uniform(4600, 6000), rng.uniform(1600, 2200), True) * 0.8
    thunk = thump(rng, 72, 44, 0.35, 0.07, 0.8, 0.6) * 0.45
    clamp = electric_field(0.03, rng, [2500, 2500], (0.01, 0.025), 1.0)
    pn = int(0.08 * SR)
    press = lp(pink(pn, rng), 350) * env_exp(pn, 0.02) * 0.8
    hn = int(0.85 * SR)
    tt = np.arange(hn) / SR
    f0 = 98.0 + 6 * v                       # dengung medan listrik (terdengar juga di speaker kecil)
    drone = sum(np.sin(2 * np.pi * f0 * h * tt + rng.uniform(0, 6)) / h ** 1.2 for h in range(1, 9))
    drone = bp(drone * (0.8 + 0.2 * lp(rng.standard_normal(hn), 12) * 10), 80, 1800)
    drone = drone * (0.55 + 0.45 * np.sin(2 * np.pi * 7.0 * tt) ** 2) * env_adsr(0.85, 0.02, 0.15, 0.6, 0.55) * 0.35
    fizz = electric_field(0.75, rng, np.linspace(120, 10, 12), gain=0.4)
    y = mix(zipn, at(mix(thunk, clamp, press, drone, fizz), stop))
    y = reverb2(master_eq(y, 0.3, 0.7, 0.5), 1.0, 0.4, 0.15, rng=rng)
    return limiter(sat(pad(y, 1.25), 1.3), 0.95)


def adam_release(rng, v):            # tarik napas, KIBASAN tangan, petir membara, semua proyektil melesat menjauh
    inhale = air_whoosh(0.12, rng, 400, 1400, 1400, 1.0, 0.9) * 0.35
    flick = air_whoosh(0.32, rng, 300, 1300, 380, 1.0, 0.3) * 1.4
    snap = transient(0.006, 1500, 0.0012, 1.6, rng)
    th = compress(unit(thunder_model(rng, listener=(4.0, 0.0, 1.6), height=300.0, branches=5)), 0.2, 4.0, 0.001, 0.1) * 0.75
    zips = np.zeros(int(0.9 * SR))
    for k in range(6):
        z = zip_by(rng.uniform(0.16, 0.24), rng, rng.uniform(3600, 5000), rng.uniform(1100, 1700), False) * (0.45 - 0.05 * k)
        o = int((0.01 + 0.035 * k + rng.uniform(0, 0.015)) * SR)
        zips[o:o + len(z)] += z[: len(zips) - o]
    boom = thump(rng, 60, 34, 0.9, 0.16, 0.6, 0.3) * 0.3
    sizz = electric_field(0.8, rng, np.linspace(250, 10, 16), gain=0.4)
    y = mix(inhale, at(mix(flick, snap, th, boom, zips, sizz), 0.1))
    y = reverb2(master_eq(y, 0.3, 0.6, 0.45), 1.8, 0.7, 0.2, rng=rng)
    return limiter(sat(pad(y, 2.2), 1.3), 0.95)


# ---------------------------------------------------------------- 0.28 / 0.28.1: Black Adam, kekuatan matahari Aton
def fire_crackle(dur, rng, density, gain=1.0):
    """Gemeretak api: letupan pendek yang JARANG (udara panas & bara pecah), badannya 600-5000 Hz, sebagian keras.
    Beda dengan percikan listrik yang rapat dan tajam."""
    n = int(dur * SR)
    y = np.zeros(n)
    curve = np.interp(np.arange(n), np.linspace(0, n - 1, len(density)), np.asarray(density, float))
    t = 0.0
    while t < dur:
        i = min(int(t * SR), n - 1)
        dens = curve[i]
        if dens <= 0.5:
            t += 0.01
            continue
        ln = int(rng.uniform(0.0008, 0.004) * SR)
        f = rng.uniform(900, 4200)
        pop = bp(rng.standard_normal(ln + 64), f * 0.6, min(f * 1.6, 15000), 2)[:ln] * np.exp(-np.arange(ln) / (ln * 0.3))
        amp = rng.uniform(0.2, 1.0) * (2.2 if rng.random() < 0.08 else 1.0)
        e = min(n, i + ln)
        y[i:e] += pop[: e - i] * amp
        t += rng.exponential(1.0 / dens)
    return y * gain


def fire_roar(dur, rng, f_lo=70.0, f_hi=900.0, turb=14.0):
    """Deru api: noise rendah yang bergolak (amplitudonya naik-turun cepat seperti lidah api)."""
    n = int(dur * SR)
    x = bp(brown(n, rng) + pink(n, rng) * 0.35, f_lo, f_hi, 2)
    am = np.clip(1 + 0.7 * unit(lp(rng.standard_normal(n), turb)), 0.15, 2.0)
    return x * am


def fire_whoosh(dur, rng, peak_at=0.3, f_open=2600.0):
    """Semburan api (WHOOMPH): deru yang terbuka cepat (filter naik) lalu meredup pelan, dengan gemeretak di dalamnya."""
    n = int(dur * SR)
    roar = fire_roar(dur, rng, 60, 3500, 18)
    k = max(2, min(62, int(64 * peak_at)))
    curve = np.concatenate([np.geomspace(180, f_open, k), np.geomspace(f_open, 420, 64 - k)])
    y = sweep_filter(roar, curve, "low", 0.9)
    tt = np.linspace(0, 1, n)
    env = np.where(tt < peak_at, (tt / peak_at) ** 1.5, ((1 - tt) / max(1e-3, 1 - peak_at)) ** 1.3)
    return unit(y * env) + fire_crackle(dur, rng, [80, 300, 120, 20], 0.35) * env


def heat_hum(dur, rng):
    """Dengung panas: hawa yang bergetar di 150-600 Hz, berdenyut pelan (tanpa nada)."""
    n = int(dur * SR)
    x = bp(pink(n, rng), 150, 600, 2)
    tt = np.arange(n) / SR
    return unit(x) * (0.7 + 0.3 * np.sin(2 * np.pi * 3.2 * tt))


def aton_pulse(rng, v):              # Cakram Aton berdenyut tiap 2 detik (Black Adam): semburan cahaya-api tepat di 0,15 dtk
    """Panas terhisap ke cakram selama 0,15 detik (semburan api dibalik), lalu SEMBURAN cahaya & api matahari tepat di tick
    denyut, dentum hangat, deru yang meredup, bara gemeretak, dan dengung panas. Tanpa petir, tanpa nada."""
    hit = ROD_HIT
    n0 = int(hit * SR)
    inhale = fire_whoosh(0.6, rng, 0.5)[::-1][-n0:] * np.linspace(0.05, 1, n0) ** 1.4 * 0.75
    burst = fire_whoosh(1.1, rng, 0.05, 2800 + 300 * v)
    boom = thump(rng, 70, 40, 0.8, 0.14, 0.9, 0.3) * 0.35
    embers = fire_crackle(1.3, rng, np.concatenate([np.full(3, 420), np.linspace(420, 8, 24)]), 0.45)
    hum = heat_hum(1.2, rng) * env_adsr(1.2, 0.04, 0.2, 0.5, 0.8) * 0.18
    y = mix(inhale, at(mix(burst, boom, embers, at(hum, 0.05)), hit))
    y = reverb2(master_eq(sat(y, 1.3), 0.5, 0.5, 0.5), 1.3, 0.5, 0.16, rng=rng)
    y = pad(y, 1.9)
    y[-int(0.45 * SR):] *= np.linspace(1, 0, int(0.45 * SR)) ** 2
    return limiter(y, 0.95)


def aton_punch(rng, v):              # Tinju Aton: hantaman berat + ledakan api matahari yang membakar sekeliling
    impact = thump(rng, 82, 42, 0.6, 0.1, 1.0, 0.9) * 0.55
    cn = int(0.03 * SR)
    crunch = bp(white(cn, rng), 400, 3200, 2) * env_exp(cn, 0.007) * 1.1
    blast = fire_whoosh(1.5, rng, 0.04, 3200) * 1.15
    embers = fire_crackle(1.6, rng, np.concatenate([np.full(3, 650), np.linspace(650, 10, 24)]), 0.55)
    y = mix(impact, crunch, at(blast, 0.01), at(embers, 0.02))
    y = reverb2(master_eq(sat(y, 1.4), 0.4, 0.5, 0.45), 2.0, 0.8, 0.22, rng=rng)
    y = pad(y, 2.5)
    y[-int(0.5 * SR):] *= np.linspace(1, 0, int(0.5 * SR)) ** 2
    return limiter(y, 0.95)


def adam_block(rng, v):              # Tangkisan Kahndaq: ditahan kulit sekeras batu, lalu panas matahari menyembur balik
    hit = thump(rng, 88 - 6 * v, 50, 0.4, 0.08, 1.0, 0.8) * 0.7
    cn = int(0.035 * SR)
    crunch = bp(white(cn, rng), 300, 2400, 2) * env_exp(cn, 0.008) * 1.2
    flare = fire_whoosh(0.55, rng, 0.08, 2400) * 0.75
    sizzle = fire_crackle(0.45, rng, np.linspace(600, 20, 10), 0.5)
    y = mix(hit, crunch, at(flare, 0.02), at(sizzle, 0.03))
    y = reverb2(master_eq(y, 0.3, 0.6, 0.45), 1.0, 0.4, 0.14, rng=rng)
    return limiter(sat(pad(y, 1.1), 1.3), 0.95)


# ---------------------------------------------------------------- 0.29: pasif tiap 2 detik padam / menyala
def rod_fade(rng, v):                # petir Shazam padam: listrik tersendat-sendat lalu habis, deru mati, desis terakhir
    dens = [900, 700, 160, 620, 90, 380, 40, 170, 10, 60, 3, 0]
    sputter = electric_field(1.25, rng, dens, (0.004, 0.04), 0.7)
    pn = int(1.3 * SR)
    down = sweep_filter(pink(pn, rng), np.geomspace(2600, 120, 40), "band", 2.5) * env_adsr(1.3, 0.02, 0.2, 0.6, 0.9) * 0.6
    fn = int(0.6 * SR)
    fizz = hp(white(fn, rng), 3000) * env_exp(fn, 0.15) * 0.15
    y = mix(sputter, at(down, 0.02), at(fizz, 0.9))
    y = reverb2(master_eq(y, 0.3, 0.6, 0.5), 1.2, 0.5, 0.16, rng=rng)
    return limiter(sat(pad(y, 1.8), 1.2), 0.95)


def aton_set(rng, v):                # Cakram Aton terbenam: deru api meredup & menutup, bara makin jarang, hembusan terakhir
    rn = int(2.0 * SR)
    roar = sweep_filter(fire_roar(2.0, rng, 60, 2000, 10), np.geomspace(2200, 140, 40), "low", 0.8)
    roar = unit(roar) * env_adsr(2.0, 0.15, 0.3, 0.7, 1.4) * 0.8
    embers = fire_crackle(2.0, rng, np.linspace(220, 3, 24), 0.4)
    en = int(0.5 * SR)
    exhale = lp(pink(en, rng), 300, 2) * env_exp(en, 0.12) * 0.5
    y = mix(roar, embers, at(exhale, 1.3))
    y = reverb2(master_eq(y, 0.4, 0.5, 0.5), 2.0, 0.8, 0.2, rng=rng)
    y = pad(y, 2.4)
    y[-int(0.5 * SR):] *= np.linspace(1, 0, int(0.5 * SR)) ** 2
    return limiter(y, 0.95)


def aton_rise(rng, v):               # Cakram Aton terbit: hawa panas bangkit, bara makin rapat, mekar hangat tepat 1 detik
    swell = fire_whoosh(1.0, rng, 0.97, 2400) * 0.8
    embers = fire_crackle(1.6, rng, np.concatenate([np.linspace(10, 320, 16), np.linspace(320, 8, 16)]), 0.4)
    bloom = fire_whoosh(0.9, rng, 0.06, 2200) * 0.7
    bn = int(0.6 * SR)
    warm = lp(brown(bn, rng), 220, 2) * env_exp(bn, 0.18) * 0.5
    y = mix(swell, embers, at(mix(bloom, warm), 1.0))
    y = reverb2(master_eq(y, 0.4, 0.5, 0.5), 1.6, 0.6, 0.18, rng=rng)
    y = pad(y, 2.2)
    y[-int(0.4 * SR):] *= np.linspace(1, 0, int(0.4 * SR)) ** 2
    return limiter(y, 0.95)


WINDUPS = {"solomon_cast", "hercules_windup", "atlas_windup", "zeus_windup", "achilles_windup", "storm_windup",
           "amon_windup", "zehuti_cast", "aton_windup", "mehen_rise", "kahndaq_windup", "call_windup", "family_windup"}

RECIPES.update({
    "solomon_cast": (solomon_cast, 1, 0.75),
    "solomon_sight": (solomon_sight, 2, 0.85),
    "hercules_windup": (hercules_windup, 1, 0.75),
    "hercules_clap": (hercules_clap, 2, 1.0),
    "hercules_throw": (hercules_throw, 2, 0.9),
    "atlas_windup": (atlas_windup, 1, 0.85),
    "atlas_slam": (atlas_slam, 2, 1.0),
    "zeus_windup": (zeus_windup, 1, 0.75),
    "zeus_spear": (zeus_spear, 2, 1.0),
    "achilles_windup": (achilles_windup, 1, 0.7),
    "achilles_warcry": (achilles_warcry, 2, 1.0),
    "courage_nova": (courage_nova, 2, 0.95),
    "storm_windup": (storm_windup, 1, 0.8),
    "storm_gods": (storm_gods, 1, 1.0),
    "thunder_punch": (thunder_punch, 2, 1.0),
    "mercury_blink": (mercury_blink, 2, 0.8),
    "shu_vortex": (shu_vortex, 1, 0.85),
    "shu_burst": (shu_burst, 2, 1.0),
    "heru_dive": (heru_dive, 2, 0.9),
    "heru_land": (heru_land, 2, 0.95),
    "amon_windup": (amon_windup, 1, 0.8),
    "amon_quake": (amon_quake, 2, 1.0),
    "zehuti_cast": (zehuti_cast, 1, 0.75),
    "zehuti_seal": (zehuti_seal, 2, 0.9),
    "aton_windup": (aton_windup, 1, 0.8),
    "aton_ray": (aton_ray, 3, 0.9),
    "mehen_rise": (mehen_rise, 1, 0.8),
    "mehen_coil": (mehen_coil, 1, 0.9),
    "mehen_bite": (mehen_bite, 2, 0.9),
    "kahndaq_windup": (kahndaq_windup, 1, 0.85),
    "kahndaq_wrath": (kahndaq_wrath, 2, 1.0),
    "call_windup": (call_windup, 1, 0.85),
    # 0.25
    "rod_strike": (rod_strike, 3, 0.9),
    # 0.26
    "family_windup": (family_windup, 1, 0.8),
    "family_strike": (family_strike, 2, 1.0),
    # 0.27
    "adam_catch": (adam_catch, 3, 0.8),
    "adam_release": (adam_release, 2, 1.0),
    # 0.28 / 0.28.1
    "adam_block": (adam_block, 2, 0.9),
    "aton_pulse": (aton_pulse, 3, 0.9),
    "aton_punch": (aton_punch, 2, 1.0),
    # 0.29
    "rod_fade": (rod_fade, 2, 0.85),
    "aton_set": (aton_set, 2, 0.85),
    "aton_rise": (aton_rise, 2, 0.85),
})

# ================================================================== 0.30 Sabbac (enam iblis) & Rival Juara
# Api neraka (deru api, gemeretak bara), geraman iblis yang sangat rendah, rantai besi, batu obsidian, dan lalat.
# Ancang-ancang (windup) tetap sepanjang tick ancang-ancangnya di ShazamAnim.

def growl(dur, f0, rng, v_from="o", v_to="u"):
    """Geraman iblis: nada sangat rendah yang kasar (sub-harmonik), pita suara bergemeretak, formant gelap."""
    n = int(dur * SR)
    t = np.linspace(0, 1, n)
    jit = 1 + 0.05 * lp(rng.standard_normal(n), 25) * 25
    f = f0 * (1 + 0.15 * np.sin(np.pi * t)) * jit
    src = osc(f, dur, "saw") + 0.6 * osc(f * 0.5, dur, "square") + 0.3 * osc(f * 0.25, dur, "saw")
    src = src * np.clip(1 + 0.6 * lp(rng.standard_normal(n), 60) * 12, 0.1, 2.5)
    w = np.clip(t * 1.2, 0, 1)
    y = formant(src, v_from) * (1 - w) + formant(src, v_to) * w + lp(src, 260) * 0.6
    return sat(y * env_adsr(dur, 0.06, 0.3, 0.8, dur * 0.5) * 2.2, 3.2)


def demon_choir(dur, root, rng, vowel="u"):
    """Paduan suara iblis: akor rendah yang sumbang (tritonus), bergetar lambat."""
    y = choir([root, root * 1.414, root * 2.0, root * 2.83], dur, rng, vowel, vib=3.1)
    return unit(lp(y, 2200)) * env_adsr(dur, 0.4, 0.5, 0.8, dur * 0.45)


def chain_rattle(dur, rng, rate=28.0, bright=1.0):
    """Mata rantai besi beradu: ketukan logam rapat yang acak, tiap ketukan berdenting pendek."""
    n = int(dur * SR)
    y = np.zeros(n)
    t = 0.0
    while t < dur:
        i = int(t * SR)
        f = rng.uniform(1800, 4200) * bright
        a = osc(f, rng.uniform(0.02, 0.06))
        ln = len(a)
        tick = (a * 0.6 + osc(f * 1.47, ln / SR + 1e-6)[:ln] * 0.4 + bp(white(ln, rng), 2500, 9000) * 0.8) * env_exp(ln, 0.008)
        e = min(n, i + ln)
        y[i:e] += tick[: e - i] * rng.uniform(0.3, 1.0)
        t += rng.exponential(1.0 / rate)
    return y


def metal_clank(rng, f0=420.0, amp=1.0):
    """Hantaman besi berat: dentang inharmonis + ketukan."""
    d = 1.2
    y = bell(f0, d, rng, ((1, 1), (1.83, 0.6), (2.71, 0.45), (4.13, 0.3), (5.9, 0.15)), tau=0.35, detune=0.01)
    return mix(y, transient(0.02, 1200, 0.004, 1.5, rng)) * amp


def stone_grind(dur, rng, lo=120, hi=1400):
    """Batu bergesek/membatu: noise kasar berbutir yang bergetar."""
    n = int(dur * SR)
    x = bp(white(n, rng) * np.clip(1 + lp(rng.standard_normal(n), 40) * 30, 0, 3), lo, hi, 2)
    return x + crackle(dur, 120, rng, 600, 3000, 0.004) * 0.6


def fly_buzz(dur, rng, f0=210.0):
    """Dengung kawanan lalat: banyak sayap bergetar di 180-320 Hz, naik-turun."""
    n = int(dur * SR)
    y = 0
    for _ in range(9):
        f = f0 * rng.uniform(0.85, 1.4) * (1 + 0.03 * lp(rng.standard_normal(n), 3) * 40)
        y = y + osc(f, dur, "saw") * (0.5 + 0.5 * np.abs(lp(rng.standard_normal(n), 2) * 30))
    return bp(y, 150, 3000, 2) * 0.15


def whisper(dur, rng, vowel="e"):
    """Bisikan: noise berbentuk vokal, tanpa nada."""
    n = int(dur * SR)
    x = hp(white(n, rng), 900)
    y = formant(x, vowel) * 0.8 + bp(x, 3000, 8000) * 0.25
    tt = np.linspace(0, 1, n)
    return y * np.sin(np.pi * tt) ** 0.7 * (0.6 + 0.4 * np.sin(2 * np.pi * rng.uniform(3, 6) * tt * dur))


def transform_sabbac(rng, v):        # SABBAC!: petir neraka menembus badan - semburan api, geraman, paduan suara iblis
    dur = 6.5
    crack = thunder_crack(rng, 0.9)
    blast = fire_whoosh(2.2, rng, 0.03, 3400) * 1.4
    kick = sub_drop(150, 26, 2.6, 0.8, 7) * 1.7
    howl = growl(2.4, 44.0, rng, "a", "o") * 0.55
    choir_ = demon_choir(4.5, 55.0, rng, "u") * 0.35
    embers = fire_crackle(4.0, rng, np.concatenate([np.full(4, 600), np.linspace(600, 6, 36)]), 0.55)
    y = mix(crack, blast, kick, at(howl, 0.05), at(choir_, 0.4), at(embers, 0.1))
    y = reverb2(master_eq(sat(y, 1.35), 0.35, 0.5, 0.4), 3.0, 1.0, 0.24, rng=rng)
    y = pad(y, dur)
    y[-int(0.8 * SR):] *= np.linspace(1, 0, int(0.8 * SR)) ** 2
    return limiter(y, 0.95)


def hellfire_pulse(rng, v):          # Api Neraka tiap 2 detik: tarikan dari bawah, SEMBURAN api tepat di 0,15 detik
    hit = ROD_HIT
    n0 = int(hit * SR)
    inhale = fire_whoosh(0.6, rng, 0.5)[::-1][-n0:] * np.linspace(0.05, 1, n0) ** 1.4 * 0.8
    burst = fire_whoosh(1.1, rng, 0.04, 2400 + 300 * v)
    boom = thump(rng, 58, 30, 0.9, 0.16, 0.9, 0.35) * 0.45
    hiss = sweep_filter(white(int(0.5 * SR), rng), np.geomspace(5000, 900, 24), "band", 1.6) * env_exp(int(0.5 * SR), 0.12) * 0.25
    embers = fire_crackle(1.3, rng, np.concatenate([np.full(3, 480), np.linspace(480, 8, 24)]), 0.5)
    y = mix(inhale, at(mix(burst, boom, hiss, embers), hit))
    y = reverb2(master_eq(sat(y, 1.35), 0.5, 0.5, 0.45), 1.4, 0.5, 0.16, rng=rng)
    y = pad(y, 1.9)
    y[-int(0.45 * SR):] *= np.linspace(1, 0, int(0.45 * SR)) ** 2
    return limiter(y, 0.95)


def hellfire_punch(rng, v):          # Tinju Neraka: hantaman berat + ledakan api neraka + rantai yang menyambar
    impact = thump(rng, 70, 34, 0.7, 0.12, 1.0, 0.9) * 0.6
    cn = int(0.03 * SR)
    crunch = bp(white(cn, rng), 350, 3000, 2) * env_exp(cn, 0.007) * 1.2
    blast = fire_whoosh(1.6, rng, 0.04, 2800) * 1.2
    chains = chain_rattle(0.6, rng, 40) * env_exp(int(0.6 * SR), 0.18) * 0.35
    embers = fire_crackle(1.7, rng, np.concatenate([np.full(3, 650), np.linspace(650, 10, 24)]), 0.55)
    y = mix(impact, crunch, at(blast, 0.01), at(chains, 0.06), at(embers, 0.02))
    y = reverb2(master_eq(sat(y, 1.4), 0.4, 0.5, 0.45), 2.0, 0.8, 0.22, rng=rng)
    y = pad(y, 2.5)
    y[-int(0.5 * SR):] *= np.linspace(1, 0, int(0.5 * SR)) ** 2
    return limiter(y, 0.95)


def sabbac_engulf(rng, v):           # Kulit Bara: serangan ditelan api - hantaman teredam, kobaran, desis
    hit = thump(rng, 80 - 6 * v, 44, 0.4, 0.08, 1.0, 0.6) * 0.6
    flare = fire_whoosh(0.6, rng, 0.07, 2200) * 0.85
    sizzle = fire_crackle(0.5, rng, np.linspace(650, 20, 10), 0.5)
    hn = int(0.35 * SR)
    hiss = hp(white(hn, rng), 3000) * env_exp(hn, 0.08) * 0.18
    y = mix(hit, at(flare, 0.01), at(sizzle, 0.03), at(hiss, 0.02))
    y = reverb2(master_eq(y, 0.3, 0.6, 0.45), 1.0, 0.4, 0.14, rng=rng)
    return limiter(sat(pad(y, 1.1), 1.3), 0.95)


def hellfire_out(rng, v):            # Api Neraka padam: kobaran tersendat & meredup, desis uap/asap, embusan terakhir
    roar_ = sweep_filter(fire_roar(1.6, rng, 60, 1800, 12), np.geomspace(1800, 120, 40), "low", 0.8)
    gate = np.clip(np.sin(np.linspace(0, 26, int(1.6 * SR))) * 2 + 0.6, 0, 1)   # tersendat-sendat
    roar_ = unit(roar_) * env_adsr(1.6, 0.05, 0.3, 0.6, 1.1) * gate * 0.75
    sn = int(1.2 * SR)
    steam = sweep_filter(white(sn, rng), np.geomspace(7000, 2500, 24), "band", 1.2) * env_adsr(1.2, 0.1, 0.3, 0.5, 0.8) * 0.3
    embers = fire_crackle(1.6, rng, np.linspace(260, 2, 24), 0.4)
    en = int(0.5 * SR)
    exhale = lp(pink(en, rng), 280, 2) * env_exp(en, 0.12) * 0.5
    y = mix(roar_, at(steam, 0.3), embers, at(exhale, 1.2))
    y = reverb2(master_eq(y, 0.4, 0.5, 0.5), 1.8, 0.7, 0.2, rng=rng)
    y = pad(y, 2.2)
    y[-int(0.5 * SR):] *= np.linspace(1, 0, int(0.5 * SR)) ** 2
    return limiter(y, 0.95)


def hellfire_in(rng, v):             # Api Neraka menyala lagi: percikan, kobaran bangkit, mekar tepat di 0,8 detik
    swell = fire_whoosh(0.8, rng, 0.97, 2200) * 0.8
    sparks = fire_crackle(1.4, rng, np.concatenate([np.linspace(20, 420, 16), np.linspace(420, 10, 16)]), 0.45)
    bloom = fire_whoosh(0.9, rng, 0.05, 2600) * 0.85
    boom = thump(rng, 62, 34, 0.6, 0.12, 0.8, 0.3) * 0.3
    y = mix(swell, sparks, at(mix(bloom, boom), 0.8))
    y = reverb2(master_eq(y, 0.4, 0.5, 0.5), 1.5, 0.6, 0.18, rng=rng)
    y = pad(y, 2.0)
    y[-int(0.4 * SR):] *= np.linspace(1, 0, int(0.4 * SR)) ** 2
    return limiter(y, 0.95)


def horns_windup(rng, v):            # 6 tick: kuku banteng neraka menggaruk tanah dua kali, dengus panas, gemuruh naik
    d = 0.3
    y = np.zeros(1)
    for k, t0 in enumerate((0.0, 0.12)):
        sn = int(0.09 * SR)
        scrape = bp(white(sn, rng) * np.clip(1 + lp(rng.standard_normal(sn), 60) * 20, 0, 3), 300, 2600, 2)
        y = mix(y, at(scrape * env_adsr(0.09, 0.01, 0.03, 0.6, 0.05) * (0.8 + 0.2 * k), t0))
    nn = int(0.16 * SR)
    snort = formant(pink(nn, rng), "o") * env_adsr(0.16, 0.02, 0.05, 0.7, 0.08) * 1.2
    rumble = lp(brown(int(d * SR), rng), 160, 2) * np.linspace(0.1, 1, int(d * SR)) ** 2 * 0.8
    y = mix(y, at(snort, 0.17), rumble)
    return cut_at(pad(y, d + 0.1), d, 0.025, 1.6)


def horns_charge(rng, v):            # serudukan: derap berat & api menderu selama 0,4 detik, lalu HANTAMAN lemparan
    d = 0.4
    gn = int(d * SR)
    gallop = np.zeros(1)
    for i in range(5):
        gallop = mix(gallop, at(thump(rng, 70, 40, 0.18, 0.05, 0.9, 0.5) * 0.35, i * 0.08))
    rush = fire_whoosh(0.5, rng, 0.85, 3000) * 0.9
    toss = thump(rng, 74, 34, 0.8, 0.14, 1.0, 1.0) * 0.7
    cn = int(0.04 * SR)
    crunch = bp(white(cn, rng), 300, 3000, 2) * env_exp(cn, 0.009) * 1.2
    blast = fire_whoosh(1.0, rng, 0.04, 2600) * 0.8
    y = mix(gallop, rush, at(mix(toss, crunch, blast), d))
    y = reverb2(master_eq(sat(y, 1.4), 0.4, 0.55, 0.45), 1.6, 0.6, 0.2, rng=rng)
    y = pad(y, 1.6)
    y[-int(0.4 * SR):] *= np.linspace(1, 0, int(0.4 * SR)) ** 2
    return limiter(y, 0.95)


def aym_shell(rng, v):               # Tubuh Aym: kulit berderak membatu (0,25 dtk), DENTUM batu, magma menggelegak
    d = 0.25
    grind = stone_grind(d, rng) * np.linspace(0.2, 1, int(d * SR)) ** 1.5 * 0.8
    thunk = thump(rng, 66, 40, 0.7, 0.12, 1.0, 0.8) * 0.55
    cn = int(0.05 * SR)
    stone = bp(white(cn, rng), 200, 2200, 2) * env_exp(cn, 0.012) * 1.3
    bn = int(0.9 * SR)
    bubble = np.zeros(1)
    for _ in range(9):   # magma menggelegak: letupan rendah
        b = osc(rng.uniform(120, 260), 0.06) * env_exp(int(0.06 * SR), 0.015)
        bubble = mix(bubble, at(b * rng.uniform(0.3, 0.8), rng.uniform(0, 0.8)))
    y = mix(grind, at(mix(thunk, stone), d), at(pad(bubble, 0.9) * 0.5, d + 0.05), at(heat_hum(0.9, rng) * 0.15, d))
    y = reverb2(master_eq(y, 0.4, 0.55, 0.45), 1.4, 0.5, 0.16, rng=rng)
    y = pad(y, 1.4)
    y[-int(0.35 * SR):] *= np.linspace(1, 0, int(0.35 * SR)) ** 2
    return limiter(sat(y, 1.2), 0.95)


def aym_burst(rng, v):               # Letusan Aym: cangkang obsidian PECAH, magma meledak, batu berjatuhan
    cn = int(0.06 * SR)
    shatter = mix(bp(white(cn, rng), 800, 7000, 2) * env_exp(cn, 0.015) * 1.6, crackle(0.5, 900, rng, 1200, 9000, 0.003) * 0.9)
    boom = thump(rng, 60, 28, 1.2, 0.22, 1.0, 1.0) * 0.8
    blast = fire_whoosh(1.8, rng, 0.03, 3000) * 1.3
    debris = crackle(1.4, 60, rng, 300, 2500, 0.01, np.linspace(1, 0, 20)) * 0.6
    y = mix(shatter, boom, at(blast, 0.01), at(debris, 0.1))
    y = reverb2(master_eq(sat(y, 1.4), 0.35, 0.5, 0.45), 2.4, 0.9, 0.24, rng=rng)
    y = pad(y, 2.6)
    y[-int(0.5 * SR):] *= np.linspace(1, 0, int(0.5 * SR)) ** 2
    return limiter(y, 0.95)


def belial_chains(rng, v):           # Rantai Belial: rantai besi menyeruak dari tanah, berdentang, lalu menegang
    burst = mix(metal_clank(rng, 380 + 40 * v, 0.8), at(metal_clank(rng, 520, 0.5), 0.07), at(metal_clank(rng, 300, 0.45), 0.15))
    rattle_ = chain_rattle(1.2, rng, 34) * env_adsr(1.2, 0.02, 0.3, 0.6, 0.7) * 0.6
    sn = int(0.6 * SR)
    shing = comb_sweep(white(sn, rng) * env_exp(sn, 0.2), 900, 2400) * 0.3
    rumble = lp(brown(int(0.8 * SR), rng), 200, 2) * env_exp(int(0.8 * SR), 0.25) * 0.5
    fire = fire_whoosh(0.8, rng, 0.08, 1800) * 0.35
    y = mix(burst, at(rattle_, 0.05), at(shing, 0.1), rumble, fire)
    y = reverb2(master_eq(y, 0.4, 0.55, 0.45), 1.8, 0.8, 0.22, rng=rng)
    y = pad(y, 2.0)
    y[-int(0.4 * SR):] *= np.linspace(1, 0, int(0.4 * SR)) ** 2
    return limiter(sat(y, 1.2), 0.95)


def beelzebub_breath(rng, v):        # Napas Beelzebub: tarikan napas 0,4 dtk, lalu semburan api 2 dtk dengan kawanan lalat
    d0 = 0.4
    n0 = int(d0 * SR)
    inhale = sweep_filter(pink(n0, rng), np.geomspace(500, 2400, 24), "band", 1.0) * np.linspace(0.1, 1, n0) ** 2 * 0.6
    fn = int(2.0 * SR)
    flame = fire_roar(2.0, rng, 80, 3200, 16)
    flame = sweep_filter(flame, np.concatenate([np.geomspace(900, 3600, 6), np.full(52, 3400), np.geomspace(3400, 900, 6)]), "low", 0.9)
    flame = unit(flame) * env_adsr(2.0, 0.04, 0.2, 0.85, 0.5) * 0.9
    growl_ = growl(2.0, 52.0, rng, "a", "a") * 0.25
    buzz = fly_buzz(2.4, rng) * env_adsr(2.4, 0.3, 0.3, 0.8, 0.8) * 0.8
    embers = fire_crackle(2.2, rng, np.full(30, 260), 0.45)
    y = mix(inhale, at(mix(flame, growl_, embers), d0), at(buzz, 0.2))
    y = reverb2(master_eq(sat(y, 1.3), 0.4, 0.55, 0.45), 1.6, 0.7, 0.2, rng=rng)
    y = pad(y, 3.0)
    y[-int(0.5 * SR):] *= np.linspace(1, 0, int(0.5 * SR)) ** 2
    return limiter(y, 0.95)


def asmodeus_roar(rng, v):           # Teror Asmodeus: raungan iblis yang sangat rendah, menggelegar, dengan gema panjang
    howl = growl(2.2, 48.0 + 6 * v, rng, "a", "o")
    top = roar(1.6, 170.0 + 20 * v, rng) * 0.35
    sub = sub_drop(90, 32, 2.0, 0.6, 5) * 0.8
    wn = int(1.4 * SR)
    wind = sweep_filter(pink(wn, rng), np.geomspace(300, 2200, 32), "band", 1.0) * env_adsr(1.4, 0.1, 0.3, 0.6, 0.8) * 0.3
    y = mix(howl, at(top, 0.04), sub, at(wind, 0.2))
    y = reverb2(master_eq(sat(y, 1.3), 0.35, 0.5, 0.4), 3.2, 1.1, 0.3, rng=rng)
    y = pad(y, 3.4)
    y[-int(0.7 * SR):] *= np.linspace(1, 0, int(0.7 * SR)) ** 2
    return limiter(y, 0.95)


def crateis_wings(rng, v):           # Kepakan Crateis: satu kepakan sayap api raksasa - hempasan udara berat & kobaran
    flap = air_whoosh(0.7, rng, 120, 900, 200, 0.9, 0.35) * 1.6
    thud = thump(rng, 64, 36, 0.6, 0.1, 0.9, 0.4) * 0.5
    blaze = fire_whoosh(1.2, rng, 0.12, 2200) * 0.9
    flutter = fire_crackle(1.2, rng, np.linspace(300, 10, 20), 0.4)
    y = mix(flap, at(thud, 0.18), at(blaze, 0.1), at(flutter, 0.15))
    y = reverb2(master_eq(sat(y, 1.3), 0.4, 0.5, 0.45), 1.8, 0.7, 0.22, rng=rng)
    y = pad(y, 1.8)
    y[-int(0.4 * SR):] *= np.linspace(1, 0, int(0.4 * SR)) ** 2
    return limiter(y, 0.95)


def hellgate_windup(rng, v):         # 12 tick: tanah neraka bergemuruh & retak, geraman dari bawah, memuncak di 0,6 dtk
    d = 0.6
    n = int(d * SR)
    rumble = lp(brown(n, rng), 140, 2) * np.linspace(0.2, 1, n) ** 1.5 * 1.2
    cracks = crackle(d, 90, rng, 400, 3000, 0.006, np.linspace(0.2, 1, 20)) * 0.6
    deep = growl(d, 38.0, rng, "u", "o") * np.linspace(0, 1, n) ** 2 * 0.4
    y = mix(rumble, cracks, deep)
    return cut_at(pad(y, d + 0.1), d, 0.03, 1.8)


def hellgate_open(rng, v):           # Gerbang Neraka: braam neraka yang sumbang + ledakan api + paduan suara iblis
    dur = 5.0
    n = int(dur * SR)
    root = 41.2
    br = 0
    for f, a in ((root, 1), (root * 1.414, 0.6), (root * 2, 0.5), (root * 2.83, 0.25)):   # tritonus: sumbang
        br = br + a * supersaw(f, dur, 7, 0.012, rng)
    fc = np.concatenate([np.geomspace(250, 2000, 6), np.geomspace(2000, 260, 58)])
    br = sat(sweep_filter(br, fc, "low", 2.0) * env_adsr(dur, 0.015, 1.0, 0.6, 3.2) * 1.5, 3.0)
    kick = sub_drop(130, 26, 2.8, 0.8, 7) * 1.6
    blast = fire_whoosh(2.4, rng, 0.03, 3200) * 1.2
    choir_ = demon_choir(4.0, 61.7, rng, "o") * 0.3
    embers = fire_crackle(4.0, rng, np.concatenate([np.full(4, 700), np.linspace(700, 6, 36)]), 0.5)
    y = mix(br * 0.8, kick, blast, at(choir_, 0.5), at(embers, 0.05))
    y = reverb2(master_eq(sat(y, 1.3), 0.35, 0.5, 0.4), 3.5, 1.2, 0.28, rng=rng)
    y = pad(y, 5.5)
    y[-int(0.9 * SR):] *= np.linspace(1, 0, int(0.9 * SR)) ** 2
    return limiter(y, 0.95)


def legion_rise(rng, v):             # Pasukan Iblis: tanah terbelah, tulang-tulang bergemeretak, erangan prajurit yang bangkit
    crack = mix(thump(rng, 58, 30, 1.0, 0.2, 1.0, 0.6) * 0.6, crackle(1.0, 140, rng, 300, 2600, 0.008, np.linspace(1, 0, 20)) * 0.7)
    bones = np.zeros(1)
    for _ in range(26):   # tulang beradu: ketukan kayu kering
        ln = int(rng.uniform(0.015, 0.04) * SR)
        k = bp(white(ln, rng), 900, 4200, 2) * env_exp(ln, 0.006) * rng.uniform(0.3, 1.0)
        bones = mix(bones, at(k, rng.uniform(0.15, 1.6)))
    groan = demon_choir(2.2, 73.4 + 4 * v, rng, "u") * 0.35
    fire = fire_whoosh(1.4, rng, 0.2, 2000) * 0.5
    y = mix(crack, at(bones, 0.0), at(groan, 0.25), fire)
    y = reverb2(master_eq(y, 0.35, 0.55, 0.45), 2.4, 0.9, 0.24, rng=rng)
    y = pad(y, 2.8)
    y[-int(0.6 * SR):] *= np.linspace(1, 0, int(0.6 * SR)) ** 2
    return limiter(sat(y, 1.2), 0.95)


def demon_call_windup(rng, v):       # 12 tick: neraka bergemuruh di bawah kaki, desis api naik, memuncak di 0,6 dtk
    d = 0.6
    n = int(d * SR)
    rumble = lp(brown(n, rng), 170, 2) * np.linspace(0.2, 1, n) ** 1.6 * 1.1
    rise = sweep_filter(pink(n, rng), np.geomspace(300, 3800, 24), "band", 1.4) * np.linspace(0, 1, n) ** 2 * 0.5
    sparks = fire_crackle(d, rng, np.linspace(30, 400, 12), 0.35)
    y = mix(rumble, rise, sparks)
    return cut_at(pad(y, d + 0.1), d, 0.03, 1.8)


def demon_call(rng, v):              # Petir neraka menyembur naik: retakan dari bawah, deru api, geraman, guntur rendah
    crack = thunder_crack(rng, 0.8)
    roar_ = fire_whoosh(2.0, rng, 0.04, 3000) * 1.2
    kick = sub_drop(120, 28, 2.4, 0.7, 7) * 1.3
    howl = growl(1.8, 46.0 + 5 * v, rng, "o", "u") * 0.45
    th = thunder(rng, v % 3) * 0.4
    y = mix(crack, roar_, kick, at(howl, 0.08), at(th, 0.1))
    y = reverb2(master_eq(sat(y, 1.35), 0.35, 0.5, 0.42), 3.0, 1.0, 0.24, rng=rng)
    y = pad(y, 3.6)
    y[-int(0.7 * SR):] *= np.linspace(1, 0, int(0.7 * SR)) ** 2
    return limiter(y, 0.95)


def sabbac_pact(rng, v):             # Perjanjian Enam Iblis: bisikan enam suara makin rapat, dengung rendah, puncak di 3 dtk
    strike = 60 * 0.05
    dur = strike + 0.4
    n = int(dur * SR)
    drone = demon_choir(dur, 36.7, rng, "u") * np.linspace(0.2, 1, n) ** 1.3 * 0.45
    ws = np.zeros(1)
    vowels = ["e", "a", "o", "u", "e", "a"]
    for k in range(6):   # enam iblis berbisik satu per satu (tiap 0,4 dtk), lalu bersamaan
        for rep in range(3):
            t0 = 0.4 + k * 0.4 + rep * rng.uniform(0.5, 0.9)
            if t0 > strike - 0.3:
                continue
            ws = mix(ws, at(whisper(rng.uniform(0.35, 0.6), rng, vowels[k]) * rng.uniform(0.5, 0.9), t0))
    swell = reverse_swell(1.2, rng, 400, 9000) * 0.5
    y = mix(drone, ws, at(swell, strike - 1.2))
    y = reverb2(master_eq(y, 0.4, 0.55, 0.45), 2.8, 1.2, 0.3, rng=rng)
    return cut_at(pad(y, dur + 0.2), strike, 0.04, 1.4)


def rival_arrive(rng, v):            # Rival Juara datang: hantaman sinematik - braam, dentum, gemuruh panjang
    b = braam(rng, 2 if v else 1) * 0.8
    hit = thump(rng, 72, 30, 1.2, 0.22, 1.0, 1.0) * 0.9
    crack = thunder_crack(rng, 0.7)
    tail = dread(rng, 0)[int(0.8 * SR):] * 0.35
    y = mix(crack, hit, b, at(tail, 0.6))
    y = master_eq(sat(y, 1.25), 0.35, 0.5, 0.42)
    y = pad(y, 4.5)
    y[-int(0.8 * SR):] *= np.linspace(1, 0, int(0.8 * SR)) ** 2
    return limiter(y, 0.95)


WINDUPS.update({"horns_windup", "hellgate_windup", "demon_call_windup"})

RECIPES.update({
    "transform_sabbac": (transform_sabbac, 1, 1.0),
    "hellfire_pulse": (hellfire_pulse, 3, 0.9),
    "hellfire_punch": (hellfire_punch, 2, 1.0),
    "sabbac_engulf": (sabbac_engulf, 2, 0.9),
    "hellfire_out": (hellfire_out, 2, 0.85),
    "hellfire_in": (hellfire_in, 2, 0.85),
    "horns_windup": (horns_windup, 1, 0.8),
    "horns_charge": (horns_charge, 2, 1.0),
    "aym_shell": (aym_shell, 1, 0.9),
    "aym_burst": (aym_burst, 2, 1.0),
    "belial_chains": (belial_chains, 2, 0.85),
    "beelzebub_breath": (beelzebub_breath, 1, 0.95),
    "asmodeus_roar": (asmodeus_roar, 2, 1.0),
    "crateis_wings": (crateis_wings, 2, 0.95),
    "hellgate_windup": (hellgate_windup, 1, 0.85),
    "hellgate_open": (hellgate_open, 1, 1.0),
    "legion_rise": (legion_rise, 2, 0.95),
    "demon_call_windup": (demon_call_windup, 1, 0.85),
    "demon_call": (demon_call, 2, 1.0),
    "sabbac_pact": (sabbac_pact, 1, 0.85),
    "rival_arrive": (rival_arrive, 2, 1.0),
})


# ================================================================== 0.32 Lintang, juara bintang (0.35: fisik, tanpa paduan suara & lonceng)
LT_HIT = 0.15   # = ShazamAnim.ROD_DESCENT: sentuhan cahaya tepat di tick denyut


def lt_chime(freqs, dur, rng, tau=1.2):   # 0.35: nggak dipakai Lintang lagi (sisa 0.32)
    y = 0
    for f in freqs:
        y = y + bell(f, dur, rng, tau=tau)
    return y


def air_crack(rng, amp=1.0, gap=0.035):
    """0.35 Retakan udara (gelombang-N sonik): dorongan tajam lalu tarikan, tanpa nada."""
    n = int(0.012 * SR)
    a = hp(white(n, rng), 500) * env_exp(n, 0.003) * 3.0 * amp
    return mix(a, at(-0.8 * a, gap))


def lt_punch(rng, v, heavy=False):
    """0.35 Pukulan Lintang: dentum badan + tamparan udara, TANPA denting lonceng (punch(crit=True) punya lonceng)."""
    y = punch(rng, v, crit=False)
    if heavy:
        crk = hp(white(int(0.015 * SR), rng), 3000) * env_exp(int(0.015 * SR), 0.002) * 2.5
        y = mix(y, at(crk, 0.09), at(thump(rng, 90 - 6 * v, 40, 0.8, 0.16, 0.7, 0.4) * 0.6, 0.09))
    return y


def solar_pulse(rng, v):          # 0.35 tenaga surya kembali / sekutu diselamatkan: tarikan udara, lalu hembusan hangat & dentum lembut di 0,15 dtk
    hit = LT_HIT
    swell = reverse_swell(hit, rng, 600, 6000) * 0.45
    whoomp = air_whoosh(0.8, rng, 200, 950 + 80 * v, 220, 1.0, 0.12) * 0.9
    th = thump(rng, 70 - 4 * v, 38, 0.9, 0.2, 0.6, 0.25) * 0.55
    n = int(1.0 * SR)
    warmth = lp(pink(n, rng), 700) * env_adsr(1.0, 0.03, 0.2, 0.5, 0.6) * 0.25
    y = mix(swell, at(mix(whoomp, th, warmth), hit))
    y = reverb(y, 1.3, 0.25, rng=rng)
    return limiter(norm(y, 0.9), 0.95)


def heat_vision(rng, v):          # Iris Surya: rengekan memanas 0,3 dtk, lalu sinar mendesis & berdengung 2 dtk
    wind, beam = 0.3, 2.0
    dur = wind + beam + 0.3
    n = int(dur * SR)
    t = t_axis(dur)
    whine = osc(exp_sweep(260, 1500 + 200 * v, wind, 3.0), wind, "saw")
    whine = lp(whine, 3000) * np.linspace(0.05, 0.6, len(whine)) ** 1.5
    f0 = 110 + 7 * v
    hum = lp(osc(f0, dur, "saw") * 0.5 + osc(f0 * 2.01, dur, "saw") * 0.3 + osc(f0 * 3.02, dur) * 0.2, 1400)
    env = np.clip((t - wind) / 0.04, 0, 1) * np.clip((dur - t) / 0.25, 0, 1)
    sizzle = bp(white(n, rng), 1800, 7500) * (0.55 + 0.45 * np.sin(2 * np.pi * 17 * t + rng.uniform(0, 6)))
    crack = crackle(dur, 140, rng, 2500, 11000, 0.002)
    burst = lp(white(int(0.25 * SR), rng), 5000) * env_exp(int(0.25 * SR), 0.05)
    y = mix(whine, (hum * 0.6 + sizzle * 0.35 + crack * 0.35) * env, at(burst * 0.7, wind))
    y = reverb(sat(y, 1.4), 0.9, 0.2, rng=rng)
    return limiter(norm(y, 0.9), 0.95)


def frost_breath(rng, v):         # Napas Salju: tarikan napas 0,4 dtk, lalu hembusan beku menderu & es berderak (0.35 tanpa denting)
    inhale = reverse_swell(0.4, rng, 900, 9000) * 0.6
    dur = 2.1
    n = int(dur * SR)
    t = t_axis(dur)
    hiss = sweep_filter(bp(white(n, rng), 900, 9000), np.linspace(9000, 3500, 48), "low", 0.8)
    env = np.minimum(1, t / 0.08) * np.clip((dur - t) / 0.5, 0, 1)
    gust = lp(pink(n, rng), 1200) * 0.5 * (0.7 + 0.3 * np.sin(2 * np.pi * 3.1 * t))
    ice = crackle(dur, 80, rng, 4000, 14000, 0.0015) * 0.7
    frost = crackle(dur, 22, rng, 1800, 6000, 0.004) * 0.35   # 0.35: es retak yang lebih besar, tanpa denting kaca
    y = mix(inhale, at(mix((hiss * 0.6 + gust) * env, ice * env, frost * env), 0.4))
    y = reverb(y, 1.4, 0.3, rng=rng)
    return limiter(norm(y, 0.88), 0.95)


def sonic_clap(rng, v):           # Tepukan Guruh: tepukan tajam, retakan udara, dentum rendah panjang, gelombang yang menjauh
    cn = int(0.012 * SR)
    clap = hp(white(cn, rng), 1200) * env_exp(cn, 0.003) * 2.0
    crack = thunder_crack(rng, 1.0) * 0.6
    boom = sub_drop(120 - 10 * v, 32, 2.0, 0.5) * 1.1
    wave = shockwave(rng, v) * 0.7
    na = int(1.6 * SR)
    air = sweep_filter(white(na, rng), np.geomspace(9000, 400, 32), "low", 0.8) * env_exp(na, 0.35) * 0.5
    y = mix(clap, at(crack, 0.002), boom, at(wave, 0.01), air)
    y = reverb(sat(y, 1.6), 2.6, 0.35, rng=rng, size=1.6)
    return limiter(norm(y, 0.95), 0.95)


def speed_dash(rng, v):           # Lesatan Bintang: desing berat lalu dentum sonik
    y = mix(whoosh(rng, v, heavy=True), at(sonic_boom(rng, v) * 0.7, 0.18))
    return limiter(norm(y, 0.92), 0.95)


def dawn_punch(rng, v):           # 0.35 Tinju Baja: hantaman sekeras baja, retakan udara, dentum gelombang kejut, puing
    hit = lt_punch(rng, v, heavy=True)
    crack = at(air_crack(rng, 1.1), 0.09)
    boom = at(thump(rng, 80 - 6 * v, 30, 1.6, 0.4, 0.8, 0.4) * 0.9, 0.09)
    na = int(1.2 * SR)
    air = at(sweep_filter(white(na, rng), np.geomspace(7000, 300, 32), "low", 0.8) * env_exp(na, 0.25) * 0.5, 0.09)
    debris = at(crackle(1.0, 90, rng, 300, 3500, 0.006, np.linspace(1, 0, 30) ** 2) * 0.45, 0.14)
    y = mix(hit, crack, boom, air, debris)
    y = reverb(sat(y, 1.6), 1.6, 0.25, rng=rng, size=1.4)
    return limiter(norm(y, 0.95), 0.95)


def barrage(rng, v):              # Amukan Kilat: rentetan pukulan secepat kilat, ditutup pukulan berat
    total = 1.45
    y = np.zeros(int(total * SR))
    tpos, k = 0.05, 0
    while tpos < 1.2:
        y = y + at(punch(rng, k % 2) * rng.uniform(0.35, 0.7), tpos, total)
        tpos += rng.uniform(0.045, 0.07)
        k += 1
    y = mix(y, at(lt_punch(rng, 1, heavy=True) * 1.2, 1.22), whoosh(rng, 0) * 0.35)   # 0.35: tanpa denting lonceng
    y = reverb(y, 0.8, 0.2, rng=rng)
    return limiter(norm(y, 0.92), 0.95)


def solar_flare(rng, v):          # 0.35 Gelegar Surya: panas tertahan 0,8 dtk (= FLARE_WINDUP), lalu ledakan panas & gelombang kejut
    wind = 0.8
    nw = int(wind * SR)
    tw = np.linspace(0, 1, nw)
    hum = heat_hum(wind, rng) * tw ** 1.5 * 0.5
    roar_up = sweep_filter(fire_roar(wind, rng, 60, 2500, 16), np.geomspace(150, 2400, 32), "low", 0.9)
    roar_up = unit(roar_up) * tw ** 2 * 0.6
    suck = reverse_swell(wind, rng, 500, 9000) * 0.55
    blast = mix(impact(rng, v), shockwave(rng, v) * 0.9, sub_drop(80, 26, 3.0, 0.8) * 1.2, air_crack(rng, 1.3))
    nb = int(2.4 * SR)
    whoomph = fire_whoosh(2.4, rng, 0.08, 3200) * 0.7
    hiss = sweep_filter(white(nb, rng), np.geomspace(9000, 500, 32), "low", 0.8) * env_exp(nb, 0.5) * 0.4
    y = mix(hum, roar_up, suck, at(mix(blast, whoomph, hiss), wind))
    y = reverb(sat(y, 1.3), 3.0, 0.32, rng=rng, size=1.8)
    return limiter(norm(y, 0.95), 0.95)


def sun_strike(rng, v):           # 0.35 (sisa, Lintang nggak memanggil tiang cahaya lagi): hantaman tanah - dentum, retakan, puing
    nb = int(0.3 * SR)
    y = mix(thump(rng, 90 - 8 * v, 34, 1.4, 0.35, 0.8, 0.4), at(earth_crack(rng, v) * 0.6, 0.01),
            lp(white(nb, rng), 4000) * env_exp(nb, 0.05) * 0.6)
    y = reverb(y, 2.0, 0.3, rng=rng)
    return limiter(norm(y, 0.92), 0.95)


def sun_call(rng, v):             # 0.35 Serap Surya: hawa panas terhisap ke badan 0,5 dtk (= SUNCALL_WINDUP), lalu dilepas: hembusan & dentum
    wind = 0.5
    nw = int(wind * SR)
    tw = np.linspace(0, 1, nw)
    hum = heat_hum(wind, rng) * tw ** 1.2 * 0.6
    air = reverse_swell(wind, rng, 600, 8000) * 0.5
    nr = int(1.6 * SR)
    release = mix(thump(rng, 75, 32, 1.4, 0.35, 0.7, 0.3), air_whoosh(1.2, rng, 160, 1100, 200, 1.0, 0.1) * 0.9,
                  heat_hum(1.6, rng) * env_exp(nr, 0.5) * 0.35)
    y = mix(hum, air, at(release, wind))
    y = reverb(y, 1.6, 0.25, rng=rng)
    return limiter(norm(y, 0.92), 0.95)


def transform_lintang(rng, v):    # 0.35 kostum Lintang terpasang secepat kilat (tick LINTANG_SUITUP): retakan sonik, dentum udara, jubah berkibar
    crack = air_crack(rng, 1.4)
    boom = mix(thump(rng, 70, 26, 3.0, 0.8, 0.9, 0.45) * 1.2, shockwave(rng, v) * 0.8)
    na = int(2.2 * SR)
    air = sweep_filter(white(na, rng), np.geomspace(10000, 500, 40), "low", 0.8) * env_exp(na, 0.5) * 0.5
    y = mix(crack, boom, air, at(cape_snap(rng, v) * 0.8, 0.06), at(cape_snap(rng, v + 1) * 0.5, 0.32))
    y = reverb(sat(y, 1.25), 2.8, 0.3, rng=rng, size=1.6)
    return limiter(norm(y, 0.95), 0.95)


def lintang_rite(rng, v):         # 0.35 Eksperimen Evolusi Surya dimulai: klik injektor, desis serum, tubuh menghangat, detak jantung
    click = hp(white(int(0.006 * SR), rng), 2500) * env_exp(int(0.006 * SR), 0.0012) * 1.5
    nh = int(0.5 * SR)
    hiss = bp(white(nh, rng), 3000, 11000) * env_adsr(0.5, 0.01, 0.1, 0.5, 0.35) * 0.45
    dur = 3.2
    n = int(dur * SR)
    t = t_axis(dur)
    warm = lp(pink(n, rng), 500) * (t / dur) ** 1.5 * np.clip((dur - t) / 0.6, 0, 1) * 0.3
    beats = mix(at(heartbeat(rng, v) * 0.7, 0.6), at(heartbeat(rng, v) * 0.8, 1.55), at(heartbeat(rng, v) * 0.9, 2.4))
    y = mix(click, at(hiss, 0.01), warm, beats)
    y = reverb(y, 1.4, 0.22, rng=rng)
    return limiter(norm(y, 0.9), 0.95)


def kelam_hum(rng, v):            # Batu Kelam: dengung gelap yang bergetar, cahaya seperti tersedot
    dur = 1.4
    t = t_axis(dur)
    drone = osc(55, dur, "saw") * 0.5 + osc(55 * 1.012, dur, "saw") * 0.5 + osc(82.4 * 0.994, dur, "saw") * 0.35
    drone = lp(drone, 500) * (0.6 + 0.4 * np.sin(2 * np.pi * 6.5 * t))
    suck = reverse_swell(0.7, rng, 300, 4000)[::-1] * 0.4
    env = np.minimum(1, t / 0.15) * np.clip((dur - t) / 0.5, 0, 1)
    y = reverb(mix(drone * env, suck), 1.6, 0.35, rng=rng)
    return limiter(norm(y, 0.85), 0.95)


def frost_parry(rng, v):          # 0.35 Refleks Kilat: tangan menyambar secepat kilat (desing), TANGKAPAN keras, dentum balasan
    zip_ = zip_by(0.06, rng, 4200, 1500, True) * 0.5
    slap = bp(white(int(0.05 * SR), rng), 500, 6000) * env_exp(int(0.05 * SR), 0.008) * 1.6
    th = thump(rng, 120 + 10 * v, 50, 0.5, 0.09, 0.6, 0.5) * 0.8
    y = mix(zip_, at(mix(slap, th, air_crack(rng, 0.6)), 0.06), at(whoosh(rng, v) * 0.3, 0.06))
    y = reverb(sat(y, 1.6), 0.9, 0.2, rng=rng)
    return limiter(norm(y, 0.9), 0.95)


RECIPES.update({
    "solar_pulse": (solar_pulse, 3, 0.85),
    "heat_vision": (heat_vision, 2, 0.95),
    "frost_breath": (frost_breath, 1, 0.9),
    "sonic_clap": (sonic_clap, 2, 1.0),
    "speed_dash": (speed_dash, 2, 0.9),
    "dawn_punch": (dawn_punch, 2, 1.0),
    "barrage": (barrage, 1, 0.9),
    "solar_flare": (solar_flare, 1, 1.0),
    "sun_strike": (sun_strike, 2, 0.95),
    "sun_call": (sun_call, 1, 0.95),
    "transform_lintang": (transform_lintang, 1, 1.0),
    "lintang_rite": (lintang_rite, 1, 0.9),
    "kelam_hum": (kelam_hum, 1, 0.8),
    "frost_parry": (frost_parry, 2, 0.9),
})


# ================================================================== 0.37 Lintang: Napas Topan & Ledakan Surya (fisik)

def super_breath(rng, v):         # 0.37 Napas Topan: tarikan napas 0,4 dtk, lalu angin topan menderu 2 dtk (tanpa nada)
    inhale = reverse_swell(0.4, rng, 500, 5000) * 0.5
    dur = 2.2
    n = int(dur * SR)
    t = t_axis(dur)
    env = np.minimum(1, t / 0.08) * np.clip((dur - t) / 0.5, 0, 1)
    ph = rng.uniform(0, 6.28)
    gust = 0.62 + 0.38 * np.sin(2 * np.pi * 1.1 * t + ph) * np.sin(2 * np.pi * 0.37 * t + 1.0 + v)
    roar = sweep_filter(white(n, rng), np.geomspace(2600, 900, 32), "low", 0.7) * 0.7
    body = lp(pink(n, rng), 400) * 0.6
    hiss = hp(white(n, rng), 5000) * 0.16
    y = mix(inhale, at((roar + body + hiss) * gust * env, 0.4))
    y = reverb(y, 1.2, 0.2, rng=rng)
    return limiter(norm(y, 0.9), 0.95)


def solar_nova(rng, v):           # 0.37 Ledakan Surya: 3 dtk panas terkumpul (gemuruh & deru naik terus), lalu ledakan raksasa tepat di 3 dtk
    wind = 3.0
    nw = int(wind * SR)
    tw = np.linspace(0, 1, nw)
    rumble = unit(lp(pink(nw, rng), 120)) * (0.15 + 0.85 * tw ** 1.6) * 0.45   # tanah bergetar makin hebat
    roar = unit(sweep_filter(fire_roar(wind, rng, 50, 3000, 12), np.geomspace(120, 3000, 48), "low", 0.9)) * tw ** 2.4 * 0.4
    hum = unit(heat_hum(wind, rng)) * tw ** 1.3 * 0.25
    suck = unit(reverse_swell(0.9, rng, 400, 10000)) * 0.5        # udara terhisap tepat sebelum meledak
    pre = mix(rumble, roar, hum, at(suck, wind - 0.9))
    tail = 5.0
    nt = int(tail * SR)
    blast = mix(impact(rng, v) * 1.2, shockwave(rng, v), sub_drop(70, 22, 4.0, 1.0) * 1.4, air_crack(rng, 1.6),
                fire_whoosh(3.5, rng, 0.06, 2800) * 0.8,
                lp(pink(nt, rng), 200) * env_exp(nt, 1.6) * 0.9,                                   # gemuruh panjang
                crackle(tail, 60, rng, 300, 4000, 0.008, np.linspace(1, 0, 40) ** 2) * 0.5)        # puing berjatuhan
    y = mix(pre, at(blast, wind))
    y = reverb(sat(y, 1.3), 3.5, 0.35, rng=rng, size=2.0)
    return limiter(norm(y, 0.95), 0.95)


RECIPES.update({
    "super_breath": (super_breath, 2, 0.9),
    "solar_nova": (solar_nova, 1, 1.0),
})



# ---------------------------------------------------------------- 0.39 Lintang gaya film

def heat_vision_film(rng, v):     # 0.39 Iris Surya: mata memanas 0,3 dtk (= IRIS_WINDUP), sinyal "fwoom", berkas 2 dtk
    wind, beam = 0.3, 2.0
    dur = wind + beam + 0.35
    n = int(dur * SR)
    t = t_axis(dur)
    # mata memanas: rengekan naik + dengung yang membengkak
    whine = osc(exp_sweep(320, 2600 + 150 * v, wind, 2.6), wind, "saw")
    whine = lp(whine, 4200) * np.linspace(0.02, 0.7, len(whine)) ** 1.6
    # nyala: hentakan udara panas
    nb = int(0.35 * SR)
    fwoom = sweep_filter(white(nb, rng), np.geomspace(9000, 700, 24), "low", 0.8) * env_exp(nb, 0.09)
    knock = thump(rng, 95 - 6 * v, 45, 0.5, 0.12, 0.7, 0.3) * 0.7
    # berkas: dengung energi rendah yang berdenyut, drone menengah yang beat, desis terbakar yang berkedip, letupan
    on = np.clip((t - wind) / 0.03, 0, 1) * np.clip((dur - t) / 0.3, 0, 1)
    f0 = 55 + 3 * v
    sub = lp(osc(f0, dur, "saw") * 0.6 + osc(f0 * 2.0, dur, "saw") * 0.4, 380) * (0.8 + 0.2 * np.sin(2 * np.pi * 6.5 * t))
    drone = bp(osc(220 + 6 * v, dur, "saw") + osc(223.5 + 6 * v, dur, "saw") + 0.5 * osc(331 + 9 * v, dur, "saw"), 260, 1700)
    flick = 0.55 + 0.45 * np.abs(np.sin(2 * np.pi * (31 + 4 * v) * t + rng.uniform(0, 6)))
    sizzle = bp(white(n, rng), 2200, 9500) * flick
    burn = crackle(dur, 220, rng, 1800, 12000, 0.0018) * 0.9
    pops = crackle(dur, 14, rng, 400, 3000, 0.01) * 0.6
    body = (unit(sub) * 0.7 + unit(drone) * 0.35 + unit(sizzle) * 0.45 + burn * 0.4 + pops) * on
    # padam: dengung turun nada
    nt = int(0.35 * SR)
    tail = lp(osc(exp_sweep(220, 70, 0.35, 1.0), 0.35, "saw"), 900) * env_exp(nt, 0.12) * 0.4
    y = mix(whine, at(mix(fwoom * 0.9, knock), wind), body, at(tail, wind + beam))
    y = reverb(sat(y, 1.8), 1.1, 0.22, rng=rng)
    return limiter(norm(y, 0.92), 0.95)


def hero_land(rng, v):            # 0.39 mendarat gaya pahlawan: dentum dalam, tanah retak, batu & debu berjatuhan
    hit = impact(rng, v) * 0.9
    sub = thump(rng, 72 - 5 * v, 28, 1.6, 0.45, 0.9, 0.45) * 1.1
    crack = at(earth_crack(rng, v) * 0.75, 0.015)
    na = int(1.4 * SR)
    dust = sweep_filter(white(na, rng), np.geomspace(6000, 250, 32), "low", 0.8) * env_exp(na, 0.3) * 0.5
    debris = at(crackle(1.6, 70, rng, 250, 3200, 0.007, np.linspace(1, 0, 30) ** 1.6) * 0.55, 0.12)
    y = mix(hit, sub, crack, at(dust, 0.02), debris)
    y = reverb(sat(y, 1.5), 1.9, 0.28, rng=rng, size=1.5)
    return limiter(norm(y, 0.95), 0.95)


RECIPES.update({
    "heat_vision": (heat_vision_film, 2, 0.95),   # 0.39: menggantikan versi 0.35
    "hero_land": (hero_land, 2, 1.0),
})


# ---------------------------------------------------------------- 0.42 Lintang: sinar di-charge, Lintas Detik, Nyala Mentari

LOOPS = {"wind_loop", "laser_charge", "laser_loop", "sun_loop"}


def seamless(y, n_loop, xf):
    """y sepanjang n_loop + xf sampel -> n_loop sampel yang mulus diulang (ekor di-crossfade ke awal)."""
    a = y[:n_loop].copy()
    w = np.linspace(0, 1, xf)
    a[:xf] = a[:xf] * w + y[n_loop:n_loop + xf] * (1 - w)
    return a


def laser_charge(rng, v):         # 0.42 mata mengumpulkan panas (diulang; client menaikkan nada & kerasnya sesuai charge)
    dur, xf = 2.0, 0.5
    L = int((dur + xf) * SR)
    tt = np.arange(L) / SR
    f0 = 110.0   # 220 putaran dalam 2 detik: kelipatan pas, sambungan nggak terdengar
    hum = osc(f0, dur + xf, "saw") * 0.5 + osc(f0 * 2, dur + xf, "saw") * 0.3 + osc(f0 * 3, dur + xf) * 0.25
    hum = lp(hum, 1600) * (0.75 + 0.25 * np.sin(2 * np.pi * 4 * tt / dur * 2))
    whine = osc(1320.0, dur + xf) * 0.12 * (0.6 + 0.4 * np.sin(2 * np.pi * 3 * tt / dur))
    shimmer = bp(white(L, rng), 2500, 9000) * 0.18 * (0.5 + 0.5 * np.abs(np.sin(2 * np.pi * 9 * tt / dur)))
    crack = crackle(dur + xf, 30, rng, 1500, 9000, 0.0015) * 0.35
    y = seamless(unit(hum) * 0.8 + whine + shimmer + crack, int(dur * SR), int(xf * SR))
    return sat(y, 1.4) * 0.9


def laser_fire(rng, v):           # 0.42 sinar dilepas: hentakan udara panas, retakan, desis yang menyembur
    dur = 1.1
    n = int(dur * SR)
    nb = int(0.45 * SR)
    fwoom = sweep_filter(white(nb, rng), np.geomspace(11000, 600, 24), "low", 0.8) * env_exp(nb, 0.12)
    knock = thump(rng, 88 - 6 * v, 38, 0.7, 0.16, 0.7, 0.4) * 0.9
    crk = air_crack(rng, 1.2, 0.03)
    t = t_axis(dur)
    sizzle = bp(white(n, rng), 2400, 10000) * np.exp(-t * 3.2) * (0.55 + 0.45 * np.abs(np.sin(2 * np.pi * 37 * t)))
    burn = crackle(dur, 260, rng, 1800, 12000, 0.0016, np.linspace(1, 0.1, 20)) * 0.8
    y = mix(fwoom, knock, crk, unit(sizzle) * 0.5, burn)
    y = reverb(sat(y, 1.8), 1.0, 0.2, rng=rng)
    return limiter(norm(y, 0.95), 0.95)


def laser_loop(rng, v):           # 0.42 sinar menyala (diulang): dengung berat yang berdenyut, desis & bahan terbakar meletup
    dur, xf = 2.0, 0.5
    L = int((dur + xf) * SR)
    tt = np.arange(L) / SR
    sub = lp(osc(55.0, dur + xf, "saw") * 0.6 + osc(110.0, dur + xf, "saw") * 0.4, 420) * (0.8 + 0.2 * np.sin(2 * np.pi * 13 * tt / dur))
    drone = bp(osc(220.0, dur + xf, "saw") + osc(222.0, dur + xf, "saw") + 0.5 * osc(330.0, dur + xf, "saw"), 260, 1800)
    flick = 0.55 + 0.45 * np.abs(np.sin(2 * np.pi * 62 * tt / dur))
    sizzle = bp(white(L, rng), 2200, 9500) * flick
    burn = crackle(dur + xf, 240, rng, 1800, 12000, 0.0018)
    pops = crackle(dur + xf, 16, rng, 300, 2600, 0.012) * 0.7
    y = unit(sub) * 0.7 + unit(drone) * 0.3 + unit(sizzle) * 0.4 + burn * 0.45 + pops
    y = seamless(y, int(dur * SR), int(xf * SR))
    return sat(y, 1.5) * 0.85


def blitz_stop(rng, v):           # 0.42 Lintas Detik: dunia berhenti - tarikan udara terbalik, "vwomp" yang anjlok, dengung tinggi
    swell = reverse_swell(0.35, rng, 500, 9000) * 0.6
    n = int(0.9 * SR)
    t = t_axis(0.9)
    vwomp = osc(exp_sweep(320, 38, 0.9, 4.0), 0.9) * np.exp(-t * 4.0) * 0.9
    body = lp(brown(n, rng), 300) * np.exp(-t * 5.0) * 0.6
    ring = osc(3400.0 + 120 * v, 1.2) * np.exp(-t_axis(1.2) * 2.6) * 0.08
    y = mix(swell, at(mix(sat(vwomp, 2.0), body), 0.35), at(ring, 0.35))
    y = reverb(y, 1.6, 0.3, rng=rng)
    return limiter(norm(y, 0.92), 0.95)


def blitz_resume(rng, v):         # 0.42 waktu jalan lagi: rentetan dentuman sonik beruntun, lalu dentum besar & puing
    parts = []
    for i in range(8):
        tt0 = 0.035 * i + rng.uniform(0, 0.012)
        parts.append(at(air_crack(rng, 0.9 + 0.1 * rng.random(), 0.03) * 0.8, tt0))
        parts.append(at(thump(rng, 80 + 6 * rng.random(), 40, 0.35, 0.08, 0.5, 0.3) * 0.35, tt0))
    big = at(sonic_boom(rng, v) * 0.9, 0.3)
    na = int(1.2 * SR)
    debris = at(crackle(1.2, 60, rng, 300, 3500, 0.006, np.linspace(1, 0, 20) ** 1.5) * 0.4, 0.35)
    dust = at(sweep_filter(white(na, rng), np.geomspace(5000, 300, 24), "low", 0.8) * env_exp(na, 0.3) * 0.35, 0.32)
    y = mix(*parts, big, debris, dust)
    y = reverb(sat(y, 1.6), 1.5, 0.25, rng=rng)
    return limiter(norm(y, 0.95), 0.95)


def sun_form(rng, v):             # 0.42 Nyala Mentari: cahaya terkumpul (deru naik 0,7 dtk = SUN_WINDUP), plasma menyala
    wind = 0.7
    swell = air_whoosh(wind, rng, 200, 2600, 900, 1.0, 0.92) * 0.8
    rise = lp(osc(exp_sweep(60, 240, wind, 2.0), wind, "saw"), 1200) * np.linspace(0, 1, int(wind * SR)) ** 2 * 0.5
    n = int(1.4 * SR)
    t = t_axis(1.4)
    roar = sweep_filter(brown(n, rng), np.geomspace(2400, 400, 24), "low", 0.7) * np.exp(-t * 1.6) * 1.2
    knock = thump(rng, 70 - 4 * v, 32, 1.0, 0.25, 0.8, 0.4) * 0.8
    crack = crackle(1.4, 120, rng, 1200, 9000, 0.002, np.linspace(1, 0.2, 20)) * 0.6
    y = mix(swell, rise, at(mix(roar, knock, crack), wind))
    y = reverb(sat(y, 1.7), 1.8, 0.28, rng=rng)
    return limiter(norm(y, 0.95), 0.95)


def sun_loop(rng, v):             # 0.42 matahari mini menyala (diulang): gemuruh plasma rendah, deru api, letupan
    dur, xf = 3.0, 0.8
    L = int((dur + xf) * SR)
    tt = np.arange(L) / SR
    rumble = lp(brown(L, rng), 160) * (0.8 + 0.2 * np.sin(2 * np.pi * 2 * tt / dur))
    roar = bp(pink(L, rng), 180, 1400) * (0.6 + 0.4 * np.sin(2 * np.pi * 3 * tt / dur + 1.0))
    hum = lp(osc(40.0, dur + xf, "saw") + 0.5 * osc(80.0, dur + xf, "saw"), 300) * 0.6
    crack = crackle(dur + xf, 70, rng, 900, 8000, 0.003) * 0.6
    y = unit(rumble) * 0.8 + unit(roar) * 0.5 + unit(hum) * 0.4 + crack
    y = seamless(y, int(dur * SR), int(xf * SR))
    return sat(y, 1.4) * 0.85


RECIPES.update({
    "laser_charge": (laser_charge, 1, 0.7),
    "laser_fire": (laser_fire, 2, 1.0),
    "laser_loop": (laser_loop, 1, 0.75),
    "blitz_stop": (blitz_stop, 1, 0.95),
    "blitz_resume": (blitz_resume, 1, 1.0),
    "sun_form": (sun_form, 1, 1.0),
    "sun_loop": (sun_loop, 1, 0.8),
})


def render(name, fn, v, gain):
    import zlib; rng = np.random.default_rng(zlib.crc32(f"{name}:{v}".encode()))
    y = fn(rng, v)
    if name in LOOPS and name != "wind_loop":   # 0.42: diolah 3x berderet, ambil yang tengah -> sambungan ulangnya mulus
        n = len(y)
        y3 = np.concatenate([y, y, y])
        y3 = hp(y3, 25, 2)
        y3 = limiter(norm(y3, 0.95), 0.92)
        return norm(y3, 0.89 * gain)[n:2 * n].astype(np.float32)
    if name not in LOOPS:   # 0.42: suara yang diulang nggak dipotong/diberi fade
        y = trim_tail(y)
        y = fade(y, 0.0005, 0.02 if name in WINDUPS else 0.08)
    y = hp(y, 25, 2)                 # buang DC/infrasonik
    y = limiter(norm(y, 0.95), 0.92)
    y = norm(y, 0.89 * gain)
    if name in WINDUPS:   # ancang-ancang: disamakan kerasnya (RMS), jangan sampai menutupi hantamannya
        rms = np.sqrt(np.mean(y ** 2)) + 1e-9
        y = y * min(10 ** (-19 / 20) / rms, 0.89 / (np.max(np.abs(y)) + 1e-9))
    return y.astype(np.float32)


def encode(y, path):
    raw = path + ".raw"
    y.tofile(raw)
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "f32le", "-ar", str(SR), "-ac", "1", "-i", raw,
                    "-c:a", "libvorbis", "-q:a", "6", path], check=True)
    os.remove(raw)


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    only = sys.argv[2:] if len(sys.argv) > 2 else None
    stats = {}
    for name, (fn, count, gain) in RECIPES.items():
        if only and name not in only:
            continue
        for v in range(count):
            y = render(name, fn, v, gain)
            fname = f"{name}_{v + 1}.ogg"
            encode(y, os.path.join(OUT, fname))
            rms = 20 * np.log10(np.sqrt(np.mean(y ** 2)) + 1e-9)
            stats[fname] = (round(len(y) / SR, 2), round(float(rms), 1))
            print(fname, stats[fname], flush=True)
