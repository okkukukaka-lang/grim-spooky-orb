@rem Menjalankan Gradle lewat gradle\wrapper\gradle-wrapper.jar
@if "%DEBUG%"=="" @echo off
setlocal
set "APP_HOME=%~dp0"
if defined JAVA_HOME (
    set "JAVA_EXE=%JAVA_HOME%\bin\java.exe"
) else (
    set "JAVA_EXE=java.exe"
)
"%JAVA_EXE%" -version >NUL 2>&1
if errorlevel 1 (
    echo ERROR: Java tidak ditemukan. Install JDK 21, lalu set JAVA_HOME atau tambahkan java ke PATH.
    exit /b 1
)
"%JAVA_EXE%" -Xmx64m -Xms64m -classpath "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
exit /b %ERRORLEVEL%
