package com.shazammod.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.ShazamClientState;
import com.shazammod.client.anim.Ease;
import com.shazammod.client.anim.ShazamPoses;

import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.PlayerSkin;

/**
 * Perlengkapan emas yang cuma dipakai Black Adam (Shazam nggak punya): gelang lengan (bracer) emas tebal di kedua
 * lengan bawah dengan permata pirus dan alur petir, dan sabuk emas lebar dengan gesper berpermata. Muncul bersama
 * kostum saat berubah dan mengecil hilang saat balik jadi manusia. Warnanya dari FormLook.BLACK_ADAM.
 *
 * Satuan: piksel model (lengan 4x12x4 atau 3x12x4 untuk skin ramping, badan 8x12x4), +y ke bawah, depan = -z.
 */
public class AdamGearLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    // ======= Ukuran & posisi =======
    private static final float BRACER_TOP = 5.3f;      // dari bahu (y = -2) ke ujung tangan (y = 10)
    private static final float BRACER_BOTTOM = 9.7f;
    private static final float BRACER_PAD = 0.42f;     // setebal ini di luar lengan baju skin
    private static final float BELT_TOP = 9.4f;        // badan: leher y = 0, pinggang y = 12
    private static final float BELT_BOTTOM = 11.7f;
    private static final float BELT_PAD = 0.5f;
    private static final int APPEAR = 5;               // tick sesudah kilau kostum mulai

    public AdamGearLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    /** Besar 0-1: muncul memantul saat berubah, mengecil hilang saat kembali jadi manusia. */
    private static float size(AbstractClientPlayer player, float partialTick) {
        float t = ShazamCape.revealTime(player, partialTick);
        if (t >= 0f) {
            float s = (t - APPEAR) / 6f;
            return s <= 0f ? 0f : s >= 1f ? 1f : Ease.OUT_BACK.apply(s);
        }
        if (!ShazamPoses.suitIn(player)) {
            float out = ShazamPoses.suitTicks(player, partialTick);
            if (out >= 0f) {
                return Math.max(0f, 1f - out / 5f);
            }
        }
        return 0f;
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, AbstractClientPlayer player,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (player.isInvisible() || !ShazamClientState.isAdam(player.getId())) {
            return;
        }
        float k = size(player, partialTick);
        if (k <= 0.001f) {
            return;
        }
        FormLook look = FormLook.BLACK_ADAM;
        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(CapeDecor.WHITE));
        boolean slim = player.getSkin().model() == PlayerSkin.Model.SLIM;
        PlayerModel<AbstractClientPlayer> model = this.getParentModel();
        for (int side = 0; side < 2; side++) {
            boolean right = side == 0;
            ModelPart arm = right ? model.rightArm : model.leftArm;
            float x0 = right ? (slim ? -2f : -3f) : -1f;
            float x1 = right ? 1f : (slim ? 2f : 3f);
            poseStack.pushPose();
            arm.translateAndRotate(poseStack);
            poseStack.scale(1f / 16f, 1f / 16f, 1f / 16f);
            bracer(vc, poseStack.last(), x0, x1, right, k, packedLight, look);
            poseStack.popPose();
        }
        poseStack.pushPose();
        model.body.translateAndRotate(poseStack);
        poseStack.scale(1f / 16f, 1f / 16f, 1f / 16f);
        belt(vc, poseStack.last(), k, packedLight, look);
        poseStack.popPose();
    }

    /** Gelang lengan: pita emas tebal, bibir atas & bawah yang lebih tebal, permata pirus dan alur petir di sisi luar. */
    private static void bracer(VertexConsumer vc, PoseStack.Pose pose, float x0, float x1, boolean right, float k, int light,
                               FormLook look) {
        float cx = (x0 + x1) / 2f, cy = (BRACER_TOP + BRACER_BOTTOM) / 2f;
        float hx = ((x1 - x0) / 2f + BRACER_PAD) * k, hy = (BRACER_BOTTOM - BRACER_TOP) / 2f * k, hz = (2f + BRACER_PAD) * k;
        box(vc, pose, cx - hx, cy - hy, -hz, cx + hx, cy + hy, hz, look.gold, light);
        float lip = 0.32f * k, out = 0.18f * k;
        box(vc, pose, cx - hx - out, cy - hy, -hz - out, cx + hx + out, cy - hy + lip * 2f, hz + out, look.goldEdge, light);
        box(vc, pose, cx - hx - out, cy + hy - lip * 2f, -hz - out, cx + hx + out, cy + hy, hz + out, look.goldEdge, light);
        // sisi luar lengan: lengan kanan di -x, lengan kiri di +x
        float face = right ? cx - hx : cx + hx;
        float dir = right ? -1f : 1f;
        float gem = 0.55f * k;
        box(vc, pose, Math.min(face, face + dir * 0.35f * k), cy - gem, -gem, Math.max(face, face + dir * 0.35f * k), cy + gem, gem,
                look.gem, LightTexture.FULL_BRIGHT);
        // alur petir di depan gelang (zig-zag tiga potong, emas tua)
        float z = -hz - 0.04f * k;
        float[][] bolt = {{-0.6f, -1.5f, 0.3f, -0.4f}, {-0.3f, -0.5f, 0.5f, 0.4f}, {-0.4f, 0.4f, 0.4f, 1.5f}};
        for (float[] b : bolt) {
            box(vc, pose, cx + b[0] * k, cy + b[1] * k, z - 0.08f * k, cx + b[2] * k, cy + b[3] * k, z, look.goldDark, light);
        }
    }

    /** Sabuk emas lebar dengan bibir berkilau dan gesper berpermata pirus di depan. */
    private static void belt(VertexConsumer vc, PoseStack.Pose pose, float k, int light, FormLook look) {
        float cy = (BELT_TOP + BELT_BOTTOM) / 2f;
        float hx = (4f + BELT_PAD) * k, hy = (BELT_BOTTOM - BELT_TOP) / 2f * k, hz = (2f + BELT_PAD) * k;
        box(vc, pose, -hx, cy - hy, -hz, hx, cy + hy, hz, look.gold, light);
        float lip = 0.28f * k, out = 0.12f * k;
        box(vc, pose, -hx - out, cy - hy, -hz - out, hx + out, cy - hy + lip * 2f, hz + out, look.goldEdge, light);
        box(vc, pose, -hx - out, cy + hy - lip * 2f, -hz - out, hx + out, cy + hy, hz + out, look.goldEdge, light);
        // gesper: pelat emas timbul di depan, permata pirus di tengah
        float bx = 1.5f * k, by = 1.35f * k, front = -hz - out;
        box(vc, pose, -bx, cy - by, front - 0.45f * k, bx, cy + by, front, look.goldEdge, light);
        box(vc, pose, -bx + 0.3f * k, cy - by + 0.3f * k, front - 0.55f * k, bx - 0.3f * k, cy + by - 0.3f * k, front - 0.45f * k,
                look.goldShade, light);
        box(vc, pose, -0.55f * k, cy - 0.55f * k, front - 0.85f * k, 0.55f * k, cy + 0.55f * k, front - 0.5f * k, look.gem,
                LightTexture.FULL_BRIGHT);
    }

    /** Balok berwarna (6 sisi, normal tiap sisi; cahaya dunia + bayangan dari normalnya). */
    private static void box(VertexConsumer vc, PoseStack.Pose pose, float x0, float y0, float z0, float x1, float y1, float z1,
                            int[] c, int light) {
        // depan (-z) & belakang (+z)
        quad(vc, pose, c, light, 0f, 0f, -1f, x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0);
        quad(vc, pose, c, light, 0f, 0f, 1f, x1, y0, z1, x0, y0, z1, x0, y1, z1, x1, y1, z1);
        // kiri (-x) & kanan (+x)
        quad(vc, pose, c, light, -1f, 0f, 0f, x0, y0, z1, x0, y0, z0, x0, y1, z0, x0, y1, z1);
        quad(vc, pose, c, light, 1f, 0f, 0f, x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0);
        // atas (-y) & bawah (+y)
        quad(vc, pose, c, light, 0f, -1f, 0f, x0, y0, z1, x1, y0, z1, x1, y0, z0, x0, y0, z0);
        quad(vc, pose, c, light, 0f, 1f, 0f, x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1);
    }

    private static void quad(VertexConsumer vc, PoseStack.Pose pose, int[] c, int light, float nx, float ny, float nz,
                             float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz) {
        vertex(vc, pose, c, light, nx, ny, nz, ax, ay, az);
        vertex(vc, pose, c, light, nx, ny, nz, bx, by, bz);
        vertex(vc, pose, c, light, nx, ny, nz, cx, cy, cz);
        vertex(vc, pose, c, light, nx, ny, nz, dx, dy, dz);
    }

    private static void vertex(VertexConsumer vc, PoseStack.Pose pose, int[] c, int light, float nx, float ny, float nz,
                               float x, float y, float z) {
        vc.addVertex(pose, x, y, z).setColor(c[0], c[1], c[2], 255).setUv(0.5f, 0.5f).setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(light).setNormal(pose, nx, ny, nz);
    }
}
