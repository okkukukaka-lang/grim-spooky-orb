package com.shazammod.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.client.fx.LintangFx;

import net.minecraft.client.model.WolfModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.animal.Wolf;

/**
 * 0.36 Jubah merah kecil anjing super (serigala jinak milik Lintang yang sedang dalam Mode Surya, lihat LintangDog).
 * Diikat di leher, menutupi punggung, ujungnya menjuntai di belakang saat diam dan berkibar lurus ke belakang saat lari
 * kencang atau terbang. Warnanya sama dengan jubah Lintang (FormLook.LINTANG). Nggak digambar saat duduk atau masih anak.
 *
 * Koordinat dalam piksel model serigala (dibagi 16 saat digambar): sumbu y ke bawah, depan = -z. Punggung (mane) di
 * y 10 untuk z -6..0, badan di y 11 untuk z 0..9 (lihat WolfModel saat berdiri).
 */
public class SuperDogCapeLayer extends RenderLayer<Wolf, WolfModel<Wolf>> {
    private static final int ROWS = 12;
    private static final float LENGTH = 15.5f;      // panjang jubah (piksel)
    private static final float BACK = 11f;          // bagian yang menutupi punggung
    private static final float NECK_Z = -3.5f;
    private static final float HALF_MANE = 4.4f;    // setengah lebar di atas surai (surai serigala selebar 8 piksel)
    private static final float HALF_BODY = 3.6f;    // setengah lebar di atas badan (6 piksel)
    private static final float HALF_FLARE = 0.9f;   // tambahan setengah lebar di ujung
    private static final float DROP = 2.6f;         // sisi jubah menjuntai menutupi pinggang (kelihatan dari samping)

    public SuperDogCapeLayer(RenderLayerParent<Wolf, WolfModel<Wolf>> parent) {
        super(parent);
    }

    private static float halfWidth(float z) {
        if (z < 0f) {
            return HALF_MANE;
        }
        return z < 1.5f ? Mth.lerp(z / 1.5f, HALF_MANE, HALF_BODY) : HALF_BODY;
    }

    private static float backY(float z) {
        if (z < 0f) {
            return 9.55f;
        }
        return z < 1.5f ? Mth.lerp(z / 1.5f, 9.55f, 10.45f) : 10.45f;
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, Wolf wolf, float limbSwing,
                       float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if (wolf.isInSittingPose() || !LintangFx.superDog(wolf)) {
            return;
        }
        double mx = wolf.getX() - wolf.xo, mz = wolf.getZ() - wolf.zo, my = wolf.getY() - wolf.yo;
        float speed = (float) Math.sqrt(mx * mx + mz * mz + my * my * 0.5);
        boolean airborne = !wolf.onGround() && speed > 0.15f;
        float k = airborne ? 1f : Mth.clamp(speed / 0.35f, 0f, 1f);   // 0 = diam, 1 = melesat / terbang
        float t = ageInTicks;

        float[] py = new float[ROWS + 1], pz = new float[ROWS + 1], hw = new float[ROWS + 1], drop = new float[ROWS + 1];
        float[] ny = new float[ROWS + 1], nz = new float[ROWS + 1];
        float freeY = 0f, freeZ = 0f;
        for (int i = 0; i <= ROWS; i++) {
            float s = i / (float) ROWS;
            float l = s * LENGTH;
            if (l <= BACK) {
                float z = NECK_Z + l;
                hw[i] = halfWidth(z);
                drop[i] = DROP * (1f - 0.65f * k) * Mth.clamp(l / 1.5f, 0.35f, 1f);   // makin melesat makin mendatar
                float lift = k * (l / BACK) * (1.6f + 0.5f * Mth.sin(t * 0.7f - l * 0.5f));   // menggembung saat melesat
                py[i] = backY(z) - lift;
                pz[i] = z;
                freeY = py[i];
                freeZ = pz[i];
            } else {
                // ujung yang bebas: menjuntai (diam) sampai berkibar mendatar ke belakang (melesat/terbang)
                float seg = LENGTH / ROWS;
                float hang = Mth.lerp(k, 50f, 6f);   // diam: rebah di atas ekor; melesat: lurus ke belakang
                float flutter = Mth.sin(t * (0.45f + 0.35f * k) - l * 0.65f) * (5f + 11f * k);
                float angle = (hang + flutter) * Mth.DEG_TO_RAD;
                freeZ += Mth.cos(angle) * seg;
                freeY += Mth.sin(angle) * seg;   // y ke bawah: sudut positif = menjuntai ke bawah
                py[i] = freeY;
                pz[i] = freeZ;
                hw[i] = HALF_BODY + HALF_FLARE * (l - BACK) / (LENGTH - BACK);
                drop[i] = Mth.lerp((l - BACK) / (LENGTH - BACK), DROP * (1f - 0.65f * k), 0.6f);
            }
        }
        for (int i = 0; i <= ROWS; i++) {   // normal tegak lurus arah kain (di bidang y-z)
            int a = Math.max(0, i - 1), b = Math.min(ROWS, i + 1);
            float dy = py[b] - py[a], dz = pz[b] - pz[a];
            float len = Mth.sqrt(dy * dy + dz * dz);
            if (len < 1.0E-4f) {
                ny[i] = -1f;
                nz[i] = 0f;
            } else {
                ny[i] = -dz / len;
                nz[i] = dy / len;
            }
        }

        int rgb = FormLook.LINTANG.cloth;
        int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, bl = rgb & 255;
        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(CapeDecor.WHITE));
        PoseStack.Pose pose = poseStack.last();
        float u = 1f / 16f;
        for (int i = 0; i < ROWS; i++) {
            int j = i + 1;
            float wave = k * 0.35f;   // sedikit bergelombang ke samping saat berkibar
            float sx0 = Mth.sin(t * 0.9f - i * 0.8f) * wave, sx1 = Mth.sin(t * 0.9f - j * 0.8f) * wave;
            // atas (punggung)
            vertex(vc, pose, (-hw[i] + sx0) * u, py[i] * u, pz[i] * u, 0f, ny[i], nz[i], r, g, bl, packedLight);
            vertex(vc, pose, (hw[i] + sx0) * u, py[i] * u, pz[i] * u, 0f, ny[i], nz[i], r, g, bl, packedLight);
            vertex(vc, pose, (hw[j] + sx1) * u, py[j] * u, pz[j] * u, 0f, ny[j], nz[j], r, g, bl, packedLight);
            vertex(vc, pose, (-hw[j] + sx1) * u, py[j] * u, pz[j] * u, 0f, ny[j], nz[j], r, g, bl, packedLight);
            // dua sisi yang menjuntai menutupi pinggang (sedikit lebih gelap: bayangan lipatan)
            int dr = r * 4 / 5, dg = g * 4 / 5, db = bl * 4 / 5;
            for (int side = -1; side <= 1; side += 2) {
                float x0 = side * hw[i] + sx0, x1 = side * hw[j] + sx1;
                vertex(vc, pose, x0 * u, py[i] * u, pz[i] * u, side, 0f, 0f, dr, dg, db, packedLight);
                vertex(vc, pose, (x0 + side * 0.25f) * u, (py[i] + drop[i]) * u, pz[i] * u, side, 0f, 0f, dr, dg, db, packedLight);
                vertex(vc, pose, (x1 + side * 0.25f) * u, (py[j] + drop[j]) * u, pz[j] * u, side, 0f, 0f, dr, dg, db, packedLight);
                vertex(vc, pose, x1 * u, py[j] * u, pz[j] * u, side, 0f, 0f, dr, dg, db, packedLight);
            }
        }
    }

    private static void vertex(VertexConsumer vc, PoseStack.Pose pose, float x, float y, float z, float nx, float ny, float nz,
                               int r, int g, int b, int light) {
        vc.addVertex(pose, x, y, z).setColor(r, g, b, 255).setUv(0.5f, 0.5f).setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(light).setNormal(pose, nx, ny, nz);
    }
}
