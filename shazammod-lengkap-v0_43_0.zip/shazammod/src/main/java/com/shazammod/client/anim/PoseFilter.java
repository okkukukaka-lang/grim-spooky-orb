package com.shazammod.client.anim;

import java.util.HashMap;
import java.util.Map;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;

/**
 * 0.34 Penghalus gerak Lintang & Sabbac. Pose akhir model (sesudah semua lapisan animasi: bawaan, ShazamPoses, klip
 * skill, LintangBody) diikuti pegas teredam per bagian tubuh yang dihitung TIAP FRAME (bukan tiap tick):
 * - perpindahan antar-animasi, sentakan keyframe, dan perubahan pose mendadak jadi mulus di FPS berapa pun;
 * - lengan & kaki mengikuti cepat (jedanya ±1 tick, pukulan tetap kena di saatnya), kepala sedikit lebih lambat, jadi
 *   ada gerak susulan alami (overlapping action) dan sedikit kebablasan seperti otot sungguhan.
 * Nggak dipakai untuk tangan orang pertama, dan otomatis lepas saat tidur, naik kendaraan, elytra, atau berenang.
 */
public final class PoseFilter {
    private PoseFilter() {}

    // ======= Angka yang gampang diutak-atik =======
    /** false = matikan penghalus (pose persis seperti animasi aslinya). */
    public static final boolean ENABLED = true;
    /** Kecepatan pegas (rad/tick) per bagian: makin besar makin cepat mengikuti pose asli (jeda kira-kira 2/angka tick). */
    private static final float HEAD = 1.8f, BODY = 2.4f, ARM = 2.8f, LEG = 2.4f;
    /** Redaman: 1 = tanpa kebablasan, makin kecil makin memantul. */
    private static final float DAMPING = 0.8f;
    /** Langkah integrasi paling besar (tick), supaya stabil di FPS rendah. */
    private static final float MAX_STEP = 0.2f;
    /** Pivot bergeser lebih dari ini (piksel model) dalam satu frame = pose diganti total: langsung pindah. */
    private static final float SNAP_PIVOT = 6f;

    private static final float[] OMEGA = {HEAD, BODY, ARM, ARM, LEG, LEG};
    private static final int PARTS = 6, CH = 6;   // per bagian: xRot, yRot, zRot, x, y, z

    private static final class State {
        final float[] pos = new float[PARTS * CH];
        final float[] vel = new float[PARTS * CH];
        final float[] raw = new float[PARTS * CH];   // pose asli (sasaran) terakhir
        float last = Float.NaN;
    }

    private static final Map<Integer, State> STATES = new HashMap<>();

    /**
     * true = entitas dunia sedang digambar (dari awal frame sampai tahap AFTER_ENTITIES). Model yang digambar di luar
     * itu (boneka di layar inventaris yang kepalanya mengikuti tetikus, pratinjau, dll.) dibiarkan apa adanya, supaya
     * pegasnya nggak tercampur dua pose yang berbeda.
     */
    private static boolean inLevel = true;

    /** Dipanggil di awal tiap frame (RenderFrameEvent.Pre). */
    public static void frameStart() {
        inLevel = true;
    }

    /** Dipanggil di tahap AFTER_ENTITIES (semua entitas dunia sudah digambar). */
    public static void entitiesDone() {
        inLevel = false;
    }

    private static ModelPart[] parts(HumanoidModel<?> m) {
        return new ModelPart[] {m.head, m.body, m.rightArm, m.leftArm, m.rightLeg, m.leftLeg};
    }

    public static void forget(int id) {
        STATES.remove(id);
    }

    /** Dipanggil paling akhir dari LintangBody.apply (cuma untuk Lintang & Sabbac yang sedang berwujud juara). */
    public static void apply(HumanoidModel<?> model, AbstractClientPlayer p, float ageInTicks) {
        if (!ENABLED || !inLevel || ageInTicks <= 0.0001f) {
            return;   // tangan orang pertama, boneka inventaris, dan sejenisnya: biarkan apa adanya
        }
        int id = p.getId();
        if (p.isSleeping() || p.isPassenger() || p.isFallFlying() || p.isVisuallySwimming() || p.isAutoSpinAttack()) {
            STATES.remove(id);
            return;
        }
        State s = STATES.get(id);
        ModelPart[] parts = parts(model);
        if (s == null || Float.isNaN(s.last)) {
            if (STATES.size() > 64) {
                STATES.clear();
            }
            s = new State();
            STATES.put(id, s);
            load(s, parts);
            s.last = ageInTicks;
            return;
        }
        float dt = ageInTicks - s.last;
        if (dt > 3f) {   // lama nggak digambar (di luar layar, baru masuk lagi): mulai dari pose sekarang
            load(s, parts);
            s.last = ageInTicks;
            return;
        }
        if (dt > 1.0E-4f) {
            integrate(s, parts, dt);
            s.last = ageInTicks;
        } else if (!same(s, parts)) {
            // gambar kedua di frame yang sama dengan pose lain (misalnya boneka di layar inventaris yang kepalanya
            // mengikuti tetikus): biarkan pose aslinya. Pose yang sama (game dijeda) tetap memakai hasil terakhir.
            return;
        }
        for (int k = 0; k < PARTS; k++) {
            int o = k * CH;
            ModelPart part = parts[k];
            part.xRot = s.pos[o];
            part.yRot = s.pos[o + 1];
            part.zRot = s.pos[o + 2];
            part.x = s.pos[o + 3];
            part.y = s.pos[o + 4];
            part.z = s.pos[o + 5];
        }
        model.hat.copyFrom(model.head);
    }

    private static void load(State s, ModelPart[] parts) {
        for (int k = 0; k < PARTS; k++) {
            int o = k * CH;
            ModelPart part = parts[k];
            s.pos[o] = part.xRot;
            s.pos[o + 1] = part.yRot;
            s.pos[o + 2] = part.zRot;
            s.pos[o + 3] = part.x;
            s.pos[o + 4] = part.y;
            s.pos[o + 5] = part.z;
        }
        System.arraycopy(s.pos, 0, s.raw, 0, s.pos.length);
        java.util.Arrays.fill(s.vel, 0f);
    }

    /** Pose asli sekarang sama dengan sasaran terakhir? */
    private static boolean same(State s, ModelPart[] parts) {
        for (int k = 0; k < PARTS; k++) {
            int o = k * CH;
            ModelPart part = parts[k];
            if (Math.abs(part.xRot - s.raw[o]) > 1.0E-4f || Math.abs(part.yRot - s.raw[o + 1]) > 1.0E-4f
                    || Math.abs(part.zRot - s.raw[o + 2]) > 1.0E-4f || Math.abs(part.x - s.raw[o + 3]) > 1.0E-3f
                    || Math.abs(part.y - s.raw[o + 4]) > 1.0E-3f || Math.abs(part.z - s.raw[o + 5]) > 1.0E-3f) {
                return false;
            }
        }
        return true;
    }

    private static void integrate(State s, ModelPart[] parts, float dt) {
        int steps = Math.max(1, (int) Math.ceil(dt / MAX_STEP));
        float h = dt / steps;
        for (int k = 0; k < PARTS; k++) {
            int o = k * CH;
            ModelPart part = parts[k];
            float w = OMEGA[k];
            float kk = w * w, cc = 2f * DAMPING * w;
            float[] target = {part.xRot, part.yRot, part.zRot, part.x, part.y, part.z};
            System.arraycopy(target, 0, s.raw, o, CH);
            for (int c = 0; c < CH; c++) {
                int i = o + c;
                float tgt = target[c];
                if (c < 3) {   // sudut: kejar lewat jalur terpendek (179° -> -179° bukan berputar satu lingkaran)
                    tgt = s.pos[i] + Mth.wrapDegrees((tgt - s.pos[i]) * Mth.RAD_TO_DEG) * Mth.DEG_TO_RAD;
                } else if (Math.abs(tgt - s.pos[i]) > SNAP_PIVOT) {
                    s.pos[i] = tgt;
                    s.vel[i] = 0f;
                    continue;
                }
                float x = s.pos[i], v = s.vel[i];
                for (int n = 0; n < steps; n++) {
                    v += (kk * (tgt - x) - cc * v) * h;
                    x += v * h;
                }
                s.pos[i] = x;
                s.vel[i] = v;
            }
        }
    }
}
