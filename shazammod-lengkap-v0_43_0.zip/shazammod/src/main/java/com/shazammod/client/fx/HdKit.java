package com.shazammod.client.fx;

import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.Vec3;

/**
 * 0.34 Pemancar butiran HD (api, kristal, gores cahaya, abu) dan bentuk-bentuk api yang dipakai LintangHd & SabbacHd.
 * Jumlah butiran di sini adalah angka dasar: Vfx.count() mengalikannya dengan kepadatan & penguat juaranya.
 */
final class HdKit {
    private HdKit() {}

    static final Vec3 UP = new Vec3(0, 1, 0);

    // ======= Angka yang gampang diutak-atik =======
    /** Pengali jumlah butiran efek HD (1 = normal). Turunkan kalau FPS berat. */
    static final float AMOUNT = 1.0f;

    static int n(double base) {
        return Vfx.count(base * AMOUNT);
    }

    static boolean firstPerson(AbstractClientPlayer p) {
        Minecraft mc = Minecraft.getInstance();
        return p == mc.player && mc.options.getCameraType().isFirstPerson();
    }

    static ClientLevel level(AbstractClientPlayer p) {
        return (ClientLevel) p.level();
    }

    static Vec3 chest(AbstractClientPlayer p) {
        return new Vec3(p.getX(), p.getY() + p.getBbHeight() * 0.68, p.getZ());
    }

    static Vec3 feet(AbstractClientPlayer p) {
        return new Vec3(p.getX(), p.getY() + 0.05, p.getZ());
    }

    static Vec3 head(AbstractClientPlayer p) {
        return new Vec3(p.getX(), p.getY() + p.getBbHeight() * 0.92, p.getZ());
    }

    static Lightning.Anchor chestAnchor(AbstractClientPlayer p) {
        return pt -> p.isRemoved() ? null : p.getPosition(pt).add(0, p.getBbHeight() * 0.68, 0);
    }

    static Lightning.Anchor feetAnchor(AbstractClientPlayer p) {
        return pt -> p.isRemoved() ? null : p.getPosition(pt).add(0, 0.05, 0);
    }

    static Vec3 norm(Vec3 v) {
        double l = v.length();
        return l < 1.0E-6 ? UP : v.scale(1.0 / l);
    }

    static Vec3 flat(Vec3 v) {
        return norm(new Vec3(v.x, 0, v.z));
    }

    /** Arah acak dalam kerucut di sekitar dir (spread = setengah lebar, kira-kira radian). */
    static Vec3 jitter(RandomSource r, Vec3 dir, double spread) {
        Vec3 d = ShazamFx.randomDir(r);
        return norm(dir.add(d.scale(spread)));
    }

    /** Titik tanah di bawah p (atau p kalau nggak ketemu). */
    static Vec3 groundAt(ClientLevel level, AbstractClientPlayer viewer, Vec3 p) {
        BlockHitResult h = level.clip(new ClipContext(p.add(0, 1.0, 0), p.add(0, -4.0, 0), ClipContext.Block.COLLIDER,
                ClipContext.Fluid.ANY, viewer));
        return h.getType() == HitResult.Type.MISS ? p : h.getLocation().add(0, 0.03, 0);
    }

    /** Titik pertama yang kena sinar dari a searah dir sejauh range (blok), atau ujungnya. */
    static Vec3 rayEnd(ClientLevel level, AbstractClientPlayer viewer, Vec3 a, Vec3 dir, double range) {
        BlockHitResult h = level.clip(new ClipContext(a, a.add(dir.scale(range)), ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, viewer));
        return h.getType() == HitResult.Type.MISS ? a.add(dir.scale(range)) : h.getLocation();
    }

    // ------------------------------------------------------------------ api

    /** Lidah api naik dari sebuah area (lingkaran jari-jari spread). */
    static void flames(Vec3 at, double base, double spread, double up, int rgb, float size, int life) {
        RandomSource r = Vfx.random();
        for (int i = 0, n = n(base); i < n; i++) {
            double a = r.nextDouble() * Math.PI * 2.0, rr = spread * Math.sqrt(r.nextDouble());
            Vfx.flame(at.x + Math.cos(a) * rr, at.y + r.nextDouble() * 0.15, at.z + Math.sin(a) * rr,
                    (r.nextDouble() - 0.5) * 0.03, up * (0.6 + r.nextDouble() * 0.7), (r.nextDouble() - 0.5) * 0.03, rgb,
                    size * (0.7f + r.nextFloat() * 0.6f), life + r.nextInt(Math.max(1, life / 2)));
        }
    }

    /** Ledakan api ke segala arah (sedikit condong ke atas). */
    static void flameBurst(Vec3 at, double base, double speed, int rgb, float size, int life) {
        RandomSource r = Vfx.random();
        for (int i = 0, n = n(base); i < n; i++) {
            Vec3 d = ShazamFx.randomDir(r);
            double s = speed * (0.4 + r.nextDouble() * 0.8);
            Vfx.flame(at.x + d.x * 0.2, at.y + d.y * 0.2, at.z + d.z * 0.2, d.x * s, Math.abs(d.y) * s * 0.7 + 0.02, d.z * s, rgb,
                    size * (0.7f + r.nextFloat() * 0.6f), life + r.nextInt(Math.max(1, life / 2)));
        }
    }

    /** Semburan api searah dir (kerucut selebar spread), dari titik from. */
    static void flameJet(Vec3 from, Vec3 dir, double base, double speed, double spread, int rgb, float size, int life) {
        RandomSource r = Vfx.random();
        for (int i = 0, n = n(base); i < n; i++) {
            Vec3 d = jitter(r, dir, spread);
            double s = speed * (0.7 + r.nextDouble() * 0.6);
            Vfx.flame(from.x, from.y, from.z, d.x * s, d.y * s, d.z * s, rgb, size * (0.7f + r.nextFloat() * 0.6f),
                    life + r.nextInt(Math.max(1, life / 3)));
        }
    }

    /** Cincin api di tanah (mengikuti peta tanah kalau ada). */
    static void flameRing(Vec3 center, double radius, double base, int rgb, float size, int life, Ground.Map ground) {
        RandomSource r = Vfx.random();
        for (int i = 0, n = n(base); i < n; i++) {
            double a = r.nextDouble() * Math.PI * 2.0, rr = radius * (0.92 + r.nextDouble() * 0.16);
            double h = ground == null ? 0.0 : ground.at(a, rr);
            Vfx.flame(center.x + Math.cos(a) * rr, center.y + h, center.z + Math.sin(a) * rr, Math.cos(a) * 0.02, 0.05 + r.nextDouble() * 0.05,
                    Math.sin(a) * 0.02, rgb, size * (0.7f + r.nextFloat() * 0.6f), life + r.nextInt(Math.max(1, life / 2)));
        }
    }

    /** Gelombang api: cincin api yang melebar di tanah selama ticks tick (dir != null: cuma kipas ±fan radian ke arah itu). */
    static void fireWave(ClientLevel level, Vec3 center, double radius, int ticks, int rgb, float size, Vec3 dir, double fan) {
        Ground.Map g = ShazamFx.ground(level, center, radius + 1.0);
        Vec3 c = g == null ? center : g.center(center);
        double base = dir == null ? 0.0 : Math.atan2(dir.z, dir.x);
        ShazamFx.schedule(0, ticks, (lvl, t) -> {
            double k = 1.0 - Math.pow(1.0 - (t + 1) / (double) ticks, 2.0);
            double front = radius * k;
            RandomSource r = lvl.random;
            int n = n(2.0 + front * 1.4);
            for (int i = 0; i < n; i++) {
                double a = dir == null ? r.nextDouble() * Math.PI * 2.0 : base + (r.nextDouble() * 2.0 - 1.0) * fan;
                double rr = front * (0.9 + r.nextDouble() * 0.15);
                double h = g == null ? 0.0 : g.at(a, rr);
                Vfx.flame(c.x + Math.cos(a) * rr, c.y + h, c.z + Math.sin(a) * rr, Math.cos(a) * 0.05, 0.06 + r.nextDouble() * 0.06,
                        Math.sin(a) * 0.05, rgb, size * (1.15f - 0.5f * (float) k) * (0.7f + r.nextFloat() * 0.6f), 12 + r.nextInt(8));
            }
        });
    }

    /** Tiang api (geyser) yang menyembur selama ticks tick dari sebuah titik (bisa ikut entity lewat anchor). */
    static void flameColumn(Lightning.Anchor base, double height, double radius, int ticks, int rgb, float size) {
        ShazamFx.schedule(0, ticks, (lvl, t) -> {
            Vec3 b = base.at(1f);
            if (b == null) {
                return;
            }
            RandomSource r = lvl.random;
            float k = (float) Math.sin(Math.PI * Math.min(1.0, (t + 1) / (double) ticks)) * 0.6f + 0.4f;
            double v = 0.12 + height * 0.022;
            for (int i = 0, n = n(3.0 * k + radius); i < n; i++) {
                double a = r.nextDouble() * Math.PI * 2.0, rr = radius * Math.sqrt(r.nextDouble());
                Vfx.flame(b.x + Math.cos(a) * rr, b.y + r.nextDouble() * 0.3, b.z + Math.sin(a) * rr, Math.cos(a) * 0.015,
                        v * (0.7 + r.nextDouble() * 0.6), Math.sin(a) * 0.015, rgb, size * k * (0.7f + r.nextFloat() * 0.7f),
                        (int) (10 + height * 1.6) + r.nextInt(6));
            }
        });
    }

    /**
     * Api yang naik berpilin di dinding tornado (pasangan Hd.Vortex dengan r0/r1/height/spin yang sama), selama ticks:
     * lidah-lidah api ikut berputar lalu tertinggal, jadi tornadonya terlihat terbuat dari api.
     */
    static void flameSpiral(Lightning.Anchor base, double r0, double r1, double height, float spin, int ticks, int rgb, float size) {
        ShazamFx.schedule(0, ticks, (lvl, t) -> {
            Vec3 b = base.at(1f);
            if (b == null) {
                return;
            }
            RandomSource r = lvl.random;
            float k = Math.min(1f, (t + 1) / 6f) * Math.min(1f, (ticks - t) / 8f);
            for (int i = 0, n = n(4.0 * k); i < n; i++) {
                double v = r.nextDouble();
                double rad = (r0 + (r1 - r0) * Math.pow(v, 1.15)) * (0.85 + r.nextDouble() * 0.25);
                double a = r.nextDouble() * Math.PI * 2.0, tang = spin * rad * 0.8;
                Vfx.flame(b.x + Math.cos(a) * rad, b.y + v * height, b.z + Math.sin(a) * rad, -Math.sin(a) * tang,
                        0.06 + r.nextDouble() * 0.05, Math.cos(a) * tang, rgb, size * (0.6f + r.nextFloat() * 0.6f) * (float) (1.0 - v * 0.35),
                        9 + r.nextInt(6));
            }
        });
    }

    // ------------------------------------------------------------------ kristal, gores cahaya, abu

    static void shards(Vec3 at, double base, double speed, int rgb, float size, int life, double floorY) {
        RandomSource r = Vfx.random();
        for (int i = 0, n = n(base); i < n; i++) {
            Vec3 d = ShazamFx.randomDir(r);
            double s = speed * (0.4 + r.nextDouble() * 0.8);
            Vfx.shard(at.x, at.y, at.z, d.x * s, d.y * s + speed * 0.3, d.z * s, rgb, size * (0.6f + r.nextFloat() * 0.8f),
                    life + r.nextInt(Math.max(1, life / 2)), floorY);
        }
    }

    /** Kristal searah dir (kerucut), misalnya napas beku. */
    static void shardJet(Vec3 from, Vec3 dir, double base, double speed, double spread, int rgb, float size, int life) {
        RandomSource r = Vfx.random();
        for (int i = 0, n = n(base); i < n; i++) {
            Vec3 d = jitter(r, dir, spread);
            double s = speed * (0.6 + r.nextDouble() * 0.7);
            Vfx.shard(from.x, from.y, from.z, d.x * s, d.y * s, d.z * s, rgb, size * (0.6f + r.nextFloat() * 0.8f),
                    life + r.nextInt(Math.max(1, life / 2)), Double.NaN);
        }
    }

    /** Gores cahaya memancar dari sebuah titik. */
    static void streaks(Vec3 at, double base, double speed, int rgb, float size, int life) {
        RandomSource r = Vfx.random();
        for (int i = 0, n = n(base); i < n; i++) {
            Vec3 d = ShazamFx.randomDir(r);
            double s = speed * (0.5 + r.nextDouble() * 0.8);
            Vfx.streak(at.x + d.x * 0.3, at.y + d.y * 0.3, at.z + d.z * 0.3, d.x * s, d.y * s, d.z * s, rgb,
                    size * (0.7f + r.nextFloat() * 0.6f), life + r.nextInt(Math.max(1, life / 2)));
        }
    }

    /** Gores cahaya yang meluncur MASUK ke sebuah titik dari bola selebar radius (cahaya yang terserap). */
    static void streaksIn(Vec3 target, double base, double radius, int rgb, float size, int life) {
        RandomSource r = Vfx.random();
        for (int i = 0, n = n(base); i < n; i++) {
            Vec3 d = ShazamFx.randomDir(r);
            double rr = radius * (0.7 + r.nextDouble() * 0.5);
            double s = rr / life;
            Vfx.streak(target.x + d.x * rr, target.y + d.y * rr, target.z + d.z * rr, -d.x * s, -d.y * s, -d.z * s, rgb,
                    size * (0.7f + r.nextFloat() * 0.6f), life);
        }
    }

    /** Abu/arang yang naik (fall < 0) atau turun (fall > 0). */
    static void cinders(Vec3 at, double base, double spread, double up, int rgb, float size, int life, float fall) {
        RandomSource r = Vfx.random();
        for (int i = 0, n = n(base); i < n; i++) {
            double a = r.nextDouble() * Math.PI * 2.0, rr = spread * Math.sqrt(r.nextDouble());
            Vfx.cinder(at.x + Math.cos(a) * rr, at.y + r.nextDouble() * 0.5, at.z + Math.sin(a) * rr,
                    (r.nextDouble() - 0.5) * 0.04, up * (0.5 + r.nextDouble()), (r.nextDouble() - 0.5) * 0.04, rgb,
                    size * (0.6f + r.nextFloat() * 0.8f), life + r.nextInt(Math.max(1, life / 2)), fall);
        }
    }
}
