package com.shazammod.client.fx;

import static com.shazammod.client.fx.GodLook.anchorWorld;
import static com.shazammod.client.fx.GodLook.lighten;

import com.shazammod.ShazamSounds;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

/**
 * 0.30 Kedatangan enam iblis Sabbac saat ritual berubah (efek & suara di dunia, dipanggil ShazamSpirits) dan pernik
 * cahaya tiap iblis (dipanggil GodLook): ujung tanduk membara, obor Aym, rantai Belial, lalat Beelzebub, mulut api
 * Asmodeus, ujung sayap Crateis. Bentuk & gerak masuknya: DemonFigures & GodShow.
 */
final class DemonSpirits {
    private DemonSpirits() {}

    private static final Vec3 UP = new Vec3(0, 1, 0);

    static void entrance(ClientLevel level, AbstractClientPlayer caster, int god, int tau, int arrive, GodShow.State s,
                         Vec3 anchor, double fx, double fy, double fz, double[] focus, boolean seen) {
        RandomSource rnd = level.random;
        double sc = s.scale;
        double ax = anchor.x, ay = anchor.y, az = anchor.z;
        int aura = GodFigures.AURA[god];
        int life = GodShow.STRIKE - GodShow.start(god) + 20;
        switch (god) {
            case GodFigures.SATAN -> {
                if (tau == 0) {   // bumi retak membara, raja iblis menyeruak dari bawah
                    Ground.Map map = ShazamFx.ground(level, anchor, 3.0);
                    if (map != null && map.found) {
                        Vfx.add(new Ground.Cracks(map.center(anchor), map, 12, 1.6f * (float) sc, life + 40, life, SabbacFx.MAGMA,
                                rnd.nextLong()));
                        Vfx.add(new Fx.Scorch(map.center(anchor), 0.9 * sc, life + 40, life, map));
                        Vfx.add(new Fx.Wave(map.center(anchor), UP, 2.2 * sc, 0.3, aura, 12, 0.85f, 0.15f, map));
                    }
                    play(level, ax, ay, az, ShazamSounds.EARTH_CRACK.get(), 1.4f, ShazamSounds.tune(0.5f));
                    play(level, ax, ay, az, ShazamSounds.DREAD.get(), 1.0f, ShazamSounds.tune(0.55f));
                }
                if (tau < arrive) {
                    for (int k = 0; k < 3; k++) {
                        double a = rnd.nextDouble() * Math.PI * 2, rr = rnd.nextDouble() * 0.8 * sc;
                        Vfx.ember(ax + Math.cos(a) * rr, ay + 0.1, az + Math.sin(a) * rr, 0, 0.06 + rnd.nextDouble() * 0.05, 0,
                                0.1f, 18);
                    }
                    if (tau % 3 == 0) {
                        double a = rnd.nextDouble() * Math.PI * 2, rr = (0.5 + rnd.nextDouble() * 0.5) * sc;
                        fire(ax + Math.cos(a) * rr, ay, az + Math.sin(a) * rr, 0.9 * sc, 0.35 * sc, 10);
                    }
                }
                if (tau == arrive) {
                    Vfx.add(new Fx.Flash(new Vec3(ax, ay + 1.6 * sc, az), 3.0f, aura, 12, 0.9f));
                    ShazamFx.shakeAround(anchor, 0.7f, 24.0);
                    play(level, ax, ay, az, ShazamSounds.IMPACT.get(), 1.4f, ShazamSounds.tune(0.5f));
                }
            }
            case GodFigures.AYM -> {
                if (tau == 0) {   // cincin api neraka di kaki
                    Ground.Map map = ShazamFx.ground(level, anchor, 2.5);
                    Vfx.add(new Fx.Wave(anchor.add(0, 0.05, 0), UP, 1.7 * sc, 0.45, aura, 18, 0.9f, 0.25f, map));
                    play(level, ax, ay, az, ShazamSounds.FIRE_BLAST.get(), 1.2f, ShazamSounds.tune(0.5f));
                }
                if (tau < arrive) {   // pusaran api berpilin naik selagi tubuh obsidiannya terbakar muncul
                    for (int k = 0; k < 4; k++) {
                        double a = tau * 0.75 + k * Math.PI / 2;
                        double rr = (0.95 - tau * 0.045) * sc;
                        double y = ay + (0.1 + tau * 0.2 + k * 0.08) * sc;
                        Vfx.ember(ax + Math.cos(a) * rr, y, az + Math.sin(a) * rr, -Math.sin(a) * 0.08, 0.06, Math.cos(a) * 0.08,
                                0.12f, 18);
                        if (k % 2 == 0) {
                            Vfx.mote(ax + Math.cos(a) * rr, y, az + Math.sin(a) * rr, 0, 0.03, 0, SabbacFx.HELL_LIGHT, 0.22f, 12);
                        }
                    }
                }
                if (tau == arrive) {   // obor neraka menyala
                    Vec3 torch = seen ? new Vec3(focus[0], focus[1], focus[2]) : new Vec3(ax, ay + 2.2 * sc, az);
                    Vfx.add(new Fx.Flash(torch, 2.2f, SabbacFx.HELL_HOT, 10, 1f));
                    ShazamFx.ringOfSparks(level, torch, 24, aura, 0.4);
                    play(level, ax, ay, az, ShazamSounds.FIRE_BLAST.get(), 1.0f, ShazamSounds.tune(0.8f));
                }
            }
            case GodFigures.BELIAL -> {
                if (tau == 0) {
                    Ground.Map map = ShazamFx.ground(level, anchor, 2.5);
                    if (map != null && map.found) {
                        Vfx.add(new Ground.Cracks(map.center(anchor), map, 7, 1.1f * (float) sc, life + 30, life / 2, SabbacFx.MAGMA,
                                rnd.nextLong()));
                    }
                    play(level, ax, ay, az, ShazamSounds.DARK_HISS.get(), 1.2f, ShazamSounds.tune(0.6f));
                }
                if (tau >= 2 && tau < arrive && tau % 3 == 2) {   // rantai membara menyeruak dari tanah di sekelilingnya
                    double a = rnd.nextDouble() * Math.PI * 2, rr = (0.9 + rnd.nextDouble() * 0.5) * sc;
                    Vec3 base = new Vec3(ax + Math.cos(a) * rr, ay + 0.02, az + Math.sin(a) * rr);
                    Vec3 top = new Vec3(ax + Math.cos(a) * rr * 0.4, ay + (1.4 + rnd.nextDouble() * 0.8) * sc,
                            az + Math.sin(a) * rr * 0.4);
                    Vfx.add(new SabbacFx.Chain(Lightning.Anchor.fixed(base), Lightning.Anchor.fixed(top), 0.12, 4, 16));
                }
                if (tau == arrive) {
                    Vfx.add(new Fx.Flash(new Vec3(ax, ay + 1.4 * sc, az), 2.2f, aura, 10, 0.8f));
                    play(level, ax, ay, az, ShazamSounds.DEFLECT.get(), 1.2f, ShazamSounds.tune(0.5f));
                }
            }
            case GodFigures.BEELZEBUB -> {
                if (tau == 0) {
                    play(level, ax, ay, az, ShazamSounds.DARK_HISS.get(), 1.3f, ShazamSounds.tune(1.6f));   // dengung kawanan
                }
                if (tau < arrive) {   // kawanan lalat berpusar makin rapat ke badannya
                    double tight = 1.0 - tau / (double) arrive;
                    for (int k = 0; k < 6; k++) {
                        double a = tau * 1.1 + k * Math.PI * 2 / 6 + rnd.nextDouble() * 0.5;
                        double rr = (0.4 + 1.3 * tight) * sc;
                        double y = ay + rnd.nextDouble() * 2.0 * sc;
                        double tx = -Math.sin(a), tz = Math.cos(a);
                        Vfx.dust(ax + Math.cos(a) * rr, y, az + Math.sin(a) * rr, tx * 0.2 - Math.cos(a) * 0.04, 0.0,
                                tz * 0.2 - Math.sin(a) * 0.04, SabbacFx.FLY, 0.06f, 10 + rnd.nextInt(6));
                        if (k % 3 == 0) {
                            Vfx.mote(ax + Math.cos(a) * rr, y, az + Math.sin(a) * rr, tx * 0.1, 0.01, tz * 0.1, aura, 0.08f, 8);
                        }
                    }
                }
                if (tau == arrive) {
                    Vfx.add(new Fx.Flash(new Vec3(ax, ay + 1.3 * sc, az), 2.0f, aura, 10, 0.8f));
                    ShazamFx.ringOfSparks(level, new Vec3(ax, ay + 1.2 * sc, az), 20, aura, 0.35);
                }
            }
            case GodFigures.ASMODEUS -> {
                if (tau == 0) {   // tanah memanas: retakan & asap
                    Ground.Map map = ShazamFx.ground(level, anchor, 3.0);
                    if (map != null && map.found) {
                        Vfx.add(new Ground.Cracks(map.center(anchor), map, 10, 1.5f * (float) sc, life + 40, life, SabbacFx.MAGMA,
                                rnd.nextLong()));
                    }
                }
                if (tau < 4 && tau % 2 == 0) {
                    Vfx.smoke(ax + (rnd.nextDouble() - 0.5), ay + 0.2, az + (rnd.nextDouble() - 0.5), 0, 0.04, 0,
                            SabbacFx.ASH, 0.6f, 30);
                }
                if (tau == 4) {   // ledakan api: Asmodeus mendarat sambil meraung
                    Vfx.add(new Fx.Flash(new Vec3(ax, ay + 1.2 * sc, az), 3.6f, SabbacFx.HELL_HOT, 12, 1f));
                    Ground.Map map = ShazamFx.ground(level, anchor, 3.0);
                    Vfx.add(new Fx.Wave(anchor.add(0, 0.05, 0), UP, 3.0 * sc, 0.4, aura, 16, 0.9f, 0.15f, map));
                    for (int k = 0; k < 5; k++) {
                        double a = Math.PI * 2 * k / 5, rr = 0.6 * sc;
                        fire(ax + Math.cos(a) * rr, ay, az + Math.sin(a) * rr, 2.4 * sc, 0.6 * sc, 18);
                    }
                    ShazamFx.ringOfSparks(level, anchor.add(0, 0.5, 0), 30, aura, 0.5);
                    ShazamFx.shakeAround(anchor, 0.9f, 28.0);
                    play(level, ax, ay, az, ShazamSounds.FIRE_BLAST.get(), 1.4f, ShazamSounds.tune(0.5f));
                    play(level, ax, ay, az, ShazamSounds.ASMODEUS_ROAR.get(), 0.7f, ShazamSounds.tune(1.1f));
                }
            }
            default -> {   // CRATEIS
                if (tau == 0) {
                    play(level, caster.getX(), caster.getY(), caster.getZ(), ShazamSounds.WHOOSH.get(), 1.2f, ShazamSounds.tune(0.5f));
                }
                if (tau < arrive) {   // jejak api di belakangnya selagi menukik
                    for (int k = 0; k < 3; k++) {
                        Vfx.mote(fx + (rnd.nextDouble() - 0.5) * 0.7 * sc, fy + (0.8 + rnd.nextDouble() * 0.8) * sc,
                                fz + (rnd.nextDouble() - 0.5) * 0.7 * sc, 0, 0.02, 0, aura, 0.22f, 12);
                        Vfx.ember(fx, fy + 1.2 * sc, fz, (rnd.nextDouble() - 0.5) * 0.1, 0.02, (rnd.nextDouble() - 0.5) * 0.1,
                                0.08f, 14);
                    }
                }
                if (tau == arrive) {   // mendarat: hembusan sayap api
                    Ground.Map map = ShazamFx.ground(level, anchor, 3.0);
                    Vfx.add(new Fx.Wave(anchor.add(0, 0.05, 0), UP, 2.8 * sc, 0.4, aura, 14, 0.85f, 0.05f, map));
                    ShazamFx.dustPuffs(level, anchor, 0x3A3030, 12, 0.9, 0.16);
                    play(level, ax, ay, az, ShazamSounds.WHOOSH_HEAVY.get(), 1.0f, ShazamSounds.tune(0.6f));
                }
            }
        }
    }

    private static void fire(double x, double y, double z, double height, double width, int life) {
        Vfx.add(new SabbacFx.Fire(Lightning.Anchor.fixed(new Vec3(x, y + 0.02, z)), height, width, 3, life, 0.95f));
    }

    private static void play(ClientLevel level, double x, double y, double z, SoundEvent sound, float volume, float pitch) {
        level.playLocalSound(x, y, z, sound, SoundSource.PLAYERS, volume, ShazamFx.slowPitch(level, pitch), false);
    }

    // ------------------------------------------------------------------ pernik cahaya tiap iblis

    static void extras(int god, GodMesh m, GodShow.State s, double ox, double oy, double oz, double camX, double camY,
                       double camZ, float time, GodLook.Glows g, float vis, float boost) {
        int aura = GodFigures.AURA[god];
        int light = lighten(aura, 0.5);
        double sc = s.scale;
        double[] p = new double[3], q = new double[3];
        float flick = (float) (0.75 + 0.25 * Math.sin(time * 0.9 + god));
        switch (god) {
            case GodFigures.SATAN, GodFigures.ASMODEUS -> {
                for (int e = GodMesh.EXTRA; e <= GodMesh.EXTRA2; e++) {   // ujung tanduk membara
                    anchorWorld(m, s, ox, oy, oz, e, p);
                    g.glow(p[0], p[1], p[2], (float) (0.14 * sc), SabbacFx.HELL_LIGHT, 0.6f * vis * flick * boost);
                    g.line(p[0], p[1], p[2], p[0], p[1] + 0.18 * sc * flick, p[2], (float) (0.05 * sc), SabbacFx.HELL, 0.4f * vis);
                }
                if (god == GodFigures.ASMODEUS) {   // mulut yang meraung menyala seperti tungku
                    anchorWorld(m, s, ox, oy, oz, GodMesh.FOCUS, p);
                    g.glow(p[0], p[1], p[2], (float) (0.3 * sc), SabbacFx.HELL_HOT, 0.55f * vis * flick * boost);
                } else {   // panas di dada
                    anchorWorld(m, s, ox, oy, oz, GodMesh.CHEST, p);
                    g.glow(p[0], p[1], p[2], (float) (0.5 * sc), aura, 0.2f * vis * boost);
                }
            }
            case GodFigures.AYM -> {
                anchorWorld(m, s, ox, oy, oz, GodMesh.EXTRA, p);   // obor neraka
                g.glow(p[0], p[1], p[2], (float) (0.42 * sc), aura, 0.5f * vis * flick * boost);
                g.glow(p[0], p[1], p[2], (float) (0.14 * sc), SabbacFx.HELL_HOT, 0.9f * vis);
                for (int k = 0; k < 3; k++) {   // lidah api obor
                    double a = time * 0.4 + k * 2.1;
                    double tx = p[0] + Math.cos(a) * 0.05 * sc, ty = p[1] + (0.22 + 0.08 * Math.sin(time * 0.7 + k)) * sc;
                    double tz = p[2] + Math.sin(a) * 0.05 * sc;
                    g.line(p[0], p[1], p[2], tx, ty, tz, (float) (0.07 * sc), SabbacFx.HELL_LIGHT, 0.55f * vis);
                }
                anchorWorld(m, s, ox, oy, oz, GodMesh.EXTRA2, q);   // api kecil di telapak kiri
                g.glow(q[0], q[1], q[2], (float) (0.16 * sc), SabbacFx.HELL_LIGHT, 0.6f * vis * flick);
            }
            case GodFigures.BELIAL -> {
                anchorWorld(m, s, ox, oy, oz, GodMesh.EXTRA, p);   // rantai membara
                g.glow(p[0], p[1], p[2], (float) (0.3 * sc), aura, 0.35f * vis * flick * boost);
                anchorWorld(m, s, ox, oy, oz, GodMesh.FOCUS, q);
                g.glow(q[0], q[1], q[2], (float) (0.14 * sc), light, 0.55f * vis * flick);
                anchorWorld(m, s, ox, oy, oz, GodMesh.EXTRA2, p);
                g.glow(p[0], p[1], p[2], (float) (0.1 * sc), SabbacFx.HELL_LIGHT, 0.5f * vis * flick);
            }
            case GodFigures.BEELZEBUB -> {
                anchorWorld(m, s, ox, oy, oz, GodMesh.EXTRA, p);   // lalat-lalat api mengitari kepala
                for (int k = 0; k < 12; k++) {
                    double a = time * (0.25 + 0.04 * (k % 4)) + k * 0.52;
                    double rr = (0.32 + 0.12 * Math.sin(k * 1.7 + time * 0.1)) * sc;
                    double x = p[0] + Math.cos(a) * rr, y = p[1] + Math.sin(a * 1.7 + k) * 0.18 * sc, z = p[2] + Math.sin(a) * rr;
                    g.glow(x, y, z, (float) (0.035 * sc), light, 0.8f * vis);
                }
                anchorWorld(m, s, ox, oy, oz, GodMesh.FOCUS, q);
                g.glow(q[0], q[1], q[2], (float) (0.18 * sc), SabbacFx.HELL_LIGHT, 0.4f * vis * flick);
            }
            default -> {   // CRATEIS: ujung sayap api
                for (int e = GodMesh.EXTRA; e <= GodMesh.EXTRA2; e++) {
                    anchorWorld(m, s, ox, oy, oz, e, p);
                    g.glow(p[0], p[1], p[2], (float) (0.2 * sc), aura, 0.55f * vis * flick * boost);
                    g.line(p[0], p[1], p[2], p[0], p[1] - 0.35 * sc, p[2], (float) (0.06 * sc), SabbacFx.HELL, 0.3f * vis * flick);
                }
                anchorWorld(m, s, ox, oy, oz, GodMesh.FOCUS, q);
                g.glow(q[0], q[1], q[2], (float) (0.2 * sc), light, 0.45f * vis * flick);
            }
        }
    }
}
