package com.shazammod.client.vfx;

/**
 * Butiran efek dalam satu kolam (tanpa objek per butir, supaya ringan walau ribuan):
 * - MOTE: butiran cahaya lembut yang melayang dan berkedip;
 * - SPARK: percikan berbentuk garis yang memanjang searah gerak (seperti tertangkap kamera), jatuh dan memantul;
 * - EMBER: bara yang naik pelan sambil mendingin (putih-kuning -> jingga -> merah);
 * - GLINT: bintang kilau empat sudut yang berputar;
 * - DUST: kepulan debu yang mengembang dan memudar (tembus pandang biasa, bervolume);
 * - SMOKE: asap tebal yang naik, melambat, mengembang, dan berkelok terbawa udara.
 * - 0.34 FLAME: lidah api yang naik, berkelok, meruncing, dan mendingin (putih-kuning -> warna api -> merah gelap);
 * - 0.34 SHARD: kristal/serpihan berputar yang berkilau (es, obsidian);
 * - 0.34 CINDER: abu/arang melayang (tembus pandang biasa), menyala sebentar di awal lalu jadi abu;
 * - 0.34 STREAK: gores cahaya panjang & tipis (garis kecepatan, hujan foton).
 *
 * Butiran baru langsung dilangkahkan sekali saat dibuat tapi umurnya tetap 0, jadi sejak frame pertama ia sudah
 * bergerak dan masih seterang-terangnya (dulu umurnya langsung jadi 1 dan awal hidupnya hilang).
 */
final class Particles {
    static final int MOTE = 0, SPARK = 1, EMBER = 2, GLINT = 3, DUST = 4, SMOKE = 5, FLAME = 6, SHARD = 7, CINDER = 8,
            STREAK = 9;
    private static final int MAX = 6000;

    private final double[] x = new double[MAX], y = new double[MAX], z = new double[MAX];
    private final double[] ox = new double[MAX], oy = new double[MAX], oz = new double[MAX];
    private final double[] vx = new double[MAX], vy = new double[MAX], vz = new double[MAX];
    private final double[] floor = new double[MAX];
    private final float[] size = new float[MAX], gravity = new float[MAX], drag = new float[MAX], seed = new float[MAX];
    private final int[] age = new int[MAX], life = new int[MAX], color = new int[MAX], type = new int[MAX];
    private final int[] born = new int[MAX];
    private final boolean[] hd = new boolean[MAX];   // 0.34: dibuat dengan penguat (Lintang & Sabbac) -> digambar HD
    private int count;
    private int clock;
    private int pick = 0x2545F491;

    boolean isEmpty() {
        return count == 0;
    }

    void clear() {
        count = 0;
    }

    int spawn(int kind, double px, double py, double pz, double mx, double my, double mz, int rgb, float s, int ticks,
              float grav, float dragPerTick, double floorY, float rand) {
        int i = count < MAX ? count++ : victim();
        type[i] = kind;
        x[i] = px; y[i] = py; z[i] = pz;
        vx[i] = mx; vy[i] = my; vz[i] = mz;
        color[i] = rgb;
        size[i] = s;
        life[i] = Math.max(1, ticks);
        age[i] = 0;
        gravity[i] = grav;
        drag[i] = dragPerTick;
        floor[i] = floorY;
        seed[i] = rand;
        born[i] = clock;
        hd[i] = Vfx.boost() > 1.001f;
        step(i);
        return i;
    }

    /** Kolam penuh: ganti butiran yang paling dekat habis (dipilih dari beberapa contoh acak, supaya murah). */
    private int victim() {
        int best = 0;
        float most = -1f;
        for (int k = 0; k < 12; k++) {
            pick = pick * 1103515245 + 12345;
            int j = (pick >>> 1) % count;
            float p = age[j] / (float) life[j];
            if (p > most) {
                most = p;
                best = j;
            }
        }
        return best;
    }

    void tick() {
        int i = 0;
        while (i < count) {
            if (born[i] == clock) {   // lahir tick ini: sudah dilangkahkan saat dibuat
                i++;
                continue;
            }
            if (++age[i] >= life[i]) {
                remove(i);
                continue;
            }
            step(i);
            i++;
        }
    }

    /** Dipanggil di akhir tick efek, sesudah semua butiran tick ini dibuat. */
    void endTick() {
        clock++;
    }

    /** Satu langkah gerak (satu tick). */
    private void step(int i) {
        ox[i] = x[i]; oy[i] = y[i]; oz[i] = z[i];
        vy[i] -= gravity[i];
        float k = 1f - drag[i];
        vx[i] *= k; vy[i] *= k; vz[i] *= k;
        int kind = type[i];
        if (kind == EMBER) {   // bara: naik berkelok-kelok
            double a = age[i] * 0.35 + seed[i] * 20.0;
            vx[i] += Math.sin(a) * 0.004;
            vz[i] += Math.cos(a * 1.3) * 0.004;
        } else if (kind == SMOKE) {   // asap: berkelok pelan terbawa pusaran udara
            double a = age[i] * 0.12 + seed[i] * 40.0;
            vx[i] += Math.sin(a) * 0.0025;
            vz[i] += Math.cos(a * 1.4) * 0.0025;
        } else if (kind == FLAME) {   // api: menari terbawa udara panas yang naik
            double a = age[i] * 0.55 + seed[i] * 20.0;
            vx[i] += Math.sin(a) * 0.006;
            vz[i] += Math.cos(a * 1.3) * 0.006;
        } else if (kind == CINDER) {  // abu: melayang berayun pelan
            double a = age[i] * 0.17 + seed[i] * 30.0;
            vx[i] += Math.sin(a) * 0.003;
            vz[i] += Math.cos(a * 1.2) * 0.003;
        }
        x[i] += vx[i]; y[i] += vy[i]; z[i] += vz[i];
        if (!Double.isNaN(floor[i]) && y[i] < floor[i]) {   // memantul di tanah
            y[i] = floor[i];
            vy[i] = Math.abs(vy[i]) * 0.35;
            vx[i] *= 0.6;
            vz[i] *= 0.6;
        }
    }

    private void remove(int i) {
        int last = --count;
        if (i == last) {
            return;
        }
        type[i] = type[last];
        x[i] = x[last]; y[i] = y[last]; z[i] = z[last];
        ox[i] = ox[last]; oy[i] = oy[last]; oz[i] = oz[last];
        vx[i] = vx[last]; vy[i] = vy[last]; vz[i] = vz[last];
        floor[i] = floor[last];
        size[i] = size[last]; gravity[i] = gravity[last]; drag[i] = drag[last]; seed[i] = seed[last];
        age[i] = age[last]; life[i] = life[last]; color[i] = color[last]; born[i] = born[last];
        hd[i] = hd[last];
    }

    void renderGlow(Draw d) {
        float pt = d.partialTick;
        for (int i = 0; i < count; i++) {
            int kind = type[i];
            if (kind == DUST || kind == SMOKE) {
                continue;
            }
            float t = Math.min(1f, (age[i] + pt) / life[i]);
            if (kind == CINDER && t > 0.35f) {   // abu yang sudah dingin cuma di lapisan soft
                continue;
            }
            double px = ox[i] + (x[i] - ox[i]) * pt, py = oy[i] + (y[i] - oy[i]) * pt, pz = oz[i] + (z[i] - oz[i]) * pt;
            float fade = 1f - t;
            d.hd(hd[i]);
            switch (kind) {
                case MOTE -> {
                    float flicker = 0.75f + 0.25f * (float) Math.sin((age[i] + pt) * 0.9f + seed[i] * 40f);
                    float a = fade * fade * flicker;
                    d.glow(px, py, pz, size[i] * (0.7f + 0.45f * fade), color[i], a);
                    d.glow(px, py, pz, size[i] * 0.3f, 0xFFFFFF, a * 0.85f);
                }
                case SPARK -> {
                    // ekor searah gerak, seperti percikan yang tertangkap kamera: makin cepat makin panjang
                    double tx = px - vx[i] * 2.2, ty = py - vy[i] * 2.2, tz = pz - vz[i] * 2.2;
                    float a = fade;
                    d.line(tx, ty, tz, px, py, pz, size[i] * 0.5f, size[i] * 1.35f, color[i], 0f, a);
                    d.line(tx, ty, tz, px, py, pz, size[i] * 0.2f, size[i] * 0.5f, 0xFFFFFF, 0f, a);
                    d.glow(px, py, pz, size[i] * 1.7f, color[i], a * 0.4f);   // kepala yang membara
                }
                case EMBER -> {
                    int c = cool(t);
                    float a = fade * (0.8f + 0.2f * (float) Math.sin((age[i] + pt) * 1.7f + seed[i] * 31f));
                    d.glow(px, py, pz, size[i] * 1.15f, c, a);
                    d.glow(px, py, pz, size[i] * 0.38f, 0xFFF2C0, a * fade);
                }
                case GLINT -> {
                    float a = (float) Math.sin(Math.PI * t);
                    d.glint(px, py, pz, size[i] * (0.5f + 0.5f * a), seed[i] * 6.28f + (age[i] + pt) * 0.12f, color[i], a);
                }
                case FLAME -> flame(d, i, px, py, pz, t, pt);
                case SHARD -> shard(d, i, px, py, pz, t, pt);
                case CINDER -> {   // bara abu yang masih panas di awal hidupnya
                    float k = (0.35f - t) / 0.35f;
                    d.glow(px, py, pz, size[i] * 1.6f, 0xFF6A26, 0.55f * k * k);
                }
                case STREAK -> {
                    float a = Math.min(1f, (age[i] + pt) / 1.5f) * fade;
                    double tx = px - vx[i] * 6.0, ty = py - vy[i] * 6.0, tz = pz - vz[i] * 6.0;
                    d.line(tx, ty, tz, px, py, pz, size[i] * 0.15f, size[i] * 0.6f, color[i], 0f, a);
                    double hx = px - vx[i] * 2.5, hy = py - vy[i] * 2.5, hz = pz - vz[i] * 2.5;
                    d.line(hx, hy, hz, px, py, pz, size[i] * 0.06f, size[i] * 0.24f, 0xFFFFFF, 0f, a);
                }
                default -> { }
            }
        }
        d.hd(false);
    }

    // tulang lidah api (tempat kerja, supaya nggak bikin sampah memori tiap frame)
    private static final int FLAME_N = 6;
    private final float[] fp = new float[FLAME_N * 3], fw = new float[FLAME_N], fa = new float[FLAME_N];
    private final float[] cw = new float[FLAME_N], ca = new float[FLAME_N];

    /**
     * Lidah api berbentuk tetesan terbalik: pangkal bulat, paling gemuk di seperempat bawah, ujungnya runcing dan menari
     * berkelok (gelombang yang merambat dari pangkal ke ujung). Arahnya naik (udara panas), condong melawan gerak mendatar
     * (api yang tertiup / semburan), makin cepat makin panjang. Inti panasnya lebih pendek, dan ada pendar di pangkal.
     */
    private void flame(Draw d, int i, double px, double py, double pz, float t, float pt) {
        float age = this.age[i] + pt;
        float in = Math.min(1f, age / 2.5f);
        float flick = 0.78f + 0.22f * (float) Math.sin(age * 1.9f + seed[i] * 37f);
        float a = in * (float) Math.pow(1f - t, 1.15) * flick;
        if (a <= 0.01f) {
            return;
        }
        float s = size[i] * (0.75f + 0.5f * (float) Math.sin(Math.PI * Math.min(1f, t * 1.4f)));
        double hs = Math.sqrt(vx[i] * vx[i] + vz[i] * vz[i]);
        double dx = -vx[i] * 4.0, dy = 1.0 + Math.max(-0.5, vy[i] * 2.0), dz = -vz[i] * 4.0;
        double dl = Math.sqrt(dx * dx + dy * dy + dz * dz);
        dx /= dl; dy /= dl; dz /= dl;
        double len = s * (2.2 + 0.6 * Math.sin(age * 1.3 + seed[i] * 11.0)) * (1.0 + Math.min(2.0, hs * 5.0));
        double back = Math.sqrt(dx * dx + dz * dz);   // ekor yang tertinggal nggak boleh lebih jauh dari jarak tempuhnya
        if (back > 0.3) {                              // (semburan: api nggak muncul di belakang mulut)
            double travelled = Math.sqrt(hs * hs + vy[i] * vy[i]) * (age + 0.6) * 1.1;
            len = Math.min(len, Math.max(s * 1.2, travelled / back));
        }
        int outer = flameOuter(color[i], t), core = flameCore(color[i], t);
        double sway = s * 0.42;
        for (int k = 0; k < FLAME_N; k++) {
            double v = k / (double) (FLAME_N - 1);
            double wave = age * 0.95 + seed[i] * 23.0 - v * 3.2;
            double off = sway * Math.pow(v, 1.3);
            fp[k * 3] = (float) (px + dx * len * v + Math.sin(wave) * off);
            fp[k * 3 + 1] = (float) (py + dy * len * v);
            fp[k * 3 + 2] = (float) (pz + dz * len * v + Math.cos(wave * 0.87 + 1.3) * off);
            double prof = Math.pow(Math.sin(Math.PI * (0.12 + 0.88 * v)), 0.7) * (1.0 - 0.6 * v);
            fw[k] = (float) (s * 1.3 * prof);
            fa[k] = a * (v < 0.6 ? 0.85f : 0.85f * (1f - (float) (v - 0.6) / 0.4f * 0.8f));
            double cv = Math.min(1.0, v / 0.62);   // inti: lebih pendek, habis di 62% panjang
            cw[k] = (float) (s * 0.62 * Math.pow(Math.sin(Math.PI * (0.1 + 0.9 * cv)), 0.8) * (1.0 - 0.5 * cv));
            ca[k] = a * (float) Math.max(0.0, 1.0 - cv * cv);
        }
        d.glow(px + dx * len * 0.14, py + dy * len * 0.14, pz + dz * len * 0.14, s * 1.6f, outer, a * 0.3f);   // pangkal yang membara
        d.strip(fp, FLAME_N, fw, 1f, fa, 1f, outer);
        d.strip(fp, FLAME_N, cw, 1f, ca, 1f, core);
    }

    /** Kristal berputar: dua kerucut runcing (belah ketupat) + inti putih, sesekali berkilau. */
    private void shard(Draw d, int i, double px, double py, double pz, float t, float pt) {
        float age = this.age[i] + pt;
        float a = Math.min(1f, age / 2f) * (1f - t * t);
        if (a <= 0.01f) {
            return;
        }
        double spin = seed[i] * 40.0 + age * (0.25 + seed[i] * 0.35);
        double tilt = seed[i] * 17.0 + age * 0.19;
        double ax = Math.cos(spin) * Math.cos(tilt), ay = Math.sin(tilt), az = Math.sin(spin) * Math.cos(tilt);
        double len = size[i] * 1.6;
        float w = size[i] * 0.55f;
        int c = color[i];
        d.line(px - ax * len, py - ay * len, pz - az * len, px, py, pz, 0f, w, c, a * 0.55f, a);
        d.line(px, py, pz, px + ax * len * 0.7, py + ay * len * 0.7, pz + az * len * 0.7, w, 0f, c, a, a * 0.55f);
        d.line(px - ax * len * 0.6, py - ay * len * 0.6, pz - az * len * 0.6, px + ax * len * 0.45, py + ay * len * 0.45,
                pz + az * len * 0.45, w * 0.25f, w * 0.25f, 0xFFFFFF, a * 0.8f, a * 0.8f);
        float twinkle = (float) Math.pow(Math.max(0.0, Math.sin(age * 0.7 + seed[i] * 50.0)), 12.0);
        if (twinkle > 0.05f) {
            d.glint(px, py, pz, size[i] * 2.4f * twinkle, seed[i] * 6.28f, 0xFFFFFF, a * twinkle);
        }
    }

    /** Inti api: putih-kuning panas yang pelan-pelan jadi warna apinya. */
    private static int flameCore(int rgb, float t) {
        return lerpColor(0xFFF6DC, lerpColor(rgb, 0xFFFFFF, 0.3f), Math.min(1f, t * 1.8f));
    }

    /** Kulit api: warna apinya, mendingin ke merah gelap menjelang padam. */
    private static int flameOuter(int rgb, float t) {
        int deep = lerpColor(rgb, 0x3A0602, 0.6f);
        return t < 0.45f ? lerpColor(lerpColor(rgb, 0xFFE6A0, 0.25f), rgb, t / 0.45f) : lerpColor(rgb, deep, (t - 0.45f) / 0.55f);
    }

    void renderSoft(Draw d) {
        float pt = d.partialTick;
        for (int i = 0; i < count; i++) {
            int kind = type[i];
            if (kind != DUST && kind != SMOKE && kind != CINDER) {
                continue;
            }
            double px = ox[i] + (x[i] - ox[i]) * pt, py = oy[i] + (y[i] - oy[i]) * pt, pz = oz[i] + (z[i] - oz[i]) * pt;
            float t = Math.min(1f, (age[i] + pt) / life[i]);
            int c = color[i];
            d.hd(hd[i]);
            if (kind == CINDER) {   // serpih abu yang berputar (ukurannya berdenyut seperti serpih yang berbalik)
                float a = 0.85f * Math.min(1f, (age[i] + pt) / 3f) * (1f - t);
                float r = size[i] * (0.75f + 0.35f * (float) Math.sin((age[i] + pt) * 0.6f + seed[i] * 9f));
                d.puff(px, py, pz, r, Draw.mix(c, 0xFFFFFF, 0.08), Draw.mix(c, 0x000000, 0.45), a);
            } else if (kind == DUST) {
                float a = 0.72f * (float) Math.sin(Math.PI * Math.min(1f, t * 1.6f + 0.12f)) * (1f - t);
                d.puff(px, py, pz, size[i] * (0.55f + 0.9f * t), Draw.mix(c, 0xFFFFFF, 0.16), Draw.mix(c, 0x000000, 0.38), a);
            } else {
                // asap: cepat menebal, lalu menipis pelan sambil terus mengembang
                float in = Math.min(1f, t / 0.1f);
                float a = 0.55f * in * (float) Math.pow(1f - t, 1.3);
                float r = size[i] * (0.6f + 1.7f * (float) Math.sqrt(t));
                d.puff(px, py, pz, r, Draw.mix(c, 0xFFFFFF, 0.22), Draw.mix(c, 0x000000, 0.35), a);
            }
        }
        d.hd(false);
    }

    /** Warna bara yang mendingin. */
    private static int cool(float t) {
        if (t < 0.35f) {
            return lerpColor(0xFFF0B0, 0xFFA030, t / 0.35f);
        }
        return lerpColor(0xFFA030, 0xC03010, (t - 0.35f) / 0.65f);
    }

    static int lerpColor(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = (int) (((a >> 16) & 0xFF) + (((b >> 16) & 0xFF) - ((a >> 16) & 0xFF)) * t);
        int g = (int) (((a >> 8) & 0xFF) + (((b >> 8) & 0xFF) - ((a >> 8) & 0xFF)) * t);
        int bl = (int) ((a & 0xFF) + ((b & 0xFF) - (a & 0xFF)) * t);
        return (r << 16) | (g << 8) | bl;
    }
}
