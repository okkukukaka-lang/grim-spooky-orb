package com.shazammod.client.vfx;

import java.util.Random;

import com.shazammod.MagicBolt;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;

/**
 * Petir sihir emas (Shazam) atau emas-jingga membara (Black Adam) digambar di lapisan cahaya: jalur zig-zag dari langit dengan pendar lebar, inti putih,
 * dan cabang-cabang; bentuknya berganti tiap 2 tick dan berkedip. Petir transformasi turun pelan dulu
 * (ujungnya bercahaya dan memercik) sebelum menyambar penuh; jalurnya sama, jadi saat menyambar bentuknya menyambung.
 *
 * 0.30 Petir neraka Sabbac (varian 2): kebalikannya - menyembur NAIK dari tanah ke langit, merah darah dengan inti
 * jingga panas, dibungkus asap hitam (lapisan lembut), dan cabangnya mencakar ke atas. Saat "turun" (transformasi),
 * ujungnya merambat naik dari bawah kaki.
 */
public final class BoltVisual extends Effect {
    private static final double HEIGHT = 88.0;
    // Shazam: emas cerah. Black Adam: pendar jingga membara di luar, emas di tengah, inti tetap putih panas.
    private static final int[] GLOW = {0xFFC24A, 0xFF7A1C, 0xD8201A, 0xFFD878};   // 0.32: tiang cahaya Lintang
    private static final int[] LIGHT = {0xFFE7A8, 0xFFC878, 0xFF6A30, 0xFFF4D0};
    /** Inti petir: putih panas (Shazam & Black Adam), jingga-kuning bara (Sabbac). */
    private static final int[] CORE = {0xFFFFFF, 0xFFFFFF, 0xFFC890, 0xFFFFFF};
    private static final double[] ROUGH = {0.09, 0.115, 0.14, 0.0};   // petir Black Adam lebih tajam, petir neraka paling liar
    private static final int SMOKE = 0x140606;                   // asap hitam yang membungkus petir neraka
    private final MagicBolt bolt;
    private final long seed;

    public BoltVisual(MagicBolt bolt) {
        super(MagicBolt.LIFETIME + 4000);
        this.bolt = bolt;
        this.seed = bolt.getId() * 31L + 7L;
    }

    @Override
    public boolean tick(ClientLevel level) {
        age++;
        return bolt.isAlive() && !bolt.isRemoved() && bolt.age() - bolt.descent() <= MagicBolt.LIFETIME + 1;
    }

    private static float flicker(float strikeAge) {
        if (strikeAge > MagicBolt.LIFETIME) {
            return 0f;
        }
        float fade = 1f - Math.max(0f, strikeAge - 4f) / (MagicBolt.LIFETIME - 4f);
        int step = (int) strikeAge;
        if (step > 3 && step % 3 == 1) {
            return fade * 0.35f;   // berkedip
        }
        return fade;
    }

    @Override
    public void renderGlow(Draw d) {
        float pt = d.partialTick;
        float age = bolt.age() + pt;
        float size = bolt.boltSize();
        int descent = bolt.descent();
        Vec3 p = bolt.getPosition(pt);
        Vec3 top = p.add(0, HEIGHT, 0);
        if (descent > 0 && age < descent) {
            descent(d, p, top, age / descent, age, size);
            return;
        }
        float strikeAge = age - descent;
        float a = flicker(strikeAge);
        if (a <= 0.01f) {
            return;
        }
        int v = variant();
        if (v == 3) {   // 0.32 Lintang: tiang cahaya lurus, bukan zig-zag
            sunColumn(d, p, top, a, strikeAge, size);
            return;
        }
        int gold = GLOW[v], goldLight = LIGHT[v];
        boolean up = v == 2;   // petir neraka: dari tanah ke langit
        Random random = new Random(seed + (descent > 0 ? 0 : (long) (strikeAge / 2f)) * 977L);
        float[] main = up ? Lightning.path(p.x, p.y, p.z, top.x, top.y, top.z, 6, ROUGH[v], random)
                : Lightning.path(top.x, top.y, top.z, p.x, p.y, p.z, 6, ROUGH[v], random);
        int n = main.length / 3;
        d.polyline(main, n, 3.2f * size, 2.4f * size, gold, gold, a * 0.22f, a * 0.3f);
        d.polyline(main, n, 1.1f * size, 0.9f * size, v >= 1 ? goldLight : gold, CORE[v], a, a);
        int branches = 2 + (int) (size * 1.6f);
        for (int b = 0; b < branches; b++) {
            int i = up ? 3 + random.nextInt(Math.max(1, n - 12)) : 6 + random.nextInt(Math.max(1, n - 16));
            double sx = main[i * 3], sy = main[i * 3 + 1], sz = main[i * 3 + 2];
            double len = (6.0 + random.nextDouble() * 10.0) * Math.max(0.6, size);
            // petir neraka: cabangnya mencakar ke atas & ke samping (seperti lidah api)
            double ex = sx + (random.nextDouble() - 0.5) * len * 1.2,
                    ey = up ? sy + len * (0.4 + random.nextDouble() * 0.5) : sy - len * (0.6 + random.nextDouble() * 0.4),
                    ez = sz + (random.nextDouble() - 0.5) * len * 1.2;
            float[] br = Lightning.path(sx, sy, sz, ex, ey, ez, 4, up ? 0.22 : 0.16, random);
            d.polyline(br, br.length / 3, 0.55f * size, 0.08f * size, gold, goldLight, a * 0.85f, 0f);
        }
        // pendar di langit dan di tanah
        d.glow(top.x, top.y - 4, top.z, 10f * size, goldLight, a * (up ? 0.12f : 0.25f));
        d.flare(p.x, p.y + 0.4, p.z, (up ? 2.2f : 1.6f) * size, gold, a);
    }

    /** 0.30 Petir neraka: asap hitam pekat yang membungkus jalurnya (lapisan tembus pandang biasa, bukan cahaya). */
    @Override
    public void renderSoft(Draw d) {
        if (variant() != 2) {
            return;
        }
        float pt = d.partialTick;
        float age = bolt.age() + pt;
        float size = bolt.boltSize();
        int descent = bolt.descent();
        Vec3 p = bolt.getPosition(pt);
        Vec3 top = p.add(0, HEIGHT, 0);
        Random random = new Random(seed + (descent > 0 || age < descent ? 0 : (long) ((age - descent) / 2f)) * 977L);
        float[] main = Lightning.path(p.x, p.y, p.z, top.x, top.y, top.z, 6, ROUGH[2], random);
        int n = main.length / 3;
        float a;
        int shown = n;
        if (descent > 0 && age < descent) {
            float reach = (float) Math.pow(Math.max(0f, Math.min(1f, age / descent)), 1.35);
            shown = Math.max(2, (int) Math.ceil(reach * (n - 1)) + 1);
            a = 0.35f;
        } else {
            a = flicker(age - descent) * 0.45f;
        }
        if (a <= 0.01f) {
            return;
        }
        d.strip(main, shown, 5.0f * size, 3.6f * size, SMOKE, a, a * 0.5f);
    }

    private int variant() {
        int v = bolt.variant();
        return v >= 0 && v < GLOW.length ? v : 0;
    }

    /** Petir sedang turun: jalur dari langit sampai ujungnya saja, ujung bercahaya yang memercik mencari jalan. */
    /** 0.32 Lintang (varian 3): tiang cahaya matahari yang lurus, tebal, dan berdenyut. */
    private void sunColumn(Draw d, Vec3 p, Vec3 top, float a, float strikeAge, float size) {
        float swell = 1f + 0.25f * (float) Math.sin(strikeAge * 1.3f);
        d.beam(top.x, top.y, top.z, p.x, p.y, p.z, 4.2f * size * swell, GLOW[3], LIGHT[3], a * 0.25f, a * 0.35f);
        d.beam(top.x, top.y, top.z, p.x, p.y, p.z, 1.6f * size, LIGHT[3], CORE[3], a, a);
        d.glow(top.x, top.y - 6, top.z, 12f * size, LIGHT[3], a * 0.3f);
        d.flare(p.x, p.y + 0.5, p.z, 2.2f * size, GLOW[3], a);
    }

    /** 0.32 Tiang cahaya turun pelan dari langit (transformasi Lintang). */
    private void sunDescent(Draw d, Vec3 p, Vec3 top, float progress, float age, float size) {
        float reach = (float) Math.pow(Math.max(0f, Math.min(1f, progress)), 1.35);
        double ty = top.y + (p.y - top.y) * reach;
        float pulse = 0.8f + 0.2f * (float) Math.sin(age * 2.2f);
        d.beam(top.x, top.y, top.z, p.x, ty, p.z, 2.4f * size, GLOW[3], LIGHT[3], 0.2f * pulse, 0.3f * pulse);
        d.beam(top.x, top.y, top.z, p.x, ty, p.z, 0.8f * size, LIGHT[3], CORE[3], 0.9f * pulse, pulse);
        d.flare(p.x, ty, p.z, 1.6f * size * pulse, LIGHT[3], 0.9f);
    }

    private void descent(Draw d, Vec3 p, Vec3 top, float progress, float age, float size) {
        int v = variant();
        if (v == 3) {
            sunDescent(d, p, top, progress, age, size);
            return;
        }
        int gold = GLOW[v], goldLight = LIGHT[v];
        boolean up = v == 2;
        Random random = new Random(seed);   // jalur sama dengan saat menyambar
        float[] main = up ? Lightning.path(p.x, p.y, p.z, top.x, top.y, top.z, 6, ROUGH[v], random)
                : Lightning.path(top.x, top.y, top.z, p.x, p.y, p.z, 6, ROUGH[v], random);
        int n = main.length / 3;
        float reach = (float) Math.pow(Math.max(0f, Math.min(1f, progress)), 1.35);
        int shown = Math.max(2, (int) Math.ceil(reach * (n - 1)) + 1);
        float pulse = 0.75f + 0.25f * (float) Math.sin(age * 2.2f);
        // potong jalur di ujung
        float[] part = new float[shown * 3];
        System.arraycopy(main, 0, part, 0, shown * 3);
        float f = reach * (n - 1) - (shown - 2);
        int last = (shown - 1) * 3, prev = (shown - 2) * 3;
        if (shown < n) {
            for (int k = 0; k < 3; k++) {
                part[last + k] = main[prev + k] + (main[last + k] - main[prev + k]) * Math.max(0f, Math.min(1f, f));
            }
        }
        d.polyline(part, shown, 2.2f * size, 1.6f * size, gold, gold, 0.18f * pulse, 0.25f * pulse);
        d.polyline(part, shown, 0.7f * size, 0.6f * size, v >= 1 ? goldLight : gold, CORE[v], 0.9f * pulse, pulse);
        double tx = part[last], ty = part[last + 1], tz = part[last + 2];
        d.flare(tx, ty, tz, 1.4f * size * pulse, goldLight, 0.9f);
        Random sparks = new Random(seed * 17L + (long) age);
        for (int b = 0; b < 3; b++) {   // percikan bercabang dari ujung, mencari jalan (petir neraka: ke atas)
            double ex = tx + (sparks.nextDouble() - 0.5) * 2.0 * size,
                    ey = up ? ty + (0.8 + sparks.nextDouble() * 1.2) * size : ty - (0.8 + sparks.nextDouble() * 1.2) * size,
                    ez = tz + (sparks.nextDouble() - 0.5) * 2.0 * size;
            float[] br = Lightning.path(tx, ty, tz, ex, ey, ez, 3, 0.3, sparks);
            d.polyline(br, br.length / 3, 0.18f * size, 0.04f * size, gold, CORE[v], 0.9f * pulse, 0f);
        }
    }
}
