package com.shazammod.client.fx;

import com.shazammod.PassiveConditions;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Hd;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

/**
 * 0.34 Lapisan VFX HD Sabbac (di atas SabbacFx & SabbacCine): api sungguhan (lidah api yang menari, mendingin dari
 * putih-kuning ke merah gelap), bola ledakan api bervolume yang berubah jadi asap hitam, tornado api, segel neraka
 * enam penjuru, gelombang api yang menyapu tanah, hujan abu, dan gelombang teror. Selama berwujud Sabbac lidah api
 * kecil menjilat di bahu (lebih besar di kegelapan), dan saat Gerbang Neraka badannya diselubungi api.
 * Dipanggil dari SabbacCine (penguat Sabbac sudah terpasang, jadi semua efek di sini digambar HD + bloom).
 */
public final class SabbacHd {
    private SabbacHd() {}

    static final int FIRE = SabbacFx.HELL;
    static final int FIRE_LIGHT = SabbacFx.HELL_LIGHT;
    static final int FIRE_HOT = 0xFFE2A8;
    static final int FIRE_DEEP = 0x9A1408;
    static final int BLOOD = SabbacFx.BLOOD;
    static final int MAGMA = SabbacFx.MAGMA;
    static final int SMOKE = 0x1A1210;
    static final int ASH = 0x2A2220;
    static final int OBSIDIAN_SHEEN = 0x9A6AD8;
    static final int FLY = 0x0E0A08;
    static final int HEAT = 0xFFE4CC;
    static final Vec3 UP = HdKit.UP;
    static final Vec3 DOWN = new Vec3(0, -1, 0);

    public static void clear() {
    }

    private static boolean alive(AbstractClientPlayer p) {
        return p.isAlive() && !p.isRemoved();
    }

    private static void later(AbstractClientPlayer p, int delay, Runnable r) {
        if (delay <= 0) {
            r.run();
            return;
        }
        ShazamFx.schedule(delay, 1, (lvl, t) -> {
            if (alive(p)) {
                r.run();
            }
        });
    }

    private static Vec3 look(AbstractClientPlayer p) {
        return p.getViewVector(1f);
    }

    private static Vec3 mouth(AbstractClientPlayer p) {
        Vec3 e = p.getEyePosition(1f), l = look(p);
        return new Vec3(e.x + l.x * 0.3, e.y - 0.16 + l.y * 0.2, e.z + l.z * 0.3);
    }

    /** Bola ledakan api neraka: putih-kuning -> jingga -> merah gelap -> asap hitam. */
    private static void nova(Vec3 at, double radius, int life, float strength, boolean ground) {
        Vfx.add(new Hd.Nova(at, radius, FIRE_HOT, FIRE_LIGHT, FIRE_DEEP, SMOKE, life, strength, ground));
    }

    private static Ground.Map map(ClientLevel level, Vec3 at, double radius) {
        return ShazamFx.ground(level, at, radius);
    }

    // ------------------------------------------------------------------ titik masuk

    public static void onAnim(AbstractClientPlayer p, ShazamAnim a, Vec3 pos) {
        try {
            onAnim0(p, a, pos);
        } catch (Throwable ignored) {
            // lapisan HD nggak boleh bikin game crash
        }
    }

    private static void onAnim0(AbstractClientPlayer p, ShazamAnim a, Vec3 pos) {
        ClientLevel level = HdKit.level(p);
        boolean fp = HdKit.firstPerson(p);
        float near = fp ? 0.35f : 1f;
        switch (a) {
            case SUMMON -> summon(level, p);
            case TRANSFORM -> later(p, ShazamAnim.TRANSFORM_STRIKE, () -> transform(level, p, near));
            case REVERT, KNOCKOUT -> later(p, a == ShazamAnim.REVERT ? ShazamAnim.REVERT_WINDUP : ShazamAnim.KNOCKOUT_BURST, () -> {
                Vec3 f = HdKit.feet(p);
                HdKit.flames(f, 8, 0.6, 0.05, FIRE, 0.15f, 12);
                HdKit.cinders(HdKit.chest(p), 14, 0.8, 0.04, ASH, 0.07f, 40, 0.0015f);
            });
            case LAUNCH -> {
                Vec3 f = HdKit.feet(p);
                HdKit.flameJet(f, DOWN, 12, 0.32, 0.65, FIRE, 0.22f, 12);
                Vfx.add(new Hd.Pressure(f, DOWN, 3.4, 1.15, FIRE, 12, 0.55f, true));
            }
            case LAND_HERO, CRASH -> {
                boolean big = a == ShazamAnim.CRASH;
                Vec3 f = HdKit.groundAt(level, p, HdKit.feet(p));
                nova(f, big ? 3.2 : 1.9, big ? 28 : 20, 0.85f, true);
                HdKit.fireWave(level, f, big ? 6.5 : 3.6, big ? 12 : 8, FIRE, 0.26f, null, 0);
                HdKit.cinders(f, big ? 24 : 12, 2.0, 0.06, ASH, 0.08f, 50, -0.0015f);
            }
            case SONIC_BOOM -> {
                Vec3 c = HdKit.chest(p), l = look(p);
                Vfx.add(new Hd.Pressure(c.add(l.scale(0.4)), l.scale(-1), 3.6, 1.05, FIRE_LIGHT, 14, 0.65f * near, true));
                HdKit.flameJet(c, l.scale(-1), 10, 0.4, 0.4, FIRE, 0.18f, 10);
            }
            case SABBAC_HORNS -> horns(level, p, pos, near);
            case SABBAC_GORE -> {
                if (pos != null) {
                    nova(pos, 1.4, 14, 0.9f, false);
                    HdKit.flameBurst(pos, 10, 0.35, FIRE, 0.2f, 12);
                }
            }
            case SABBAC_AYM -> aym(level, p, near);
            case SABBAC_AYM_BURST -> later(p, ShazamAnim.NOVA_WINDUP, () -> {
                Vec3 c = HdKit.chest(p), f = HdKit.feet(p);
                nova(c, 4.6, 30, near, false);
                HdKit.shards(c, 30, 0.7, OBSIDIAN_SHEEN, 0.11f, 26, f.y);
                Vfx.add(new Hd.Pressure(c, UP, 9.0, Math.PI, FIRE, 18, 0.75f, true));
                HdKit.fireWave(level, f, 7.0, 12, FIRE, 0.28f, null, 0);
                HdKit.cinders(c, 24, 1.6, 0.08, ASH, 0.09f, 60, -0.002f);
            });
            case SABBAC_CHAINS -> later(p, ShazamAnim.CHAIN_WINDUP, () -> {
                Vec3 f = HdKit.feet(p);
                Ground.Map g = map(level, f, 2.2);
                Vfx.add(new Hd.Sigil(g == null ? f : g.center(f), 1.7, 6, FIRE, FIRE_HOT, 40, 0.85f, 0.03f, g));
                HdKit.flameRing(g == null ? f : g.center(f), 1.5, 8, FIRE, 0.18f, 14, g);
            });
            case SABBAC_CHAIN_BIND -> {
                if (pos != null) {
                    Ground.Map g = map(level, pos, 1.6);
                    Vec3 gc = g == null ? pos : g.center(pos);
                    Vfx.add(new Hd.Sigil(gc, 1.15, 6, FIRE, FIRE_HOT, 34, 0.9f, -0.05f, g));
                    HdKit.flameColumn(Lightning.Anchor.fixed(gc), 1.8, 0.28, 10, FIRE, 0.17f);
                    nova(gc.add(0, 0.4, 0), 0.8, 10, 0.7f, false);
                    HdKit.cinders(gc, 8, 0.5, 0.05, ASH, 0.06f, 30, -0.002f);
                }
            }
            case SABBAC_BREATH -> breath(level, p, near);
            case SABBAC_ROAR -> later(p, ShazamAnim.TERROR_WINDUP, () -> roar(level, p, near));
            case SABBAC_WINGS -> later(p, ShazamAnim.WINGS_WINDUP, () -> {
                Vec3 c = HdKit.chest(p), f = HdKit.feet(p), l = HdKit.flat(look(p));
                HdKit.fireWave(level, f, 9.0, 10, FIRE, 0.3f, l, 1.1);
                Vfx.add(new Hd.Pressure(c, l, 8.0, 1.2, FIRE_LIGHT, 14, 0.7f, true));
                Vfx.add(new Hd.Pressure(f, UP, 5.0, 1.5, FIRE, 12, 0.5f, false));
                Vec3 back = c.subtract(l.scale(0.4)).add(0, 0.3, 0);
                HdKit.flameJet(back, l.scale(-1).add(0, 0.6, 0), 14, 0.4, 0.8, FIRE, 0.22f, 14);
            });
            case SABBAC_HELLGATE -> hellgate(level, p, near);
            case SABBAC_GEYSER -> {
                if (pos != null) {
                    Vec3 g = HdKit.groundAt(level, p, pos);
                    HdKit.flameColumn(Lightning.Anchor.fixed(g), 6.0, 0.6, 18, FIRE, 0.3f);
                    nova(g, 1.6, 16, 0.85f, true);
                    HdKit.cinders(g, 12, 0.8, 0.12, ASH, 0.08f, 50, -0.0025f);
                }
            }
            case SABBAC_CALL -> later(p, ShazamAnim.SABBAC_CALL_WINDUP, () -> {
                Vec3 c = HdKit.chest(p), f = HdKit.feet(p);
                HdKit.flameColumn(HdKit.feetAnchor(p), 7.0, 0.7, 20, FIRE, 0.3f);
                nova(c, 2.6, 20, near, false);
                HdKit.fireWave(level, f, 5.0, 10, FIRE, 0.26f, null, 0);
            });
            case SABBAC_LEGION -> later(p, ShazamAnim.LEGION_WINDUP, () -> {
                Vec3 f = HdKit.feet(p);
                Ground.Map g = map(level, f, 3.6);
                HdKit.fireWave(level, f, 5.0, 12, FIRE, 0.28f, null, 0);
                Vfx.add(new Hd.Sigil(g == null ? f : g.center(f), 3.0, 6, FIRE, FIRE_HOT, 46, 0.9f, 0.02f, g));
            });
            case SABBAC_RISE -> {
                if (pos != null) {
                    Vec3 g = HdKit.groundAt(level, p, pos);
                    HdKit.flameColumn(Lightning.Anchor.fixed(g), 2.6, 0.45, 16, FIRE, 0.24f);
                    nova(g.add(0, 0.5, 0), 1.0, 12, 0.7f, true);
                    HdKit.cinders(g, 10, 0.6, 0.08, ASH, 0.07f, 40, -0.002f);
                }
            }
            case SABBAC_PULSE -> {
                Vec3 f = HdKit.feet(p);
                HdKit.flameRing(f, 0.55, 7, FIRE, 0.2f, 14, null);
                if (!fp) {
                    HdKit.flames(HdKit.chest(p).add(0, -0.5, 0), 4, 0.35, 0.08, FIRE_LIGHT, 0.16f, 10);
                }
                if (PassiveConditions.inferno(level)) {   // di Nether apinya meluap
                    HdKit.fireWave(level, f, 4.5, 8, FIRE, 0.24f, null, 0);
                }
            }
            case SABBAC_HELLPUNCH -> {
                if (pos != null) {
                    Vec3 dir = HdKit.norm(pos.subtract(HdKit.chest(p)));
                    nova(pos, 2.4, 20, 1f, false);
                    Vfx.add(new Hd.Pressure(pos, dir, 6.0, 1.1, FIRE_LIGHT, 14, 0.7f, true));
                    HdKit.flameBurst(pos, 16, 0.45, FIRE, 0.24f, 14);
                    HdKit.cinders(pos, 10, 0.8, 0.06, ASH, 0.08f, 40, -0.002f);
                }
            }
            case SABBAC_ENGULF -> {
                if (pos != null) {
                    Vfx.add(new Hd.Vortex(Lightning.Anchor.fixed(pos.add(0, -0.6, 0)), 0.2, 0.8, 1.6, 3, 1.5, 0.16f, FIRE,
                            FIRE_HOT, 0, 0.5f, 14, 0.9f));
                    HdKit.flameBurst(pos, 8, 0.25, FIRE, 0.16f, 10);
                }
            }
            case SABBAC_FIRE_OUT -> {
                HdKit.flames(HdKit.feet(p), 6, 0.5, 0.03, FIRE, 0.12f, 10);
                HdKit.cinders(HdKit.chest(p), 10, 0.6, 0.03, ASH, 0.06f, 40, 0.0015f);
            }
            case SABBAC_FIRE_IN -> {
                Vec3 f = HdKit.feet(p);
                HdKit.flameRing(f, 0.8, 10, FIRE, 0.2f, 14, null);
                HdKit.fireWave(level, f, 2.0, 8, FIRE, 0.2f, null, 0);
            }
            case SABBAC_PUNCH -> {
                if (pos != null) {
                    HdKit.flameBurst(pos, 5, 0.25, FIRE, 0.12f, 9);
                }
            }
            case SABBAC_PACT -> pact(level, p);
            case RIVAL_ARRIVE -> {
                if (pos != null) {
                    Vec3 g = HdKit.groundAt(level, p, pos);
                    nova(g.add(0, 0.6, 0), 3.0, 26, 1f, true);
                    HdKit.flameColumn(Lightning.Anchor.fixed(g), 8.0, 0.8, 20, FIRE, 0.32f);
                    HdKit.fireWave(level, g, 6.0, 12, FIRE, 0.28f, null, 0);
                }
            }
            default -> {
            }
        }
    }

    // ------------------------------------------------------------------ transformasi & ritual

    /** Enam iblis datang: segel neraka menyala di tanah, api menyala di penjuru tiap iblis datang. */
    private static void summon(ClientLevel level, AbstractClientPlayer p) {
        Vec3 f = HdKit.feet(p);
        Ground.Map g = map(level, f, 4.2);
        Vec3 gc = g == null ? f : g.center(f);
        double phase = Math.toRadians(p.getYRot() + 90.0);
        float spin = 0.004f;
        double radius = 3.4;
        Vfx.add(new Hd.Sigil(gc, radius, 6, FIRE, FIRE_HOT, ShazamAnim.SUMMON_TICKS + 14, 0.85f, spin, phase, g));
        Vfx.add(new Hd.Haze(Lightning.Anchor.fixed(gc), radius * 0.8, 3.0, 9, HEAT, ShazamAnim.SUMMON_TICKS + 10, 0.8f));
        for (int k = 0; k < GodShow.ARRIVE.length && k < 6; k++) {
            int at = GodShow.ARRIVE[k];
            double ang = phase + at * spin + Math.PI * 2.0 * k / 6.0;
            double star = radius * 0.86;
            Vec3 point = new Vec3(gc.x + Math.cos(ang) * star, gc.y, gc.z + Math.sin(ang) * star);
            ShazamFx.schedule(Math.max(0, at - 2), 1, (lvl, t) -> {
                HdKit.flameColumn(Lightning.Anchor.fixed(point), 2.6, 0.3, ShazamAnim.SUMMON_TICKS - at + 10, FIRE, 0.2f);
                nova(point.add(0, 0.5, 0), 0.9, 12, 0.75f, true);
                HdKit.cinders(point, 6, 0.4, 0.08, ASH, 0.06f, 40, -0.002f);
            });
        }
        ShazamFx.schedule(0, ShazamAnim.SUMMON_TICKS, (lvl, t) -> {
            if (t % 3 == 0) {
                HdKit.cinders(gc, 1.5, radius * 0.8, 0.05, ASH, 0.06f, 50, -0.0025f);
            }
        });
    }

    /** Berubah jadi Sabbac: bola api neraka, tornado api, gelombang api, hujan abu. */
    private static void transform(ClientLevel level, AbstractClientPlayer p, float near) {
        Vec3 c = HdKit.chest(p), f = HdKit.feet(p);
        nova(c, 3.6, 32, near, false);
        Vfx.add(new Hd.Vortex(HdKit.feetAnchor(p), 0.7, 2.8, 7.0, 3, 1.8, 0.42f, FIRE, FIRE_HOT, SMOKE, 0.28f, 50, 0.95f * near));
        if (!HdKit.firstPerson(p)) {   // tornadonya terbuat dari api (di orang pertama cuma menutupi layar)
            HdKit.flameSpiral(HdKit.feetAnchor(p), 0.7, 2.8, 7.0, 0.28f, 40, FIRE, 0.26f);
        }
        Vfx.add(new Hd.Pressure(c, UP, 10.0, Math.PI, FIRE, 18, 0.7f, true));
        HdKit.fireWave(level, f, 9.0, 14, FIRE, 0.3f, null, 0);
        HdKit.flameBurst(c, 22, 0.5, FIRE, 0.25f, 16);
        HdKit.cinders(c, 26, 2.5, 0.08, ASH, 0.11f, 60, -0.002f);
        Vfx.add(new Hd.Haze(HdKit.feetAnchor(p), 2.0, 3.5, 9, HEAT, 80, 1f));
        ShazamFx.schedule(24, 50, (lvl, t) -> {   // abu turun pelan sesudahnya
            if (t % 2 == 0 && alive(p)) {
                Vec3 ff = HdKit.feet(p);
                HdKit.cinders(ff.add(0, 4.0, 0), 1.5, 4.0, -0.01, ASH, 0.08f, 70, 0.0012f);
            }
        });
    }

    /** Perjanjian Enam Iblis: segel di tanah, enam tiang api menyala satu per satu, lalu ledakan saat terbuka. */
    private static void pact(ClientLevel level, AbstractClientPlayer p) {
        Vec3 c0 = p.position();
        double yaw = p.getYRot() * Mth.DEG_TO_RAD;
        later(p, 4, () -> {
            Ground.Map g = map(level, c0, 3.8);
            Vec3 gc = g == null ? c0 : g.center(c0);
            Vfx.add(new Hd.Sigil(gc, 3.0 / 0.86, 6, BLOOD, FIRE, ShazamAnim.PACT_TICKS, 0.85f, 0f, yaw, g));
        });
        for (int k = 0; k < 6; k++) {
            int demon = k;
            later(p, 8 + k * 8, () -> {
                double a = Math.PI * 2.0 * demon / 6.0 + p.getYRot() * Mth.DEG_TO_RAD;
                Vec3 at = HdKit.groundAt(level, p, p.position().add(Math.cos(a) * 3.0, 0.02, Math.sin(a) * 3.0));
                HdKit.flameColumn(Lightning.Anchor.fixed(at), 2.8, 0.32, ShazamAnim.PACT_STRIKE - 8 - demon * 8 + 10, FIRE, 0.22f);
                nova(at.add(0, 0.5, 0), 0.9, 12, 0.8f, true);
            });
        }
        later(p, ShazamAnim.PACT_STRIKE, () -> {
            Vec3 c = HdKit.chest(p);
            nova(c, 3.0, 26, HdKit.firstPerson(p) ? 0.4f : 1f, false);
            Vfx.add(new Hd.Vortex(HdKit.feetAnchor(p), 0.5, 2.2, 5.0, 3, 1.6, 0.34f, FIRE, FIRE_HOT, SMOKE, 0.3f, 30, 0.85f));
            if (!HdKit.firstPerson(p)) {
                HdKit.flameSpiral(HdKit.feetAnchor(p), 0.5, 2.2, 5.0, 0.3f, 24, FIRE, 0.22f);
            }
            Vfx.add(new Hd.Pressure(c, UP, 8.0, Math.PI, FIRE, 16, 0.7f, true));
        });
    }

    // ------------------------------------------------------------------ skill

    /** Tanduk Setan: api di tanduk (ancang-ancang), jejak api di sepanjang serudukan, ledakan di ujung. */
    private static void horns(ClientLevel level, AbstractClientPlayer p, Vec3 pos, float near) {
        int w = ShazamAnim.HORN_WINDUP, run = ShazamAnim.HORN_TICKS;
        ShazamFx.schedule(0, w + run, (lvl, t) -> {
            if (!alive(p) || HdKit.firstPerson(p)) {
                return;
            }
            Vec3 h = HdKit.head(p).add(0, 0.25 * p.getScale(), 0);
            float yaw = p.yBodyRot * Mth.DEG_TO_RAD;
            double rx = -Math.cos(yaw), rz = -Math.sin(yaw);
            for (int s = -1; s <= 1; s += 2) {
                double hx = h.x + rx * s * 0.32 * p.getScale(), hz = h.z + rz * s * 0.32 * p.getScale();
                Vfx.flame(hx, h.y + 0.2, hz, 0, 0.03, 0, FIRE, 0.07f, 8);
            }
        });
        later(p, w, () -> {
            Vec3 c = HdKit.chest(p), l = HdKit.flat(look(p));
            Vfx.add(new Hd.Pressure(c.add(l.scale(0.5)), l, 4.0, 1.0, FIRE_LIGHT, 10, 0.6f, true));
            ShazamFx.schedule(0, run + 2, (lvl, t) -> {
                if (!alive(p)) {
                    return;
                }
                Vec3 f = HdKit.feet(p);
                HdKit.flames(f, 3, 0.4, 0.06, FIRE, 0.22f, 14);
                if (t % 2 == 0) {
                    HdKit.cinders(f, 2, 0.4, 0.05, ASH, 0.06f, 30, -0.002f);
                }
            });
        });
        if (pos != null) {
            later(p, w + run, () -> {
                Vec3 end = HdKit.groundAt(level, p, pos);
                nova(end.add(0, 0.6, 0), 1.8, 18, 0.9f, true);
                HdKit.fireWave(level, end, 3.5, 8, FIRE, 0.24f, HdKit.flat(look(p)), 0.9);
            });
        }
    }

    /** Tubuh Aym: serpih obsidian terhisap ke badan (ancang-ancang), lalu riak panas & cincin magma selama 7 detik. */
    private static void aym(ClientLevel level, AbstractClientPlayer p, float near) {
        int w = ShazamAnim.AYM_WINDUP;
        Vec3 c0 = HdKit.chest(p);
        RandomSource r = level.random;
        for (int i = 0, n = HdKit.n(10); i < n; i++) {
            double a = r.nextDouble() * Math.PI * 2.0, h = (r.nextDouble() - 0.4) * 1.4, rr = 1.6 + r.nextDouble() * 0.6;
            double sx = c0.x + Math.cos(a) * rr, sy = c0.y + h, sz = c0.z + Math.sin(a) * rr;
            double k = 1.0 / (w + 1);
            Vfx.shard(sx, sy, sz, (c0.x - sx) * k, (c0.y - sy) * k, (c0.z - sz) * k, OBSIDIAN_SHEEN, 0.08f, w + 2, Double.NaN);
        }
        later(p, w, () -> {
            Vfx.add(new Hd.Haze(HdKit.feetAnchor(p), 0.9, 2.6, 6, HEAT, ShazamAnim.AYM_TICKS, 0.9f));
            ShazamFx.schedule(0, ShazamAnim.AYM_TICKS, (lvl, t) -> {
                if (!alive(p) || SabbacFx.aymStrength(p, 0f) <= 0.05f) {
                    return;
                }
                if (t % 6 == 0) {
                    HdKit.flameRing(HdKit.feet(p), 0.85, 3, MAGMA, 0.12f, 10, null);
                }
            });
        });
    }

    /** Napas Beelzebub: semburan lidah api yang padat, lalat hitam, dan api yang menyala di tempat semburan jatuh. */
    private static void breath(ClientLevel level, AbstractClientPlayer p, float near) {
        int w = ShazamAnim.BREATH_WINDUP;
        HdKit.streaksIn(mouth(p), 6, 1.2, FIRE_LIGHT, 0.04f, w);
        later(p, w, () -> ShazamFx.schedule(0, ShazamAnim.BREATH_TICKS, (lvl, t) -> {
            if (!alive(p)) {
                return;
            }
            Vec3 m = mouth(p), l = look(p);
            Vec3 from = m.add(l.scale(0.35));
            HdKit.flameJet(from, l, 3.2, 0.55, 0.2, FIRE, 0.2f, 14);
            RandomSource r = lvl.random;
            Vec3 d = HdKit.jitter(r, l, 0.35);   // lalat hitam yang ikut tersembur
            Vfx.cinder(from.x, from.y, from.z, d.x * 0.32, d.y * 0.32, d.z * 0.32, FLY, 0.035f, 18 + r.nextInt(8), 0f);
            if (t % 5 == 2) {
                Vec3 end = HdKit.rayEnd(lvl, p, m, l, 12.0);
                if (end.distanceTo(m) < 11.5) {
                    HdKit.flames(end, 5, 0.8, 0.08, FIRE, 0.22f, 16);
                    HdKit.cinders(end, 2, 0.6, 0.06, ASH, 0.07f, 40, -0.002f);
                }
            }
        }));
    }

    /** Teror Asmodeus: dua gelombang teror (merah & merah darah), surai api meledak, segel teror di tanah. */
    private static void roar(ClientLevel level, AbstractClientPlayer p, float near) {
        Vec3 c = HdKit.chest(p), l = look(p), f = HdKit.feet(p);
        Vfx.add(new Hd.Pressure(c, l, 12.0, 1.15, FIRE, 18, 0.8f, true));
        Vfx.add(new Hd.Pressure(c, UP, 6.0, Math.PI, BLOOD, 14, 0.55f * near, true));
        later(p, 4, () -> Vfx.add(new Hd.Pressure(HdKit.chest(p), look(p), 8.0, 1.0, BLOOD, 14, 0.7f, true)));
        if (!HdKit.firstPerson(p)) {
            HdKit.flameJet(HdKit.head(p), UP.add(l.scale(-0.6)), 14, 0.3, 0.6, FIRE, 0.22f, 14);
        }
        HdKit.cinders(c, 20, 1.0, 0.06, ASH, 0.1f, 40, -0.002f);
        Ground.Map g = map(level, f, 3.0);
        Vfx.add(new Hd.Sigil(g == null ? f : g.center(f), 2.6, 6, BLOOD, FIRE, 26, 0.9f, -0.04f, g));
    }

    /** Gerbang Neraka: segel raksasa selama amarah, pusaran gerbang, bola api, gelombang api, cincin api menyala terus. */
    private static void hellgate(ClientLevel level, AbstractClientPlayer p, float near) {
        int w = ShazamAnim.HELLGATE_WINDUP;
        Vfx.add(new Hd.Haze(HdKit.feetAnchor(p), 1.6, 3.0, 8, HEAT, w + 40, 1f));
        ShazamFx.schedule(0, w, (lvl, t) -> {
            if (alive(p) && t % 2 == 0) {
                HdKit.flameRing(HdKit.feet(p), 1.2 + t * 0.08, 3, FIRE, 0.2f, 12, null);
            }
        });
        later(p, w, () -> {
            Vec3 c = HdKit.chest(p), f = HdKit.feet(p);
            Ground.Map g = map(level, f, 6.5);
            Vec3 gc = g == null ? f : g.center(f);
            Vfx.add(new Hd.Sigil(gc, 5.6, 6, FIRE, FIRE_HOT, 240, 1f, 0.008f, g));
            Vfx.add(new Hd.Vortex(Lightning.Anchor.fixed(gc), 1.0, 5.4, 1.2, 6, 0.9, 0.35f, FIRE, FIRE_HOT, SMOKE, 0.12f, 70, 0.9f));
            nova(c, 5.0, 36, near, false);
            Vfx.add(new Hd.Pressure(c, UP, 14.0, Math.PI, FIRE, 22, 0.8f, true));
            HdKit.fireWave(level, f, 11.0, 16, FIRE, 0.34f, null, 0);
            ShazamFx.schedule(0, 60, (lvl, t) -> {
                if (t % 2 == 0) {
                    HdKit.flameRing(gc, 5.6 * 0.98, 2, FIRE, 0.24f, 16, g);
                }
            });
        });
    }

    // ------------------------------------------------------------------ tiap tick

    public static void tick(ClientLevel level) {
        try {
            tick0(level);
        } catch (Throwable ignored) {
        }
    }

    private static void tick0(ClientLevel level) {
        boolean dark = PassiveConditions.darkness(level);
        for (AbstractClientPlayer p : level.players()) {
            int id = p.getId();
            if (!ShazamClientState.isTransformed(id) || !ShazamClientState.isSabbac(id) || p.isInvisible()) {
                continue;
            }
            if (HdKit.firstPerson(p)) {
                continue;
            }
            RandomSource r = level.random;
            boolean lit = PassiveConditions.hellfireBlock(level, p.blockPosition(), p.isUnderWater()) == PassiveConditions.Hellfire.NONE;
            double sc = p.getScale();
            float yaw = p.yBodyRot * Mth.DEG_TO_RAD;
            double fx = -Math.sin(yaw), fz = Math.cos(yaw), rx = -Math.cos(yaw), rz = -Math.sin(yaw);
            if (lit && p.tickCount % (dark ? 2 : 4) == 0) {   // lidah api kecil menjilat di bahu & punggung
                double side = r.nextBoolean() ? 1 : -1;
                double sx = p.getX() + rx * side * 0.26 * sc - fx * 0.12 * sc, sz = p.getZ() + rz * side * 0.26 * sc - fz * 0.12 * sc;
                double sy = p.getY() + (1.38 + r.nextDouble() * 0.1) * sc;
                Vfx.flame(sx, sy, sz, (r.nextDouble() - 0.5) * 0.01, 0.02, (r.nextDouble() - 0.5) * 0.01, FIRE, (dark ? 0.085f : 0.06f) * (float) sc, 8);
            }
            if (ShazamClientState.isRaging(id) && p.tickCount % 2 == 0) {   // Gerbang Neraka: raksasa diselubungi api
                HdKit.flames(HdKit.feet(p), 2, 0.7 * sc, 0.1, FIRE, 0.24f * (float) sc, 14);
                if (p.tickCount % 40 == 0) {
                    Vfx.add(new Hd.Haze(HdKit.feetAnchor(p), 1.4 * sc, 3.0 * sc, 8, HEAT, 44, 0.9f));
                }
            }
            if (ShazamClientState.isFlying(id) && !p.onGround() && lit) {   // terbang: jejak api & abu
                Vec3 m = new Vec3(p.getX() - p.xo, p.getY() - p.yo, p.getZ() - p.zo);
                if (m.length() > 0.45) {
                    Vec3 back = HdKit.chest(p).subtract(m.scale(0.6)).add(ShazamFx.randomDir(r).scale(0.3));
                    Vec3 v = m.scale(-0.08);
                    Vfx.flame(back.x, back.y, back.z, v.x, v.y, v.z, FIRE, 0.16f, 10);
                    if (p.tickCount % 3 == 0) {
                        Vfx.cinder(back.x, back.y, back.z, v.x, v.y + 0.01, v.z, ASH, 0.06f, 30, 0.001f);
                    }
                }
            }
            if (ShazamClientState.isCharged(id) && p.tickCount % 2 == 0) {   // Muatan Neraka penuh: api di kedua kepalan
                for (boolean right : new boolean[] {true, false}) {
                    Vec3 h = ShazamPoses.handPos(p, right, 1f);
                    Vfx.flame(h.x, h.y - 0.05, h.z, 0, 0.02, 0, FIRE, 0.06f, 8);
                }
            }
        }
    }
}
