package com.shazammod.client.fx;

import com.shazammod.LintangItems;
import com.shazammod.LintangSkills;
import com.shazammod.PassiveConditions;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamSounds;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Vfx;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.Vec3;

/**
 * Lapisan sinematik Lintang (berbasis sains): eksperimen evolusi, efek skill yang lebih tebal, dan sistem "melemah"
 * (Nether tanpa matahari / radiasi Batu Cryon) yang dibaca oleh pose & layer kulit.
 * 0.35: semua yang terlihat di sini FISIK, ala Superman: gelombang udara, debu, puing, kawah, uap, napas berat, detak
 * jantung, urat di kulit. Nggak ada tiang cahaya, sinar dewa, aliran foton, heliks bercahaya, percikan listrik,
 * butiran berkilau, atau kilatan cahaya dari tubuh. Semua titik masuk tetap memanggil LintangFx dulu, lalu menambah lapisan.
 */
public final class LintangCine {
    static final int WHITE = 0xFFFFFF;
    static final int AIR = 0xF2F6FA;
    static final int AIR_DIM = 0xC8D2DC;
    static final int CRYON = 0x3CFF86;
    static final int CRYON_DARK = 0x0B3D24;
    static final int FROST = 0xD6F4FF;
    static final int ICE = 0x8FDCFF;
    static final int HEAT = 0xFF3A16;
    static final int DUST = 0xC8B696;
    static final int CRACK = 0x2E2620;       // retakan tanah dingin (bukan bara)
    static final int SPARK = 0xF2E8D8;       // percikan benturan keras (batu/baja)

    public static final int COLLAPSE_LEN = 72;
    public static final int EXPERIMENT_LEN = 136;
    public static final int CHARGE_LEN = 92;   // sisa 0.34 (Lintang nggak mengumpulkan cahaya lagi sebelum berubah)
    public static final int IGNITE_LEN = 40;
    private static final long NEVER = Long.MIN_VALUE / 4;

    static final class V {
        float weak;
        float weakO;
        float solar;
        float solarO;
        boolean cryon;
        long collapse = NEVER;
        long lastCollapse = NEVER;
        long experiment = NEVER;
        long recover = NEVER;
        int nextBeat;
        int nextBreath;
    }

    private static final Map<Integer, V> VITALS = new HashMap<>();

    private LintangCine() {
    }

    // ------------------------------------------------------------------ titik masuk (redirect)

    public static void onAnim(AbstractClientPlayer p, ShazamAnim a, Vec3 pos) {
        float boostOld = Vfx.setBoost(LintangFx.BOOST);   // 0.33: lapisan tambahan ikut tebal (HD)
        try {
            onAnim0(p, a, pos);
        } finally {
            Vfx.setBoost(boostOld);
        }
    }

    private static void onAnim0(AbstractClientPlayer p, ShazamAnim a, Vec3 pos) {
        if (a == ShazamAnim.LINTANG_RITE) {
            try {
                startExperiment(p);
            } catch (Throwable ignored) {
            }
            LintangHd.onAnim(p, a, pos);   // 0.34: lapisan HD
            return;
        }
        try {
            if (a == ShazamAnim.LINTANG_FADE && experimentAge(p, 0.0f) >= 0.0f && !ShazamClientState.isTransformed(p.getId())) {
                abortExperiment(p);
                return;
            }
        } catch (Throwable ignored) {
        }
        LintangFx.onAnim(p, a, pos);
        try {
            if (LintangFx.handles(p, a)) extra(p, a, pos);
        } catch (Throwable ignored) {
        }
        try {
            if (LintangFx.handles(p, a)) LintangHd.onAnim(p, a, pos);   // 0.34: lapisan HD di atas semuanya
        } catch (Throwable ignored) {
        }
    }

    public static void tick(ClientLevel level) {
        float boostOld = Vfx.setBoost(LintangFx.BOOST);
        try {
            tick0(level);
        } finally {
            Vfx.setBoost(boostOld);
        }
    }

    private static void tick0(ClientLevel level) {
        LintangFx.tick(level);
        try {
            tickVitals(level);
        } catch (Throwable ignored) {
        }
        LintangHd.tick(level);   // 0.35: riak panas Mode Surya
    }

    public static void clear() {
        LintangFx.clear();
        VITALS.clear();
        LintangHd.clear();
    }

    public static float eyeGlow(AbstractClientPlayer p, float pt) {
        float g = LintangFx.eyeGlow(p, pt);
        try {
            return g * (1.0f - 0.85f * weakness(p, pt));
        } catch (Throwable t) {
            return g;
        }
    }

    /** MagicBolt varian 3 (sisa lama, Lintang nggak memakainya lagi): cukup hantaman tanah biasa. */
    public static void sunStrike(ClientLevel level, Vec3 pos, Ground.Map map, float scale) {
        float boostOld = Vfx.setBoost(LintangFx.BOOST);
        try {
            LintangFx.sunStrike(level, pos, map, scale);
        } finally {
            Vfx.setBoost(boostOld);
        }
    }

    // ------------------------------------------------------------------ kueri untuk pose & layer kulit

    public static float weakness(AbstractClientPlayer p, float pt) {
        V v = VITALS.get(p.getId());
        return v == null ? 0.0f : Mth.lerp(pt, v.weakO, v.weak);
    }

    /** 0-1: urat surya di kulit. 0.35: cuma saat eksperimen (sel tubuh bermutasi), nggak lagi berpendar di bawah matahari. */
    public static float solar(AbstractClientPlayer p, float pt) {
        V v = VITALS.get(p.getId());
        return v == null ? 0.0f : Mth.lerp(pt, v.solarO, v.solar);
    }

    public static boolean cryon(AbstractClientPlayer p) {
        V v = VITALS.get(p.getId());
        return v != null && v.cryon;
    }

    private static float age(AbstractClientPlayer p, long start, float pt, int len) {
        if (start == NEVER) return -1.0f;
        float t = (float) (p.level().getGameTime() - start) + pt;
        return t >= 0.0f && t <= len ? t : -1.0f;
    }

    public static float collapseAge(AbstractClientPlayer p, float pt) {
        V v = VITALS.get(p.getId());
        return v == null ? -1.0f : age(p, v.collapse, pt, COLLAPSE_LEN);
    }

    public static float experimentAge(AbstractClientPlayer p, float pt) {
        V v = VITALS.get(p.getId());
        return v == null ? -1.0f : age(p, v.experiment, pt, EXPERIMENT_LEN);
    }

    /** Sebaran urat per bagian tubuh (kepala, badan, lengan kanan, lengan kiri, kaki kanan, kaki kiri): 0..1. */
    public static float[] spread(AbstractClientPlayer p, float pt) {
        float[] s = {1f, 1f, 1f, 1f, 1f, 1f};
        float e = experimentAge(p, pt);
        if (e >= 0.0f) {
            float k = Mth.clamp((e - 4.0f) / 70.0f, 0.0f, 1.0f);
            s[2] = Mth.clamp(k / 0.18f, 0.0f, 1.0f);
            s[1] = Mth.clamp((k - 0.12f) / 0.25f, 0.0f, 1.0f);
            s[3] = Mth.clamp((k - 0.3f) / 0.22f, 0.0f, 1.0f);
            s[0] = Mth.clamp((k - 0.45f) / 0.25f, 0.0f, 1.0f);
            s[4] = Mth.clamp((k - 0.55f) / 0.25f, 0.0f, 1.0f);
            s[5] = Mth.clamp((k - 0.6f) / 0.25f, 0.0f, 1.0f);
            return s;
        }
        float c = collapseAge(p, pt);
        if (c >= 0.0f) {
            float k = Mth.clamp(c / 26.0f, 0.0f, 1.0f);
            s[1] = Mth.clamp(k / 0.3f, 0.0f, 1.0f);
            s[0] = Mth.clamp((k - 0.2f) / 0.4f, 0.0f, 1.0f);
            s[2] = s[3] = Mth.clamp((k - 0.25f) / 0.45f, 0.0f, 1.0f);
            s[4] = s[5] = Mth.clamp((k - 0.45f) / 0.5f, 0.0f, 1.0f);
        }
        return s;
    }

    private static V vital(AbstractClientPlayer p) {
        V v = VITALS.get(p.getId());
        if (v == null) {
            v = new V();
            VITALS.put(p.getId(), v);
        }
        return v;
    }

    // ------------------------------------------------------------------ alat bantu fisik

    /** Kawah tanpa bara: retakan dingin, puing blok yang terlempar, debu & asap tanah. */
    private static void crater(ClientLevel level, Vec3 at, double radius, int life) {
        Ground.Map g = CineKit.ground(level, at, radius + 1.0);
        if (g == null) return;
        Vec3 c = g.center(at);
        int dust = g.found ? g.dustColor(level, at) : DUST;
        if (g.found) {
            RandomSource r = Vfx.random();
            Vfx.add(new Ground.Cracks(c, g, 6 + (int) (radius * 1.6), (float) radius, 160 + life, 1, CRACK, r.nextLong()));
            Vfx.add(new Ground.Debris(c, g, 8 + (int) (radius * 2.2), 0.14 + radius * 0.025, 0.36 + radius * 0.02, 0.4 + radius * 0.12, 46));
        }
        ShazamFx.dustPuffs(level, c, dust, 10 + (int) (radius * 5.0), radius * 0.6, 0.12 + radius * 0.03);
        ShazamFx.smokeCloud(level, c, dust, 3 + (int) radius, radius * 0.7);
    }

    /** Gelombang udara & dinding debu yang menyapu tanah (lapisan soft, bukan cincin cahaya). */
    private static void airShock(ClientLevel level, Vec3 at, double radius, int life, float strength, boolean onGround) {
        CineKit.shock(level, at, CineKit.UP, radius, onGround ? 0xD8CCB8 : AIR, AIR, life, strength * 0.7f, onGround, true);
    }

    /** Benturan keras tanpa cahaya: udara terpukul (riak), sedikit debu, percikan kalau keras sekali. */
    private static void impact(ClientLevel level, AbstractClientPlayer p, Vec3 at, float s, boolean sparks) {
        Vec3 dir = CineKit.norm(at.subtract(CineKit.chest(p)));
        Vfx.add(new Fx.Ripple(at.subtract(dir.scale(0.2)), dir, 1.4 * s, 0.2, 1.0 * s, 0.1, AIR, 8, 0.6f, true));
        Vfx.add(new Fx.Wave(at, dir, 1.5 * s, 0.12 * s, AIR_DIM, 9, 0.5f, 0.04f, null, true));
        if (sparks) CineKit.sparks(at, (int) (6 * s), SPARK, 0.26 * s, 0.04f, 8, at.y - 1.2);
    }

    // ------------------------------------------------------------------ sistem melemah

    private static void tickVitals(ClientLevel level) {
        long now = level.getGameTime();
        Minecraft mc = Minecraft.getInstance();
        boolean nether = PassiveConditions.inferno(level);
        RandomSource r = level.random;
        Set<Integer> seen = new HashSet<>();
        List<AbstractClientPlayer> players = level.players();
        for (AbstractClientPlayer p : players) {
            try {
                int id = p.getId();
                seen.add(id);
                boolean lin = ShazamClientState.isTransformed(id) && ShazamClientState.isLintang(id);
                V v = VITALS.get(id);
                if (v == null) {
                    if (!lin) continue;
                    v = vital(p);
                }
                boolean local = p == mc.player;
                float target = 0.0f;
                if (lin) {
                    if (local) v.cryon = ShazamClientState.kelam;
                    else if ((p.tickCount + id) % 10 == 0) v.cryon = LintangSkills.kelamAround(level, p, false);
                    if (nether) target = 0.62f;
                    if (v.cryon) target = 1.0f;
                } else {
                    v.cryon = false;
                }
                v.weakO = v.weak;
                v.weak += (target - v.weak) * (target > v.weak ? 0.075f : 0.035f);
                if (Math.abs(target - v.weak) < 0.003f) v.weak = target;

                // 0.35: urat surya cuma muncul saat eksperimen (bukan di bawah matahari / saat berubah)
                float sol = 0.0f;
                float e = (float) (now - v.experiment);
                if (v.experiment != NEVER && e >= 0.0f && e <= EXPERIMENT_LEN) sol = experimentSolar(e);
                sol *= 1.0f - v.weak;
                v.solarO = v.solar;
                v.solar += (sol - v.solar) * 0.25f;

                if (lin && v.weakO < 0.42f && v.weak >= 0.42f) {
                    if (now - v.lastCollapse > 300L) {
                        v.collapse = now;
                        v.lastCollapse = now;
                        collapseFx(level, p, local, v);
                    } else {
                        flinchFx(level, p, local, v);
                    }
                }
                if (lin && v.weakO >= 0.25f && v.weak < 0.25f && target <= 0.0f) {
                    v.recover = now;
                    recoverFx(level, p, local);
                }
                if (lin && v.weak > 0.04f) weakAmbient(level, p, local, v, r);
            } catch (Throwable ignored) {
            }
        }
        VITALS.keySet().removeIf(k -> !seen.contains(k));
        if (mc.player != null && ShazamClientState.isLintang(mc.player.getId())) cryonAmbience(level, mc.player, r);
    }

    private static float experimentSolar(float e) {
        if (e < 14.0f) return 0.15f + 0.35f * (e / 14.0f);
        if (e < 74.0f) return 0.5f + 0.5f * ((e - 14.0f) / 60.0f);
        if (e < 104.0f) return 0.55f + 0.45f * Math.abs(Mth.sin(e * 0.9f));
        if (e < 112.0f) return 1.0f;
        return Math.max(0.2f, 1.0f - (e - 112.0f) / 24.0f);
    }

    /** Ambruk (radiasi Cryon / Nether): tenaga hilang, badan jatuh berlutut, debu di tempatnya jatuh, napas berat. */
    private static void collapseFx(ClientLevel level, AbstractClientPlayer p, boolean local, V v) {
        final boolean cry = v.cryon;
        Vec3 c = CineKit.chest(p);
        CineKit.sound(level, c, ShazamSounds.HEARTBEAT, 1.1f, 0.85f);
        CineKit.sound(level, c, ShazamSounds.POWER_DOWN, 0.8f, 0.6f);
        if (cry) CineKit.sound(level, c, ShazamSounds.KELAM_HUM, 1.0f, 0.75f);
        ShazamFx.schedule(0, 30, (lvl, t) -> {   // napas tersengal (uap dari mulut)
            if (t % 6 != 0) return;
            Vec3 m = CineKit.mouth(p);
            Vec3 l = CineKit.look(p);
            Vfx.smoke(m.x, m.y, m.z, l.x * 0.04, -0.005, l.z * 0.04, cry ? 0xBFD8C8 : 0xD8D2CC, 0.14f, 18);
        });
        ShazamFx.schedule(18, 1, (lvl, t) -> {   // lutut menghantam tanah
            Vec3 f = CineKit.feet(p);
            ShazamFx.dustPuffs(lvl, f, 0x8A7A68, Vfx.count(16), 0.9, 0.12);
            airShock(lvl, f, 2.2, 12, 0.5f, true);
            CineKit.sound(lvl, f, ShazamSounds.BODY_HIT, 0.9f, 0.6f);
            if (CineKit.isLocal(p)) CameraShake.add(0.6f);
        });
        if (local) {
            ScreenFx.vignette(0.8f, cry ? CRYON_DARK : 0x2A1A10, 80);
            CameraShake.add(0.35f);
        }
    }

    private static void flinchFx(ClientLevel level, AbstractClientPlayer p, boolean local, V v) {
        Vec3 c = CineKit.chest(p);
        CineKit.sound(level, c, ShazamSounds.HEARTBEAT, 0.7f, 0.95f);
        if (local) {
            ScreenFx.vignette(0.5f, v.cryon ? CRYON_DARK : 0x2A1A10, 24);
            CameraShake.add(0.2f);
        }
    }

    /** Pulih: berdiri tegak lagi dengan hentakan, udara & debu terdorong dari kakinya. */
    private static void recoverFx(ClientLevel level, AbstractClientPlayer p, boolean local) {
        Vec3 f = CineKit.feet(p);
        CineKit.sound(level, CineKit.chest(p), ShazamSounds.WHOOSH_HEAVY, 0.9f, 0.8f);
        airShock(level, f, 3.0, 14, 0.6f, p.onGround());
        if (p.onGround()) ShazamFx.dustPuffs(level, f, DUST, Vfx.count(10), 0.8, 0.1);
        if (local) CameraShake.add(0.25f);
    }

    /** Selama melemah: napas berat (uap), detak jantung yang terasa, pandangan menggelap. */
    private static void weakAmbient(ClientLevel level, AbstractClientPlayer p, boolean local, V v, RandomSource r) {
        float w = v.weak;
        Vec3 c = CineKit.chest(p);
        if (--v.nextBreath <= 0) {
            v.nextBreath = (int) (48.0f - 18.0f * w);
            Vec3 m = CineKit.mouth(p);
            Vec3 l = CineKit.look(p);
            for (int i = 0; i < 3; i++) {
                Vfx.smoke(m.x, m.y, m.z, l.x * 0.035 + (r.nextDouble() - 0.5) * 0.01, -0.004 + r.nextDouble() * 0.006, l.z * 0.035 + (r.nextDouble() - 0.5) * 0.01,
                        v.cryon ? 0xBFD8C8 : 0xD8D2CC, 0.1f + i * 0.03f, 16 + i * 4);
            }
        }
        if (local && --v.nextBeat <= 0) {
            v.nextBeat = (int) (36.0f - 14.0f * w);
            ScreenFx.vignette(0.2f + 0.35f * w, v.cryon ? CRYON_DARK : 0x301810, 16);
            if (w > 0.55f) CineKit.sound(level, c, ShazamSounds.HEARTBEAT, 0.3f + 0.35f * w, 0.9f);
            CameraShake.add(0.05f * w);
        }
    }

    /** Bijih Batu Cryon di sekitar Lintang berpendar hijau (radioaktif), sumber kelemahannya. */
    private static void cryonAmbience(ClientLevel level, AbstractClientPlayer me, RandomSource r) {
        Block ore = (Block) LintangItems.KELAM_ORE.get();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        int bx = (int) Math.floor(me.getX()), by = (int) Math.floor(me.getY()), bz = (int) Math.floor(me.getZ());
        int n = Vfx.count(140);
        for (int i = 0; i < n; i++) {
            int x = bx + r.nextInt(25) - 12, y = by + r.nextInt(17) - 8, z = bz + r.nextInt(25) - 12;
            m.set(x, y, z);
            if (!level.getBlockState(m).is(ore)) continue;
            double px = x + r.nextDouble(), py = y + r.nextDouble(), pz = z + r.nextDouble();
            Vfx.glint(px, py, pz, CRYON, 0.05f + r.nextFloat() * 0.06f, 10 + r.nextInt(8));
        }
    }

    // ------------------------------------------------------------------ eksperimen evolusi (pengganti ritual)

    private static boolean running(AbstractClientPlayer p, V v, long start) {
        return v.experiment == start && p.isAlive();
    }

    /**
     * Eksperimen di bawah matahari (semua fisik): serum disuntikkan ke lengan, tubuh menyerap sinar matahari (urat di
     * kulit menyebar, udara di sekitar badan memanas & debu berputar), sel bermutasi (kejang, berlutut, detak jantung),
     * lalu di tick 104 kekuatan barunya meledak keluar sebagai gelombang tekanan udara: kawah, puing, debu.
     */
    private static void startExperiment(AbstractClientPlayer p) {
        ClientLevel level = CineKit.level(p);
        final V v = vital(p);
        final long start = level.getGameTime();
        final boolean local = CineKit.isLocal(p);
        v.experiment = start;
        if (local) {
            ScreenFx.cinema(EXPERIMENT_LEN + 6);
            ScreenFx.vignette(0.35f, 0x0A2A3A, 40);
        }
        // 0-14: injeksi serum di lengan (tabung berkilap, bukan cahaya sihir)
        ShazamFx.schedule(0, 16, (lvl, t) -> {
            if (!running(p, v, start)) return;
            Vec3 c = CineKit.chest(p);
            Vec3 side = CineKit.flat(new Vec3(-CineKit.look(p).z, 0.0, CineKit.look(p).x));
            Vec3 arm = c.add(side.x * 0.38, -0.12, side.z * 0.38).add(CineKit.flat(CineKit.look(p)).scale(0.25));
            if (t % 4 == 0) Vfx.glint(arm.x, arm.y, arm.z, WHITE, 0.06f, 4);
            if (t == 6) CineKit.sound(lvl, arm, ShazamSounds.CAPE_SNAP, 0.4f, 1.9f);   // tusukan & desis jarum
        });
        // 14-74: tubuh menyerap sinar matahari: udara di sekitar badan memanas, debu berputar, napas makin cepat
        ShazamFx.schedule(14, 60, (lvl, t) -> {
            if (!running(p, v, start)) return;
            if (t % 9 == 0) CineKit.heatRings(CineKit.feet(p).add(0.0, 0.2, 0.0), 0xFFF4E0, 1.2 + t * 0.012, 16);
            ShazamFx.swirlDust(lvl, p, t);
            if (t % 20 == 10) CineKit.sound(lvl, CineKit.chest(p), ShazamSounds.HEARTBEAT, 0.6f, 0.9f + t * 0.008f);
            if (t % 12 == 6) {
                Vec3 m = CineKit.mouth(p);
                Vec3 l = CineKit.look(p);
                Vfx.smoke(m.x, m.y, m.z, l.x * 0.04, -0.004, l.z * 0.04, 0xD8D2CC, 0.12f, 16);
            }
        });
        // 74-104: mutasi sel (kejang, berlutut, urat berdenyut)
        ShazamFx.schedule(74, 30, (lvl, t) -> {
            if (!running(p, v, start)) return;
            Vec3 c = CineKit.chest(p);
            if (t % 8 == 0) {
                CineKit.sound(lvl, c, ShazamSounds.HEARTBEAT, 0.9f, 1.0f + t * 0.02f);
                if (CineKit.isLocal(p)) {
                    CameraShake.add(0.25f + t * 0.01f);
                    ScreenFx.vignette(0.45f, 0x4A1A08, 10);
                }
            }
            if (t == 6) {
                ShazamFx.dustPuffs(lvl, CineKit.feet(p), DUST, Vfx.count(14), 0.8, 0.1);
                CineKit.sound(lvl, c, ShazamSounds.BODY_HIT, 0.8f, 0.7f);
            }
        });
        // 104: EVOLUSI - kekuatan baru meledak keluar dari tubuh sebagai tekanan udara (bukan cahaya / petir)
        ShazamFx.schedule(104, 1, (lvl, t) -> {
            if (!running(p, v, start)) return;
            evolutionBurst(lvl, p);
        });
        // 106-136: uap panas keluar dari tubuh
        ShazamFx.schedule(106, 30, (lvl, t) -> {
            if (!running(p, v, start)) return;
            Vec3 c = CineKit.chest(p);
            RandomSource r = lvl.random;
            if (t % 2 == 0) {
                double sx = (r.nextDouble() - 0.5) * 0.6, sz = (r.nextDouble() - 0.5) * 0.6;
                Vfx.smoke(c.x + sx, c.y + 0.25, c.z + sz, sx * 0.02, 0.03 + r.nextDouble() * 0.02, sz * 0.02, 0xE8E2D8, 0.18f, 24);
            }
        });
    }

    private static void evolutionBurst(ClientLevel level, AbstractClientPlayer p) {
        Vec3 c = CineKit.chest(p);
        Vec3 f = CineKit.feet(p);
        boolean local = CineKit.isLocal(p);
        airShock(level, f, 10.0, 24, 1f, true);
        Vfx.add(new Fx.Ripple(c, CineKit.UP, 3.0, 0.6, 3.5, 0.25, AIR, 14, 0.6f, true));
        Vfx.add(new Fx.Ripple(c, CineKit.UP.scale(-1.0), 1.2, 0.6, 3.0, 0.3, AIR_DIM, 12, 0.5f, true));
        crater(level, f, 3.4, 40);
        CineKit.sound(level, f, ShazamSounds.EARTH_CRACK, 1.2f, 0.8f);
        if (local) {
            CameraShake.add(1.0f);
            FovKick.punch(0.6f);
        } else {
            ShazamFx.shakeAround(c, 0.6f, 26.0);
        }
    }

    private static void abortExperiment(AbstractClientPlayer p) {
        V v = vital(p);
        v.experiment = NEVER;
        ClientLevel level = CineKit.level(p);
        Vec3 c = CineKit.chest(p);
        ShazamFx.smokeCloud(level, c, 0x6A6A70, 5, 0.6);
        CineKit.sound(level, c, ShazamSounds.POWER_DOWN, 0.9f, 0.9f);
    }

    // ------------------------------------------------------------------ lapisan tambahan per skill

    /**
     * 0.33: lapisan tambahan harus meledak tepat saat gerakan utamanya (sesudah ancang-ancang), bukan saat animasi mulai.
     * Ancang-ancang diambil dari konstanta ShazamAnim yang sama dengan efek aslinya.
     */
    private static void extra(AbstractClientPlayer p, ShazamAnim a, Vec3 pos) {
        int delay = switch (a) {
            case TRANSFORM -> ShazamAnim.LINTANG_SUITUP;
            case REVERT -> ShazamAnim.REVERT_WINDUP;
            case LINTANG_DASH -> ShazamAnim.LESAT_WINDUP;
            case LINTANG_EYES -> ShazamAnim.IRIS_WINDUP;
            case LINTANG_BREATH -> ShazamAnim.FROST_WINDUP;
            case LINTANG_CLAP -> ShazamAnim.SONIC_WINDUP;
            case LINTANG_BARRAGE -> ShazamAnim.BARRAGE_WINDUP;
            case LINTANG_LEAP -> ShazamAnim.LEAP_WINDUP;
            case LINTANG_FLARE -> ShazamAnim.FLARE_WINDUP;
            case LINTANG_RESCUE -> ShazamAnim.RESCUE_WINDUP;
            case HERCULES_THROW -> ShazamAnim.THROW_RELEASE;
            case LINTANG_GUST -> ShazamAnim.FROST_WINDUP;
            case LINTANG_COMBO -> ShazamAnim.COMBO_UPPERCUT;
            case LINTANG_NOVA -> ShazamAnim.SOLAR_NOVA_WINDUP;
            default -> 0;
        };
        if (delay <= 0) {
            extraNow(p, a, pos);
        } else {
            ShazamFx.schedule(delay, 1, (lvl, t) -> {
                if (p.isAlive()) extraNow(p, a, pos);
            });
        }
    }

    private static void extraNow(AbstractClientPlayer p, ShazamAnim a, Vec3 pos) {
        ClientLevel level = CineKit.level(p);
        boolean local = CineKit.isLocal(p);
        V v = vital(p);
        long now = level.getGameTime();
        Vec3 c = CineKit.chest(p);
        Vec3 f = CineKit.feet(p);
        Vec3 l = CineKit.look(p);
        Vec3 at = pos != null ? pos : c;
        switch (a) {
            case TRANSFORM -> {   // kostum terpasang: udara dari putaran menyapu tanah
                if (p.onGround()) airShock(level, f, 6.0, 18, 0.8f, true);
            }
            // 0.38: kawah, gelombang kejut, kerucut uap & kilatan benturan sinematik sekarang di LintangFx (LintangFilm);
            // lapisan ini tinggal kamera, suara, riak panas, dan sisa yang melengkapi
            case LAUNCH -> Vfx.add(new Fx.Cone(f, CineKit.UP.scale(-1.0), 2.6, 0.9, AIR, 10, 0.45f, 2.0, true));
            case LAND_HERO, CRASH -> CineKit.camera(p, f, a == ShazamAnim.CRASH ? 0.8f : 0.45f, 20.0);
            case SONIC_BOOM -> CineKit.camera(p, c, 0.35f, 24.0);
            case LINTANG_DASH -> {
                if (local) ScreenFx.speedLines(0.9f);
            }
            case LINTANG_EYES -> {   // 0.39: riak panas & bara sinar sekarang di LintangHeat (ikut mata yang digambar)
                if (local) ScreenFx.vignette(0.3f, 0x5A1A08, 30);
            }
            case LINTANG_BREATH -> {
                ShazamFx.schedule(0, ShazamAnim.FROST_TICKS, (lvl, t) -> {
                    Vec3 mm = CineKit.mouth(p);
                    Vec3 ll = CineKit.look(p);
                    RandomSource r = lvl.random;
                    int n = Vfx.count(3);
                    for (int i = 0; i < n; i++) {
                        double s = 0.28 + r.nextDouble() * 0.22;
                        Vfx.smoke(mm.x, mm.y, mm.z, ll.x * s + (r.nextDouble() - 0.5) * 0.06, ll.y * s + (r.nextDouble() - 0.5) * 0.05, ll.z * s + (r.nextDouble() - 0.5) * 0.06,
                                i == 0 ? WHITE : FROST, 0.16f + r.nextFloat() * 0.12f, 18 + r.nextInt(8));
                    }
                    if (t % 2 == 0) {   // butir es kecil
                        double s = 0.35 + r.nextDouble() * 0.3;
                        Vfx.shard(mm.x, mm.y, mm.z, ll.x * s, ll.y * s, ll.z * s, ICE, 0.035f, 10, mm.y - 3.0);
                    }
                });
            }
            case LINTANG_CLAP -> CineKit.camera(p, c.add(l.scale(0.7)), 0.6f, 22.0);
            case LINTANG_DAWNPUNCH -> CineKit.camera(p, at, 0.7f, 22.0);   // Tinju Baja
            case LINTANG_LEAP -> Vfx.add(new Fx.Cone(f, CineKit.UP.scale(-1.0), 2.2, 0.8, AIR, 9, 0.4f, 2.0, true));
            case LINTANG_SLAM -> {
                CineKit.camera(p, at, 1.0f, 30.0);
                CineKit.sound(level, at, ShazamSounds.EARTH_CRACK, 1.4f, 0.8f);
            }
            case LINTANG_FLARE -> {   // riak panas yang naik sesudah ledakan (ledakannya di LintangFx & LintangHd)
                ShazamFx.schedule(4, 34, (lvl, t) -> {
                    if (t % 6 == 0) CineKit.heatRings(CineKit.chest(p), 0xFFF0E0, 2.0 + t * 0.12, 14);
                });
                CineKit.camera(p, c, 1.2f, 32.0);
            }
            case LINTANG_CALL -> ShazamFx.schedule(0, 40, (lvl, t) -> {   // panas berlebih keluar dari badan
                if (t % 8 == 0) CineKit.heatRings(CineKit.feet(p).add(0.0, 0.1, 0.0), 0xFFF4E0, 1.6, 14);
            });
            case LINTANG_LANCE -> {   // sinar panas singkat: asap dari titik yang terbakar
                ShazamFx.smokeCloud(level, at.subtract(0.0, 0.6, 0.0), 0x6A6058, 2, 0.3);
            }
            case LINTANG_FADE -> {
                if (collapseAge(p, 0.0f) < 0.0f) flinchFx(level, p, local, v);
            }
            case LINTANG_RETURN -> {
                v.collapse = NEVER;
                recoverFx(level, p, local);
            }
            case LINTANG_NOVA -> {   // 0.37 Ledakan Surya: gelombang udara & dinding debu raksasa, kawah, riak panas
                Ground.Map g = CineKit.ground(level, f, 22.0);
                boolean grounded = g != null && g.found;
                airShock(level, grounded ? f : c, 22.0, 40, 1f, grounded);
                if (grounded) crater(level, f, 7.0, 80);
                ShazamFx.schedule(4, 60, (lvl, t) -> {
                    if (t % 6 == 0) CineKit.heatRings(f.add(0.0, 0.2, 0.0), 0xFFF0E0, 3.0 + t * 0.15, 16);
                });
                CineKit.camera(p, c, 1.6f, 48.0);
            }
            case LINTANG_GUST -> CineKit.camera(p, c, 0.15f, 12.0);   // 0.37 Napas Topan
            case LINTANG_COMBO -> CineKit.camera(p, at, 0.4f, 20.0);   // 0.37 Kombo Langit: uppercut
            case HERCULES_THROW -> {   // 0.36 Angkat & Lempar: debu tersapu di kaki saat melempar
                if (p.onGround()) ShazamFx.dustPuffs(level, f, DUST, Vfx.count(10), 0.9, 0.18);
            }
            case HERCULES_IMPACT -> CineKit.camera(p, at, 0.6f, 26.0);   // musuh yang dilempar menghantam
            case LINTANG_KELAM -> {
                v.cryon = true;
                if (now - v.lastCollapse > 300L) {
                    v.collapse = now;
                    v.lastCollapse = now;
                    v.weak = Math.max(v.weak, 0.45f);
                    collapseFx(level, p, local, v);
                } else {
                    flinchFx(level, p, local, v);
                }
            }
            default -> {
                // SUMMON, REVERT, KNOCKOUT, HERO_CALL, PULSE: cukup efek di LintangFx & LintangHd
            }
        }
    }
}
