package com.shazammod.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.ShazamMod;
import com.shazammod.client.fx.LintangCine;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Perubahan fisik HD (tekstur 512x512 di atas UV kulit 64x64):
 * - melemah: kulit pucat, lingkar mata gelap, urat hijau Cryon berdenyut (atau urat redup di Nether);
 * - Mode Surya / eksperimen: urat surya keemasan menyebar dari titik suntikan ke seluruh tubuh.
 */
public class CryonSkinLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation PALE = ShazamMod.id("textures/entity/lintang/cryon_pale.png");
    private static final ResourceLocation VEINS = ShazamMod.id("textures/entity/lintang/cryon_veins.png");
    private static final ResourceLocation SOLAR = ShazamMod.id("textures/entity/lintang/solar_veins.png");
    private static final int FULLBRIGHT = 15728880;

    public CryonSkinLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buffers, int light, AbstractClientPlayer p, float limbSwing, float limbAmount,
                       float pt, float ageInTicks, float netHeadYaw, float headPitch) {
        try {
            if (p.isInvisible()) return;
            float weak = LintangCine.weakness(p, pt);
            float solar = LintangCine.solar(p, pt);
            if (weak < 0.02f && solar < 0.02f) return;
            PlayerModel<AbstractClientPlayer> m = getParentModel();
            float[] spread = LintangCine.spread(p, pt);
            if (weak >= 0.02f) {
                int alpha = (int) (Mth.clamp(weak, 0.0f, 1.0f) * 0.62f * 255.0f);
                VertexConsumer pale = buffers.getBuffer(RenderType.entityTranslucent(PALE));
                parts(m, ps, pale, light, alpha, 0xFFFFFF, null);
                boolean cry = LintangCine.cryon(p);
                float pulse = 0.55f + 0.45f * (0.5f + 0.5f * Mth.sin(ageInTicks * (cry ? 0.24f : 0.12f)));
                float k = weak * pulse * (cry ? 1.0f : 0.4f);
                VertexConsumer veins = buffers.getBuffer(RenderType.eyes(VEINS));
                parts(m, ps, veins, FULLBRIGHT, 255, scale(cry ? 0x3CFF86 : 0xB86A2A, k), spread);
            }
            if (solar >= 0.02f) {
                VertexConsumer gold = buffers.getBuffer(RenderType.eyes(SOLAR));
                parts(m, ps, gold, FULLBRIGHT, 255, scale(0xFFC660, Mth.clamp(solar, 0.0f, 1.0f)), spread);
            }
        } catch (Throwable ignored) {
        }
    }

    private static int scale(int rgb, float k) {
        int r = (int) (((rgb >> 16) & 255) * k);
        int g = (int) (((rgb >> 8) & 255) * k);
        int b = (int) ((rgb & 255) * k);
        return (Mth.clamp(r, 0, 255) << 16) | (Mth.clamp(g, 0, 255) << 8) | Mth.clamp(b, 0, 255);
    }

    private static void parts(PlayerModel<AbstractClientPlayer> m, PoseStack ps, VertexConsumer vc, int light, int alpha, int rgb, float[] spread) {
        one(m.hat, m.head, ps, vc, light, alpha, rgb, spread == null ? 1.0f : spread[0]);
        one(m.jacket, m.body, ps, vc, light, alpha, rgb, spread == null ? 1.0f : spread[1]);
        one(m.rightSleeve, m.rightArm, ps, vc, light, alpha, rgb, spread == null ? 1.0f : spread[2]);
        one(m.leftSleeve, m.leftArm, ps, vc, light, alpha, rgb, spread == null ? 1.0f : spread[3]);
        one(m.rightPants, m.rightLeg, ps, vc, light, alpha, rgb, spread == null ? 1.0f : spread[4]);
        one(m.leftPants, m.leftLeg, ps, vc, light, alpha, rgb, spread == null ? 1.0f : spread[5]);
    }

    private static void one(ModelPart outer, ModelPart base, PoseStack ps, VertexConsumer vc, int light, int alpha, int rgb, float k) {
        if (k <= 0.01f) return;
        int color;
        if (alpha < 255) {
            color = ((int) (alpha * k) << 24) | (rgb & 0xFFFFFF);
        } else {
            color = 0xFF000000 | scale(rgb, k);
        }
        ModelPart part = outer != null && outer.visible ? outer : base;
        if (part == null || !base.visible) return;
        part.render(ps, vc, light, OverlayTexture.NO_OVERLAY, color);
    }
}
