package com.shazammod.client.fx;

import java.util.HashMap;
import java.util.Map;

import com.shazammod.HelionSkills;
import com.shazammod.PassiveConditions;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamSounds;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Hd;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * 0.43 Efek Projek Helion-6: RADIASI Cryon, bukan sihir & bukan matahari. Semua yang terlihat hijau radioaktif: urat & jalur
 * kostum yang menyala, sinar mata Cryon berpilin, butiran radiasi yang tersedot lalu meledak, retakan tanah yang membara
 * hijau, kristal Cryon yang pecah, dan saat terkena matahari: kulit berasap, bara kecil, urat yang meredup & berkedip.
 * Dipicu animasi dari server (ShazamAnim.HELION_* dan animasi umum seperti TRANSFORM/LAUNCH saat juaranya Helion-6).
 */
public final class HelionFx {
    /** Penguat sinematik (bloom, butiran lebih padat/besar/lama, mode HD), sama dengan Lintang & Sabbac. */
    public static final float BOOST = 1.5f;

    private HelionFx() {}

    // ======= Warna (RGB) =======
    public static final int CRYON = 0x46FF8C;        // radiasi Cryon
    public static final int CRYON_HOT = 0xDCFFE8;    // inti putih kehijauan
    public static final int CRYON_MID = 0x24D468;
    public static final int CRYON_DEEP = 0x0B5A2C;
    public static final int CRYON_DARK = 0x05200F;
    public static final int SMOKE = 0x3E4440;
    private static final Vec3 UP = new Vec3(0, 1, 0);

    private static final Map<Integer, long[]> EYES = new HashMap<>();   // Emisi Cryon: {mulai, sinar mulai, selesai}
    private static final Map<Integer, Long> SURGE = new HashMap<>();    // Lonjakan Cryon: selesai
    private static final Map<Integer, Long> NOVA = new HashMap<>();     // Supernova-6: mulai menyerap
    private static final Map<Integer, Long> INHALE = new HashMap<>();   // Hirup Cryon: mulai
    private static final Map<Integer, Long> RITE = new HashMap<>();     // eksperimen: mulai
    private static final Map<Integer, Long> PULSE = new HashMap<>();    // Denyut Cryon terakhir

    public static void clear() {
        EYES.clear();
        SURGE.clear();
        NOVA.clear();
        INHALE.clear();
        RITE.clear();
        PULSE.clear();
    }

    /** Animasi ini diurus HelionFx (ShazamFx & ChampionFx melewatinya). */
    public static boolean handles(AbstractClientPlayer caster, ShazamAnim anim) {
        return switch (anim) {
            case SUMMON, TRANSFORM, REVERT, KNOCKOUT, LAUNCH, LAND_HERO, CRASH, SONIC_BOOM, HERO_CALL ->
                    ShazamClientState.isHelion(caster.getId());
            default -> anim.name().startsWith("HELION_");
        };
    }

    public static void onAnim(AbstractClientPlayer caster, ShazamAnim anim, Vec3 pos) {
        if (!handles(caster, anim)) {
            return;
        }
        float boostOld = Vfx.setBoost(BOOST);
        try {
            onAnim0(caster, anim, pos);
        } catch (RuntimeException ignored) {
            // efek nggak boleh bikin game crash
        } finally {
            Vfx.setBoost(boostOld);
        }
    }

    private static void onAnim0(AbstractClientPlayer caster, ShazamAnim anim, Vec3 pos) {
        boolean self = caster == Minecraft.getInstance().player;
        switch (anim) {
            case SUMMON -> { }
            case TRANSFORM -> transform(caster, self);
            case REVERT -> revert(caster);
            case KNOCKOUT -> knockout(caster, self);
            case LAUNCH -> launch(caster);
            case LAND_HERO -> landing(caster, self, false);
            case CRASH -> landing(caster, self, true);
            case SONIC_BOOM -> sonicBoom(caster, self);
            case HERO_CALL -> heroCall(pos);
            case HELION_RITE -> rite(caster, self);
            case HELION_DASH -> dash(caster, pos, self);
            case HELION_DASH_HIT -> hit(pos, 1.0f);
            case HELION_EYES -> eyes(caster, self);
            case HELION_QUAKE -> quake(caster, self);
            case HELION_NOVA -> novaCharge(caster, self);
            case HELION_NOVA_BLAST -> novaBlast(caster, pos, self);
            case HELION_INHALE -> inhale(caster, self);
            case HELION_PULSE -> pulse(caster, self);
            case HELION_PUNCH -> hit(pos, 0.6f);
            case HELION_CRYON_PUNCH -> cryonPunch(caster, pos, self);
            case HELION_DEFLECT -> deflect(pos);
            case HELION_SUN_BURN -> sunBurn(caster, self);
            case HELION_SUN_CLEAR -> sunClear(caster, self);
            case HELION_COLLAPSE -> collapse(caster, self);
            default -> { }
        }
    }

    // ------------------------------------------------------------------ bantu

    private static void schedule(int delay, int duration, ShazamFx.Step step) {
        ShazamFx.schedule(delay, duration, step);
    }

    private static Vec3 chest(AbstractClientPlayer p) {
        return p.position().add(0, p.getBbHeight() * 0.62, 0);
    }

    private static boolean firstPerson(AbstractClientPlayer p) {
        return HdKit.firstPerson(p);
    }

    private static boolean nearGround(ClientLevel level, AbstractClientPlayer p, double depth) {
        Vec3 f = p.position().add(0, 0.2, 0);
        BlockHitResult hit = level.clip(new ClipContext(f, f.subtract(0, depth, 0), ClipContext.Block.COLLIDER,
                ClipContext.Fluid.ANY, p));
        return hit.getType() != HitResult.Type.MISS;
    }

    /** Sedang di bawah matahari? Pemain sendiri: kata server (Batu Cryon di dekatnya menetralkan); pemain lain: dihitung sendiri. */
    static boolean inSun(AbstractClientPlayer p) {
        if (p == Minecraft.getInstance().player) {
            return ShazamClientState.sun && !ShazamClientState.kelam;
        }
        return PassiveConditions.underSun(p.level(), p.blockPosition());
    }

    static boolean surging(AbstractClientPlayer p) {
        Long until = SURGE.get(p.getId());
        return until != null && until > p.level().getGameTime();
    }

    /** Titik kedua mata, mengikuti arah pandang. Di sudut pandang orang pertama digeser ke depan-bawah layar. */
    static Vec3[] eyePoints(AbstractClientPlayer p, float pt) {
        Vec3 look = p.getViewVector(pt);
        Vec3 eye = p.getEyePosition(pt);
        Vec3 right = look.cross(UP);
        right = right.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : right.normalize();
        Vec3 up = right.cross(look).normalize();
        boolean fp = firstPerson(p);
        Vec3 base = fp ? eye.add(look.scale(0.6)).add(up.scale(-0.22)) : eye.add(look.scale(0.27)).add(up.scale(0.03));
        double sep = fp ? 0.17 : 0.115;
        return new Vec3[] {base.add(right.scale(sep)), base.subtract(right.scale(sep))};
    }

    /** Ujung sinar di blok pertama sepanjang arah pandang. */
    static Vec3 beamEnd(AbstractClientPlayer p, float pt, double maxDist) {
        Vec3 eye = p.getEyePosition(pt);
        Vec3 far = eye.add(p.getViewVector(pt).scale(maxDist));
        BlockHitResult hit = p.level().clip(new ClipContext(eye, far, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        return hit.getType() == HitResult.Type.MISS ? far : hit.getLocation();
    }

    /** Ledakan di tanah: retakan membara hijau, puing blok aslinya, semburan tanah, dinding & kepulan debu, noda radiasi. */
    private static void groundBurst(ClientLevel level, Vec3 at, double size, boolean glow) {
        Ground.Map g = ShazamFx.ground(level, at, 2.5 + size * 2.4);
        if (g == null || !g.found) {
            return;
        }
        Vec3 c = g.center(at);
        int dust = g.dustColor(level, at);
        RandomSource r = level.random;
        Vfx.add(new Ground.Cracks(c, g, 7 + (int) (size * 3.5), (float) (1.3 + size * 1.4), 200 + (int) (size * 30),
                glow ? 80 + (int) (size * 20) : 1, glow ? CRYON : 0x2E2620, r.nextLong()));
        Vfx.add(new Ground.Debris(c, g, 8 + (int) (size * 7.0), 0.14 + size * 0.09, 0.32 + size * 0.13, 0.55 + size * 0.32, 56));
        LintangFilm.dirtSprays(c, (int) (4 + size * 5), 0.22 + size * 0.07, dust);
        Vfx.add(new Fx.Wave(c, UP, 2.2 + size * 2.3, 0.8 + size * 0.35, dust, 30, 0.62f, 0f, g, true));
        ShazamFx.dustPuffs(level, c, dust, (int) (10 + size * 9), 0.7 + size * 0.55, 0.12 + size * 0.05);
        ShazamFx.smokeCloud(level, c, dust, (int) (5 + size * 4), 0.8 + size * 0.8);
        if (glow) {
            Vfx.add(new RadGlow(c, 0.8 + size * 0.8, 120 + (int) (size * 30), g));
        }
    }

    /** Ledakan radiasi besar dari dada (berubah wujud, eksperimen berhasil). */
    private static void bigBurst(ClientLevel level, AbstractClientPlayer caster, float scale, boolean self) {
        Vec3 c = chest(caster);
        Vec3 f = caster.position();
        CineKit.burst(c, 2.6f * scale, CRYON, CRYON_HOT, 16, 1f);
        Vfx.add(new Hd.Nova(c, 3.2 * scale, CRYON_HOT, CRYON, CRYON_DEEP, 0x2A3430, 28, 0.85f, false));
        Vfx.add(new Hd.Pressure(c, UP, 6.5 * scale, 1.0, CRYON, 16, 0.9f, true));
        CineKit.shock(level, f.add(0, 0.1, 0), UP, 9.5 * scale, CRYON, CRYON_HOT, 18, 1f, true);
        Vfx.add(new Fx.Pillar(f, 10.0 * scale, 1.3f, CRYON, 20));
        CineKit.sparks(c, 40, CRYON, 0.55, 0.09f, 16, f.y);
        HdKit.shards(c, 16, 0.45, CRYON, 0.18f, 26, f.y);
        groundBurst(level, f, 1.6 * scale, true);
        if (self) {
            CameraShake.add(0.7f);
            FovKick.punch(0.5f);
            ScreenFlash.flash(0.55f, 0xC8FFD8);
            ScreenFx.vignette(0.5f, 0x022A12, 14);
        } else {
            ShazamFx.shakeAround(c, 0.5f, 24);
        }
    }

    // ------------------------------------------------------------------ dibaca lapisan render

    /** 0-1: mata menyala hijau terang (Emisi Cryon, Hirup Cryon, Supernova, Lonjakan, eksperimen). */
    public static float eyeGlow(AbstractClientPlayer p, float pt) {
        float now = p.level().getGameTime() + pt;
        float g = 0f;
        long[] e = EYES.get(p.getId());
        if (e != null) {
            if (now < e[1]) {
                g = Mth.clamp((now - e[0]) / Math.max(1f, e[1] - e[0]), 0f, 1f);
            } else if (now < e[2] + 3) {
                g = 1f;
            }
        }
        Long in = INHALE.get(p.getId());
        if (in != null) {
            float t = now - in - ShazamAnim.HELION_INHALE_WINDUP;
            if (t > -6f && t < 24f) {
                g = Math.max(g, 1f - Math.abs(t) / 24f);
            }
        }
        Long nova = NOVA.get(p.getId());
        if (nova != null) {
            g = Math.max(g, Mth.clamp((now - nova) / ShazamAnim.HELION_NOVA_WINDUP, 0f, 1f));
        }
        if (surging(p)) {
            g = Math.max(g, 0.7f);
        }
        Long rite = RITE.get(p.getId());
        if (rite != null) {
            float t = now - rite;
            if (t > 60f && t < ShazamAnim.HELION_RITE_TICKS) {
                g = Math.max(g, Mth.clamp((t - 60f) / 50f, 0f, 1f));
            }
        }
        return g;
    }

    /** 0-1+: terang jalur radiasi di kostum. Redup & berkedip di bawah matahari, membara saat Lonjakan / skill. */
    public static float veinGlow(AbstractClientPlayer p, float pt) {
        float age = p.tickCount + pt;
        float k;
        if (inSun(p)) {
            k = 0.24f + 0.1f * Mth.sin(age * 0.9f) * Mth.sin(age * 0.23f) + (((int) age / 3) % 7 == 0 ? 0.14f : 0f);
        } else {
            k = 0.72f + 0.14f * Mth.sin(age * 0.12f);
        }
        if (surging(p)) {
            k = Math.max(k, 0.95f + 0.1f * Mth.sin(age * 0.7f));
        }
        k = Math.max(k, eyeGlow(p, pt) * 0.95f);
        Long pulse = PULSE.get(p.getId());
        if (pulse != null) {
            float t = p.level().getGameTime() + pt - pulse;
            if (t >= 0f && t < 12f) {
                k = Math.max(k, 1f - t / 12f * 0.3f);
            }
        }
        return k;
    }

    /** 0-1: urat Cryon di wajah. */
    public static float faceVeins(AbstractClientPlayer p, float pt) {
        float age = p.tickCount + pt;
        float k = inSun(p) ? 0.1f + 0.08f * Mth.sin(age * 1.3f) : 0.3f;
        k = Math.max(k, eyeGlow(p, pt) * 0.8f);
        return surging(p) ? Math.max(k, 0.85f) : k;
    }

    /** 0-1: kulit pucat terbakar saat di bawah matahari. */
    public static float sunPale(AbstractClientPlayer p, float pt) {
        return inSun(p) ? 0.55f + 0.08f * Mth.sin((p.tickCount + pt) * 0.2f) : 0f;
    }

    /** 0-1: urat radiasi yang menjalar di kulit manusia selama Eksperimen Proyek Helion-6. */
    public static float riteVeins(AbstractClientPlayer p, float pt) {
        Long start = RITE.get(p.getId());
        if (start == null) {
            return 0f;
        }
        float t = p.level().getGameTime() + pt - start;
        int strike = ShazamAnim.HELION_RITE_STRIKE;
        if (t < 8f) {
            return 0f;
        }
        float spread = Mth.clamp((t - 8f) / 80f, 0f, 1f);
        float k = spread * (0.62f + 0.38f * Mth.sin(t * (t > 80f ? 0.9f : 0.35f)));
        if (t > strike) {
            k = Math.max(0f, 1f - (t - strike) / 30f);
        }
        return k;
    }

    // ------------------------------------------------------------------ tiap tick

    public static void tick(ClientLevel level) {
        long now = level.getGameTime();
        EYES.values().removeIf(e -> now > e[2] + 5);
        SURGE.values().removeIf(t -> now > t + 5);
        NOVA.values().removeIf(t -> now > t + ShazamAnim.HELION_NOVA_WINDUP + 10);
        INHALE.values().removeIf(t -> now > t + 80);
        RITE.values().removeIf(t -> now > t + ShazamAnim.HELION_RITE_TICKS + 40);
        PULSE.values().removeIf(t -> now > t + 20);
        for (AbstractClientPlayer p : level.players()) {
            int id = p.getId();
            if (!ShazamClientState.isTransformed(id) || !ShazamClientState.isHelion(id) || p.isInvisible()) {
                continue;
            }
            float old = Vfx.setBoost(BOOST);
            try {
                ambient(level, p);
            } catch (RuntimeException ignored) {
                // efek nggak boleh bikin game crash
            } finally {
                Vfx.setBoost(old);
            }
        }
    }

    /** Terus-menerus: di bawah matahari kulit berasap & memercikkan bara; di tempat gelap radiasi hijau samar naik dari tubuh. */
    private static void ambient(ClientLevel level, AbstractClientPlayer p) {
        boolean fp = firstPerson(p);
        RandomSource r = level.random;
        double h = p.getBbHeight();
        if (inSun(p)) {
            if (!fp && p.tickCount % 2 == 0) {
                double a = r.nextDouble() * Math.PI * 2.0, rr = p.getBbWidth() * 0.45;
                Vfx.smoke(p.getX() + Math.cos(a) * rr, p.getY() + 0.3 + r.nextDouble() * h * 0.8, p.getZ() + Math.sin(a) * rr,
                        Math.cos(a) * 0.01, 0.03 + r.nextDouble() * 0.025, Math.sin(a) * 0.01, SMOKE,
                        0.2f + r.nextFloat() * 0.16f, 24 + r.nextInt(12));
            }
            if (!fp && r.nextInt(4) == 0) {
                Vfx.ember(p.getX() + (r.nextDouble() - 0.5) * 0.6, p.getY() + 0.4 + r.nextDouble() * h * 0.7,
                        p.getZ() + (r.nextDouble() - 0.5) * 0.6, 0, 0.04, 0, 0.05f, 14);
            }
            if (fp && p.tickCount % 3 == 0) {   // asap tipis naik di bawah pandangan
                Vec3 e = p.getEyePosition(1f).add(p.getViewVector(1f).scale(0.9));
                Vfx.smoke(e.x + (r.nextDouble() - 0.5) * 0.9, e.y - 0.75, e.z + (r.nextDouble() - 0.5) * 0.9, 0, 0.04, 0, SMOKE,
                        0.16f, 16);
            }
            if (p == Minecraft.getInstance().player && p.tickCount % 40 == 0) {
                ScreenFx.vignette(0.3f, 0xFFF0C0, 14);   // silau & panas matahari
            }
        } else if (!fp && p.tickCount % (surging(p) ? 1 : 4) == 0) {
            double a = r.nextDouble() * Math.PI * 2.0, rr = p.getBbWidth() * (0.4 + r.nextDouble() * 0.3);
            Vfx.mote(p.getX() + Math.cos(a) * rr, p.getY() + 0.2 + r.nextDouble() * h * 0.9, p.getZ() + Math.sin(a) * rr,
                    0, 0.02 + r.nextDouble() * 0.02, 0, CRYON, 0.07f + r.nextFloat() * 0.05f, 18 + r.nextInt(10));
        }
    }

    /** Muatan Cryon penuh (dari ChampionFx): percikan radiasi menari di kedua kepalan. */
    static void chargedFists(ClientLevel level, AbstractClientPlayer p) {
        float old = Vfx.setBoost(BOOST);
        try {
            if (p.tickCount % 2 != 0 || firstPerson(p)) {
                return;
            }
            RandomSource r = level.random;
            for (boolean right : new boolean[] {true, false}) {
                Lightning.Anchor hand = pt -> ShazamPoses.handPos(p, right, pt);
                Vec3 off = ShazamFx.randomDir(r).scale(0.25 + r.nextDouble() * 0.2);
                Vfx.add(new Lightning.Arc(hand, pt -> hand.at(pt).add(off), CRYON, 0.03f, 2, 1, 0, 0.35));
            }
            if (p.tickCount % 6 == 0) {
                Vec3 h = ShazamPoses.handPos(p, r.nextBoolean(), 1f);
                Vfx.glint(h.x, h.y, h.z, CRYON, 0.22f, 6);
            }
        } finally {
            Vfx.setBoost(old);
        }
    }

    /** Jejak terbang (dari ShazamFx.flightTrail): uap tipis + butiran radiasi hijau di belakang lintasan. */
    static void flightTrail(ClientLevel level, AbstractClientPlayer p, float speed) {
        float old = Vfx.setBoost(BOOST);
        try {
            if (speed < 0.9f || p.isInvisible()) {
                return;
            }
            Vec3 motion = new Vec3(p.getX() - p.xo, p.getY() - p.yo, p.getZ() - p.zo);
            if (motion.lengthSqr() < 1.0E-4) {
                return;
            }
            RandomSource r = level.random;
            Vec3 back = motion.normalize().scale(-1);
            float k = Mth.clamp((speed - 0.9f) / 1.6f, 0f, 1f);
            Vec3 c = p.position().add(0, 0.9 * p.getScale(), 0);
            if (r.nextInt(2) == 0) {
                Vec3 q = c.add(back.scale(0.8 + r.nextDouble() * 0.6)).add(ShazamFx.randomDir(r).scale(0.25));
                Vfx.smoke(q.x, q.y, q.z, back.x * 0.04, back.y * 0.04, back.z * 0.04, 0xEEF4F0, 0.26f + 0.3f * k, 10 + r.nextInt(6));
            }
            for (int i = 0, n = Vfx.count(1 + 2 * k); i < n; i++) {
                Vec3 q = c.add(back.scale(0.5 + r.nextDouble() * 2.0)).add(ShazamFx.randomDir(r).scale(0.35));
                Vfx.mote(q.x, q.y, q.z, back.x * 0.05, back.y * 0.05, back.z * 0.05, CRYON, 0.1f + 0.08f * k, 10 + r.nextInt(6));
            }
            if (k > 0.55f && p.tickCount % 5 == 0) {
                LintangFilm.windStreaks(c.subtract(back.scale(2.0)), c.add(back.scale(6.0)), 8, 6);
            }
        } finally {
            Vfx.setBoost(old);
        }
    }

    // ------------------------------------------------------------------ berubah wujud

    /**
     * Berubah wujud (klip Helion TRANSFORM, HELION_SUITUP tick): radiasi Cryon tersedot ke dada dari segala arah, tanah retak
     * membara hijau, badan menegang & bergetar, mata menyala, lalu radiasinya MELEDAK keluar dan kostum terbentuk.
     */
    private static void transform(AbstractClientPlayer caster, boolean self) {
        int suit = ShazamAnim.HELION_SUITUP;
        schedule(0, suit, (level, t) -> {
            Vec3 c = chest(caster);
            float k = t / (float) suit;
            RandomSource r = level.random;
            for (int i = 0, n = Vfx.count(3 + k * 6); i < n; i++) {
                Vec3 d = ShazamFx.randomDir(r);
                Vec3 p = c.add(d.scale(2.2 + r.nextDouble() * 2.5 * (1 - k * 0.5)));
                Vec3 v = c.subtract(p).scale(0.11 + 0.05 * k);
                Vfx.streak(p.x, p.y, p.z, v.x, v.y, v.z, r.nextInt(3) == 0 ? CRYON_HOT : CRYON, 0.05f + 0.04f * k, 9);
            }
            if (t == 2) {
                Vfx.add(new Hd.Haze(Lightning.Anchor.on(caster, 0, 0, 0), 0.7, 2.2, 6, CRYON_DEEP, suit + 6, 0.6f));
                Ground.Map g = ShazamFx.ground(level, caster.position(), 4.5);
                if (g != null && g.found) {
                    Vfx.add(new Ground.Cracks(g.center(caster.position()), g, 8, 3.6f, 120, 60, CRYON, r.nextLong()));
                }
            }
            if (t == suit - 5) {   // mata menyala
                for (Vec3 e : eyePoints(caster, 1f)) {
                    Vfx.add(new Fx.Flash(e, 0.35f, CRYON_HOT, 8, 1f));
                }
                CineFx.flare(caster.getEyePosition(1f), CRYON, 2.4f, 0.12f, 0.9f, 10);
            }
            if (self && t % 4 == 0) {
                ScreenFx.vignette(0.25f + 0.35f * k, 0x02240F, 6);
                CameraShake.add(0.04f + 0.05f * k);
            }
        });
        schedule(suit, 1, (level, t) -> bigBurst(level, caster, 1f, self));
        if (self) {
            schedule(suit + 6, 1, (level, t) -> ScreenFx.titleKey("title.shazammod.helion", CRYON, 70, 0));
        }
    }

    /** Kembali jadi manusia: radiasi padam, butiran hijau terlepas dari tubuh lalu memudar. */
    private static void revert(AbstractClientPlayer caster) {
        schedule(1, ShazamAnim.REVERT_WINDUP + 4, (level, t) -> {
            RandomSource r = level.random;
            for (int i = 0, n = Vfx.count(4); i < n; i++) {
                double a = r.nextDouble() * Math.PI * 2.0;
                Vfx.mote(caster.getX() + Math.cos(a) * 0.35, caster.getY() + r.nextDouble() * 1.8, caster.getZ() + Math.sin(a) * 0.35,
                        Math.cos(a) * 0.03, 0.03 + r.nextDouble() * 0.03, Math.sin(a) * 0.03, CRYON, 0.1f, 20);
            }
        });
        schedule(ShazamAnim.REVERT_WINDUP, 1, (level, t) -> {
            Vfx.add(new Fx.Wave(caster.position().add(0, 0.1, 0), UP, 3.0, 0.22, CRYON_DEEP, 12, 0.5f, 0.04f, null));
            ShazamFx.dustPuffs(level, caster.position(), 0xA89A86, 8, 0.9, 0.1);
        });
    }

    /** Terhantam sampai lepas wujud: radiasi tercabut keluar dari dada. */
    private static void knockout(AbstractClientPlayer caster, boolean self) {
        schedule(0, 1, (level, t) -> {
            Vec3 c = chest(caster);
            Vfx.add(new Fx.Flash(c, 1.8f, CRYON, 8, 0.8f));
            CineKit.sparks(c, 24, CRYON, 0.45, 0.07f, 14, caster.getY());
            HdKit.shards(c, 10, 0.35, CRYON, 0.14f, 22, caster.getY());
            groundBurst(level, caster.position(), 0.9, false);
            if (self) {
                CameraShake.add(0.7f);
                ScreenFx.vignette(0.4f, 0x081A0C, 16);
            }
        });
    }

    // ------------------------------------------------------------------ terbang

    private static void launch(AbstractClientPlayer caster) {
        schedule(0, 1, (level, t) -> {
            Vec3 f = caster.position();
            if (!nearGround(level, caster, 2.5)) {
                return;
            }
            groundBurst(level, f, 0.8, true);
            CineKit.shock(level, f.add(0, 0.12, 0), UP, 5.5, CRYON, CRYON_HOT, 14, 0.75f, true);
        });
    }

    private static void landing(AbstractClientPlayer caster, boolean self, boolean crash) {
        schedule(0, 1, (level, t) -> {
            Vec3 f = caster.position();
            groundBurst(level, f, crash ? 2.6 : 1.4, true);
            CineKit.shock(level, f.add(0, 0.12, 0), UP, crash ? 9.0 : 5.5, CRYON, CRYON_HOT, crash ? 22 : 16, crash ? 1f : 0.8f, true);
            Vfx.add(new Fx.Flash(f.add(0, 0.4, 0), crash ? 2.0f : 1.2f, CRYON_HOT, 5, 0.9f));
            if (self) {
                CameraShake.add(crash ? 0.75f : 0.5f);
                FovKick.punch(crash ? 0.5f : 0.3f);
            }
        });
    }

    private static void sonicBoom(AbstractClientPlayer caster, boolean self) {
        schedule(0, 1, (level, t) -> {
            Vec3 motion = new Vec3(caster.getX() - caster.xo, caster.getY() - caster.yo, caster.getZ() - caster.zo);
            Vec3 dir = motion.lengthSqr() > 1.0E-4 ? motion.normalize() : caster.getViewVector(1f);
            Vec3 c = caster.position().add(0, 0.9, 0);
            LintangFilm.vaporCone(c, dir, 1.2);
            Vfx.add(new Fx.Ripple(c, dir.scale(-1), 6.0, 0.6, 3.4, 0.25, CRYON, 14, 0.6f, false));
            LintangFilm.windStreaks(c.subtract(dir.scale(9.0)), c, 18, 8);
            if (self) {
                CameraShake.add(0.45f);
                FovKick.kick(0.3f);
            } else {
                ShazamFx.shakeAround(c, 0.4f, 32);
            }
        });
    }

    private static void heroCall(Vec3 pos) {
        schedule(0, 6, (level, t) -> {
            if (t % 3 == 0) {
                Vfx.add(new Fx.Ripple(pos, UP, 0.0, 0.3, 1.6, 0.05, CRYON, 12, 0.45f, false));
            }
        });
    }

    // ------------------------------------------------------------------ eksperimen

    /** Eksperimen Proyek Helion-6 (wujud manusia): suntikan, radiasi menjalar, kejang, lalu meledak di HELION_RITE_STRIKE. */
    private static void rite(AbstractClientPlayer caster, boolean self) {
        RITE.put(caster.getId(), caster.level().getGameTime());
        int strike = ShazamAnim.HELION_RITE_STRIKE;
        schedule(6, 1, (level, t) -> {   // suntikan di leher
            Vec3 neck = caster.position().add(0, caster.getBbHeight() * 0.8, 0);
            Vfx.add(new Fx.Flash(neck, 0.4f, CRYON_HOT, 5, 0.9f));
            CineKit.sparks(neck, 10, CRYON, 0.15, 0.04f, 10, caster.getY());
        });
        schedule(10, strike - 10, (level, t) -> {
            float k = t / (float) (strike - 10);
            Vec3 c = chest(caster);
            RandomSource r = level.random;
            if (t % 2 == 0) {
                for (int i = 0, n = Vfx.count(1 + 5 * k); i < n; i++) {
                    Vec3 p = c.add(ShazamFx.randomDir(r).scale(1.6 + r.nextDouble() * 1.8));
                    Vec3 v = c.subtract(p).scale(0.1);
                    Vfx.streak(p.x, p.y, p.z, v.x, v.y, v.z, CRYON, 0.04f + 0.03f * k, 10);
                }
            }
            if (t % 20 == 0) {
                Vfx.add(new Fx.Wave(caster.position().add(0, 0.05, 0), UP, 2.0 + 3.0 * k, 0.2, CRYON, 16, 0.5f + 0.3f * k, 0.05f, null));
            }
            if (t > 60 && t % 3 == 0) {   // kejang: percikan radiasi dari tubuh
                CineKit.sparks(c, 4, CRYON, 0.2, 0.05f, 8, caster.getY());
            }
            if (self) {
                if (t % 10 == 0) {
                    ScreenFx.vignette(0.2f + 0.45f * k, 0x02200E, 10);
                }
                CameraShake.add(t > 70 ? 0.06f : 0.012f);
            }
        });
        schedule(strike, 1, (level, t) -> {
            bigBurst(level, caster, 1.1f, self);
            if (self) {
                ScreenFx.titleKey("title.shazammod.helion_project", CRYON, 80, 6);
            }
        });
    }

    // ------------------------------------------------------------------ H - Hempasan Lesat

    private static void dash(AbstractClientPlayer caster, Vec3 end, boolean self) {
        int w = ShazamAnim.HELION_DASH_WINDUP, len = ShazamAnim.HELION_DASH_TICKS;
        Vfx.add(new Fx.Glow(caster, CineKit.chestAnchor(caster), 0.9f, CRYON, w + 2, w));
        schedule(0, w, (level, t) -> {
            if (t % 2 == 0) {
                CineKit.sparks(chest(caster), 4, CRYON, 0.15, 0.04f, 6, caster.getY());
            }
        });
        schedule(w, 1, (level, t) -> {
            Vec3 start = caster.position();
            Vec3 dir = end.subtract(start);
            dir = dir.lengthSqr() < 1.0E-4 ? caster.getViewVector(1f) : dir.normalize();
            Vfx.add(new Fx.Trail(caster, pt -> caster.getPosition(pt).add(0, 0.9, 0), CRYON, 1.0f, 8, len + 1, true));
            Vfx.add(new Fx.Trail(caster, pt -> caster.getPosition(pt).add(0, 1.5, 0), CRYON_HOT, 0.35f, 6, len + 1, false));
            ShazamPoses.ghostBurst(caster, len + 4);
            LintangFilm.vaporCone(start.add(0, 0.9, 0), dir, 1.0);
            LintangFilm.windStreaks(start.add(0, 0.9, 0), end.add(0, 0.9, 0), 16, 8);
            Vfx.add(new Fx.Wave(start.add(0, 0.9, 0), dir, 3.0, 0.3, CRYON, 10, 0.8f, 0.05f, null));
            if (self) {
                FovKick.kick(0.35f);
                CameraShake.add(0.25f);
                ScreenFx.speedLines(0.6f);
            }
        });
        schedule(w + len, 1, (level, t) -> {
            Vec3 e = caster.position();
            CineKit.shock(level, e.add(0, 0.1, 0), UP, 6.0, CRYON, CRYON_HOT, 14, 0.9f, true);
            Vfx.add(new Fx.Flash(e.add(0, 1.0, 0), 1.6f, CRYON_HOT, 5, 0.9f));
            CineKit.sparks(e.add(0, 1.0, 0), 18, CRYON, 0.4, 0.07f, 12, e.y);
            if (self) {
                CameraShake.add(0.3f);
            }
        });
    }

    /** Hantaman radiasi di satu titik (lesatan, tinju, rambatan Tinju Cryon). */
    private static void hit(Vec3 pos, float size) {
        schedule(0, 1, (level, t) -> {
            RandomSource r = level.random;
            Vfx.add(new Fx.Flash(pos, 1.1f * size, CRYON_HOT, 4, 0.9f));
            Vfx.add(new Fx.Flash(pos, 2.0f * size, CRYON, 8, 0.4f));
            CineKit.sparks(pos, (int) (16 * size), CRYON, 0.4 * size, 0.07f, 10, pos.y - 2.0);
            Vfx.add(new Fx.Wave(pos, ShazamFx.randomDir(r), 1.8 * size, 0.14, CRYON, 8, 0.7f, 0f, null));
            for (int i = 0; i < (size > 0.8f ? 3 : 1); i++) {
                Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(pos), Lightning.Anchor.fixed(pos.add(ShazamFx.randomDir(r).scale(1.2 * size))),
                        CRYON, 0.05f, 3, 1, 1, 0.3));
            }
        });
    }

    private static void deflect(Vec3 pos) {
        schedule(0, 1, (level, t) -> {
            Vfx.add(new Fx.Flash(pos, 0.5f, CRYON_HOT, 3, 0.8f));
            CineKit.sparks(pos, 8, CRYON, 0.3, 0.05f, 7, pos.y - 2.0);
        });
    }

    /** Tinju Cryon: radiasi meledak di sasaran - kilat berlapis, gelombang searah pukulan, kristal pecah, busur radiasi. */
    private static void cryonPunch(AbstractClientPlayer caster, Vec3 pos, boolean self) {
        schedule(0, 1, (level, t) -> {
            Vec3 dir = pos.subtract(chest(caster));
            dir = dir.lengthSqr() < 1.0E-4 ? caster.getViewVector(1f) : dir.normalize();
            CineKit.burst(pos, 1.6f, CRYON, CRYON_HOT, 12, 1f);
            Vfx.add(new Hd.Pressure(pos.subtract(dir.scale(0.3)), dir, 4.0, 0.6, CRYON, 12, 0.85f, true));
            for (int k = 0; k < 2; k++) {
                Vfx.add(new Fx.Ripple(pos.subtract(dir.scale(0.4)), dir, 6.5 - k * 2.0, 0.45 + k * 0.15, 2.8 - k * 0.6, 0.24,
                        k == 0 ? CRYON : CRYON_HOT, 12 + k * 3, 0.65f - k * 0.15f, false));
            }
            HdKit.shards(pos, 12, 0.4, CRYON, 0.14f, 20, pos.y - 2.0);
            CineKit.sparks(pos, 26, CRYON, 0.55, 0.08f, 12, pos.y - 2.0);
            RandomSource r = level.random;
            for (int i = 0; i < 4; i++) {
                Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(pos), Lightning.Anchor.fixed(pos.add(ShazamFx.randomDir(r).scale(2.0))),
                        CRYON, 0.06f, 4, 1, 2, 0.3));
            }
            if (self) {
                CameraShake.add(0.5f);
                FovKick.punch(0.3f);
            } else {
                ShazamFx.shakeAround(pos, 0.3f, 16);
            }
        });
    }

    // ------------------------------------------------------------------ E - Emisi Cryon

    private static void eyes(AbstractClientPlayer caster, boolean self) {
        long now = caster.level().getGameTime();
        int w = ShazamAnim.HELION_EYES_WINDUP, len = ShazamAnim.HELION_EYES_TICKS;
        EYES.put(caster.getId(), new long[] {now, now + w, now + w + len});
        schedule(0, w, (level, t) -> {   // radiasi terkumpul di kedua mata
            RandomSource r = level.random;
            for (Vec3 e : eyePoints(caster, 1f)) {
                for (int i = 0, n = Vfx.count(1 + t * 0.2); i < n; i++) {
                    Vec3 p = e.add(ShazamFx.randomDir(r).scale(0.9 + r.nextDouble() * 0.9));
                    Vec3 v = e.subtract(p).scale(0.2);
                    Vfx.streak(p.x, p.y, p.z, v.x, v.y, v.z, CRYON, 0.035f, 5);
                }
            }
            if (self && t % 3 == 0) {
                ScreenFx.vignette(0.15f + 0.04f * t, 0x02260F, 4);
            }
        });
        schedule(w, 1, (level, t) -> {
            Vfx.add(new CryonBeam(caster, len, self));
            LoopSound.play(ShazamSounds.HELION_BEAM_LOOP.get(), () -> caster.getEyePosition(1f).add(caster.getViewVector(1f).scale(3.0)),
                    () -> beaming(caster), 1.2f, 1f);
            for (Vec3 e : eyePoints(caster, 1f)) {
                Vfx.add(new Fx.Flash(e, 0.5f, CRYON_HOT, 4, 1f));
            }
            if (self) {
                CameraShake.add(0.3f);
                FovKick.punch(-0.08f);
            }
        });
    }

    private static boolean beaming(AbstractClientPlayer p) {
        long[] e = EYES.get(p.getId());
        long now = p.level().getGameTime();
        return e != null && now >= e[1] && now < e[2] && p.isAlive() && ShazamClientState.isTransformed(p.getId());
    }

    /**
     * Dua sinar Cryon dari mata ke titik kena (dihitung tiap frame, jadi mulus saat disapukan): pendar luar hijau tua, badan
     * hijau, inti putih panas, pilinan radiasi di sekelilingnya, kilau di mata, dan titik kena yang menyala, memercik, berasap.
     * Sinar berhenti di musuh pertama (sama dengan server) atau blok pertama.
     */
    static final class CryonBeam extends Effect {
        private final AbstractClientPlayer p;
        private final int beamTicks;
        private final boolean self;
        private double entityDist = Double.MAX_VALUE;

        CryonBeam(AbstractClientPlayer p, int beamTicks, boolean self) {
            super(beamTicks + 6);
            this.p = p;
            this.beamTicks = beamTicks;
            this.self = self;
        }

        private float strength(float t) {
            return Mth.clamp(t / 2f, 0f, 1f) * Mth.clamp((beamTicks + 2 - t) / 4f, 0f, 1f);
        }

        private Vec3 endPoint(float pt) {
            Vec3 eye = p.getEyePosition(pt);
            Vec3 end = beamEnd(p, pt, HelionSkills.BEAM_RANGE);
            double len = end.distanceTo(eye);
            if (entityDist < len) {
                end = eye.add(end.subtract(eye).scale(entityDist / Math.max(1.0E-6, len)));
            }
            return end;
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (!p.isAlive() || !ShazamClientState.isTransformed(p.getId())) {
                return false;
            }
            Vec3 eye = p.getEyePosition(1f);
            Vec3 end = beamEnd(p, 1f, HelionSkills.BEAM_RANGE);
            Vec3 d = end.subtract(eye);
            double len = d.length();
            entityDist = Double.MAX_VALUE;
            for (LivingEntity m : level.getEntitiesOfClass(LivingEntity.class, new AABB(eye, end).inflate(1.2),
                    e -> e != p && e.isAlive() && e instanceof Enemy)) {
                Vec3 c = m.position().add(0, m.getBbHeight() * 0.5, 0);
                double t = Mth.clamp(c.subtract(eye).dot(d) / Math.max(1.0E-6, d.lengthSqr()), 0.0, 1.0);
                if (c.distanceTo(eye.add(d.scale(t))) < Math.max(0.5, m.getBbWidth() * 0.6)) {
                    entityDist = Math.min(entityDist, t * len);
                }
            }
            if (strength(age) > 0.2f) {
                Vec3 hp = endPoint(1f);
                RandomSource r = level.random;
                for (int i = 0, n = Vfx.count(3); i < n; i++) {
                    Vec3 v = ShazamFx.randomDir(r);
                    Vfx.spark(hp.x, hp.y, hp.z, v.x * 0.25, Math.abs(v.y) * 0.3 + 0.08, v.z * 0.25, i % 2 == 0 ? CRYON : CRYON_HOT,
                            0.06f, 8 + r.nextInt(5), hp.y - 2.0);
                }
                if (age % 2 == 0) {
                    Vfx.smoke(hp.x, hp.y + 0.1, hp.z, (r.nextDouble() - 0.5) * 0.02, 0.04, (r.nextDouble() - 0.5) * 0.02, SMOKE,
                            0.3f + r.nextFloat() * 0.2f, 26);
                }
                if (age % 3 == 0) {
                    Vfx.mote(hp.x, hp.y, hp.z, (r.nextDouble() - 0.5) * 0.05, 0.05, (r.nextDouble() - 0.5) * 0.05, CRYON, 0.12f, 14);
                }
                if (age % 6 == 0) {
                    Vfx.add(new Fx.Flash(hp, 0.9f, CRYON, 4, 0.7f));
                }
                if (self) {
                    CameraShake.add(0.015f);
                }
            }
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float t = time(pt);
            float s = strength(t);
            if (s <= 0.01f || !p.isAlive()) {
                return;
            }
            Vec3 end = endPoint(pt);
            Vec3[] eyes = eyePoints(p, pt);
            boolean fp = firstPerson(p);
            float flick = 0.86f + 0.14f * Mth.sin(t * 2.7f) + 0.06f * Mth.sin(t * 7.3f);
            float a0 = fp ? s * 0.5f : s;
            for (Vec3 e : eyes) {
                float w = 0.26f * flick;
                d.line(e.x, e.y, e.z, end.x, end.y, end.z, w * 2.6f, w * 3.2f, CRYON_DEEP, 0.32f * a0, 0.24f * s);
                d.beam(e.x, e.y, e.z, end.x, end.y, end.z, w, CRYON, CRYON_HOT, a0, s * 0.9f);
                d.glow(e.x, e.y, e.z, fp ? 0.12f : 0.22f, CRYON_HOT, 0.9f * a0);
                d.glow(e.x, e.y, e.z, fp ? 0.3f : 0.55f, CRYON, 0.45f * a0);
            }
            Vec3 mid = eyes[0].add(eyes[1]).scale(0.5);
            Vec3 axis = end.subtract(mid);
            double len = axis.length();
            if (len > 0.5) {   // pilinan radiasi di sekeliling sinar
                Vec3 dir = axis.scale(1.0 / len);
                Vec3 side = dir.cross(UP);
                side = side.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : side.normalize();
                Vec3 up2 = side.cross(dir);
                int n = Math.min(64, Math.max(8, (int) (len * 3)));
                float[] pts = new float[n * 3];
                for (int k = 0; k < n; k++) {
                    double f = k / (double) (n - 1);
                    double ang = f * len * 2.2 - t * 0.9;
                    double rad = 0.16 + 0.05 * Math.sin(f * 20.0 + t);
                    Vec3 q = mid.add(axis.scale(f)).add(side.scale(Math.cos(ang) * rad)).add(up2.scale(Math.sin(ang) * rad));
                    pts[k * 3] = (float) q.x;
                    pts[k * 3 + 1] = (float) q.y;
                    pts[k * 3 + 2] = (float) q.z;
                }
                d.strip(pts, n, 0.05f, 0.08f, CRYON_HOT, 0.55f * a0, 0.35f * s);
            }
            d.glow(end.x, end.y, end.z, 1.1f * flick, CRYON, 0.75f * s);
            d.glow(end.x, end.y, end.z, 0.45f, CRYON_HOT, s);
            d.glint(end.x, end.y, end.z, 1.2f, t * 0.3f, CRYON_HOT, 0.7f * s);
        }
    }

    // ------------------------------------------------------------------ I - Injakan Cryon

    private static void quake(AbstractClientPlayer caster, boolean self) {
        int w = ShazamAnim.HELION_QUAKE_WINDUP;
        Vfx.add(new Fx.Glow(caster, pt -> ShazamPoses.handPos(caster, true, pt), 0.7f, CRYON, w + 3, w));
        Vfx.add(new Fx.Glow(caster, pt -> ShazamPoses.handPos(caster, false, pt), 0.7f, CRYON, w + 3, w));
        schedule(0, w, (level, t) -> {   // radiasi terkumpul di kedua kepalan, tanah di bawahnya mulai berpendar
            RandomSource r = level.random;
            for (boolean right : new boolean[] {true, false}) {
                Vec3 h = ShazamPoses.handPos(caster, right, 1f);
                Vec3 p = h.add(ShazamFx.randomDir(r).scale(1.0 + r.nextDouble()));
                Vec3 v = h.subtract(p).scale(0.18);
                Vfx.streak(p.x, p.y, p.z, v.x, v.y, v.z, CRYON, 0.05f, 6);
            }
            if (self && t % 4 == 0) {
                ScreenFx.vignette(0.2f + 0.03f * t, 0x02260F, 5);
            }
        });
        schedule(w, 1, (level, t) -> quakeImpact(level, caster, self));
        schedule(w + 8, 1, (level, t) -> {   // gempa susulan yang menyapu lebih jauh
            Vec3 f = caster.position();
            Ground.Map g = ShazamFx.ground(level, f, 19.0);
            Vec3 c = g != null ? g.center(f) : f;
            Vfx.add(new Fx.Wave(c, UP, 19.0, 1.2, CRYON, 22, 0.5f, 0.03f, g));
            CineKit.shock(level, c, UP, 19.0, 0xD8CCB8, CRYON, 24, 0.6f, true, true);
            if (self) {
                CameraShake.add(0.35f);
            } else {
                ShazamFx.shakeAround(c, 0.3f, 30);
            }
        });
    }

    private static void quakeImpact(ClientLevel level, AbstractClientPlayer caster, boolean self) {
        Vec3 f = caster.position();
        Ground.Map g = ShazamFx.ground(level, f, 14.0);
        Vec3 c = g != null ? g.center(f) : f;
        int dust = g != null && g.found ? g.dustColor(level, f) : 0x8A7A66;
        RandomSource r = level.random;
        CineKit.burst(c.add(0, 0.6, 0), 2.4f, CRYON, CRYON_HOT, 12, 1f);
        for (int i = 0; i < 3; i++) {
            Vfx.add(new Fx.Wave(c, UP, 6.0 + i * 4.5, 0.5 + i * 0.25, i == 0 ? CRYON_HOT : CRYON, 14 + i * 6, 0.95f - i * 0.2f, 0.08f, g));
        }
        CineKit.shock(level, c, UP, 13.0, CRYON, CRYON_HOT, 22, 1f, true);
        Vfx.add(new Fx.Bubble(c, 5.5, CRYON, 16, 0.75f, 0.5, 2.2, true));   // kubah radiasi
        if (g != null && g.found) {
            Vfx.add(new Ground.Cracks(c, g, 16, 9.0f, 220, 90, CRYON, r.nextLong()));
            Vfx.add(new Ground.Debris(c, g, 22, 0.32, 0.62, 1.4, 60));
            Vfx.add(new RadGlow(c, 3.0, 140, g));
            ShazamFx.dustPuffs(level, c, dust, 30, 3.2, 0.32);
            ShazamFx.smokeCloud(level, c, dust, 14, 3.5);
            LintangFilm.dirtSprays(c, 14, 0.42, dust);
            for (int i = 0; i < 6; i++) {   // semburan radiasi dari retakan
                double a = r.nextDouble() * Math.PI * 2.0, d = 2.5 + r.nextDouble() * 4.5;
                double gx = c.x + Math.cos(a) * d, gz = c.z + Math.sin(a) * d;
                Vfx.add(new Fx.Pillar(new Vec3(gx, c.y + g.at(a, d), gz), 2.5 + r.nextDouble() * 3.0, 0.5f, CRYON, 12 + r.nextInt(8)));
            }
        }
        Vfx.add(new Hd.DustBurst(c, 4.5, dust, 40, 0.9f, true));
        if (self) {
            CameraShake.add(0.9f);
            FovKick.punch(0.6f);
            ScreenFlash.flash(0.35f, 0xC8FFD8);
            ScreenFx.vignette(0.45f, 0x021A0C, 12);
        } else {
            ShazamFx.shakeAround(c, 0.7f, 30);
        }
    }

    // ------------------------------------------------------------------ 6 - Supernova-6

    private static void novaCharge(AbstractClientPlayer caster, boolean self) {
        NOVA.put(caster.getId(), caster.level().getGameTime());
        int w = ShazamAnim.HELION_NOVA_WINDUP;
        Vfx.add(new Hd.Vortex(Lightning.Anchor.on(caster, 0, 0.05, 0), 5.0, 0.7, 3.4, 5, 1.7, 0.16f, CRYON, CRYON_HOT, 0, -0.2f, w, 0.8f));
        Vfx.add(new Hd.Corona(CineKit.chestAnchor(caster), 0.5, 2.6, 14, CRYON, CRYON_HOT, w, 0.7f, null));
        schedule(0, w, (level, t) -> {
            float k = t / (float) w;
            Vec3 c = chest(caster);
            Vec3 f = caster.position();
            RandomSource r = level.random;
            for (int i = 0, n = Vfx.count(3 + 9 * k); i < n; i++) {   // radiasi tersedot dari sekeliling
                Vec3 p = c.add(ShazamFx.randomDir(r).scale(4.0 + r.nextDouble() * 5.0));
                Vec3 v = c.subtract(p).scale(0.09 + 0.06 * k);
                Vfx.streak(p.x, p.y, p.z, v.x, v.y, v.z, r.nextInt(3) == 0 ? CRYON_HOT : CRYON, 0.06f + 0.05f * k, 10);
            }
            if (t % 4 == 0) {   // debu & kerikil terangkat
                for (int i = 0, n = Vfx.count(2 + 4 * k); i < n; i++) {
                    double a = r.nextDouble() * Math.PI * 2.0, rr = 1.5 + r.nextDouble() * 5.0;
                    Vfx.dust(f.x + Math.cos(a) * rr, f.y + 0.1, f.z + Math.sin(a) * rr, -Math.cos(a) * 0.03, 0.04 + 0.05 * k,
                            -Math.sin(a) * 0.03, 0x8C8274, 0.3f + 0.2f * k, 26);
                }
            }
            if (t % 15 == 0) {   // retakan bercahaya menjalar makin jauh
                Ground.Map g = ShazamFx.ground(level, f, 3.0 + 6.0 * k);
                if (g != null && g.found) {
                    Vfx.add(new Ground.Cracks(g.center(f), g, 5 + (int) (6 * k), (float) (2.0 + 6.0 * k), 120, 70, CRYON, r.nextLong()));
                }
            }
            if (t % 10 == 0) {
                Vfx.add(new Fx.Flash(c, 0.8f + 1.2f * k, CRYON, 6, 0.5f + 0.4f * k));
            }
            if (t == w - 8) {   // tarikan terakhir: semuanya tersedot ke dada, hening sekejap
                Vfx.add(new Implosion(caster, 7.0, 8));
            }
            if (self) {
                CameraShake.add(0.015f + 0.05f * k);
                if (t % 6 == 0) {
                    ScreenFx.vignette(0.2f + 0.5f * k, 0x021A0C, 7);
                }
                if (t == w - 2) {
                    ScreenFx.cinema(60);
                }
            } else if (t % 10 == 0) {
                ShazamFx.shakeAround(c, 0.1f + 0.2f * k, 28);
            }
        });
    }

    /** data.x = jari-jari ledakan (blok), data.y = kekuatan 0-1 (dari radiasi yang dibakar). */
    private static void novaBlast(AbstractClientPlayer caster, Vec3 data, boolean self) {
        double radius = Mth.clamp(data.x, 6.0, 40.0);
        float k = (float) Mth.clamp(data.y, 0.2, 1.0);
        NOVA.remove(caster.getId());
        final Vec3 base = caster.position();
        schedule(0, 1, (level, t) -> {
            Vec3 c = base.add(0, caster.getBbHeight() * 0.62, 0);
            Vfx.add(new Fx.Flash(c, (float) radius * 0.45f, 0xFFFFFF, 6, 1f));
            CineKit.burst(c, (float) (radius * 0.2), CRYON, CRYON_HOT, 26, 1f);
            Vfx.add(new Hd.Nova(c, radius * 0.4, CRYON_HOT, CRYON, CRYON_DEEP, 0x26302A, 64, 1f, caster.onGround()));
            Vfx.add(new Hd.Pressure(c, UP, radius, 1.0, CRYON, 26, 1f, true));
            Vfx.add(new Fx.Bubble(c, radius * 0.85, CRYON, 22, 0.6f, 1.0, 2.6, true));
            CineKit.shock(level, base.add(0, 0.1, 0), UP, radius, CRYON, CRYON_HOT, 30, 1f, true);
            Ground.Map g = ShazamFx.ground(level, base, Math.min(radius, 22.0));
            Vec3 gc = g != null ? g.center(base) : base;
            for (int i = 0; i < 3; i++) {
                Vfx.add(new Fx.Wave(gc, UP, radius * (0.45 + 0.3 * i), 0.6 + 0.4 * i, i == 0 ? CRYON_HOT : CRYON, 18 + 8 * i,
                        0.9f - 0.2f * i, 0.05f, g));
            }
            if (g != null && g.found) {
                int dust = g.dustColor(level, base);
                Vfx.add(new Ground.Cracks(gc, g, 22, (float) Math.min(radius * 0.7, 16.0), 260, 140, CRYON, level.random.nextLong()));
                Vfx.add(new Ground.Debris(gc, g, 34, 0.42, 0.85, 2.0, 80));
                Vfx.add(new RadGlow(gc, Math.min(radius * 0.4, 10.0), 160, g));
                Vfx.add(new Hd.DustBurst(gc, Math.min(radius * 0.35, 9.0), dust, 70, 1f, true));
                ShazamFx.dustPuffs(level, gc, dust, 44, Math.min(radius * 0.3, 8.0), 0.45);
                LintangFilm.dirtSprays(gc, 20, 0.6, dust);
            }
            CineKit.sparks(c, 60, CRYON, 0.9, 0.1f, 20, base.y);
            HdKit.shards(c, 30, 0.8, CRYON, 0.22f, 34, base.y);
            if (self) {
                ScreenFlash.flash(0.9f, 0xE6FFEE);
                CameraShake.add(1.0f);
                FovKick.punch(0.9f);
                ScreenFx.vignette(0.6f, 0x021A0C, 30);
                ScreenFx.titleKey("title.shazammod.supernova6", CRYON, 60, 4);
            } else {
                ShazamFx.shakeAround(c, 0.9f, radius * 2.5);
            }
        });
        final double rr = radius;
        schedule(2, 46, (level, t) -> {   // tiang asap jamur & sisa radiasi yang berkilau naik
            RandomSource r = level.random;
            double top = 2.0 + t * 0.32 * (0.6 + 0.4 * k);
            for (int i = 0, n = Vfx.count(3); i < n; i++) {
                Vfx.smoke(base.x + (r.nextDouble() - 0.5) * 1.6, base.y + top * r.nextDouble(), base.z + (r.nextDouble() - 0.5) * 1.6,
                        0, 0.12, 0, 0x37403A, 0.9f + r.nextFloat() * 0.6f, 50 + r.nextInt(20));
            }
            if (t > 18) {
                for (int i = 0, n = Vfx.count(4); i < n; i++) {
                    double a = r.nextDouble() * Math.PI * 2.0, d = (t - 18) * 0.14 * (0.6 + r.nextDouble() * 0.6);
                    Vfx.smoke(base.x + Math.cos(a) * d, base.y + top, base.z + Math.sin(a) * d, Math.cos(a) * 0.06, 0.02,
                            Math.sin(a) * 0.06, 0x2E3A33, 1.1f + r.nextFloat() * 0.6f, 60 + r.nextInt(20));
                }
            }
            if (t % 3 == 0) {
                double a = r.nextDouble() * Math.PI * 2.0, d = r.nextDouble() * rr * 0.4;
                Vfx.mote(base.x + Math.cos(a) * d, base.y + 0.2, base.z + Math.sin(a) * d, 0, 0.05 + r.nextDouble() * 0.04, 0,
                        CRYON, 0.14f, 30);
            }
        });
    }

    /** Tarikan terakhir sebelum Supernova: cangkang radiasi mengecil ke dada sambil makin terang. */
    static final class Implosion extends Effect {
        private final Entity owner;
        private final double r0;

        Implosion(Entity owner, double r0, int life) {
            super(life);
            this.owner = owner;
            this.r0 = r0;
        }

        @Override
        public void renderGlow(Draw d) {
            float t = progress(d.partialTick);
            Vec3 c = owner.getPosition(d.partialTick).add(0, owner.getBbHeight() * 0.6, 0);
            double r = r0 * (1 - t) * (1 - t) + 0.25;
            d.shell(c.x, c.y, c.z, r, CRYON, 0.25f + 0.6f * t, 2.4, 1.0);
            d.glow(c.x, c.y, c.z, 0.4f + 1.2f * t, CRYON_HOT, 0.4f + 0.6f * t);
        }
    }

    // ------------------------------------------------------------------ M - Hirup Cryon

    private static void inhale(AbstractClientPlayer caster, boolean self) {
        long now = caster.level().getGameTime();
        int w = ShazamAnim.HELION_INHALE_WINDUP;
        INHALE.put(caster.getId(), now);
        SURGE.put(caster.getId(), now + w + HelionSkills.SURGE_TICKS);
        schedule(6, 1, (level, t) -> {   // pecahan Cryon diremukkan di genggaman
            Vec3 h = ShazamPoses.handPos(caster, true, 1f);
            Vfx.add(new Fx.Flash(h, 0.6f, CRYON_HOT, 4, 1f));
            HdKit.shards(h, 10, 0.18, CRYON, 0.12f, 18, caster.getY());
            CineKit.sparks(h, 10, CRYON, 0.2, 0.05f, 8, caster.getY());
        });
        schedule(7, w - 7, (level, t) -> {   // uap radiasi mengalir dari genggaman ke hidung
            Vec3 h = ShazamPoses.handPos(caster, true, 1f);
            Vec3 m = CineKit.mouth(caster);
            RandomSource r = level.random;
            for (int i = 0, n = Vfx.count(4); i < n; i++) {
                double f = r.nextDouble();
                Vec3 q = h.lerp(m, f).add(ShazamFx.randomDir(r).scale(0.12 * (1 - f)));
                Vec3 v = m.subtract(q).scale(0.25);
                Vfx.mote(q.x, q.y, q.z, v.x, v.y, v.z, CRYON, 0.08f, 6);
            }
            if (!firstPerson(caster) && t % 2 == 0) {
                Vfx.smoke(h.x, h.y, h.z, (m.x - h.x) * 0.08, (m.y - h.y) * 0.08, (m.z - h.z) * 0.08, 0x58C884, 0.14f, 10);
            }
            if (self && t % 4 == 0) {
                ScreenFx.vignette(0.25f + 0.04f * t, 0x02260F, 5);
            }
        });
        schedule(w, 1, (level, t) -> {   // radiasi menyebar ke seluruh tubuh: urat menyala, raungan, gelombang
            Vec3 c = chest(caster);
            CineKit.burst(c, 1.8f, CRYON, CRYON_HOT, 12, 0.9f);
            Vfx.add(new Hd.Corona(CineKit.chestAnchor(caster), 0.4, 2.4, 16, CRYON, CRYON_HOT, 22, 0.8f, null));
            CineKit.shock(level, caster.position().add(0, 0.1, 0), UP, 6.0, CRYON, CRYON_HOT, 14, 0.8f, true);
            Vfx.add(new Aura(caster, HelionSkills.SURGE_TICKS));
            if (self) {
                ScreenFlash.flash(0.35f, 0xC8FFD8);
                FovKick.punch(0.45f);
                CameraShake.add(0.5f);
                ScreenFx.vignette(0.5f, 0x02260F, 16);
            } else {
                ShazamFx.shakeAround(c, 0.4f, 20);
            }
        });
    }

    /** Lonjakan Cryon: lidah-lidah radiasi hijau naik berkelok di sekeliling badan, pendar samar, butiran naik. */
    static final class Aura extends Effect {
        private final AbstractClientPlayer p;

        Aura(AbstractClientPlayer p, int life) {
            super(life);
            this.p = p;
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (!p.isAlive() || !ShazamClientState.isTransformed(p.getId())) {
                return false;
            }
            if (age % 2 == 0 && !firstPerson(p)) {
                RandomSource r = level.random;
                double a = r.nextDouble() * Math.PI * 2.0, rr = p.getBbWidth() * 0.6;
                Vfx.mote(p.getX() + Math.cos(a) * rr, p.getY() + r.nextDouble() * p.getBbHeight(), p.getZ() + Math.sin(a) * rr, 0,
                        0.05 + r.nextDouble() * 0.03, 0, CRYON, 0.1f, 16);
            }
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            if (firstPerson(p)) {
                return;
            }
            float pt = d.partialTick;
            float t = time(pt);
            float s = Mth.clamp(t / 6f, 0f, 1f) * Mth.clamp((life - t) / 20f, 0f, 1f);
            if (s <= 0.01f) {
                return;
            }
            Vec3 base = p.getPosition(pt);
            double h = p.getBbHeight(), w = p.getBbWidth() * 0.62;
            int wisps = 10;
            for (int k = 0; k < wisps; k++) {
                double ang = k * Math.PI * 2.0 / wisps + t * 0.06;
                double cx = base.x + Math.cos(ang) * w, cz = base.z + Math.sin(ang) * w;
                double lx = cx, ly = base.y, lz = cz;
                for (int i = 1; i <= 6; i++) {
                    double f = i / 6.0;
                    double sway = Math.sin(t * 0.35 + k * 1.7 + f * 4.0) * 0.1 * f;
                    double nx = cx + Math.cos(ang + Math.PI / 2) * sway, nz = cz + Math.sin(ang + Math.PI / 2) * sway;
                    double ny = base.y + h * (0.05 + 1.05 * f) * (0.85 + 0.15 * Math.sin(t * 0.23 + k));
                    float a0 = (float) Math.sin(Math.PI * (f - 1.0 / 6.0)) * 0.6f * s;
                    float a1 = (float) Math.sin(Math.PI * f) * 0.6f * s;
                    d.line(lx, ly, lz, nx, ny, nz, 0.24f, 0.12f, CRYON, a0, a1);
                    lx = nx;
                    ly = ny;
                    lz = nz;
                }
            }
            float old = d.body(0.45f);
            d.glow(base.x, base.y + h * 0.55, base.z, (float) (h * 0.85), CRYON, 0.22f * s);
            d.body(old);
        }
    }

    /** Noda radiasi di tanah: menyala hijau, lalu meredup jadi bekas gelap. */
    static final class RadGlow extends Effect {
        private final Vec3 c;
        private final double radius;
        private final Draw.Height ground;

        RadGlow(Vec3 c, double radius, int life, Draw.Height ground) {
            super(life);
            this.c = c;
            this.radius = radius;
            this.ground = ground;
        }

        @Override
        public void renderGlow(Draw d) {
            float t = progress(d.partialTick);
            float a = (1f - t) * (1f - t) * 0.8f;
            d.disc(c.x, c.y, c.z, 0, 1, 0, radius, CRYON, a, 0f, ground);
            d.disc(c.x, c.y, c.z, 0, 1, 0, radius * 0.45, CRYON_HOT, a * 0.7f, 0f, ground);
        }

        @Override
        public void renderSoft(Draw d) {
            float t = progress(d.partialTick);
            float a = 0.6f * Math.min(1f, (age + d.partialTick) / 3f) * Math.min(1f, (1f - t) / 0.4f);
            d.disc(c.x, c.y, c.z, 0, 1, 0, radius * 1.1, 0x0E140F, a, 0f, ground);
        }
    }

    // ------------------------------------------------------------------ pasif & matahari

    /** Denyut Cryon tiap 2 detik: urat menyala sesaat, cincin radiasi di kaki, butiran naik. */
    private static void pulse(AbstractClientPlayer caster, boolean self) {
        PULSE.put(caster.getId(), caster.level().getGameTime());
        schedule(0, 1, (level, t) -> {
            Vec3 f = caster.position();
            Vfx.add(new Fx.Wave(f.add(0, 0.08, 0), UP, 2.6, 0.18, CRYON, 14, 0.55f, 0.06f, null));
            Vfx.add(new Fx.Glow(caster, CineKit.chestAnchor(caster), 0.6f, CRYON, 10, 2));
            if (!firstPerson(caster)) {
                CineKit.motesOut(chest(caster), 8, CRYON, 0.05, 0.09f, 16);
            }
            if (self) {
                ScreenFx.vignette(0.12f, 0x02200E, 4);
            }
        });
    }

    /** Masuk ke sinar matahari: kulit mengepulkan asap & bara, layar silau. */
    private static void sunBurn(AbstractClientPlayer caster, boolean self) {
        schedule(0, 1, (level, t) -> {
            Vec3 c = chest(caster);
            RandomSource r = level.random;
            for (int i = 0, n = Vfx.count(14); i < n; i++) {
                Vec3 d = ShazamFx.randomDir(r);
                Vfx.smoke(c.x + d.x * 0.4, c.y + d.y * 0.8, c.z + d.z * 0.4, d.x * 0.04, 0.05, d.z * 0.04, SMOKE, 0.3f + r.nextFloat() * 0.2f, 30);
            }
            CineKit.embers(caster.position(), 10, 0.5, 0.05, 0.06f, 16);
            if (self) {
                ScreenFlash.flash(0.25f, 0xFFF4D0);
                ScreenFx.vignette(0.4f, 0x3A2A08, 20);
            }
        });
    }

    /** Keluar dari sinar matahari: radiasi hijau menyala lagi. */
    private static void sunClear(AbstractClientPlayer caster, boolean self) {
        schedule(0, 1, (level, t) -> {
            Vec3 c = chest(caster);
            CineKit.motesOut(c, 18, CRYON, 0.08, 0.1f, 16);
            Vfx.add(new Fx.Wave(caster.position().add(0, 0.08, 0), UP, 3.2, 0.2, CRYON, 14, 0.6f, 0.05f, null));
            if (self) {
                ScreenFx.vignette(0.3f, 0x02260F, 10);
            }
        });
    }

    /** Radiasi habis di bawah matahari: jatuh berlutut, uap hijau terakhir menguap. */
    private static void collapse(AbstractClientPlayer caster, boolean self) {
        schedule(0, 1, (level, t) -> {
            CineKit.motesOut(chest(caster), 14, CRYON_DEEP, 0.05, 0.1f, 20);
            Vfx.add(new Fx.Wave(caster.position().add(0, 0.08, 0), UP, 2.6, 0.3, 0xBFAE96, 20, 0.5f, 0f, null, true));
            if (self) {
                CameraShake.add(0.35f);
                ScreenFx.vignette(0.5f, 0x1A1408, 24);
            }
        });
        schedule(8, 1, (level, t) -> ShazamFx.dustPuffs(level, caster.position(), 0xA89A86, 10, 0.8, 0.1));
    }
}
