package com.shazammod.client.fx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Molten;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * 0.42 Apa pun yang kena sinar mata Lintang langsung terbakar (efek di client, mengikuti titik kena tiap tick):
 * - permukaan blok: api 3D yang tetap menyala beberapa detik sesudah sinarnya pindah (makin di-charge makin besar);
 * - makhluk: api 3D yang membungkus seluruh badannya selama ia benar-benar terbakar (status api dari server);
 * - makin panas titiknya (suhu cermin server, LintangHeat): gumpalan lahar terlempar, lahar menetes turun di dinding,
 *   dan genangan lahar berpijar di lantai yang pelan-pelan berkerak lalu membeku.
 */
final class LintangBurn {
    private LintangBurn() {}

    private static final int MAX_SPOTS = 28, MAX_POOLS = 18;
    private static final List<Molten.Fire3D> SPOTS = new ArrayList<>();
    private static final Map<Integer, Molten.Fire3D> BODIES = new HashMap<>();
    private static final List<Molten.LavaPool> POOLS = new ArrayList<>();
    private static final Map<Long, long[]> DRIPS = new HashMap<>();   // blok -> {tetesan terakhir, jumlah}
    private static long lastSound;

    static void clear() {
        SPOTS.clear();
        BODIES.clear();
        POOLS.clear();
        DRIPS.clear();
    }

    static void tick(ClientLevel level) {
        SPOTS.removeIf(f -> !f.burning());
        POOLS.removeIf(p -> p.gone());
        long now = level.getGameTime();
        DRIPS.values().removeIf(d -> now - d[0] > 400);
        Iterator<Map.Entry<Integer, Molten.Fire3D>> it = BODIES.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Molten.Fire3D> en = it.next();
            Molten.Fire3D fire = en.getValue();
            Entity e = level.getEntity(en.getKey());
            if (!fire.burning()) {
                it.remove();
                continue;
            }
            if (e == null || !e.isAlive()) {
                fire.douse();
            } else if (e.isInWaterRainOrBubble()) {   // api padam jadi uap
                fire.douse();
                Vfx.smoke(e.getX(), e.getY() + e.getBbHeight() * 0.6, e.getZ(), 0, 0.05, 0, 0xD8D8D8, 0.5f, 20);
            } else if (e.isOnFire()) {
                fire.refresh(8, 1f);   // nyala selama status apinya masih ada (dari server)
            } else {
                fire.douse();
            }
        }
    }

    private static Vec3 normal(Direction face) {
        return new Vec3(face.getStepX(), face.getStepY(), face.getStepZ());
    }

    /** Satu tick sinar mengenai permukaan blok di titik ini (temp = suhu titik itu, cermin server). */
    static void beamHit(ClientLevel level, Vec3 at, Direction face, float charge, float temp) {
        Vec3 n = normal(face);
        RandomSource r = level.random;
        Molten.Fire3D spot = null;
        double best = 0.55 * 0.55;
        for (Molten.Fire3D f : SPOTS) {
            double d2 = f.at(1f).distanceToSqr(at);
            if (d2 < best) {
                best = d2;
                spot = f;
            }
        }
        int keep = (int) (50 + 70 * charge);
        float strength = 0.75f + 0.35f * charge;
        if (spot != null) {
            spot.refresh(keep, strength);
        } else {
            if (SPOTS.size() >= MAX_SPOTS) {
                SPOTS.remove(0).douse();
            }
            boolean up = face == Direction.UP;
            spot = new Molten.Fire3D(Lightning.Anchor.fixed(at), n, 0.22 + 0.16 * charge,
                    up ? 0.55 + 0.5 * charge : 0.4 + 0.35 * charge, keep, strength, false);
            SPOTS.add(spot);
            Vfx.add(spot);
        }
        long now = level.getGameTime();
        if (now - lastSound > 8) {   // desis & gemeretak benda yang terbakar
            lastSound = now;
            level.playLocalSound(at.x, at.y, at.z, SoundEvents.FIRE_AMBIENT, SoundSource.BLOCKS, 0.8f, 0.8f + r.nextFloat() * 0.4f,
                    false);
        }
        if (temp > 850f && r.nextFloat() < 0.2f + 0.3f * charge) {
            blob(level, at, n, charge);
        }
        if (temp > 1050f) {
            if (face == Direction.UP) {
                pool(level, at, 0.035 + 0.05 * charge, 30);
            } else if (face.getAxis().isHorizontal()) {
                drip(level, at, n, charge, now);
            }
        }
    }

    /** Makhluk yang kena sinar: api 3D membungkus badannya (selama status apinya masih ada). */
    static void igniteEntity(LivingEntity e) {
        Molten.Fire3D f = BODIES.get(e.getId());
        if (f != null && f.burning()) {
            f.refresh(20, 1f);
            return;
        }
        f = new Molten.Fire3D(Lightning.Anchor.on(e, 0, 0, 0), new Vec3(0, 1, 0), e.getBbWidth() * 0.55, e.getBbHeight() * 1.1,
                20, 1f, true);
        BODIES.put(e.getId(), f);
        Vfx.add(f);
    }

    /** Lantai di bawah satu titik dari dunia (buat gumpalan lahar yang jatuh), atau NaN. */
    static Molten.Floor floor(ClientLevel level) {
        return (x, y, z) -> {
            BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
            int bx = (int) Math.floor(x), by = (int) Math.floor(y), bz = (int) Math.floor(z);
            for (int i = 0; i < 12; i++) {
                m.set(bx, by - i, bz);
                BlockState s = level.getBlockState(m);
                VoxelShape shape = s.getCollisionShape(level, m);
                if (!shape.isEmpty()) {
                    return m.getY() + shape.max(Direction.Axis.Y);
                }
            }
            return Double.NaN;
        };
    }

    /** Lahar baru masuk di titik ini: genangan terdekat melebar, atau genangan baru. */
    static void pool(ClientLevel level, Vec3 at, double amount, int hold) {
        for (Molten.LavaPool p : POOLS) {
            if (p.near(at, 0.25)) {
                p.feed(amount, hold);
                return;
            }
        }
        if (POOLS.size() >= MAX_POOLS) {
            return;
        }
        Molten.LavaPool p = new Molten.LavaPool(at, 0.16 + amount, 1.3, hold);
        POOLS.add(p);
        Vfx.add(p);
        level.playLocalSound(at.x, at.y, at.z, SoundEvents.LAVA_POP, SoundSource.BLOCKS, 0.6f, 0.9f + level.random.nextFloat() * 0.3f,
                false);
    }

    /** Gumpalan lahar terlempar dari titik leleh, jatuh melengkung, lalu jadi genangan kecil di lantai. */
    static void blob(ClientLevel level, Vec3 at, Vec3 n, float charge) {
        RandomSource r = level.random;
        Vec3 v = n.scale(0.12 + 0.1 * r.nextDouble()).add(ShazamFx.randomDir(r).scale(0.08)).add(0, 0.1 + 0.1 * r.nextDouble(), 0);
        Vfx.add(new Molten.LavaBlob(at.add(n.scale(0.1)), v, 0.04f + 0.05f * charge * r.nextFloat(), floor(level),
                land -> pool(level, land, 0.03, 10)));
    }

    /** Lahar menetes turun di dinding sampai lantai, lalu menggenang. */
    static void drip(ClientLevel level, Vec3 at, Vec3 n, float charge, long now) {
        long key = BlockPos.containing(at.subtract(n.scale(0.05))).asLong();
        long[] st = DRIPS.computeIfAbsent(key, k -> new long[] {-1000L, 0L});
        if (now - st[0] < 14 - 6 * charge || st[1] > 6) {
            return;
        }
        st[0] = now;
        st[1]++;
        double fl = floor(level).below(at.x + n.x * 0.3, at.y, at.z + n.z * 0.3);
        if (Double.isNaN(fl)) {
            fl = at.y - 6.0;
        }
        Vfx.add(new Molten.LavaDrip(at, n, fl, 0.05 + 0.03 * charge, land -> pool(level, land, 0.06, 20)));
    }
}
