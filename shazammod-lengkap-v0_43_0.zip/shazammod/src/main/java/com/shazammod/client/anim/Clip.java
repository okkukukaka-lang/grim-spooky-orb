package com.shazammod.client.anim;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;

/**
 * Satu animasi berbasis keyframe. Tiap keyframe menyimpan rotasi bagian tubuh (derajat),
 * kemiringan seluruh badan (tilt, positif = condong ke depan), turunnya badan (drop, blok),
 * putaran pinggang (twist: badan atas berputar, bahu ikut, kaki tetap), condong ke samping (lean),
 * putaran seluruh badan (spin), dan gemetar (shake, derajat: buat mengumpulkan tenaga).
 * Keyframe baru otomatis menyalin keyframe sebelumnya, jadi cukup tulis yang berubah.
 *
 * Gerak antar-keyframe dihaluskan seperti otot sungguhan: pose di tiap saat dirata-rata dengan pose sesaat
 * sebelum dan sesudahnya (kurva lonceng selebar {@link #SMOOTH} tick). Tanpa ini, tiap keyframe yang memakai
 * OUT_* langsung mulai di kecepatan penuh, jadi tangan/kepala "menyentak" dalam satu frame; sekarang kecepatannya
 * naik dan turun mulus, tapi waktunya tetap sama (pukulan tetap kena di tick yang sama dengan damage).
 */
public final class Clip {
    private static final int PARTS = Part.values().length;

    // ======= Angka yang gampang diutak-atik =======
    /** Lebar penghalusan gerak (tick). 0 = persis keyframe (seperti versi 0.15), makin besar makin lembut. */
    public static final float SMOOTH = 1.6f;
    private static final float[] TAPS = {1 / 64f, 6 / 64f, 15 / 64f, 20 / 64f, 15 / 64f, 6 / 64f, 1 / 64f};

    // urutan saluran nilai: rotasi tiap bagian (x, y, z), lalu nilai seluruh badan
    private static final int TILT = PARTS * 3, DROP = TILT + 1, AIM = TILT + 2, TWIST = TILT + 3, LEAN = TILT + 4,
            SPIN = TILT + 5, SHAKE = TILT + 6, CHANNELS = TILT + 7;
    private final float[] smooth = new float[CHANNELS];
    private final float[] sample = new float[CHANNELS];
    private float smoothT = Float.NaN;

    public final float length;
    private final float fadeIn;
    private final float fadeOut;
    private final Key[] keys;
    private final boolean[] controlled = new boolean[PARTS];

    private static final class Key {
        final float tick;
        final Ease ease;
        final float[] rot = new float[PARTS * 3];
        final boolean[] set = new boolean[PARTS];
        float tilt;
        float drop;
        float aim;
        float twist;
        float lean;
        float spin;
        float shake;

        Key(float tick, Ease ease) {
            this.tick = tick;
            this.ease = ease;
        }

        Key next(float tick, Ease ease) {
            Key key = new Key(tick, ease);
            System.arraycopy(rot, 0, key.rot, 0, rot.length);
            System.arraycopy(set, 0, key.set, 0, set.length);
            key.tilt = tilt;
            key.drop = drop;
            key.aim = aim;
            key.twist = twist;
            key.lean = lean;
            key.spin = spin;
            key.shake = shake;
            return key;
        }
    }

    private Clip(float length, float fadeIn, float fadeOut, List<Key> keys) {
        this.length = length;
        this.fadeIn = fadeIn;
        this.fadeOut = fadeOut;
        this.keys = keys.toArray(new Key[0]);
        for (Key key : this.keys) {
            for (int i = 0; i < PARTS; i++) {
                controlled[i] |= key.set[i];
            }
        }
    }

    /** Bobot animasi pada waktu t: naik pelan di awal, turun pelan di akhir (melengkung, tanpa sentakan). */
    public float weight(float t) {
        if (t < 0f || t > length) {
            return 0f;
        }
        float in = fadeIn <= 0f ? 1f : ease(t / fadeIn);
        float out = fadeOut <= 0f ? 1f : ease((length - t) / fadeOut);
        return Math.min(in, out);
    }

    /** 0..1 melengkung (kecepatan nol di kedua ujung). */
    static float ease(float v) {
        v = Mth.clamp(v, 0f, 1f);
        return v * v * (3f - 2f * v);
    }

    private int segment(float t) {
        int i = 0;
        while (i + 1 < keys.length && keys[i + 1].tick <= t) {
            i++;
        }
        return i;
    }

    private float progress(int i, float t) {
        if (i + 1 >= keys.length) {
            return 0f;
        }
        Key a = keys[i];
        Key b = keys[i + 1];
        float u = (t - a.tick) / Math.max(0.0001f, b.tick - a.tick);
        return b.ease.apply(Mth.clamp(u, 0f, 1f));
    }

    /** Nilai mentah semua saluran pada waktu t (persis keyframe). */
    private void raw(float t, float[] out) {
        int i = segment(t);
        Key a = keys[i];
        Key b = i + 1 < keys.length ? keys[i + 1] : a;
        float u = progress(i, t);
        for (int c = 0; c < PARTS * 3; c++) {
            out[c] = Mth.lerp(u, a.rot[c], b.rot[c]);
        }
        out[TILT] = Mth.lerp(u, a.tilt, b.tilt);
        out[DROP] = Mth.lerp(u, a.drop, b.drop);
        out[AIM] = Mth.lerp(u, a.aim, b.aim);
        out[TWIST] = Mth.lerp(u, a.twist, b.twist);
        out[LEAN] = Mth.lerp(u, a.lean, b.lean);
        out[SPIN] = Mth.lerp(u, a.spin, b.spin);
        out[SHAKE] = Mth.lerp(u, a.shake, b.shake);
    }

    /** Semua saluran pada waktu t, dihaluskan (rata-rata berbobot di sekitar t). Disimpan buat panggilan berikutnya. */
    private float[] at(float t) {
        if (t == smoothT) {
            return smooth;
        }
        if (SMOOTH <= 0f) {
            raw(t, smooth);
        } else {
            Arrays.fill(smooth, 0f);
            for (int j = 0; j < TAPS.length; j++) {
                raw(t + SMOOTH * (j / (float) (TAPS.length - 1) - 0.5f), sample);
                float w = TAPS[j];
                for (int c = 0; c < CHANNELS; c++) {
                    smooth[c] += sample[c] * w;
                }
            }
        }
        smoothT = t;
        return smooth;
    }

    public float tilt(float t) {
        return at(t)[TILT];
    }

    public float drop(float t) {
        return at(t)[DROP];
    }

    /** Condong ke samping (derajat, positif = ke kanan). */
    public float lean(float t) {
        return at(t)[LEAN];
    }

    /** Putaran seluruh badan (derajat). */
    public float spin(float t) {
        return at(t)[SPIN];
    }

    /** Kuat gemetar (derajat). */
    public float shake(float t) {
        if (t < 0f || t > length) {
            return 0f;
        }
        return at(t)[SHAKE];
    }

    /** Getaran acak halus -1..1 (gabungan beberapa gelombang cepat). */
    public static float noise(float age, float seed) {
        return Mth.sin(age * 2.3f + seed) * 0.5f + Mth.sin(age * 3.7f + seed * 1.9f) * 0.3f + Mth.sin(age * 6.1f + seed * 3.1f) * 0.2f;
    }

    /** Terapkan pose ke model. headX/headY = arah kepala bawaan (buat lengan yang membidik). */
    public void apply(HumanoidModel<?> model, float t, float headX, float headY) {
        apply(model, t, headX, headY, 1f);
    }

    /** Sama, dengan bobot tambahan (buat memudarkan klip lama saat klip baru mulai). */
    public void apply(HumanoidModel<?> model, float t, float headX, float headY, float scale) {
        float w = weight(t) * scale;
        if (w <= 0f) {
            return;
        }
        float[] v = at(t);
        float aim = v[AIM];
        for (Part part : Part.values()) {
            int p = part.ordinal();
            if (!controlled[p]) {
                continue;
            }
            float x = v[p * 3] * Mth.DEG_TO_RAD;
            float y = v[p * 3 + 1] * Mth.DEG_TO_RAD;
            float z = v[p * 3 + 2] * Mth.DEG_TO_RAD;
            if (part == Part.RIGHT_ARM && aim != 0f) {
                x += aim * headX;
                y += aim * headY;
            }
            ModelPart modelPart = part.of(model);
            modelPart.xRot = Mth.lerp(w, modelPart.xRot, x);
            modelPart.yRot = Mth.lerp(w, modelPart.yRot, y);
            modelPart.zRot = Mth.lerp(w, modelPart.zRot, z);
        }
        // gemetar: lengan dan kepala bergetar halus (mengumpulkan tenaga, meraung)
        float shake = v[SHAKE] * Mth.DEG_TO_RAD * w;
        if (shake > 0f) {
            model.rightArm.xRot += shake * noise(t, 0.7f);
            model.rightArm.zRot += shake * noise(t, 1.9f);
            model.leftArm.xRot += shake * noise(t, 2.6f);
            model.leftArm.zRot += shake * noise(t, 3.3f);
            model.head.xRot += shake * 0.6f * noise(t, 4.4f);
            model.head.yRot += shake * 0.6f * noise(t, 5.2f);
        }
        // putaran pinggang: badan atas berputar, poros bahu ikut berpindah (seperti ayunan pukulan bawaan)
        float twist = v[TWIST] * Mth.DEG_TO_RAD * w;
        if (Math.abs(twist) > 1.0E-4f) {
            float angle = model.body.yRot + twist;
            model.body.yRot = angle;
            model.rightArm.z = Mth.sin(angle) * 5.0f;
            model.rightArm.x = -Mth.cos(angle) * 5.0f;
            model.leftArm.z = -Mth.sin(angle) * 5.0f;
            model.leftArm.x = Mth.cos(angle) * 5.0f;
            model.rightArm.yRot += twist;
            model.leftArm.yRot += twist;
        }
    }

    public static Builder builder(float length) {
        return new Builder(length);
    }

    public static final class Builder {
        private final float length;
        private final List<Key> keys = new ArrayList<>();
        private float fadeIn = 3f;
        private float fadeOut = 5f;
        private Key current;

        private Builder(float length) {
            this.length = length;
        }

        /** Mulai keyframe baru pada tick tertentu (menyalin keyframe sebelumnya). */
        public Builder key(float tick, Ease ease) {
            current = current == null ? new Key(tick, ease) : current.next(tick, ease);
            keys.add(current);
            return this;
        }

        private Builder set(Part part, float x, float y, float z) {
            int p = part.ordinal();
            current.rot[p * 3] = x;
            current.rot[p * 3 + 1] = y;
            current.rot[p * 3 + 2] = z;
            current.set[p] = true;
            return this;
        }

        public Builder head(float x, float y, float z) { return set(Part.HEAD, x, y, z); }
        public Builder body(float x, float y, float z) { return set(Part.BODY, x, y, z); }
        public Builder rightArm(float x, float y, float z) { return set(Part.RIGHT_ARM, x, y, z); }
        public Builder leftArm(float x, float y, float z) { return set(Part.LEFT_ARM, x, y, z); }
        public Builder rightLeg(float x, float y, float z) { return set(Part.RIGHT_LEG, x, y, z); }
        public Builder leftLeg(float x, float y, float z) { return set(Part.LEFT_LEG, x, y, z); }

        /** Kaki dibuka ke samping (derajat). */
        public Builder legs(float spread) {
            set(Part.RIGHT_LEG, 0f, 0f, spread);
            return set(Part.LEFT_LEG, 0f, 0f, -spread);
        }

        public Builder tilt(float degrees) { current.tilt = degrees; return this; }
        public Builder drop(float blocks) { current.drop = blocks; return this; }
        /** Seberapa banyak lengan kanan ikut arah pandangan (0-1). */
        public Builder aim(float amount) { current.aim = amount; return this; }
        /** Putaran pinggang (derajat): positif = bahu kanan ke belakang... sesuai yRot badan model. */
        public Builder twist(float degrees) { current.twist = degrees; return this; }
        /** Condong seluruh badan ke samping (derajat). */
        public Builder lean(float degrees) { current.lean = degrees; return this; }
        /** Putaran seluruh badan (derajat). */
        public Builder spin(float degrees) { current.spin = degrees; return this; }
        /** Gemetar (derajat). */
        public Builder shake(float degrees) { current.shake = degrees; return this; }

        public Builder fade(float in, float out) {
            fadeIn = in;
            fadeOut = out;
            return this;
        }

        public Clip build() {
            return new Clip(length, fadeIn, fadeOut, keys);
        }
    }
}
