package com.shazammod.client.fx;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.shazammod.PassiveConditions;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamForm;
import com.shazammod.ShazamSounds;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Runes;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * 0.30 Efek Sabbac di client: api neraka yang menjilat naik (bukan petir dari langit), petir neraka merah-hitam yang
 * menyembur dari bawah tanah, tanah retak membara, asap hitam, rantai membara, dan sayap api. Semuanya buatan sendiri di
 * atas mesin efek (client.vfx), dipicu animasi dari server (ShazamAnim.SABBAC_*, plus SUMMON/TRANSFORM/REVERT/KNOCKOUT
 * dan gerak terbang kalau pemainnya Sabbac). Juga efek datang & pergi Rival Juara (RIVAL_ARRIVE / RIVAL_DEPART).
 *
 * S Tanduk Setan      : menggaruk tanah, tanduk menyala, menyeruduk meninggalkan jejak api, hantaman di ujung.
 * A Tubuh Aym         : kulit membatu jadi obsidian berurat magma (digambar SabbacGearLayer), meletus saat pecah.
 * B Rantai Belial     : cakar mencakar tanah, rantai neraka membara menyeruak dan membelit tiap musuh.
 * B Napas Beelzebub   : menarik napas, lalu semburan api neraka 2 detik dengan kawanan lalat hitam.
 * A Teror Asmodeus    : raungan: gelombang teror hitam-merah, layar yang ketakutan menggelap.
 * C Kepakan Crateis   : sayap api terbentang, satu kepakan dahsyat, lalu terbang dengan sayap api.
 * R Gerbang Neraka    : tanah bergemuruh, lingkaran neraka, cincin api di kaki selama amarah.
 * M Petir Neraka      : telapak menekan tanah, petir neraka menyembur naik menembus badan.
 * J Pasukan Iblis     : lengan menghantam ke bawah, tanah terbelah, prajurit bangkit dari api.
 * Selalu              : bara naik pelan dari badan & lidah api kecil di bahu (padam di bawah matahari / di air).
 */
public final class SabbacFx {
    /** 0.33: penguat sinematik semua efek Sabbac (bloom + butiran lebih padat/besar/lama, lihat Vfx). */
    public static final float BOOST = 1.5f;

    private SabbacFx() {}

    // ======= Warna (RGB) =======
    public static final int HELL = 0xE8341A;         // api neraka: merah bara
    public static final int HELL_LIGHT = 0xFF7A3A;   // jingga panas
    public static final int HELL_HOT = 0xFFD08A;     // inti api: kuning panas
    public static final int BLOOD = 0xA8120C;        // merah darah gelap
    public static final int MAGMA = 0xFF5A1E;        // retakan magma
    public static final int CHAIN = 0xFF6A2A;        // rantai membara
    public static final int ASH = 0x16100E;          // asap hitam neraka
    public static final int SOOT = 0x2E2420;
    public static final int OBSIDIAN = 0x24142C;     // obsidian Aym (lapisan lembut)
    public static final int FLY = 0x120E0A;          // lalat Beelzebub
    private static final Vec3 UP = new Vec3(0, 1, 0);

    // ======= Angka yang gampang diutak-atik =======
    /** Bara yang naik dari badan selama berwujud Sabbac (tiap berapa tick). 0 = mati. */
    private static final int AURA_EMBER_EVERY = 3;
    /** Sayap api tetap terbentang (lebih kecil) selama Sabbac terbang. */
    private static final boolean WINGS_IN_FLIGHT = true;
    private static final float FLIGHT_WING_OPEN = 0.72f;

    private static final Map<Integer, long[]> AYM = new HashMap<>();     // kulit obsidian: {mulai, selesai}
    private static final Map<Integer, Long> HORNS = new HashMap<>();      // Tanduk Setan: kapan mulai
    private static final Map<Integer, long[]> EYES = new HashMap<>();     // mata menyala: {mulai, selesai}
    private static final Map<Integer, Wings> WINGS = new HashMap<>();     // sayap api yang sedang terbentang
    private static final Map<Integer, Long> WINGS_UNTIL = new HashMap<>(); // Kepakan Crateis: sayap besar sampai kapan

    public static void clear() {
        AYM.clear();
        HORNS.clear();
        EYES.clear();
        WINGS.clear();
        WINGS_UNTIL.clear();
    }

    /** Animasi ini diurus SabbacFx (ShazamFx melewatinya). */
    public static boolean handles(AbstractClientPlayer caster, ShazamAnim anim) {
        return switch (anim) {
            case SUMMON, TRANSFORM, REVERT, KNOCKOUT, LAUNCH, LAND_HERO, CRASH, SONIC_BOOM, ROLL_LEFT, ROLL_RIGHT ->
                    ShazamClientState.isSabbac(caster.getId());
            default -> anim.name().startsWith("SABBAC_") || anim.name().startsWith("RIVAL_");
        };
    }

    public static void onAnim(AbstractClientPlayer caster, ShazamAnim anim, Vec3 pos) {
        float boostOld = Vfx.setBoost(BOOST);
        try {
            onAnim0(caster, anim, pos);
        } finally {
            Vfx.setBoost(boostOld);
        }
    }

    private static void onAnim0(AbstractClientPlayer caster, ShazamAnim anim, Vec3 pos) {
        if (!handles(caster, anim)) {
            return;
        }
        boolean self = caster == Minecraft.getInstance().player;
        switch (anim) {
            case SUMMON -> summon(caster, self);
            case TRANSFORM -> transform(caster, self);
            case REVERT -> revert(caster, self);
            case KNOCKOUT -> knockout(caster, self);
            case LAUNCH -> launch(caster);
            case LAND_HERO -> landing(caster, self);
            case CRASH -> crash(caster);
            case SONIC_BOOM -> sonicBoom(caster, self);
            case ROLL_LEFT, ROLL_RIGHT -> sidestep(caster, self);
            case SABBAC_HORNS -> horns(caster, self);
            case SABBAC_GORE -> gore(caster, pos);
            case SABBAC_AYM -> aym(caster, self);
            case SABBAC_AYM_BURST -> aymBurst(caster, self);
            case SABBAC_CHAINS -> chains(caster, self);
            case SABBAC_CHAIN_BIND -> bind(caster, pos);
            case SABBAC_BREATH -> breath(caster, self);
            case SABBAC_ROAR -> roar(caster, self);
            case SABBAC_WINGS -> wingsBeat(caster, self);
            case SABBAC_HELLGATE -> hellgate(caster, self);
            case SABBAC_GEYSER -> geyser(pos);
            case SABBAC_CALL -> call(caster, self);
            case SABBAC_LEGION -> legion(caster, self);
            case SABBAC_RISE -> rise(pos);
            case SABBAC_PULSE -> pulse(caster, self);
            case SABBAC_HELLPUNCH -> hellPunch(caster, pos, self);
            case SABBAC_ENGULF -> engulf(pos);
            case SABBAC_FIRE_OUT -> fireOut(caster, self);
            case SABBAC_FIRE_IN -> fireIn(caster, self);
            case SABBAC_PUNCH -> punch(pos);
            case SABBAC_PACT -> pact(caster, self);
            case RIVAL_ARRIVE -> rivalArrive(caster, pos);
            case RIVAL_DEPART -> rivalDepart(caster, pos);
            default -> { }
        }
    }

    // ------------------------------------------------------------------ dibaca lapisan lain

    /** 0-1: kulit obsidian Aym (SabbacGearLayer). */
    public static float aymStrength(AbstractClientPlayer player, float partialTick) {
        long[] a = AYM.get(player.getId());
        if (a == null) {
            return 0f;
        }
        float now = player.level().getGameTime() + partialTick;
        if (now < a[0]) {
            return 0f;
        }
        float in = Mth.clamp((now - a[0]) / 4f, 0f, 1f);
        float out = Mth.clamp((a[1] - now) / 6f, 0f, 1f);
        return in * out;
    }

    /** 0-1: tanduk membesar & menyala saat Tanduk Setan (SabbacGearLayer). */
    public static float hornCharge(AbstractClientPlayer player, float partialTick) {
        Long start = HORNS.get(player.getId());
        if (start == null) {
            return 0f;
        }
        float t = player.level().getGameTime() - start + partialTick;
        float end = ShazamAnim.HORN_WINDUP + ShazamAnim.HORN_TICKS;
        if (t < 0f || t > end + 8f) {
            return 0f;
        }
        return Mth.clamp(t / 4f, 0f, 1f) * Mth.clamp((end + 8f - t) / 8f, 0f, 1f);
    }

    /** 0-1: mata menyala sesaat (napas api, raungan, petir neraka). */
    public static float eyeGlow(AbstractClientPlayer player, float partialTick) {
        long[] e = EYES.get(player.getId());
        if (e == null) {
            return 0f;
        }
        float now = player.level().getGameTime() + partialTick;
        if (now < e[0]) {
            return 0f;
        }
        return Mth.clamp((now - e[0]) / 3f, 0f, 1f) * Mth.clamp((e[1] - now) / 10f, 0f, 1f);
    }

    private static void eyes(AbstractClientPlayer player, int delay, int ticks) {
        long now = player.level().getGameTime();
        EYES.put(player.getId(), new long[] {now + delay, now + delay + ticks});
    }

    // ------------------------------------------------------------------ tiap tick

    public static void tick(ClientLevel level) {
        float boostOld = Vfx.setBoost(BOOST);
        try {
            tick0(level);
        } finally {
            Vfx.setBoost(boostOld);
        }
    }

    private static void tick0(ClientLevel level) {
        long now = level.getGameTime();
        AYM.entrySet().removeIf(e -> now > e.getValue()[1] + 2 || !(level.getEntity(e.getKey()) instanceof AbstractClientPlayer));
        HORNS.entrySet().removeIf(e -> now - e.getValue() > 60);
        EYES.entrySet().removeIf(e -> now > e.getValue()[1] + 2);
        WINGS_UNTIL.entrySet().removeIf(e -> now > e.getValue());
        Iterator<Map.Entry<Integer, Wings>> it = WINGS.entrySet().iterator();
        while (it.hasNext()) {
            if (it.next().getValue().done) {
                it.remove();
            }
        }
        Minecraft mc = Minecraft.getInstance();
        for (AbstractClientPlayer player : level.players()) {
            int id = player.getId();
            if (!ShazamClientState.isTransformed(id) || !ShazamClientState.isSabbac(id) || player.isInvisible()) {
                Wings w = WINGS.get(id);
                if (w != null) {
                    w.want(0f, 1f);
                }
                continue;
            }
            boolean firstPerson = player == mc.player && mc.options.getCameraType().isFirstPerson();
            boolean lit = PassiveConditions.hellfireBlock(level, player.blockPosition(), player.isUnderWater())
                    == PassiveConditions.Hellfire.NONE;
            aura(level, player, firstPerson, lit);
            // sayap api: besar sesudah Kepakan Crateis, lebih kecil selama terbang
            boolean flying = !player.onGround() && (ShazamClientState.isFlying(id)
                    || (player == mc.player && player.getAbilities().flying));
            boolean beat = WINGS_UNTIL.containsKey(id);
            float target = beat ? 1f : (WINGS_IN_FLIGHT && flying ? FLIGHT_WING_OPEN : 0f);
            Wings w = WINGS.get(id);
            if (target > 0f && (w == null || w.done)) {
                w = new Wings(player);
                WINGS.put(id, w);
                Vfx.add(w);
            }
            if (w != null) {
                w.want(target, beat ? 1.35f : 1f);
            }
            // Gerbang Neraka: cincin api menjilat di sekeliling kaki selama amarah
            if (ShazamClientState.isRaging(id) && player.tickCount % 5 == 0) {
                double r = 1.6 * player.getScale();
                for (int k = 0; k < 6; k++) {
                    double a = Math.PI * 2.0 * k / 6.0 + player.tickCount * 0.05;
                    int pid = id;
                    double ox = Math.cos(a) * r, oz = Math.sin(a) * r;
                    Vfx.add(new Fire(pt -> {
                        Entity e = level.getEntity(pid);
                        return e == null ? null : e.getPosition(pt).add(ox, 0.02, oz);
                    }, 0.9 + level.random.nextDouble() * 0.5, 0.45, 2, 9, 0.75f));
                }
            }
            // kulit obsidian Aym: magma menetes, asap tipis
            if (aymStrength(player, 0f) > 0.3f && player.tickCount % 3 == 0 && !firstPerson) {
                double a = level.random.nextDouble() * Math.PI * 2.0, r = 0.28 * player.getScale();
                Vfx.spark(player.getX() + Math.cos(a) * r, player.getY() + (0.4 + level.random.nextDouble() * 1.3) * player.getScale(),
                        player.getZ() + Math.sin(a) * r, 0, -0.02, 0, MAGMA, 0.05f, 14, player.getY());
            }
        }
    }

    /** Bara naik pelan dari badan, lidah api kecil di bahu, asap hitam tipis dari kaki. */
    private static void aura(ClientLevel level, AbstractClientPlayer player, boolean firstPerson, boolean lit) {
        if (firstPerson) {
            return;
        }
        RandomSource r = level.random;
        double sc = player.getScale();
        boolean dark = PassiveConditions.darkness(level);
        if (!lit) {   // Api Neraka padam: cuma asap tipis yang mengepul
            if (player.tickCount % 6 == 0) {
                Vfx.smoke(player.getX() + (r.nextDouble() - 0.5) * 0.5, player.getY() + (0.6 + r.nextDouble()) * sc,
                        player.getZ() + (r.nextDouble() - 0.5) * 0.5, 0, 0.02, 0, SOOT, 0.3f, 30);
            }
            return;
        }
        int every = dark ? Math.max(1, AURA_EMBER_EVERY - 1) : AURA_EMBER_EVERY;
        if (AURA_EMBER_EVERY > 0 && player.tickCount % every == 0) {
            double a = r.nextDouble() * Math.PI * 2.0, rr = (0.25 + r.nextDouble() * 0.2) * sc;
            Vfx.ember(player.getX() + Math.cos(a) * rr, player.getY() + (0.2 + r.nextDouble() * 1.6) * sc,
                    player.getZ() + Math.sin(a) * rr, 0, 0.025 + r.nextDouble() * 0.025, 0, 0.055f, 14 + r.nextInt(10));
        }
        if (player.tickCount % (dark ? 7 : 11) == 0) {   // lidah api kecil di salah satu bahu
            int id = player.getId();
            boolean right = r.nextBoolean();
            Vfx.add(new Fire(pt -> level.getEntity(id) instanceof AbstractClientPlayer p ? shoulder(p, right, pt) : null,
                    0.3 * sc, 0.16 * sc, 2, 8, 0.7f));
        }
        if (player.tickCount % 13 == 0) {
            Vfx.smoke(player.getX() + (r.nextDouble() - 0.5) * 0.6, player.getY() + 0.1, player.getZ() + (r.nextDouble() - 0.5) * 0.6,
                    0, 0.012, 0, ASH, 0.4f, 34);
        }
    }

    /** Titik di atas bahu (dunia). */
    private static Vec3 shoulder(AbstractClientPlayer p, boolean right, float pt) {
        Vec3 pos = p.getPosition(pt);
        float yaw = Mth.rotLerp(pt, p.yBodyRotO, p.yBodyRot) * Mth.DEG_TO_RAD;
        double rx = -Math.cos(yaw), rz = -Math.sin(yaw);
        double s = right ? 1.0 : -1.0, sc = p.getScale();
        return pos.add(rx * s * 0.3 * sc, 1.42 * sc, rz * s * 0.3 * sc);
    }

    // ------------------------------------------------------------------ alat bantu

    private static void schedule(int delay, int duration, ShazamFx.Step step) {
        ShazamFx.schedule(delay, duration, step);
    }

    private static void sound(ClientLevel level, Vec3 at, SoundEvent sound, float volume, float pitch) {
        level.playLocalSound(at.x, at.y, at.z, sound, SoundSource.PLAYERS, volume, ShazamFx.slowPitch(level, pitch), false);
    }

    private static boolean firstPerson(AbstractClientPlayer player) {
        Minecraft mc = Minecraft.getInstance();
        return player == mc.player && mc.options.getCameraType().isFirstPerson();
    }

    private static Vec3 chest(AbstractClientPlayer player) {
        return player.position().add(0, 1.2 * player.getScale(), 0);
    }

    private static Vec3 look(AbstractClientPlayer player) {
        return Vec3.directionFromRotation(player.getXRot(), player.getYHeadRot());
    }

    private static Vec3 flat(Vec3 v) {
        Vec3 f = new Vec3(v.x, 0, v.z);
        return f.lengthSqr() < 1.0E-6 ? new Vec3(0, 0, 1) : f.normalize();
    }

    /** Lidah api di satu titik. */
    private static void fire(Vec3 at, double height, double width, int tongues, int life, float strength) {
        Vfx.add(new Fire(Lightning.Anchor.fixed(at), height, width, tongues, life, strength));
    }

    /** Cincin lidah api di tanah sekeliling center. */
    private static void fireRing(Vec3 center, double radius, int count, double height, double width, int life, float strength) {
        for (int k = 0; k < count; k++) {
            double a = Math.PI * 2.0 * k / count;
            fire(center.add(Math.cos(a) * radius, 0.02, Math.sin(a) * radius), height, width, 2, life, strength);
        }
    }

    /** Petir neraka merayap di kulit selama beberapa tick. */
    private static void surge(AbstractClientPlayer caster, int ticks, float perTick, float width) {
        Lightning.Crackle crackle = new Lightning.Crackle(caster, HELL_LIGHT, perTick, width, ticks).reach(1.1);
        crackle.strength(firstPerson(caster) ? 0.25f : 1f);
        Vfx.add(crackle);
    }

    /** Busur petir neraka dari titik ke luar (rendah, mencakar tanah). */
    private static void arcsOut(ClientLevel level, Vec3 from, int count, double reach, int rgb, float width, int life) {
        for (int k = 0; k < count; k++) {
            Vec3 d = ShazamFx.randomDir(level.random);
            d = new Vec3(d.x, Math.abs(d.y) * 0.7 - 0.1, d.z).normalize();
            Vec3 end = from.add(d.scale(reach * (0.6 + level.random.nextDouble() * 0.5)));
            Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(from), Lightning.Anchor.fixed(end), rgb, width,
                    life + level.random.nextInt(3), 1, 2, 0.32));
        }
    }

    /** Asap hitam neraka yang mengepul dari titik. */
    private static void ash(ClientLevel level, Vec3 c, int count, double radius, double rise) {
        RandomSource r = level.random;
        for (int i = 0, n = Vfx.count(count); i < n; i++) {
            double a = r.nextDouble() * Math.PI * 2.0, d = radius * Math.sqrt(r.nextDouble());
            Vfx.smoke(c.x + Math.cos(a) * d, c.y + 0.2 + r.nextDouble() * 0.4, c.z + Math.sin(a) * d,
                    Math.cos(a) * 0.02, rise * (0.6 + r.nextDouble() * 0.8), Math.sin(a) * 0.02, i % 3 == 0 ? SOOT : ASH,
                    0.5f + r.nextFloat() * 0.45f, 40 + r.nextInt(30));
        }
    }

    /** Bara berhamburan naik dari titik. */
    private static void embers(ClientLevel level, Vec3 c, int count, double radius, double speed) {
        RandomSource r = level.random;
        for (int i = 0, n = Vfx.count(count); i < n; i++) {
            double a = r.nextDouble() * Math.PI * 2.0, d = radius * r.nextDouble();
            Vfx.ember(c.x + Math.cos(a) * d, c.y + 0.1 + r.nextDouble() * 0.3, c.z + Math.sin(a) * d,
                    Math.cos(a) * speed * 0.4, speed * (0.5 + r.nextDouble()), Math.sin(a) * speed * 0.4, 0.06f + r.nextFloat() * 0.04f,
                    18 + r.nextInt(16));
        }
    }

    /** Tanah retak membara + bekas hangus + gelombang (kalau ada tanah). */
    private static Ground.Map scar(ClientLevel level, Vec3 at, double radius, int cracks, float length, int heat) {
        Ground.Map map = ShazamFx.ground(level, at, radius);
        if (map == null || !map.found) {
            return null;
        }
        Vec3 g = map.center(at);
        Vfx.add(new Ground.Cracks(g, map, cracks, length, 150, heat, MAGMA, level.random.nextLong()));
        Vfx.add(new Fx.Scorch(g, 0.4 + length * 0.3, 150, heat, map));
        return map;
    }

    /** Makhluk hidup terdekat di sekitar titik (bukan pengecualian). */
    private static LivingEntity nearest(ClientLevel level, Vec3 pos, double radius, Entity except) {
        List<LivingEntity> list = level.getEntitiesOfClass(LivingEntity.class, new AABB(pos, pos).inflate(radius),
                e -> e != except && e.isAlive());
        LivingEntity best = null;
        double bestD = Double.MAX_VALUE;
        for (LivingEntity e : list) {
            double d = e.position().add(0, e.getBbHeight() * 0.5, 0).distanceToSqr(pos);
            if (d < bestD) {
                bestD = d;
                best = e;
            }
        }
        return best;
    }

    // ------------------------------------------------------------------ petir neraka menyambar tanah

    /** Petir neraka (varian 2) menyembur dari tanah: dipanggil ShazamFx.boltStrike. */
    public static void hellStrike(ClientLevel level, Vec3 g, Ground.Map map, float size) {
        float boostOld = Vfx.setBoost(BOOST);
        try {
            hellStrike0(level, g, map, size);
        } finally {
            Vfx.setBoost(boostOld);
        }
    }

    private static void hellStrike0(ClientLevel level, Vec3 g, Ground.Map map, float size) {
        Vfx.add(new Fx.Flash(g.add(0, 0.8, 0), 1.0f + size * 1.5f, HELL_HOT, 8, 1f));
        Vfx.add(new Fx.Flash(g.add(0, 0.4, 0), 1.6f + size * 1.6f, HELL, 12, 0.8f));
        Vfx.add(new Fx.Wave(g, UP, 1.4 + size * 2.0, 0.3, HELL, 12, 0.85f, 0.15f, map));
        Vfx.add(new Fx.Bubble(g, 0.9 + size, HELL_LIGHT, 7, 0.6f, 0.5, 2.0, true));
        if (map.found) {
            Vfx.add(new Fx.Scorch(g, 0.4 + size * 0.45, 160, 36, map));
            Vfx.add(new Ground.Cracks(g, map, 5 + (int) (size * 3f), 0.9f + size * 1.1f, 160, 44, MAGMA, level.random.nextLong()));
        }
        fire(g, 1.4 + size * 1.3, 0.45 + size * 0.35, 4 + (int) (size * 3f), 18, 1f);
        ShazamFx.ringOfSparks(level, g.add(0, 0.3, 0), (int) (10 + 14 * size), HELL_LIGHT, 0.32 + size * 0.1);
        ash(level, g, 3 + (int) (size * 2), 0.4 + size * 0.35, 0.03);
        embers(level, g, (int) (6 + size * 6), 0.6 + size * 0.6, 0.06);
        ShazamFx.shakeAround(g, 0.25f * size, 26);
    }

    // ------------------------------------------------------------------ berubah wujud

    /**
     * Memanggil enam iblis: lingkaran neraka merah darah di tanah, tanah retak membara melingkar, asap hitam merayap,
     * bara terhisap ke bawah, dan petir neraka kecil merayap di lingkaran. Iblis-iblisnya: ShazamSpirits (DemonFigures).
     */
    private static void summon(AbstractClientPlayer caster, boolean self) {
        ShazamSpirits.start(caster);
        if (self) {
            ShazamCinematic.start();
            ScreenFx.cinema(ShazamAnim.SUMMON_TICKS + ShazamAnim.TRANSFORM_STRIKE + 30);
        }
        int total = ShazamAnim.SUMMON_TICKS + ShazamAnim.TRANSFORM_STRIKE;
        schedule(0, 1, (level, t) -> {
            Vec3 c = caster.position();
            Ground.Map map = ShazamFx.ground(level, c, 3.6);
            double groundY = (map == null ? c.y : map.centerY) + 0.03;
            double sc = caster.getScale();
            Vfx.add(new Runes.Circle(pt -> new Vec3(caster.getPosition(pt).x, groundY, caster.getPosition(pt).z), UP,
                    2.8 * sc, HELL, total + 8, 0.025f, 1f, null));
            Vfx.add(new Runes.Circle(pt -> new Vec3(caster.getPosition(pt).x, groundY + 0.01, caster.getPosition(pt).z), UP,
                    1.6 * sc, HELL_LIGHT, total + 8, -0.04f, 0.7f, null));
            Vfx.add(new Runes.Circle(pt -> new Vec3(caster.getPosition(pt).x, groundY + 0.02, caster.getPosition(pt).z), UP,
                    3.9 * sc, BLOOD, total + 8, -0.015f, 0.5f, null));
            if (map != null && map.found) {
                Vfx.add(new Ground.Cracks(map.center(c), map, 9, 3.4f, total + 60, total + 20, MAGMA, level.random.nextLong()));
            }
            sound(level, c, ShazamSounds.RESONANCE.get(), 1.2f, ShazamSounds.tune(0.36f));
            sound(level, c, ShazamSounds.EARTH_CRACK.get(), 1.0f, ShazamSounds.tune(0.5f));
            sound(level, c, ShazamSounds.DREAD.get(), 0.9f, ShazamSounds.tune(0.7f));
        });
        schedule(0, total, (level, t) -> {
            RandomSource r = level.random;
            double radius = 2.8 * caster.getScale();
            for (int i = 0, n = Vfx.count(2); i < n; i++) {   // bara dari lingkaran terhisap ke kaki, berpilin
                double a = r.nextDouble() * Math.PI * 2.0;
                double x = caster.getX() + Math.cos(a) * radius, z = caster.getZ() + Math.sin(a) * radius;
                double tx = caster.getX() - x, tz = caster.getZ() - z;
                Vfx.mote(x, caster.getY() + 0.3, z, tx * 0.05 - tz * 0.03, -0.004, tz * 0.05 + tx * 0.03,
                        i % 2 == 0 ? HELL : HELL_LIGHT, 0.1f, 20 + r.nextInt(8));
            }
            if (t % 3 == 0) {   // asap hitam merayap di kaki
                double a = r.nextDouble() * Math.PI * 2.0, d = 0.6 + r.nextDouble() * 1.4;
                Vfx.smoke(caster.getX() + Math.cos(a) * d, caster.getY() + 0.1, caster.getZ() + Math.sin(a) * d,
                        -Math.cos(a) * 0.015, 0.01, -Math.sin(a) * 0.015, ASH, 0.5f + r.nextFloat() * 0.3f, 40);
            }
            if (t % 8 == 3) {   // petir neraka kecil merayap di lingkaran
                double a = r.nextDouble() * Math.PI * 2.0;
                Vec3 from = caster.position().add(Math.cos(a) * radius, 0.06, Math.sin(a) * radius);
                Vec3 to = caster.position().add(Math.cos(a + 0.7) * radius * 0.6, 0.06, Math.sin(a + 0.7) * radius * 0.6);
                Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(from), Lightning.Anchor.fixed(to), HELL, 0.05f, 3, 1, 1, 0.3));
            }
            if (t % 5 == 0) {   // api kecil menjilat dari retakan
                double a = r.nextDouble() * Math.PI * 2.0, d = radius * (0.4 + r.nextDouble() * 0.6);
                fire(caster.position().add(Math.cos(a) * d, 0.02, Math.sin(a) * d), 0.5 + r.nextDouble() * 0.5, 0.3, 2, 12, 0.8f);
            }
            if (self && t % 6 == 0) {
                ScreenFx.vignette(0.18f + 0.25f * t / total, 0x200000, 6);
            }
        });
    }

    /**
     * Berubah: kepalan menghantam tanah, retakan menyala merambat ke kaki, petir neraka (MagicBolt varian 2, dibuat
     * server) merambat naik dari bawah kaki, lalu menembus badan: semburan api ke langit, kubah api, tanah terbakar.
     */
    private static void transform(AbstractClientPlayer caster, boolean self) {
        schedule(0, 1, (level, t) -> {
            sound(level, caster.position(), ShazamSounds.THUNDER.get(), 0.7f, ShazamSounds.tune(0.32f));
            sound(level, caster.position(), ShazamSounds.EARTH_CRACK.get(), 1.2f, ShazamSounds.tune(0.45f));
        });
        // 0-18: tenaga neraka terkumpul dari dalam tanah
        schedule(0, ShazamAnim.TRANSFORM_STRIKE, (level, t) -> {
            RandomSource r = level.random;
            if (t == 7) {   // kepalan menghantam tanah
                Vec3 c = caster.position();
                Ground.Map map = scar(level, c, 3.5, 8, 2.6f, 40);
                if (map != null) {
                    Vfx.add(new Fx.Wave(map.center(c), UP, 2.4, 0.3, HELL, 10, 0.8f, 0.1f, map));
                }
                ShazamFx.dustPuffs(level, c, SOOT, 10, 0.8, 0.1);
                if (self) {
                    CameraShake.add(0.25f);
                }
            }
            if (t >= 7) {   // petir neraka kecil dari retakan ke kepalan
                for (int k = 0; k < (t > 12 ? 2 : 1); k++) {
                    double a = r.nextDouble() * Math.PI * 2.0, d = 1.0 + r.nextDouble() * 1.6;
                    Vec3 from = caster.position().add(Math.cos(a) * d, 0.05, Math.sin(a) * d);
                    boolean right = r.nextBoolean();
                    Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(from), pt -> ShazamPoses.handPos(caster, right, pt),
                            HELL, 0.08f, 3, 1, 1, 0.3));
                }
                if (t % 2 == 0) {
                    embers(level, caster.position(), 3, 1.6, 0.06);
                }
            }
            if (t % 2 == 1) {   // asap hitam terhisap ke badan
                double a = r.nextDouble() * Math.PI * 2.0, d = 2.0 + r.nextDouble() * 1.2;
                Vfx.smoke(caster.getX() + Math.cos(a) * d, caster.getY() + 0.2, caster.getZ() + Math.sin(a) * d,
                        -Math.cos(a) * 0.07, 0.02, -Math.sin(a) * 0.07, ASH, 0.5f, 22);
            }
            if (self && t >= ShazamAnim.TRANSFORM_WINDUP) {
                ScreenFx.vignette(0.32f + (t - ShazamAnim.TRANSFORM_WINDUP) * 0.04f, 0x200000, 2);
                if (t % 2 == 0) {
                    CameraShake.add(0.05f);
                }
            }
        });
        schedule(ShazamAnim.TRANSFORM_WINDUP, 1, (level, t) -> Vfx.add(new Fire(Lightning.Anchor.on(caster, 0, 0.02, 0),
                1.2 * caster.getScale(), 0.9 * caster.getScale(), 6, ShazamAnim.BOLT_DESCENT + 4, 0.8f)));
        // 18: petir neraka menembus badan
        schedule(ShazamAnim.TRANSFORM_STRIKE, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vec3 ch = chest(caster);
            Vfx.add(new Fx.Flash(ch, 4.0f, HELL_HOT, 13, 1f));
            Vfx.add(new Fx.Flash(c.add(0, 1.0, 0), 3.4f, HELL, 16, 1f));
            Vfx.add(new Fx.Pillar(c, 60.0, 2.4f, HELL, 18));
            Vfx.add(new Fx.Bubble(c.add(0, 1.0, 0), 3.8, HELL, 12, 0.95f, 1.0, 1.7, true));
            Vfx.add(new Fx.Bubble(c.add(0, 1.0, 0), 2.6, HELL_LIGHT, 10, 0.6f, 1.0, 2.4, true));
            ShazamFx.impact(level, caster, c, 2.8f, HELL, MAGMA, true, 1.6f);
            fireRing(c, 1.6 * caster.getScale(), 8, 1.4, 0.5, 30, 1f);
            fire(c, 3.4 * caster.getScale(), 1.1, 9, 26, 1f);
            ShazamFx.ringOfSparks(level, ch, 70, HELL_LIGHT, 0.6);
            arcsOut(level, c.add(0, 0.2, 0), 9, 5.0, HELL, 0.09f, 6);
            ash(level, c, 12, 3.0, 0.04);
            surge(caster, 44, 2.4f, 0.07f);
            ShazamFx.shakeAround(c, 1.2f, 36);
            eyes(caster, 0, 40);
            if (self) {
                ScreenFlash.flash(1.0f, 0xFFB898);
                ScreenFx.titleKey("title.shazammod.sabbac", 0xFF4A2A, 60, 0);
                FovKick.punch(-0.08f);
            }
        });
        // api naik membelit badan dari kaki ke kepala selagi wujud iblis terbentuk
        schedule(ShazamAnim.TRANSFORM_STRIKE, 24, (level, t) -> {
            double h = caster.getBbHeight();
            for (int k = 0; k < 2; k++) {
                double u = Mth.clamp((t + k * 0.5) / 24.0, 0.0, 1.0);
                double a = u * Math.PI * 6.0 + k * Math.PI;
                double r = 0.6 * caster.getScale();
                Vfx.mote(caster.getX() + Math.cos(a) * r, caster.getY() + u * h, caster.getZ() + Math.sin(a) * r,
                        0, 0.04, 0, k == 0 ? HELL_LIGHT : HELL, 0.16f, 10);
            }
            if (t % 3 == 0) {
                embers(level, caster.position(), 2, 0.6, 0.08);
            }
        });
        schedule(ShazamAnim.TRANSFORM_STRIKE + 25, 1, (level, t) -> ash(level, caster.position(), 6, 1.8, 0.02));
    }

    /** Kembali jadi manusia: api terhisap ke dada, lalu padam jadi abu & asap. */
    private static void revert(AbstractClientPlayer caster, boolean self) {
        schedule(0, ShazamAnim.REVERT_WINDUP, (level, t) -> {
            Vec3 ch = chest(caster);
            for (int i = 0, n = Vfx.count(5); i < n; i++) {
                Vec3 off = ShazamFx.randomDir(level.random).scale(1.4 + level.random.nextDouble() * 0.6);
                Vfx.mote(ch.x + off.x, ch.y + off.y, ch.z + off.z, -off.x * 0.16, -off.y * 0.16, -off.z * 0.16,
                        HELL_LIGHT, 0.09f, 7);
            }
        });
        schedule(ShazamAnim.REVERT_WINDUP, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vec3 ch = c.add(0, 1.2, 0);
            Vfx.add(new Fx.Flash(ch, 2.2f, HELL_LIGHT, 10, 1f));
            Vfx.add(new Fx.Bubble(ch, 1.9, HELL, 9, 0.75f, 1.0, 2.0, true));
            Ground.Map map = ShazamFx.ground(level, c, 3.0);
            if (map != null) {
                Vfx.add(new Fx.Wave(map.center(c), UP, 3.4, 0.35, HELL, 13, 0.75f, 0.1f, map));
                Vfx.add(new Fx.Wave(map.center(c), UP, 2.8, 0.9, SOOT, 20, 0.5f, 0f, map, true));
            }
            ash(level, c, 10, 1.2, 0.03);
            ShazamFx.ringOfSparks(level, ch, 26, HELL_LIGHT, 0.36);
            for (int i = 0, n = Vfx.count(14); i < n; i++) {   // abu berjatuhan
                Vec3 off = ShazamFx.randomDir(level.random).scale(0.6);
                Vfx.dust(ch.x + off.x, ch.y + off.y, ch.z + off.z, off.x * 0.05, 0.01, off.z * 0.05, SOOT, 0.25f, 30);
            }
            ShazamFx.shakeAround(c, 0.4f, 16);
            if (self) {
                ScreenFlash.flash(0.5f, 0xFFD0B8);
            }
        });
    }

    /** Terlempar balik jadi manusia: enam lidah api (enam iblis) tercabut dari dada dan menyelam ke tanah. */
    private static void knockout(AbstractClientPlayer caster, boolean self) {
        schedule(0, 1, (level, t) -> {
            Vfx.add(new Fx.Flash(chest(caster), 1.7f, 0xFFB8A0, 6, 1f));
            ShazamFx.shakeAround(caster.position(), 0.6f, 20);
            if (self) {
                ScreenFx.vignette(0.7f, 0x3A0000, 14);
                CameraShake.add(0.45f);
            }
        });
        schedule(ShazamAnim.KNOCKOUT_BURST, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vec3 ch = chest(caster);
            Vfx.add(new Fx.Flash(ch, 2.8f, HELL_LIGHT, 11, 1f));
            Vfx.add(new Fx.Bubble(ch, 2.5, HELL, 11, 0.8f, 1.0, 2.0, true));
            for (int k = 0; k < 6; k++) {   // enam iblis meninggalkan badan, kembali ke bawah tanah
                double a = Math.PI * 2.0 * (k + level.random.nextDouble() * 0.5) / 6.0;
                double r = 2.0 + level.random.nextDouble() * 1.5;
                Vec3 down = c.add(Math.cos(a) * r, 0.05, Math.sin(a) * r);
                Vfx.add(new Lightning.Arc(Lightning.Anchor.on(caster, 0, 1.2, 0), Lightning.Anchor.fixed(down), HELL,
                        0.09f, 5 + k, 1, 1, 0.3));
                fire(down, 1.2, 0.4, 3, 14, 0.9f);
            }
            scar(level, c, 3.5, 6, 2.0f, 30);
            ash(level, c, 12, 1.4, 0.035);
            ShazamFx.ringOfSparks(level, ch, 36, HELL_LIGHT, 0.5);
            sound(level, c, ShazamSounds.POWER_DOWN.get(), 1.2f, ShazamSounds.tune(0.4f));
            ShazamFx.shakeAround(c, 0.5f, 18);
            if (self) {
                ScreenFlash.flash(0.6f, 0xFFC8B0);
            }
        });
    }

    // ------------------------------------------------------------------ terbang Sabbac

    /** Lepas landas: tanah retak membara, api menyembur dari bawah kaki, sayap api menyala sesaat. */
    private static void launch(AbstractClientPlayer caster) {
        schedule(0, 1, (level, t) -> {
            Vec3 c = caster.position();
            Ground.Map map = ShazamFx.ground(level, c, 3.0);
            if (map != null && map.found && c.y - map.centerY < 1.5) {
                Vec3 g = map.center(c);
                Vfx.add(new Fx.Wave(g, UP, 3.4, 0.3, HELL_LIGHT, 12, 0.85f, 0.1f, map));
                Vfx.add(new Fx.Wave(g, UP, 2.8, 1.0, SOOT, 22, 0.55f, 0f, map, true));
                Vfx.add(new Ground.Cracks(g, map, 7, 1.5f, 120, 36, MAGMA, level.random.nextLong()));
                Vfx.add(new Fx.Scorch(g, 0.8, 120, 30, map));
                fireRing(g, 0.9, 5, 0.9, 0.4, 14, 0.9f);
                ash(level, g, 5, 1.0, 0.03);
            }
            Vfx.add(new Fx.Ripple(c.add(0, 0.2, 0), UP, 3.0, 0.5, 1.9, 0.3, HELL_LIGHT, 10, 0.75f, false));
            ShazamFx.shakeAround(c, 0.4f, 16);
        });
    }

    /** Pendaratan berat: hantaman, magma memercik, lidah api di sekeliling. */
    private static void landing(AbstractClientPlayer caster, boolean self) {
        schedule(0, 1, (level, t) -> {
            Vec3 c = caster.position();
            ShazamFx.impact(level, caster, c, 2.3f, HELL, MAGMA, true, 1.4f);
            Vfx.add(new Fx.Flash(c.add(0, 0.6, 0), 2.8f, HELL_LIGHT, 10, 0.9f));
            Vfx.add(new Fx.Bubble(c, 3.2, HELL, 12, 0.7f, 0.5, 2.2, true));
            fireRing(c, 1.4, 7, 1.1, 0.45, 18, 0.9f);
            ash(level, c, 8, 2.0, 0.03);
            ShazamFx.shakeAround(c, 1.1f, 32);
            if (self) {
                FovKick.punch(-0.05f);
                ScreenFlash.flash(0.25f, 0xFFC0A0);
            }
        });
    }

    private static void crash(AbstractClientPlayer caster) {
        schedule(0, 1, (level, t) -> {
            Vec3 dir = caster.getViewVector(1f);
            Vec3 c = caster.position().add(0, 1.0, 0).add(dir.scale(0.8));
            Vfx.add(new Fx.Flash(c, 2.2f, HELL_LIGHT, 9, 1f));
            Vfx.add(new Fx.Ripple(c, dir.scale(-1), 1.4, 0.4, 3.0, 0.4, HELL_HOT, 11, 0.85f, false));
            for (int i = 0, n = Vfx.count(30); i < n; i++) {
                Vec3 v = ShazamFx.randomDir(level.random).add(dir.scale(-1.2)).normalize().scale(0.25 + level.random.nextDouble() * 0.4);
                Vfx.spark(c.x, c.y, c.z, v.x, v.y, v.z, i % 3 == 0 ? HELL_HOT : HELL_LIGHT, 0.065f, 10 + level.random.nextInt(8),
                        caster.getY());
            }
            Ground.Map map = ShazamFx.ground(level, caster.position(), 2.5);
            if (map != null) {
                Vfx.add(new Ground.Debris(map.center(caster.position()), map, 14, 0.22, 0.32, 0.6, 45));
                ash(level, map.center(caster.position()), 5, 0.8, 0.03);
            }
            ShazamFx.shakeAround(c, 0.9f, 26);
        });
    }

    /** Sonic boom membara: kerucut api, cincin bara, bara memancar ke belakang. */
    private static void sonicBoom(AbstractClientPlayer caster, boolean self) {
        schedule(0, 1, (level, t) -> {
            Vec3 motion = new Vec3(caster.getX() - caster.xo, caster.getY() - caster.yo, caster.getZ() - caster.zo);
            Vec3 dir = motion.lengthSqr() < 1.0E-4 ? caster.getViewVector(1f) : motion.normalize();
            Vec3 c = caster.position().add(0, 0.9, 0);
            Vfx.add(new Fx.Flash(c, 2.6f, HELL_HOT, 8, 0.95f));
            Vfx.add(new Fx.Cone(c.add(dir.scale(1.2)), dir.scale(-1), 5.5, 0.8, 0x4A2A24, 13, 0.6f, 2.0, true));
            Vfx.add(new Fx.Ripple(c, dir.scale(-1), 3.0, 0.6, 4.8, 0.7, SOOT, 15, 0.7f, true));
            Vfx.add(new Fx.Ripple(c, dir.scale(-1), 2.0, 0.4, 3.6, 0.3, HELL_LIGHT, 11, 0.9f, false));
            Vfx.add(new Fx.Ripple(c, dir.scale(-1), 1.2, 0.3, 2.4, 0.18, HELL, 9, 0.8f, false));
            for (int i = 0, n = Vfx.count(16); i < n; i++) {
                Vec3 v = dir.scale(-0.4).add(ShazamFx.randomDir(level.random).scale(0.2));
                Vfx.ember(c.x, c.y, c.z, v.x, v.y, v.z, 0.08f, 16 + level.random.nextInt(8));
            }
            ShazamFx.shakeAround(caster.position(), 0.6f, 40);
            if (self) {
                ScreenFx.speedLines(1f);
                ScreenFlash.flash(0.2f, 0xFFD8C8);
            }
        });
    }

    /** Sabbac nggak berguling: melesat menyamping tegak, meninggalkan bara & bayangan merah. */
    private static void sidestep(AbstractClientPlayer caster, boolean self) {
        schedule(0, 1, (level, t) -> {
            Vec3 c = caster.position().add(0, 1.0, 0);
            Vfx.add(new Fx.Flash(c, 1.4f, HELL_LIGHT, 6, 0.8f));
            Vfx.add(new Fx.Trail(caster, pt -> caster.getPosition(pt).add(0, 1.0, 0), HELL, 0.9f, 8, 7, false));
            embers(level, caster.position(), 8, 0.5, 0.06);
            if (self) {
                ScreenFx.speedLines(0.4f);
            }
        });
    }

    /** Jejak terbang: bara & asap hitam berhamburan di belakang lintasan (dipanggil ShazamFx.flightTrail). */
    static void flightEmbers(ClientLevel level, AbstractClientPlayer player, float speed) {
        float boostOld = Vfx.setBoost(BOOST);
        try {
            flightEmbers0(level, player, speed);
        } finally {
            Vfx.setBoost(boostOld);
        }
    }

    private static void flightEmbers0(ClientLevel level, AbstractClientPlayer player, float speed) {
        if (firstPerson(player) && speed < 1.5f) {
            return;
        }
        Vec3 motion = new Vec3(player.getX() - player.xo, player.getY() - player.yo, player.getZ() - player.zo);
        Vec3 c = player.position().add(0, 0.9 * player.getScale(), 0);
        RandomSource r = level.random;
        for (int i = 0, n = Vfx.count(1 + speed); i < n; i++) {
            Vec3 v = motion.scale(-0.12).add(ShazamFx.randomDir(r).scale(0.04));
            Vfx.ember(c.x + (r.nextDouble() - 0.5) * 0.6, c.y + (r.nextDouble() - 0.5) * 1.0, c.z + (r.nextDouble() - 0.5) * 0.6,
                    v.x, v.y + 0.02, v.z, 0.07f, 12 + r.nextInt(8));
        }
        if (speed > 1.0f && r.nextInt(2) == 0) {
            Vfx.smoke(c.x, c.y, c.z, -motion.x * 0.05, 0.01, -motion.z * 0.05, ASH, 0.45f, 26);
        }
    }

    // ------------------------------------------------------------------ pasif

    /** Api Neraka tiap 2 detik: tanah retak menyala, api & petir neraka menyembur naik menelan badan (ROD_DESCENT tick). */
    private static void pulse(AbstractClientPlayer caster, boolean self) {
        schedule(0, 1, (level, t) -> {
            Vec3 c = caster.position();
            Ground.Map map = ShazamFx.ground(level, c, 2.4);
            if (map != null && map.found && c.y - map.centerY < 1.2) {
                Vec3 g = map.center(c);
                Vfx.add(new Ground.Cracks(g, map, 5, 1.3f, 50, 22, MAGMA, level.random.nextLong()));
                Vfx.add(new Fx.Wave(g, UP, 1.8, 0.25, HELL, 8, 0.7f, 0.2f, map));
            }
            Vfx.add(new Fire(Lightning.Anchor.on(caster, 0, 0.02, 0), 2.2 * caster.getScale(), 0.7 * caster.getScale(), 5,
                    ShazamAnim.ROD_DESCENT + 10, firstPerson(caster) ? 0.35f : 0.95f));
            for (int k = 0; k < 3; k++) {   // petir neraka dari tanah menyambar naik ke dada
                double a = level.random.nextDouble() * Math.PI * 2.0, d = 0.6 + level.random.nextDouble() * 0.8;
                Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(c.add(Math.cos(a) * d, 0.05, Math.sin(a) * d)),
                        Lightning.Anchor.on(caster, 0, 1.2 * caster.getScale(), 0), HELL_LIGHT, 0.06f,
                        ShazamAnim.ROD_DESCENT + 1, 1, 1, 0.28));
            }
        });
        schedule(ShazamAnim.ROD_DESCENT, 1, (level, t) -> {
            Vec3 ch = chest(caster);
            boolean fp = firstPerson(caster);
            Vfx.add(new Fx.Flash(ch, fp ? 1.2f : 2.0f, HELL_LIGHT, 8, fp ? 0.4f : 0.9f));
            Vfx.add(new Fx.Bubble(ch, 1.4, HELL, 8, 0.55f, 1.0, 2.2, true));
            ShazamFx.ringOfSparks(level, ch, 14, HELL_LIGHT, 0.3);
            surge(caster, 14, 1.2f, 0.045f);
            if (PassiveConditions.inferno(level)) {   // Nether: apinya ikut membakar sekeliling
                Ground.Map map = ShazamFx.ground(level, caster.position(), 4.0);
                if (map != null) {
                    Vfx.add(new Fx.Wave(map.center(caster.position()), UP, 4.0, 0.4, HELL, 14, 0.85f, 0.15f, map));
                }
                fireRing(caster.position(), 2.4, 6, 0.9, 0.4, 12, 0.9f);
            }
            if (self) {
                ScreenFx.vignette(0.18f, 0x300800, 3);
            }
        });
    }

    /** Api Neraka padam: lidah api tersendat, bara meredup, asap (di air: uap & gelembung) mengepul. */
    private static void fireOut(AbstractClientPlayer caster, boolean self) {
        boolean water = caster.isUnderWater();
        schedule(0, ShazamAnim.FIRE_OUT_TICKS, (level, t) -> {
            float k = 1f - t / (float) ShazamAnim.FIRE_OUT_TICKS;
            RandomSource r = level.random;
            if (t % 3 == 0 && k > 0.3f && !water) {   // lidah api tersendat makin kecil
                Vfx.add(new Fire(Lightning.Anchor.on(caster, (r.nextDouble() - 0.5) * 0.4, 0.4 + r.nextDouble() * 0.8,
                        (r.nextDouble() - 0.5) * 0.4), 0.4 * k, 0.2, 1, 5, k));
            }
            Vec3 c = caster.position().add(0, (0.3 + r.nextDouble() * 1.4) * caster.getScale(), 0);
            if (water) {
                Vfx.dust(c.x + (r.nextDouble() - 0.5) * 0.6, c.y, c.z + (r.nextDouble() - 0.5) * 0.6, 0, 0.05, 0, 0xC8D4DC,
                        0.3f, 20);
            } else if (t % 2 == 0) {
                Vfx.smoke(c.x + (r.nextDouble() - 0.5) * 0.5, c.y, c.z + (r.nextDouble() - 0.5) * 0.5, 0, 0.03, 0, SOOT, 0.4f, 36);
            }
        });
        schedule(ShazamAnim.FIRE_OUT_TICKS - 2, 1, (level, t) -> {
            Vfx.add(new Fx.Flash(chest(caster), 1.0f, BLOOD, 8, 0.5f));
            ash(level, caster.position(), 5, 0.6, 0.03);
            if (self) {
                ScreenFx.vignette(0.25f, 0x101010, 8);
            }
        });
    }

    /** Api Neraka menyala lagi: cincin api menyala dari tanah, lalu naik ke dada. */
    private static void fireIn(AbstractClientPlayer caster, boolean self) {
        schedule(0, ShazamAnim.FIRE_IN_TICKS, (level, t) -> {
            if (t % 4 == 0) {
                double r = 0.4 + t * 0.07;
                fireRing(caster.position(), r * caster.getScale(), 5, 0.6 + t * 0.03, 0.3, 8, 0.85f);
            }
            if (t == ShazamAnim.FIRE_IN_TICKS - 1) {
                Vfx.add(new Fx.Flash(chest(caster), 1.8f, HELL_LIGHT, 9, 0.9f));
                surge(caster, 12, 1.4f, 0.05f);
                embers(level, caster.position(), 10, 0.6, 0.08);
                if (self) {
                    ScreenFlash.flash(0.2f, 0xFFB898);
                }
            }
        });
    }

    /** Muatan Neraka penuh: kepalan terbakar api neraka (dipanggil ChampionFx). */
    static void chargedFists(ClientLevel level, AbstractClientPlayer p) {
        float boostOld = Vfx.setBoost(BOOST);
        try {
            chargedFists0(level, p);
        } finally {
            Vfx.setBoost(boostOld);
        }
    }

    private static void chargedFists0(ClientLevel level, AbstractClientPlayer p) {
        if (p.tickCount % 2 == 0) {
            for (boolean right : new boolean[] {true, false}) {
                Vec3 h = ShazamPoses.handPos(p, right, 1f);
                Vfx.mote(h.x, h.y, h.z, (level.random.nextDouble() - 0.5) * 0.03, 0.04 + level.random.nextDouble() * 0.03,
                        (level.random.nextDouble() - 0.5) * 0.03, level.random.nextBoolean() ? HELL : HELL_LIGHT, 0.12f, 8);
                Vfx.ember(h.x, h.y, h.z, 0, 0.04, 0, 0.05f, 10);
            }
        }
        if (p.tickCount % 6 == 0) {
            Vec3 h = ShazamPoses.handPos(p, level.random.nextBoolean(), 1f);
            Vfx.glint(h.x, h.y, h.z, HELL_LIGHT, 0.24f, 6);
        }
    }

    /** Tinju Neraka (Muatan Neraka penuh): ledakan api neraka di sasaran. */
    private static void hellPunch(AbstractClientPlayer caster, Vec3 at, boolean self) {
        schedule(0, 1, (level, t) -> {
            CineFx.impact(level, at, 1.6f, HELL, HELL_HOT, self, true);
            fire(at.add(0, -0.5, 0), 1.8, 0.7, 5, 16, 1f);
            Vfx.add(new Lightning.Arc(pt -> ShazamPoses.handPos(caster, true, pt), Lightning.Anchor.fixed(at), HELL_LIGHT,
                    0.08f, 4, 1, 1, 0.3));
            embers(level, at, 14, 0.5, 0.12);
            ash(level, at, 4, 0.6, 0.03);
        });
    }

    /** Kulit Bara: serangan ditelan api di titik kena. */
    private static void engulf(Vec3 at) {
        schedule(0, 1, (level, t) -> {
            Vfx.add(new Fx.Flash(at, 1.2f, HELL_LIGHT, 7, 0.85f));
            fire(at.add(0, -0.3, 0), 0.9, 0.35, 3, 10, 1f);
            ShazamFx.ringOfSparks(level, at, 10, HELL_LIGHT, 0.25);
        });
    }

    /** Tinju Sabbac biasa: bara & api kecil. */
    private static void punch(Vec3 at) {
        schedule(0, 1, (level, t) -> {
            Vfx.add(new Fx.Flash(at, 0.9f, HELL_LIGHT, 5, 0.7f));
            for (int i = 0, n = Vfx.count(8); i < n; i++) {
                Vec3 v = ShazamFx.randomDir(level.random).scale(0.12);
                Vfx.ember(at.x, at.y, at.z, v.x, v.y + 0.04, v.z, 0.06f, 12 + level.random.nextInt(6));
            }
        });
    }

    /** Hati Pahlawan versi Sabbac: rantai neraka mencap penyerang si lemah (dipanggil ChampionFx). */
    static void preyCall(AbstractClientPlayer caster, Vec3 pos, boolean self) {
        float boostOld = Vfx.setBoost(BOOST);
        try {
            preyCall0(caster, pos, self);
        } finally {
            Vfx.setBoost(boostOld);
        }
    }

    private static void preyCall0(AbstractClientPlayer caster, Vec3 pos, boolean self) {
        schedule(0, 1, (level, t) -> {
            LivingEntity foe = nearest(level, pos, 2.5, caster);
            Lightning.Anchor chest = Lightning.Anchor.on(caster, 0, 1.3 * caster.getScale(), 0);
            Lightning.Anchor target;
            if (foe != null) {
                target = pt -> foe.getPosition(pt).add(0, foe.getBbHeight() * 0.6, 0);
                Vfx.add(new Runes.Reticle(foe, HELL_LIGHT, 160, 2));
            } else {
                target = Lightning.Anchor.fixed(pos);
            }
            Vfx.add(new Chain(chest, target, 0.6, 4, 16));
            Vfx.add(new Fx.Flash(pos, 1.6f, HELL, 8, 0.9f));
            if (self) {
                sound(level, caster.position(), ShazamSounds.DARK_HISS.get(), 1.0f, ShazamSounds.tune(0.8f));
                ScreenFx.vignette(0.25f, 0x3A0800, 6);
            }
        });
    }

    // ------------------------------------------------------------------ S - Tanduk Setan

    private static void horns(AbstractClientPlayer caster, boolean self) {
        HORNS.put(caster.getId(), caster.level().getGameTime());
        // menggaruk tanah seperti banteng neraka
        schedule(0, ShazamAnim.HORN_WINDUP, (level, t) -> {
            if (t % 2 == 0) {
                Vec3 foot = caster.position().add(flat(caster.getViewVector(1f)).scale(-0.3));
                Ground.Map map = ShazamFx.ground(level, foot, 1.5);
                int dust = map == null ? SOOT : map.dustColor(level, foot);
                ShazamFx.dustPuffs(level, foot, dust, 4, 0.3, 0.06);
                embers(level, foot, 3, 0.3, 0.05);
            }
            if (t % 2 == 1) {   // lidah api di ujung tanduk
                for (int s = -1; s <= 1; s += 2) {
                    int side = s;
                    Vfx.add(new Fire(pt -> hornTip(caster, side, pt), 0.25, 0.12, 1, 4, 0.9f));
                }
            }
            if (self && t % 2 == 0) {
                CameraShake.add(0.04f);
            }
        });
        schedule(ShazamAnim.HORN_WINDUP, 1, (level, t) -> {
            Vec3 c = caster.position().add(0, 1.0, 0);
            Vec3 dir = flat(caster.getViewVector(1f));
            Vfx.add(new Fx.Flash(c.add(dir.scale(0.6)), 1.8f, HELL_LIGHT, 7, 0.9f));
            Vfx.add(new Fx.Ripple(c, dir, 1.0, 0.5, 2.2, 0.25, HELL, 9, 0.8f, false));
            Vfx.add(new Fx.Trail(caster, pt -> caster.getPosition(pt).add(0, 1.3 * caster.getScale(), 0), HELL, 1.0f, 8,
                    ShazamAnim.HORN_TICKS + 1, false));
            for (int s = -1; s <= 1; s += 2) {
                int side = s;
                Vfx.add(new Fx.Trail(caster, pt -> hornTip(caster, side, pt), HELL_HOT, 0.14f, 7, ShazamAnim.HORN_TICKS + 1,
                        false));
            }
            if (self) {
                ScreenFx.speedLines(0.8f);
                FovKick.kick(0.15f);
            }
        });
        schedule(ShazamAnim.HORN_WINDUP, ShazamAnim.HORN_TICKS, (level, t) -> {
            Vec3 c = caster.position();
            RandomSource r = level.random;
            for (int i = 0, n = Vfx.count(4); i < n; i++) {
                Vfx.ember(c.x + (r.nextDouble() - 0.5) * 0.8, c.y + 0.2 + r.nextDouble() * 1.4, c.z + (r.nextDouble() - 0.5) * 0.8,
                        0, 0.03, 0, 0.08f, 14);
            }
            if (caster.onGround() && t % 2 == 0) {
                Ground.Map map = ShazamFx.ground(level, c, 1.2);
                if (map != null && map.found) {
                    Vfx.add(new Fx.Scorch(map.center(c), 0.5, 120, 20, map));
                }
            }
        });
        schedule(ShazamAnim.HORN_WINDUP + ShazamAnim.HORN_TICKS, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vec3 front = c.add(flat(caster.getViewVector(1f)).scale(1.0)).add(0, 1.2, 0);
            Vfx.add(new Fx.Flash(front, 2.4f, HELL_HOT, 9, 1f));
            Ground.Map map = ShazamFx.ground(level, c, 3.5);
            if (map != null) {
                Vfx.add(new Fx.Wave(map.center(c), UP, 3.5, 0.35, HELL, 12, 0.85f, 0.1f, map));
                Vfx.add(new Fx.Wave(map.center(c), UP, 2.8, 0.9, SOOT, 20, 0.5f, 0f, map, true));
            }
            ShazamFx.ringOfSparks(level, front, 24, HELL_LIGHT, 0.45);
            ShazamFx.shakeAround(c, 0.7f, 22);
        });
    }

    /** Ujung tanduk kiri/kanan (perkiraan dunia, dari posisi kepala dan arah hadap). */
    static Vec3 hornTip(AbstractClientPlayer p, int side, float pt) {
        Vec3 eye = p.getEyePosition(pt);
        float yaw = Mth.rotLerp(pt, p.yHeadRotO, p.yHeadRot) * Mth.DEG_TO_RAD;
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);
        double rx = -Math.cos(yaw), rz = -Math.sin(yaw);
        double sc = p.getScale() * (1.0 + 0.5 * hornCharge(p, pt));
        return eye.add(rx * side * 0.36 * sc + fx * 0.18 * sc, 0.5 * sc, rz * side * 0.36 * sc + fz * 0.18 * sc);
    }

    /** Tanduk menyeruduk satu musuh. */
    private static void gore(AbstractClientPlayer caster, Vec3 at) {
        schedule(0, 1, (level, t) -> {
            Vfx.add(new Fx.Flash(at, 1.6f, HELL_HOT, 7, 1f));
            Vfx.add(new Fx.Flash(at, 2.2f, HELL, 10, 0.7f));
            ShazamFx.ringOfSparks(level, at, 18, HELL_LIGHT, 0.4);
            fire(at.add(0, -0.4, 0), 0.9, 0.35, 3, 10, 1f);
        });
    }

    // ------------------------------------------------------------------ A - Tubuh Aym

    private static void aym(AbstractClientPlayer caster, boolean self) {
        long now = caster.level().getGameTime();
        AYM.put(caster.getId(), new long[] {now + ShazamAnim.AYM_WINDUP, now + ShazamAnim.AYM_WINDUP + ShazamAnim.AYM_TICKS});
        schedule(0, ShazamAnim.AYM_WINDUP, (level, t) -> {   // asap hitam terhisap ke badan, tanah memanas
            Vec3 ch = chest(caster);
            for (int i = 0, n = Vfx.count(4); i < n; i++) {
                Vec3 off = ShazamFx.randomDir(level.random).scale(1.6 + level.random.nextDouble() * 0.6);
                Vfx.smoke(ch.x + off.x, ch.y + off.y * 0.6, ch.z + off.z, -off.x * 0.12, -off.y * 0.06, -off.z * 0.12, ASH, 0.35f, 10);
            }
        });
        schedule(ShazamAnim.AYM_WINDUP, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vec3 ch = chest(caster);
            Vfx.add(new Fx.Flash(ch, 2.2f, MAGMA, 10, 1f));
            Ground.Map map = scar(level, c, 3.0, 6, 1.8f, 50);
            if (map != null) {
                Vfx.add(new Fx.Wave(map.center(c), UP, 3.4, 0.4, HELL, 14, 0.85f, 0.1f, map));
                Vfx.add(new Fx.Wave(map.center(c), UP, 2.8, 0.9, OBSIDIAN, 22, 0.6f, 0f, map, true));
            }
            ShazamFx.ringOfSparks(level, ch, 24, MAGMA, 0.35);
            sound(level, c, ShazamSounds.EARTH_CRACK.get(), 1.0f, ShazamSounds.tune(0.7f));
            if (self) {
                ScreenFx.vignette(0.4f, 0x1A0404, 10);
            }
        });
    }

    /** Letusan Aym: cangkang obsidian pecah, magma meledak keluar. */
    private static void aymBurst(AbstractClientPlayer caster, boolean self) {
        schedule(0, ShazamAnim.NOVA_WINDUP, (level, t) -> {   // urat magma memijar terang sesaat
            Vfx.add(new Fx.Glow(caster, pt -> caster.getPosition(pt).add(0, 1.1 * caster.getScale(), 0), 1.4f, MAGMA, 4, 2));
        });
        schedule(ShazamAnim.NOVA_WINDUP, 1, (level, t) -> {
            AYM.remove(caster.getId());
            Vec3 c = caster.position();
            Vec3 ch = chest(caster);
            Vfx.add(new Fx.Flash(ch, 3.4f, HELL_HOT, 11, 1f));
            Vfx.add(new Fx.Bubble(ch, 5.0, MAGMA, 13, 0.85f, 1.0, 2.0, true));
            ShazamFx.impact(level, caster, c, 2.0f, HELL, MAGMA, true, 1.2f);
            RandomSource r = level.random;
            for (int i = 0, n = Vfx.count(26); i < n; i++) {   // pecahan obsidian beterbangan
                Vec3 v = ShazamFx.randomDir(r);
                v = new Vec3(v.x, Math.abs(v.y) * 0.6 + 0.1, v.z).scale(0.3 + r.nextDouble() * 0.3);
                Vfx.dust(ch.x, ch.y, ch.z, v.x, v.y, v.z, OBSIDIAN, 0.18f + r.nextFloat() * 0.12f, 22 + r.nextInt(10));
                if (i % 2 == 0) {
                    Vfx.spark(ch.x, ch.y, ch.z, v.x * 1.4, v.y * 1.4, v.z * 1.4, MAGMA, 0.06f, 14 + r.nextInt(8), c.y);
                }
            }
            fireRing(c, 2.2, 8, 1.1, 0.45, 18, 1f);
            ShazamFx.shakeAround(c, 0.9f, 26);
            if (self) {
                ScreenFlash.flash(0.45f, 0xFFB080);
                CameraShake.add(0.3f);
            }
        });
    }

    // ------------------------------------------------------------------ B - Rantai Belial

    private static void chains(AbstractClientPlayer caster, boolean self) {
        schedule(0, ShazamAnim.CHAIN_WINDUP, (level, t) -> {
            if (t == ShazamAnim.CHAIN_WINDUP - 1) {   // cakar mencakar tanah: retakan merambat
                Vec3 at = caster.position().add(flat(caster.getViewVector(1f)).scale(0.8));
                Ground.Map map = scar(level, at, 3.0, 7, 2.6f, 40);
                if (map != null) {
                    Vfx.add(new Fx.Wave(map.center(at), UP, 2.2, 0.3, HELL, 10, 0.8f, 0.1f, map));
                }
                ShazamFx.dustPuffs(level, at, SOOT, 8, 0.6, 0.08);
                if (self) {
                    CameraShake.add(0.2f);
                }
            }
        });
        schedule(ShazamAnim.CHAIN_WINDUP, 1, (level, t) -> {   // rantai menyeruak dari tanah di sekeliling
            Vec3 c = caster.position();
            for (int k = 0; k < 5; k++) {
                double a = Math.PI * 2.0 * (k + level.random.nextDouble() * 0.5) / 5.0, d = 1.5 + level.random.nextDouble();
                Vec3 base = c.add(Math.cos(a) * d, 0.0, Math.sin(a) * d);
                Vec3 top = base.add((level.random.nextDouble() - 0.5) * 0.8, 1.8 + level.random.nextDouble() * 1.2,
                        (level.random.nextDouble() - 0.5) * 0.8);
                Vfx.add(new Chain(Lightning.Anchor.fixed(base), Lightning.Anchor.fixed(top), 0.1, 3, 12));
                Vfx.add(new Fx.Flash(base.add(0, 0.2, 0), 0.9f, HELL, 6, 0.8f));
            }
            embers(level, c, 12, 2.0, 0.08);
        });
    }

    /** Satu rantai membelit musuh di pos: dua rantai dari tanah di sekitarnya, satu dari tangan Sabbac. */
    private static void bind(AbstractClientPlayer caster, Vec3 pos) {
        schedule(0, 1, (level, t) -> {
            LivingEntity target = nearest(level, pos.add(0, 0.8, 0), 1.6, caster);
            Lightning.Anchor body = target == null ? Lightning.Anchor.fixed(pos.add(0, 0.9, 0))
                    : pt -> target.getPosition(pt).add(0, target.getBbHeight() * 0.55, 0);
            int life = ShazamAnim.CHAIN_PULL + 12;
            for (int k = 0; k < 2; k++) {
                double a = Math.PI * k + level.random.nextDouble() * 1.2;
                Vec3 ground = pos.add(Math.cos(a) * 1.3, 0.02, Math.sin(a) * 1.3);
                Vfx.add(new Chain(Lightning.Anchor.fixed(ground), body, 0.15, 3, life));
                Vfx.add(new Fx.Flash(ground.add(0, 0.2, 0), 0.8f, HELL, 6, 0.7f));
            }
            Vfx.add(new Chain(pt -> ShazamPoses.handPos(caster, true, pt), body, 0.5, 5, life - 4));
            Ground.Map map = scar(level, pos, 2.0, 4, 1.2f, 30);
            if (map != null) {
                Vfx.add(new Fx.Wave(map.center(pos), UP, 1.6, 0.25, HELL, 9, 0.75f, 0.15f, map));
            }
            ShazamFx.ringOfSparks(level, pos.add(0, 0.6, 0), 10, CHAIN, 0.25);
        });
    }

    // ------------------------------------------------------------------ B - Napas Beelzebub

    private static void breath(AbstractClientPlayer caster, boolean self) {
        eyes(caster, 2, ShazamAnim.BREATH_WINDUP + ShazamAnim.BREATH_TICKS);
        schedule(0, ShazamAnim.BREATH_WINDUP, (level, t) -> {   // menarik napas: bara & asap terhisap ke mulut
            Vec3 mouth = caster.getEyePosition().add(0, -0.15, 0);
            for (int i = 0, n = Vfx.count(4); i < n; i++) {
                Vec3 off = ShazamFx.randomDir(level.random).scale(1.4 + level.random.nextDouble() * 0.8);
                Vfx.mote(mouth.x + off.x, mouth.y + off.y * 0.6, mouth.z + off.z, -off.x * 0.17, -off.y * 0.1, -off.z * 0.17,
                        HELL, 0.08f, 6);
            }
        });
        schedule(ShazamAnim.BREATH_WINDUP, ShazamAnim.BREATH_TICKS, (level, t) -> {
            RandomSource r = level.random;
            Vec3 look = look(caster);
            Vec3 mouth = caster.getEyePosition().add(0, -0.15 * caster.getScale(), 0).add(look.scale(0.45 * caster.getScale()));
            boolean fp = firstPerson(caster);
            for (int i = 0, n = Vfx.count(fp ? 5 : 8); i < n; i++) {   // semburan api: cepat, menyebar, mendingin ke merah
                Vec3 v = look.scale(0.55 + r.nextDouble() * 0.45).add(ShazamFx.randomDir(r).scale(0.1 + r.nextDouble() * 0.06));
                int col = i % 3 == 0 ? HELL_HOT : i % 3 == 1 ? HELL_LIGHT : HELL;
                Vfx.mote(mouth.x, mouth.y, mouth.z, v.x, v.y, v.z, col, 0.22f + r.nextFloat() * 0.2f, 9 + r.nextInt(5));
            }
            for (int i = 0, n = Vfx.count(2); i < n; i++) {
                Vec3 v = look.scale(0.5 + r.nextDouble() * 0.3).add(ShazamFx.randomDir(r).scale(0.12));
                Vfx.ember(mouth.x, mouth.y, mouth.z, v.x, v.y, v.z, 0.08f, 14 + r.nextInt(8));
            }
            if (t % 2 == 0) {
                Vfx.add(new Fx.Cone(mouth, look, 6.5 * caster.getScale(), 0.85, HELL, 4, fp ? 0.25f : 0.5f, 2.0, false));
                Vec3 far = mouth.add(look.scale(5.0 + r.nextDouble() * 2.0));
                Vfx.smoke(far.x, far.y, far.z, look.x * 0.05, 0.03, look.z * 0.05, ASH, 0.6f, 30);
            }
            for (int i = 0, n = Vfx.count(3); i < n; i++) {   // kawanan lalat Beelzebub menari di sekitar semburan
                Vec3 p = mouth.add(look.scale(1.0 + r.nextDouble() * 5.0)).add(ShazamFx.randomDir(r).scale(0.6 + r.nextDouble() * 0.8));
                Vec3 v = ShazamFx.randomDir(r).scale(0.15);
                Vfx.dust(p.x, p.y, p.z, v.x, v.y, v.z, FLY, 0.05f, 10 + r.nextInt(6));
            }
            if (self && t % 4 == 0) {
                CameraShake.add(0.05f);
            }
        });
        schedule(ShazamAnim.BREATH_WINDUP + ShazamAnim.BREATH_TICKS, 1, (level, t) -> {
            Vec3 mouth = caster.getEyePosition().add(look(caster).scale(0.4));
            for (int i = 0; i < 4; i++) {
                Vfx.smoke(mouth.x, mouth.y, mouth.z, (level.random.nextDouble() - 0.5) * 0.03, 0.03, (level.random.nextDouble() - 0.5) * 0.03,
                        SOOT, 0.3f, 26);
            }
        });
    }

    // ------------------------------------------------------------------ A - Teror Asmodeus

    private static void roar(AbstractClientPlayer caster, boolean self) {
        eyes(caster, ShazamAnim.TERROR_WINDUP - 1, 50);
        schedule(0, ShazamAnim.TERROR_WINDUP, (level, t) -> {   // amarah terkumpul: asap hitam terhisap, tanah bergetar
            Vec3 ch = chest(caster);
            for (int i = 0, n = Vfx.count(3); i < n; i++) {
                Vec3 off = ShazamFx.randomDir(level.random).scale(2.2 + level.random.nextDouble());
                Vfx.smoke(ch.x + off.x, ch.y + off.y * 0.5, ch.z + off.z, -off.x * 0.14, -off.y * 0.05, -off.z * 0.14, ASH, 0.35f, 10);
            }
            ShazamFx.swirlDust(level, caster, t);
            if (self) {
                CameraShake.add(0.04f);
            }
        });
        schedule(ShazamAnim.TERROR_WINDUP, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vec3 mouth = caster.getEyePosition();
            Vec3 lk = look(caster);
            Vfx.add(new Fx.Flash(mouth, 2.2f, HELL, 10, 0.9f));
            for (int k = 0; k < 4; k++) {   // gelombang raungan dari mulut
                int delay = k * 2;
                schedule(delay, 1, (lv, tt) -> {
                    Vfx.add(new Fx.Ripple(caster.getEyePosition().add(lk.scale(0.4)), lk, 6.0, 0.4, 2.6, 0.22, HELL_LIGHT, 13,
                            0.75f, false));
                    Vfx.add(new Fx.Ripple(caster.getEyePosition().add(lk.scale(0.4)), lk, 5.0, 0.4, 2.2, 0.5, SOOT, 14, 0.5f, true));
                });
            }
            Ground.Map map = ShazamFx.ground(level, c, 4.0);
            if (map != null) {   // gelombang teror hitam merambat di tanah
                Vfx.add(new Fx.Wave(map.center(c), UP, 10.0, 1.6, ASH, 26, 0.7f, 0f, map, true));
                Vfx.add(new Fx.Wave(map.center(c), UP, 9.0, 0.35, HELL, 18, 0.8f, 0.05f, map));
            }
            Vfx.add(new Fx.Bubble(c, 8.0, BLOOD, 16, 0.6f, 0.5, 2.4, true));
            ShazamFx.ringOfSparks(level, chest(caster), 30, HELL, 0.45);
            ShazamFx.shakeAround(c, 0.8f, 30);
            Minecraft mc = Minecraft.getInstance();
            if (self) {
                ScreenFx.vignette(0.55f, 0x300000, 12);
                CameraShake.add(0.4f);
            } else if (mc.player != null && mc.player.distanceToSqr(caster) < 12.0 * 12.0) {
                ScreenFx.vignette(0.75f, 0x120000, 40);   // yang ketakutan: pandangan menggelap
                CameraShake.add(0.25f);
            }
        });
    }

    // ------------------------------------------------------------------ C - Kepakan Crateis

    private static void wingsBeat(AbstractClientPlayer caster, boolean self) {
        long now = caster.level().getGameTime();
        WINGS_UNTIL.put(caster.getId(), now + ShazamAnim.WINGS_WINDUP + 60);
        Wings w = WINGS.get(caster.getId());
        if (w == null || w.done) {
            w = new Wings(caster);
            WINGS.put(caster.getId(), w);
            Vfx.add(w);
        }
        w.want(1f, 1.35f);
        Wings wings = w;
        schedule(0, ShazamAnim.WINGS_WINDUP, (level, t) -> {   // sayap terbentang, api terhisap ke punggung
            Vec3 back = caster.position().add(0, 1.3 * caster.getScale(), 0);
            for (int i = 0, n = Vfx.count(3); i < n; i++) {
                Vec3 off = ShazamFx.randomDir(level.random).scale(1.8);
                Vfx.mote(back.x + off.x, back.y + off.y * 0.5, back.z + off.z, -off.x * 0.15, -off.y * 0.07, -off.z * 0.15,
                        HELL_LIGHT, 0.08f, 6);
            }
        });
        schedule(ShazamAnim.WINGS_WINDUP, 1, (level, t) -> {
            wings.flap();
            Vec3 c = caster.position();
            Vfx.add(new Fx.Flash(c.add(0, 1.3, 0), 3.0f, HELL_LIGHT, 10, 0.9f));
            Ground.Map map = ShazamFx.ground(level, c, 4.0);
            if (map != null) {
                Vfx.add(new Fx.Wave(map.center(c), UP, 7.0, 0.5, HELL, 16, 0.9f, 0.1f, map));
                Vfx.add(new Fx.Wave(map.center(c), UP, 6.0, 1.4, SOOT, 26, 0.6f, 0f, map, true));
                ShazamFx.dustPuffs(level, map.center(c), map.dustColor(level, c), 18, 1.4, 0.24);
            }
            Vfx.add(new Fx.Ripple(c.add(0, 1.0, 0), UP, 2.0, 1.0, 6.5, 0.4, HELL_LIGHT, 12, 0.8f, false));
            fireRing(c, 2.6, 10, 1.2, 0.5, 16, 1f);
            embers(level, c, 20, 2.5, 0.12);
            ShazamFx.shakeAround(c, 0.8f, 28);
            if (self) {
                FovKick.punch(-0.06f);
                CameraShake.add(0.3f);
                ScreenFlash.flash(0.2f, 0xFFC8A8);
            }
        });
    }

    // ------------------------------------------------------------------ R - Gerbang Neraka

    private static void hellgate(AbstractClientPlayer caster, boolean self) {
        eyes(caster, ShazamAnim.HELLGATE_WINDUP - 2, 60);
        schedule(0, ShazamAnim.HELLGATE_WINDUP, (level, t) -> {   // tanah bergemuruh, retakan melingkar membara
            Vec3 c = caster.position();
            if (t == 2 || t == 7) {
                scar(level, c, 4.5, 6 + t, 1.6f + t * 0.2f, 60);
            }
            embers(level, c, 4, 2.5, 0.07);
            if (t % 3 == 0) {
                double a = level.random.nextDouble() * Math.PI * 2.0, d = 1.5 + level.random.nextDouble() * 2.5;
                fire(c.add(Math.cos(a) * d, 0.02, Math.sin(a) * d), 0.6, 0.3, 2, 10, 0.8f);
            }
            if (self) {
                ScreenFx.vignette(0.25f + t * 0.03f, 0x240000, 3);
                CameraShake.add(0.05f + t * 0.006f);
            }
        });
        schedule(ShazamAnim.HELLGATE_WINDUP, 1, (level, t) -> {
            Vec3 c = caster.position();
            Ground.Map map = ShazamFx.ground(level, c, 5.0);
            double gy = map == null ? c.y + 0.03 : map.centerY + 0.03;
            Vfx.add(new Runes.Circle(pt -> new Vec3(caster.getPosition(pt).x, gy, caster.getPosition(pt).z), UP, 5.0, HELL,
                    80, 0.03f, 1f, null));
            Vfx.add(new Runes.Circle(pt -> new Vec3(caster.getPosition(pt).x, gy + 0.01, caster.getPosition(pt).z), UP, 3.2,
                    BLOOD, 80, -0.05f, 0.8f, null));
            Vfx.add(new Fx.Flash(chest(caster), 4.2f, HELL_HOT, 14, 1f));
            Vfx.add(new Fx.Bubble(c.add(0, 1.0, 0), 5.5, HELL, 16, 0.9f, 0.5, 1.8, true));
            ShazamFx.impact(level, caster, c, 3.0f, HELL, MAGMA, true, 1.8f);
            fireRing(c, 2.4, 10, 1.8, 0.6, 30, 1f);
            fireRing(c, 4.2, 14, 1.2, 0.5, 26, 0.9f);
            arcsOut(level, c.add(0, 0.3, 0), 10, 5.5, HELL, 0.1f, 7);
            surge(caster, 40, 2.4f, 0.07f);
            ash(level, c, 14, 3.5, 0.04);
            ShazamFx.shakeAround(c, 1.4f, 40);
            if (self) {
                ScreenFlash.flash(0.7f, 0xFFB090);
                ScreenFx.titleKey("title.shazammod.hellgate", 0xFF3A20, 50, 0);
                FovKick.punch(-0.1f);
            }
        });
    }

    /** Semburan api neraka dari tanah di bawah satu musuh (badai Gerbang Neraka & tinju raksasa). */
    private static void geyser(Vec3 at) {
        schedule(0, 1, (level, t) -> {
            Ground.Map map = scar(level, at, 2.0, 5, 1.2f, 30);
            Vec3 g = map == null ? at : map.center(at);
            Vfx.add(new Fx.Flash(g.add(0, 0.8, 0), 2.0f, HELL_HOT, 9, 1f));
            Vfx.add(new Fx.Pillar(g, 7.0, 1.3f, HELL, 12));
            fire(g, 4.0, 1.0, 7, 22, 1f);
            if (map != null) {
                Vfx.add(new Fx.Wave(g, UP, 2.0, 0.3, HELL, 10, 0.8f, 0.15f, map));
            }
            RandomSource r = level.random;
            for (int i = 0, n = Vfx.count(14); i < n; i++) {
                Vfx.spark(g.x, g.y + 0.2, g.z, (r.nextDouble() - 0.5) * 0.3, 0.4 + r.nextDouble() * 0.4, (r.nextDouble() - 0.5) * 0.3,
                        i % 3 == 0 ? HELL_HOT : HELL_LIGHT, 0.06f, 14 + r.nextInt(8), g.y);
            }
            ash(level, g, 5, 0.6, 0.06);
            ShazamFx.shakeAround(g, 0.4f, 18);
        });
    }

    // ------------------------------------------------------------------ M - Panggil Petir Neraka

    private static void call(AbstractClientPlayer caster, boolean self) {
        eyes(caster, ShazamAnim.SABBAC_CALL_WINDUP - 1, 40);
        schedule(0, ShazamAnim.SABBAC_CALL_WINDUP, (level, t) -> {
            Vec3 hand = ShazamPoses.handPos(caster, true, 1f);
            if (t == 2) {   // telapak menekan tanah
                scar(level, caster.position(), 3.0, 7, 2.0f, 40);
            }
            if (t >= 2) {
                RandomSource r = level.random;
                double a = r.nextDouble() * Math.PI * 2.0, d = 0.8 + r.nextDouble() * 1.6;
                Vec3 from = caster.position().add(Math.cos(a) * d, 0.05, Math.sin(a) * d);
                Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(from), Lightning.Anchor.fixed(hand), HELL, 0.06f, 3, 1, 1, 0.3));
                embers(level, caster.position(), 2, 1.5, 0.06);
            }
            if (self) {
                ScreenFx.vignette(0.25f + t * 0.03f, 0x200000, 3);
                if (t % 2 == 0) {
                    CameraShake.add(0.05f);
                }
            }
        });
        schedule(ShazamAnim.SABBAC_CALL_WINDUP, 1, (level, t) -> {
            Vec3 ch = chest(caster);
            Vfx.add(new Fx.Flash(ch, 3.4f, HELL_HOT, 12, 1f));
            Vfx.add(new Fx.Bubble(ch, 3.2, HELL, 12, 0.85f, 1.0, 1.8, true));
            fire(caster.position(), 2.8 * caster.getScale(), 1.0, 7, 24, 1f);
            surge(caster, 50, 2.6f, 0.07f);
            ShazamFx.ringOfSparks(level, ch, 40, HELL_LIGHT, 0.5);
            if (self) {
                ScreenFlash.flash(0.75f, 0xFFB898);
                FovKick.punch(-0.06f);
            }
        });
    }

    // ------------------------------------------------------------------ J - Pasukan Iblis

    private static void legion(AbstractClientPlayer caster, boolean self) {
        schedule(0, ShazamAnim.LEGION_WINDUP, (level, t) -> {   // asap hitam berkumpul di kaki
            Vec3 c = caster.position();
            RandomSource r = level.random;
            for (int i = 0, n = Vfx.count(2); i < n; i++) {
                double a = r.nextDouble() * Math.PI * 2.0, d = 2.5 + r.nextDouble() * 2.0;
                Vfx.smoke(c.x + Math.cos(a) * d, c.y + 0.1, c.z + Math.sin(a) * d, -Math.cos(a) * 0.05, 0.01,
                        -Math.sin(a) * 0.05, ASH, 0.45f, 24);
            }
        });
        schedule(ShazamAnim.LEGION_WINDUP, 1, (level, t) -> {
            Vec3 c = caster.position();
            Ground.Map map = scar(level, c, 5.0, 12, 4.2f, 70);
            double gy = map == null ? c.y + 0.03 : map.centerY + 0.03;
            Vfx.add(new Runes.Circle(Lightning.Anchor.fixed(new Vec3(c.x, gy, c.z)), UP, 4.0, BLOOD, 50, 0.03f, 0.9f, map));
            if (map != null) {
                Vfx.add(new Fx.Wave(map.center(c), UP, 5.0, 0.45, HELL, 16, 0.85f, 0.1f, map));
                Vfx.add(new Fx.Wave(map.center(c), UP, 4.4, 1.2, SOOT, 26, 0.6f, 0f, map, true));
            }
            Vfx.add(new Fx.Flash(c.add(0, 0.5, 0), 3.0f, HELL, 12, 0.8f));
            ash(level, c, 10, 3.5, 0.03);
            ShazamFx.shakeAround(c, 0.9f, 30);
            if (self) {
                CameraShake.add(0.3f);
                ScreenFx.vignette(0.35f, 0x200000, 10);
            }
        });
    }

    /** Satu prajurit iblis bangkit dari api (atau runtuh jadi bara). */
    private static void rise(Vec3 at) {
        schedule(0, 1, (level, t) -> {
            Ground.Map map = scar(level, at, 1.6, 4, 1.0f, 30);
            Vec3 g = map == null ? at : map.center(at);
            Vfx.add(new Fx.Flash(g.add(0, 0.6, 0), 1.5f, HELL, 8, 0.85f));
            fire(g, 2.2, 0.6, 4, 20, 1f);
            embers(level, g, 10, 0.5, 0.08);
            ash(level, g, 6, 0.5, 0.05);
        });
    }

    // ------------------------------------------------------------------ Perjanjian Enam Iblis

    /** Mahkota Sabbac diangkat: enam lidah api (enam iblis) menjawab satu per satu di enam penjuru, lalu petir neraka. */
    private static void pact(AbstractClientPlayer caster, boolean self) {
        schedule(4, 1, (level, t) -> {
            Vec3 c = caster.position();
            Ground.Map map = ShazamFx.ground(level, c, 3.6);
            double gy = map == null ? c.y + 0.03 : map.centerY + 0.03;
            Vfx.add(new Runes.Circle(Lightning.Anchor.fixed(new Vec3(c.x, gy, c.z)), UP, 3.2, BLOOD, ShazamAnim.PACT_TICKS,
                    0.02f, 0.9f, map));
            sound(level, c, ShazamSounds.DREAD.get(), 1.0f, ShazamSounds.tune(0.6f));
        });
        // mahkota berpendar merah di antara kedua tangan
        schedule(10, 1, (level, t) -> Vfx.add(new Fx.Glow(caster, pt -> ShazamPoses.handPos(caster, true, pt)
                .add(ShazamPoses.handPos(caster, false, pt)).scale(0.5), 0.9f, HELL, ShazamAnim.PACT_STRIKE - 8,
                ShazamAnim.PACT_STRIKE - 10)));
        for (int k = 0; k < 6; k++) {
            int demon = k;
            schedule(8 + k * 8, 1, (level, t) -> {
                double a = Math.PI * 2.0 * demon / 6.0 + caster.getYRot() * Mth.DEG_TO_RAD;
                Vec3 at = caster.position().add(Math.cos(a) * 3.0, 0.02, Math.sin(a) * 3.0);
                fire(at, 2.4, 0.6, 4, ShazamAnim.PACT_STRIKE - 8 - demon * 8 + 10, 1f);
                Vfx.add(new Fx.Flash(at.add(0, 1.0, 0), 1.6f, HELL, 9, 0.8f));
                scar(level, at, 1.5, 3, 0.8f, 40);
                sound(level, at, ShazamSounds.FIRE_BLAST.get(), 0.8f, ShazamSounds.tune(0.5f + demon * 0.06f));
                if (self) {
                    CameraShake.add(0.06f);
                }
            });
        }
        schedule(ShazamAnim.PACT_STRIKE, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vfx.add(new Fx.Flash(chest(caster), 4.0f, HELL_HOT, 14, 1f));
            Vfx.add(new Fx.Bubble(c.add(0, 1.0, 0), 4.0, HELL, 14, 0.9f, 1.0, 1.8, true));
            fireRing(c, 3.0, 12, 1.6, 0.5, 30, 1f);
            ShazamFx.shakeAround(c, 1.2f, 36);
            if (self) {
                ScreenFlash.flash(0.9f, 0xFFA890);
                ScreenFx.titleKey("title.shazammod.sabbac_pact", 0xFF3A20, 70, 0);
            }
        });
    }

    // ------------------------------------------------------------------ Rival Juara

    /** Rival datang: gelombang kejut besar di titik datang (petirnya dibuat server, warnanya ikut juaranya). */
    private static void rivalArrive(AbstractClientPlayer puppet, Vec3 at) {
        ShazamForm form = ShazamClientState.form(puppet.getId());
        int glow = switch (form) {
            case BLACK_ADAM -> AdamFx.AMBER;
            case SABBAC -> HELL;
            default -> ShazamFx.GOLD;
        };
        schedule(0, 1, (level, t) -> {
            Ground.Map map = ShazamFx.ground(level, at, 4.5);
            Vec3 g = map == null ? at : map.center(at);
            Vfx.add(new Fx.Flash(g.add(0, 1.2, 0), 4.0f, glow, 14, 1f));
            if (map != null) {
                Vfx.add(new Fx.Wave(g, UP, 8.0, 0.5, glow, 18, 0.95f, 0.1f, map));
                Vfx.add(new Fx.Wave(g, UP, 6.5, 1.6, map.dustColor(level, at), 30, 0.6f, 0f, map, true));
                ShazamFx.dustPuffs(level, g, map.dustColor(level, at), 22, 2.0, 0.22);
            }
            if (form == ShazamForm.SABBAC) {
                scar(level, at, 4.0, 10, 3.0f, 80);
                fireRing(g, 2.2, 10, 1.8, 0.6, 30, 1f);
                ash(level, g, 14, 2.5, 0.04);
            }
            ShazamFx.shakeAround(g, 1.2f, 48);
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null && mc.player.distanceToSqr(at) < 48.0 * 48.0) {
                ScreenFx.vignette(0.45f, form == ShazamForm.SABBAC ? 0x2A0000 : 0x1A1206, 20);
                CameraShake.add(0.3f);
            }
        });
    }

    /** Rival pergi: pilar cahaya (atau api neraka yang menyelam ke tanah), lalu asap. */
    private static void rivalDepart(AbstractClientPlayer puppet, Vec3 at) {
        ShazamForm form = ShazamClientState.form(puppet.getId());
        int glow = switch (form) {
            case BLACK_ADAM -> AdamFx.AMBER_LIGHT;
            case SABBAC -> HELL_LIGHT;
            default -> ShazamFx.GOLD_LIGHT;
        };
        schedule(0, 1, (level, t) -> {
            Vfx.add(new Fx.Flash(at.add(0, 1.2, 0), 3.2f, glow, 12, 1f));
            Vfx.add(new Fx.Pillar(at, form == ShazamForm.SABBAC ? 8.0 : 40.0, 1.6f, glow, 16));
            if (form == ShazamForm.SABBAC) {
                scar(level, at, 2.5, 6, 1.6f, 50);
                fire(at, 2.6, 0.8, 6, 20, 1f);
                ash(level, at, 10, 1.2, 0.05);
            } else {
                ShazamFx.ringOfSparks(level, at.add(0, 1.0, 0), 30, glow, 0.4);
                ShazamFx.smokeCloud(level, at, 0x6A6460, 6, 1.0);
            }
            ShazamFx.shakeAround(at, 0.6f, 30);
        });
    }

    // ================================================================== efek

    /** Lidah-lidah api yang menjilat naik dari satu titik (boleh ikut bergerak), berkedip dan berayun. */
    static final class Fire extends Effect {
        private final Lightning.Anchor base;
        private final double height, width;
        private final int tongues;
        private final float strength;
        private final long seed;

        Fire(Lightning.Anchor base, double height, double width, int tongues, int life, float strength) {
            super(life);
            this.base = base;
            this.height = height;
            this.width = width;
            this.tongues = Math.max(1, tongues);
            this.strength = strength;
            this.seed = Vfx.random().nextLong();
        }

        @Override
        public boolean tick(ClientLevel level) {
            // 0.34 HD: lidah api butiran yang menari di dalam api ini (lebih bervolume)
            if (boost > 1.001f && age % 2 == 0 && progress(0f) < 0.75f) {
                Vec3 b = base.at(1f);
                if (b != null) {
                    float old = Vfx.setBoost(boost);
                    try {
                        RandomSource r = level.random;
                        double a = r.nextDouble() * Math.PI * 2.0, rr = width * 0.4 * Math.sqrt(r.nextDouble());
                        Vfx.flame(b.x + Math.cos(a) * rr, b.y + r.nextDouble() * height * 0.25, b.z + Math.sin(a) * rr, 0,
                                0.04 + height * 0.012, 0, HELL, (float) (width * 0.32 + 0.05) * strength, 9 + r.nextInt(5));
                    } finally {
                        Vfx.setBoost(old);
                    }
                }
            }
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float u = progress(pt);
            float k = strength * Math.min(1f, u / 0.12f) * Math.min(1f, (1f - u) / 0.45f);
            if (k <= 0.01f) {
                return;
            }
            Vec3 b = base.at(pt);
            if (b == null) {
                return;   // yang ditempeli api sudah nggak ada
            }
            float t = time(pt);
            Random r = new Random(seed);
            int n = 6;
            float[] pts = new float[n * 3];
            float[] w = new float[n];
            float[] a = new float[n];
            // lidah api tumbuh cepat lalu menyusut pelan
            double grow = Math.min(1.0, u / 0.2) * (0.7 + 0.3 * Math.min(1.0, (1.0 - u) / 0.5));
            for (int i = 0; i < tongues; i++) {
                double ang = r.nextDouble() * Math.PI * 2.0, off = r.nextDouble() * width * 0.45;
                double bx = b.x + Math.cos(ang) * off, bz = b.z + Math.sin(ang) * off;
                double phase = r.nextDouble() * 10.0;
                double h = height * grow * (0.55 + r.nextDouble() * 0.45) * (0.82 + 0.18 * Math.sin(t * 0.9 + phase));
                double lean = (r.nextDouble() - 0.5) * width * 0.4;
                for (int j = 0; j < n; j++) {
                    double v = j / (double) (n - 1);
                    double sway = Math.sin(t * 0.55 + phase + v * 3.0) * width * 0.22 * v;
                    double sway2 = Math.cos(t * 0.47 + phase * 1.3 + v * 2.4) * width * 0.22 * v;
                    pts[j * 3] = (float) (bx + sway + lean * v);
                    pts[j * 3 + 1] = (float) (b.y + h * v);
                    pts[j * 3 + 2] = (float) (bz + sway2);
                    w[j] = (float) (width * 0.6 * (1.0 - v * 0.85) * (0.75 + 0.25 * Math.sin(t * 1.3 + phase + j)));
                    a[j] = k * (float) (1.0 - v * 0.75);
                }
                d.polyline(pts, n, w, a, i % 2 == 0 ? HELL : HELL_LIGHT, HELL_HOT);
            }
            d.glow(b.x, b.y + height * 0.25, b.z, (float) (width * 1.2 + height * 0.35), HELL, 0.3f * k);
        }
    }

    /**
     * Rantai neraka membara dari a ke b (melengkung ke bawah sedikit), tumbuh dari a selama grow tick. Mata rantainya
     * lonjong, bergantian menghadap dua arah seperti rantai sungguhan, dan berdenyut panas.
     */
    static final class Chain extends Effect {
        private static final double LINK = 0.26;
        private final Lightning.Anchor from, to;
        private final double sag;
        private final int grow;

        Chain(Lightning.Anchor from, Lightning.Anchor to, double sag, int grow, int life) {
            super(life);
            this.from = from;
            this.to = to;
            this.sag = sag;
            this.grow = grow;
        }

        @Override
        public boolean tick(ClientLevel level) {
            // 0.34 HD: tetesan logam cair & bara jatuh dari rantai
            if (boost > 1.001f && age > 2 && age % 3 == 0 && life - age > 6) {
                Vec3 a = from.at(1f), b = to.at(1f);
                if (a != null && b != null) {
                    float old = Vfx.setBoost(boost);
                    try {
                        double u = level.random.nextDouble() * (grow <= 0 ? 1.0 : Math.min(1.0, age / (double) grow));
                        double x = a.x + (b.x - a.x) * u, y = a.y + (b.y - a.y) * u - sag * 4.0 * u * (1.0 - u), z = a.z + (b.z - a.z) * u;
                        Vfx.spark(x, y, z, 0, -0.03, 0, HELL_LIGHT, 0.045f, 14, y - 3.0);
                        if (level.random.nextInt(3) == 0) {
                            Vfx.flame(x, y, z, 0, 0.02, 0, HELL, 0.07f, 7);
                        }
                    } finally {
                        Vfx.setBoost(old);
                    }
                }
            }
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float t = time(pt);
            float fade = Math.min(1f, (life - t) / 6f);
            if (fade <= 0.01f) {
                return;
            }
            float reach = grow <= 0 ? 1f : Math.min(1f, t / grow);
            Vec3 a = from.at(pt), b = to.at(pt);
            double dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z;
            double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (len < 0.05) {
                return;
            }
            int links = Math.max(2, (int) (len * reach / LINK));
            double px = a.x, py = a.y, pz = a.z;
            for (int k = 0; k <= links; k++) {
                double u = reach * k / (double) links;
                double x = a.x + dx * u, y = a.y + dy * u - sag * 4.0 * u * (1.0 - u), z = a.z + dz * u;
                double tx = dx, ty = dy - sag * 4.0 * (1.0 - 2.0 * u), tz = dz;
                double tl = Math.sqrt(tx * tx + ty * ty + tz * tz);
                tx /= tl; ty /= tl; tz /= tl;
                // dua arah tegak lurus rantai
                double sx = -tz, sy = 0, sz = tx;   // t x (0, 1, 0)
                double sl = Math.sqrt(sx * sx + sy * sy + sz * sz);
                if (sl < 1.0E-4) {
                    sx = 1; sy = 0; sz = 0;
                    sl = 1;
                }
                sx /= sl; sy /= sl; sz /= sl;
                double qx = ty * sz - tz * sy, qy = tz * sx - tx * sz, qz = tx * sy - ty * sx;
                double nx = k % 2 == 0 ? sx : qx, ny = k % 2 == 0 ? sy : qy, nz = k % 2 == 0 ? sz : qz;
                float heat = 0.7f + 0.3f * Mth.sin(t * 0.8f + k * 0.9f);
                // mata rantai lonjong: 6 garis di bidang (t, n)
                double hl = LINK * 0.55, hw = LINK * 0.26;
                double lx = 0, ly = 0, lz = 0;
                for (int s = 0; s <= 6; s++) {
                    double ang = Math.PI * 2.0 * s / 6.0;
                    double ex = x + tx * Math.cos(ang) * hl + nx * Math.sin(ang) * hw;
                    double ey = y + ty * Math.cos(ang) * hl + ny * Math.sin(ang) * hw;
                    double ez = z + tz * Math.cos(ang) * hl + nz * Math.sin(ang) * hw;
                    if (s > 0) {
                        d.line(lx, ly, lz, ex, ey, ez, 0.05f, 0.05f, CHAIN, 0.85f * fade * heat, 0.85f * fade * heat);
                        if (boost > 1.001f) {   // 0.34 HD: inti logam yang membara putih-kuning
                            d.line(lx, ly, lz, ex, ey, ez, 0.018f, 0.018f, HELL_HOT, 0.7f * fade * heat, 0.7f * fade * heat);
                        }
                    }
                    lx = ex; ly = ey; lz = ez;
                }
                if (boost > 1.001f && k % 2 == 0) {
                    d.glow(x, y, z, 0.17f, HELL, 0.28f * fade * heat);
                }
                if (k > 0) {
                    d.line(px, py, pz, x, y, z, 0.09f, 0.09f, HELL, 0.18f * fade, 0.18f * fade);
                }
                px = x; py = y; pz = z;
            }
            d.glow(px, py, pz, 0.3f, HELL_LIGHT, 0.6f * fade);
        }
    }

    /**
     * Sayap api di punggung: empat tulang jari tiap sisi, selaput api bergradasi dari kuning panas di pangkal ke merah
     * darah di ujung, ujungnya berkedip seperti lidah api. open = seberapa terbentang (0 = terlipat & hilang), flap() =
     * satu kepakan ke bawah.
     */
    static final class Wings extends Effect {
        private static final int FINGERS = 4;
        private static final double[] LEN = {1.55, 1.85, 1.6, 1.2};
        private static final float FLAP_TICKS = 9f;
        private final AbstractClientPlayer owner;
        private float open, openO, target, span = 1f, spanTarget = 1f;
        private float flapAge = -100f;
        boolean done;

        Wings(AbstractClientPlayer owner) {
            super(20 * 60 * 60);
            this.owner = owner;
        }

        void want(float openTarget, float spanValue) {
            target = openTarget;
            spanTarget = spanValue;
        }

        void flap() {
            flapAge = age;
        }

        @Override
        public boolean tick(ClientLevel level) {
            age++;
            openO = open;
            open += (target - open) * (target > open ? 0.25f : 0.1f);
            if (Math.abs(target - open) < 0.01f) {
                open = target;
            }
            span += (spanTarget - span) * 0.15f;
            if (!owner.isAlive() || owner.isRemoved() || (target <= 0f && open <= 0.02f)) {
                done = true;
                return false;
            }
            // bara berjatuhan dari tepi sayap
            if (open > 0.3f && age % 2 == 0 && !firstPerson(owner)) {
                Vec3 tip = tip(1f, level.random.nextBoolean() ? 1 : -1, level.random.nextInt(FINGERS), open);
                Vfx.ember(tip.x, tip.y, tip.z, 0, 0.02, 0, 0.06f, 12 + level.random.nextInt(8));
            }
            // 0.34 HD: lidah api menjilat di sepanjang tepi sayap (lebih banyak saat mengepak)
            if (boost > 1.001f && open > 0.3f && !firstPerson(owner)) {
                float old = Vfx.setBoost(boost);
                try {
                    int n = flapAmount(0f) > 0.1f ? 3 : 1;
                    for (int i = 0; i < n; i++) {
                        int s = level.random.nextBoolean() ? 1 : -1, f = level.random.nextInt(FINGERS);
                        double[] root = new double[3], tp = new double[3];
                        bone(1f, s, f, open, root, tp);
                        double u = 0.45 + level.random.nextDouble() * 0.55;
                        Vec3 q = new Vec3(root[0] + (tp[0] - root[0]) * u, root[1] + (tp[1] - root[1]) * u, root[2] + (tp[2] - root[2]) * u);
                        Vfx.flame(q.x, q.y, q.z, 0, 0.025, 0, HELL, 0.1f * open, 8 + level.random.nextInt(4));
                    }
                } finally {
                    Vfx.setBoost(old);
                }
            }
            return age < life;
        }

        private float flapAmount(float pt) {
            float u = (age - flapAge + pt) / FLAP_TICKS;
            return u >= 0f && u < 1f ? Mth.sin(u * Mth.PI) : 0f;
        }

        /** Ujung tulang jari ke-i sisi s (dunia). */
        private Vec3 tip(float pt, int s, int i, float o) {
            double[] root = new double[3], tip = new double[3];
            bone(pt, s, i, o, root, tip);
            return new Vec3(tip[0], tip[1], tip[2]);
        }

        private void bone(float pt, int s, int i, float o, double[] root, double[] tip) {
            Vec3 p = owner.getPosition(pt);
            double sc = owner.getScale();
            float yaw = Mth.rotLerp(pt, owner.yBodyRotO, owner.yBodyRot) * Mth.DEG_TO_RAD;
            double fx = -Math.sin(yaw), fz = Math.cos(yaw);    // depan
            double rx = -Math.cos(yaw), rz = -Math.sin(yaw);   // kanan
            root[0] = p.x - fx * 0.2 * sc + rx * s * 0.14 * sc;
            root[1] = p.y + 1.34 * sc;
            root[2] = p.z - fz * 0.2 * sc + rz * s * 0.14 * sc;
            double v = i / (double) (FINGERS - 1);   // 0 = jari teratas, 1 = terbawah
            double t = time(pt);
            double openAng = lerp(o, -78.0 + v * -6.0, 64.0 - v * 92.0);
            double ang = Math.toRadians(openAng - flapAmount(pt) * 58.0 + Math.sin(t * 0.17 + v) * 5.0);
            double back = 0.3 + 0.45 * (1.0 - o);
            double dx = rx * s * Math.cos(ang) - fx * back, dy = Math.sin(ang), dz = rz * s * Math.cos(ang) - fz * back;
            double dl = Math.sqrt(dx * dx + dy * dy + dz * dz);
            double len = sc * span * LEN[i] * (0.35 + 0.65 * o) * (1.0 + 0.05 * Math.sin(t * 1.7 + i * 2.0 + s));
            tip[0] = root[0] + dx / dl * len;
            tip[1] = root[1] + dy / dl * len;
            tip[2] = root[2] + dz / dl * len;
        }

        private static double lerp(double t, double a, double b) {
            return a + (b - a) * t;
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float o = Mth.lerp(pt, openO, open);
            if (o <= 0.02f || owner.isInvisible()) {
                return;
            }
            float vis = Math.min(1f, o * 1.4f) * (firstPerson(owner) ? 0.25f : 1f);
            double[][] roots = new double[FINGERS][3], tips = new double[FINGERS][3];
            float t = time(pt);
            for (int s = -1; s <= 1; s += 2) {
                for (int i = 0; i < FINGERS; i++) {
                    bone(pt, s, i, o, roots[i], tips[i]);
                }
                double[] r0 = roots[0];
                // selaput api di antara jari
                for (int i = 0; i < FINGERS - 1; i++) {
                    double[] a = tips[i], b = tips[i + 1];
                    float flick = 0.8f + 0.2f * Mth.sin(t * 1.1f + i * 1.9f + s);
                    d.quad2(r0[0], r0[1], r0[2], r0[0], r0[1], r0[2], b[0], b[1], b[2], a[0], a[1], a[2], HELL_HOT, BLOOD,
                            0.5f * vis, 0.5f * vis, 0.2f * vis * flick, 0.2f * vis * flick);
                    // tepi bawah selaput berlekuk: titik tengah agak ke dalam, menyala
                    double mx = (a[0] + b[0]) * 0.5 * 0.85 + r0[0] * 0.15, my = (a[1] + b[1]) * 0.5 * 0.85 + r0[1] * 0.15,
                            mz = (a[2] + b[2]) * 0.5 * 0.85 + r0[2] * 0.15;
                    d.line(a[0], a[1], a[2], mx, my, mz, 0.1f, 0.06f, HELL, 0.5f * vis * flick, 0.3f * vis);
                    d.line(mx, my, mz, b[0], b[1], b[2], 0.06f, 0.1f, HELL, 0.3f * vis, 0.5f * vis * flick);
                }
                // tulang jari menyala & ujung berkedip
                for (int i = 0; i < FINGERS; i++) {
                    double[] a = tips[i];
                    d.line(r0[0], r0[1], r0[2], a[0], a[1], a[2], 0.09f, 0.03f, HELL_LIGHT, 0.85f * vis, 0.6f * vis);
                    if (boost > 1.001f) {   // 0.34 HD: inti tulang yang membara putih-kuning
                        d.line(r0[0], r0[1], r0[2], a[0], a[1], a[2], 0.035f, 0.01f, HELL_HOT, 0.8f * vis, 0.35f * vis);
                    }
                    d.glow(a[0], a[1], a[2], 0.22f, HELL_LIGHT, 0.45f * vis * (0.7f + 0.3f * Mth.sin(t * 1.6f + i)));
                }
                d.glow(r0[0], r0[1], r0[2], 0.45f, HELL, 0.35f * vis);
            }
        }
    }
}
