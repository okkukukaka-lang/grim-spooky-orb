package com.shazammod.client.fx;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamFamily;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Kekuatan Keluarga (0.26, tombol J): momen klimaks film Shazam!, Billy membagi kekuatannya dan petir menyambar seluruh
 * keluarganya bersamaan. Tiga ketukan seperti VFX 0.24:
 *
 * 1. Ancang-ancang (ShazamAnim.FAMILY_WINDUP tick): kepalan kanan terangkat ke langit dan menghimpun cahaya emas, listrik
 *    merayap di badan, dan tautan petir emas menyambung dari dada Shazam ke tiap anggota keluarga, makin tebal.
 * 2. Sambaran: petir sihir dari server menyambar semuanya bersamaan (MagicBolt); di tiap anggota ada kilatan putih & emas,
 *    cincin cahaya naik dari kaki ke kepala, gelombang emas di tanah, percikan. Di kepalan Shazam kilatan besar, suar lensa,
 *    guncangan kamera.
 * 3. Selama kekuatan bertahan (ShazamFamily.DURATION_TICKS): tiap anggota berpendar emas dengan bara naik dan listrik kecil
 *    yang merayap di badannya, berhenti kalau dia mati.
 */
public final class FamilyFx {
    private FamilyFx() {}

    private static final int GOLD = 0xFFC24A;
    private static final int GOLD_LIGHT = 0xFFE7A8;
    private static final Vec3 UP = new Vec3(0, 1, 0);

    /** Anggota keluarga di sekitar Shazam, terdekat dulu (aturannya sama dengan server: ShazamFamily.isFamily). */
    static List<LivingEntity> family(ClientLevel level, AbstractClientPlayer caster) {
        double r = ShazamFamily.RADIUS;
        List<LivingEntity> list = new ArrayList<>(level.getEntitiesOfClass(LivingEntity.class, caster.getBoundingBox().inflate(r),
                e -> ShazamFamily.isFamily(e, caster) && e.distanceToSqr(caster) <= r * r));
        list.sort(Comparator.comparingDouble(e -> e.distanceToSqr(caster)));
        return list.size() > ShazamFamily.MAX_FAMILY ? new ArrayList<>(list.subList(0, ShazamFamily.MAX_FAMILY)) : list;
    }

    /** Animasi FAMILY_CALL. */
    public static void call(AbstractClientPlayer caster, boolean self) {
        Minecraft mc = Minecraft.getInstance();
        boolean first = self && mc.options.getCameraType().isFirstPerson();
        int windup = ShazamAnim.FAMILY_WINDUP;
        List<LivingEntity> fam = family(caster.clientLevel, caster);
        Lightning.Anchor fist = pt -> ShazamPoses.handPos(caster, true, pt);
        Lightning.Anchor chest = Lightning.Anchor.on(caster, 0, 1.3 * caster.getScale(), 0);
        // 1) ancang-ancang: cahaya emas terhimpun di kepalan, listrik merayap, tautan petir ke tiap anggota keluarga
        CineFx.gather(caster, 0, windup, fist, GOLD_LIGHT, 1.6, 4f, true);
        Lightning.Crackle charge = new Lightning.Crackle(caster, GOLD_LIGHT, 1.2f, 0.05f, windup + 6).reach(0.9);
        charge.strength(first ? 0.25f : 0.9f);
        Vfx.add(charge);
        ShazamFx.schedule(0, windup, (level, t) -> {
            if (t % 2 != 0) {
                return;
            }
            for (LivingEntity member : fam) {
                if (member.isAlive()) {
                    Lightning.Anchor to = Lightning.Anchor.on(member, 0, member.getBbHeight() * 0.6, 0);
                    Vfx.add(new Lightning.Arc(chest, to, GOLD_LIGHT, 0.035f + 0.006f * t, 2, 1, 1, 0.22));
                }
            }
        });
        // 2) sambaran: bersamaan dengan petir sihir dari server
        ShazamFx.schedule(windup, 1, (level, t) -> {
            for (LivingEntity member : fam) {
                if (member.isAlive()) {
                    empower(level, member);
                }
            }
            impact(caster, self, first);
        });
    }

    private static void empower(ClientLevel level, LivingEntity member) {
        double h = member.getBbHeight();
        double w = member.getBbWidth();
        Vec3 base = member.position();
        Vec3 c = base.add(0, h * 0.55, 0);
        Vfx.add(new Fx.Flash(c, (float) (0.8 + h), 0xFFFFFF, 7, 1f));
        Vfx.add(new Fx.Flash(c, (float) (1.4 + h * 1.2), GOLD, 12, 0.85f));
        Vfx.add(new Fx.Ripple(base.add(0, 0.05, 0), UP, h * 1.15, w * 0.9, w * 1.3, 0.12, GOLD_LIGHT, 12, 0.9f, false));
        Ground.Map map = ShazamFx.ground(level, base, 2.5);
        if (map != null && map.found && base.y - map.centerY < 1.5) {
            Vfx.add(new Fx.Wave(map.center(base), UP, 2.4, 0.2, GOLD, 10, 0.85f, 0f, map));
        }
        ShazamFx.ringOfSparks(level, c, 16, GOLD_LIGHT, 0.3);
        // 3) pendar emas & listrik kecil merayap selama kekuatannya bertahan (berhenti kalau anggota itu mati)
        int life = ShazamFamily.DURATION_TICKS;
        Vfx.add(new Fx.Aura(member, GOLD, life, () -> member.isAlive() ? 0.55f : 0f));
        Lightning.Crackle crackle = new Lightning.Crackle(member, GOLD_LIGHT, 0.35f, 0.035f, life).reach(0.7);
        Vfx.add(crackle);
        ShazamFx.schedule(0, life, (lv, t) -> {
            if (t % 5 == 0 && !member.isAlive()) {
                crackle.stop();
            }
        });
    }

    private static void impact(AbstractClientPlayer caster, boolean self, boolean first) {
        if (!caster.isAlive()) {
            return;
        }
        Vec3 fist = ShazamPoses.handPos(caster, true, 1f);
        Vfx.add(new Fx.Flash(fist, first ? 0.8f : 2.4f, 0xFFFFFF, 8, 1f));
        Vfx.add(new Fx.Flash(fist, first ? 1.2f : 3.4f, GOLD, 14, 0.85f));
        CineFx.flare(fist, 0xFFF4D8, first ? 3f : 8f, 0.12f, first ? 0.4f : 1f, 12);
        Lightning.Crackle crackle = new Lightning.Crackle(caster, GOLD_LIGHT, 2.2f, 0.07f, 26).reach(1.0);
        crackle.strength(first ? 0.2f : 1f);
        Vfx.add(crackle);
        ShazamFx.shakeAround(caster.position(), 0.45f, 32);
        if (self) {
            ScreenFlash.flash(first ? 0.15f : 0.3f, 0xFFF6DC);
            FovKick.punch(-0.05f);
        }
    }
}
