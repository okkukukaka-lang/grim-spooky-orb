package com.shazammod.client.render;

import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.resources.PlayerSkin;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

/** Mendaftarkan layer kulit HD Lintang ke renderer pemain. */
@EventBusSubscriber(modid = "shazammod", bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class LintangLayers {
    private LintangLayers() {
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    @SubscribeEvent
    public static void addLayers(EntityRenderersEvent.AddLayers event) {
        for (Object o : event.getSkins()) {
            EntityRenderer r = event.getSkin((PlayerSkin.Model) o);
            if (r instanceof PlayerRenderer pr) {
                pr.addLayer(new CryonSkinLayer((RenderLayerParent) pr));
            }
        }
    }
}
