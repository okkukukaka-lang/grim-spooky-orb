package com.shazammod.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.PassiveConditions;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamMod;
import com.shazammod.client.anim.Ease;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.fx.SabbacFx;

import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * 0.30 Wujud iblis Sabbac di model pemain (skin pemain sendiri nggak diganti):
 * - Tanduk iblis melengkung ke luar lalu ke atas, pangkal hitam hangus, ujung membara. Membesar & menyala saat Tanduk
 *   Setan (SabbacFx.hornCharge). Muncul tumbuh saat berubah, mengerut hilang saat balik jadi manusia.
 * - Urat bara: pola retakan api yang mengalir pelan di seluruh badan (tekstur textures/entity/fx/embers.png), lebih
 *   terang di kegelapan, padam di bawah matahari / di dalam air.
 * - Tubuh Aym: badan terbungkus obsidian ungu-hitam dengan urat magma yang berdenyut (SabbacFx.aymStrength, tekstur
 *   textures/entity/fx/magma.png).
 *
 * Satuan tanduk: piksel model kepala (kepala 8x8x8, atas kepala y = -8, depan = -z).
 */
public class SabbacGearLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation VEINS = ShazamMod.id("textures/entity/fx/embers.png");
    private static final ResourceLocation MAGMA = ShazamMod.id("textures/entity/fx/magma.png");

    // ======= Tanduk =======
    /** Titik lengkung tanduk kiri (x dicerminkan untuk tanduk kanan), dari pangkal ke ujung. */
    private static final float[][] HORN = {
            {3.0f, -7.2f, -1.2f}, {4.6f, -8.5f, -0.8f}, {5.6f, -10.5f, -1.0f}, {5.9f, -12.5f, -2.0f}, {5.1f, -14.2f, -3.7f}};
    /** Setengah tebal tanduk di tiap titik. */
    private static final float[] HORN_R = {1.15f, 0.95f, 0.75f, 0.55f, 0.3f};
    private static final int SUBDIV = 3;
    private static final int[] HORN_BASE = {46, 32, 28};
    private static final int[] HORN_MID = {86, 58, 46};
    private static final int[] HORN_RIDGE = {30, 20, 18};
    private static final int[] HORN_TIP = {255, 104, 44};
    private static final int APPEAR = 4;
    // ======= Urat bara =======
    private static final float VEIN_BASE = 0.2f;     // terang biasa
    private static final float VEIN_DARK = 0.32f;    // di kegelapan neraka
    private static final float VEIN_RAGE = 0.55f;    // Gerbang Neraka

    public SabbacGearLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    /** Besar 0-1: tumbuh memantul saat berubah, mengerut hilang saat kembali jadi manusia. */
    private static float size(AbstractClientPlayer player, float partialTick) {
        float t = ShazamCape.revealTime(player, partialTick);
        if (t >= 0f) {
            float s = (t - APPEAR) / 7f;
            return s <= 0f ? 0f : s >= 1f ? 1f : Ease.OUT_BACK.apply(s);
        }
        if (!ShazamPoses.suitIn(player)) {
            float out = ShazamPoses.suitTicks(player, partialTick);
            if (out >= 0f) {
                return Math.max(0f, 1f - out / 5f);
            }
        }
        return 0f;
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, AbstractClientPlayer player,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (player.isInvisible() || !ShazamClientState.isSabbac(player.getId())) {
            return;
        }
        float k = size(player, partialTick);
        if (k <= 0.001f) {
            return;
        }
        PlayerModel<AbstractClientPlayer> model = this.getParentModel();

        // 1) urat bara di seluruh badan
        boolean lit = PassiveConditions.hellfireBlock(player.level(), player.blockPosition(), player.isUnderWater())
                == PassiveConditions.Hellfire.NONE;
        float vein = ShazamClientState.isRaging(player.getId()) ? VEIN_RAGE
                : PassiveConditions.darkness(player.level()) ? VEIN_DARK : VEIN_BASE;
        if (lit) {
            float scroll = ageInTicks * 0.004f;
            VertexConsumer swirl = buffer.getBuffer(RenderType.energySwirl(VEINS, scroll % 1f, (scroll * 2.2f) % 1f));
            float pulse = 0.8f + 0.2f * Mth.sin(ageInTicks * 0.21f);
            float a = Mth.clamp(vein * pulse * k, 0f, 1f);
            poseStack.pushPose();
            poseStack.translate(0f, 0.75f, 0f);
            poseStack.scale(1.02f, 1.01f, 1.02f);
            poseStack.translate(0f, -0.75f, 0f);
            model.renderToBuffer(poseStack, swirl, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY,
                    0xFF000000 | ((int) (255 * a) << 16) | ((int) (70 * a) << 8) | (int) (24 * a));
            poseStack.popPose();
        }

        // 2) Tubuh Aym: obsidian berurat magma
        float aym = SabbacFx.aymStrength(player, partialTick);
        if (aym > 0.01f) {
            poseStack.pushPose();
            poseStack.translate(0f, 0.75f, 0f);
            poseStack.scale(1.05f, 1.03f, 1.05f);
            poseStack.translate(0f, -0.75f, 0f);
            VertexConsumer stone = buffer.getBuffer(RenderType.entityTranslucent(CapeDecor.WHITE));
            int alpha = (int) (215 * aym);
            model.renderToBuffer(poseStack, stone, packedLight, OverlayTexture.NO_OVERLAY, (alpha << 24) | 0x261A2C);
            float scroll = ageInTicks * 0.008f;
            VertexConsumer lava = buffer.getBuffer(RenderType.energySwirl(MAGMA, scroll % 1f, (scroll * 0.4f) % 1f));
            float pulse = 0.7f + 0.3f * Mth.sin(ageInTicks * 0.3f);
            float g = Mth.clamp(aym * pulse, 0f, 1f);
            poseStack.translate(0f, 0.75f, 0f);
            poseStack.scale(1.015f, 1.01f, 1.015f);
            poseStack.translate(0f, -0.75f, 0f);
            model.renderToBuffer(poseStack, lava, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY,
                    0xFF000000 | ((int) (255 * g) << 16) | ((int) (90 * g) << 8) | (int) (30 * g));
            poseStack.popPose();
        }

        // 3) tanduk
        float charge = SabbacFx.hornCharge(player, partialTick);
        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(CapeDecor.WHITE));
        poseStack.pushPose();
        model.head.translateAndRotate(poseStack);
        poseStack.scale(1f / 16f, 1f / 16f, 1f / 16f);
        PoseStack.Pose pose = poseStack.last();
        for (int side = -1; side <= 1; side += 2) {
            horn(vc, pose, side, k * (1f + 0.45f * charge), charge, packedLight);
        }
        poseStack.popPose();
    }

    /** Satu tanduk: balok-balok kecil bertumpuk mengikuti lengkung, mengecil ke ujung, ujungnya membara. */
    private static void horn(VertexConsumer vc, PoseStack.Pose pose, int side, float k, float charge, int light) {
        float bx = HORN[0][0] * side, by = HORN[0][1], bz = HORN[0][2];
        int segments = HORN.length - 1;
        int steps = segments * SUBDIV;
        for (int i = 0; i <= steps; i++) {
            int seg = Math.min(segments - 1, i / SUBDIV);
            float f = i == steps ? 1f : (i % SUBDIV) / (float) SUBDIV;
            if (i == steps) {
                seg = segments - 1;
            }
            float[] a = HORN[seg], b = HORN[seg + 1];
            float x = Mth.lerp(f, a[0], b[0]) * side, y = Mth.lerp(f, a[1], b[1]), z = Mth.lerp(f, a[2], b[2]);
            float r = Mth.lerp(f, HORN_R[seg], HORN_R[seg + 1]);
            // tumbuh dari pangkal: titik ditarik ke pangkal sebesar k
            x = bx + (x - bx) * k;
            y = by + (y - by) * k;
            z = bz + (z - bz) * k;
            r *= Math.min(1f, 0.4f + 0.6f * k);
            float u = i / (float) steps;
            boolean tip = u > 0.72f;
            int[] c;
            if (tip) {
                float heat = 0.75f + 0.25f * charge;
                c = new int[] {(int) (HORN_TIP[0] * heat), (int) (HORN_TIP[1] * heat), (int) (HORN_TIP[2] * heat)};
            } else if (i % SUBDIV == 0 && i > 0) {
                c = HORN_RIDGE;   // gelang beralur
            } else {
                c = lerp(u / 0.72f, HORN_BASE, HORN_MID);
            }
            float pad = i % SUBDIV == 0 && i > 0 && !tip ? 0.12f : 0f;
            box(vc, pose, x - r - pad, y - r, z - r - pad, x + r + pad, y + r, z + r + pad, c,
                    tip ? LightTexture.FULL_BRIGHT : light);
        }
    }

    private static int[] lerp(float t, int[] a, int[] b) {
        t = Mth.clamp(t, 0f, 1f);
        return new int[] {(int) Mth.lerp(t, a[0], b[0]), (int) Mth.lerp(t, a[1], b[1]), (int) Mth.lerp(t, a[2], b[2])};
    }

    /** Balok berwarna (6 sisi, normal tiap sisi; cahaya dunia + bayangan dari normalnya). */
    private static void box(VertexConsumer vc, PoseStack.Pose pose, float x0, float y0, float z0, float x1, float y1, float z1,
                            int[] c, int light) {
        quad(vc, pose, c, light, 0f, 0f, -1f, x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0);
        quad(vc, pose, c, light, 0f, 0f, 1f, x1, y0, z1, x0, y0, z1, x0, y1, z1, x1, y1, z1);
        quad(vc, pose, c, light, -1f, 0f, 0f, x0, y0, z1, x0, y0, z0, x0, y1, z0, x0, y1, z1);
        quad(vc, pose, c, light, 1f, 0f, 0f, x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0);
        quad(vc, pose, c, light, 0f, -1f, 0f, x0, y0, z1, x1, y0, z1, x1, y0, z0, x0, y0, z0);
        quad(vc, pose, c, light, 0f, 1f, 0f, x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1);
    }

    private static void quad(VertexConsumer vc, PoseStack.Pose pose, int[] c, int light, float nx, float ny, float nz,
                             float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz) {
        vertex(vc, pose, c, light, nx, ny, nz, ax, ay, az);
        vertex(vc, pose, c, light, nx, ny, nz, bx, by, bz);
        vertex(vc, pose, c, light, nx, ny, nz, cx, cy, cz);
        vertex(vc, pose, c, light, nx, ny, nz, dx, dy, dz);
    }

    private static void vertex(VertexConsumer vc, PoseStack.Pose pose, int[] c, int light, float nx, float ny, float nz,
                               float x, float y, float z) {
        vc.addVertex(pose, x, y, z).setColor(c[0], c[1], c[2], 255).setUv(0.5f, 0.5f).setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(light).setNormal(pose, nx, ny, nz);
    }
}
