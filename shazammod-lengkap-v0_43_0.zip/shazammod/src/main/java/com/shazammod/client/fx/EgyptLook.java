package com.shazammod.client.fx;

import static com.shazammod.client.fx.GodLook.anchorDirWorld;
import static com.shazammod.client.fx.GodLook.anchorWorld;
import static com.shazammod.client.fx.GodLook.basis;
import static com.shazammod.client.fx.GodLook.lighten;

/**
 * Pernik cahaya dewa-dewa Mesir (murni Java, dipanggil dari GodLook.extras):
 * Shu menyangga lengkung langit berbintang (tubuh dewi Nut), Heru dengan tatapan elang & pusaka berkilau,
 * Amon dengan bulu mahkota menyala & aura biru pekat, Zehuti dengan cakram bulan & cincin hieroglif yang berputar,
 * Aton dengan korona matahari yang berputar pelan, Mehen dengan tudung berpendar & taring berbisa.
 */
final class EgyptLook {
    private EgyptLook() {}

    /** Bintang-bintang lengkung langit Shu: posisi sepanjang lengkung (0..1), geser samping, geser kedalaman. */
    private static final double[] SKY = sky(26, 9127L);

    private static double[] sky(int n, long seed) {
        java.util.Random r = new java.util.Random(seed);
        double[] out = new double[n * 3];
        for (int i = 0; i < n; i++) {
            out[i * 3] = (i + r.nextDouble() * 0.8) / n;
            out[i * 3 + 1] = (r.nextDouble() - 0.5) * 0.18;
            out[i * 3 + 2] = (r.nextDouble() - 0.5) * 0.22;
        }
        return out;
    }

    /** Coretan hieroglif (tiap huruf 2-3 garis pendek, koordinat -1..1) untuk cincin Zehuti. */
    static final double[][] GLYPHS = {
            {-0.6, -1, -0.6, 1, -0.6, 1, 0.6, 0.4},            // bendera / tongkat
            {-0.8, 0, 0.8, 0, 0, -1, 0, 1},                    // salib
            {-0.7, -1, 0.7, -1, 0.7, -1, 0, 1, 0, 1, -0.7, -1}, // segitiga (gunung)
            {-1, 0.3, 1, 0.3, -0.5, -1, -0.5, 0.3, 0.5, -1, 0.5, 0.3},   // meja persembahan
            {-0.8, -0.6, 0.8, -0.6, -0.8, 0.6, 0.8, 0.6},      // air (dua garis)
            {0, -1, 0, 0.4, -0.6, 0.4, 0.6, 0.4, 0, 0.4, 0, 1}, // ankh sederhana
            {-1, -1, 1, 1, -1, 1, 1, -1},                      // silang
            {-0.9, 1, 0.9, 1, 0, 1, 0, -1}};                   // T

    static void extras(int god, GodMesh m, GodShow.State s, double ox, double oy, double oz, double camX, double camY,
                       double camZ, float time, GodLook.Glows g, float vis, float boost) {
        int aura = GodFigures.AURA[god];
        int light = lighten(aura, 0.55);
        double sc = s.scale;
        double[] p = new double[3], q = new double[3], d = new double[3];
        switch (god) {
            case GodFigures.SHU -> {
                // lengkung langit berbintang di antara kedua telapak (tubuh dewi Nut yang disangga Shu)
                float sky = m.extraSize * vis;
                anchorWorld(m, s, ox, oy, oz, GodMesh.EXTRA, p);
                anchorWorld(m, s, ox, oy, oz, GodMesh.EXTRA2, q);
                if (sky > 0.02f) {
                    double mx = (p[0] + q[0]) * 0.5, my = (p[1] + q[1]) * 0.5 + 0.55 * sc, mz = (p[2] + q[2]) * 0.5;
                    int n = SKY.length / 3;
                    double px0 = p[0], py0 = p[1], pz0 = p[2];
                    for (int k = 0; k <= 16; k++) {   // pita Bima Sakti
                        double u = k / 16.0, v = 1 - u;
                        double x = v * v * p[0] + 2 * v * u * mx + u * u * q[0];
                        double y = v * v * p[1] + 2 * v * u * my + u * u * q[1] + 0.06 * sc;
                        double z = v * v * p[2] + 2 * v * u * mz + u * u * q[2];
                        if (k > 0) {
                            g.line(px0, py0, pz0, x, y, z, (float) (0.22 * sc), 0x9CC8FF, 0.18f * sky);
                            g.line(px0, py0, pz0, x, y, z, (float) (0.06 * sc), 0xE8F4FF, 0.3f * sky);
                        }
                        px0 = x; py0 = y; pz0 = z;
                    }
                    for (int i = 0; i < n; i++) {
                        double u = SKY[i * 3], v = 1 - u;
                        double x = v * v * p[0] + 2 * v * u * mx + u * u * q[0];
                        double y = v * v * p[1] + 2 * v * u * my + u * u * q[1] + 0.06 * sc + SKY[i * 3 + 1] * sc;
                        double z = v * v * p[2] + 2 * v * u * mz + u * u * q[2] + SKY[i * 3 + 2] * sc;
                        float tw = (float) (0.6 + 0.4 * Math.sin(time * 0.33 + i * 2.1));
                        g.glow(x, y, z, (float) (0.07 * sc), 0xF4FAFF, 0.9f * sky * tw);
                        g.glow(x, y, z, (float) (0.022 * sc), 0xFFFFFF, sky * tw);
                    }
                    g.glow(mx, my, mz, (float) (0.9 * sc), 0x9CC8FF, 0.12f * sky);
                }
                // angin berpilin di kaki
                double fx = ox + s.x, fy = oy + s.y, fz = oz + s.z;
                for (int k = 0; k < 3; k++) {
                    double base = time * 0.3 + k * Math.PI * 2 / 3;
                    double prevX = 0, prevY = 0, prevZ = 0;
                    for (int j = 0; j <= 8; j++) {
                        double u = j / 8.0;
                        double a = base + u * 2.6;
                        double rr = (0.45 - 0.12 * u) * sc;
                        double x = fx + Math.cos(a) * rr, y = fy + (0.08 + 0.5 * u) * sc, z = fz + Math.sin(a) * rr;
                        if (j > 0) {
                            g.line(prevX, prevY, prevZ, x, y, z, (float) (0.03 * sc), 0xEAF6FF,
                                    0.35f * vis * (float) Math.sin(Math.PI * u));
                        }
                        prevX = x; prevY = y; prevZ = z;
                    }
                }
            }
            case GodFigures.HERU -> {
                // tatapan elang: kilau mendatar dari kedua mata
                for (int e = GodMesh.EYE_L; e <= GodMesh.EYE_R; e++) {
                    anchorWorld(m, s, ox, oy, oz, e, p);
                    anchorDirWorld(m, s, e, d);
                    g.line(p[0], p[1], p[2], p[0] + d[0] * 0.12 * sc, p[1] + d[1] * 0.12 * sc, p[2] + d[2] * 0.12 * sc,
                            (float) (0.018 * sc), 0xFFF0C8, 0.7f * vis);
                }
                anchorWorld(m, s, ox, oy, oz, GodMesh.FOCUS, p);
                float flick = (float) (0.8 + 0.2 * Math.sin(time * 0.7));
                g.glow(p[0], p[1], p[2], (float) (0.24 * sc), aura, 0.45f * vis * flick * boost);
                g.glow(p[0], p[1], p[2], (float) (0.07 * sc), 0xFFFFFF, 0.8f * vis);
                anchorWorld(m, s, ox, oy, oz, GodMesh.EXTRA, q);
                g.glow(q[0], q[1], q[2], (float) (0.16 * sc), 0xFFE8A0, 0.4f * vis);
                // bulu-bulu cahaya yang gugur dari sayap
                anchorWorld(m, s, ox, oy, oz, GodMesh.CHEST, p);
                for (int k = 0; k < 4; k++) {
                    double u = (time * 0.012 + k * 0.25) % 1.0;
                    double side = (k % 2 == 0 ? 1 : -1) * (0.55 + 0.3 * k / 4.0) * m.extraSize;
                    anchorDirWorld(m, s, GodMesh.HEAD, d);
                    double rx = -d[2], rz = d[0];
                    g.glow(p[0] + rx * side * sc, p[1] + (0.4 - 1.3 * u) * sc, p[2] + rz * side * sc,
                            (float) (0.05 * sc), 0xFFE0A0, 0.6f * vis * (float) Math.sin(Math.PI * u));
                }
            }
            case GodFigures.AMON -> {
                // bulu mahkota menyala, ankh & tongkat berkilau, aura biru tua yang pekat
                anchorWorld(m, s, ox, oy, oz, GodMesh.EXTRA2, p);
                float pulse = (float) (0.75 + 0.25 * Math.sin(time * 0.2));
                g.glow(p[0], p[1], p[2], (float) (0.3 * sc), 0xC8D8FF, 0.35f * vis * pulse);
                g.line(p[0], p[1], p[2], p[0], p[1] + 0.35 * sc, p[2], (float) (0.05 * sc), 0xDDE6FF, 0.3f * vis * pulse);
                anchorWorld(m, s, ox, oy, oz, GodMesh.EXTRA, q);
                g.glow(q[0], q[1], q[2], (float) (0.18 * sc), 0xFFE7A0, 0.45f * vis);
                anchorWorld(m, s, ox, oy, oz, GodMesh.FOCUS, p);
                g.glow(p[0], p[1], p[2], (float) (0.22 * sc), aura, 0.4f * vis * boost);
                anchorWorld(m, s, ox, oy, oz, GodMesh.CHEST, p);
                g.glow(p[0], p[1], p[2], (float) (1.1 * sc), 0x2A44AA, 0.22f * vis);
            }
            case GodFigures.ZEHUTI -> {
                // cakram bulan menyala dengan cincin cahaya
                anchorWorld(m, s, ox, oy, oz, GodMesh.EXTRA, p);
                double tx = camX - p[0], ty = camY - p[1], tz = camZ - p[2];
                double tl = Math.sqrt(tx * tx + ty * ty + tz * tz) + 1.0E-9;
                g.glow(p[0], p[1], p[2], (float) (0.42 * sc), 0xD8FFF0, 0.45f * vis * boost);
                g.ring(p[0], p[1], p[2], tx / tl, ty / tl, tz / tl, 0.22 * sc, 0.02 * sc, 0xF0FFF8, 0.6f * vis);
                // cincin hieroglif yang berputar mengelilingi badan
                anchorWorld(m, s, ox, oy, oz, GodMesh.CHEST, q);
                double cy = q[1] - 0.15 * sc;
                double cx = ox + s.x, cz = oz + s.z;
                int count = 14;
                for (int i = 0; i < count; i++) {
                    double a = time * 0.035 + Math.PI * 2.0 * i / count;
                    double rr = 0.62 * sc;
                    double gx = cx + Math.cos(a) * rr, gz = cz + Math.sin(a) * rr;
                    double gy = cy + 0.05 * sc * Math.sin(time * 0.1 + i);
                    double ux = -Math.sin(a), uz = Math.cos(a);   // arah lebar huruf (searah lingkaran)
                    double[] gl = GLYPHS[i % GLYPHS.length];
                    double size = 0.06 * sc;
                    float fade = (float) (0.55 + 0.45 * Math.sin(time * 0.15 + i * 0.7));
                    for (int k = 0; k + 3 < gl.length; k += 4) {
                        g.line(gx + ux * gl[k] * size, gy + gl[k + 1] * size, gz + uz * gl[k] * size,
                                gx + ux * gl[k + 2] * size, gy + gl[k + 3] * size, gz + uz * gl[k + 2] * size,
                                (float) (0.016 * sc), light, 0.75f * vis * fade);
                    }
                }
                anchorWorld(m, s, ox, oy, oz, GodMesh.FOCUS, p);
                g.glow(p[0], p[1], p[2], (float) (0.12 * sc), 0xEAFFF6, 0.8f * vis);
                anchorWorld(m, s, ox, oy, oz, GodMesh.EXTRA2, q);
                g.glow(q[0], q[1], q[2], (float) (0.14 * sc), aura, 0.2f * vis);
            }
            case GodFigures.ATON -> {
                // cahaya matahari & korona berputar pelan
                anchorWorld(m, s, ox, oy, oz, GodMesh.EXTRA, p);
                anchorDirWorld(m, s, GodMesh.EXTRA, d);
                double R = EgyptFigures.ATON_R * sc;
                g.glow(p[0], p[1], p[2], (float) (R * 2.6), 0xFFB030, 0.16f * vis * boost);
                g.glow(p[0], p[1], p[2], (float) (R * 1.2), 0xFFE7A0, 0.22f * vis);
                double[] e1 = new double[3], e2 = new double[3];
                basis(d, e1, e2);
                int rays = 28;
                for (int i = 0; i < rays; i++) {
                    double a = time * 0.008 + Math.PI * 2.0 * i / rays;
                    double c0 = Math.cos(a), s0 = Math.sin(a);
                    double r0 = R * 1.06, r1 = R * (i % 2 == 0 ? 1.55 : 1.3) * (1.0 + 0.05 * Math.sin(time * 0.2 + i));
                    g.line(p[0] + (e1[0] * c0 + e2[0] * s0) * r0, p[1] + (e1[1] * c0 + e2[1] * s0) * r0,
                            p[2] + (e1[2] * c0 + e2[2] * s0) * r0, p[0] + (e1[0] * c0 + e2[0] * s0) * r1,
                            p[1] + (e1[1] * c0 + e2[1] * s0) * r1, p[2] + (e1[2] * c0 + e2[2] * s0) * r1,
                            (float) (0.05 * sc), 0xFFE7A0, 0.32f * vis);
                }
                anchorWorld(m, s, ox, oy, oz, GodMesh.FOCUS, q);
                g.glow(q[0], q[1], q[2], (float) (0.2 * sc), 0xFFFFFF, 0.6f * vis * m.extraSize);
            }
            case GodFigures.MEHEN -> {
                // tudung berpendar, taring berbisa berkilau, sisik berkilat di gulungan
                anchorWorld(m, s, ox, oy, oz, GodMesh.EXTRA, p);
                float flare = m.extraSize;
                g.glow(p[0], p[1], p[2], (float) (0.5 * sc), aura, (0.2f + 0.25f * flare) * vis * boost);
                anchorWorld(m, s, ox, oy, oz, GodMesh.FOCUS, q);
                float drip = (float) (0.5 + 0.5 * Math.sin(time * 0.5));
                g.glow(q[0], q[1], q[2], (float) (0.1 * sc), 0xFFF0A0, 0.6f * vis * drip);
                for (int k = GodMesh.HAND_L; k <= GodMesh.HAND_R; k++) {
                    anchorWorld(m, s, ox, oy, oz, k, p);
                    float tw = (float) (0.5 + 0.5 * Math.sin(time * 0.4 + k * 1.7));
                    g.glow(p[0], p[1] + 0.08 * sc, p[2], (float) (0.12 * sc), 0xFFD080, 0.5f * vis * tw);
                }
                anchorWorld(m, s, ox, oy, oz, GodMesh.EXTRA2, p);
                g.glow(p[0], p[1] + 0.1 * sc, p[2], (float) (0.3 * sc), aura, 0.25f * vis);
            }
            default -> { }
        }
    }
}
