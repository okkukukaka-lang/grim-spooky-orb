package com.shazammod.client.render;

/**
 * Satu pakaian utuh beserta fisikanya (murni Java, gampang diuji): jubah panjang, mantel bahu, dan hood.
 *
 * Tiap potong kain dihitung di ruang tempat ia dipasang: jubah dan mantel di ruang leher (badan atas), hood di
 * ruang kepala saat dipakai (atau ruang leher saat diturunkan). Gerak ruang itu di dunia (jalan, lompat,
 * terbang, berbelok, menoleh) masuk sebagai gaya semu yang benar secara fisika, jadi kain tetap punya
 * kelembaman, tapi nggak pernah tertinggal jauh, molor, atau meledak walau gerak Minecraft patah-patah.
 *
 * Satuan dunia nyata: 1 blok = 1 meter, gravitasi 9,81 m/s², udara 1,225 kg/m³, kain wol 0,45-0,7 kg/m².
 * Urutan tiap langkah kecil: jubah, mantel (selalu di luar bagian atas jubah), lalu hood (saat diturunkan,
 * tergeletak di atas mantel).
 */
public final class Cloak {
    // ======= Waktu =======
    public static final double TICK = 0.05;             // detik per tick game (slow motion ikut melambat)
    public static final int SUBSTEPS = 8;               // 160 langkah per detik
    public static final double H = TICK / SUBSTEPS;
    private static final int ITERATIONS = 2;

    // ======= Fisika dunia nyata =======
    public static final double GRAVITY = 9.81;          // m/s²
    private static final double NORMAL_DRAG = 1.3;      // koefisien gaya udara tegak lurus kain (pelat datar)
    private static final double SKIN_DRAG = 0.03;       // gesekan udara searah permukaan kain
    private static final double DAMPING = 0.3;          // redaman di dalam serat kain (per detik)
    private static final double WATER_BUOYANCY = 0.85;  // di air, berat kain tinggal 15%

    // ======= Batas gaya semu (gerak Minecraft kadang patah-patah: teleport, berbalik seketika) =======
    private static final double MAX_ACCEL = 70.0;       // m/s² (±7 g)
    private static final double MAX_SPIN = 9.0;         // rad/s
    private static final double MAX_SPIN_ACCEL = 160.0; // rad/s²
    private static final double INERTIA_SMOOTH = 0.05;  // detik (lonjakan kecepatan antar-tick disebar)
    private static final double TELEPORT = 1.5;         // pindah lebih dari ini dalam satu langkah (240 m/s) = teleport
    private static final double MAX_AIR_SPEED = 120.0;  // m/s; Shazam paling kencang 100 m/s, lebih dari itu = lompatan posisi

    // ======= Tabrakan =======
    private static final double BODY_THICK = 0.016;     // tebal kain + celah dari kulit (blok)
    private static final double BODY_FRICTION = 0.35;
    private static final double WORLD_THICK = 0.02;
    private static final double WORLD_FRICTION = 0.6;
    private static final double LAYER_CLEAR = MantleShape.CAPE_CLEAR;
    private static final double HOOD_ON_MANTLE = 0.022;
    /** Isi mantel di bahu dan punggung atas, di ruang leher: {-, pusat y, pusat z, setengah x, y, z}. */
    private static final double[] MANTLE_BOX = {0.0, -0.2, 0.06, 0.36, 0.2, 0.24};

    /** Keadaan tubuh di satu langkah kecil (diisi ShazamCape dari pemain, atau oleh pengujian). */
    public static final class Input {
        /** Ruang badan -> dunia (termasuk ukuran badan), di waktu langkah ini. */
        public final Xform body = new Xform();
        /** Pose model (lihat BodyRig). */
        public final float[] parts = BodyRig.DEFAULT.clone();
        public boolean slim;
        /** Angin sekitar (dunia, m/s). */
        public final double[] wind = new double[3];
        public boolean water;
        /** Blok dunia di sekitar: {minX, minY, minZ, maxX, maxY, maxZ} berurutan. */
        public double[] boxes = new double[0];
        public int boxCount;
        /** Waktu (detik). */
        public double time;
        /** Hood: 0 = dipakai, 1 = diturunkan (sudah diperhalus). */
        public double hoodDown;
    }

    /** Gerak ruang tempat kain dipasang. */
    private static final class Kin {
        final Xform prev = new Xform();
        boolean has;
        double vx, vy, vz;            // dunia, m/s
        double ax, ay, az;            // dunia, m/s² (diperhalus)
        final double[] w = new double[3];   // lokal, rad/s
        double alx, aly, alz;         // lokal, rad/s² (diperhalus)
        private final double[] nw = new double[3];

        void reset(Xform now) {
            prev.set(now);
            has = true;
            vx = vy = vz = 0;
            ax = ay = az = 0;
            w[0] = w[1] = w[2] = 0;
            alx = aly = alz = 0;
        }

        void update(Xform now, double h) {
            if (!has) {
                reset(now);
                return;
            }
            double dx = now.tx - prev.tx, dy = now.ty - prev.ty, dz = now.tz - prev.tz;
            if (dx * dx + dy * dy + dz * dz > TELEPORT * TELEPORT) {
                reset(now);
                return;
            }
            double k = 1.0 - Math.exp(-h / INERTIA_SMOOTH);
            double nvx = dx / h, nvy = dy / h, nvz = dz / h;
            ax += ((nvx - vx) / h - ax) * k;
            ay += ((nvy - vy) / h - ay) * k;
            az += ((nvz - vz) / h - az) * k;
            vx = nvx; vy = nvy; vz = nvz;
            now.angularVelocity(prev, h, nw);
            alx += ((nw[0] - w[0]) / h - alx) * k;
            aly += ((nw[1] - w[1]) / h - aly) * k;
            alz += ((nw[2] - w[2]) / h - alz) * k;
            w[0] = nw[0]; w[1] = nw[1]; w[2] = nw[2];
            prev.set(now);
        }

        void motion(Xform now, double gravity, ClothSim.Motion m) {
            double[] a = {ax, ay, az};
            clamp(a, MAX_ACCEL);
            now.dirToLocal(a);
            m.ax = a[0] / now.s; m.ay = a[1] / now.s; m.az = a[2] / now.s;
            double[] g = {0.0, -gravity, 0.0};
            now.dirToLocal(g);
            m.gx = g[0] / now.s; m.gy = g[1] / now.s; m.gz = g[2] / now.s;
            double[] o = {w[0], w[1], w[2]};
            clamp(o, MAX_SPIN);
            m.wx = o[0]; m.wy = o[1]; m.wz = o[2];
            double[] al = {alx, aly, alz};
            clamp(al, MAX_SPIN_ACCEL);
            m.alx = al[0]; m.aly = al[1]; m.alz = al[2];
        }

        /** Udara bebas relatif ke titik asal ruang ini (lokal, satuan lokal/s). */
        void flow(Xform now, double[] wind, double[] out) {
            out[0] = wind[0] - vx; out[1] = wind[1] - vy; out[2] = wind[2] - vz;
            clamp(out, MAX_AIR_SPEED);
            now.dirToLocal(out);
            out[0] /= now.s; out[1] /= now.s; out[2] /= now.s;
        }
    }

    private static void clamp(double[] v, double max) {
        double l = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
        if (l > max) {
            double f = max / l;
            v[0] *= f; v[1] *= f; v[2] *= f;
        }
    }

    /** Satu potong kain beserta ruang dan tabrakannya. */
    private static final class Piece {
        final Xform frame = new Xform();       // ruang kain -> dunia, langkah sekarang
        final Xform prevFrame = new Xform();   // ... langkah lalu
        final Xform toBody = new Xform();      // ruang kain -> ruang badan
        final Kin kin = new Kin();
        final ClothSim.Motion motion = new ClothSim.Motion();
        final ClothCollider.Box[] boxes = new ClothCollider.Box[6];
        int airTick;
        boolean fresh;    // gerak sebelumnya nggak diketahui (baru lanjut setelah jeda)

        Piece() {
            for (int k = 0; k < boxes.length; k++) {
                boxes[k] = new ClothCollider.Box();
            }
        }

        void reset(Xform world) {
            frame.set(world);
            prevFrame.set(world);
            kin.reset(world);
            for (ClothCollider.Box b : boxes) {
                b.forget();
                b.active = false;
            }
            airTick = 0;
        }
    }

    public ClothSim cape;
    public ClothSim mantle;
    public ClothSim hood;
    private final Piece capePiece = new Piece();
    private final Piece mantlePiece = new Piece();
    private final Piece hoodPiece = new Piece();
    /** Hood dihitung di ruang kepala (dipakai) atau ruang leher (diturunkan). */
    private boolean hoodOnHead = true;

    // ruang bagian tubuh (lokal badan) di langkah sekarang
    private final Xform[] partL = new Xform[6];
    private final Xform neckL = new Xform();
    private final Xform neckW = new Xform();
    private final Xform headW = new Xform();
    private final double[] boxDims = new double[6];
    private final double[] flow = new double[3];
    private final double[] omega = new double[3];
    private static final Xform IDENTITY = new Xform();
    private final Xform tmpA = new Xform();
    private final Xform tmpB = new Xform();
    private final Xform armRestR = new Xform();
    private final Xform armRestL = new Xform();

    public Cloak() {
        for (int k = 0; k < partL.length; k++) {
            partL[k] = new Xform();
        }
        // lengan dalam pose diam, di ruang leher pose diam (buat bagian mantel yang ikut lengan)
        Xform neckRest = BodyRig.neck(BodyRig.DEFAULT, new Xform());
        Xform inv = new Xform().invert(neckRest);
        armRestR.mul(inv, BodyRig.frame(BodyRig.DEFAULT, BodyRig.RIGHT_ARM, new Xform()));
        armRestL.mul(inv, BodyRig.frame(BodyRig.DEFAULT, BodyRig.LEFT_ARM, new Xform()));
    }

    public boolean hoodOnHead() {
        return hoodOnHead;
    }

    // ------------------------------------------------------------------ pasang & lepas

    private void computeFrames(Input in) {
        for (int k = 0; k < partL.length; k++) {
            BodyRig.frame(in.parts, k, partL[k]);
        }
        BodyRig.neck(in.parts, neckL);
        neckW.mul(in.body, neckL);
        headW.mul(in.body, partL[BodyRig.HEAD]);
    }

    /** Jubah baru: menggantung, atau terbentang ke belakang lalu jatuh (saat berubah jadi Shazam). */
    public void addCape(Input in, boolean unfurl) {
        computeFrames(in);
        cape = CapeShape.create();
        CapeShape.place(cape, unfurl);
        capePiece.reset(neckW);
    }

    public void addMantle(Input in) {
        computeFrames(in);
        mantle = MantleShape.create();
        mantleTargets(in);
        mantle.resetToTargets();
        mantlePiece.reset(neckW);
    }

    /** Hood baru: langsung dipakai, atau sudah diturunkan di belakang leher. */
    public void addHood(Input in, boolean down) {
        computeFrames(in);
        hood = HoodShape.create();
        hoodOnHead = true;
        hoodPiece.reset(headW);
        hood.resetToTargets();
        if (down) {
            // dibentuk dengan fisikanya sendiri: diturunkan lewat atas kepala, lalu dibiarkan tenang
            double keep = in.hoodDown;
            int moves = SUBSTEPS * 10, rest = SUBSTEPS * 12;
            for (int k = 0; k < moves + rest; k++) {
                double t = Math.min(1.0, (k + 1) / (double) moves);
                in.hoodDown = t * t * (3.0 - 2.0 * t);
                stepHood(in);
            }
            in.hoodDown = keep;
            hood.snapshot();
        }
    }

    /**
     * Lupakan gerak sebelumnya (dipanggil saat fisika lanjut setelah jeda, misalnya lag atau pemain yang tadinya
     * jauh). Bentuk kain tetap, cuma lompatan posisi selama jeda nggak dianggap gerak.
     */
    public void resetMotion() {
        for (Piece piece : new Piece[] {capePiece, mantlePiece, hoodPiece}) {
            piece.kin.has = false;
            piece.fresh = true;
            for (ClothCollider.Box b : piece.boxes) {
                b.forget();
            }
        }
    }

    public void removeCape() {
        cape = null;
    }

    public void removeMantle() {
        mantle = null;
    }

    public void removeHood() {
        hood = null;
    }

    // ------------------------------------------------------------------ satu langkah kecil

    public void step(Input in) {
        computeFrames(in);
        if (cape != null) {
            stepCape(in);
        }
        if (mantle != null) {
            stepMantle(in);
        }
        if (hood != null) {
            stepHood(in);
        }
    }

    private void begin(Piece piece, Xform world, Input in) {
        if (piece.fresh) {
            piece.frame.set(world);
            piece.fresh = false;
        }
        piece.prevFrame.set(piece.frame);
        piece.frame.set(world);
        piece.kin.update(world, H);
        piece.kin.motion(world, in.water ? GRAVITY * (1.0 - WATER_BUOYANCY) : GRAVITY, piece.motion);
        piece.kin.flow(world, in.wind, flow);
        double[] o = {piece.kin.w[0], piece.kin.w[1], piece.kin.w[2]};
        clamp(o, MAX_SPIN);
        omega[0] = o[0]; omega[1] = o[1]; omega[2] = o[2];
    }

    private void physics(ClothSim sim, Piece piece, Input in, Runnable contacts) {
        double s = piece.frame.s;
        // udara berubah pelan dibanding langkah fisika: dihitung ulang tiap dua langkah
        if ((piece.airTick++ & 1) == 0) {
            CapeAir.fill(sim, flow, omega, piece.toBody, s, in.time, in.water ? 0.0 : 1.0);
        }
        double density = in.water ? CapeAir.WATER_DENSITY : CapeAir.AIR_DENSITY;
        double areal = sim == cape ? CapeShape.DENSITY : sim == mantle ? MantleShape.DENSITY : HoodShape.DENSITY;
        double dragN = 0.5 * density * NORMAL_DRAG / areal * s;
        double dragT = 0.5 * density * SKIN_DRAG / areal * s;
        sim.snapshot();
        sim.integrate(H, piece.motion, dragN, dragT, DAMPING);
        sim.solve(H, ITERATIONS, contacts);
    }

    /** Kotak bagian tubuh di ruang kain (inv = ruang badan -> ruang kain). */
    private void bodyBox(Piece piece, int slot, int part, Xform inv, boolean slim, int faces) {
        BodyRig.box(part, slim, boxDims);
        tmpA.mul(inv, partL[part]);
        ClothCollider.Box b = piece.boxes[slot];
        b.update(tmpA, boxDims[0], boxDims[1], boxDims[2], boxDims[3], boxDims[4], boxDims[5]);
        b.faces = faces;
    }

    private void stepCape(Input in) {
        Piece piece = capePiece;
        begin(piece, neckW, in);
        piece.toBody.set(neckL);
        Xform inv = tmpB.invert(neckL);
        bodyBox(piece, 0, BodyRig.TORSO, inv, in.slim, ClothCollider.ALL);
        bodyBox(piece, 1, BodyRig.HEAD, inv, in.slim, ClothCollider.ALL);
        bodyBox(piece, 2, BodyRig.RIGHT_ARM, inv, in.slim, ClothCollider.ALL);
        bodyBox(piece, 3, BodyRig.LEFT_ARM, inv, in.slim, ClothCollider.ALL);
        bodyBox(piece, 4, BodyRig.RIGHT_LEG, inv, in.slim, ClothCollider.ALL);
        bodyBox(piece, 5, BodyRig.LEFT_LEG, inv, in.slim, ClothCollider.ALL);
        physics(cape, piece, in, () -> {
            for (ClothCollider.Box b : piece.boxes) {
                ClothCollider.collide(cape, b, BODY_THICK, BODY_FRICTION, CapeShape.COLS);
            }
            ClothCollider.world(cape, piece.frame, piece.prevFrame, in.boxes, in.boxCount, WORLD_THICK, WORLD_FRICTION,
                    CapeShape.COLS);
        });
        if (cape.broken()) {
            CapeShape.place(cape, false);
        }
    }

    /** Bentuk pakai mantel: bentuk diam di ruang leher, bagian bahu ikut lengan. */
    private void mantleTargets(Input in) {
        Xform invNeck = new Xform().invert(neckL);
        // gerak tiap lengan dari pose diamnya, dinyatakan di ruang leher
        Xform armR = new Xform().mul(new Xform().mul(invNeck, partL[BodyRig.RIGHT_ARM]), new Xform().invert(armRestR));
        Xform armL = new Xform().mul(new Xform().mul(invNeck, partL[BodyRig.LEFT_ARM]), new Xform().invert(armRestL));
        double[] p = new double[3];
        for (int i = 0; i < mantle.count; i++) {
            double rx = MantleShape.REST_X[i], ry = MantleShape.REST_Y[i], rz = MantleShape.REST_Z[i];
            double wgt = MantleShape.ARM_WEIGHT[i];
            if (wgt > 0.0) {
                p[0] = rx; p[1] = ry; p[2] = rz;
                (rx > 0 ? armR : armL).toWorld(p);
                double dx = p[0] - rx, dy = p[1] - ry, dz = p[2] - rz;
                double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
                if (d > MantleShape.ARM_REACH) {
                    double f = MantleShape.ARM_REACH / d;
                    dx *= f; dy *= f; dz *= f;
                }
                rx += dx * wgt; ry += dy * wgt; rz += dz * wgt;
            }
            mantle.tgtX[i] = rx; mantle.tgtY[i] = ry; mantle.tgtZ[i] = rz;
        }
    }

    private void stepMantle(Input in) {
        Piece piece = mantlePiece;
        begin(piece, neckW, in);
        piece.toBody.set(neckL);
        mantleTargets(in);
        Xform inv = tmpB.invert(neckL);
        bodyBox(piece, 0, BodyRig.TORSO, inv, in.slim, ClothCollider.ALL);
        bodyBox(piece, 2, BodyRig.RIGHT_ARM, inv, in.slim, ClothCollider.ALL);
        bodyBox(piece, 3, BodyRig.LEFT_ARM, inv, in.slim, ClothCollider.ALL);
        physics(mantle, piece, in, () -> {
            ClothCollider.collide(mantle, piece.boxes[0], BODY_THICK, BODY_FRICTION, MantleShape.COLS);
            ClothCollider.collide(mantle, piece.boxes[2], BODY_THICK, BODY_FRICTION, MantleShape.COLS);
            ClothCollider.collide(mantle, piece.boxes[3], BODY_THICK, BODY_FRICTION, MantleShape.COLS);
            if (cape != null) {
                // mantel selalu di luar bagian atas jubah yang tertutup mantel (keduanya di ruang leher)
                ClothCollider.layer(mantle, cape, 0, CapeShape.UNDER_MANTLE_ROWS, 0, CapeShape.COLS - 1, IDENTITY, IDENTITY,
                        LAYER_CLEAR, 0.08, MantleShape.COLS);
            }
        });
        if (mantle.broken()) {
            mantleTargets(in);
            mantle.resetToTargets();
        }
    }

    private void stepHood(Input in) {
        Piece piece = hoodPiece;
        double down = Math.max(0.0, Math.min(1.0, in.hoodDown));
        boolean onHead = down < 0.5;
        Xform frameL = onHead ? partL[BodyRig.HEAD] : neckL;
        Xform frameW = onHead ? headW : neckW;
        if (onHead != hoodOnHead) {
            // pindah ruang: posisi di dunia tetap, cuma dinyatakan di ruang yang lain
            hood.reframe(piece.frame, frameW);
            piece.kin.reset(frameW);
            piece.frame.set(frameW);
            for (ClothCollider.Box b : piece.boxes) {
                b.forget();
            }
            hoodOnHead = onHead;
        }
        begin(piece, frameW, in);
        piece.toBody.set(frameL);

        // pinggiran: dipaku di wajah (dipakai), dipegang tangan (dibuka/dipasang), atau melingkari leher (diturunkan)
        double[] p = new double[3];
        for (int c = 0; c < HoodShape.COLS; c++) {
            HoodShape.rim(c, down, headW, neckW, p);
            frameW.toLocal(p);
            hood.tgtX[c] = p[0]; hood.tgtY[c] = p[1]; hood.tgtZ[c] = p[2];
        }
        // bentuk tujuan: bentuk hood (dipakai), lintasan lewat atas kepala (dibuka/dipasang), atau kantong di punggung
        HoodShape.constrain(hood, down);
        for (int i = HoodShape.COLS; i < hood.count; i++) {
            if (down <= 0.0) {
                hood.tgtX[i] = HoodShape.REST_X[i]; hood.tgtY[i] = HoodShape.REST_Y[i]; hood.tgtZ[i] = HoodShape.REST_Z[i];
                if (!onHead) {
                    p[0] = hood.tgtX[i]; p[1] = hood.tgtY[i]; p[2] = hood.tgtZ[i];
                    headW.toWorld(p);
                    frameW.toLocal(p);
                    hood.tgtX[i] = p[0]; hood.tgtY[i] = p[1]; hood.tgtZ[i] = p[2];
                }
            } else {
                HoodShape.path(i, down, headW, p);
                frameW.toLocal(p);
                hood.tgtX[i] = p[0]; hood.tgtY[i] = p[1]; hood.tgtZ[i] = p[2];
            }
        }
        Xform inv = tmpB.invert(frameL);
        bodyBox(piece, 0, BodyRig.HEAD, inv, in.slim, ClothCollider.ALL);
        boolean torso = !onHead;
        if (torso) {
            // badan cuma ditabrak saat hood sudah di belakang kepala; saat dipakai, hood ikut kepala
            // (kepala Minecraft memang masuk ke badan saat mendongak atau menunduk)
            bodyBox(piece, 1, BodyRig.TORSO, inv, in.slim, ClothCollider.ALL);
        } else {
            piece.boxes[1].active = false;
            piece.boxes[1].forget();
        }
        boolean onMantle = !onHead && mantle != null;
        boolean shoulders = torso && mantle != null;
        if (shoulders) {
            // isi mantel di bahu dan punggung atas (ruang leher), supaya hood tergeletak di atas mantel
            tmpA.mul(inv, neckL);
            piece.boxes[2].update(tmpA, 0.0, MANTLE_BOX[1], MANTLE_BOX[2], MANTLE_BOX[3], MANTLE_BOX[4], MANTLE_BOX[5]);
            piece.boxes[2].faces = ClothCollider.ALL;
        } else {
            piece.boxes[2].active = false;
            piece.boxes[2].forget();
        }
        physics(hood, piece, in, () -> {
            ClothCollider.collide(hood, piece.boxes[0], BODY_THICK, BODY_FRICTION, HoodShape.COLS);
            if (torso) {
                ClothCollider.collide(hood, piece.boxes[1], BODY_THICK, BODY_FRICTION, HoodShape.COLS);
            }
            if (shoulders) {
                ClothCollider.collide(hood, piece.boxes[2], BODY_THICK, BODY_FRICTION, HoodShape.COLS);
            }
            if (onMantle) {
                // hood yang diturunkan tergeletak di atas punggung mantel (keduanya di ruang leher)
                ClothCollider.layer(hood, mantle, 0, MantleShape.ROWS - 1, 5, MantleShape.COLS - 6, IDENTITY, IDENTITY,
                        HOOD_ON_MANTLE, 0.12, HoodShape.COLS);
            }
        });
        if (hood.broken()) {
            hoodOnHead = true;
            piece.reset(headW);
            hood.resetToTargets();
        }
    }

    // ------------------------------------------------------------------ hasil

    /** Ruang lokal jubah dan mantel (leher) di ruang badan. */
    public static Xform neckFrame(float[] parts, Xform out) {
        return BodyRig.neck(parts, out);
    }

    /** Ruang lokal hood sekarang (kepala atau leher) di ruang badan. */
    public Xform hoodFrame(float[] parts, Xform out) {
        return hoodOnHead ? BodyRig.frame(parts, BodyRig.HEAD, out) : BodyRig.neck(parts, out);
    }

    /** Ruang dunia terakhir tiap potong (buat butiran cahaya saat lenyap). */
    public Xform worldFrame(ClothSim sim) {
        return sim == cape ? capePiece.frame : sim == mantle ? mantlePiece.frame : hoodPiece.frame;
    }

    /**
     * Posisi gambar tiap titik: interpolasi antara keadaan sebelum dan sesudah langkah terakhir (alpha 0..1),
     * lalu dipasang di ruang render (frame = ruang kain -> ruang render).
     */
    public static void pose(ClothSim sim, Xform frame, double alpha, float[] vx, float[] vy, float[] vz) {
        double[] p = new double[3];
        for (int i = 0; i < sim.count; i++) {
            p[0] = sim.rx[i] + (sim.x[i] - sim.rx[i]) * alpha;
            p[1] = sim.ry[i] + (sim.y[i] - sim.ry[i]) * alpha;
            p[2] = sim.rz[i] + (sim.z[i] - sim.rz[i]) * alpha;
            frame.toWorld(p);
            vx[i] = (float) p[0]; vy[i] = (float) p[1]; vz[i] = (float) p[2];
        }
    }
}
