package com.shazammod.client.fx;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamSounds;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Runes;
import com.shazammod.client.vfx.Vfx;
import java.util.List;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

/** Lapisan api neraka tambahan untuk Sabbac: lebih tebal, lebih "film". Efek asli SabbacFx tetap jalan. */
public final class SabbacCine {
    static final int HELL = 0xFF5A1E;
    static final int HELL_DEEP = 0xB3120A;
    static final int EMBER = 0xFFB347;
    static final int CORE = 0xFFE3A6;
    static final int BLOOD = 0x6E0A0A;
    static final int SMOKE = 0x2A1410;
    static final int ASH = 0x4A3A34;

    private SabbacCine() {
    }

    public static void onAnim(AbstractClientPlayer p, ShazamAnim a, Vec3 pos) {
        float boostOld = Vfx.setBoost(SabbacFx.BOOST);   // 0.33: lapisan tambahan ikut tebal (bloom)
        try {
            onAnim0(p, a, pos);
        } finally {
            Vfx.setBoost(boostOld);
        }
    }

    private static void onAnim0(AbstractClientPlayer p, ShazamAnim a, Vec3 pos) {
        SabbacFx.onAnim(p, a, pos);
        try {
            if (SabbacFx.handles(p, a)) extra(p, a, pos);
        } catch (Throwable ignored) {
        }
        try {
            if (SabbacFx.handles(p, a)) SabbacHd.onAnim(p, a, pos);   // 0.34: lapisan HD di atas semuanya
        } catch (Throwable ignored) {
        }
    }

    public static void tick(ClientLevel level) {
        float boostOld = Vfx.setBoost(SabbacFx.BOOST);   // 0.33: lapisan tambahan ikut tebal (bloom)
        try {
            tick0(level);
        } finally {
            Vfx.setBoost(boostOld);
        }
    }

    private static void tick0(ClientLevel level) {
        SabbacFx.tick(level);
        try {
            ambient(level);
        } catch (Throwable ignored) {
        }
        SabbacHd.tick(level);   // 0.34: api di bahu, selubung api Gerbang Neraka, jejak api terbang
    }

    public static void clear() {
        SabbacFx.clear();
        SabbacHd.clear();
    }

    private static void ambient(ClientLevel level) {
        RandomSource r = level.random;
        List<AbstractClientPlayer> players = level.players();
        for (AbstractClientPlayer p : players) {
            int id = p.getId();
            if (!ShazamClientState.isTransformed(id) || !ShazamClientState.isSabbac(id) || p.isInvisible()) continue;
            Vec3 c = CineKit.chest(p);
            if (r.nextFloat() < 0.5f) {
                double a = r.nextDouble() * Math.PI * 2.0;
                Vfx.ember(c.x + Math.cos(a) * 0.35, c.y + (r.nextDouble() - 0.3) * 0.9, c.z + Math.sin(a) * 0.35,
                        (r.nextDouble() - 0.5) * 0.02, 0.03 + r.nextDouble() * 0.04, (r.nextDouble() - 0.5) * 0.02, 0.05f + r.nextFloat() * 0.04f, 16 + r.nextInt(10));
            }
            if (r.nextFloat() < 0.12f) {
                Vfx.smoke(c.x + (r.nextDouble() - 0.5) * 0.5, c.y + 0.6, c.z + (r.nextDouble() - 0.5) * 0.5, 0.0, 0.025, 0.0, SMOKE, 0.2f, 30);
            }
            if (p.onGround() && (p.tickCount + id) % 7 == 0) {
                Vec3 v = p.getDeltaMovement();
                if (v.x * v.x + v.z * v.z > 0.004) {
                    Ground.Map g = CineKit.ground(level, CineKit.feet(p), 1.0);
                    Vfx.add(new Fx.Scorch(g.center(CineKit.feet(p)), 0.38, 90, 26, g));
                }
            }
        }
    }

    private static void hellImpact(ClientLevel level, AbstractClientPlayer p, Vec3 at, float s) {
        Vec3 dir = CineKit.norm(at.subtract(CineKit.chest(p)));
        Vfx.add(new Fx.Flash(at, 1.2f * s, CORE, 6, 0.95f));
        Vfx.add(new Fx.Flash(at, 2.0f * s, HELL, 10, 0.55f));
        Vfx.add(new Fx.Wave(at, dir, 1.9 * s, 0.14 * s, HELL, 10, 0.8f, 0.06f, null));
        Vfx.add(new Fx.Ripple(at, dir, 1.6 * s, 0.2, 1.1 * s, 0.12, EMBER, 8, 0.6f, true));
        CineFx.flare(at, HELL, 7.0f * s, 0.14f, 0.85f, 12);
        CineKit.sparks(at, (int) (16 * s), EMBER, 0.32 * s, 0.05f, 9, at.y - 1.2);
        CineKit.embers(at, (int) (12 * s), 0.4 * s, 0.06, 0.08f, 18);
        ShazamFx.smokeCloud(level, at, SMOKE, 2 + (int) (2 * s), 0.5 * s);
    }

    private static void eruption(ClientLevel level, AbstractClientPlayer p, Vec3 at, double height, double radius, boolean big) {
        Vfx.add(new Fx.Pillar(at, height, (float) (radius * 0.45), HELL, 18));
        Vfx.add(new Fx.Pillar(at, height * 0.45, (float) (radius * 0.22), CORE, 12));
        CineKit.shock(level, at, CineKit.UP, radius * 2.2, HELL, EMBER, 22, 0.85f, true);
        CineKit.crater(level, at, radius, HELL, ASH, big ? 60 : 30);
        CineKit.embers(at, big ? 90 : 40, radius * 0.5, 0.12, 0.09f, 26);
        ShazamFx.smokeCloud(level, at.add(0.0, 1.0, 0.0), SMOKE, big ? 12 : 6, radius * 0.8);
        ShazamFx.schedule(2, 26, (lvl, t) -> {
            if (t % 2 == 0) CineKit.embers(at, 6, radius * 0.35, 0.18 + t * 0.004, 0.08f, 22);
            if (t % 5 == 0) Vfx.smoke(at.x, at.y + 1.0 + t * 0.15, at.z, 0.0, 0.06, 0.0, SMOKE, 0.5f, 40);
        });
    }

    /** 0.33: lapisan tambahan meledak tepat sesudah ancang-ancang (konstanta ShazamAnim yang sama dengan SabbacFx). */
    private static void extra(AbstractClientPlayer p, ShazamAnim a, Vec3 pos) {
        int delay = switch (a) {
            case TRANSFORM -> ShazamAnim.TRANSFORM_STRIKE;
            case REVERT -> ShazamAnim.REVERT_WINDUP;
            case KNOCKOUT -> ShazamAnim.KNOCKOUT_BURST;
            case SABBAC_AYM -> ShazamAnim.AYM_WINDUP;
            case SABBAC_AYM_BURST -> ShazamAnim.NOVA_WINDUP;
            case SABBAC_CHAINS -> ShazamAnim.CHAIN_WINDUP;
            case SABBAC_BREATH -> ShazamAnim.BREATH_WINDUP;
            case SABBAC_ROAR -> ShazamAnim.TERROR_WINDUP;
            case SABBAC_WINGS -> ShazamAnim.WINGS_WINDUP;
            case SABBAC_HELLGATE -> ShazamAnim.HELLGATE_WINDUP;
            case SABBAC_CALL -> ShazamAnim.SABBAC_CALL_WINDUP;
            case SABBAC_LEGION -> ShazamAnim.LEGION_WINDUP;
            default -> 0;
        };
        if (delay <= 0) {
            extraNow(p, a, pos);
        } else {
            ShazamFx.schedule(delay, 1, (lvl, t) -> {
                if (p.isAlive()) extraNow(p, a, pos);
            });
        }
    }

    private static void extraNow(AbstractClientPlayer p, ShazamAnim a, Vec3 pos) {
        ClientLevel level = CineKit.level(p);
        boolean local = CineKit.isLocal(p);
        Vec3 c = CineKit.chest(p);
        Vec3 f = CineKit.feet(p);
        Vec3 l = CineKit.look(p);
        Vec3 at = pos != null ? pos : c;
        switch (a) {
            case SUMMON -> {
                Ground.Map g = CineKit.ground(level, f, 5.0);
                Vfx.add(new Ground.Cracks(g.center(f), g, 10, 4.5f, 150, 90, HELL, level.random.nextLong()));
                Vfx.add(new Runes.Circle(Lightning.Anchor.fixed(g.center(f).add(0.0, 0.05, 0.0)), CineKit.UP, 2.4, HELL, 88, 0.03f, 0.75f, g));
                ShazamFx.schedule(0, 88, (lvl, t) -> {
                    double rad = 0.8 + t * 0.03;
                    Vec3 ff = CineKit.feet(p);
                    RandomSource r = lvl.random;
                    for (int i = 0; i < 2; i++) {
                        double ang = t * 0.35 + i * Math.PI + r.nextDouble() * 0.4;
                        Vfx.ember(ff.x + Math.cos(ang) * rad, ff.y + 0.1, ff.z + Math.sin(ang) * rad, -Math.sin(ang) * 0.05, 0.05 + t * 0.002, Math.cos(ang) * 0.05, 0.08f, 24);
                    }
                    if (t % 8 == 0) ShazamFx.smokeCloud(lvl, ff, SMOKE, 3, rad);
                    if (t % 22 == 0) CineKit.sound(lvl, ff, ShazamSounds.DARK_HISS, 0.7f, 0.7f);
                });
                if (local) ScreenFx.vignette(0.55f, BLOOD, 88);
            }
            case TRANSFORM -> {
                eruption(level, p, f, 46.0, 3.6, true);
                CineKit.burst(c, 3.0f, HELL, CORE, 16, 1.0f);
                Vfx.add(new Fx.Bubble(c, 6.0, HELL_DEEP, 18, 0.6f, 1.0, 2.2, true));
                CineFx.godRays(CineKit.chestAnchor(p), HELL, 40.0, 3.0, 9, 0.85f, 30);
                CineKit.sound(level, c, ShazamSounds.FIRE_BLAST, 1.4f, 0.8f);
                if (local) {
                    ScreenFlash.flash(0.7f, 0xFF4A18);
                    FovKick.punch(0.5f);
                }
                CineKit.camera(p, c, 1.0f, 28.0);
            }
            case REVERT, KNOCKOUT -> {
                ShazamFx.smokeCloud(level, c, SMOKE, 8, 0.9);
                CineKit.embers(f, 30, 0.6, 0.05, 0.07f, 22);
            }
            case LAUNCH -> {
                CineKit.shock(level, f, CineKit.UP, 4.5, HELL, EMBER, 14, 0.6f, true);
                CineKit.embers(f, 30, 1.0, 0.15, 0.08f, 20);
            }
            case LAND_HERO, CRASH -> {
                boolean big = a == ShazamAnim.CRASH;
                CineKit.crater(level, f, big ? 4.2 : 2.6, HELL, ASH, big ? 50 : 24);
                CineKit.shock(level, f, CineKit.UP, big ? 9.0 : 5.5, HELL, EMBER, 18, 0.8f, true);
                CineKit.embers(f, big ? 50 : 24, 1.2, 0.12, 0.08f, 22);
                CineKit.camera(p, f, big ? 0.9f : 0.5f, 22.0);
            }
            case SONIC_BOOM -> {
                Vfx.add(new Fx.Cone(c.add(l.scale(0.6)), l.scale(-1.0), 3.4, 1.15, HELL, 12, 0.5f, 1.8, true));
                Vfx.add(new Fx.Ripple(c, l, 3.0, 0.8, 4.2, 0.35, EMBER, 12, 0.6f, true));
            }
            case SABBAC_HORNS -> {
                Vfx.add(new Fx.Glow(p, CineKit.headAnchor(p), 1.3f, HELL, 18, 3));
                ShazamFx.schedule(0, 16, (lvl, t) -> {
                    Vec3 h = CineKit.chest(p).add(0.0, 0.55, 0.0);
                    double ang = t * 0.9;
                    Vfx.ember(h.x + Math.cos(ang) * 0.6, h.y, h.z + Math.sin(ang) * 0.6, -Math.sin(ang) * 0.08, 0.05, Math.cos(ang) * 0.08, 0.08f, 14);
                    Vfx.ember(h.x - Math.cos(ang) * 0.6, h.y, h.z - Math.sin(ang) * 0.6, Math.sin(ang) * 0.08, 0.05, -Math.cos(ang) * 0.08, 0.08f, 14);
                });
                Ground.Map g = CineKit.ground(level, f, 2.5);
                Vfx.add(new Ground.Cracks(g.center(f), g, 6, 2.2f, 110, 50, HELL, level.random.nextLong()));
            }
            case SABBAC_GORE, SABBAC_PUNCH -> hellImpact(level, p, at, a == ShazamAnim.SABBAC_GORE ? 2.2f : 1.0f);
            case SABBAC_HELLPUNCH -> {
                hellImpact(level, p, at, 3.0f);
                CineFx.godRays(Lightning.Anchor.fixed(at), HELL, 30.0, 1.6, 7, 0.85f, 20);
                CineKit.camera(p, at, 0.9f, 26.0);
                if (local) ScreenFlash.flash(0.3f, 0xFF3A10);
            }
            case SABBAC_AYM -> {
                Vfx.add(new Fx.Glow(p, CineKit.chestAnchor(p), 1.8f, HELL, 28, 10));
                ShazamFx.schedule(0, 28, (lvl, t) -> {
                    Vec3 ff = CineKit.feet(p);
                    RandomSource r = lvl.random;
                    int n = Vfx.count(5);
                    for (int i = 0; i < n; i++) {
                        double h = r.nextDouble() * 2.4;
                        double rad = 0.7 + h * 0.45;
                        double ang = t * 0.55 + h * 2.0 + i * 1.3;
                        Vfx.ember(ff.x + Math.cos(ang) * rad, ff.y + h, ff.z + Math.sin(ang) * rad, -Math.sin(ang) * 0.12, 0.06, Math.cos(ang) * 0.12, 0.09f, 12);
                    }
                    if (t % 5 == 0) CineKit.heatRings(ff.add(0.0, 0.3, 0.0), HELL, 1.6, 12);
                });
            }
            case SABBAC_AYM_BURST -> {
                CineKit.shock(level, f, CineKit.UP, 9.0, HELL, EMBER, 20, 0.9f, true);
                Vfx.add(new Fx.Bubble(c, 4.8, HELL, 14, 0.65f, 1.0, 2.0, true));
                Vfx.add(new Fx.Ripple(c, CineKit.UP, 1.4, 1.0, 6.0, 0.6, EMBER, 14, 0.5f, true));
                CineKit.embers(c, 70, 1.6, 0.14, 0.1f, 22);
                CineKit.sparks(c, 40, EMBER, 0.5, 0.055f, 12, f.y);
                CineKit.camera(p, c, 0.7f, 22.0);
            }
            case SABBAC_CHAINS -> ShazamFx.schedule(0, 14, (lvl, t) -> {
                Vec3 cc = CineKit.chest(p);
                Vec3 ll = CineKit.look(p);
                Vfx.smoke(cc.x + ll.x * 0.5, cc.y, cc.z + ll.z * 0.5, ll.x * 0.12, 0.01, ll.z * 0.12, SMOKE, 0.25f, 22);
                CineKit.embers(cc.add(ll.scale(0.6)), 3, 0.2, 0.05, 0.07f, 14);
            });
            case SABBAC_CHAIN_BIND -> {
                Ground.Map g = CineKit.ground(level, at, 2.0);
                Vfx.add(new Runes.Circle(Lightning.Anchor.fixed(g.center(at).add(0.0, 0.05, 0.0)), CineKit.UP, 1.5, HELL, 34, 0.08f, 0.9f, g));
                CineKit.shock(level, at, CineKit.UP, 2.4, HELL, EMBER, 12, 0.6f, true);
                ShazamFx.smokeCloud(level, at, SMOKE, 6, 0.8);
            }
            case SABBAC_BREATH -> {
                Vec3 m = CineKit.mouth(p);
                Vfx.add(new Fx.Cone(m, l, 8.0, 0.8, HELL, 18, 0.5f, 2.0, true));
                ShazamFx.schedule(0, ShazamAnim.BREATH_TICKS, (lvl, t) -> {
                    Vec3 mm = CineKit.mouth(p);
                    Vec3 ll = CineKit.look(p);
                    RandomSource r = lvl.random;
                    int n = Vfx.count(3);
                    for (int i = 0; i < n; i++) {
                        double s = 0.25 + r.nextDouble() * 0.25;
                        Vfx.ember(mm.x, mm.y, mm.z, ll.x * s + (r.nextDouble() - 0.5) * 0.08, ll.y * s + (r.nextDouble() - 0.5) * 0.06, ll.z * s + (r.nextDouble() - 0.5) * 0.08, 0.1f, 14);
                    }
                    if (t % 2 == 0) Vfx.smoke(mm.x, mm.y, mm.z, ll.x * 0.2, ll.y * 0.2 + 0.01, ll.z * 0.2, SMOKE, 0.3f, 26);
                });
            }
            case SABBAC_ROAR -> {
                Vfx.add(new Fx.Ripple(c, l, 10.0, 0.6, 5.5, 0.7, HELL_DEEP, 18, 0.55f, true));
                Vfx.add(new Fx.Ripple(c, l, 6.0, 0.4, 3.5, 0.35, HELL, 12, 0.6f, false));
                Vfx.add(new Fx.Wave(c.add(l.scale(0.8)), l, 4.0, 0.25, HELL, 12, 0.7f, 0.06f, null));
                CineKit.shock(level, f, CineKit.UP, 6.5, ASH, HELL, 16, 0.6f, true);
                CineKit.camera(p, c, 0.8f, 26.0);
                if (local) ScreenFx.vignette(0.6f, BLOOD, 30);
            }
            case SABBAC_WINGS -> {
                CineKit.shock(level, f, CineKit.UP, 6.0, EMBER, HELL, 14, 0.6f, true);
                ShazamFx.dustPuffs(level, f, ASH, Vfx.count(24), 2.0, 0.3);
                CineKit.embers(c, 40, 1.4, 0.08, 0.08f, 20);
            }
            case SABBAC_HELLGATE -> {
                eruption(level, p, f, 60.0, 4.2, true);
                Ground.Map g = CineKit.ground(level, f, 5.0);
                Vfx.add(new Runes.Circle(Lightning.Anchor.fixed(g.center(f).add(0.0, 0.05, 0.0)), CineKit.UP, 3.4, HELL, 50, 0.04f, 1.0f, g));
                if (local) ScreenFlash.flash(0.5f, 0xFF3A10);
                CineKit.camera(p, f, 1.1f, 30.0);
            }
            case SABBAC_GEYSER -> {
                eruption(level, p, at, 24.0, 1.8, false);
                ShazamFx.schedule(2, 18, (lvl, t) -> {
                    RandomSource r = lvl.random;
                    for (int i = 0; i < 3; i++) {
                        Vfx.spark(at.x, at.y + 2.0 + t * 0.3, at.z, (r.nextDouble() - 0.5) * 0.3, 0.2 + r.nextDouble() * 0.2, (r.nextDouble() - 0.5) * 0.3, EMBER, 0.07f, 18, at.y);
                    }
                });
            }
            case SABBAC_CALL -> {
                if (local) ScreenFlash.flash(0.35f, 0x5A0A05);
                CineKit.embers(f, 40, 2.2, 0.1, 0.08f, 24);
                CineKit.shock(level, f, CineKit.UP, 5.0, HELL_DEEP, HELL, 18, 0.5f, true);
            }
            case SABBAC_LEGION -> {
                RandomSource r = level.random;
                for (int i = 0; i < 5; i++) {
                    double ang = i * Math.PI * 2.0 / 5.0 + r.nextDouble() * 0.3;
                    Vec3 sp = f.add(Math.cos(ang) * 2.6, 0.0, Math.sin(ang) * 2.6);
                    Ground.Map g = CineKit.ground(level, sp, 1.4);
                    Vec3 gc = g.center(sp);
                    Vfx.add(new Runes.Circle(Lightning.Anchor.fixed(gc.add(0.0, 0.05, 0.0)), CineKit.UP, 0.9, HELL, 40, 0.1f, 0.85f, g));
                    Vfx.add(new Fx.Pillar(gc, 6.0, 0.6f, HELL, 14));
                    ShazamFx.smokeCloud(level, gc, SMOKE, 4, 0.6);
                }
            }
            case SABBAC_RISE -> {
                Ground.Map g = CineKit.ground(level, at, 2.0);
                Vfx.add(new Ground.Cracks(g.center(at), g, 7, 1.8f, 120, 60, HELL, level.random.nextLong()));
                Vfx.add(new Fx.Flash(at.add(0.0, 0.3, 0.0), 1.4f, HELL, 10, 0.7f));
                ShazamFx.smokeCloud(level, at, SMOKE, 6, 0.7);
                CineKit.embers(at, 20, 0.6, 0.1, 0.08f, 20);
            }
            case SABBAC_PULSE -> Vfx.add(new Fx.Ripple(c, CineKit.UP, 1.6, 0.5, 1.8, 0.14, HELL, 10, 0.5f, true));
            case SABBAC_ENGULF -> {
                ShazamFx.smokeCloud(level, at, SMOKE, 6, 0.6);
                CineKit.embers(at, 22, 0.5, 0.04, 0.08f, 16);
                Vfx.add(new Fx.Flash(at, 0.9f, HELL, 6, 0.6f));
            }
            case SABBAC_FIRE_OUT -> ShazamFx.smokeCloud(level, c, 0x8A8480, 8, 0.7);
            case SABBAC_FIRE_IN -> {
                CineKit.burst(c, 1.6f, HELL, CORE, 10, 0.8f);
                CineKit.embers(c, 40, 0.8, 0.1, 0.09f, 20);
            }
            case SABBAC_PACT -> ShazamFx.schedule(0, 90, (lvl, t) -> {
                Vec3 ff = CineKit.feet(p);
                if (t % 3 == 0) CineKit.embers(ff, 4, 2.0 - t * 0.015, 0.06, 0.08f, 24);
                if (t % 15 == 0) {
                    ShazamFx.smokeCloud(lvl, ff, SMOKE, 5, 2.2);
                    if (CineKit.isLocal(p)) ScreenFx.vignette(0.45f, BLOOD, 16);
                }
            });
            default -> {
            }
        }
    }
}
