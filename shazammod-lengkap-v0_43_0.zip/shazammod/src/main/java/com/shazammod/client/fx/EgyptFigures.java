package com.shazammod.client.fx;

import static com.shazammod.client.fx.GodFigures.RIG;
import static com.shazammod.client.fx.GodFigures.clamp01;
import static com.shazammod.client.fx.GodFigures.deltoids;
import static com.shazammod.client.fx.GodFigures.dir;
import static com.shazammod.client.fx.GodFigures.hairCap;
import static com.shazammod.client.fx.GodFigures.hand;
import static com.shazammod.client.fx.GodFigures.head;
import static com.shazammod.client.fx.GodFigures.leg;
import static com.shazammod.client.fx.GodFigures.lerp;
import static com.shazammod.client.fx.GodFigures.limbArm;
import static com.shazammod.client.fx.GodFigures.longHair;
import static com.shazammod.client.fx.GodFigures.loop;
import static com.shazammod.client.fx.GodFigures.muscles;
import static com.shazammod.client.fx.GodFigures.outBack;
import static com.shazammod.client.fx.GodFigures.smooth;
import static com.shazammod.client.fx.GodFigures.torso;

import com.shazammod.client.fx.GodFigures.Body;
import com.shazammod.client.fx.GodFigures.Pose;
import com.shazammod.client.fx.GodFigures.Rig;
import com.shazammod.client.fx.GodMesh.Frame;

/**
 * Enam dewa Mesir pemberi kekuatan Black Adam (murni Java), dengan rangka & alat bantu yang sama dengan GodFigures:
 *
 * S - Shu    : dewa udara, bulu burung unta tegak di kepala, kedua tangan menyangga langit berbintang (Nut).
 * H - Heru   : berkepala elang dengan tanda mata Wedjat, mahkota ganda merah-putih (pschent), sayap lebar, tongkat was.
 * A - Amon   : raja para dewa, kulit biru, mahkota dua bulu tinggi bergaris, janggut dewa, tongkat was & ankh.
 * Z - Zehuti : berkepala ibis berparuh panjang melengkung, cakram bulan & bulan sabit, palet juru tulis & pena buluh.
 * A - Aton   : cakram matahari bersinar dengan ular kobra (uraeus); sinar-sinarnya berujung tangan terbuka, satu
 *              menyodorkan ankh (tanda kehidupan).
 * M - Mehen  : ular raksasa bergelang emas-merah yang melingkar berlapis-lapis, lalu menegakkan leher & tudungnya.
 *
 * Semua berpakaian khas Mesir: kain shendyt berlipit dengan celemek emas, kalung lebar (wesekh) berlapis emas & batu,
 * gelang lengan, rambut palsu (wig).
 */
final class EgyptFigures {
    private EgyptFigures() {}

    private static final Body SHU_BODY = new Body();
    private static final Body HERU_BODY = new Body();
    private static final Body AMON_BODY = new Body();
    private static final Body ZEHUTI_BODY = new Body();

    static {
        Body b = SHU_BODY;   // ramping & ringan seperti udara
        b.chestRx = 0.18; b.chestRz = 0.118; b.waistRx = 0.142; b.waistRz = 0.1; b.hipRx = 0.155; b.hipRz = 0.106;
        b.shoulderX = 0.2; b.limb = 1.0; b.neckR = 0.06;

        b = HERU_BODY;       // pejuang
        b.hip = 1.03; b.chestRx = 0.215; b.chestRz = 0.142; b.waistRx = 0.165; b.waistRz = 0.115; b.hipRx = 0.178;
        b.hipRz = 0.12; b.shoulderX = 0.222; b.limb = 1.15; b.neckR = 0.066;

        b = AMON_BODY;       // raja para dewa
        b.hip = 1.04; b.chestRx = 0.225; b.chestRz = 0.148; b.waistRx = 0.178; b.waistRz = 0.124; b.hipRx = 0.188;
        b.hipRz = 0.128; b.shoulderX = 0.232; b.limb = 1.18; b.neckR = 0.07; b.headRx = 0.1;

        b = ZEHUTI_BODY;     // juru tulis para dewa: langsing
        b.chestRx = 0.168; b.chestRz = 0.11; b.waistRx = 0.136; b.waistRz = 0.096; b.hipRx = 0.15; b.hipRz = 0.104;
        b.shoulderX = 0.188; b.limb = 0.94; b.neckR = 0.058; b.neck = 0.09;
    }

    // ================================================================== pakaian & perhiasan Mesir

    /** Kain shendyt berlipit dari pinggang, ikat pinggang emas, dan celemek emas di depan. */
    static void kilt(GodMesh m, Rig r, Body b, int linen, int gold, double t, double len, double flare) {
        Frame pv = r.pelvis;
        double sway = Math.sin(t * 0.06) * 0.012;
        double[] ly = {0.07, -0.05, -0.05 - len * 0.5, -0.05 - len};
        double[] lrx = {b.hipRx * 1.05, b.hipRx * 1.13, b.hipRx * (1.18 + flare * 0.5), b.hipRx * (1.22 + flare)};
        double[] lrz = {b.hipRz * 1.12, b.hipRz * 1.24, b.hipRz * (1.32 + flare * 0.5), b.hipRz * (1.38 + flare)};
        double[] lcz = {0, 0.004, 0.01 + sway, 0.014 + sway * 1.6};
        m.mat(linen, 0.9f, 0.12f).lathe(pv, null, ly, lcz, lrx, lrz, 4, 28, 0, Math.PI * 2,
                (k, a) -> 1.0 + (k == 0 ? 0.0 : 0.032 * Math.sin(a * 28.0)), false);
        loop(m.mat(gold, 0.96f, 0.5f), pv, 0.07, b.hipRx * 1.08, b.hipRz * 1.15, 0, 0.017, 20);
        // celemek emas berlipit di depan (menyempit ke atas)
        double[] ap = new double[3 * 3], aw = new double[3 * 3];
        pv.point(0, 0.05, b.hipRz * 1.18, ap, 0);
        pv.point(0, -0.05 - len * 0.45, b.hipRz * (1.32 + flare * 0.45) + 0.012, ap, 3);
        pv.point(0, -0.05 - len * 0.95, b.hipRz * (1.38 + flare) + 0.016, ap, 6);
        for (int k = 0; k < 3; k++) {
            aw[k * 3] = pv.xx; aw[k * 3 + 1] = pv.xy; aw[k * 3 + 2] = pv.xz;
        }
        m.mat(gold, 0.95f, 0.42f).ribbon(ap, aw, new double[] {0.09, 0.15, 0.21}, 3, 3, -0.18);
    }

    /** Kalung lebar wesekh: tiga lapis (emas - batu - emas) menutup bahu & dada atas. */
    static void collar(GodMesh m, Rig r, Body b, int gold, int stone) {
        Frame ch = r.chest;
        double top = b.chestLen + 0.014;
        double nx = b.neckR * 1.18, nz = b.neckR * 1.12;
        double ox = b.shoulderX * 0.99, oz = b.chestRz * 1.16;
        int[] colors = {gold, stone, gold};
        for (int k = 0; k < 3; k++) {
            double u0 = k / 3.0, u1 = (k + 1) / 3.0;
            double[] ys = {top - 0.105 * u0, top - 0.105 * u1};
            double[] rx = {lerp(u0, nx, ox), lerp(u1, nx, ox)};
            double[] rz = {lerp(u0, nz, oz), lerp(u1, nz, oz)};
            double[] cz = {0.004 + 0.005 * u0, 0.004 + 0.005 * u1};
            m.mat(colors[k], 0.96f, k == 1 ? 0.4f : 0.5f).lathe(ch, null, ys, cz, rx, rz, 2, 24, 0, Math.PI * 2, null, true);
        }
        // butir-butir manik di tepi bawah
        double[] edge = new double[18 * 3];
        double[] rad = new double[18];
        for (int i = 0; i < 18; i++) {
            double a = Math.PI * 2.0 * i / 18;
            ch.point(ox * 1.01 * Math.cos(a), top - 0.11, 0.009 + oz * 1.01 * Math.sin(a), edge, i * 3);
            rad[i] = 0.012;
        }
        m.mat(gold, 0.97f, 0.6f).tube(edge, rad, 18, 4, false, 0, 1, 0, 1.0, true);
    }

    /** Gelang emas di lengan atas & pergelangan. */
    static void bands(GodMesh m, Rig r, Body b, int gold) {
        for (int s = -1; s <= 1; s += 2) {
            double[] sh = s > 0 ? r.shL : r.shR, el = s > 0 ? r.elL : r.elR, wr = s > 0 ? r.wrL : r.wrR;
            band(m, r.f3, sh, el, 0.58, 0.068 * b.limb, gold);
            band(m, r.f3, el, wr, 0.8, 0.054 * b.limb, gold);
        }
    }

    private static void band(GodMesh m, Frame f, double[] a, double[] c, double u, double rad, int gold) {
        double[] d = new double[3];
        dir(a, c[0], c[1], c[2], d);
        f.identity().at(lerp(u, a[0], c[0]), lerp(u, a[1], c[1]), lerp(u, a[2], c[2])).aim(d[0], d[1], d[2], 0, 0, 1);
        m.mat(gold, 0.96f, 0.5f);
        loop(m, f, -0.012, rad, rad, 0, 0.011, 12);
        loop(m, f, 0.016, rad * 0.97, rad * 0.97, 0, 0.009, 12);
    }

    /** Tongkat was: batang lurus, kepala hewan Set yang miring di atas, ujung bawah bercabang dua. */
    static void was(GodMesh m, Frame f, double[] lo, double[] hi, int color) {
        double dx = hi[0] - lo[0], dy = hi[1] - lo[1], dz = hi[2] - lo[2];
        double l = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (l < 1.0E-6) {
            return;
        }
        dx /= l; dy /= l; dz /= l;
        m.mat(color, 0.95f, 0.45f).tube(new double[] {lo[0], lo[1], lo[2], hi[0], hi[1], hi[2]}, new double[] {0.014, 0.013}, 2, 6,
                true, Math.abs(dy) > 0.9 ? 1 : 0, Math.abs(dy) > 0.9 ? 0 : 1, 0, 1.0);
        // kepala Set: moncong miring ke depan + dua telinga tegak
        f.identity().at(hi[0], hi[1], hi[2]).aim(dx, dy, dz, 0, 0, 1).rotX(62);
        m.ellipsoid(f, 0, 0.045, 0, 0.019, 0.058, 0.017, 7, 4);
        for (int s = -1; s <= 1; s += 2) {
            double[] e = new double[6];
            f.point(s * 0.008, 0.0, -0.01, e, 0);
            f.point(s * 0.014, -0.02, -0.055, e, 3);
            m.tube(e, new double[] {0.008, 0.0}, 2, 4, true, 1, 0, 0, 1.0);
        }
        // cabang di bawah
        f.identity().at(lo[0], lo[1], lo[2]).aim(-dx, -dy, -dz, 0, 0, 1);
        for (int s = -1; s <= 1; s += 2) {
            double[] e = new double[6];
            f.point(0, 0, 0, e, 0);
            f.point(s * 0.03, 0.05, 0, e, 3);
            m.tube(e, new double[] {0.012, 0.004}, 2, 5, true, 0, 0, 1, 1.0);
        }
    }

    /** Ankh: lingkaran lonjong di atas, palang, dan batang ke bawah. Sumbu Y frame = ke atas (batang -> lingkaran). */
    static void ankh(GodMesh m, Frame f, double s, int color) {
        m.mat(color, 0.97f, 0.7f);
        double[] stem = new double[6];
        f.point(0, 0, 0, stem, 0);
        f.point(0, -0.17 * s, 0, stem, 3);
        m.tube(stem, new double[] {0.013 * s, 0.019 * s}, 2, 6, true, f.zx, f.zy, f.zz, 1.0);
        double[] bar = new double[6];
        f.point(-0.075 * s, 0, 0, bar, 0);
        f.point(0.075 * s, 0, 0, bar, 3);
        m.tube(bar, new double[] {0.014 * s, 0.014 * s}, 2, 6, true, f.zx, f.zy, f.zz, 1.0);
        Frame o = new Frame().set(f).move(0, 0.062 * s, 0).rotX(90);
        loop(m, o, 0, 0.045 * s, 0.062 * s, 0, 0.012 * s, 14);
    }

    /** Rambut palsu tiga bagian: tutup kepala (kecuali dewa berkepala hewan) + dua juntai di depan bahu. */
    static void wig(GodMesh m, Rig r, Body b, int color, double len, boolean cap) {
        if (cap) {
            hairCap(m, r, color, 0.9f, 0.12f, 1.1, 0.5);
        }
        longHair(m, r, color, 0.88f, 0.12f, len, 0.0);
        Frame h = r.head;
        for (int s = -1; s <= 1; s += 2) {
            double[] lp = new double[3 * 3], lw = new double[3 * 3];
            h.point(s * b.headRx * 0.95, r.hc - 0.02, 0.01, lp, 0);
            h.point(s * b.headRx * 1.05, r.hc - 0.14, 0.025, lp, 3);
            r.chest.point(s * 0.13, b.chestLen - 0.07, b.chestRz + 0.03, lp, 6);
            for (int k = 0; k < 3; k++) {
                lw[k * 3] = h.zx; lw[k * 3 + 1] = h.zy; lw[k * 3 + 2] = h.zz;
            }
            m.mat(color, 0.88f, 0.12f).ribbon(lp, lw, new double[] {0.06, 0.075, 0.08}, 3, 3, 0.4);
        }
    }

    /** Janggut dewa: kepang sempit dari dagu, ujungnya melengkung ke depan. */
    static void godBeard(GodMesh m, Rig r, Body b, int color) {
        Frame h = r.head;
        double hc = r.hc;
        double[] p = new double[5 * 3];
        h.point(0, hc - 0.075, b.headRz * 0.74, p, 0);
        h.point(0, hc - 0.125, b.headRz * 0.8, p, 3);
        h.point(0, hc - 0.18, b.headRz * 0.83, p, 6);
        h.point(0, hc - 0.232, b.headRz * 0.9, p, 9);
        h.point(0, hc - 0.248, b.headRz * 1.08, p, 12);
        m.mat(color, 0.92f, 0.22f).tube(p, new double[] {0.022, 0.02, 0.019, 0.016, 0.01}, 5, 7, true, h.xx, h.xy, h.xz, 0.8);
        for (int k = 1; k <= 3; k++) {   // ikatan kepang
            Frame f = r.f3.set(h).at(p[k * 3], p[k * 3 + 1], p[k * 3 + 2]);
            loop(m, f, 0, 0.022, 0.02, 0, 0.005, 8);
        }
    }

    // ================================================================== S - SHU

    private static final int SHU_SKIN = 0xEAF4FF, SHU_LINEN = 0xFAFCFF, SHU_GOLD = 0xFFE6A0, SHU_STONE = 0x8CC8FF;
    private static final int SHU_FEATHER = 0xFFFFFF, SHU_WIG = 0x56688A;

    static void shu(GodMesh m, Pose p) {
        Rig r = RIG;
        Body b = SHU_BODY;
        double t = p.time, c = smooth(p.converge);
        double breath = Math.sin(t * 0.08);
        double spin = p.tau < 12 ? 1.0 - smooth(p.tau / 12.0) : 0.0;   // masih berputar di dalam pusaran
        double hold = smooth((p.tau - 7.0) / 7.0);                       // lengan naik menyangga langit
        double strain = Math.sin(t * 0.21) * 0.008 * hold;               // menahan berat langit
        r.torso(b, 0, 0.005 * breath, 0, 0, 1 + 4 * spin + breath * 0.4, 0, -2 * hold, 0, 0,
                lerp(c, lerp(hold, 8, -18), -10), 0, 0);
        r.legL(0.17, 0.07, 0.1, 0.25, 0.3, 1);
        r.legR(-0.17, 0.07, -0.05, -0.25, 0.3, 1);
        // kedua tangan menyangga langit (telapak ke atas); saat menyatu tangan kanan menunjuk kepalan
        double[] aim = new double[3];
        dir(r.shR, p.aimX, p.aimY, p.aimZ, aim);
        double up = 2.06 + strain;
        r.armL(lerp(hold, 0.36, 0.56), lerp(hold, 1.02, up), lerp(hold, 0.14, 0.06), 1, lerp(hold, -0.6, 0.1), -0.3);
        double rx = lerp(hold, -0.36, -0.56), ry = lerp(hold, 1.02, up), rz = lerp(hold, 0.14, 0.06);
        rx = lerp(c, rx, r.shR[0] + aim[0] * 0.56);
        ry = lerp(c, ry, r.shR[1] + aim[1] * 0.56);
        rz = lerp(c, rz, r.shR[2] + aim[2] * 0.56);
        r.armR(rx, ry, rz, -1, lerp(hold, -0.6, 0.1), -0.3);

        torso(m, r, SHU_SKIN, 0.9f, 0.1f);
        muscles(m, r, SHU_SKIN, 0.9f, 0.1f, 0.85);
        deltoids(m, r, SHU_SKIN, 0.9f, 0.08f, b.limb * 0.88);
        m.mat(SHU_SKIN, 0.9f, 0.08f);
        limbArm(m, r, true, b.limb);
        limbArm(m, r, false, b.limb);
        hand(m, r, true, 1.0, 0, 1, 0, false);
        hand(m, r, false, 1.0, 0, lerp(c, 1, 0), lerp(c, 0, 1), false);
        leg(m, r, true, b.limb, 0.15, 1, 0, true);
        leg(m, r, false, b.limb, -0.12, 1, 0, true);
        head(m, r, SHU_SKIN, 0.9f, 0.08f, true);
        wig(m, r, b, SHU_WIG, 0.17, true);
        Frame h = r.head;
        double hc = r.hc;
        loop(m.mat(SHU_GOLD, 0.95f, 0.5f), r.f1.set(h).move(0, hc + 0.045, -0.004).rotX(-6), 0, b.headRx * 1.13,
                b.headRz * 1.13, 0, 0.009, 16);
        // bulu burung unta tegak di kepala (lambang Shu), ujungnya melengkung jatuh ke belakang
        Frame fe = r.f2.set(h).move(0, hc + 0.1, -0.06).rotX(-10 + Math.sin(t * 0.09) * 3);
        m.mat(SHU_FEATHER, 0.86f, 0.65f).ellipsoid(fe, 0, 0.18, -0.01, 0.05, 0.2, 0.011, 10, 8);
        m.ellipsoid(r.f3.set(fe).move(0, 0.35, -0.02).rotX(-50), 0, 0.045, 0, 0.038, 0.065, 0.009, 8, 5);
        double[] q = new double[6];
        fe.point(0, -0.03, 0.004, q, 0);
        fe.point(0, 0.37, -0.012, q, 3);
        m.mat(SHU_GOLD, 0.95f, 0.5f).tube(q, new double[] {0.008, 0.003}, 2, 5, true, 0, 0, 1, 1.0);
        kilt(m, r, b, SHU_LINEN, SHU_GOLD, t, 0.3, 0.12);
        collar(m, r, b, SHU_GOLD, SHU_STONE);
        bands(m, r, b, SHU_GOLD);

        // langit yang disangga: di antara kedua telapak (digambar GodLook sebagai lengkung bintang)
        m.anchor(GodMesh.EXTRA, m.anchor[GodMesh.HAND_L * 3], m.anchor[GodMesh.HAND_L * 3 + 1], m.anchor[GodMesh.HAND_L * 3 + 2]);
        m.anchor(GodMesh.EXTRA2, m.anchor[GodMesh.HAND_R * 3], m.anchor[GodMesh.HAND_R * 3 + 1], m.anchor[GodMesh.HAND_R * 3 + 2]);
        m.anchor(GodMesh.FOCUS, m.anchor[GodMesh.HAND_R * 3], m.anchor[GodMesh.HAND_R * 3 + 1], m.anchor[GodMesh.HAND_R * 3 + 2]);
        m.anchorDir(GodMesh.FOCUS, aim[0], aim[1], aim[2]);
        m.extraSize = (float) (hold * (1.0 - c));
    }

    // ================================================================== H - HERU

    private static final int HER_SKIN = 0xFFE4C4, HER_FEATHER = 0xF2B868, HER_BEAK = 0xFFE7A0, HER_MARK = 0x5A3A20;
    private static final int HER_RED = 0xFF6E4E, HER_WHITE = 0xFFF6EA, HER_GOLD = 0xFFD070, HER_STONE = 0x6EA0FF;
    private static final int HER_LINEN = 0xFFF2DC, HER_WING = 0xF6C47A;

    static void heru(GodMesh m, Pose p) {
        Rig r = RIG;
        Body b = HERU_BODY;
        double t = p.time, c = smooth(p.converge);
        double breath = Math.sin(t * 0.085);
        boolean diving = p.tau < 10;
        double impact = diving ? 0.0 : Math.max(0.0, 1.0 - (p.tau - 10.0) / 7.0);     // merunduk saat mendarat
        double spread = diving ? 1.0 : 1.0 - 0.45 * smooth((p.tau - 11.0) / 9.0);     // sayap terbentang -> setengah terlipat
        double flap = Math.sin(t * (diving ? 0.9 : 0.12)) * (diving ? 9 : 3);
        double lean = diving ? 38 : 2 + 18 * impact + breath * 0.4;
        r.torso(b, 0, -0.17 * impact, 0, 0, lean, 0, 4 * impact, 0, 0, lerp(c, diving ? -26 : 4 - 6 * impact, -12), 0, 0);
        if (diving) {   // menukik: kaki terlipat ke belakang seperti cakar elang
            r.legL(0.12, 0.42, -0.28, 0.1, -0.2, 1);
            r.legR(-0.12, 0.46, -0.32, -0.1, -0.2, 1);
        } else {
            r.legL(0.17, 0.07, 0.15 + 0.08 * impact, 0.2, 0.3, 1);
            r.legR(-0.17, 0.07, -0.1 - 0.05 * impact, -0.2, 0.3, 1);
        }
        // tangan kanan: tongkat was tegak di samping -> diarahkan ke kepalan saat menyatu
        double[] aim = new double[3];
        dir(r.shR, p.aimX, p.aimY, p.aimZ, aim);
        double hx = diving ? -0.26 : -0.31, hy = diving ? 1.25 : 1.12 - 0.12 * impact, hz = diving ? -0.3 : 0.2;
        hx = lerp(c, hx, r.shR[0] + aim[0] * 0.5);
        hy = lerp(c, hy, r.shR[1] + aim[1] * 0.5);
        hz = lerp(c, hz, r.shR[2] + aim[2] * 0.5);
        r.armR(hx, hy, hz, -0.5, -1, -0.3);
        // tangan kiri: memegang ankh di samping
        r.armL(diving ? 0.26 : 0.3, diving ? 1.25 : 0.98 - 0.1 * impact, diving ? -0.3 : 0.16, 1, -0.5, -0.3);

        torso(m, r, HER_SKIN, 0.9f, 0.1f);
        muscles(m, r, HER_SKIN, 0.9f, 0.1f, 1.05);
        deltoids(m, r, HER_SKIN, 0.9f, 0.08f, b.limb * 0.92);
        m.mat(HER_SKIN, 0.9f, 0.08f);
        limbArm(m, r, true, b.limb);
        limbArm(m, r, false, b.limb);
        hand(m, r, true, 1.05, 0, 0, 1, true);
        hand(m, r, false, 1.05, 0, 0, 1, true);
        leg(m, r, true, b.limb, 0.15, 1, diving ? 50 : 0, true);
        leg(m, r, false, b.limb, -0.12, 1, diving ? 50 : 0, true);
        falconHead(m, r, b, HER_FEATHER, HER_BEAK, HER_MARK);
        pschent(m, r, b, HER_RED, HER_WHITE, HER_GOLD);
        wings(m, r, b, spread, flap, HER_WING);
        kilt(m, r, b, HER_LINEN, HER_GOLD, t, 0.28, 0.08);
        collar(m, r, b, HER_GOLD, HER_STONE);
        bands(m, r, b, HER_GOLD);

        // tongkat was di tangan kanan: tegak (diam) atau searah kepalan (menyatu)
        double[] wr = r.wrR;
        double sdx = lerp(c, 0.02, aim[0]), sdy = lerp(c, 1.0, aim[1]), sdz = lerp(c, 0.03, aim[2]);
        double sl = Math.sqrt(sdx * sdx + sdy * sdy + sdz * sdz);
        sdx /= sl; sdy /= sl; sdz /= sl;
        double down = diving ? 0.7 : 1.08 - 0.12 * impact;
        double[] lo = {wr[0] - sdx * down, wr[1] - sdy * down, wr[2] - sdz * down};
        double[] hi = {wr[0] + sdx * 0.6, wr[1] + sdy * 0.6, wr[2] + sdz * 0.6};
        was(m, r.f3, lo, hi, HER_GOLD);
        m.anchor(GodMesh.FOCUS, hi[0], hi[1] + 0.03, hi[2]);
        m.anchorDir(GodMesh.FOCUS, sdx, sdy, sdz);
        // ankh tergantung di tangan kiri
        Frame af = r.f3.identity().at(r.wrL[0], r.wrL[1] - 0.1, r.wrL[2] + 0.02).aim(0, 1, 0, 0, 0, 1);
        ankh(m, af, 0.85, HER_GOLD);
        m.anchor(GodMesh.EXTRA, af.ox, af.oy + 0.05, af.oz);
        m.extraSize = (float) spread;
    }

    /** Kepala elang: tengkorak berbulu, paruh bengkok, garis mata Wedjat. Mengisi titik kepala & mata. */
    static void falconHead(GodMesh m, Rig r, Body b, int feather, int beak, int mark) {
        Frame h = r.head;
        double hc = r.hc;
        m.mat(feather, 0.9f, 0.14f);
        m.ellipsoid(h, 0, hc + 0.004, -0.006, b.headRx * 1.03, b.headRy * 0.96, b.headRz * 1.06, 12, 9);
        m.ellipsoid(h, 0, hc - 0.052, 0.028, b.headRx * 0.8, b.headRy * 0.52, b.headRz * 0.82, 10, 6);
        // jambul bulu di tengkuk
        m.ellipsoid(h, 0, hc - 0.07, -b.headRz * 0.72, b.headRx * 0.9, 0.08, 0.05, 10, 5);
        double z0 = b.headRz * 0.86;
        double[] bp = new double[5 * 3];
        h.point(0, hc - 0.004, z0, bp, 0);
        h.point(0, hc - 0.012, z0 + 0.048, bp, 3);
        h.point(0, hc - 0.032, z0 + 0.085, bp, 6);
        h.point(0, hc - 0.064, z0 + 0.098, bp, 9);
        h.point(0, hc - 0.09, z0 + 0.082, bp, 12);
        m.mat(beak, 0.95f, 0.35f).tube(bp, new double[] {0.034, 0.028, 0.02, 0.011, 0.0}, 5, 8, true, h.xx, h.xy, h.xz, 0.82);
        m.ellipsoid(h, 0, hc + 0.002, z0 + 0.006, 0.03, 0.022, 0.02, 6, 4);   // pangkal paruh
        for (int s = -1; s <= 1; s += 2) {   // garis mata Wedjat
            double[] mk = new double[3 * 3];
            h.point(s * 0.056, hc + 0.008, z0 * 0.64, mk, 0);
            h.point(s * 0.072, hc - 0.032, z0 * 0.48, mk, 3);
            h.point(s * 0.074, hc - 0.072, z0 * 0.4, mk, 6);
            m.mat(mark, 0.95f, 0.04f).tube(mk, new double[] {0.009, 0.008, 0.004}, 3, 5, true, s, 0, 0, 1.0);
        }
        m.anchor(GodMesh.HEAD, h.px(0, hc, 0), h.py(0, hc, 0), h.pz(0, hc, 0));
        m.anchorDir(GodMesh.HEAD, h.zx, h.zy, h.zz);
        for (int e = 0; e < 2; e++) {
            double s = e == 0 ? 1 : -1;
            int k = e == 0 ? GodMesh.EYE_L : GodMesh.EYE_R;
            m.anchor(k, h.px(s * 0.06, hc + 0.02, z0 * 0.66), h.py(s * 0.06, hc + 0.02, z0 * 0.66),
                    h.pz(s * 0.06, hc + 0.02, z0 * 0.66));
            m.anchorDir(k, h.dx(s * 0.6, 0, 0.8), h.dy(s * 0.6, 0, 0.8), h.dz(s * 0.6, 0, 0.8));
        }
        double[] c = new double[3];
        r.chest.point(0, b.chestLen * 0.6, b.chestRz, c, 0);
        m.anchor(GodMesh.CHEST, c[0], c[1], c[2]);
        // leher
        double[] neck = new double[6];
        r.chest.point(0, b.chestLen - 0.04, -0.005, neck, 0);
        h.point(0, 0.05, 0.0, neck, 3);
        m.mat(feather, 0.9f, 0.14f).tube(neck, new double[] {b.neckR * 1.15, b.neckR * 1.05}, 2, 8, false,
                r.chest.zx, r.chest.zy, r.chest.zz, 1.0);
    }

    /** Mahkota ganda Mesir Hulu & Hilir: merah (deshret, sandaran tinggi & ikal) memeluk putih (hedjet, tinggi berbonggol). */
    static void pschent(GodMesh m, Rig r, Body b, int red, int white, int gold) {
        Frame h = r.head;
        double hc = r.hc;
        double[] ys = {hc + 0.02, hc + 0.11, hc + 0.15};
        double[] rx = {b.headRx * 1.09, b.headRx * 1.07, b.headRx * 1.0};
        double[] rz = {b.headRz * 1.1, b.headRz * 1.07, b.headRz * 1.02};
        double[] cz = {-0.012, -0.014, -0.016};
        m.mat(red, 0.93f, 0.28f).lathe(h, null, ys, cz, rx, rz, 3, 18, 0, Math.PI * 2, null, true);
        m.box(r.f3.set(h).move(0, hc + 0.205, -b.headRz * 0.84), 0, 0, 0, b.headRx * 0.78, 0.075, 0.013);
        // ikal emas yang menjulur ke depan dari mahkota merah
        double[] cu = new double[7 * 3];
        for (int i = 0; i < 7; i++) {
            double u = i / 6.0;
            double y = hc + 0.13 + 0.12 * u, z = b.headRz * 0.6 + 0.07 * Math.sin(u * 2.4);
            if (u > 0.7) {   // ujung melingkar
                double a = (u - 0.7) / 0.3 * Math.PI * 1.4;
                y = hc + 0.13 + 0.084 + 0.03 * Math.sin(a);
                z = b.headRz * 0.6 + 0.07 * Math.sin(1.68) + 0.03 * (1 - Math.cos(a));
            }
            h.point(0.0, y, z, cu, i * 3);
        }
        double[] cr = new double[7];
        java.util.Arrays.fill(cr, 0.0065);
        m.mat(gold, 0.96f, 0.55f).tube(cu, cr, 7, 5, true, 1, 0, 0, 1.0);
        // mahkota putih: tinggi, menyempit, bonggol di puncak
        double[] wy = {hc + 0.12, hc + 0.22, hc + 0.33, hc + 0.4, hc + 0.43};
        double[] wr = {0.078, 0.072, 0.06, 0.046, 0.0};
        double[] wz = {-0.014, -0.016, -0.018, -0.02, -0.02};
        double[] wrz = {0.074, 0.068, 0.056, 0.043, 0.0};
        m.mat(white, 0.93f, 0.32f).lathe(h, null, wy, wz, wr, wrz, 5, 14, 0, Math.PI * 2, null, false);
        m.ellipsoid(h, 0, hc + 0.42, -0.02, 0.036, 0.03, 0.035, 8, 5);
        // uraeus (kobra kecil) di dahi
        double[] ur = new double[4 * 3];
        h.point(0, hc + 0.06, b.headRz * 1.04, ur, 0);
        h.point(0, hc + 0.1, b.headRz * 1.12, ur, 3);
        h.point(0, hc + 0.13, b.headRz * 1.1, ur, 6);
        h.point(0, hc + 0.14, b.headRz * 1.16, ur, 9);
        m.mat(gold, 0.96f, 0.6f).tube(ur, new double[] {0.009, 0.011, 0.011, 0.006}, 4, 5, true, 1, 0, 0, 0.8);
    }

    /** Sayap elang di punggung: bulu terbang panjang + bulu penutup; spread 0 = terlipat, 1 = terbentang. */
    static void wings(GodMesh m, Rig r, Body b, double spread, double flap, int color) {
        Frame w = new Frame();
        for (int s = -1; s <= 1; s += 2) {
            w.set(r.chest).move(s * 0.1, b.chestLen * 0.8, -b.chestRz * 0.9).rotX(-18);
            w.rotZ(-s * (lerp(spread, 158, 62) - flap));
            m.mat(color, 0.86f, 0.32f).featherFan(w, 8, Math.toRadians(lerp(spread, 22, 74)), lerp(spread, 0.62, 0.92), 0.055, 0.008);
            m.mat(GodLook.lighten(color, 0.25), 0.88f, 0.3f).featherFan(w, 6, Math.toRadians(lerp(spread, 18, 62)),
                    lerp(spread, 0.36, 0.5), 0.07, 0.012);
            m.ellipsoid(w, 0, 0.1, 0, 0.07, 0.14, 0.03, 8, 5);   // pangkal sayap
        }
    }

    // ================================================================== A - AMON

    private static final int AMN_SKIN = 0xA6C0FF, AMN_LINEN = 0xEEF2FF, AMN_GOLD = 0xFFD86A, AMN_STONE = 0x4E7CFF;
    private static final int AMN_PLUME = 0xF4F6FF, AMN_CAP = 0x3C58B0, AMN_BEARD = 0x5E74C0;

    static void amon(GodMesh m, Pose p) {
        Rig r = RIG;
        Body b = AMON_BODY;
        double t = p.time, c = smooth(p.converge);
        double breath = Math.sin(t * 0.075);
        r.torso(b, 0, 0, 0, 0, 1 + breath * 0.4, 0, 0, 0, 0, lerp(c, 5, -10), 0, 0);
        // berdiri melangkah ala patung Mesir: kaki kiri di depan
        r.legL(0.12, 0.07, 0.25, 0.1, 0.3, 1);
        r.legR(-0.12, 0.07, -0.06, -0.1, 0.3, 1);
        double[] aim = new double[3];
        dir(r.shR, p.aimX, p.aimY, p.aimZ, aim);
        double hx = lerp(c, -0.3, r.shR[0] + aim[0] * 0.5), hy = lerp(c, 1.2, r.shR[1] + aim[1] * 0.5);
        double hz = lerp(c, 0.28, r.shR[2] + aim[2] * 0.5);
        r.armR(hx, hy, hz, -0.6, -1, -0.2);
        r.armL(0.27, 0.93 + breath * 0.004, 0.08, 1, -0.4, -0.3);

        torso(m, r, AMN_SKIN, 0.9f, 0.12f);
        muscles(m, r, AMN_SKIN, 0.9f, 0.12f, 1.0);
        deltoids(m, r, AMN_SKIN, 0.9f, 0.1f, b.limb * 0.9);
        m.mat(AMN_SKIN, 0.9f, 0.1f);
        limbArm(m, r, true, b.limb);
        limbArm(m, r, false, b.limb);
        hand(m, r, true, 1.08, 0, 0, 1, true);
        hand(m, r, false, 1.08, 0, 0, 1, true);
        leg(m, r, true, b.limb, 0.1, 1, 0, true);
        leg(m, r, false, b.limb, -0.08, 1, 0, true);
        head(m, r, AMN_SKIN, 0.9f, 0.1f, true);
        hairCap(m, r, AMN_CAP, 0.92f, 0.2f, 1.07, 0.4);
        godBeard(m, r, b, AMN_BEARD);
        // mahkota: topi rata (modius) + dua bulu tinggi bergaris emas-biru
        Frame h = r.head;
        double hc = r.hc;
        double[] my = {hc + 0.06, hc + 0.15, hc + 0.155};
        double[] mr = {0.088, 0.094, 0.0};
        double[] mz = {-0.012, -0.012, -0.012};
        m.mat(AMN_GOLD, 0.95f, 0.5f).lathe(h, null, my, mz, mr, mr, 3, 16, 0, Math.PI * 2, null, false);
        double sway = Math.sin(t * 0.06) * 1.5;
        for (int s = -1; s <= 1; s += 2) {
            Frame pf = r.f3.set(h).move(s * 0.034, hc + 0.155, -0.012).rotZ(-s * 2 + sway);
            for (int k = 0; k < 6; k++) {
                double w = 0.034 - k * 0.0018;
                m.mat(k % 2 == 0 ? AMN_PLUME : AMN_STONE, 0.9f, k % 2 == 0 ? 0.55f : 0.4f)
                        .box(pf, 0, 0.032 + k * 0.064, 0, w, 0.031, 0.009);
            }
            m.mat(AMN_PLUME, 0.9f, 0.55f).ellipsoid(pf, 0, 0.384, 0, 0.024, 0.03, 0.009, 8, 4);
            if (s > 0) {
                m.anchor(GodMesh.EXTRA2, pf.px(-0.034, 0.4, 0), pf.py(-0.034, 0.4, 0), pf.pz(-0.034, 0.4, 0));
            }
        }
        // cakram matahari kecil di pangkal bulu (Amon-Ra)
        m.mat(AMN_GOLD, 0.95f, 0.85f).ellipsoid(r.f3.set(h).move(0, hc + 0.2, 0.04), 0, 0, 0, 0.05, 0.05, 0.012, 12, 6);
        kilt(m, r, b, AMN_LINEN, AMN_GOLD, t, 0.32, 0.1);
        collar(m, r, b, AMN_GOLD, AMN_STONE);
        bands(m, r, b, AMN_GOLD);

        // tongkat was di tangan kanan, berpijak di tanah di depan (menyatu: diarahkan ke kepalan)
        double[] wr = r.wrR;
        double sdx = lerp(c, -0.02, aim[0]), sdy = lerp(c, 1.0, aim[1]), sdz = lerp(c, -0.05, aim[2]);
        double sl = Math.sqrt(sdx * sdx + sdy * sdy + sdz * sdz);
        sdx /= sl; sdy /= sl; sdz /= sl;
        double[] lo = {wr[0] - sdx * 1.17, Math.max(0.0, wr[1] - sdy * 1.17), wr[2] - sdz * 1.17};
        double[] hi = {wr[0] + sdx * 0.62, wr[1] + sdy * 0.62, wr[2] + sdz * 0.62};
        was(m, r.f3, lo, hi, AMN_GOLD);
        m.anchor(GodMesh.FOCUS, hi[0], hi[1] + 0.03, hi[2]);
        m.anchorDir(GodMesh.FOCUS, sdx, sdy, sdz);
        Frame af = r.f3.identity().at(r.wrL[0], r.wrL[1] - 0.1, r.wrL[2] + 0.025).aim(0, 1, 0, 0, 0, 1);
        ankh(m, af, 0.9, AMN_GOLD);
        m.anchor(GodMesh.EXTRA, af.ox, af.oy + 0.055, af.oz);
        m.extraSize = 1f;
    }

    // ================================================================== Z - ZEHUTI

    private static final int ZEH_SKIN = 0xD6FFEE, ZEH_FEATHER = 0xF4FFF9, ZEH_BEAK = 0x3A5A52, ZEH_MOON = 0xF6FFFA;
    private static final int ZEH_LINEN = 0xF0FFF8, ZEH_GOLD = 0xFFE6A0, ZEH_STONE = 0x46D8A6, ZEH_WIG = 0x2A5A64;
    private static final int ZEH_PALETTE = 0xE8F0D8;

    static void zehuti(GodMesh m, Pose p) {
        Rig r = RIG;
        Body b = ZEHUTI_BODY;
        double t = p.time, c = smooth(p.converge);
        double breath = Math.sin(t * 0.08);
        double write = Math.sin(t * 0.45) * 0.02 * (1.0 - c);
        r.torso(b, 0, 0, 0, 0, 2 + breath * 0.4, 0, 4 * (1.0 - c), 0, 0, lerp(c, 16, -8), 0, 0);
        r.legL(0.11, 0.07, 0.21, 0.1, 0.3, 1);
        r.legR(-0.11, 0.07, -0.05, -0.1, 0.3, 1);
        double[] aim = new double[3];
        dir(r.shR, p.aimX, p.aimY, p.aimZ, aim);
        // tangan kiri: palet juru tulis di depan dada; tangan kanan: pena buluh menulis (menyatu: menunjuk kepalan)
        r.armL(0.11, 1.24, 0.33, 1, -1, 0);
        double hx = lerp(c, -0.04 + write, r.shR[0] + aim[0] * 0.56), hy = lerp(c, 1.31 + write * 0.5, r.shR[1] + aim[1] * 0.56);
        double hz = lerp(c, 0.36, r.shR[2] + aim[2] * 0.56);
        r.armR(hx, hy, hz, -1, -1, 0);

        torso(m, r, ZEH_SKIN, 0.9f, 0.1f);
        deltoids(m, r, ZEH_SKIN, 0.9f, 0.08f, b.limb * 0.85);
        m.mat(ZEH_SKIN, 0.9f, 0.08f);
        limbArm(m, r, true, b.limb);
        limbArm(m, r, false, b.limb);
        hand(m, r, true, 0.95, 0, 0, 1, false);
        hand(m, r, false, 0.95, 0, 0, 1, true);
        leg(m, r, true, b.limb, 0.1, 1, 0, true);
        leg(m, r, false, b.limb, -0.08, 1, 0, true);
        ibisHead(m, r, b, ZEH_FEATHER, ZEH_BEAK);
        wig(m, r, b, ZEH_WIG, 0.2, false);
        // cakram bulan purnama di atas bulan sabit
        Frame h = r.head;
        Frame mf = r.f3.set(h).move(0, r.hc + 0.25, -0.02);
        m.mat(ZEH_MOON, 0.88f, 0.9f).ellipsoid(mf, 0, 0, 0, 0.1, 0.1, 0.017, 16, 8);
        int n = 11;
        double[] cp = new double[n * 3], cr = new double[n];
        for (int i = 0; i < n; i++) {
            double u = i / (double) (n - 1);
            double a = Math.toRadians(195 + 150 * u);
            mf.point(Math.cos(a) * 0.125, Math.sin(a) * 0.125, 0, cp, i * 3);
            cr[i] = 0.004 + 0.02 * Math.sin(Math.PI * u);
        }
        m.mat(ZEH_GOLD, 0.95f, 0.6f).tube(cp, cr, n, 6, true, 0, 0, 1, 1.0);
        m.anchor(GodMesh.EXTRA, mf.ox, mf.oy, mf.oz);
        kilt(m, r, b, ZEH_LINEN, ZEH_GOLD, t, 0.52, 0.06);
        collar(m, r, b, ZEH_GOLD, ZEH_STONE);
        bands(m, r, b, ZEH_GOLD);

        // palet juru tulis di tangan kiri (dua lekuk tinta) dan pena buluh di tangan kanan
        double[] wl = r.wrL;
        Frame pf = r.f3.identity().at(wl[0] - 0.06, wl[1] + 0.03, wl[2] + 0.04).aim(-0.25, 0.45, 0.86, 0, 1, 0);
        m.mat(ZEH_PALETTE, 0.93f, 0.12f).box(pf, 0, 0, 0, 0.085, 0.018, 0.12);
        m.mat(ZEH_STONE, 0.95f, 0.5f).ellipsoid(pf, -0.03, 0.02, 0.08, 0.015, 0.005, 0.015, 6, 3);
        m.ellipsoid(pf, 0.03, 0.02, 0.08, 0.015, 0.005, 0.015, 6, 3);
        m.anchor(GodMesh.EXTRA2, pf.px(0, 0.03, 0), pf.py(0, 0.03, 0), pf.pz(0, 0.03, 0));
        double[] wr = r.wrR, ed = new double[3];
        dir(r.elR, wr[0], wr[1], wr[2], ed);
        double pdx = lerp(c, ed[0] * 0.4, aim[0]), pdy = lerp(c, -0.6, aim[1]), pdz = lerp(c, 0.8, aim[2]);
        double pl = Math.sqrt(pdx * pdx + pdy * pdy + pdz * pdz);
        pdx /= pl; pdy /= pl; pdz /= pl;
        double[] pen = {wr[0] - pdx * 0.04, wr[1] - pdy * 0.04, wr[2] - pdz * 0.04,
                wr[0] + pdx * 0.2, wr[1] + pdy * 0.2, wr[2] + pdz * 0.2};
        m.mat(ZEH_GOLD, 0.95f, 0.5f).tube(pen, new double[] {0.008, 0.002}, 2, 5, true, 1, 0, 0, 1.0);
        m.anchor(GodMesh.FOCUS, pen[3], pen[4], pen[5]);
        m.anchorDir(GodMesh.FOCUS, pdx, pdy, pdz);
        m.extraSize = 1f;
    }

    /** Kepala ibis: tengkorak kecil, paruh panjang tipis melengkung ke bawah. */
    static void ibisHead(GodMesh m, Rig r, Body b, int feather, int beak) {
        Frame h = r.head;
        double hc = r.hc;
        m.mat(feather, 0.9f, 0.16f);
        m.ellipsoid(h, 0, hc + 0.01, -0.012, b.headRx * 0.9, b.headRy * 0.88, b.headRz * 0.98, 12, 8);
        m.ellipsoid(h, 0, hc - 0.03, 0.02, b.headRx * 0.7, b.headRy * 0.5, b.headRz * 0.72, 10, 5);
        double z0 = b.headRz * 0.78;
        double[] bp = new double[6 * 3];
        h.point(0, hc - 0.012, z0, bp, 0);
        h.point(0, hc - 0.03, z0 + 0.075, bp, 3);
        h.point(0, hc - 0.065, z0 + 0.15, bp, 6);
        h.point(0, hc - 0.115, z0 + 0.21, bp, 9);
        h.point(0, hc - 0.185, z0 + 0.245, bp, 12);
        h.point(0, hc - 0.255, z0 + 0.25, bp, 15);
        m.mat(beak, 0.94f, 0.3f).tube(bp, new double[] {0.033, 0.026, 0.02, 0.015, 0.01, 0.003}, 6, 7, true,
                h.xx, h.xy, h.xz, 0.85);
        m.anchor(GodMesh.HEAD, h.px(0, hc, 0), h.py(0, hc, 0), h.pz(0, hc, 0));
        m.anchorDir(GodMesh.HEAD, h.zx, h.zy, h.zz);
        for (int e = 0; e < 2; e++) {
            double s = e == 0 ? 1 : -1;
            int k = e == 0 ? GodMesh.EYE_L : GodMesh.EYE_R;
            m.anchor(k, h.px(s * 0.052, hc + 0.024, z0 * 0.6), h.py(s * 0.052, hc + 0.024, z0 * 0.6),
                    h.pz(s * 0.052, hc + 0.024, z0 * 0.6));
            m.anchorDir(k, h.dx(s * 0.6, 0, 0.8), h.dy(s * 0.6, 0, 0.8), h.dz(s * 0.6, 0, 0.8));
        }
        double[] c = new double[3];
        r.chest.point(0, b.chestLen * 0.6, b.chestRz, c, 0);
        m.anchor(GodMesh.CHEST, c[0], c[1], c[2]);
        double[] neck = new double[6];
        r.chest.point(0, b.chestLen - 0.04, -0.005, neck, 0);
        h.point(0, 0.05, 0.0, neck, 3);
        m.mat(feather, 0.9f, 0.16f).tube(neck, new double[] {b.neckR * 1.05, b.neckR * 0.9}, 2, 8, false,
                r.chest.zx, r.chest.zy, r.chest.zz, 1.0);
    }

    // ================================================================== A - ATON

    private static final int ATN_SUN = 0xFFD45A, ATN_CORE = 0xFFF2C8, ATN_RIM = 0xFFB838, ATN_RAY = 0xFFE7A0;
    private static final int ATN_HAND = 0xFFF2D6, ATN_ANKH = 0xFFF8E0, ATN_COBRA = 0xFFB050;
    /** Jari-jari cakram & tinggi pusatnya (satuan dasar). */
    static final double ATON_R = 0.5, ATON_Y = 1.62;
    private static final int RAYS = 11;

    static void aton(GodMesh m, Pose p) {
        double t = p.time, c = smooth(p.converge);
        double bob = Math.sin(t * 0.07) * 0.025;
        double grow = smooth((p.tau - 6.0) / 9.0);   // sinar-sinar memanjang sesudah cakram terbit
        Frame d = RIG.f1.identity().at(0, ATON_Y + bob, 0);
        double R = ATON_R;
        // cakram cembung: piringan, inti terang yang menonjol, bingkai emas
        m.mat(ATN_SUN, 0.92f, 0.5f).ellipsoid(d, 0, 0, 0, R, R, 0.075, 26, 10);
        m.mat(ATN_CORE, 0.9f, 0.6f).ellipsoid(d, 0, 0, 0.035, R * 0.66, R * 0.66, 0.07, 22, 8);
        Frame ring = RIG.f2.set(d).rotX(90);
        loop(m.mat(ATN_RIM, 0.96f, 0.7f), ring, 0, R * 1.012, R * 1.012, 0, 0.024, 36);
        loop(m, ring, 0.05, R * 0.7, R * 0.7, 0, 0.012, 28);
        // uraeus: kobra tegak di bawah cakram, menghadap depan
        double[] cb = new double[5 * 3];
        d.point(0, -R * 0.92, 0.07, cb, 0);
        d.point(0, -R * 1.02, 0.13, cb, 3);
        d.point(0, -R * 0.9, 0.17, cb, 6);
        d.point(0, -R * 0.74, 0.17, cb, 9);
        d.point(0, -R * 0.66, 0.2, cb, 12);
        m.mat(ATN_COBRA, 0.95f, 0.6f).tube(cb, new double[] {0.03, 0.034, 0.03, 0.026, 0.02}, 5, 7, true, 1, 0, 0, 0.85);
        Frame hood = RIG.f3.identity().at(cb[9], cb[10], cb[11]).aim(0, 1, 0, 0, 0, 1);
        m.ellipsoid(hood, 0, 0.0, -0.01, 0.07, 0.08, 0.016, 10, 5);
        m.ellipsoid(hood, 0, 0.075, 0.03, 0.026, 0.02, 0.034, 7, 4);
        m.anchor(GodMesh.EYE_L, hood.px(0.014, 0.08, 0.06), hood.py(0.014, 0.08, 0.06), hood.pz(0.014, 0.08, 0.06));
        m.anchor(GodMesh.EYE_R, hood.px(-0.014, 0.08, 0.06), hood.py(-0.014, 0.08, 0.06), hood.pz(-0.014, 0.08, 0.06));
        m.anchorDir(GodMesh.EYE_L, 0, 0, 1);
        m.anchorDir(GodMesh.EYE_R, 0, 0, 1);

        // sinar-sinar berujung tangan; sinar tengah menyodorkan ankh (saat menyatu: ke arah kepalan)
        double[] s = new double[3], e = new double[3], dr = new double[3];
        Frame hf = RIG.f3;
        int mid = RAYS / 2;
        for (int i = 0; i < RAYS; i++) {
            double u = i / (double) (RAYS - 1);
            double th = Math.toRadians(-74 + 148 * u);
            double sx = Math.sin(th), sy = -Math.cos(th);
            s[0] = d.ox + sx * R * 0.97;
            s[1] = d.oy + sy * R * 0.97;
            s[2] = d.oz + 0.02;
            dr[0] = sx;
            dr[1] = sy - 0.05;
            dr[2] = 0.34 + 0.12 * Math.cos(th);
            double len = (0.72 + 0.2 * Math.cos(th * 1.4)) * grow;
            if (i == mid) {
                double ax = p.aimX - s[0], ay = p.aimY - s[1], az = p.aimZ - s[2];
                double al = Math.sqrt(ax * ax + ay * ay + az * az) + 1.0E-9;
                dr[0] = lerp(c, dr[0], ax / al);
                dr[1] = lerp(c, dr[1], ay / al);
                dr[2] = lerp(c, dr[2], az / al);
                len = lerp(c, len, Math.min(1.25, al * 0.55)) + 0.08 * grow;
            }
            double dl = Math.sqrt(dr[0] * dr[0] + dr[1] * dr[1] + dr[2] * dr[2]);
            dr[0] /= dl; dr[1] /= dl; dr[2] /= dl;
            if (len < 0.03) {
                continue;
            }
            e[0] = s[0] + dr[0] * len;
            e[1] = s[1] + dr[1] * len;
            e[2] = s[2] + dr[2] * len;
            double wave = Math.sin(t * 0.13 + i * 0.9) * 0.012 * grow;
            double[] ray = {s[0], s[1], s[2], (s[0] + e[0]) * 0.5 + wave, (s[1] + e[1]) * 0.5, (s[2] + e[2]) * 0.5, e[0], e[1], e[2]};
            m.mat(ATN_RAY, 0.8f, 0.9f).tube(ray, new double[] {0.02, 0.014, 0.011}, 3, 5, false, 0, 0, 1, 1.0);
            // tangan terbuka di ujung sinar (telapak menghadap ke bawah-depan, memberi)
            hf.identity().at(e[0], e[1], e[2]).aim(dr[0], dr[1], dr[2], 0, -0.4, 1);
            m.mat(ATN_HAND, 0.9f, 0.85f).ellipsoid(hf, 0, 0.04, 0, 0.034, 0.05, 0.012, 7, 4);
            for (int f = -1; f <= 2; f++) {   // empat jari
                double fx = f * 0.016 - 0.008;
                double[] fp = new double[6];
                hf.point(fx, 0.08, 0, fp, 0);
                hf.point(fx * 1.15, 0.12 + (f == 0 || f == 1 ? 0.01 : 0.0), 0.004, fp, 3);
                m.tube(fp, new double[] {0.008, 0.005}, 2, 4, true, 0, 0, 1, 1.0);
            }
            double[] th1 = new double[6];
            hf.point(0.03, 0.03, 0.004, th1, 0);
            hf.point(0.055, 0.07, 0.01, th1, 3);
            m.tube(th1, new double[] {0.009, 0.005}, 2, 4, true, 0, 0, 1, 1.0);
            if (i == mid) {
                Frame af = new Frame().set(hf).move(0, 0.14, 0.0);
                af.aim(dr[0], dr[1], dr[2], 0, 0, 1);
                Frame up = new Frame().identity().at(af.ox, af.oy, af.oz).aim(af.yx, af.yy, af.yz, 0, 0, 1);
                ankh(m, up, 1.1, ATN_ANKH);
                m.anchor(GodMesh.FOCUS, up.px(0, 0.06, 0), up.py(0, 0.06, 0), up.pz(0, 0.06, 0));
                m.anchorDir(GodMesh.FOCUS, dr[0], dr[1], dr[2]);
            }
        }
        if (grow < 0.05) {
            m.anchor(GodMesh.FOCUS, d.ox, d.oy, d.oz + 0.1);
            m.anchorDir(GodMesh.FOCUS, 0, 0, 1);
        }
        m.anchor(GodMesh.HEAD, d.ox, d.oy, d.oz);
        m.anchorDir(GodMesh.HEAD, 0, 0, 1);
        m.anchor(GodMesh.CHEST, d.ox, d.oy, d.oz + 0.1);
        m.anchor(GodMesh.EXTRA, d.ox, d.oy, d.oz);
        m.anchorDir(GodMesh.EXTRA, 0, 0, 1);
        m.anchor(GodMesh.EXTRA2, d.ox, d.oy + R, d.oz);
        m.anchor(GodMesh.HAND_L, d.ox + R, d.oy, d.oz);
        m.anchor(GodMesh.HAND_R, d.ox - R, d.oy, d.oz);
        m.extraSize = (float) grow;
    }

    // ================================================================== M - MEHEN

    private static final int MEH_GOLD = 0xFFC860, MEH_RED = 0xE85A40, MEH_BELLY = 0xFFE8B8, MEH_TONGUE = 0xFF4A4A;
    private static final int COIL = 40, NECK = 14;

    static void mehen(GodMesh m, Pose p) {
        double t = p.time, c = smooth(p.converge);
        double rear = outBack(clamp01((p.tau - 3.0) / 9.0));   // leher tegak
        double flare = smooth((p.tau - 8.0) / 6.0);              // tudung mengembang
        double sway = Math.sin(t * 0.09), sway2 = Math.sin(t * 0.13 + 1.1);
        int n = COIL + NECK;
        double[] pts = new double[n * 3], rad = new double[n];
        // gulungan: spiral bertumpuk dari ekor (tengah, di atas) ke luar (di tanah)
        double turns = 2.3, phase = Math.PI * 0.5;
        for (int i = 0; i < COIL; i++) {
            double u = i / (double) (COIL - 1);
            double a = phase - turns * Math.PI * 2.0 * (1.0 - u);
            double rr = 0.1 + 0.64 * u;
            pts[i * 3] = Math.cos(a) * rr;
            pts[i * 3 + 1] = 0.07 + 0.15 * (1.0 - u) * (1.0 - u) + 0.01 * Math.sin(u * 30 + t * 0.2);
            pts[i * 3 + 2] = Math.sin(a) * rr;
            rad[i] = 0.018 + 0.075 * Math.pow(u, 0.7);
        }
        // leher: dari ujung gulungan naik melengkung (S) sampai kepala di depan-atas
        double ex = pts[(COIL - 1) * 3], ey = pts[(COIL - 1) * 3 + 1], ez = pts[(COIL - 1) * 3 + 2];
        double headX = 0.05 * sway, headY = 0.3 + 1.25 * rear + 0.02 * sway2, headZ = 0.3 + 0.04 * sway2;
        double ax = p.aimX, ay = p.aimY, az = p.aimZ;
        double reach = 0.42 * c;   // menyatu: kepala mematuk ke arah kepalan
        headX = lerp(reach, headX, ax);
        headY = lerp(reach, headY, ay);
        headZ = lerp(reach, headZ, az);
        for (int k = 0; k < NECK; k++) {
            double u = (k + 1) / (double) NECK;
            // kurva Bezier kubik: ujung gulungan -> keluar & naik -> lekuk S -> kepala
            double p1x = ex * 1.1, p1y = 0.3 * rear + 0.05, p1z = ez * 1.1 - 0.15;
            double p2x = headX * 0.4 - 0.1 * sway, p2y = headY * 0.95, p2z = headZ - 0.42;
            double v = 1 - u;
            double bx = v * v * v * ex + 3 * v * v * u * p1x + 3 * v * u * u * p2x + u * u * u * headX;
            double by = v * v * v * ey + 3 * v * v * u * p1y + 3 * v * u * u * p2y + u * u * u * headY;
            double bz = v * v * v * ez + 3 * v * v * u * p1z + 3 * v * u * u * p2z + u * u * u * headZ;
            int i = COIL + k;
            pts[i * 3] = bx;
            pts[i * 3 + 1] = by;
            pts[i * 3 + 2] = bz;
            rad[i] = 0.093 - 0.035 * u * u;
        }
        // badan bergelang: potongan berselang emas & merah (ujung tiap potongan saling menyambung)
        int seg = 3;
        for (int a = 0, band = 0; a < n - 1; a += seg - 1, band++) {
            int cnt = Math.min(seg, n - a);
            double[] sp = new double[cnt * 3], sr = new double[cnt];
            System.arraycopy(pts, a * 3, sp, 0, cnt * 3);
            System.arraycopy(rad, a, sr, 0, cnt);
            m.mat(band % 2 == 0 ? MEH_GOLD : MEH_RED, 0.92f, band % 2 == 0 ? 0.42f : 0.3f)
                    .tube(sp, sr, cnt, 10, a == 0, 0, 1, 0, 1.0);
        }
        // kepala kobra: arah dari leher ke kepala, sedikit menunduk
        int last = (n - 1) * 3, prev = (n - 3) * 3;
        double dx = pts[last] - pts[prev], dy = pts[last + 1] - pts[prev + 1], dz = pts[last + 2] - pts[prev + 2];
        double dl = Math.sqrt(dx * dx + dy * dy + dz * dz) + 1.0E-9;
        dx /= dl; dy /= dl; dz /= dl;
        double fx = lerp(0.75, dx, 0.0), fy = lerp(0.75, dy, -0.3), fz = lerp(0.75, dz, 1.0);
        Frame hf = RIG.f1.identity().at(pts[last], pts[last + 1], pts[last + 2]).aim(fx, fy, fz, 0, 1, 0);
        m.mat(MEH_GOLD, 0.94f, 0.45f).ellipsoid(hf, 0, 0.08, 0, 0.082, 0.14, 0.052, 12, 7);
        m.ellipsoid(hf, 0, 0.19, -0.006, 0.052, 0.06, 0.036, 10, 5);   // moncong
        m.mat(MEH_BELLY, 0.94f, 0.4f).ellipsoid(hf, 0, 0.07, -0.028, 0.06, 0.12, 0.03, 10, 5);
        // tudung kobra: lonjong tinggi di leher tepat di bawah kepala, menghadap depan
        int hi = n - 5;
        double hdx = pts[(hi + 1) * 3] - pts[(hi - 1) * 3], hdy = pts[(hi + 1) * 3 + 1] - pts[(hi - 1) * 3 + 1];
        double hdz = pts[(hi + 1) * 3 + 2] - pts[(hi - 1) * 3 + 2];
        Frame hood = RIG.f2.identity().at(pts[hi * 3], pts[hi * 3 + 1], pts[hi * 3 + 2]).aim(hdx, hdy, hdz, 0, 0, 1);
        double hw = 0.09 + 0.12 * flare;
        m.mat(MEH_RED, 0.9f, 0.35f).ellipsoid(hood, 0, 0.05, -0.03, hw, 0.27, 0.028, 14, 7);
        m.mat(MEH_BELLY, 0.92f, 0.55f).ellipsoid(hood, 0, 0.04, -0.004, hw * 0.5, 0.22, 0.02, 12, 6);
        for (int s = -1; s <= 1; s += 2) {   // bercak "mata" di tudung
            m.mat(MEH_GOLD, 0.95f, 0.75f).ellipsoid(hood, s * hw * 0.55, 0.12, 0.0, 0.032 * (0.5 + 0.5 * flare), 0.045, 0.012,
                    8, 4);
        }
        m.anchor(GodMesh.EXTRA, hood.px(0, 0.05, 0.03), hood.py(0, 0.05, 0.03), hood.pz(0, 0.05, 0.03));
        m.anchorDir(GodMesh.EXTRA, hood.zx, hood.zy, hood.zz);
        // lidah bercabang yang menjulur keluar-masuk
        double flick = Math.max(0.0, Math.sin(t * 0.75)) * (0.5 + 0.5 * c);
        if (flick > 0.05) {
            for (int s = -1; s <= 1; s += 2) {
                double[] tg = new double[9];
                hf.point(0, 0.245, -0.02, tg, 0);
                hf.point(0, 0.245 + 0.06 * flick, -0.022, tg, 3);
                hf.point(s * 0.022 * flick, 0.25 + 0.1 * flick, -0.018, tg, 6);
                m.mat(MEH_TONGUE, 0.95f, 0.6f).tube(tg, new double[] {0.006, 0.005, 0.0}, 3, 4, true, 0, 0, 1, 1.0);
            }
        }
        m.anchor(GodMesh.FOCUS, hf.px(0, 0.25, 0), hf.py(0, 0.25, 0), hf.pz(0, 0.25, 0));
        m.anchorDir(GodMesh.FOCUS, fx, fy, fz);
        m.anchor(GodMesh.HEAD, hf.px(0, 0.07, 0), hf.py(0, 0.07, 0), hf.pz(0, 0.07, 0));
        m.anchorDir(GodMesh.HEAD, hf.yx, hf.yy, hf.yz);
        for (int e = 0; e < 2; e++) {
            double s = e == 0 ? 1 : -1;
            int k = e == 0 ? GodMesh.EYE_L : GodMesh.EYE_R;
            m.anchor(k, hf.px(s * 0.058, 0.12, 0.032), hf.py(s * 0.058, 0.12, 0.032), hf.pz(s * 0.058, 0.12, 0.032));
            m.anchorDir(k, hf.dx(s * 0.5, 0.3, 0.8), hf.dy(s * 0.5, 0.3, 0.8), hf.dz(s * 0.5, 0.3, 0.8));
        }
        m.anchor(GodMesh.CHEST, hood.ox, hood.oy, hood.oz);
        m.anchor(GodMesh.EXTRA2, pts[0], pts[1], pts[2]);
        m.anchor(GodMesh.HAND_L, pts[(COIL / 2) * 3], pts[(COIL / 2) * 3 + 1], pts[(COIL / 2) * 3 + 2]);
        m.anchor(GodMesh.HAND_R, pts[(COIL - 1) * 3], pts[(COIL - 1) * 3 + 1], pts[(COIL - 1) * 3 + 2]);
        m.extraSize = (float) flare;
    }
}
