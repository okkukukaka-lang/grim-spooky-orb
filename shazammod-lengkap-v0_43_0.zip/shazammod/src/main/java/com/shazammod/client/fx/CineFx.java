package com.shazammod.client.fx;

import java.util.Random;

import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * Bahasa visual sinematik (0.24) yang dipakai semua skill Shazam, disinkronkan dengan gerak badan (client.anim.Clips) dan
 * avatar dewa (GodAvatars). Tiap serangan disusun seperti adegan film dalam tiga ketukan:
 *
 * 1. Ancang-ancang : energi terhisap ke tangan atau pusaka dewa yang sedang ditarik ke belakang, makin deras, dengan cahaya
 *                    inti yang membesar dan memuncak TEPAT di tick hantaman (bukan sebelum atau sesudahnya).
 * 2. Hantaman      : kilatan inti putih, suar lensa anamorfik (garis cahaya mendatar seperti lensa kamera film), gelombang
 *                    kejut berlapis (muka gelombang putih tipis yang cepat, gelombang berwarna, cincin debu), percikan,
 *                    guncangan kamera menurut jarak, dan untuk pemain sendiri kilatan layar & sentakan pandangan.
 * 3. Sisa          : listrik merayap, bara & asap mengendap, cahaya meredup pelan.
 *
 * Plus berkas cahaya dari langit (god rays) dan tombak petir (petir yang dilempar dari tangan dewa ke sasaran).
 */
public final class CineFx {
    private CineFx() {}

    // ======= Angka yang gampang diutak-atik =======
    /** Kekuatan suar lensa anamorfik (1 = biasa, 0 = mati). */
    public static final float FLARES = 1f;
    /** Kekuatan berkas cahaya dari langit (1 = biasa, 0 = mati). */
    public static final float GOD_RAYS = 1f;
    private static final Vec3 UP = new Vec3(0, 1, 0);

    // ------------------------------------------------------------------ alat bantu adegan

    /** Suar lensa anamorfik di titik (bisa bergerak). length = setengah panjang garis (blok), width = tebal. */
    public static void flareAt(Lightning.Anchor at, int rgb, float length, float width, float strength, int life) {
        if (FLARES > 0f) {
            Vfx.add(new Flare(at, rgb, length, width, strength * FLARES, life));
        }
    }

    public static void flare(Vec3 at, int rgb, float length, float width, float strength, int life) {
        flareAt(Lightning.Anchor.fixed(at), rgb, length, width, strength, life);
    }

    /** Berkas cahaya dari langit yang turun ke titik ini, berputar pelan, muncul lalu memudar. */
    public static void godRays(Lightning.Anchor at, int rgb, double height, double radius, int count, float strength, int life) {
        if (GOD_RAYS > 0f) {
            Vfx.add(new GodRays(at, rgb, height, radius, count, strength * GOD_RAYS, life));
        }
    }

    /** Tombak petir: petir tebal yang melesat dari a ke b dalam grow tick, berkedip, lalu padam. */
    public static void boltSpear(Vec3 a, Vec3 b, int rgb, float width, int grow, int life) {
        Vfx.add(new BoltSpear(a, b, rgb, width, grow, life));
    }

    /**
     * Ancang-ancang: energi terhisap ke titik yang bergerak (tangan, pusaka dewa) mulai delay selama ticks, makin deras,
     * dengan cahaya inti yang memuncak tepat di akhir (saat hantaman). arcs = listrik kecil menari di titik itu.
     */
    public static void gather(Entity owner, int delay, int ticks, Lightning.Anchor at, int rgb, double radius, float rate,
                              boolean arcs) {
        int span = Math.max(1, ticks);
        ShazamFx.schedule(delay, 1, (level, t) -> Vfx.add(new Fx.Glow(owner, at, (float) (radius * 0.5), rgb, span + 3, span)));
        ShazamFx.schedule(delay, span, (level, t) -> {
            float k = (t + 1) / (float) span;
            Vec3 c = at.at(1f);
            for (int i = 0, n = Vfx.count(rate * (0.4f + k)); i < n; i++) {
                Vec3 off = ShazamFx.randomDir(level.random).scale(radius * (0.55 + level.random.nextDouble() * 0.6));
                double pull = 0.2 + 0.12 * k;
                Vfx.mote(c.x + off.x, c.y + off.y, c.z + off.z, -off.x * pull, -off.y * pull, -off.z * pull, rgb,
                        0.06f + 0.04f * k, 5);
            }
            if (arcs && t % 2 == 0) {
                Vec3 off = ShazamFx.randomDir(level.random).scale(radius * (0.45 + 0.4 * k));
                Vfx.add(new Lightning.Arc(at, pt -> at.at(pt).add(off), rgb, 0.035f + 0.03f * k, 2, 1, 0, 0.3));
            }
        });
    }

    /**
     * Hantaman sinematik di titik ini: kilatan inti putih, suar anamorfik, gelombang udara berlapis, gelombang kejut di tanah
     * (kalau ground dan tanahnya dekat), percikan, guncangan kamera menurut jarak, dan (self) kilatan layar & sentakan
     * pandangan. power ±0,5 (kecil) sampai 3 (besar).
     */
    public static void impact(ClientLevel level, Vec3 at, float power, int rgb, int hot, boolean self, boolean ground) {
        Vfx.add(new Fx.Flash(at, 0.9f + power * 0.9f, 0xFFFFFF, 6, 1f));
        Vfx.add(new Fx.Flash(at, 1.4f + power * 1.3f, rgb, 10, 0.8f));
        flare(at, hot, 2.5f + power * 2.5f, 0.1f + power * 0.06f, 1f, 9);
        Vfx.add(new Fx.Bubble(at, 0.8 + power * 1.1, 0xFFFFFF, 6, 0.55f, 1.0, 3.0, true));
        Vfx.add(new Fx.Bubble(at, 1.2 + power * 1.6, rgb, 11, 0.7f, 1.0, 2.0, true));
        if (ground) {
            Ground.Map map = ShazamFx.ground(level, at, 2.0 + power * 2.5);
            if (map != null && map.found && at.y - map.centerY < 2.5) {
                Vec3 g = map.center(at);
                Vfx.add(new Fx.Wave(g, UP, 2.2 + power * 2.6, 0.18, 0xFFFFFF, 7, 0.95f, 0f, map));
                Vfx.add(new Fx.Wave(g, UP, 1.8 + power * 2.2, 0.3 + power * 0.1, rgb, 13, 0.85f, 0.08f, map));
                Vfx.add(new Fx.Wave(g, UP, 1.6 + power * 2.0, 0.8 + power * 0.3, map.dustColor(level, at), 26, 0.55f, 0f, map,
                        true));
            }
        }
        ShazamFx.ringOfSparks(level, at, (int) (14 + power * 12), hot, 0.3 + power * 0.1);
        ShazamFx.shakeAround(at, 0.25f + power * 0.25f, 16 + power * 8);
        if (self) {
            ScreenFlash.flash(0.12f + power * 0.08f, Draw.mix(rgb, 0xFFFFFF, 0.6));
            FovKick.punch(-0.03f - power * 0.02f);
        }
    }

    // ------------------------------------------------------------------ efek

    /**
     * Suar lensa anamorfik: garis cahaya mendatar (di layar) yang menyilang titik paling terang, seperti lensa kamera film,
     * dengan inti putih dan pendar bulat. Ukurannya ikut jarak sedikit, supaya tetap terasa dari jauh.
     */
    static final class Flare extends Effect {
        private final Lightning.Anchor at;
        private final int rgb;
        private final float length, width, strength;

        Flare(Lightning.Anchor at, int rgb, float length, float width, float strength, int life) {
            super(life);
            this.at = at;
            this.rgb = rgb;
            this.length = length;
            this.width = width;
            this.strength = strength;
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float p = progress(pt);
            float a = strength * (1f - p) * (1f - p);
            if (a <= 0.01f) {
                return;
            }
            Vec3 c = at.at(pt);
            double vx = c.x - d.camX, vz = c.z - d.camZ;
            double hl = Math.sqrt(vx * vx + vz * vz);
            double rx = hl < 1.0E-4 ? 1.0 : -vz / hl, rz = hl < 1.0E-4 ? 0.0 : vx / hl;   // kanan layar, mendatar
            double dist = d.distance(c.x, c.y, c.z);
            double len = length * (0.55 + 0.45 * (1f - p)) * Math.max(1.0, dist / 14.0);
            float w = (float) (width * Math.max(1.0, dist / 14.0));
            a *= d.nearFade(c.x, c.y, c.z, 0.9, 2.6);
            if (a <= 0.01f) {
                return;
            }
            float old = d.body(0f);   // murni cahaya
            for (int s = -1; s <= 1; s += 2) {
                double ex = c.x + rx * len * s, ez = c.z + rz * len * s;
                d.line(c.x, c.y, c.z, ex, c.y, ez, w, w * 0.4f, rgb, a, 0f);
                d.line(c.x, c.y, c.z, c.x + rx * len * 0.5 * s, c.y, c.z + rz * len * 0.5 * s, w * 0.35f, w * 0.15f, 0xFFFFFF,
                        a * 0.9f, 0f);
            }
            d.flare(c.x, c.y, c.z, w * 4.5f, rgb, a);
            d.body(old);
        }
    }

    /** Berkas cahaya dari langit: beberapa pancaran lembut yang menyempit ke titik di tanah dan berputar pelan. */
    static final class GodRays extends Effect {
        private final Lightning.Anchor at;
        private final int rgb;
        private final double height, radius;
        private final int count;
        private final float strength;

        GodRays(Lightning.Anchor at, int rgb, double height, double radius, int count, float strength, int life) {
            super(life);
            this.at = at;
            this.rgb = rgb;
            this.height = height;
            this.radius = radius;
            this.count = Math.max(1, count);
            this.strength = strength;
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float time = time(pt);
            float p = progress(pt);
            float a = strength * Math.min(1f, time / 6f) * (1f - p * p);
            if (a <= 0.01f) {
                return;
            }
            Vec3 c = at.at(pt);
            int core = Draw.mix(rgb, 0xFFFFFF, 0.6);
            float old = d.body(0.15f);   // hampir murni cahaya: tetap lembut di siang hari
            for (int k = 0; k < count; k++) {
                double angle = k * Math.PI * 2.0 / count + time * 0.012 + (k % 2) * 0.3;
                double spread = radius * (0.55 + 0.45 * Math.sin(k * 2.1 + 0.4));
                double tx = c.x + Math.cos(angle) * spread * 1.8, tz = c.z + Math.sin(angle) * spread * 1.8;
                double bx = c.x + Math.cos(angle) * spread * 0.35, bz = c.z + Math.sin(angle) * spread * 0.35;
                float flick = 0.75f + 0.25f * (float) Math.sin(time * 0.3f + k * 1.7f);
                float near = d.nearFade(bx, c.y + 1.0, bz, 1.0, 3.0);
                d.beam(tx, c.y + height, tz, bx, c.y, bz, (float) (radius * 0.55), rgb, core, 0.05f * a * flick * near,
                        0.3f * a * flick * near);
            }
            d.glow(c.x, c.y + 0.3, c.z, (float) (radius * 1.6), rgb, 0.3f * a);
            d.body(old);
        }
    }

    /** Tombak petir: petir tebal yang tumbuh dari a ke b, berganti bentuk tiap 2 tick, dengan kepala yang menyala. */
    static final class BoltSpear extends Effect {
        private final Vec3 a, b;
        private final int rgb;
        private final float width;
        private final int grow;
        private final long seed = Vfx.random().nextLong();

        BoltSpear(Vec3 a, Vec3 b, int rgb, float width, int grow, int life) {
            super(life);
            this.a = a;
            this.b = b;
            this.rgb = rgb;
            this.width = width;
            this.grow = Math.max(1, grow);
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float shown = Math.min(1f, time(pt) / grow);
            float p = progress(pt);
            float alpha = (float) Math.pow(1f - p, 1.2) * (age % 3 == 1 ? 0.75f : 1f);
            if (alpha <= 0.01f || a.distanceToSqr(b) < 0.04) {
                return;
            }
            Vec3 e = a.lerp(b, shown);
            Random random = new Random(seed + age / 2);
            for (int k = 0; k < 2; k++) {
                float[] path = Lightning.path(a.x, a.y, a.z, e.x, e.y, e.z, 5, k == 0 ? 0.07 : 0.11, random);
                int n = path.length / 3;
                d.polyline(path, n, width * (k == 0 ? 1f : 0.45f), width * (k == 0 ? 0.75f : 0.3f), rgb, 0xFFFFFF, alpha, alpha);
                if (k == 0) {
                    float old = d.body(0.3f);
                    d.strip(path, n, width * 3.2f, width * 2.4f, rgb, alpha * 0.2f, alpha * 0.18f);
                    d.body(old);
                }
            }
            d.flare(e.x, e.y, e.z, width * 5f, rgb, alpha);
        }
    }
}
