package com.shazammod.client.fx;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Hd;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * 0.35 Lapisan VFX HD Lintang (di atas LintangFx & LintangCine), FISIK semua, ala Superman: gelombang tekanan udara
 * yang bening & membiaskan pandangan, ledakan debu bervolume dari tanah yang dihantam, riak udara panas, uap kondensasi,
 * dan es yang merambat dari napas beku. Tanpa korona, plasma, tombak cahaya, perisai cahaya, bayangan bercahaya, atau
 * hujan foton. Dipanggil dari LintangCine (penguat Lintang sudah terpasang, jadi semua efek di sini digambar HD).
 */
public final class LintangHd {
    private LintangHd() {}

    static final int AIR = 0xEAF4FF;          // udara terkompresi / uap kondensasi
    static final int VAPOR = 0xF2F6FA;
    static final int FROST = 0xD6F4FF;
    static final int ICE = 0x8FDCFF;
    static final int HAZE = 0xFFF4E0;         // riak udara panas
    static final int DUST = 0xC8B696;         // debu kalau warna tanah nggak terbaca
    static final Vec3 UP = HdKit.UP;
    static final Vec3 DOWN = new Vec3(0, -1, 0);

    /** Mode Surya: riak panas yang sedang tampil per pemain (sampai game time ini). */
    private static final Map<Integer, Long> RAGE = new HashMap<>();

    public static void clear() {
        RAGE.clear();
    }

    private static boolean alive(AbstractClientPlayer p) {
        return p.isAlive() && !p.isRemoved();
    }

    private static void later(AbstractClientPlayer p, int delay, Runnable r) {
        if (delay <= 0) {
            r.run();
            return;
        }
        ShazamFx.schedule(delay, 1, (lvl, t) -> {
            if (alive(p)) {
                r.run();
            }
        });
    }

    private static Vec3 look(AbstractClientPlayer p) {
        return p.getViewVector(1f);
    }

    private static Vec3 mouth(AbstractClientPlayer p) {
        Vec3 e = p.getEyePosition(1f), l = look(p);
        return new Vec3(e.x + l.x * 0.3, e.y - 0.16 + l.y * 0.2, e.z + l.z * 0.3);
    }

    // ------------------------------------------------------------------ alat bantu fisik

    /**
     * Gelombang tekanan udara: bola (cap = PI) atau kubah searah. Mode uap (Hd.Pressure.vapor): selaput uap tipis
     * tembus pandang + pita pembiasan di lapisan soft, jadi terlihat seperti udara yang beriak, bukan kubah cahaya.
     */
    private static void air(Vec3 at, Vec3 axis, double radius, double cap, int life, float strength) {
        Vfx.add(new Hd.Pressure(at, axis, radius, cap, AIR, life, strength, true).vapor());
    }

    /**
     * Ledakan debu bervolume di tanah di bawah at (warna diambil dari bloknya). Nggak muncul kalau tanahnya jauh di
     * bawah (misalnya saat melayang tinggi).
     */
    private static void dust(ClientLevel level, AbstractClientPlayer viewer, Vec3 at, double radius, int life, float strength) {
        Vec3 g = HdKit.groundAt(level, viewer, at);
        if (g == at || at.y - g.y > 3.5) {
            return;
        }
        Ground.Map map = ShazamFx.ground(level, g, 2.0);
        int col = map != null && map.found ? map.dustColor(level, g) : DUST;
        Vfx.add(new Hd.DustBurst(g, radius, col, life, strength, true));
    }

    /** Semburan debu/uap searah (tembus pandang biasa, bukan cahaya). */
    private static void dustJet(Vec3 from, Vec3 dir, double base, double speed, double spread, int rgb, float size, int life) {
        RandomSource r = Vfx.random();
        for (int i = 0, n = HdKit.n(base); i < n; i++) {
            Vec3 d = HdKit.jitter(r, dir, spread);
            double s = speed * (0.6 + r.nextDouble() * 0.7);
            Vfx.dust(from.x, from.y, from.z, d.x * s, d.y * s, d.z * s, rgb, size * (0.7f + r.nextFloat() * 0.6f), life + r.nextInt(6));
        }
    }

    /** Riak udara panas di sekeliling badan selama ticks. */
    private static void heatHaze(AbstractClientPlayer p, double radius, double height, int strands, int ticks, float strength) {
        Vfx.add(new Hd.Haze(HdKit.feetAnchor(p), radius, height, strands, HAZE, ticks, strength));
    }

    // ------------------------------------------------------------------ titik masuk

    public static void onAnim(AbstractClientPlayer p, ShazamAnim a, Vec3 pos) {
        try {
            onAnim0(p, a, pos);
        } catch (Throwable ignored) {
            // lapisan HD nggak boleh bikin game crash
        }
    }

    private static void onAnim0(AbstractClientPlayer p, ShazamAnim a, Vec3 pos) {
        ClientLevel level = HdKit.level(p);
        boolean fp = HdKit.firstPerson(p);
        float near = fp ? 0.35f : 1f;   // orang pertama: efek di badan sendiri ditipiskan supaya layar nggak tertutup
        switch (a) {
            case TRANSFORM -> later(p, ShazamAnim.LINTANG_SUITUP, () -> {   // udara yang terdorong putaran meledak keluar
                Vec3 c = HdKit.chest(p);
                air(c, UP, 7.5, Math.PI, 16, 0.7f * near);
                dust(level, p, HdKit.feet(p), 2.6, 30, 0.9f);
            });
            case REVERT -> later(p, ShazamAnim.REVERT_WINDUP, () -> air(HdKit.chest(p), UP, 2.6, Math.PI, 10, 0.4f * near));
            case KNOCKOUT -> later(p, ShazamAnim.KNOCKOUT_BURST, () -> {
                air(HdKit.chest(p), UP, 3.0, Math.PI, 10, 0.5f * near);
                dust(level, p, HdKit.feet(p), 1.8, 24, 0.8f);
            });
            case LAUNCH -> {
                Vec3 f = HdKit.feet(p);
                air(f, DOWN, 3.6, 1.15, 12, 0.6f);
                dust(level, p, f, 1.6, 22, 0.7f);
            }
            case LAND_HERO, CRASH -> {
                boolean big = a == ShazamAnim.CRASH;
                Vec3 f = HdKit.groundAt(level, p, HdKit.feet(p));
                dust(level, p, f, big ? 3.2 : 1.9, big ? 40 : 26, 0.9f);
                air(f, UP, big ? 8.0 : 4.8, 1.45, 14, 0.5f);
            }
            case SONIC_BOOM -> {
                Vec3 c = HdKit.chest(p), l = look(p);
                air(c.add(l.scale(0.4)), l.scale(-1), 3.6, 1.05, 14, 0.75f * near);
                air(c, l, 2.4, 0.9, 8, 0.5f * near);
                dustJet(c, l.scale(-1), 12, 0.7, 0.35, VAPOR, 0.3f, 10);   // uap kondensasi
            }
            case LINTANG_DASH -> dash(level, p, pos, near);
            case LINTANG_EYES -> Vfx.add(new Hd.Haze(pt -> {   // udara di depan mata memanas (0.39: ikut mata yang digambar)
                if (p.isRemoved()) {
                    return null;
                }
                Vec3[] e = LintangHeat.eyes(p, pt);
                return e[0].add(e[1]).scale(0.5).add(0, 0.05, 0);
            }, 0.35, 0.8, 4, 0xFFE8D0, ShazamAnim.IRIS_WINDUP + ShazamAnim.IRIS_TICKS, 0.8f));
            case LINTANG_BREATH -> breath(level, p, near);
            case LINTANG_CLAP -> clap(p, near);
            case LINTANG_BARRAGE -> barrage(p, pos);
            case LINTANG_HIT -> {
                if (pos != null) {
                    air(pos, HdKit.norm(pos.subtract(HdKit.chest(p))), 1.0, 1.0, 6, 0.45f);
                }
            }
            case LINTANG_LEAP -> later(p, ShazamAnim.LEAP_WINDUP, () -> {
                Vec3 f = HdKit.feet(p);
                air(f, DOWN, 4.0, 1.2, 12, 0.6f);
                dust(level, p, f, 1.8, 26, 0.8f);
            });
            case LINTANG_SLAM -> slam(level, p, pos != null ? pos : HdKit.feet(p));
            case LINTANG_FLARE -> flare(level, p, near);
            case LINTANG_CALL -> call(p, near);
            case LINTANG_RESCUE -> later(p, ShazamAnim.RESCUE_WINDUP, () -> air(HdKit.chest(p), UP, 2.4, Math.PI, 10, 0.45f * near));
            case LINTANG_SAVE -> save(level, p, pos);
            case LINTANG_LANCE -> {   // sinar panas singkat: udara di titik yang terbakar beriak
                if (pos != null) {
                    Vfx.add(new Hd.Haze(Lightning.Anchor.fixed(pos.subtract(0, 0.4, 0)), 0.3, 1.0, 3, HAZE, 26, 0.7f));
                }
            }
            case LINTANG_DAWNPUNCH -> {   // Tinju Baja: gelombang tekanan searah pukulan + debu di bawah sasaran
                if (pos != null) {
                    Vec3 dir = HdKit.norm(pos.subtract(HdKit.chest(p)));
                    air(pos, dir, 6.5, 1.1, 14, 0.75f);
                    dust(level, p, pos, 2.2, 30, 0.9f);
                    dustJet(pos, dir, 10, 0.6, 0.5, VAPOR, 0.35f, 12);
                }
            }
            case LINTANG_PARRY -> {
                if (pos != null) {
                    air(pos, UP, 1.0, Math.PI, 6, 0.45f);
                }
            }
            case LINTANG_BOUNCE, LINTANG_PUNCH -> {
                if (pos != null) {
                    air(pos, UP, a == ShazamAnim.LINTANG_PUNCH ? 0.8 : 0.7, Math.PI, 5, 0.35f);
                }
            }
            case LINTANG_RITE -> rite(level, p);
            case LINTANG_GUST -> later(p, ShazamAnim.FROST_WINDUP, () -> {   // 0.37 Napas Topan: kubah udara terdorong ke depan
                Vec3 m = mouth(p), l = look(p);
                air(m.add(l.scale(0.5)), l, 6.0, 0.55, 12, 0.4f * near);
            });
            case LINTANG_COMBO -> later(p, ShazamAnim.COMBO_UPPERCUT, () -> {   // 0.37 Kombo Langit: uppercut
                if (pos != null) {
                    air(pos.add(0, 1.0, 0), UP, 3.2, 0.9, 10, 0.6f);
                }
            });
            case LINTANG_COMBO_SMASH -> air(HdKit.chest(p), DOWN, 4.0, 0.9, 10, 0.65f * near);
            case LINTANG_NOVA -> nova(level, p, near);                          // 0.37 Ledakan Surya
            case HERCULES_THROW -> later(p, ShazamAnim.THROW_RELEASE, () -> {   // 0.36 Angkat & Lempar: udara terdorong lemparan
                Vec3 l = look(p);
                air(HdKit.chest(p).add(l.scale(0.6)), l, 4.0, 0.95, 10, 0.6f * near);
            });
            case HERCULES_IMPACT -> {   // musuh yang dilempar menghantam tanah
                if (pos != null) {
                    dust(level, p, pos, 2.4, 32, 0.9f);
                    air(pos, UP, 6.0, 1.4, 16, 0.7f);
                }
            }
            default -> {
                // SUMMON (nggak dipakai Lintang lagi), PULSE (Regenerasi Surya nggak terlihat), FADE, RETURN, KELAM,
                // HERO_CALL: cukup efek di LintangFx/LintangCine
            }
        }
    }

    // ------------------------------------------------------------------ skill

    /** Lesatan Bintang: kubah udara di belakang, jejak uap & debu sepanjang jalur, hentakan udara di ujung. */
    private static void dash(ClientLevel level, AbstractClientPlayer p, Vec3 pos, float near) {
        later(p, ShazamAnim.LESAT_WINDUP, () -> {
            Vec3 l = look(p);
            Vec3 start = HdKit.chest(p);
            Vec3 end = pos != null ? pos.add(0, p.getBbHeight() * 0.68, 0) : start.add(l.scale(16));
            Vec3 dir = HdKit.norm(end.subtract(start));
            air(start, dir.scale(-1), 3.2, 1.0, 12, 0.65f * near);
            RandomSource r = level.random;
            double len = end.distanceTo(start);
            for (int i = 0, n = HdKit.n(6 + len * 0.8); i < n; i++) {   // uap tipis yang tertinggal di sepanjang jalur
                double v = r.nextDouble();
                Vec3 q = start.add(end.subtract(start).scale(v)).add(ShazamFx.randomDir(r).scale(0.35 + r.nextDouble() * 0.4));
                Vfx.smoke(q.x, q.y, q.z, dir.x * 0.06, dir.y * 0.06, dir.z * 0.06, VAPOR, 0.26f + r.nextFloat() * 0.18f, 10 + r.nextInt(6));
            }
            later(p, ShazamAnim.LESAT_TICKS, () -> {
                air(end, UP, 3.6, Math.PI, 12, 0.55f);
                dust(level, p, end.subtract(0, p.getBbHeight() * 0.68, 0), 1.4, 22, 0.75f);
            });
        });
    }

    /** Napas Salju: embun beku menyembur & es merambat di tempat yang kena (tanpa gores cahaya). */
    private static void breath(ClientLevel level, AbstractClientPlayer p, float near) {
        later(p, ShazamAnim.FROST_WINDUP, () -> {
            int[] decals = {0};
            ShazamFx.schedule(0, ShazamAnim.FROST_TICKS, (lvl, t) -> {
                if (!alive(p)) {
                    return;
                }
                Vec3 m = mouth(p), l = look(p);
                HdKit.shardJet(m.add(l.scale(0.35)), l, 2.0, 0.55, 0.24, ICE, 0.07f, 16);
                if (t % 2 == 0) {
                    dustJet(m.add(l.scale(0.35)), l, 1.5, 0.6, 0.2, 0xF4FBFF, 0.3f, 12);
                }
                if (t % 9 == 4 && decals[0] < 4) {   // es merambat di tempat hembusan menyentuh
                    Vec3 end = HdKit.rayEnd(lvl, p, m, l, 12.0);
                    if (end.distanceTo(m) < 11.5) {
                        Ground.Map g = ShazamFx.ground(lvl, end, 3.0);
                        if (g != null && g.found && Math.abs(g.centerY - end.y) < 1.5) {
                            Vfx.add(new Hd.Frost(g.center(end), 2.2 + decals[0] * 0.3, ICE, 10, 140, 0.9f, g));
                            HdKit.shards(end, 6, 0.25, ICE, 0.06f, 14, g.centerY);
                            decals[0]++;
                        }
                    }
                }
            });
        });
    }

    /** Tepukan Guruh: kubah tekanan udara meledak ke depan, uap & debu tersapu. */
    private static void clap(AbstractClientPlayer p, float near) {
        later(p, ShazamAnim.SONIC_WINDUP, () -> {
            Vec3 l = look(p);
            Vec3 h = HdKit.chest(p).add(l.scale(0.7));
            air(h, l, 11.0, 1.05, 16, 0.85f);
            air(h, l, 6.5, 0.85, 11, 0.6f);
            dustJet(h, l, 16, 0.9, 0.5, VAPOR, 0.4f, 12);
        });
    }

    /** Amukan Kilat: tiap pukulan memampatkan udara, pukulan penutup melempar sasaran dengan kubah tekanan. */
    private static void barrage(AbstractClientPlayer p, Vec3 pos) {
        later(p, ShazamAnim.BARRAGE_WINDUP, () -> ShazamFx.schedule(0, ShazamAnim.BARRAGE_TICKS, (lvl, t) -> {
            if (!alive(p)) {
                return;
            }
            Vec3 c = HdKit.chest(p), l = look(p);
            Vec3 target = pos != null ? pos.add(0, 0.9, 0) : c.add(l.scale(1.4));
            RandomSource r = lvl.random;
            if (t % 2 == 0 && t < ShazamAnim.BARRAGE_TICKS - 3) {
                Vec3 hit = target.add((r.nextDouble() - 0.5) * 0.7, (r.nextDouble() - 0.5) * 0.6, (r.nextDouble() - 0.5) * 0.7);
                air(hit, HdKit.norm(hit.subtract(c)), 1.2, 1.0, 6, 0.5f);
            }
            if (t == ShazamAnim.BARRAGE_TICKS - 2) {   // pukulan penutup
                Vec3 dir = HdKit.norm(target.subtract(c));
                air(target, dir, 4.5, 1.0, 12, 0.7f);
                dustJet(target, dir, 10, 0.7, 0.45, VAPOR, 0.35f, 10);
            }
        }));
    }

    /** Napak Langit: tanah dihantam, ledakan debu besar & kubah tekanan. */
    private static void slam(ClientLevel level, AbstractClientPlayer p, Vec3 pos) {
        Vec3 at = HdKit.groundAt(level, p, pos);
        dust(level, p, at, 4.0, 44, 1f);
        air(at, UP, 11.0, 1.4, 22, 0.7f);
    }

    /**
     * Gelegar Surya: panas yang tersimpan di sel tubuh dilepas sekaligus. Ancang-ancang: udara di sekitar badan memanas
     * (riak panas). Ledakan: bola ledakan panas yang cepat mendingin jadi asap (seperti ledakan sungguhan, bukan bola
     * cahaya), kubah tekanan raksasa, debu dari tanah, lalu riak panas yang lama.
     */
    private static void flare(ClientLevel level, AbstractClientPlayer p, float near) {
        int w = ShazamAnim.FLARE_WINDUP;
        heatHaze(p, 0.9, 2.4, 7, w + 4, 0.9f);
        later(p, w, () -> {
            Vec3 c = HdKit.chest(p), f = HdKit.feet(p);
            // ledakan panas sungguhan: inti panas sebentar, cepat mendingin jadi asap gelap
            Vfx.add(new Hd.Nova(c, 3.8, 0xFFE2B8, 0xFF9A50, 0x6A4A3A, 0x4A4038, 18, 0.55f * near, false));
            air(c, UP, 16.0, Math.PI, 26, 0.8f);
            dust(level, p, f, 5.0, 50, 1f);
            heatHaze(p, 4.0, 4.0, 12, 120, 1f);
        });
    }

    /** Serap Surya: tubuh menyerap sinar matahari (riak panas naik dari badan), lalu panas berlebihnya dilepas. */
    private static void call(AbstractClientPlayer p, float near) {
        int w = ShazamAnim.SUNCALL_WINDUP;
        heatHaze(p, 0.8, 2.6, 7, w + 30, 0.9f);
        later(p, w, () -> air(HdKit.chest(p), UP, 6.0, Math.PI, 14, 0.5f));
    }

    /** Satu sekutu diselamatkan: Lintang tiba secepat kilat, debu berputar di kaki & udara terdorong. */
    private static void save(ClientLevel level, AbstractClientPlayer p, Vec3 pos) {
        if (pos == null) {
            return;
        }
        LivingEntity ally = null;
        double best = 4.0;
        List<LivingEntity> near = level.getEntitiesOfClass(LivingEntity.class, new AABB(pos, pos).inflate(1.6), e -> e != p && e.isAlive());
        for (LivingEntity e : near) {
            double d = e.position().distanceToSqr(pos);
            if (d < best) {
                best = d;
                ally = e;
            }
        }
        double radius = ally != null ? Math.max(0.8, Math.max(ally.getBbWidth(), ally.getBbHeight()) * 0.75) : 1.2;
        air(pos.add(0, 0.9, 0), UP, radius * 1.8, Math.PI, 10, 0.4f);
        dust(level, p, pos, 1.3, 20, 0.7f);
    }

    /**
     * Eksperimen Evolusi Surya (wujud manusia): selama tubuh menyerap sinar matahari, udara di sekelilingnya memanas &
     * beriak; di tick 104 tenaga sel yang baru meledak keluar sebagai tekanan udara & debu.
     */
    private static void rite(ClientLevel level, AbstractClientPlayer p) {
        Supplier<Boolean> running = () -> LintangCine.experimentAge(p, 0f) >= 0f && alive(p);
        ShazamFx.schedule(14, 1, (lvl, t) -> {
            if (running.get()) {
                heatHaze(p, 1.1, 2.4, 6, 90, 0.9f);
            }
        });
        ShazamFx.schedule(104, 1, (lvl, t) -> {
            if (!running.get()) {
                return;
            }
            Vec3 c = HdKit.chest(p), f = HdKit.feet(p);
            air(c, UP, 12.0, Math.PI, 22, 0.75f);
            dust(lvl, p, f, 3.4, 40, 1f);
        });
    }

    /** 0.37 Ledakan Surya: udara memanas makin hebat selama 3 detik, lalu bola ledakan panas, kubah tekanan raksasa, debu. */
    private static void nova(ClientLevel level, AbstractClientPlayer p, float near) {
        int w = ShazamAnim.SOLAR_NOVA_WINDUP;
        heatHaze(p, 1.0, 2.6, 8, w, 0.8f);
        later(p, w / 2, () -> heatHaze(p, 2.0, 3.2, 10, w / 2 + 4, 1f));
        later(p, w, () -> {
            Vec3 c = HdKit.chest(p), f = HdKit.feet(p);
            // bola ledakan panas (jingga, cepat jadi asap gelap), bukan bola cahaya putih
            Vfx.add(new Hd.Nova(c, 5.5, 0xFFD9A8, 0xFF9A50, 0x6A4A3A, 0x4A4038, 36, 0.65f * near, false));
            air(c, UP, 20.0, Math.PI, 30, 0.55f);
            dust(level, p, f, 8.0, 60, 1f);
            heatHaze(p, 6.0, 6.0, 16, 160, 1f);
        });
    }

    // ------------------------------------------------------------------ tiap tick

    public static void tick(ClientLevel level) {
        try {
            tick0(level);
        } catch (Throwable ignored) {
        }
    }

    private static void tick0(ClientLevel level) {
        long now = level.getGameTime();
        RAGE.keySet().removeIf(id -> !(level.getEntity(id) instanceof AbstractClientPlayer));
        for (AbstractClientPlayer p : level.players()) {
            int id = p.getId();
            if (!ShazamClientState.isTransformed(id) || !ShazamClientState.isLintang(id) || p.isInvisible()
                    || !ShazamClientState.isRaging(id) || HdKit.firstPerson(p)) {
                RAGE.remove(id);
                continue;
            }
            // Mode Surya: udara di sekeliling badan bergetar karena panas (riak panas), tanpa korona atau api
            Long until = RAGE.get(id);
            if (until == null || now >= until) {
                heatHaze(p, 0.7, 2.3, 5, 70, 0.75f);
                RAGE.put(id, now + 60);
            }
        }
    }
}
