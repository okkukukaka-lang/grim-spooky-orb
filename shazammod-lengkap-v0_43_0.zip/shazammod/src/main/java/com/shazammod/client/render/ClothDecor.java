package com.shazammod.client.render;

/**
 * Geometri hiasan kain (murni Java, gampang diuji): normal grid, rantai tepi, list emas timbul,
 * dan titik di permukaan kain. Grid: indeks = baris * cols + kolom.
 */
public final class ClothDecor {
    private ClothDecor() {}

    /** Satu quad di array keluaran: 4 titik (x, y, z), normal (x, y, z), lalu jenis warnanya. */
    public static final int STRIDE = 16;
    public static final int FACE = 0;    // permukaan list (atas/bawah)
    public static final int OUTER = 1;   // tepi luar (paling terang)
    public static final int INNER = 2;   // tepi dalam (bayangan)
    private static final float EDGE_OUT = 0.006f;   // list sedikit melewati tepi kain

    /** Normal halus tiap titik grid. Arahnya menghadap ke badan/kepala; sisi luar = kebalikannya. */
    public static void normals(float[] vx, float[] vy, float[] vz, int cols, int rows, float[] nx, float[] ny, float[] nz) {
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int i = r * cols + c;
                int left = r * cols + Math.max(0, c - 1);
                int right = r * cols + Math.min(cols - 1, c + 1);
                int up = Math.max(0, r - 1) * cols + c;
                int down = Math.min(rows - 1, r + 1) * cols + c;
                float tx = vx[right] - vx[left], ty = vy[right] - vy[left], tz = vz[right] - vz[left];
                float bx = vx[down] - vx[up], by = vy[down] - vy[up], bz = vz[down] - vz[up];
                float x = ty * bz - tz * by, y = tz * bx - tx * bz, z = tx * by - ty * bx;
                float len = (float) Math.sqrt(x * x + y * y + z * z);
                if (len < 1.0E-6f) {
                    x = 0f; y = 1f; z = 0f; len = 1f;
                }
                nx[i] = x / len;
                ny[i] = y / len;
                nz[i] = z / len;
            }
        }
    }

    /** Tepi jubah: kiri (bahu -> bawah), bawah (kiri -> kanan), kanan (bawah -> bahu). */
    public static int[] capeChain(int cols, int rows) {
        int[] chain = new int[rows + (cols - 1) + (rows - 1)];
        int k = 0;
        for (int r = 0; r < rows; r++) {
            chain[k++] = r * cols;
        }
        for (int c = 1; c < cols; c++) {
            chain[k++] = (rows - 1) * cols + c;
        }
        for (int r = rows - 2; r >= 0; r--) {
            chain[k++] = r * cols + cols - 1;
        }
        return chain;
    }

    /** Bukaan hood: tepi bawah kiri (tengkuk -> dagu), pinggiran wajah, tepi bawah kanan (dagu -> tengkuk). */
    public static int[] hoodChain(int cols, int rows) {
        int[] chain = new int[rows + (cols - 1) + (rows - 1)];
        int k = 0;
        for (int r = rows - 1; r >= 0; r--) {
            chain[k++] = r * cols;
        }
        for (int c = 1; c < cols; c++) {
            chain[k++] = c;
        }
        for (int r = 1; r < rows; r++) {
            chain[k++] = r * cols + cols - 1;
        }
        return chain;
    }

    /**
     * List emas timbul di sepanjang rantai tepi: lempeng selebar width yang menonjol setinggi raise
     * di kedua sisi kain, lengkap dengan dinding tepi luar dan dalam. Mengisi out, mengembalikan jumlah quad.
     * Ukuran out minimal chain.length * 4 * STRIDE.
     */
    public static int trim(float[] vx, float[] vy, float[] vz, float[] nx, float[] ny, float[] nz,
                           int cols, int rows, int[] chain, float width, float raise, float[] out) {
        int n = chain.length;
        float[] ox = new float[n], oy = new float[n], oz = new float[n];   // tepi luar list
        float[] ix = new float[n], iy = new float[n], iz = new float[n];   // tepi dalam list
        float[] dx = new float[n], dy = new float[n], dz = new float[n];   // arah ke dalam kain
        for (int k = 0; k < n; k++) {
            int i = chain[k];
            int r = i / cols, c = i % cols;
            // arah ke dalam: rata-rata tetangga dikurangi titik ini, dibuang komponen normalnya
            float sx = 0f, sy = 0f, sz = 0f;
            int count = 0;
            for (int dr = -1; dr <= 1; dr++) {
                for (int dc = -1; dc <= 1; dc++) {
                    int rr = r + dr, cc = c + dc;
                    if ((dr == 0 && dc == 0) || rr < 0 || cc < 0 || rr >= rows || cc >= cols) {
                        continue;
                    }
                    int j = rr * cols + cc;
                    sx += vx[j]; sy += vy[j]; sz += vz[j];
                    count++;
                }
            }
            float ax = sx / count - vx[i], ay = sy / count - vy[i], az = sz / count - vz[i];
            float dot = ax * nx[i] + ay * ny[i] + az * nz[i];
            ax -= dot * nx[i]; ay -= dot * ny[i]; az -= dot * nz[i];
            float len = (float) Math.sqrt(ax * ax + ay * ay + az * az);
            if (len > 1.0E-6f) {
                ax /= len; ay /= len; az /= len;
            } else {
                ax = 0f; ay = 0f; az = 0f;
            }
            boolean corner = k > 0 && k < n - 1 && (r == 0 || r == rows - 1) && (c == 0 || c == cols - 1);
            float w = corner ? width * 1.41f : width;   // sudut siku: list tetap selebar di kedua sisi
            dx[k] = ax; dy[k] = ay; dz[k] = az;
            ox[k] = vx[i] - ax * EDGE_OUT; oy[k] = vy[i] - ay * EDGE_OUT; oz[k] = vz[i] - az * EDGE_OUT;
            ix[k] = vx[i] + ax * w; iy[k] = vy[i] + ay * w; iz[k] = vz[i] + az * w;
        }
        int q = 0;
        for (int k = 0; k + 1 < n; k++) {
            int a = chain[k], b = chain[k + 1];
            float hax = nx[a] * raise, hay = ny[a] * raise, haz = nz[a] * raise;
            float hbx = nx[b] * raise, hby = ny[b] * raise, hbz = nz[b] * raise;
            float[] m = unit(nx[a] + nx[b], ny[a] + ny[b], nz[a] + nz[b], 0f, 1f, 0f);
            float[] d = unit(dx[k] + dx[k + 1], dy[k] + dy[k + 1], dz[k] + dz[k + 1], 1f, 0f, 0f);
            q = quad(out, q, ox[k] + hax, oy[k] + hay, oz[k] + haz, ox[k + 1] + hbx, oy[k + 1] + hby, oz[k + 1] + hbz,
                    ix[k + 1] + hbx, iy[k + 1] + hby, iz[k + 1] + hbz, ix[k] + hax, iy[k] + hay, iz[k] + haz,
                    m[0], m[1], m[2], FACE);
            q = quad(out, q, ox[k] - hax, oy[k] - hay, oz[k] - haz, ix[k] - hax, iy[k] - hay, iz[k] - haz,
                    ix[k + 1] - hbx, iy[k + 1] - hby, iz[k + 1] - hbz, ox[k + 1] - hbx, oy[k + 1] - hby, oz[k + 1] - hbz,
                    -m[0], -m[1], -m[2], FACE);
            q = quad(out, q, ox[k] + hax, oy[k] + hay, oz[k] + haz, ox[k] - hax, oy[k] - hay, oz[k] - haz,
                    ox[k + 1] - hbx, oy[k + 1] - hby, oz[k + 1] - hbz, ox[k + 1] + hbx, oy[k + 1] + hby, oz[k + 1] + hbz,
                    -d[0], -d[1], -d[2], OUTER);
            q = quad(out, q, ix[k] + hax, iy[k] + hay, iz[k] + haz, ix[k + 1] + hbx, iy[k + 1] + hby, iz[k + 1] + hbz,
                    ix[k + 1] - hbx, iy[k + 1] - hby, iz[k + 1] - hbz, ix[k] - hax, iy[k] - hay, iz[k] - haz,
                    d[0], d[1], d[2], INNER);
        }
        return q;
    }

    /**
     * Haluskan grid untuk digambar: tiap sel dipecah factor x factor mengikuti kurva Catmull-Rom yang
     * melewati titik-titik aslinya (jadi baris yang dipaku tetap persis di tempatnya).
     * Hasil: {x, y, z}, ukuran ((cols-1)*factor+1) x ((rows-1)*factor+1).
     */
    public static float[][] refine(float[] vx, float[] vy, float[] vz, int cols, int rows, int factor) {
        int nc = (cols - 1) * factor + 1;
        int nr = (rows - 1) * factor + 1;
        float[][] across = new float[3][rows * nc];   // tiap baris dihaluskan mendatar dulu
        float[][] src = {vx, vy, vz};
        for (int r = 0; r < rows; r++) {
            for (int j = 0; j < nc; j++) {
                int c1 = Math.min(j / factor, cols - 2);
                float t = j / (float) factor - c1;
                int c0 = Math.max(c1 - 1, 0), c2 = c1 + 1, c3 = Math.min(c1 + 2, cols - 1);
                for (int a = 0; a < 3; a++) {
                    float[] v = src[a];
                    across[a][r * nc + j] = catmull(v[r * cols + c0], v[r * cols + c1], v[r * cols + c2], v[r * cols + c3], t);
                }
            }
        }
        float[][] out = new float[3][nr * nc];
        for (int i = 0; i < nr; i++) {
            int r1 = Math.min(i / factor, rows - 2);
            float t = i / (float) factor - r1;
            int r0 = Math.max(r1 - 1, 0), r2 = r1 + 1, r3 = Math.min(r1 + 2, rows - 1);
            for (int j = 0; j < nc; j++) {
                for (int a = 0; a < 3; a++) {
                    float[] v = across[a];
                    out[a][i * nc + j] = catmull(v[r0 * nc + j], v[r1 * nc + j], v[r2 * nc + j], v[r3 * nc + j], t);
                }
            }
        }
        return out;
    }

    private static float catmull(float p0, float p1, float p2, float p3, float t) {
        float t2 = t * t, t3 = t2 * t;
        return 0.5f * (2f * p1 + (p2 - p0) * t + (2f * p0 - 5f * p1 + 4f * p2 - p3) * t2 + (3f * p1 - p0 - 3f * p2 + p3) * t3);
    }

    /**
     * Titik di permukaan kain pada kolom cf dan baris rf (boleh pecahan), plus normal halusnya.
     * out = {x, y, z, nx, ny, nz}.
     */
    public static void sample(float[] vx, float[] vy, float[] vz, float[] nx, float[] ny, float[] nz,
                              int cols, int rows, float cf, float rf, float[] out) {
        cf = Math.max(0f, Math.min(cols - 1, cf));
        rf = Math.max(0f, Math.min(rows - 1, rf));
        int c0 = Math.min((int) cf, cols - 2);
        int r0 = Math.min((int) rf, rows - 2);
        float fc = cf - c0, fr = rf - r0;
        int i00 = r0 * cols + c0, i10 = i00 + 1, i01 = i00 + cols, i11 = i01 + 1;
        float w00 = (1f - fc) * (1f - fr), w10 = fc * (1f - fr), w01 = (1f - fc) * fr, w11 = fc * fr;
        out[0] = vx[i00] * w00 + vx[i10] * w10 + vx[i01] * w01 + vx[i11] * w11;
        out[1] = vy[i00] * w00 + vy[i10] * w10 + vy[i01] * w01 + vy[i11] * w11;
        out[2] = vz[i00] * w00 + vz[i10] * w10 + vz[i01] * w01 + vz[i11] * w11;
        float[] n = unit(nx[i00] * w00 + nx[i10] * w10 + nx[i01] * w01 + nx[i11] * w11,
                ny[i00] * w00 + ny[i10] * w10 + ny[i01] * w01 + ny[i11] * w11,
                nz[i00] * w00 + nz[i10] * w10 + nz[i01] * w01 + nz[i11] * w11, 0f, 1f, 0f);
        out[3] = n[0];
        out[4] = n[1];
        out[5] = n[2];
    }

    private static float[] unit(float x, float y, float z, float fx, float fy, float fz) {
        float len = (float) Math.sqrt(x * x + y * y + z * z);
        return len < 1.0E-6f ? new float[] {fx, fy, fz} : new float[] {x / len, y / len, z / len};
    }

    private static int quad(float[] out, int q, float x1, float y1, float z1, float x2, float y2, float z2,
                            float x3, float y3, float z3, float x4, float y4, float z4,
                            float nx, float ny, float nz, int kind) {
        int o = q * STRIDE;
        out[o] = x1; out[o + 1] = y1; out[o + 2] = z1;
        out[o + 3] = x2; out[o + 4] = y2; out[o + 5] = z2;
        out[o + 6] = x3; out[o + 7] = y3; out[o + 8] = z3;
        out[o + 9] = x4; out[o + 10] = y4; out[o + 11] = z4;
        out[o + 12] = nx; out[o + 13] = ny; out[o + 14] = nz;
        out[o + 15] = kind;
        return q + 1;
    }
}
