package com.shazammod.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.shazammod.DemonSoldier;
import com.shazammod.ShazamMod;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.resources.ResourceLocation;

/**
 * 0.30 Prajurit iblis Pasukan Sabbac: kerangka hangus berurat bara dengan tengkorak bertanduk (badan kerangka vanila,
 * tekstur sendiri), mata & urat bara menyala dalam gelap (lapisan mata). Sedikit lebih besar dari kerangka biasa.
 */
public class DemonSoldierRenderer extends HumanoidMobRenderer<DemonSoldier, HumanoidModel<DemonSoldier>> {
    private static final ResourceLocation TEXTURE = ShazamMod.id("textures/entity/demon_soldier.png");
    private static final ResourceLocation GLOW = ShazamMod.id("textures/entity/demon_soldier_glow.png");
    private static final RenderType GLOW_TYPE = RenderType.eyes(GLOW);

    public DemonSoldierRenderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.SKELETON)), 0.5f);
        this.addLayer(new EyesLayer<>(this) {
            @Override
            public RenderType renderType() {
                return GLOW_TYPE;
            }
        });
    }

    @Override
    public ResourceLocation getTextureLocation(DemonSoldier entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(DemonSoldier entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(1.08f, 1.08f, 1.08f);
    }
}
