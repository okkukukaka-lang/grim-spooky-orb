package com.shazammod.client.fx;

import java.util.Comparator;
import java.util.List;
import java.util.Random;

import com.shazammod.AdamCatch;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Tangan Kahndaq (0.27, Black Adam): seperti di film, proyektil berhenti di udara di depan Black Adam.
 *
 * ADAM_CATCH (per proyektil): kilatan kecil & riak "berhenti" di titik tangkap, lalu selama proyektil itu masih melayang
 * busur petir membara menyambung dari telapak kanan Black Adam ke proyektil, yang berpendar jingga di tempatnya.
 * ADAM_RELEASE (tombol J): kilatan & suar di telapak, gelombang kejut melingkar dari badan, dan tiap proyektil yang melesat
 * balik meninggalkan jejak petir membara.
 */
public final class AdamCatchFx {
    private AdamCatchFx() {}

    private static Projectile nearest(ClientLevel level, Vec3 pos, double radius) {
        List<Projectile> list = level.getEntitiesOfClass(Projectile.class, new AABB(pos, pos).inflate(radius), Projectile::isAlive);
        return list.stream().min(Comparator.comparingDouble(p -> p.distanceToSqr(pos))).orElse(null);
    }

    /** ADAM_CATCH: satu proyektil berhenti di udara. */
    public static void caught(AbstractClientPlayer caster, Vec3 pos) {
        Vfx.add(new Fx.Flash(pos, 0.8f, AdamFx.AMBER_LIGHT, 6, 0.9f));
        Vfx.add(new Fx.Bubble(pos, 0.7, AdamFx.GOLD_HOT, 7, 0.6f, 1.0, 2.0, true));
        Projectile p = nearest(caster.clientLevel, pos, 1.5);
        if (p != null) {
            Vfx.add(new Hold(caster, p));
        }
    }

    /** Busur petir membara dari telapak ke proyektil yang melayang, selama proyektil itu masih tertahan. */
    private static final class Hold extends Effect {
        private final AbstractClientPlayer caster;
        private final Projectile projectile;
        private final long seed = Vfx.random().nextLong();

        Hold(AbstractClientPlayer caster, Projectile projectile) {
            super(AdamCatch.HOLD_TICKS + 20);
            this.caster = caster;
            this.projectile = projectile;
        }

        @Override
        public boolean tick(ClientLevel level) {
            // berhenti saat dilepas (melesat lagi), hilang, atau Black Adam-nya pergi
            return caster.isAlive() && projectile.isAlive() && projectile.getDeltaMovement().lengthSqr() < 0.25
                    && super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            Vec3 hand = ShazamPoses.handPos(caster, true, pt);
            Vec3 at = projectile.getPosition(pt).add(0, projectile.getBbHeight() * 0.5, 0);
            float flick = 0.75f + 0.25f * (float) Math.sin((age + pt) * 2.7f);
            Random random = new Random(seed + (age / 2) * 977L);
            float[] path = Lightning.path(hand.x, hand.y, hand.z, at.x, at.y, at.z, 4, 0.22, random);
            float near = d.nearFade(at.x, at.y, at.z, 0.8, 2.5);
            d.polyline(path, path.length / 3, 0.07f, 0.045f, AdamFx.AMBER, 0xFFFFFF, 0.85f * flick * near, 0.85f * flick * near);
            d.glow(at.x, at.y, at.z, 0.5f, AdamFx.AMBER, 0.5f * flick * near);
            d.flare(at.x, at.y, at.z, 0.28f, AdamFx.GOLD_HOT, 0.7f * near);
        }
    }

    /**
     * 0.28 Tangkisan Kahndaq: serangan ditahan kulit Black Adam. Kulitnya berkilat jingga di titik kena (riak seperti kulit
     * batu yang bergetar), lalu (0.28.1) panas matahari menyembur balik ke penyerang terdekat dan membakarnya.
     */
    public static void block(AbstractClientPlayer caster, Vec3 pos, boolean self) {
        ClientLevel level = caster.clientLevel;
        Vec3 chest = caster.position().add(0, caster.getBbHeight() * 0.6, 0);
        Vec3 n = pos.subtract(chest);
        n = n.lengthSqr() < 1.0E-4 ? caster.getViewVector(1f) : n.normalize();
        Vfx.add(new Fx.Flash(pos, 1.2f, AdamFx.AMBER, 7, 1f));
        Vfx.add(new Fx.Flash(pos, 0.5f, 0xFFFFFF, 4, 1f));
        Vfx.add(new Fx.Ripple(pos, n, 0.6, 0.3, 1.4, 0.1, AdamFx.GOLD_HOT, 8, 0.9f, false));
        CineFx.flare(pos, 0xFFD8A0, 3f, 0.07f, 1f, 7);
        List<LivingEntity> near = level.getEntitiesOfClass(LivingEntity.class, new AABB(pos, pos).inflate(4.0),
                e -> e != caster && e.isAlive());
        LivingEntity foe = near.stream().min(Comparator.comparingDouble(e -> e.distanceToSqr(pos))).orElse(null);
        if (foe != null) {   // 0.28.1: panas matahari menyembur balik ke penyerang (tanpa petir)
            Vec3 at = foe.position().add(0, foe.getBbHeight() * 0.6, 0);
            AtonFx.link(Lightning.Anchor.fixed(pos), pt -> foe.getPosition(pt).add(0, foe.getBbHeight() * 0.6, 0), 6);
            Vfx.add(new Fx.Flash(at, 1.4f, AdamFx.SUN, 8, 0.9f));
            for (int i = 0, count = Vfx.count(12); i < count; i++) {
                Vec3 d = ShazamFx.randomDir(level.random).scale(0.12);
                Vfx.ember(at.x, at.y, at.z, d.x, d.y + 0.05, d.z, 0.06f, 14 + level.random.nextInt(8));
            }
        }
        for (int i = 0, count = Vfx.count(10); i < count; i++) {   // bara memercik dari kulit yang ditahan
            Vec3 d = ShazamFx.randomDir(level.random).scale(0.1);
            Vfx.ember(pos.x, pos.y, pos.z, d.x, d.y + 0.04, d.z, 0.05f, 12 + level.random.nextInt(8));
        }
        ShazamFx.shakeAround(pos, 0.2f, 10);
        if (self) {
            FovKick.punch(-0.02f);
        }
    }

    /** ADAM_RELEASE: semua proyektil yang tertahan melesat balik. */
    public static void release(AbstractClientPlayer caster, boolean self) {
        ClientLevel level = caster.clientLevel;
        Vec3 hand = ShazamPoses.handPos(caster, true, 1f);
        Vec3 c = caster.position().add(0, 1.0, 0);
        Vfx.add(new Fx.Flash(hand, 1.6f, AdamFx.AMBER, 8, 0.9f));
        Vfx.add(new Fx.Flash(hand, 0.6f, 0xFFFFFF, 5, 1f));
        CineFx.flare(hand, 0xFFD8A0, 5f, 0.09f, 1f, 9);
        Vfx.add(new Fx.Ripple(c, caster.getViewVector(1f), 3.0, 0.6, 2.2, 0.16, AdamFx.AMBER_LIGHT, 9, 0.8f, false));
        double r = AdamCatch.HOLD_DISTANCE + 1.5;
        for (Projectile p : level.getEntitiesOfClass(Projectile.class, caster.getBoundingBox().inflate(r), Projectile::isAlive)) {
            Vfx.add(new Fx.Trail(p, pt -> p.getPosition(pt).add(0, p.getBbHeight() * 0.5, 0), AdamFx.AMBER, 0.35f, 8, 14, true));
            Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(hand), Lightning.Anchor.on(p, 0, 0, 0), AdamFx.AMBER_LIGHT, 0.05f, 3, 1,
                    1, 0.25));
        }
        ShazamFx.shakeAround(caster.position(), 0.3f, 20);
        if (self) {
            FovKick.punch(0.06f);
            ScreenFx.speedLines(0.4f);
        }
    }
}
