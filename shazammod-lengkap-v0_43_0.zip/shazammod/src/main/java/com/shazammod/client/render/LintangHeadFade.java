package com.shazammod.client.render;

import java.util.HashMap;
import java.util.Map;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.ShazamClientState;
import com.shazammod.client.fx.LintangFx;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.PlayerModelPart;
import net.minecraft.world.phys.Vec3;

/**
 * 0.42 Selama Lintang memakai sinar mata (charge & menembak), kepalanya jadi agak tembus pandang kalau kamera ada di
 * belakang kepala (kamera orang ketiga dari belakang, atau pemain lain di belakangnya): dari situ kepala menutupi sinar
 * yang keluar dari mata dan titik kenanya. Kepala & rambutnya digambar ulang dengan jenis render tembus pandang yang
 * nggak menulis kedalaman, jadi sinar (digambar sesudahnya) tetap tampil penuh menembus kepala. Dari depan kepala tetap
 * biasa (sinarnya memang kelihatan dari depan).
 */
public class LintangHeadFade extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    /** Kepala paling tembus pandang (charge penuh / sinar menyala, kamera tepat di belakang). */
    public static final float MIN_ALPHA = 0.45f;
    private static final Map<Integer, Float> FADING = new HashMap<>();   // id pemain -> alpha kepala di frame ini

    public LintangHeadFade(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    /**
     * Dipanggil di RenderPlayerEvent.Pre (sesudah bagian model diatur, sebelum digambar): kalau kepalanya perlu tembus
     * pandang, kepala & rambut model disembunyikan dulu, lalu digambar ulang tembus pandang oleh lapisan ini.
     */
    public static void pre(AbstractClientPlayer player, PlayerModel<AbstractClientPlayer> model, float partialTick) {
        FADING.remove(player.getId());
        try {
            if (player.isInvisible() || !ShazamClientState.isLintang(player.getId())
                    || !ShazamClientState.isTransformed(player.getId())) {
                return;
            }
            float heat = LintangFx.headFade(player, partialTick);
            if (heat <= 0.05f) {
                return;
            }
            Camera cam = Minecraft.getInstance().gameRenderer.getMainCamera();
            Vec3 to = player.getEyePosition(partialTick).subtract(cam.getPosition());
            double len = to.length();
            if (len < 0.3) {
                return;   // kamera di dalam kepala (orang pertama): kepala memang nggak digambar
            }
            double d = player.getViewVector(partialTick).dot(to.scale(1.0 / len));   // 1 = kamera tepat di belakang
            float fade = heat * Mth.clamp((float) (d + 0.2) / 0.6f, 0f, 1f);
            if (fade <= 0.05f) {
                return;
            }
            FADING.put(player.getId(), 1f - (1f - MIN_ALPHA) * fade);
            model.head.visible = false;
            model.hat.visible = false;
        } catch (Throwable ignored) {
            // efek nggak boleh bikin game crash
        }
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buffers, int light, AbstractClientPlayer player, float limbSwing,
                       float limbAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        Float alpha = FADING.remove(player.getId());
        if (alpha == null) {
            return;
        }
        PlayerModel<AbstractClientPlayer> m = getParentModel();
        boolean hat = player.isModelPartShown(PlayerModelPart.HAT);
        m.head.visible = true;   // dikembalikan (bayangan & lapisan lain sesudah ini memakai model yang sama)
        m.hat.visible = hat;
        try {
            float b = brightness(player, light, partialTick);
            int tint = ((int) (b * 255f) << 16) | ((int) (b * 245f) << 8) | (int) (b * 235f);
            VertexConsumer vc = buffers.getBuffer(RenderType.entityTranslucentEmissive(player.getSkin().texture()));
            m.head.render(ps, vc, light, OverlayTexture.NO_OVERLAY, ((int) (alpha * 255f) << 24) | tint);
            if (hat) {
                m.hat.render(ps, vc, light, OverlayTexture.NO_OVERLAY, ((int) (alpha * 230f) << 24) | tint);
            }
        } catch (Throwable ignored) {
            // efek nggak boleh bikin game crash
        }
    }

    /** Terang kepala menurut cahaya tempatnya (jenis render ini nggak memakai peta cahaya, jadi diatur lewat warnanya). */
    private static float brightness(AbstractClientPlayer player, int light, float partialTick) {
        float sky = LightTexture.sky(light) / 15f, block = LightTexture.block(light) / 15f;
        float sun = Mth.cos(player.level().getTimeOfDay(partialTick) * (float) (Math.PI * 2.0));
        float day = Mth.clamp(sun * 2f + 0.2f, 0f, 1f) * 0.8f + 0.2f;   // langit siang 1, malam 0,2 (seperti vanila)
        return 0.3f + 0.7f * Math.max(block, sky * day);
    }
}
