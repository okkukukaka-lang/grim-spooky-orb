package com.shazammod.client.fx;

import java.util.function.BooleanSupplier;
import java.util.function.Supplier;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;

/**
 * 0.42 Suara yang diulang selama efeknya hidup (dengung charge mata, sinar yang menyala, matahari mini): mengikuti
 * posisinya, keras & nadanya bisa diubah halus tiap tick (setTarget), dan memudar sendiri begitu efeknya selesai.
 */
final class LoopSound extends AbstractTickableSoundInstance {
    private final Supplier<Vec3> where;
    private final BooleanSupplier alive;
    private float targetVolume, targetPitch;

    private LoopSound(SoundEvent sound, Supplier<Vec3> where, BooleanSupplier alive, float volume, float pitch) {
        super(sound, SoundSource.PLAYERS, SoundInstance.createUnseededRandom());
        this.where = where;
        this.alive = alive;
        this.looping = true;
        this.delay = 0;
        this.volume = 0.05f;
        this.pitch = pitch;
        this.targetVolume = volume;
        this.targetPitch = pitch;
        Vec3 p = where.get();
        this.x = p.x;
        this.y = p.y;
        this.z = p.z;
    }

    static LoopSound play(SoundEvent sound, Supplier<Vec3> where, BooleanSupplier alive, float volume, float pitch) {
        LoopSound s = new LoopSound(sound, where, alive, volume, pitch);
        try {
            Minecraft.getInstance().getSoundManager().play(s);
        } catch (Throwable ignored) {
            // suara nggak boleh bikin efeknya gagal
        }
        return s;
    }

    void setTarget(float volume, float pitch) {
        targetVolume = volume;
        targetPitch = pitch;
    }

    /** Boleh mulai walau kerasnya masih hampir 0 (naik pelan di tick). */
    public boolean canStartSilent() {
        return true;
    }

    @Override
    public void tick() {
        if (!alive.getAsBoolean()) {
            volume *= 0.6f;
            if (volume < 0.02f) {
                stop();
            }
            return;
        }
        volume += (targetVolume - volume) * 0.35f;
        pitch += (targetPitch - pitch) * 0.35f;
        Vec3 p = where.get();
        x = p.x;
        y = p.y;
        z = p.z;
    }
}
