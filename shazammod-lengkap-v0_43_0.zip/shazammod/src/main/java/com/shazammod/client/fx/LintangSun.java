package com.shazammod.client.fx;

import java.util.HashMap;
import java.util.Map;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamSounds;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Hd;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Molten;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * 0.42 Nyala Mentari (N), efek di client. Cahaya tersedot ke antara kedua tangan Lintang dan memadat jadi bola plasma
 * kecil, didorong ke titik bidik sambil membesar, lalu menggantung sebagai matahari mini: permukaan bergranula yang
 * bergolak, korona, prominensa, tanah di bawahnya memerah, debu & api terseret naik berputar ke arahnya (pusaran api).
 * Menjelang runtuh ia berdenyut & berkedip. Ditinju (N lagi): melesat jadi komet berekor api lalu meledak saat menghantam.
 */
final class LintangSun {
    private LintangSun() {}

    private static final Vec3 UP = new Vec3(0, 1, 0);
    private static final Map<Integer, SunFx> SUNS = new HashMap<>();

    static void clear() {
        SUNS.clear();
    }

    static void tick() {
        SUNS.values().removeIf(s -> !s.alive());
    }

    static void cast(AbstractClientPlayer caster, Vec3 target, boolean self) {
        SunFx old = SUNS.remove(caster.getId());
        if (old != null) {
            old.end();
        }
        SunFx s = new SunFx(caster, target);
        SUNS.put(caster.getId(), s);
        Vfx.add(s);
        if (self) {
            FovKick.kick(0.2f);
        }
    }

    /** Tinju udara (dir = arah lesat): kerucut uap dari kepalan, lalu mataharinya melesat jadi komet. */
    static void punch(AbstractClientPlayer caster, Vec3 dir, boolean self) {
        SunFx s = SUNS.get(caster.getId());
        Vec3 n = dir.lengthSqr() < 1.0E-4 ? caster.getViewVector(1f) : dir.normalize();
        if (s != null) {
            s.launch(n);
        }
        ShazamFx.schedule(ShazamAnim.SUN_PUNCH_WINDUP, 1, (level, t) -> {
            Vec3 hand = ShazamPoses.handPos(caster, true, 1f);
            LintangFilm.vaporCone(hand, n, 1.1);
            LintangFilm.shockwave(hand.add(n.scale(0.8)), n, 3.0, 10, 0.9f);
            if (s != null) {
                LintangFilm.windStreaks(hand, s.pos(1f), 14, 8);
            }
        });
        if (self) {
            FovKick.punch(0.45f);
            CameraShake.add(0.3f);
        }
    }

    static void boom(AbstractClientPlayer caster, Vec3 pos, boolean self) {
        SunFx s = SUNS.remove(caster.getId());
        if (s != null) {
            s.end();
        }
        explode(caster, pos, 1.25f);
    }

    static void collapse(AbstractClientPlayer caster, Vec3 pos, boolean self) {
        SunFx s = SUNS.remove(caster.getId());
        if (s != null) {
            s.end();
        }
        explode(caster, pos, 1f);
    }

    /** Ledakan surya: kilat putih-emas, bola api & asap, gelombang kejut, kawah hangus, tanah yang ikut terbakar. */
    private static void explode(AbstractClientPlayer caster, Vec3 c, float k) {
        ClientLevel level = caster.clientLevel;
        LintangFilm.solarFlash(c, 2.4f * k);
        Vfx.add(new Hd.Nova(c, 7.0 * k, 0xFFF4D6, 0xFFB040, 0xC2400C, 0x3A2A22, 30, 1f, false));
        LintangFilm.shockwave(c, UP, 12.0 * k, 16, 1f);
        RandomSource r = level.random;
        for (int i = 0, n = Vfx.count(30 * k); i < n; i++) {   // api yang terlempar ke segala arah
            Vec3 d = ShazamFx.randomDir(r);
            double s = 0.25 + r.nextDouble() * 0.45;
            Vfx.flame(c.x + d.x * 0.6, c.y + d.y * 0.6, c.z + d.z * 0.6, d.x * s, Math.abs(d.y) * s * 0.7 + 0.04, d.z * s,
                    Molten.FIRE_ORANGE, 0.5f + r.nextFloat() * 0.5f, 18 + r.nextInt(12));
        }
        ShazamFx.smokeCloud(level, c, 0x3A3028, (int) (10 * k), 2.5 * k);
        BlockHitResult down = level.clip(new ClipContext(c, c.subtract(0, 8.0, 0), ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, caster));
        if (down.getType() != HitResult.Type.MISS) {   // tanah di bawahnya: kawah hangus & api yang menyala sebentar
            Vec3 g = down.getLocation();
            LintangFilm.crater(level, g, 2.0 * k, true);
            for (int i = 0; i < 5; i++) {
                double a = r.nextDouble() * Math.PI * 2.0, rr = 1.0 + r.nextDouble() * 3.0 * k;
                Vec3 p = g.add(Math.cos(a) * rr, 0.02, Math.sin(a) * rr);
                Vfx.add(new Molten.Fire3D(Lightning.Anchor.fixed(p), UP, 0.3, 0.6 + r.nextDouble() * 0.4, 50 + r.nextInt(50), 1f, false));
            }
        }
        ShazamFx.shakeAround(c, 1.0f * k, 40);
    }

    // ------------------------------------------------------------------ matahari mini

    static final class SunFx extends Effect {
        private static final double RADIUS = 1.25;
        private final AbstractClientPlayer caster;
        private final Vec3 target;
        private final long seed;
        private double groundY;
        private boolean ground;
        private Vec3 vel;
        private Vec3 launchFrom;
        private int launchAt = -1;
        private boolean ended;

        SunFx(AbstractClientPlayer caster, Vec3 target) {
            super(ShazamAnim.SUN_WINDUP + ShazamAnim.SUN_TRAVEL + ShazamAnim.SUN_TICKS + 60);
            this.caster = caster;
            this.target = target;
            this.seed = Vfx.random().nextLong();
            BlockHitResult down = caster.level().clip(new ClipContext(target, target.subtract(0, 9.0, 0), ClipContext.Block.COLLIDER,
                    ClipContext.Fluid.ANY, caster));
            if (down.getType() != HitResult.Type.MISS) {
                ground = true;
                groundY = down.getLocation().y;
            }
            LoopSound.play(ShazamSounds.SUN_LOOP.get(), () -> pos(1f), () -> !ended && age > ShazamAnim.SUN_WINDUP, 1.0f, 1f);
        }

        boolean alive() {
            return !ended && age < life;
        }

        void end() {
            ended = true;
        }

        void launch(Vec3 dir) {
            if (launchAt >= 0) {
                return;
            }
            launchFrom = pos(0f);
            vel = dir.scale(2.2);
            launchAt = age + ShazamAnim.SUN_PUNCH_WINDUP;
        }

        private Vec3 hands(float pt) {
            Vec3 h = ShazamPoses.handPos(caster, true, pt).add(ShazamPoses.handPos(caster, false, pt)).scale(0.5);
            return h.add(caster.getViewVector(pt).scale(0.35));
        }

        Vec3 pos(float pt) {
            float t = age + pt;
            if (launchAt >= 0 && t >= launchAt) {
                return launchFrom.add(vel.scale(t - launchAt));
            }
            if (launchAt >= 0) {
                return launchFrom;
            }
            int w = ShazamAnim.SUN_WINDUP;
            if (t < w) {
                return hands(pt);
            }
            if (t < w + ShazamAnim.SUN_TRAVEL) {
                float k = (t - w) / ShazamAnim.SUN_TRAVEL;
                k = 1f - (1f - k) * (1f - k) * (1f - k);
                return hands(pt).lerp(target, k);
            }
            return target.add(0, 0.08 * Math.sin(t * 0.08), 0);
        }

        private double radius(float t) {
            int w = ShazamAnim.SUN_WINDUP;
            if (t < w) {
                float k = t / w;
                return 0.05 + 0.35 * k * k;
            }
            if (t < w + ShazamAnim.SUN_TRAVEL) {
                return Mth.lerp((t - w) / ShazamAnim.SUN_TRAVEL, 0.4, RADIUS);
            }
            return RADIUS;
        }

        private float unstable(float t) {
            float start = ShazamAnim.SUN_WINDUP + ShazamAnim.SUN_TRAVEL + ShazamAnim.SUN_TICKS - 25;
            return launchAt >= 0 ? 0f : Mth.clamp((t - start) / 25f, 0f, 1f);
        }

        private boolean hanging(float t) {
            return launchAt < 0 && t >= ShazamAnim.SUN_WINDUP + ShazamAnim.SUN_TRAVEL;
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (ended || (!caster.isAlive() && launchAt < 0) || !ShazamClientState.isTransformed(caster.getId()) && launchAt < 0) {
                ended = true;
                return false;
            }
            float t = age;
            RandomSource r = level.random;
            Vec3 p = pos(0f);
            if (t < ShazamAnim.SUN_WINDUP) {   // cahaya tersedot ke antara kedua tangan
                for (int i = 0; i < 3; i++) {
                    Vec3 off = ShazamFx.randomDir(r).scale(1.6 + r.nextDouble() * 1.2);
                    Vec3 v = off.scale(-0.16);
                    Vfx.mote(p.x + off.x, p.y + off.y, p.z + off.z, v.x, v.y, v.z, i == 0 ? Molten.SUN_WHITE : Molten.SUN_GOLD,
                            0.07f, 9);
                }
            } else if (hanging(t)) {
                if (ground) {   // debu & api terseret masuk lalu naik berputar
                    for (int i = 0, n = Vfx.count(2); i < n; i++) {
                        double a = r.nextDouble() * Math.PI * 2.0, rr = 3.0 + r.nextDouble() * 6.0;
                        double x = p.x + Math.cos(a) * rr, z = p.z + Math.sin(a) * rr;
                        double vin = 0.18, vsw = 0.12;
                        Vfx.dust(x, groundY + 0.2, z, -Math.cos(a) * vin - Math.sin(a) * vsw, 0.05, -Math.sin(a) * vin + Math.cos(a) * vsw,
                                0xB8A28C, 0.45f, 22);
                    }
                    if (r.nextFloat() < 0.5f) {
                        double a = r.nextDouble() * Math.PI * 2.0, rr = 0.5 + r.nextDouble() * 1.5;
                        Vfx.flame(p.x + Math.cos(a) * rr, groundY + 0.2, p.z + Math.sin(a) * rr, 0, 0.12, 0, Molten.FIRE_ORANGE,
                                0.45f, 16);
                    }
                }
                if (r.nextFloat() < 0.6f) {   // bara yang naik dari permukaannya
                    Vec3 d = ShazamFx.randomDir(r);
                    Vfx.ember(p.x + d.x * RADIUS, p.y + d.y * RADIUS, p.z + d.z * RADIUS, d.x * 0.04, 0.05, d.z * 0.04, 0.06f, 16);
                }
            } else if (launchAt >= 0 && t >= launchAt) {   // komet: ekor api, bara, asap
                Vec3 back = vel.normalize().scale(-1.0);
                for (int i = 0, n = Vfx.count(4); i < n; i++) {
                    Vec3 q = p.add(back.scale(r.nextDouble() * 2.0)).add(ShazamFx.randomDir(r).scale(0.5));
                    Vfx.flame(q.x, q.y, q.z, back.x * 0.1, back.y * 0.1 + 0.02, back.z * 0.1, Molten.FIRE_ORANGE, 0.6f, 12);
                }
                Vfx.smoke(p.x + back.x * 2.0, p.y + back.y * 2.0, p.z + back.z * 2.0, 0, 0.02, 0, 0x3A3028, 0.7f, 30);
            }
            return super.tick(level);
        }

        private float alpha(float t) {
            return Mth.clamp(t / 3f, 0f, 1f) * Mth.clamp((life - t) / 6f, 0f, 1f);
        }

        @Override
        public void renderSoft(Draw d) {
            float pt = d.partialTick, t = age + pt;
            Molten.sunOrb(d, true, pos(pt), radius(t), t, alpha(t), unstable(t), seed);
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick, t = age + pt;
            float a = alpha(t);
            Vec3 p = pos(pt);
            double r = radius(t);
            Molten.sunOrb(d, false, p, r, t, a, unstable(t), seed);
            if (t < ShazamAnim.SUN_WINDUP) {   // benang-benang cahaya yang terkumpul ke tangan
                for (int i = 0; i < 8; i++) {
                    double ang = Molten.hash(seed, i) * Math.PI * 2.0 + t * 0.2, el = (Molten.hash(seed, i + 20) - 0.5) * 2.0;
                    double len = 1.4 + 1.4 * (1.0 - t / ShazamAnim.SUN_WINDUP);
                    Vec3 q = p.add(Math.cos(ang) * Math.cos(el) * len, Math.sin(el) * len, Math.sin(ang) * Math.cos(el) * len);
                    d.line(q.x, q.y, q.z, p.x, p.y, p.z, 0.04f, 0.01f, Molten.SUN_GOLD, 0f, a * 0.8f);
                }
            }
            if (hanging(t) && ground) {   // pusaran api ke atas & tanah yang memerah di bawahnya
                Molten.fireSwirl(d, p, groundY, 2.4, t, a * 0.85f);
                d.disc(p.x, groundY + 0.06, p.z, 0, 1, 0, 3.6, Molten.FIRE_ORANGE, a * 0.35f, 0f, null);
            }
            if (launchAt >= 0 && t >= launchAt) {   // ekor komet
                Vec3 back = vel.normalize().scale(-1.0);
                int n = 10;
                float[] pts = new float[n * 3];
                for (int i = 0; i < n; i++) {
                    Vec3 q = p.add(back.scale(i * 0.7));
                    pts[i * 3] = (float) q.x;
                    pts[i * 3 + 1] = (float) q.y;
                    pts[i * 3 + 2] = (float) q.z;
                }
                d.polyline(pts, n, (float) (r * 1.6), 0.1f, Molten.FIRE_ORANGE, Molten.SUN_WHITE, a * 0.9f, 0f);
            }
        }
    }
}
