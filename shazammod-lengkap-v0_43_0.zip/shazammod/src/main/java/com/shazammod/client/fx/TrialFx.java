package com.shazammod.client.fx;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import com.shazammod.ShazamAnim;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Runes;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

/**
 * Efek jalan mendapatkan juara (wujud manusia):
 *
 * Black Adam - Ujian Kahndaq: Skarabe Teth-Adam berdenyut di tangan yang terangkat, badai pasir raksasa melingkari
 *   tanah ujian, bayangan Teth-Adam (siluet bertudung dari asap, mata membara) menjulang di dalam badai, makhluk makam
 *   menyeruak dari pasir. Lulus: badai runtuh ke dalam, enam cahaya dewa Mesir mengorbit, skarabe naik lalu menyatu ke
 *   dada, dan petir Kahndaq menyambar.
 * Shazam - enam totem: enam cahaya totem (warna tiap dewa) terangkat dari tas, berputar, menyatu jadi bintang emas di
 *   atas kepala, lalu petir Penyihir menyambar.
 */
public final class TrialFx {
    private TrialFx() {}

    private static final Vec3 UP = new Vec3(0, 1, 0);
    // Warna enam dewa Mesir (Shu, Heru, Amon, Zehuti, Aton, Mehen) dan enam totem Shazam
    private static final int[] EGYPT = {0xCFEAFF, 0xFFB060, 0x7A96FF, AdamFx.TURQUOISE, AdamFx.SUN, AdamFx.SERPENT_RED};
    private static final int[] TOTEMS = {ShazamFx.SOLOMON, ShazamFx.HERCULES, ShazamFx.ATLAS, ShazamFx.ZEUS, 0xFFE9A0,
            ShazamFx.MERCURY};
    private static final int STORM_LIFE = 20 * 60 * 6;

    private static final Map<Integer, Sandstorm> STORMS = new HashMap<>();

    public static void clear() {
        STORMS.clear();
    }

    public static void tick(ClientLevel level) {
        STORMS.values().removeIf(s -> s.finished);
        LocalPlayer me = Minecraft.getInstance().player;
        if (me == null) {
            return;
        }
        for (Sandstorm storm : STORMS.values()) {   // di dalam badai: layar berdebu kecokelatan
            if (!storm.ending && me.position().distanceTo(storm.center) < Sandstorm.RADIUS + 3.0) {
                ScreenFx.vignette(0.24f, 0x3A2408, 3);
            }
        }
    }

    public static void onAnim(AbstractClientPlayer caster, ShazamAnim anim, Vec3 pos) {
        boolean self = caster == Minecraft.getInstance().player;
        switch (anim) {
            case KAHNDAQ_TRIAL -> trialStart(caster, self);
            case KAHNDAQ_RISE -> rise(caster, pos);
            case KAHNDAQ_AWAKEN -> awaken(caster, self);
            case KAHNDAQ_END -> {
                Sandstorm storm = STORMS.remove(caster.getId());
                if (storm != null) {
                    storm.end();
                }
            }
            case SHAZAM_CHOSEN -> chosen(caster, self);
            default -> { }
        }
    }

    // ------------------------------------------------------------------ Ujian Kahndaq

    private static void trialStart(AbstractClientPlayer caster, boolean self) {
        Sandstorm old = STORMS.remove(caster.getId());
        if (old != null) {
            old.end();
        }
        Sandstorm storm = new Sandstorm(caster, caster.position());
        STORMS.put(caster.getId(), storm);
        Vfx.add(storm);
        Vfx.add(new Scarab(pt -> ShazamPoses.handPos(caster, true, pt).add(0, 0.3, 0), 0.8f, 72));
        ClientLevel level = (ClientLevel) caster.level();
        Ground.Map map = ShazamFx.ground(level, caster.position(), 4.5);
        double gy = (map == null ? caster.getY() : map.centerY) + 0.03;
        Vec3 c = caster.position();
        Vfx.add(new Runes.Circle(Lightning.Anchor.fixed(new Vec3(c.x, gy, c.z)), UP, 4.2, AdamFx.AMBER, 90, 0.02f, 0.9f, null));
        Vec3 look = caster.getViewVector(1f);
        Vec3 flat = new Vec3(look.x, 0, look.z);
        flat = flat.lengthSqr() < 1.0E-4 ? new Vec3(0, 0, 1) : flat.normalize();
        Vfx.add(new Shade(c.add(flat.scale(13.0)).add(0, 4.6, 0), caster, 160));
        schedule(0, 40, (lvl, t) -> {   // pasir terhisap ke skarabe
            Vec3 hand = ShazamPoses.handPos(caster, true, 1f);
            for (int i = 0, n = Vfx.count(3); i < n; i++) {
                Vec3 off = ShazamFx.randomDir(lvl.random).scale(2.0 + lvl.random.nextDouble());
                Vfx.dust(hand.x + off.x, hand.y + off.y * 0.5, hand.z + off.z, -off.x * 0.12, -off.y * 0.05, -off.z * 0.12,
                        AdamFx.SAND, 0.35f, 10);
            }
        });
        if (self) {
            ScreenFlash.flash(0.25f, 0xFFD8A0);
            CameraShake.add(0.2f);
        }
    }

    /** Makhluk makam menyeruak dari pasir (atau runtuh jadi pasir): pasir menyembur, cincin debu, kilau sihir. */
    private static void rise(AbstractClientPlayer caster, Vec3 pos) {
        ClientLevel level = (ClientLevel) caster.level();
        Ground.Map map = ShazamFx.ground(level, pos.add(0, 0.5, 0), 2.0);
        Vec3 g = map == null ? pos : map.center(pos);
        int dust = map == null ? AdamFx.SAND : map.dustColor(level, pos);
        for (int i = 0, n = Vfx.count(14); i < n; i++) {
            double a = level.random.nextDouble() * Math.PI * 2.0, r = level.random.nextDouble() * 0.6;
            Vfx.dust(g.x + Math.cos(a) * r, g.y + 0.1, g.z + Math.sin(a) * r, Math.cos(a) * 0.06, 0.14 + level.random.nextDouble() * 0.12,
                    Math.sin(a) * 0.06, dust, 0.6f, 26 + level.random.nextInt(10));
        }
        if (map != null) {
            Vfx.add(new Fx.Wave(g, UP, 2.0, 0.8, dust, 18, 0.6f, 0f, map, true));
            if (map.found) {
                Vfx.add(new Ground.Debris(g, map, 6, 0.08, 0.38, 0.3, 30));
            }
        }
        Vfx.add(new Fx.Flash(g.add(0, 0.6, 0), 1.2f, AdamFx.AMBER, 7, 0.7f));
        for (int i = 0, n = Vfx.count(5); i < n; i++) {
            Vfx.glint(g.x + (level.random.nextDouble() - 0.5), g.y + 0.3 + level.random.nextDouble() * 1.4,
                    g.z + (level.random.nextDouble() - 0.5), AdamFx.GOLD_HOT, 0.22f, 10);
        }
        ShazamFx.smokeCloud(level, g, dust, 3, 0.6);
    }

    /** Lulus ujian: badai runtuh ke dalam, enam cahaya dewa Mesir mengorbit, skarabe naik lalu menyatu, petir Kahndaq. */
    private static void awaken(AbstractClientPlayer caster, boolean self) {
        Sandstorm storm = STORMS.remove(caster.getId());
        if (storm != null) {
            storm.collapse();
        }
        int strike = ShazamAnim.KAHNDAQ_AWAKEN_STRIKE;
        ClientLevel level0 = (ClientLevel) caster.level();
        Ground.Map map = ShazamFx.ground(level0, caster.position(), 4.0);
        double gy = (map == null ? caster.getY() : map.centerY) + 0.03;
        Vfx.add(new Runes.Circle(pt -> new Vec3(caster.getPosition(pt).x, gy, caster.getPosition(pt).z), UP, 3.4, AdamFx.AMBER,
                ShazamAnim.KAHNDAQ_AWAKEN_TICKS + 10, -0.04f, 1f, null));
        Vfx.add(new Runes.Circle(pt -> new Vec3(caster.getPosition(pt).x, gy + 0.01, caster.getPosition(pt).z), UP, 2.0,
                AdamFx.GOLD_HOT, ShazamAnim.KAHNDAQ_AWAKEN_TICKS + 10, 0.06f, 0.8f, null));
        // skarabe naik dari tangan ke atas kepala, berputar, lalu (saat petir) menyatu ke dada
        Vfx.add(new Scarab(new Lightning.Anchor() {
            private final long t0 = caster.level().getGameTime();

            @Override
            public Vec3 at(float pt) {
                float t = caster.level().getGameTime() - t0 + pt;
                Vec3 hand = ShazamPoses.handPos(caster, true, pt).add(0, 0.28, 0);
                Vec3 above = caster.getPosition(pt).add(0, caster.getBbHeight() + 1.4, 0);
                Vec3 chest = caster.getPosition(pt).add(0, caster.getBbHeight() * 0.65, 0);
                if (t < 30f) {
                    return hand.lerp(above, GodFigures.smooth(t / 30f));
                }
                if (t < strike - 3f) {
                    return above.add(0, Math.sin(t * 0.2) * 0.08, 0);
                }
                return above.lerp(chest, Mth.clamp((t - (strike - 3f)) / 3f, 0f, 1f));
            }
        }, 0.7f, strike + 1));
        for (int i = 0; i < 6; i++) {   // enam cahaya dewa Mesir
            Orb orb = new Orb(caster, EGYPT[i], Math.PI * 2.0 * i / 6.0, 2.8, 0.6 + i * 0.12, caster.getBbHeight() + 1.4,
                    strike - 14, strike);
            Vfx.add(orb);
            Vfx.add(new Fx.Trail(caster, orb::pos, EGYPT[i], 0.22f, 8, strike, false));
        }
        schedule(0, strike, (level, t) -> {
            Vec3 c = caster.position();
            for (int i = 0, n = Vfx.count(3); i < n; i++) {   // pasir & cahaya terhisap ke pusat
                double a = level.random.nextDouble() * Math.PI * 2.0, r = 4.0 + level.random.nextDouble() * 3.0;
                Vfx.dust(c.x + Math.cos(a) * r, c.y + 0.2, c.z + Math.sin(a) * r, -Math.cos(a) * 0.2, 0.02, -Math.sin(a) * 0.2,
                        AdamFx.SAND, 0.5f, 18);
                Vfx.mote(c.x + Math.cos(a) * r * 0.6, c.y + 0.3, c.z + Math.sin(a) * r * 0.6, -Math.cos(a) * 0.08, 0.08,
                        -Math.sin(a) * 0.08, AdamFx.AMBER_LIGHT, 0.09f, 20);
            }
            if (t > 20 && t % 3 == 0) {   // busur petir dari cahaya dewa ke skarabe
                Vec3 top = c.add(0, caster.getBbHeight() + 1.4, 0);
                double a = level.random.nextDouble() * Math.PI * 2.0;
                Vec3 from = c.add(Math.cos(a) * 2.6, 1.6 + level.random.nextDouble() * 1.2, Math.sin(a) * 2.6);
                Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(from), Lightning.Anchor.fixed(top), AdamFx.AMBER_LIGHT, 0.06f, 3, 1,
                        1, 0.3));
            }
            if (self && t % 3 == 0) {
                CameraShake.add(0.02f + t * 0.001f);
            }
        });
        schedule(strike, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vfx.add(new Fx.Flash(c.add(0, 1.6, 0), 4.8f, AdamFx.WHITE_HOT, 14, 1f));
            Vfx.add(new Fx.Flash(c.add(0, 1.0, 0), 3.4f, AdamFx.AMBER, 16, 1f));
            Vfx.add(new Fx.Pillar(c, 80.0, 2.4f, AdamFx.AMBER, 20));
            Vfx.add(new Fx.Bubble(c.add(0, 1.0, 0), 5.5, AdamFx.AMBER, 15, 0.95f, 1.0, 1.7, true));
            ShazamFx.impact(level, caster, c, 3.0f, AdamFx.AMBER, AdamFx.GOLD_HOT, true, 1.6f);
            Ground.Map m = ShazamFx.ground(level, c, 6.0);
            if (m != null) {
                Vfx.add(new Fx.Wave(m.center(c), UP, 13.0, 0.6, AdamFx.WHITE_HOT, 16, 0.9f, 0f, m));
                Vfx.add(new Fx.Wave(m.center(c), UP, 9.0, 2.4, AdamFx.SAND, 40, 0.7f, 0f, m, true));
            }
            ShazamFx.groundArcs(level, c, 12, 7.0, AdamFx.AMBER, 8);
            ShazamFx.ringOfSparks(level, c.add(0, 1.6, 0), 90, AdamFx.AMBER_LIGHT, 0.65);
            ShazamFx.smokeCloud(level, c, AdamFx.SMOKE, 10, 2.5);
            Lightning.Crackle crackle = new Lightning.Crackle(caster, AdamFx.AMBER_LIGHT, 2.6f, 0.06f, 50).reach(1.1);
            crackle.strength(self && Minecraft.getInstance().options.getCameraType().isFirstPerson() ? 0.25f : 1f);
            Vfx.add(crackle);
            ShazamFx.shakeAround(c, 1.3f, 40);
            if (self) {
                ScreenFlash.flash(1.0f, 0xFFE8C8);
                CameraShake.add(0.7f);
                FovKick.punch(-0.1f);
            }
        });
    }

    // ------------------------------------------------------------------ enam totem Shazam

    private static void chosen(AbstractClientPlayer caster, boolean self) {
        int strike = ShazamAnim.SHAZAM_CHOSEN_STRIKE;
        ClientLevel level0 = (ClientLevel) caster.level();
        Ground.Map map = ShazamFx.ground(level0, caster.position(), 3.5);
        double gy = (map == null ? caster.getY() : map.centerY) + 0.03;
        Vfx.add(new Runes.Circle(pt -> new Vec3(caster.getPosition(pt).x, gy, caster.getPosition(pt).z), UP, 3.0, ShazamFx.GOLD,
                ShazamAnim.SHAZAM_CHOSEN_TICKS + 10, 0.04f, 1f, null));
        for (int i = 0; i < 6; i++) {   // enam cahaya totem terangkat, berputar, lalu menyatu di atas kepala
            Orb orb = new Orb(caster, TOTEMS[i], Math.PI * 2.0 * i / 6.0, 2.2, 1.0, caster.getBbHeight() + 1.6,
                    strike - 16, strike - 4);
            Vfx.add(orb);
            Vfx.add(new Fx.Trail(caster, orb::pos, TOTEMS[i], 0.2f, 8, strike, false));
        }
        schedule(0, strike, (level, t) -> {
            Vec3 c = caster.position();
            if (t % 2 == 0) {
                double a = level.random.nextDouble() * Math.PI * 2.0, r = 2.6;
                Vfx.mote(c.x + Math.cos(a) * r, c.y + 0.1, c.z + Math.sin(a) * r, -Math.cos(a) * 0.05, 0.09, -Math.sin(a) * 0.05,
                        ShazamFx.GOLD_LIGHT, 0.09f, 22);
            }
            if (t > strike - 6) {   // bintang emas di atas kepala sebelum petir
                Vec3 top = c.add(0, caster.getBbHeight() + 1.6, 0);
                Vfx.glint(top.x, top.y, top.z, ShazamFx.WHITE_HOT, 0.9f, 3);
            }
        });
        schedule(strike, 1, (level, t) -> {
            Vec3 c = caster.position();
            Vfx.add(new Fx.Flash(c.add(0, 1.6, 0), 4.2f, ShazamFx.WHITE_HOT, 13, 1f));
            Vfx.add(new Fx.Flash(c.add(0, 1.0, 0), 3.0f, ShazamFx.GOLD, 15, 1f));
            Vfx.add(new Fx.Bubble(c.add(0, 1.0, 0), 4.5, ShazamFx.GOLD, 13, 0.9f, 1.0, 1.8, true));
            ShazamFx.impact(level, caster, c, 2.4f, ShazamFx.GOLD, ShazamFx.GOLD_LIGHT, true);
            ShazamFx.ringOfSparks(level, c.add(0, 1.6, 0), 70, ShazamFx.GOLD_LIGHT, 0.6);
            ShazamFx.groundArcs(level, c, 8, 5.0, ShazamFx.GOLD, 7);
            ShazamFx.shakeAround(c, 1.0f, 36);
            if (self) {
                ScreenFlash.flash(0.9f, 0xFFF4D8);
                CameraShake.add(0.5f);
            }
        });
    }

    private static void schedule(int delay, int duration, ShazamFx.Step step) {
        ShazamFx.schedule(delay, duration, step);
    }

    // ------------------------------------------------------------------ efek

    /** Cahaya dewa/totem yang mengorbit pemain sambil naik, lalu menyatu di satu titik di atas kepala. */
    static final class Orb extends Effect {
        private final AbstractClientPlayer owner;
        private final int rgb;
        private final double phase, radius, startY, topY;
        private final int convergeFrom, convergeAt;

        Orb(AbstractClientPlayer owner, int rgb, double phase, double radius, double startY, double topY, int convergeFrom,
            int convergeAt) {
            super(convergeAt + 2);
            this.owner = owner;
            this.rgb = rgb;
            this.phase = phase;
            this.radius = radius;
            this.startY = startY;
            this.topY = topY;
            this.convergeFrom = convergeFrom;
            this.convergeAt = convergeAt;
        }

        Vec3 pos(float pt) {
            float t = time(pt);
            Vec3 base = owner.getPosition(pt);
            double grow = GodFigures.smooth(Math.min(1.0, t / 14.0));
            double y = startY + (topY - 0.8 - startY) * GodFigures.smooth(Math.min(1.0, t / (double) convergeFrom));
            double r = radius * grow;
            double ang = phase + t * (0.1 + 0.08 * Math.min(1.0, t / (double) convergeAt));
            if (t > convergeFrom) {
                double k = GodFigures.smooth(Math.min(1.0, (t - convergeFrom) / (double) Math.max(1, convergeAt - convergeFrom)));
                r *= 1.0 - k;
                y += (topY - y) * k;
            }
            return base.add(Math.cos(ang) * r, y, Math.sin(ang) * r);
        }

        @Override
        public void renderGlow(Draw d) {
            float t = time(d.partialTick);
            float a = Math.min(1f, t / 5f) * Math.min(1f, (life - t) / 2f);
            if (a <= 0.01f) {
                return;
            }
            Vec3 p = pos(d.partialTick);
            float near = d.nearFade(p.x, p.y, p.z, 0.6, 1.8);
            d.flare(p.x, p.y, p.z, 0.45f, rgb, a * near);
            d.glint(p.x, p.y, p.z, 0.35f, t * 0.2f, Draw.mix(rgb, 0xFFFFFF, 0.5), 0.8f * a * near);
        }
    }

    /** Skarabe Teth-Adam bercahaya: badan kumbang emas, sayap terbuka, permata pirus, sinar berdenyut. */
    static final class Scarab extends Effect {
        private final Lightning.Anchor at;
        private final float size;

        Scarab(Lightning.Anchor at, float size, int life) {
            super(life);
            this.at = at;
            this.size = size;
        }

        @Override
        public void renderGlow(Draw d) {
            float t = time(d.partialTick);
            float a = Math.min(1f, t / 4f) * Math.min(1f, (life - t) / 3f);
            if (a <= 0.01f) {
                return;
            }
            Vec3 p = at.at(d.partialTick);
            float near = d.nearFade(p.x, p.y, p.z, 0.5, 1.6);
            float pulse = 0.8f + 0.2f * (float) Math.sin(t * 0.5f);
            float s = size;
            // badan: dua cahaya lonjong bertumpuk (kepala & perut), sayap: garis-garis melengkung ke samping
            d.glow(p.x, p.y, p.z, 0.5f * s, AdamFx.AMBER, 0.6f * a * near * pulse);
            d.flare(p.x, p.y, p.z, 0.22f * s, AdamFx.GOLD_HOT, a * near);
            double vx = p.x - d.camX, vz = p.z - d.camZ;
            double rl = Math.sqrt(vx * vx + vz * vz) + 1.0E-9;
            double rx = -vz / rl, rz = vx / rl;
            for (int side = -1; side <= 1; side += 2) {
                for (int k = 0; k < 3; k++) {
                    double lift = 0.12 + 0.1 * k + 0.05 * Math.sin(t * 0.7 + k);
                    double reach = (0.55 - 0.1 * k) * s;
                    d.line(p.x, p.y, p.z, p.x + rx * side * reach, p.y + lift * s, p.z + rz * side * reach, 0.06f * s, 0.015f * s,
                            k == 0 ? AdamFx.GOLD_HOT : AdamFx.AMBER_LIGHT, 0.85f * a * near, 0.2f * a * near);
                }
            }
            d.glow(p.x, p.y + 0.03 * s, p.z, 0.09f * s, AdamFx.TURQUOISE, a * near);   // permata pirus
            int rays = 10;
            for (int i = 0; i < rays; i++) {
                double ang = t * 0.06 + Math.PI * 2.0 * i / rays;
                double len = (0.7 + 0.25 * Math.sin(t * 0.4 + i)) * s;
                d.line(p.x, p.y, p.z, p.x + rx * Math.cos(ang) * len, p.y + Math.sin(ang) * len, p.z + rz * Math.cos(ang) * len,
                        0.04f * s, 0.005f, AdamFx.GOLD_HOT, 0.4f * a * near * pulse, 0f);
            }
        }
    }

    /**
     * Badai pasir raksasa melingkari tanah ujian: pita-pita pasir tebal berputar pelan setinggi ±9 blok, debu beterbangan,
     * dan petir membara sesekali menyambar di dalamnya. Saat lulus, badai runtuh ke dalam.
     */
    static final class Sandstorm extends Effect {
        static final double RADIUS = 11.0;
        private final AbstractClientPlayer owner;
        final Vec3 center;
        boolean ending, finished;
        private boolean collapsing;
        private int endAge = -1;
        private float fade, fadeO, shrink = 1f, shrinkO = 1f;

        Sandstorm(AbstractClientPlayer owner, Vec3 center) {
            super(STORM_LIFE);
            this.owner = owner;
            this.center = center;
        }

        void end() {
            if (!ending) {
                ending = true;
                endAge = age;
            }
        }

        void collapse() {
            collapsing = true;
            end();
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (!owner.isAlive() || owner.isRemoved()) {
                end();
            }
            fadeO = fade;
            shrinkO = shrink;
            fade = Mth.approach(fade, ending ? 0f : 1f, ending ? (collapsing ? 0.035f : 0.04f) : 0.03f);
            if (collapsing) {
                shrink = Mth.approach(shrink, 0.05f, 0.03f);
            }
            RandomSource r = level.random;
            double rad = RADIUS * shrink;
            if (fade > 0.05f) {
                for (int i = 0, n = Vfx.count(6 * fade); i < n; i++) {   // debu beterbangan mengikuti putaran badai
                    double a = r.nextDouble() * Math.PI * 2.0, rr = rad + (r.nextDouble() - 0.5) * 4.0;
                    double tx = -Math.sin(a), tz = Math.cos(a);
                    Vfx.dust(center.x + Math.cos(a) * rr, center.y + r.nextDouble() * 7.0, center.z + Math.sin(a) * rr,
                            tx * 0.35 - (collapsing ? Math.cos(a) * 0.3 : 0), 0.02, tz * 0.35 - (collapsing ? Math.sin(a) * 0.3 : 0),
                            r.nextBoolean() ? AdamFx.SAND : AdamFx.SAND_DARK, 0.9f + r.nextFloat() * 0.8f, 20 + r.nextInt(14));
                }
                if (age % 14 == 0 && fade > 0.5f) {   // petir membara di dalam badai
                    double a0 = r.nextDouble() * Math.PI * 2.0, a1 = a0 + 0.3 + r.nextDouble() * 0.5;
                    Vec3 from = center.add(Math.cos(a0) * rad, 5.0 + r.nextDouble() * 3.0, Math.sin(a0) * rad);
                    Vec3 to = center.add(Math.cos(a1) * rad, 1.0 + r.nextDouble() * 3.0, Math.sin(a1) * rad);
                    Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(from), Lightning.Anchor.fixed(to), AdamFx.AMBER, 0.1f, 4, 1, 2,
                            0.3));
                }
            }
            boolean alive = super.tick(level) && !(ending && fade <= 0f && age - endAge > 5);
            finished = !alive;
            return alive;
        }

        @Override
        public void renderSoft(Draw d) {
            float f = Mth.lerp(d.partialTick, fadeO, fade);
            if (f <= 0.01f) {
                return;
            }
            float sh = Mth.lerp(d.partialTick, shrinkO, shrink);
            float time = time(d.partialTick);
            int bands = 22, n = 18;
            float[] pts = new float[n * 3], w = new float[n], a = new float[n];
            for (int b = 0; b < bands; b++) {
                double start = b * Math.PI * 2.0 / bands * 2.3 + time * (0.012 + 0.004 * (b % 3));
                double height = 0.4 + (b * 0.53) % 9.0;
                double rad = (RADIUS + ((b * 1.7) % 4.0) - 2.0) * sh;
                for (int i = 0; i < n; i++) {
                    double u = i / (double) (n - 1);
                    double ang = start + u * 1.6;
                    double y = center.y + height + Math.sin(u * Math.PI * 2.0 + time * 0.05 + b) * 0.6;
                    pts[i * 3] = (float) (center.x + Math.cos(ang) * rad);
                    pts[i * 3 + 1] = (float) y;
                    pts[i * 3 + 2] = (float) (center.z + Math.sin(ang) * rad);
                    w[i] = (float) (3.2 + 1.8 * Math.sin(u * Math.PI));
                    float near = d.nearFade(pts[i * 3], pts[i * 3 + 1], pts[i * 3 + 2], 1.5, 5.0);
                    a[i] = (float) Math.sin(u * Math.PI) * 0.5f * f * near;
                }
                d.strip(pts, n, w, 1f, a, 1f, b % 3 == 0 ? AdamFx.SAND_DARK : b % 3 == 1 ? AdamFx.SAND : 0xC4A876);
            }
        }
    }

    /**
     * Bayangan Teth-Adam: siluet raksasa bertudung dari asap gelap yang menjulang di dalam badai, menatap pemain yang
     * membangunkan skarabenya dengan mata membara; lambang petir samar berdenyut di dadanya.
     */
    static final class Shade extends Effect {
        private final Vec3 c;
        private final AbstractClientPlayer watch;
        private final long seed = Vfx.random().nextLong();
        /** Besar bayangan (1 = setinggi ±6 blok). */
        private static final double S = 2.0;

        Shade(Vec3 c, AbstractClientPlayer watch, int life) {
            super(life);
            this.c = c;
            this.watch = watch;
        }

        private float alpha(float pt) {
            float t = time(pt);
            return Math.min(1f, t / 25f) * Math.min(1f, (life - t) / 30f);
        }

        /** Basis menghadap pemain: {kanan x, kanan z, ke pemain x, ke pemain z}. */
        private double[] basis(float pt) {
            Vec3 p = watch.getPosition(pt);
            double dx = p.x - c.x, dz = p.z - c.z;
            double l = Math.sqrt(dx * dx + dz * dz) + 1.0E-9;
            dx /= l;
            dz /= l;
            return new double[] {-dz, dx, dx, dz};
        }

        @Override
        public void renderSoft(Draw d) {
            float a = alpha(d.partialTick);
            if (a <= 0.01f) {
                return;
            }
            double[] b = basis(d.partialTick);
            float time = time(d.partialTick);
            Random random = new Random(seed);
            int lit = 0x2E241C, shade = 0x080604;
            // tudung (kubah meruncing), bahu lebar, badan & jubah yang menipis ke bawah: kumpulan kepulan asap
            double[][] blobs = {
                    {0, 2.5, 0.95}, {0, 3.2, 0.7}, {0, 3.7, 0.45}, {-0.55, 2.3, 0.7}, {0.55, 2.3, 0.7},
                    {-1.5, 1.45, 1.0}, {1.5, 1.45, 1.0}, {-0.7, 1.5, 1.1}, {0.7, 1.5, 1.1},
                    {0, 0.6, 1.4}, {-1.1, 0.2, 1.1}, {1.1, 0.2, 1.1}, {0, -0.8, 1.3}, {-0.9, -1.4, 1.0}, {0.9, -1.4, 1.0},
                    {0, -2.2, 1.0}};
            for (double[] blob : blobs) {
                double wob = Math.sin(time * 0.05 + random.nextDouble() * 6.0) * 0.12;
                double x = c.x + b[0] * (blob[0] + wob) * S, z = c.z + b[1] * (blob[0] + wob) * S;
                double y = c.y + (blob[1] + Math.sin(time * 0.04 + blob[0]) * 0.08) * S;
                float fall = blob[1] < -1.0 ? 0.7f : 1f;
                d.puff(x, y, z, (float) (blob[2] * 1.15 * S), lit, shade, 0.78f * a * fall);
            }
        }

        @Override
        public void renderGlow(Draw d) {
            float a = alpha(d.partialTick);
            if (a <= 0.01f) {
                return;
            }
            double[] b = basis(d.partialTick);
            float time = time(d.partialTick);
            float flicker = 0.8f + 0.2f * (float) Math.sin(time * 0.9f) + (((int) time) % 23 == 0 ? 0.3f : 0f);
            for (int s = -1; s <= 1; s += 2) {   // mata membara di dalam bayangan tudung
                double x = c.x + (b[0] * s * 0.3 + b[2] * 0.75) * S, z = c.z + (b[1] * s * 0.3 + b[3] * 0.75) * S;
                double y = c.y + 2.55 * S;
                d.glow(x, y, z, (float) (0.34 * S), AdamFx.AMBER, 0.95f * a * flicker);
                d.glow(x, y, z, (float) (0.11 * S), 0xFFF4E0, a * flicker);
                d.line(x - b[0] * 0.4 * S, y, z - b[1] * 0.4 * S, x + b[0] * 0.4 * S, y, z + b[1] * 0.4 * S, (float) (0.06 * S),
                        (float) (0.06 * S), AdamFx.AMBER_LIGHT, 0.55f * a * flicker, 0.55f * a * flicker);
            }
            // lambang petir samar di dada
            double fx = b[2] * 1.2 * S, fz = b[3] * 1.2 * S;
            double[][] bolt = {{-0.25, 1.4}, {0.15, 0.95}, {-0.1, 0.9}, {0.3, 0.3}};
            float pulse = 0.35f + 0.25f * (float) Math.sin(time * 0.15f);
            for (int i = 0; i + 1 < bolt.length; i++) {
                d.line(c.x + b[0] * bolt[i][0] * S + fx, c.y + bolt[i][1] * S, c.z + b[1] * bolt[i][0] * S + fz,
                        c.x + b[0] * bolt[i + 1][0] * S + fx, c.y + bolt[i + 1][1] * S, c.z + b[1] * bolt[i + 1][0] * S + fz,
                        (float) (0.13 * S), (float) (0.13 * S), AdamFx.AMBER, pulse * a, pulse * a);
            }
        }
    }
}
