package com.shazammod.client.fx;

import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

/**
 * 0.38 Perangkat efek sinematik Lintang (gaya film, tetap tanpa sihir): kilatan benturan singkat dengan garis pancar,
 * gelombang kejut udara berlapis yang tebal, batu & puing besar yang terlempar dengan jejak debu, kawah besar, garis
 * angin di sepanjang lintasan, dan kerucut uap sonic boom. Semuanya benturan, udara, debu, batu, dan panas.
 */
final class LintangFilm {
    static final int FLASH = 0xFFF6EA;      // kilatan benturan: putih hangat
    static final int FLASH_WARM = 0xFFC88A;
    static final int SHOCK = 0xF4F8FC;      // udara terkompresi
    static final int SHOCK_DIM = 0xC4CED8;
    static final int DUST = 0xB8AA94;
    static final Vec3 UP = new Vec3(0, 1, 0);

    private LintangFilm() {}

    // ------------------------------------------------------------------ kilatan benturan

    /**
     * Kilatan benturan ala film: kilat putih yang cuma 2-4 tick dengan garis-garis pancar pendek ke segala arah (seperti
     * "impact frame"), bukan bola cahaya yang menggantung. size = jari-jari kira-kira (blok).
     */
    static void impactFlash(Vec3 at, float size) {
        Vfx.add(new Fx.Flash(at, size, FLASH, 3, 0.85f));
        Vfx.add(new Fx.Flash(at, size * 1.7f, FLASH_WARM, 5, 0.3f));
        Vfx.add(new Starburst(at, size * 1.9f, 10 + (int) (size * 6f), 4));
    }

    /** Garis pancar kilatan benturan: memanjang cepat lalu padam dalam beberapa tick (lapisan cahaya). */
    static final class Starburst extends Effect {
        private final Vec3 at;
        private final Vec3[] dirs;
        private final float[] len;
        private final float size;

        Starburst(Vec3 at, float size, int count, int life) {
            super(life);
            this.at = at;
            this.size = size;
            RandomSource r = Vfx.random();
            int n = Math.max(4, Vfx.count(count));
            dirs = new Vec3[n];
            len = new float[n];
            for (int i = 0; i < n; i++) {
                dirs[i] = ShazamFx.randomDir(r);
                len[i] = 0.45f + r.nextFloat() * 0.75f;
            }
        }

        @Override
        public void renderGlow(Draw d) {
            float t = progress(d.partialTick);
            float grow = Mth.clamp(t * 3.2f, 0f, 1f);
            float a = (1f - t) * (1f - t);
            if (a <= 0.01f) {
                return;
            }
            for (int i = 0; i < dirs.length; i++) {
                double l = size * len[i] * (0.35 + 0.65 * grow);
                Vec3 b = at.add(dirs[i].scale(l));
                Vec3 s = at.add(dirs[i].scale(l * 0.15));
                d.line(s.x, s.y, s.z, b.x, b.y, b.z, 0.05f * size, 0f, FLASH, a * 0.9f, 0f);
            }
        }
    }

    /** 0.39 kilatan tenaga surya (Gelegar Surya, Serap Surya): kilat putih-emas singkat dengan garis pancar keemasan. */
    static void solarFlash(Vec3 at, float size) {
        Vfx.add(new Fx.Flash(at, size, 0xFFF4D6, 4, 0.9f));
        Vfx.add(new Fx.Flash(at, size * 2.0f, 0xFFC45C, 10, 0.38f));
        Vfx.add(new Starburst(at, size * 2.1f, 12 + (int) (size * 6f), 5));
    }

    /**
     * 0.39 Serap Surya: sinar matahari yang terkumpul ke badan Lintang - berkas cahaya hangat yang lembut dari langit
     * (cuma kalau langit terlihat), memudar masuk & keluar. Bukan tiang cahaya keras: tipis, tembus, keemasan.
     */
    static final class SunShaft extends Effect {
        private final net.minecraft.client.player.AbstractClientPlayer owner;

        SunShaft(net.minecraft.client.player.AbstractClientPlayer owner, int life) {
            super(life);
            this.owner = owner;
        }

        @Override
        public void renderGlow(Draw d) {
            float t = age + d.partialTick;
            float a = Mth.clamp(t / 6f, 0f, 1f) * Mth.clamp((life - t) / 6f, 0f, 1f);
            if (a <= 0.01f || !owner.isAlive()) {
                return;
            }
            double x = Mth.lerp(d.partialTick, owner.xo, owner.getX());
            double y = Mth.lerp(d.partialTick, owner.yo, owner.getY());
            double z = Mth.lerp(d.partialTick, owner.zo, owner.getZ());
            float pulse = 1f + 0.08f * Mth.sin(t * 0.5f);
            d.pillar(x, y + 0.1, z, y + 26.0, 1.3f * pulse, 0xFFD890, 0xFFF4DA, a * 0.22f);
            d.pillar(x, y + 0.1, z, y + 26.0, 0.55f, 0xFFE6B0, 0xFFFFF0, a * 0.3f);
            d.glow(x, y + 1.1, z, 1.6f, 0xFFD27A, a * 0.35f);
        }
    }

    // ------------------------------------------------------------------ gelombang kejut

    /**
     * Gelombang kejut udara berlapis: cincin uap tebal di depan, cincin tipis yang lebih cepat, dan riak tekanan samar
     * di dalamnya (lapisan soft: tembus pandang, kena cahaya dunia).
     */
    static void shockwave(Vec3 at, Vec3 normal, double radius, int life, float strength) {
        Vfx.add(new Fx.Wave(at, normal, radius, Math.max(0.22, radius * 0.075), SHOCK, life, 0.7f * strength, 0.05f, null, true));
        Vfx.add(new Fx.Wave(at, normal, radius * 0.6, Math.max(0.1, radius * 0.03), SHOCK, Math.max(4, (int) (life * 0.55f)),
                0.75f * strength, 0.02f, null, true));
        Vfx.add(new Fx.Ripple(at, normal, 0.0, radius * 0.1, radius * 0.85, Math.max(0.1, radius * 0.04), SHOCK_DIM, life,
                0.38f * strength, true));
    }

    /** Gelombang kejut yang menyapu tanah: cincin debu tebal + dinding debu bergerak di garis depannya. */
    static void groundShock(ClientLevel level, Vec3 at, double radius, int life, float strength) {
        CineKit.shock(level, at, UP, radius, 0xD8CCB8, SHOCK, life, strength * 0.75f, true, true);
    }

    // ------------------------------------------------------------------ batu, puing, kawah

    /**
     * Semburan tanah: gumpalan debu yang terlempar melengkung dari titik hantaman lalu jatuh (lapisan soft, bukan
     * butiran berkilau). Batunya sendiri dari Ground.Debris (pecahan blok tanah aslinya). speed = blok/tick.
     */
    static void dirtSprays(Vec3 g, int count, double speed, int rgb) {
        RandomSource r = Vfx.random();
        final int dust = Draw.mix(rgb, DUST, 0.3);
        for (int i = 0, n = Vfx.count(count); i < n; i++) {
            double a = r.nextDouble() * Math.PI * 2.0;
            double up = 0.35 + r.nextDouble() * 0.65;
            double s = speed * (0.5 + r.nextDouble() * 0.7);
            final double px = g.x, py = g.y + 0.2, pz = g.z;
            final double fvx = Math.cos(a) * s, fvz = Math.sin(a) * s, fvy = up * s * 1.1;
            ShazamFx.schedule(0, 8, (lvl, t) -> {
                double tt = t + 1;
                double x = px + fvx * tt, y = py + fvy * tt - 0.04 * tt * tt, z = pz + fvz * tt;
                if (y > g.y) {
                    Vfx.dust(x, y, z, fvx * 0.15, 0.0, fvz * 0.15, dust, 0.2f + 0.05f * t, 14);
                }
            });
        }
    }

    /**
     * Kawah sinematik: retakan yang menjalar (membara kalau heat), puing blok aslinya, batu besar terlempar, dinding &
     * kubah debu, asap tanah. size kira-kira 1 (mendarat) sampai 4 (hantaman raksasa).
     */
    static void crater(ClientLevel level, Vec3 at, double size, boolean heat) {
        Ground.Map map = ShazamFx.ground(level, at, 2.5 + size * 2.4);
        if (map == null || !map.found) {
            return;
        }
        Vec3 g = map.center(at);
        int dust = map.dustColor(level, at);
        RandomSource r = level.random;
        Vfx.add(new Ground.Cracks(g, map, 7 + (int) (size * 3.5), (float) (1.3 + size * 1.35), 200 + (int) (size * 30),
                heat ? 60 : 1, heat ? LintangFx.HEAT_MID : 0x2E2620, r.nextLong()));
        Vfx.add(new Ground.Debris(g, map, 8 + (int) (size * 7.0), 0.14 + size * 0.09, 0.32 + size * 0.13, 0.55 + size * 0.32, 56));
        // batu-batu yang terlempar lebih jauh & tinggi (pecahan blok tanah aslinya), dengan semburan tanah di belakangnya
        Vfx.add(new Ground.Debris(g, map, 3 + (int) (size * 3.0), 0.24 + size * 0.08, 0.5 + size * 0.16, 0.4 + size * 0.2, 70));
        dirtSprays(g, (int) (4 + size * 5), 0.22 + size * 0.07, dust);
        Vfx.add(new Fx.Wave(g, UP, 2.2 + size * 2.3, 0.8 + size * 0.35, dust, 30, 0.62f, 0f, map, true));   // dinding debu
        // kubah debu bervolume dari LintangHd (Hd.DustBurst) di animasi yang sama
        ShazamFx.dustPuffs(level, g, dust, (int) (10 + size * 9), 0.7 + size * 0.55, 0.12 + size * 0.05);
        ShazamFx.smokeCloud(level, g, dust, (int) (5 + size * 4), 0.8 + size * 0.8);
        if (heat) {
            Vfx.add(new Fx.Scorch(g, 0.8 + size * 0.7, 220, 70, map));
        }
    }

    // ------------------------------------------------------------------ angin & kecepatan

    /** Garis-garis angin putih tipis yang melesat di sepanjang lintasan from -> to (lesatan, terbang, selamatkan). */
    static void windStreaks(Vec3 from, Vec3 to, int count, int life) {
        Vec3 path = to.subtract(from);
        double len = path.length();
        if (len < 0.5) {
            return;
        }
        Vfx.add(new Streaks(from, path.scale(1.0 / len), len, Vfx.count(count), life));
    }

    static final class Streaks extends Effect {
        private final Vec3 from, dir;
        private final double len;
        private final double[] off;   // {jarak sepanjang, geser x, geser y, geser z, panjang}

        Streaks(Vec3 from, Vec3 dir, double len, int count, int life) {
            super(life);
            this.from = from;
            this.dir = dir;
            this.len = len;
            RandomSource r = Vfx.random();
            int n = Math.max(3, count);
            off = new double[n * 5];
            for (int i = 0; i < n; i++) {
                Vec3 side = ShazamFx.randomDir(r);
                side = side.subtract(dir.scale(side.dot(dir)));
                double rad = 0.25 + r.nextDouble() * 0.9;
                off[i * 5] = r.nextDouble() * len;
                off[i * 5 + 1] = side.x * rad;
                off[i * 5 + 2] = side.y * rad;
                off[i * 5 + 3] = side.z * rad;
                off[i * 5 + 4] = 1.2 + r.nextDouble() * 2.4;
            }
        }

        @Override
        public void renderSoft(Draw d) {
            float t = progress(d.partialTick);
            float a = (1f - t) * 0.55f;
            if (a <= 0.01f) {
                return;
            }
            for (int i = 0; i < off.length; i += 5) {
                double s = off[i] + t * 1.5, l = off[i + 4] * (1.0 - 0.5 * t);
                if (s > len) {
                    continue;
                }
                double s0 = Math.max(0.0, s - l);
                double x0 = from.x + dir.x * s0 + off[i + 1], y0 = from.y + dir.y * s0 + off[i + 2], z0 = from.z + dir.z * s0 + off[i + 3];
                double x1 = from.x + dir.x * s + off[i + 1], y1 = from.y + dir.y * s + off[i + 2], z1 = from.z + dir.z * s + off[i + 3];
                d.line(x0, y0, z0, x1, y1, z1, 0f, 0.035f, 0xFFFFFF, 0f, a);
            }
        }
    }

    /**
     * Kerucut uap kondensasi saat menembus kecepatan suara (efek Prandtl-Glauert, sains): kerucut putih tebal di
     * belakang badan + cincin uap yang melebar + kilatan udara singkat. dir = arah gerak.
     */
    static void vaporCone(Vec3 at, Vec3 dir, double size) {
        Vec3 back = dir.scale(-1);
        Vfx.add(new Fx.Cone(at.add(dir.scale(0.4 * size)), back, 3.6 * size, 0.95, 0xF6FAFF, 14, 0.62f, 1.7, true));
        Vfx.add(new Fx.Cone(at, back, 2.4 * size, 0.7, 0xFFFFFF, 10, 0.45f, 2.2, true));
        shockwave(at.add(back.scale(0.6)), back, 4.2 * size, 16, 1f);
        Vfx.add(new Fx.Ripple(at, back, 7.0 * size, 0.7, 3.6 * size, 0.3, SHOCK, 16, 0.55f, true));
        RandomSource r = Vfx.random();
        for (int i = 0, n = Vfx.count(14); i < n; i++) {   // uap yang tertinggal di belakang
            Vec3 o = ShazamFx.randomDir(r).scale(0.4 + r.nextDouble() * 0.8 * size);
            Vec3 p = at.add(back.scale(0.8 + r.nextDouble() * 2.0 * size)).add(o);
            Vfx.smoke(p.x, p.y, p.z, back.x * 0.05 + o.x * 0.03, o.y * 0.03, back.z * 0.05 + o.z * 0.03, 0xF4F8FC,
                    0.45f + r.nextFloat() * 0.35f, 14 + r.nextInt(8));
        }
    }
}
