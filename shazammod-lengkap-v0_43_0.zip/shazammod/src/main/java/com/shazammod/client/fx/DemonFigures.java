package com.shazammod.client.fx;

import static com.shazammod.client.fx.GodFigures.RIG;
import static com.shazammod.client.fx.GodFigures.deltoids;
import static com.shazammod.client.fx.GodFigures.dir;
import static com.shazammod.client.fx.GodFigures.godCape;
import static com.shazammod.client.fx.GodFigures.hand;
import static com.shazammod.client.fx.GodFigures.head;
import static com.shazammod.client.fx.GodFigures.leg;
import static com.shazammod.client.fx.GodFigures.lerp;
import static com.shazammod.client.fx.GodFigures.limbArm;
import static com.shazammod.client.fx.GodFigures.loop;
import static com.shazammod.client.fx.GodFigures.muscles;
import static com.shazammod.client.fx.GodFigures.smooth;
import static com.shazammod.client.fx.GodFigures.torso;

import com.shazammod.client.fx.GodFigures.Body;
import com.shazammod.client.fx.GodFigures.Pose;
import com.shazammod.client.fx.GodFigures.Rig;
import com.shazammod.client.fx.GodMesh.Frame;

/**
 * 0.30 Enam iblis pemberi kekuatan Sabbac (murni Java), dengan rangka & alat bantu yang sama dengan GodFigures. Semuanya
 * roh iblis dari api neraka: kulit gelap yang bersinar merah di tepinya, mata menyala, urat & ujung tanduk membara.
 *
 * S - Setan     : raja iblis raksasa berotot, tanduk domba besar melengkung, kepalan mengepal. (kekuatan)
 * A - Aym       : iblis obsidian berurat magma, mahkota tiga lidah api, mengangkat obor neraka. (tubuh tak tertembus)
 * B - Belial    : raja kurus berjubah panjang, tanduk tersapu ke belakang, rantai membara di lengan & di tangan. (rantai)
 * B - Beelzebub : penguasa lalat: membungkuk, mata majemuk besar, rahang capit, empat sayap serangga. (napas api)
 * A - Asmodeus  : iblis buas bertanduk tiga, rahang terbuka meraung, surai api di tengkuk. (teror)
 * C - Crateis   : iblis ramping bersayap kelelawar lebar bertepi api, rambut api berkibar. (sayap)
 *
 * Ruang dewa: lihat GodMesh (+Y atas, +Z depan, +X kiri si iblis). Ukuran dasar tinggi badan 1,9.
 */
final class DemonFigures {
    private DemonFigures() {}

    private static final Body SATAN_BODY = new Body();
    private static final Body AYM_BODY = new Body();
    private static final Body BELIAL_BODY = new Body();
    private static final Body BEELZ_BODY = new Body();
    private static final Body ASMO_BODY = new Body();
    private static final Body CRATEIS_BODY = new Body();

    static {
        Body b = SATAN_BODY;     // raksasa
        b.hip = 1.05; b.chestRx = 0.29; b.chestRz = 0.18; b.waistRx = 0.2; b.waistRz = 0.14; b.hipRx = 0.21; b.hipRz = 0.14;
        b.shoulderX = 0.275; b.limb = 1.7; b.neckR = 0.09; b.headRx = 0.105; b.headRy = 0.13; b.headRz = 0.115;

        b = AYM_BODY;            // pejuang obsidian
        b.hip = 1.02; b.chestRx = 0.225; b.chestRz = 0.148; b.waistRx = 0.17; b.waistRz = 0.12; b.hipRx = 0.18;
        b.hipRz = 0.122; b.shoulderX = 0.232; b.limb = 1.25; b.neckR = 0.07;

        b = BELIAL_BODY;         // raja kurus menjulang
        b.hip = 1.07; b.chestRx = 0.18; b.chestRz = 0.118; b.waistRx = 0.13; b.waistRz = 0.094; b.hipRx = 0.15;
        b.hipRz = 0.104; b.shoulderX = 0.205; b.limb = 0.95; b.neck = 0.095; b.neckR = 0.052;

        b = BEELZ_BODY;          // serangga membungkuk
        b.chestRx = 0.2; b.chestRz = 0.165; b.waistRx = 0.115; b.waistRz = 0.1; b.hipRx = 0.17; b.hipRz = 0.135;
        b.shoulderX = 0.2; b.limb = 0.9; b.headRx = 0.112; b.headRy = 0.11; b.headRz = 0.12;

        b = ASMO_BODY;           // buas
        b.hip = 1.03; b.chestRx = 0.27; b.chestRz = 0.172; b.waistRx = 0.19; b.waistRz = 0.132; b.hipRx = 0.2;
        b.hipRz = 0.136; b.shoulderX = 0.262; b.limb = 1.55; b.neckR = 0.09; b.headRx = 0.11;

        b = CRATEIS_BODY;        // ramping bersayap
        b.chestRx = 0.17; b.chestRz = 0.112; b.waistRx = 0.135; b.waistRz = 0.096; b.hipRx = 0.15; b.hipRz = 0.104;
        b.shoulderX = 0.19; b.limb = 1.0; b.neckR = 0.058;
    }

    // ================================================================== alat bantu iblis

    /**
     * Tanduk melengkung dari kepala (side +1 = kiri, -1 = kanan): pangkal di pelipis, ke luar sejauh out, naik setinggi
     * rise, ujungnya maju sejauh curl (negatif = tersapu ke belakang). Pangkal tebal, ujung runcing membara.
     */
    static void horn(GodMesh m, Rig r, int side, double out, double rise, double curl, double radius, int color, int tip,
                     double baseZ, int anchor) {
        Body b = r.b;
        Frame h = r.head;
        int n = 8;
        double[] pts = new double[n * 3], rad = new double[n];
        double bx = side * b.headRx * 0.62, by = r.hc + b.headRy * 0.5, bz = baseZ;
        for (int i = 0; i < n; i++) {
            double u = i / (double) (n - 1);
            double x = bx + side * out * Math.sin(u * 1.35) / Math.sin(1.35);
            double y = by + rise * (1.0 - Math.cos(u * 1.7)) / (1.0 - Math.cos(1.7));
            double z = bz + curl * u * u * u;
            h.point(x, y, z, pts, i * 3);
            rad[i] = radius * Math.pow(1.0 - u, 0.85) + 0.003;
        }
        m.mat(color, 0.95f, 0.14f).tube(pts, rad, n, 7, true, h.zx, h.zy, h.zz, 1.0);
        // gelang beralur di pangkal
        for (int k = 1; k <= 3; k++) {
            int i = k;
            double[] seg = {pts[i * 3], pts[i * 3 + 1], pts[i * 3 + 2], pts[(i + 1) * 3], pts[(i + 1) * 3 + 1], pts[(i + 1) * 3 + 2]};
            double rr = rad[i] * 1.12;
            m.mat(GodLook.lighten(color, 0.08), 0.95f, 0.12f).tube(seg, new double[] {rr, rr * 0.4}, 2, 7, false, h.zx, h.zy,
                    h.zz, 1.0);
        }
        // ujung membara
        int a = n - 3;
        m.mat(tip, 0.95f, 0.85f).spike(pts[a * 3], pts[a * 3 + 1], pts[a * 3 + 2], pts[(n - 1) * 3], pts[(n - 1) * 3 + 1],
                pts[(n - 1) * 3 + 2], rad[a] * 1.05, 6);
        if (anchor >= 0) {
            m.anchor(anchor, pts[(n - 1) * 3], pts[(n - 1) * 3 + 1], pts[(n - 1) * 3 + 2]);
        }
    }

    /** Urat bara: cincin tipis menyala melingkari dada, perut, & lengan. */
    static void veins(GodMesh m, Rig r, Body b, int color, double t) {
        m.mat(color, 0.9f, 0.75f);
        Frame ch = r.chest;
        double flick = 0.0015 * Math.sin(t * 0.5);
        loop(m, ch, b.chestLen * 0.62, b.chestRx * 1.01, b.chestRz * 1.02, 0.004, 0.006 + flick, 18);
        loop(m, ch, b.chestLen * 0.28, (b.chestRx + b.waistRx) * 0.505, (b.chestRz + b.waistRz) * 0.51, 0.003, 0.005, 16);
        loop(m, r.pelvis, -0.02, b.hipRx * 1.01, b.hipRz * 1.02, 0.0, 0.006, 16);
        double[] d = new double[3];
        for (int s = -1; s <= 1; s += 2) {
            double[] el = s > 0 ? r.elL : r.elR, wr = s > 0 ? r.wrL : r.wrR, sh = s > 0 ? r.shL : r.shR;
            for (int k = 0; k < 2; k++) {
                double[] a = k == 0 ? sh : el, c = k == 0 ? el : wr;
                dir(a, c[0], c[1], c[2], d);
                Frame f = r.f3.identity().at(lerp(0.55, a[0], c[0]), lerp(0.55, a[1], c[1]), lerp(0.55, a[2], c[2]))
                        .aim(d[0], d[1], d[2], 0, 0, 1);
                double rr = (k == 0 ? 0.058 : 0.047) * b.limb * 1.03;
                loop(m, f, 0, rr, rr, 0, 0.0055, 10);
            }
        }
    }

    /** Kain cawat gelap berumbai dari pinggang. */
    static void loincloth(GodMesh m, Rig r, Body b, int cloth, int belt, double t, double len) {
        EgyptFigures.kilt(m, r, b, cloth, belt, t, len, 0.12);
    }

    /** Sayap: fan jari tulang (tabung menyala) dengan selaput dari elips pipih; spread 0 = terlipat, 1 = terbentang. */
    static void batWings(GodMesh m, Rig r, Body b, double spread, double flap, int membrane, int bone, double size,
                         boolean anchorTips) {
        Frame w = new Frame();
        for (int s = -1; s <= 1; s += 2) {
            w.set(r.chest).move(s * 0.09, b.chestLen * 0.78, -b.chestRz * 0.92).rotX(-22);
            w.rotZ(-s * (lerp(spread, 160, 58) - flap));
            // selaput: elips pipih lebar yang saling menumpuk
            m.mat(membrane, 0.55f, 0.32f).featherFan(w, 4, Math.toRadians(lerp(spread, 24, 74)), lerp(spread, 0.52, 0.95) * size,
                    0.24 * size, 0.004);
            // tulang jari di tepi atas & ujung menyala
            Frame q = new Frame();
            for (int k = 0; k < 3; k++) {
                double u = k / 2.0 - 0.5;
                q.set(w).rotZ(Math.toDegrees(u * Math.toRadians(lerp(spread, 24, 74)) * 1.1));
                double len = lerp(spread, 0.58, 1.02) * size * (1.0 - 0.22 * Math.abs(u));
                double[] p = new double[6];
                q.point(0, 0, 0.004, p, 0);
                q.point(0, len, 0.004, p, 3);
                m.mat(bone, 0.95f, 0.7f).tube(p, new double[] {0.022 * size, 0.006}, 2, 5, true, q.zx, q.zy, q.zz, 1.0);
                if (anchorTips && k == 2) {
                    m.anchor(s > 0 ? GodMesh.EXTRA : GodMesh.EXTRA2, p[3], p[4], p[5]);
                }
            }
            m.mat(bone, 0.95f, 0.5f).ellipsoid(w, 0, 0.06, 0, 0.05, 0.09, 0.03, 7, 4);   // pangkal sayap
        }
    }

    // ================================================================== S - SETAN

    private static final int SAT_SKIN = 0x6E1A12, SAT_HORN = 0x2E2220, SAT_EMBER = 0xFF6A30, SAT_CLOTH = 0x2A1412;
    private static final int SAT_BELT = 0x8A5A2A, SAT_VEIN = 0xFF4A1E;

    static void satan(GodMesh m, Pose p) {
        Rig r = RIG;
        Body b = SATAN_BODY;
        double t = p.time, c = smooth(p.converge);
        double breath = Math.sin(t * 0.07);
        double emerge = 1.0 - smooth((p.tau - 7.0) / 7.0);   // lengan terangkat selagi menyeruak dari tanah
        r.torso(b, 0, 0.0, 0, 0, 4 + breath * 0.8 - 6 * emerge, 0, 6 - 6 * emerge, 0, 0, lerp(c, 12 - 30 * emerge, -8), 0, 0);
        r.legL(0.25, 0.07, 0.05, 0.3, 0.2, 1);
        r.legR(-0.25, 0.07, -0.03, -0.3, 0.2, 1);
        double[] aim = new double[3];
        dir(r.shR, p.aimX, p.aimY, p.aimZ, aim);
        double lx = lerp(emerge, 0.44, 0.66), ly = lerp(emerge, 0.8, 1.98), lz = lerp(emerge, 0.12, 0.08);
        r.armL(lx, ly, lz, 1, -0.4, -0.5);
        double rx = lerp(emerge, -0.44, -0.66), ry = lerp(emerge, 0.8, 1.98), rz = lerp(emerge, 0.12, 0.08);
        rx = lerp(c, rx, r.shR[0] + aim[0] * 0.62);
        ry = lerp(c, ry, r.shR[1] + aim[1] * 0.62);
        rz = lerp(c, rz, r.shR[2] + aim[2] * 0.62);
        r.armR(rx, ry, rz, -1, -0.4, -0.5);

        torso(m, r, SAT_SKIN, 0.92f, 0.1f);
        muscles(m, r, SAT_SKIN, 0.92f, 0.1f, 1.25);
        deltoids(m, r, SAT_SKIN, 0.92f, 0.1f, b.limb * 0.98);
        m.mat(SAT_SKIN, 0.92f, 0.1f);
        limbArm(m, r, true, b.limb);
        limbArm(m, r, false, b.limb);
        hand(m, r, true, 1.35, 0, 0, 1, true);
        hand(m, r, false, 1.35, 0, 0, 1, true);
        leg(m, r, true, b.limb, 0.15, 1, 0, true);
        leg(m, r, false, b.limb, -0.15, 1, 0, true);
        head(m, r, SAT_SKIN, 0.92f, 0.1f, false);
        Frame h = r.head;
        // alis menonjol & rahang lebar
        m.mat(SAT_SKIN, 0.92f, 0.08f).ellipsoid(h, 0, r.hc + 0.035, b.headRz * 0.86, b.headRx * 0.9, 0.022, 0.035, 8, 4);
        m.ellipsoid(h, 0, r.hc - 0.075, b.headRz * 0.55, b.headRx * 0.78, 0.04, 0.06, 8, 4);
        // tanduk domba besar
        horn(m, r, 1, 0.26, 0.34, 0.16, 0.05, SAT_HORN, SAT_EMBER, -0.01, GodMesh.EXTRA);
        horn(m, r, -1, 0.26, 0.34, 0.16, 0.05, SAT_HORN, SAT_EMBER, -0.01, GodMesh.EXTRA2);
        // duri di punggung atas
        for (int k = 0; k < 4; k++) {
            double[] a = new double[3], z = new double[3];
            r.chest.point(0, b.chestLen * (0.92 - k * 0.2), -b.chestRz * 0.95, a, 0);
            r.chest.point(0, b.chestLen * (0.98 - k * 0.2), -b.chestRz * 1.6, z, 0);
            m.mat(SAT_HORN, 0.95f, 0.2f).spike(a[0], a[1], a[2], z[0], z[1], z[2], 0.028, 5);
        }
        veins(m, r, b, SAT_VEIN, t);
        loincloth(m, r, b, SAT_CLOTH, SAT_BELT, t, 0.34);
        m.anchor(GodMesh.FOCUS, m.anchor[GodMesh.HAND_R * 3], m.anchor[GodMesh.HAND_R * 3 + 1], m.anchor[GodMesh.HAND_R * 3 + 2]);
        m.anchorDir(GodMesh.FOCUS, aim[0], aim[1], aim[2]);
    }

    // ================================================================== A - AYM

    private static final int AYM_SKIN = 0x2C1E30, AYM_MAGMA = 0xFF7A2A, AYM_FLAME = 0xFFB04A, AYM_WOOD = 0x2A1A14;
    private static final int AYM_CLOTH = 0x1C1418, AYM_BELT = 0x6A3A20;

    static void aym(GodMesh m, Pose p) {
        Rig r = RIG;
        Body b = AYM_BODY;
        double t = p.time, c = smooth(p.converge);
        double breath = Math.sin(t * 0.08);
        double raise = smooth((p.tau - 6.0) / 6.0);   // obor diangkat tinggi sesudah tubuhnya terbakar muncul
        r.torso(b, 0, 0.005 * breath, 0, 0, 1 + breath * 0.5, 0, -2 * raise, 0, -4, lerp(c, lerp(raise, 6, -12), -6), 0, 0);
        r.legL(0.19, 0.07, 0.08, 0.25, 0.3, 1);
        r.legR(-0.18, 0.07, -0.06, -0.25, 0.3, 1);
        double[] aim = new double[3];
        dir(r.shR, p.aimX, p.aimY, p.aimZ, aim);
        // tangan kanan memegang obor: di samping (awal), diangkat tinggi (hadir), diarahkan ke kepalan (menyatu)
        double rx = lerp(raise, -0.36, -0.42), ry = lerp(raise, 0.95, 2.02), rz = lerp(raise, 0.22, 0.12);
        rx = lerp(c, rx, r.shR[0] + aim[0] * 0.56);
        ry = lerp(c, ry, r.shR[1] + aim[1] * 0.56);
        rz = lerp(c, rz, r.shR[2] + aim[2] * 0.56);
        r.armR(rx, ry, rz, -1, -0.5, -0.3);
        // tangan kiri terbuka di depan dada, api kecil di telapak
        r.armL(0.26, 1.28, 0.34, 1, -0.6, -0.2);

        torso(m, r, AYM_SKIN, 0.93f, 0.12f);
        muscles(m, r, AYM_SKIN, 0.93f, 0.12f, 1.05);
        deltoids(m, r, AYM_SKIN, 0.93f, 0.12f, b.limb * 0.9);
        m.mat(AYM_SKIN, 0.93f, 0.12f);
        limbArm(m, r, true, b.limb);
        limbArm(m, r, false, b.limb);
        hand(m, r, false, 1.1, 0, 0, 1, true);
        hand(m, r, true, 1.05, 0, 1, 0, false);
        leg(m, r, true, b.limb, 0.15, 1, 0, true);
        leg(m, r, false, b.limb, -0.12, 1, 0, true);
        head(m, r, AYM_SKIN, 0.93f, 0.12f, false);
        // mahkota tiga lidah api
        Frame h = r.head;
        for (int k = -1; k <= 1; k++) {
            double[] a = new double[3], z = new double[3];
            h.point(k * 0.055, r.hc + b.headRy * 0.75, 0.02, a, 0);
            h.point(k * 0.09, r.hc + b.headRy * 0.75 + (k == 0 ? 0.24 : 0.17) + 0.01 * Math.sin(t * 0.6 + k), 0.0, z, 0);
            m.mat(AYM_FLAME, 0.85f, 0.9f).spike(a[0], a[1], a[2], z[0], z[1], z[2], 0.03, 6);
        }
        veins(m, r, b, AYM_MAGMA, t);
        // retakan magma di pipi & dahi
        m.mat(AYM_MAGMA, 0.9f, 0.8f).ellipsoid(h, 0, r.hc + 0.05, b.headRz * 0.95, 0.006, 0.04, 0.006, 4, 3);
        loincloth(m, r, b, AYM_CLOTH, AYM_BELT, t, 0.32);
        // obor neraka: tongkat dari genggaman kanan, kepala obor di atas
        double[] wr = r.wrR, d = new double[3];
        dir(r.elR, wr[0], wr[1], wr[2], d);
        double ux = lerp(c, 0, aim[0]), uy = lerp(c, 1, aim[1]), uz = lerp(c, 0.1, aim[2]);
        double ul = Math.sqrt(ux * ux + uy * uy + uz * uz);
        ux /= ul; uy /= ul; uz /= ul;
        double[] staff = {wr[0] - ux * 0.32, wr[1] - uy * 0.32, wr[2] - uz * 0.32, wr[0] + ux * 0.42, wr[1] + uy * 0.42,
                wr[2] + uz * 0.42};
        m.mat(AYM_WOOD, 0.95f, 0.1f).tube(staff, new double[] {0.022, 0.026}, 2, 6, true, 1, 0, 0, 1.0);
        Frame top = r.f1.identity().at(staff[3], staff[4], staff[5]).aim(ux, uy, uz, 1, 0, 0);
        m.mat(AYM_BELT, 0.95f, 0.3f).ellipsoid(top, 0, 0.0, 0, 0.045, 0.05, 0.045, 7, 5);
        m.mat(AYM_FLAME, 0.8f, 0.95f).ellipsoid(top, 0, 0.1, 0, 0.055, 0.1 + 0.012 * Math.sin(t * 0.9), 0.055, 7, 5);
        double fx = top.px(0, 0.14, 0), fy = top.py(0, 0.14, 0), fz = top.pz(0, 0.14, 0);
        m.anchor(GodMesh.EXTRA, fx, fy, fz);
        m.anchor(GodMesh.FOCUS, fx, fy, fz);
        m.anchorDir(GodMesh.FOCUS, ux, uy, uz);
        m.anchor(GodMesh.EXTRA2, m.anchor[GodMesh.HAND_L * 3], m.anchor[GodMesh.HAND_L * 3 + 1] + 0.05,
                m.anchor[GodMesh.HAND_L * 3 + 2]);
    }

    // ================================================================== B - BELIAL

    private static final int BEL_SKIN = 0x4A3A3A, BEL_ROBE = 0x2A1C22, BEL_TRIM = 0x8A2A1C, BEL_HORN = 0x241A1A;
    private static final int BEL_CHAIN = 0xFF8A3A;

    static void belial(GodMesh m, Pose p) {
        Rig r = RIG;
        Body b = BELIAL_BODY;
        double t = p.time, c = smooth(p.converge);
        double breath = Math.sin(t * 0.06);
        r.torso(b, 0, 0.004 * breath, 0, 0, 2 + breath * 0.4, 0, 4, 0, 0, lerp(c, 10, -6), 0, 0);
        r.legL(0.13, 0.07, 0.05, 0.25, 0.3, 1);
        r.legR(-0.13, 0.07, -0.02, -0.25, 0.3, 1);
        double[] aim = new double[3];
        dir(r.shR, p.aimX, p.aimY, p.aimZ, aim);
        // kedua tangan rendah di depan memegang rantai yang menjuntai; saat menyatu tangan kanan melontarkan rantainya
        r.armL(0.22, 0.98, 0.32, 1, -0.4, -0.6);
        double rx = lerp(c, -0.22, r.shR[0] + aim[0] * 0.55), ry = lerp(c, 0.98, r.shR[1] + aim[1] * 0.55);
        double rz = lerp(c, 0.32, r.shR[2] + aim[2] * 0.55);
        r.armR(rx, ry, rz, -1, -0.4, -0.6);

        torso(m, r, BEL_SKIN, 0.92f, 0.08f);
        deltoids(m, r, BEL_SKIN, 0.92f, 0.08f, b.limb * 0.85);
        m.mat(BEL_SKIN, 0.92f, 0.08f);
        limbArm(m, r, true, b.limb);
        limbArm(m, r, false, b.limb);
        hand(m, r, true, 1.0, 0, 1, 0, true);
        hand(m, r, false, 1.0, 0, 1, 0, true);
        leg(m, r, true, b.limb, 0.12, 1, 0, true);
        leg(m, r, false, b.limb, -0.1, 1, 0, true);
        head(m, r, BEL_SKIN, 0.92f, 0.08f, true);
        // tanduk tersapu panjang ke belakang
        horn(m, r, 1, 0.08, 0.16, -0.34, 0.032, BEL_HORN, BEL_CHAIN, -0.03, GodMesh.EXTRA2);
        horn(m, r, -1, 0.08, 0.16, -0.34, 0.032, BEL_HORN, BEL_CHAIN, -0.03, -1);
        // jubah raja: rok panjang sampai mata kaki + jubah di punggung
        EgyptFigures.kilt(m, r, b, BEL_ROBE, BEL_TRIM, t, 0.86, 0.32);
        godCape(m, r, BEL_ROBE, BEL_TRIM, 1.38, 0.9, 0.45, 0.0, t, 0.88f, 0.12f, 0.24);
        // rantai melilit lengan bawah
        double[] d = new double[3];
        for (int s = -1; s <= 1; s += 2) {
            double[] el = s > 0 ? r.elL : r.elR, wr = s > 0 ? r.wrL : r.wrR;
            dir(el, wr[0], wr[1], wr[2], d);
            for (int k = 0; k < 3; k++) {
                double u = 0.3 + k * 0.22;
                Frame f = r.f3.identity().at(lerp(u, el[0], wr[0]), lerp(u, el[1], wr[1]), lerp(u, el[2], wr[2]))
                        .aim(d[0], d[1], d[2], 0, 0, 1).rotX(14);
                loop(m.mat(BEL_CHAIN, 0.95f, 0.65f), f, 0, 0.052 * b.limb, 0.052 * b.limb, 0, 0.009, 10);
            }
        }
        // rantai menjuntai di antara kedua tangan (dan saat menyatu, terlontar lurus ke kepalan)
        double[] hl = {m.anchor[GodMesh.HAND_L * 3], m.anchor[GodMesh.HAND_L * 3 + 1], m.anchor[GodMesh.HAND_L * 3 + 2]};
        double[] hr = {m.anchor[GodMesh.HAND_R * 3], m.anchor[GodMesh.HAND_R * 3 + 1], m.anchor[GodMesh.HAND_R * 3 + 2]};
        int n = 12;
        double[] chain = new double[n * 3], rad = new double[n];
        double sway = Math.sin(t * 0.09) * 0.03;
        for (int i = 0; i < n; i++) {
            double u = i / (double) (n - 1);
            double sag = 0.42 * 4.0 * u * (1.0 - u) * (1.0 - c);
            chain[i * 3] = lerp(u, hl[0], hr[0]) + sway * Math.sin(u * Math.PI);
            chain[i * 3 + 1] = lerp(u, hl[1], hr[1]) - sag;
            chain[i * 3 + 2] = lerp(u, hl[2], hr[2]) + 0.06 * Math.sin(u * Math.PI);
            rad[i] = 0.016;
        }
        m.mat(BEL_CHAIN, 0.95f, 0.7f).tube(chain, rad, n, 5, true, 0, 1, 0, 1.0);
        // ujung rantai lepas yang menjuntai dari tangan kanan
        double[] tail = new double[5 * 3], tr = new double[5];
        for (int i = 0; i < 5; i++) {
            double u = i / 4.0;
            tail[i * 3] = hr[0] + lerp(c, Math.sin(t * 0.1 + u) * 0.04, aim[0] * u * 0.9);
            tail[i * 3 + 1] = hr[1] - lerp(c, u * 0.5, -aim[1] * u * 0.9);
            tail[i * 3 + 2] = hr[2] + lerp(c, 0.02 * u, aim[2] * u * 0.9);
            tr[i] = 0.015;
        }
        m.tube(tail, tr, 5, 5, true, 1, 0, 0, 1.0);
        m.anchor(GodMesh.FOCUS, tail[12], tail[13], tail[14]);
        m.anchorDir(GodMesh.FOCUS, aim[0], aim[1], aim[2]);
        m.anchor(GodMesh.EXTRA, chain[(n / 2) * 3], chain[(n / 2) * 3 + 1], chain[(n / 2) * 3 + 2]);
    }

    // ================================================================== B - BEELZEBUB

    private static final int BEE_SKIN = 0x2E3418, BEE_SHELL = 0x4A5420, BEE_EYE = 0xD8F04A, BEE_WING = 0xC8D8A0;
    private static final int BEE_FANG = 0x1E1A10;

    static void beelzebub(GodMesh m, Pose p) {
        Rig r = RIG;
        Body b = BEELZ_BODY;
        double t = p.time, c = smooth(p.converge);
        double buzz = Math.sin(t * 2.7);
        r.torso(b, 0, -0.06, 0, 0, 10, 0, 18 - 8 * c, 0, 0, lerp(c, -14, -24), 0, 0);   // membungkuk, kepala menjulur
        r.legL(0.2, 0.07, 0.1, 0.4, 0.3, 1);
        r.legR(-0.2, 0.07, -0.04, -0.4, 0.3, 1);
        double[] aim = new double[3];
        dir(r.shR, p.aimX, p.aimY, p.aimZ, aim);
        r.armL(0.3, 1.1, 0.42, 1, -0.3, -0.4);   // cakar terbuka ke depan
        double rx = lerp(c, -0.3, r.shR[0] + aim[0] * 0.5), ry = lerp(c, 1.1, r.shR[1] + aim[1] * 0.5);
        double rz = lerp(c, 0.42, r.shR[2] + aim[2] * 0.5);
        r.armR(rx, ry, rz, -1, -0.3, -0.4);

        torso(m, r, BEE_SKIN, 0.92f, 0.1f);
        // pelat kitin di dada & punggung
        m.mat(BEE_SHELL, 0.95f, 0.16f);
        for (int k = 0; k < 4; k++) {
            m.ellipsoid(r.chest, 0, b.chestLen * (0.85 - k * 0.2), b.chestRz * 0.55, b.chestRx * (0.85 - k * 0.07), 0.05,
                    b.chestRz * 0.6, 9, 4);
        }
        m.ellipsoid(r.chest, 0, b.chestLen * 0.6, -b.chestRz * 0.4, b.chestRx * 1.02, b.chestLen * 0.5, b.chestRz * 0.8, 10, 6);
        deltoids(m, r, BEE_SHELL, 0.95f, 0.16f, b.limb * 0.95);
        m.mat(BEE_SKIN, 0.92f, 0.1f);
        limbArm(m, r, true, b.limb);
        limbArm(m, r, false, b.limb);
        hand(m, r, true, 1.0, 0, 0, 1, false);
        hand(m, r, false, 1.0, 0, 0, 1, false);
        leg(m, r, true, b.limb, 0.15, 1, 0, true);
        leg(m, r, false, b.limb, -0.15, 1, 0, true);
        head(m, r, BEE_SKIN, 0.92f, 0.1f, false);
        Frame h = r.head;
        // mata majemuk besar menyala
        for (int s = -1; s <= 1; s += 2) {
            m.mat(BEE_EYE, 0.95f, 0.85f).ellipsoid(h, s * 0.062, r.hc + 0.02, b.headRz * 0.62, 0.055, 0.068, 0.05, 9, 6);
        }
        // rahang capit
        for (int s = -1; s <= 1; s += 2) {
            double[] a = new double[3], z = new double[3];
            h.point(s * 0.035, r.hc - 0.07, b.headRz * 0.8, a, 0);
            h.point(s * 0.012, r.hc - 0.14, b.headRz * 1.05, z, 0);
            m.mat(BEE_FANG, 0.95f, 0.2f).spike(a[0], a[1], a[2], z[0], z[1], z[2], 0.018, 5);
        }
        // sungut
        for (int s = -1; s <= 1; s += 2) {
            double[] q = new double[3 * 3];
            h.point(s * 0.03, r.hc + b.headRy * 0.8, b.headRz * 0.5, q, 0);
            h.point(s * 0.09, r.hc + b.headRy * 0.8 + 0.12, b.headRz * 0.9, q, 3);
            h.point(s * 0.16, r.hc + b.headRy * 0.8 + 0.16, b.headRz * 1.3, q, 6);
            m.mat(BEE_FANG, 0.95f, 0.3f).tube(q, new double[] {0.008, 0.006, 0.003}, 3, 4, true, 1, 0, 0, 1.0);
        }
        // empat sayap serangga yang bergetar
        Frame w = new Frame();
        for (int s = -1; s <= 1; s += 2) {
            for (int k = 0; k < 2; k++) {
                w.set(r.chest).move(s * 0.06, b.chestLen * (0.8 - k * 0.2), -b.chestRz * 0.95).rotX(-30 - k * 12)
                        .rotZ(-s * (118 - k * 32 + buzz * 7));
                m.mat(BEE_WING, 0.32f, 0.35f).ellipsoid(w, 0, 0.32 - k * 0.06, 0, 0.09 - k * 0.015, 0.32 - k * 0.06, 0.004, 9, 4);
            }
        }
        m.anchor(GodMesh.FOCUS, h.px(0, r.hc - 0.08, b.headRz * 1.1), h.py(0, r.hc - 0.08, b.headRz * 1.1),
                h.pz(0, r.hc - 0.08, b.headRz * 1.1));
        m.anchorDir(GodMesh.FOCUS, aim[0], aim[1], aim[2]);
        m.anchor(GodMesh.EXTRA, h.px(0, r.hc, 0), h.py(0, r.hc, 0), h.pz(0, r.hc, 0));
    }

    // ================================================================== A - ASMODEUS

    private static final int ASM_SKIN = 0x5A1C14, ASM_HORN = 0x2A1C18, ASM_FIRE = 0xFF5A2A, ASM_MAW = 0xFFB060;
    private static final int ASM_CLOTH = 0x241010, ASM_BELT = 0x5A2A18, ASM_VEIN = 0xFF3A1A;

    static void asmodeus(GodMesh m, Pose p) {
        Rig r = RIG;
        Body b = ASMO_BODY;
        double t = p.time, c = smooth(p.converge);
        double roar = 0.5 + 0.5 * Math.sin(t * 0.21);
        double land = p.tau < 6 ? 1.0 - smooth((p.tau - 4.0) / 2.0) : 0.0;
        r.torso(b, 0, -0.06 * land, 0, 0, 2 + 10 * land, 0, -4 - 4 * roar + 10 * land, 0, 0,
                lerp(c, -18 - 10 * roar, -8), 0, 0);
        r.legL(0.27, 0.07, 0.1, 0.35, 0.2, 1);
        r.legR(-0.27, 0.07, -0.06, -0.35, 0.2, 1);
        double[] aim = new double[3];
        dir(r.shR, p.aimX, p.aimY, p.aimZ, aim);
        // lengan mengembang buas, kepalan setinggi pinggang
        r.armL(0.5, 0.95, 0.18, 1, 0.2, -0.6);
        double rx = lerp(c, -0.5, r.shR[0] + aim[0] * 0.6), ry = lerp(c, 0.95, r.shR[1] + aim[1] * 0.6);
        double rz = lerp(c, 0.18, r.shR[2] + aim[2] * 0.6);
        r.armR(rx, ry, rz, -1, 0.2, -0.6);

        torso(m, r, ASM_SKIN, 0.92f, 0.1f);
        muscles(m, r, ASM_SKIN, 0.92f, 0.1f, 1.18);
        deltoids(m, r, ASM_SKIN, 0.92f, 0.1f, b.limb * 0.96);
        m.mat(ASM_SKIN, 0.92f, 0.1f);
        limbArm(m, r, true, b.limb);
        limbArm(m, r, false, b.limb);
        hand(m, r, true, 1.3, 0, 0, 1, true);
        hand(m, r, false, 1.3, 0, 0, 1, true);
        leg(m, r, true, b.limb, 0.18, 1, 0, true);
        leg(m, r, false, b.limb, -0.18, 1, 0, true);
        head(m, r, ASM_SKIN, 0.92f, 0.1f, false);
        Frame h = r.head;
        // rahang bawah terbuka meraung, mulut membara
        double jaw = 0.05 + 0.04 * roar;
        Frame j = r.f1.set(h).move(0, r.hc - 0.06, b.headRz * 0.3).rotX(18 + 22 * roar);
        m.mat(ASM_SKIN, 0.92f, 0.1f).ellipsoid(j, 0, -jaw, b.headRz * 0.4, b.headRx * 0.75, 0.035, 0.07, 8, 4);
        m.mat(ASM_MAW, 0.9f, 0.9f).ellipsoid(h, 0, r.hc - 0.07, b.headRz * 0.78, 0.045, 0.022 + 0.02 * roar, 0.02, 7, 4);
        // tiga tanduk: dua di samping, satu di dahi menunjuk ke depan
        horn(m, r, 1, 0.2, 0.2, 0.22, 0.04, ASM_HORN, ASM_FIRE, 0.0, GodMesh.EXTRA);
        horn(m, r, -1, 0.2, 0.2, 0.22, 0.04, ASM_HORN, ASM_FIRE, 0.0, GodMesh.EXTRA2);
        double[] a = new double[3], z = new double[3];
        h.point(0, r.hc + b.headRy * 0.7, b.headRz * 0.5, a, 0);
        h.point(0, r.hc + b.headRy * 0.7 + 0.18, b.headRz * 0.5 + 0.12, z, 0);
        m.mat(ASM_HORN, 0.95f, 0.16f).spike(a[0], a[1], a[2], z[0], z[1], z[2], 0.035, 6);
        // surai api di tengkuk
        for (int k = 0; k < 7; k++) {
            double u = (k - 3) / 3.0;
            h.point(u * b.headRx * 0.8, r.hc + 0.02 - Math.abs(u) * 0.05, -b.headRz * 0.8, a, 0);
            h.point(u * b.headRx * 1.3, r.hc + 0.22 - Math.abs(u) * 0.08 + 0.02 * Math.sin(t * 0.7 + k), -b.headRz * 1.6, z, 0);
            m.mat(ASM_FIRE, 0.82f, 0.9f).spike(a[0], a[1], a[2], z[0], z[1], z[2], 0.03, 5);
        }
        veins(m, r, b, ASM_VEIN, t);
        loincloth(m, r, b, ASM_CLOTH, ASM_BELT, t, 0.3);
        double mx = h.px(0, r.hc - 0.07, b.headRz * 0.95), my = h.py(0, r.hc - 0.07, b.headRz * 0.95);
        double mz = h.pz(0, r.hc - 0.07, b.headRz * 0.95);
        m.anchor(GodMesh.FOCUS, mx, my, mz);
        m.anchorDir(GodMesh.FOCUS, aim[0], aim[1], aim[2]);
    }

    // ================================================================== C - CRATEIS

    private static final int CRA_SKIN = 0x3A1838, CRA_WING = 0x6A2048, CRA_FIRE = 0xFF6A9A, CRA_HAIR = 0xFF4A6A;
    private static final int CRA_CLOTH = 0x2A1028, CRA_BELT = 0x8A3A5A;

    static void crateis(GodMesh m, Pose p) {
        Rig r = RIG;
        Body b = CRATEIS_BODY;
        double t = p.time, c = smooth(p.converge);
        double dive = p.tau < 10 ? 1.0 : 0.0;
        double settle = p.tau < 10 ? 0.0 : smooth((p.tau - 10.0) / 6.0);
        double flap = Math.sin(t * 0.25) * 10 * settle + 20 * dive;
        double bob = Math.sin(t * 0.12) * 0.03 * settle;
        r.torso(b, 0, 0.05 + bob, 0, 0, 2 + 14 * dive, 0, -2, 0, 0, lerp(c, -6, -10), 0, 0);
        r.legL(0.12, 0.12 + 0.2 * dive, 0.06, 0.25, 0.3, 1);
        r.legR(-0.1, 0.1 + 0.3 * dive, -0.1, -0.25, 0.3, 1);
        double[] aim = new double[3];
        dir(r.shR, p.aimX, p.aimY, p.aimZ, aim);
        r.armL(0.42, 1.3, 0.1, 1, -0.4, -0.4);
        double rx = lerp(c, lerp(settle, -0.4, -0.3), r.shR[0] + aim[0] * 0.56);
        double ry = lerp(c, lerp(settle, 1.3, 1.95), r.shR[1] + aim[1] * 0.56);
        double rz = lerp(c, lerp(settle, 0.1, 0.18), r.shR[2] + aim[2] * 0.56);
        r.armR(rx, ry, rz, -1, -0.5, -0.3);

        torso(m, r, CRA_SKIN, 0.9f, 0.12f);
        deltoids(m, r, CRA_SKIN, 0.9f, 0.12f, b.limb * 0.85);
        m.mat(CRA_SKIN, 0.9f, 0.12f);
        limbArm(m, r, true, b.limb);
        limbArm(m, r, false, b.limb);
        hand(m, r, true, 1.0, 0, 1, 0, false);
        hand(m, r, false, 1.0, 0, 0, 1, false);
        leg(m, r, true, b.limb, 0.12, 1, 30 * dive + 12, true);
        leg(m, r, false, b.limb, -0.1, 1, 30 * dive + 12, true);
        head(m, r, CRA_SKIN, 0.9f, 0.12f, true);
        horn(m, r, 1, 0.05, 0.12, -0.12, 0.022, CRA_SKIN, CRA_FIRE, -0.02, -1);
        horn(m, r, -1, 0.05, 0.12, -0.12, 0.022, CRA_SKIN, CRA_FIRE, -0.02, -1);
        // rambut api panjang berkibar ke belakang
        Frame h = r.head;
        for (int k = 0; k < 5; k++) {
            double u = (k - 2) / 2.0;
            double[] q = new double[4 * 3];
            for (int i = 0; i < 4; i++) {
                double v = i / 3.0;
                h.point(u * b.headRx * 0.7 * (1 - v * 0.3), r.hc + 0.08 - v * 0.38, -b.headRz * (0.7 + v * 1.4)
                        - 0.04 * Math.sin(t * 0.3 + k + v * 2.0), q, i * 3);
            }
            m.mat(CRA_HAIR, 0.8f, 0.85f).tube(q, new double[] {0.028, 0.022, 0.014, 0.003}, 4, 5, true, 1, 0, 0, 1.0);
        }
        batWings(m, r, b, lerp(dive, 1.0, 0.85), flap, CRA_WING, CRA_FIRE, 1.15, true);
        loincloth(m, r, b, CRA_CLOTH, CRA_BELT, t, 0.3);
        m.anchor(GodMesh.FOCUS, m.anchor[GodMesh.HAND_R * 3], m.anchor[GodMesh.HAND_R * 3 + 1], m.anchor[GodMesh.HAND_R * 3 + 2]);
        m.anchorDir(GodMesh.FOCUS, aim[0], aim[1], aim[2]);
    }
}
