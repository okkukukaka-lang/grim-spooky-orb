package com.shazammod.client.fx;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import com.shazammod.PassiveConditions;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

/**
 * Penangkal Petir Hidup (0.25): tiap 2 detik petir sihir menyambar dada Shazam, disusun seperti adegan di film dalam tiga
 * ketukan (dipicu animasi ROD_STRIKE dari server, suaranya ShazamSounds.ROD_STRIKE):
 *
 * 1. Petir turun (ShazamAnim.ROD_DESCENT tick): ujung petir yang bercahaya menukik dari awan sambil mencari jalan dengan
 *    percikan bercabang; badan Shazam memancarkan busur listrik ke atas menyambutnya (seperti petir sungguhan) dan listrik
 *    mulai merayap di badan.
 * 2. Hantaman: petir tebal seperti di film (0.25.1): kanal utama berinti putih panas dengan korona emas lebar, dibelit dua
 *    untai petir yang berputar seperti tali plasma, cabang-cabang panjang, dan udara terionisasi biru-putih. Petirnya bertahan
 *    dan berkedip empat kali (sambaran balik), tiang cahaya berdiri dari tanah ke langit, awan berkilat, kilatan putih & suar
 *    lensa anamorfik, cangkang energi, gelombang kejut dan busur listrik di tanah, bekas hangus, percikan. Badan tersentak
 *    (kepala mendongak, lengan terbuka), listrik melilit badan berbentuk spiral, mata dan lambang menyala putih, dan dua
 *    cincin cahaya naik dari kaki ke kepala: energi, darah, dan armor pulih.
 * 3. Sisa: listrik merayap di badan, kepalan berlistrik (Pukulan Guntur siap, lihat ChampionFx), bara & debu tipis.
 *
 * Dari sudut pandang orang pertama semuanya diredam (bagian petir yang dekat kamera memudar, kilatan layar kecil) supaya
 * layar nggak tertutup tiap 2 detik.
 */
public final class RodStrikeFx {
    private RodStrikeFx() {}

    // ======= Angka yang gampang diutak-atik =======
    /** Petir datang dari langit setinggi ini (blok) di atas dada. */
    private static final double HEIGHT = 64.0;
    /** Pangkal petir bergeser paling jauh segini (blok) dari tegak lurus, jadi petirnya sedikit miring seperti di film. */
    private static final double SLANT = 9.0;
    /** Tebal petir (petir sihir biasa = 1, petir transformasi SHAZAM! = 2,4). */
    private static final float SIZE = 2.0f;
    /** Untai petir tambahan yang membelit kanal utama (kesan tebal seperti tali plasma di film), 0 = mati. */
    private static final int STRANDS = 2;
    /** Lama listrik melilit badan berbentuk spiral sesudah hantaman (tick), 0 = mati. */
    private static final int COCOON_TICKS = 12;
    /** Lama mata & lambang menyala putih sesudah tersambar (tick). */
    private static final int GLOW_TICKS = 18;
    /** Kilatan layar saat diri sendiri tersambar: orang ketiga / orang pertama (0 = mati). */
    private static final float SELF_FLASH = 0.3f;
    private static final float SELF_FLASH_FIRST_PERSON = 0.12f;
    /** Titik sambaran: lambang di dada (blok di atas kaki, dikali ukuran badan). */
    private static final double CHEST = 1.25;
    // =========================================================================

    /** 0.28: warna petir ikut juaranya (Shazam emas, Black Adam jingga membara). */
    private record Palette(int gold, int light, int ion, int flash) {}

    private static final Palette SHAZAM = new Palette(0xFFC24A, 0xFFE7A8, 0xB8D8FF, 0xFFF6DC);   // emas, udara biru-putih
    private static final Palette ADAM = new Palette(AdamFx.AMBER, AdamFx.AMBER_LIGHT, 0xFFB088, 0xFFE8C8);   // jingga membara

    private static Palette palette(AbstractClientPlayer player) {
        return ShazamClientState.isAdam(player.getId()) ? ADAM : SHAZAM;
    }
    private static final Vec3 UP = new Vec3(0, 1, 0);
    private static final int STRIKE_LIFE = 16;       // petir menyala selama ini sesudah menghantam (tick): 4 sambaran balik

    private static final Map<Integer, Long> LAST_HIT = new HashMap<>();   // tick hantaman terakhir tiap pemain

    public static void clear() {
        LAST_HIT.clear();
    }

    public static void tick(ClientLevel level) {
        long now = level.getGameTime();
        LAST_HIT.values().removeIf(hit -> now - hit > 60L);
    }

    /**
     * 0.29 ROD_FADE: petir Shazam padam (gurun / es & salju / Nether). Mata & lambang berkilat untuk terakhir kali lalu meredup,
     * listrik di badan tersendat dalam tiga gelombang yang makin lemah, sisa listrik dibuang ke tanah, percikan sekarat
     * berjatuhan, dan beberapa kedipan terakhir. Jejaknya ikut tempatnya: gurun berdebu pasir, es berembun beku berkilau,
     * Nether berasap & berabu.
     */
    public static void fade(AbstractClientPlayer caster, boolean self) {
        boolean first = firstPerson(caster);
        PassiveConditions.Block why = PassiveConditions.lightningBlock(caster.level(), caster.blockPosition());
        int ticks = ShazamAnim.ROD_FADE_TICKS;
        markHit(caster);
        float[] waves = {1f, 0.55f, 0.25f};
        for (int i = 0; i < waves.length; i++) {
            float strength = waves[i] * (first ? 0.25f : 1f);
            ShazamFx.schedule(i * 7, 1, (level, t) -> {
                Lightning.Crackle crackle = new Lightning.Crackle(caster, ShazamFx.STORM, 2.2f, 0.05f, 6).reach(1.0);
                crackle.strength(strength);
                Vfx.add(crackle);
            });
        }
        ShazamFx.schedule(0, ticks, (level, t) -> {
            if (!caster.isAlive()) {
                return;
            }
            Vec3 feet = caster.position();
            RandomSource r = level.random;
            if (t < 6) {   // sisa listrik dibuang ke tanah
                double a = r.nextDouble() * Math.PI * 2.0;
                Vfx.add(new Lightning.Arc(Lightning.Anchor.on(caster, 0, 1.0 * caster.getScale(), 0),
                        Lightning.Anchor.fixed(feet.add(Math.cos(a) * 1.2, 0.05, Math.sin(a) * 1.2)), ShazamFx.STORM,
                        first ? 0.025f : 0.05f, 3, 1, 1, 0.3));
            }
            if (t >= 18 && t % 3 == 0 && r.nextBoolean()) {   // kedipan terakhir yang tersendat
                Vfx.add(new Lightning.Arc(
                        Lightning.Anchor.on(caster, (r.nextDouble() - 0.5) * 0.6, 0.8 + r.nextDouble() * 0.8, (r.nextDouble() - 0.5) * 0.4),
                        Lightning.Anchor.on(caster, (r.nextDouble() - 0.5) * 0.8, 0.5 + r.nextDouble() * 1.0, (r.nextDouble() - 0.5) * 0.4),
                        ShazamFx.STORM, 0.03f, 2, 1, 0, 0.35));
            }
            if (t % 2 == 0) {   // percikan sekarat berjatuhan
                Vec3 p = feet.add((r.nextDouble() - 0.5) * 0.8, 0.6 + r.nextDouble() * 1.2, (r.nextDouble() - 0.5) * 0.8);
                Vfx.spark(p.x, p.y, p.z, (r.nextDouble() - 0.5) * 0.05, 0.02, (r.nextDouble() - 0.5) * 0.05, ShazamFx.GOLD_LIGHT,
                        0.05f, 10 + r.nextInt(6), feet.y);
            }
            if (t % 3 == 0) {   // jejak tempatnya
                double ox = (r.nextDouble() - 0.5) * 1.2, oz = (r.nextDouble() - 0.5) * 1.2;
                switch (why) {
                    case DESERT -> Vfx.dust(feet.x + ox, feet.y + 0.1, feet.z + oz, ox * 0.05, 0.04, oz * 0.05, 0xD9C08A, 0.4f, 18);
                    case ICE -> {
                        Vfx.smoke(feet.x + ox, feet.y + 0.6 + r.nextDouble(), feet.z + oz, 0, 0.02, 0, 0xDDEEFF, 0.45f, 26);
                        Vfx.glint(feet.x + ox * 0.6, feet.y + 0.4 + r.nextDouble() * 1.4, feet.z + oz * 0.6, 0xCFEFFF, 0.12f, 8);
                    }
                    case NETHER -> {
                        Vfx.smoke(feet.x + ox, feet.y + 0.6 + r.nextDouble(), feet.z + oz, 0, 0.03, 0, 0x2A2220, 0.5f, 26);
                        Vfx.ember(feet.x + ox, feet.y + 0.3, feet.z + oz, 0, 0.05, 0, 0.04f, 14);
                    }
                    default -> { }
                }
            }
        });
        if (self) {
            ScreenFx.vignette(0.3f, 0x0A1018, ticks);
        }
    }

    /** 0.28.1: tandai 'tersambar' tanpa petir (denyut Cakram Aton Black Adam): mata & lambang ikut menyala. */
    public static void markHit(AbstractClientPlayer player) {
        LAST_HIT.put(player.getId(), player.level().getGameTime());
    }

    /** 0-1: mata dan lambang menyala putih sesudah tersambar (dipakai ShazamEyesLayer & ShazamEmblemLayer). */
    public static float glow(AbstractClientPlayer player, float partialTick) {
        Long hit = LAST_HIT.get(player.getId());
        if (hit == null) {
            return 0f;
        }
        float t = player.level().getGameTime() - hit + partialTick;
        if (t < 0f || t >= GLOW_TICKS) {
            return 0f;
        }
        if (t < 1.5f) {
            return t / 1.5f;
        }
        float k = 1f - (t - 1.5f) / (GLOW_TICKS - 1.5f);
        return k * k;
    }

    private static boolean firstPerson(AbstractClientPlayer player) {
        Minecraft mc = Minecraft.getInstance();
        return player == mc.player && mc.options.getCameraType().isFirstPerson();
    }

    /** Animasi ROD_STRIKE: petir mulai turun sekarang dan menghantam ROD_DESCENT tick lagi. */
    public static void strike(AbstractClientPlayer caster, boolean self) {
        Palette pal = palette(caster);
        Lightning.Anchor chest = pt -> caster.getPosition(pt).add(0, CHEST * caster.getScale(), 0);
        long seed = Vfx.random().nextLong();
        Random random = new Random(seed);
        double angle = random.nextDouble() * Math.PI * 2.0;
        double slant = SLANT * (0.35 + random.nextDouble() * 0.65);
        Vec3 offset = new Vec3(Math.cos(angle) * slant, HEIGHT, Math.sin(angle) * slant);
        Vfx.add(new Bolt(caster, chest, offset, seed, pal));
        int descent = ShazamAnim.ROD_DESCENT;
        boolean first = firstPerson(caster);
        // 1) petir turun: badan menyambutnya dengan busur listrik ke atas, listrik mulai merayap di badan
        ShazamFx.schedule(0, descent, (level, t) -> {
            Lightning.Anchor crown = pt -> chest.at(pt).add(0, 0.5 * caster.getScale(), 0);
            Vec3 c = crown.at(1f);
            for (int k = 0; k < 2; k++) {
                Vec3 tip = c.add((level.random.nextDouble() - 0.5) * 1.0, 0.6 + level.random.nextDouble() * (0.5 + t * 0.4),
                        (level.random.nextDouble() - 0.5) * 1.0);
                Vfx.add(new Lightning.Arc(crown, Lightning.Anchor.fixed(tip), pal.light, first ? 0.025f : 0.045f, 2, 1, 1, 0.3));
            }
            if (t == 0) {
                Lightning.Crackle crackle = new Lightning.Crackle(caster, ShazamFx.STORM, 1.0f, 0.04f, descent + 4).reach(0.8);
                crackle.strength(first ? 0.2f : 0.8f);
                Vfx.add(crackle);
            }
        });
        // 2) hantaman: tepat di tick kekuatannya masuk di server (dan retakan di SFX-nya)
        ShazamFx.schedule(descent, 1, (level, t) -> impact(level, caster, chest, self, pal));
        // 3) listrik melilit badan berbentuk spiral, naik dari kaki ke kepala (seperti Billy diselubungi petir di film)
        if (COCOON_TICKS > 0) {
            ShazamFx.schedule(descent, COCOON_TICKS, (level, t) -> {
                if (!caster.isAlive()) {
                    return;
                }
                double sc = caster.getScale();
                float fade = 1f - t / (float) COCOON_TICKS;
                for (int k = 0; k < 3; k++) {
                    double ang = t * 0.95 + k * (Math.PI * 2.0 / 3.0);
                    double h = ((t * 0.16 + k / 3.0) % 1.0) * 1.9 * sc;
                    double r = 0.55 * sc;
                    double h2 = Math.min(2.05 * sc, h + 0.5 * sc);
                    Lightning.Anchor from = pt -> caster.getPosition(pt).add(Math.cos(ang) * r, h, Math.sin(ang) * r);
                    Lightning.Anchor to = pt -> caster.getPosition(pt).add(Math.cos(ang + 1.4) * r, h2, Math.sin(ang + 1.4) * r);
                    Vfx.add(new Lightning.Arc(from, to, k == 0 ? 0xFFFFFF : pal.light, (first ? 0.03f : 0.075f) * (0.5f + 0.5f * fade),
                            2, 1, 1, 0.3));
                }
            });
        }
    }

    private static void impact(ClientLevel level, AbstractClientPlayer caster, Lightning.Anchor chestAnchor, boolean self,
                               Palette pal) {
        if (!caster.isAlive()) {
            return;
        }
        boolean first = firstPerson(caster);
        float k = first ? 0.35f : 1f;   // orang pertama: diredam supaya layar nggak tertutup
        float scale = caster.getScale();
        Vec3 c = caster.position();
        Vec3 chest = chestAnchor.at(1f);
        Vec3 core = first ? c.add(0, 0.35, 0) : chest;   // orang pertama: kilatan di kaki, bukan tepat di bawah kamera
        LAST_HIT.put(caster.getId(), level.getGameTime());
        ShazamPoses.surge(caster);
        level.setSkyFlashTime(2);   // awan berkilat
        // kilatan inti putih, pendar emas, dan suar lensa anamorfik di lambang
        Vfx.add(new Fx.Flash(core, 1.0f + 2.2f * k, 0xFFFFFF, 8, 1f));
        Vfx.add(new Fx.Flash(core, 1.4f + 3.2f * k, pal.gold, 14, 0.9f));
        CineFx.flareAt(first ? Lightning.Anchor.fixed(core) : chestAnchor, pal.flash, 4f + 8f * k, 0.07f + 0.12f * k, k, 14);
        Vfx.add(new Fx.Bubble(chest, 2.2 * scale, ShazamFx.WHITE_HOT, 9, 0.65f * k, 1.0, 2.6, true));   // cangkang energi
        // tiang cahaya dari tanah ke langit: sambarannya terasa sebesar di film (orang pertama: tipis, nggak menutup layar)
        Vfx.add(new Fx.Pillar(c, 70.0, (first ? 0.6f : 1.5f) * scale, pal.light, 12));
        // dua cincin cahaya naik dari kaki ke kepala: kekuatan petir mengalir ke seluruh badan (energi, darah, armor pulih)
        Vfx.add(new Fx.Ripple(c.add(0, 0.05, 0), UP, 2.1 * scale, 0.55, 0.8, 0.14, pal.light, 12, first ? 0.45f : 0.9f, false));
        Vfx.add(new Fx.Ripple(c.add(0, 0.05, 0), UP, 2.1 * scale, 0.75, 1.05, 0.08, pal.ion, 9, first ? 0.3f : 0.6f, false));
        // sisa: listrik merayap di badan (lebih rapat & tebal)
        Lightning.Crackle crackle = new Lightning.Crackle(caster, pal.light, 2.6f, 0.08f, 32).reach(1.1);
        crackle.strength(first ? 0.2f : 1f);
        Vfx.add(crackle);
        // di tanah (kalau berdiri atau melayang rendah): gelombang kejut, debu, bekas hangus, busur listrik
        Ground.Map map = ShazamFx.ground(level, c, 3.0);
        if (map != null && map.found && c.y - map.centerY < 2.0) {
            Vec3 g = map.center(c);
            int dust = map.dustColor(level, c);
            Vfx.add(new Fx.Wave(g, UP, 5.0, 0.22, 0xFFFFFF, 8, 0.95f, 0f, map));
            Vfx.add(new Fx.Wave(g, UP, 4.2, 0.42, pal.gold, 13, 0.9f, 0.12f, map));
            Vfx.add(new Fx.Wave(g, UP, 3.8, 1.0, dust, 24, 0.55f, 0f, map, true));
            Vfx.add(new Fx.Scorch(g, 1.1, 100, 16, map));
            ShazamFx.groundArcs(level, c, 9, 4.0, pal.gold, 6);
            ShazamFx.dustPuffs(level, g, dust, 10, 1.3, 0.12);
        }
        ShazamFx.ringOfSparks(level, chest, 34, pal.light, 0.45);
        for (int i = 0, n = Vfx.count(8); i < n; i++) {
            Vec3 d = ShazamFx.randomDir(level.random).scale(0.3 * scale);
            Vfx.ember(chest.x + d.x, chest.y + d.y, chest.z + d.z, 0, 0.03 + level.random.nextDouble() * 0.03, 0, 0.06f,
                    16 + level.random.nextInt(10));
        }
        ShazamFx.shakeAround(c, 0.4f, 24);
        if (self) {
            ScreenFlash.flash(first ? SELF_FLASH_FIRST_PERSON : SELF_FLASH, pal.flash);
            FovKick.punch(-0.035f);
        }
    }

    /**
     * Petir yang menyambar dada dan ikut bergerak bersama Shazam (walau sedang terbang kencang): turun dulu (ujungnya
     * bercahaya dan memercik mencari jalan), lalu tebal menyambung dan berkedip. Jalur utamanya sama dari awal turun sampai
     * padam, jadi saat menyambar bentuknya menyambung; cabang-cabangnya berganti tiap 2 tick.
     */
    private static final class Bolt extends Effect {
        private final AbstractClientPlayer owner;
        private final Lightning.Anchor target;
        private final Vec3 offset;
        private final long seed;
        private final Palette pal;

        Bolt(AbstractClientPlayer owner, Lightning.Anchor target, Vec3 offset, long seed, Palette pal) {
            super(ShazamAnim.ROD_DESCENT + STRIKE_LIFE);
            this.pal = pal;
            this.owner = owner;
            this.target = target;
            this.offset = offset;
            this.seed = seed;
        }

        @Override
        public boolean tick(ClientLevel level) {
            return owner.isAlive() && super.tick(level);
        }

        /** Terang petir sesudah menghantam: empat sambaran balik (tick 0, 3, 6, 9) yang tetap tebal, lalu padam. */
        private static float flicker(float s) {
            if (s > STRIKE_LIFE - 1) {
                return 0f;
            }
            float fade = 1f - Math.max(0f, s - 9f) / (STRIKE_LIFE - 10f);
            int step = (int) s;
            float stroke = step % 3 == 0 && step <= 9 ? 1f : step % 3 == 1 ? 0.62f : 0.4f;
            return Math.max(0f, fade) * stroke;
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float time = age + pt;
            int descent = ShazamAnim.ROD_DESCENT;
            Vec3 hit = target.at(pt);
            Vec3 top = hit.add(offset);
            float[] main = Lightning.path(top.x, top.y, top.z, hit.x, hit.y, hit.z, 6, 0.085, new Random(seed));
            int n = main.length / 3;
            boolean first = firstPerson(owner);
            if (time < descent) {
                descend(d, main, n, time / descent, time, first);
                return;
            }
            float s = time - descent;
            float a = flicker(s);
            if (a <= 0.01f) {
                return;
            }
            // lebar & kekuatan per titik: bagian yang lewat dekat kamera memudar (orang pertama nggak tertutup petir)
            float[] w = new float[n], glowW = new float[n], body = new float[n], glowA = new float[n], ionA = new float[n];
            for (int i = 0; i < n; i++) {
                float near = d.nearFade(main[i * 3], main[i * 3 + 1], main[i * 3 + 2], 1.0, first ? 5.0 : 2.5);
                float f = i / (float) (n - 1);
                w[i] = SIZE * (1.0f + 0.25f * f);   // sedikit menebal ke arah sasaran
                glowW[i] = w[i] * 2.9f;
                body[i] = a * near;
                glowA[i] = a * near * 0.24f;
                ionA[i] = a * near;
            }
            float old = d.body(0.3f);   // udara terionisasi: pendar biru-putih yang lebar
            d.strip(main, n, w, 4.2f, ionA, 0.12f, pal.ion);
            d.body(0.15f);              // korona emas sangat lebar: petirnya terasa menyilaukan seperti di film
            d.strip(main, n, w, 7.5f, ionA, 0.07f, pal.light);
            d.body(old);
            d.polyline(main, n, glowW, glowA, pal.gold, pal.gold);
            d.polyline(main, n, w, body, pal.gold, 0xFFFFFF);
            // dua untai petir membelit kanal utama dan berputar (tali plasma), menyatu di titik sambaran
            if (STRANDS > 0) {
                Vec3 axis = hit.subtract(top).normalize();
                Vec3 e1 = axis.cross(Math.abs(axis.x) < 0.9 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0)).normalize();
                Vec3 e2 = axis.cross(e1);
                float[] sw = new float[n], sa = new float[n];
                for (int k = 0; k < STRANDS; k++) {
                    Random jr = new Random(seed * 13L + k * 101L + (long) (s / 2f) * 7L);
                    double phase = k * Math.PI * 2.0 / STRANDS + time * 0.9;
                    float[] strand = new float[n * 3];
                    for (int i = 0; i < n; i++) {
                        double f = i / (double) (n - 1);
                        double r = SIZE * (0.26 + 0.14 * jr.nextDouble()) * (1.0 - 0.75 * f * f);
                        double ang = phase + i * 0.55;
                        double ox = (e1.x * Math.cos(ang) + e2.x * Math.sin(ang)) * r;
                        double oy = (e1.y * Math.cos(ang) + e2.y * Math.sin(ang)) * r;
                        double oz = (e1.z * Math.cos(ang) + e2.z * Math.sin(ang)) * r;
                        strand[i * 3] = (float) (main[i * 3] + ox);
                        strand[i * 3 + 1] = (float) (main[i * 3 + 1] + oy);
                        strand[i * 3 + 2] = (float) (main[i * 3 + 2] + oz);
                        sw[i] = 0.38f * SIZE * (1f - 0.5f * (float) f);
                        sa[i] = body[i] * 0.75f;
                    }
                    d.polyline(strand, n, sw, sa, pal.light, 0xFFFFFF);
                }
            }
            // cabang-cabang yang berganti tiap 2 tick
            Random random = new Random(seed * 31L + (long) (s / 2f) * 977L);
            int branches = 4 + (int) (SIZE * 2f);
            for (int b = 0; b < branches; b++) {
                int i = 4 + random.nextInt(Math.max(1, n - 14));
                double sx = main[i * 3], sy = main[i * 3 + 1], sz = main[i * 3 + 2];
                double len = (4.0 + random.nextDouble() * 8.0) * SIZE;
                double ex = sx + (random.nextDouble() - 0.5) * len * 1.2, ey = sy - len * (0.55 + random.nextDouble() * 0.4),
                        ez = sz + (random.nextDouble() - 0.5) * len * 1.2;
                float[] br = Lightning.path(sx, sy, sz, ex, ey, ez, len > 10.0 ? 5 : 4, 0.16, random);
                float bn = d.nearFade(sx, sy, sz, 1.5, 5.0);
                d.polyline(br, br.length / 3, 0.5f * SIZE, 0.08f * SIZE, pal.gold, 0xFFFFFF, a * 0.85f * bn, 0f);
                if (b % 2 == 0) {   // cabang bercabang lagi: petirnya terlihat rimbun
                    int j = 2 + random.nextInt(Math.max(1, br.length / 3 - 4));
                    double qx = br[j * 3], qy = br[j * 3 + 1], qz = br[j * 3 + 2];
                    float[] tw = Lightning.path(qx, qy, qz, qx + (random.nextDouble() - 0.5) * len * 0.6,
                            qy - len * 0.35, qz + (random.nextDouble() - 0.5) * len * 0.6, 3, 0.2, random);
                    d.polyline(tw, tw.length / 3, 0.22f * SIZE, 0.04f * SIZE, pal.gold, pal.light, a * 0.6f * bn, 0f);
                }
            }
            // awan berkilat di pangkal, cahaya di titik sambaran (lambang)
            d.glow(top.x, top.y - 4, top.z, 12f * SIZE, pal.light, a * 0.25f);
            float hitFade = d.nearFade(hit.x, hit.y, hit.z, 0.8, 3.0);
            d.flare(hit.x, hit.y, hit.z, 1.5f * SIZE, pal.gold, a * hitFade);
        }

        /** Petir sedang turun: jalur dari langit sampai ujungnya saja; ujung bercahaya yang memercik mencari jalan. */
        private void descend(Draw d, float[] main, int n, float progress, float time, boolean first) {
            float reach = (float) Math.pow(Math.max(0f, Math.min(1f, progress)), 1.35);
            int shown = Math.max(2, (int) Math.ceil(reach * (n - 1)) + 1);
            float[] part = new float[shown * 3];
            System.arraycopy(main, 0, part, 0, shown * 3);
            float f = reach * (n - 1) - (shown - 2);
            int last = (shown - 1) * 3, prev = (shown - 2) * 3;
            if (shown < n) {
                for (int k = 0; k < 3; k++) {
                    part[last + k] = main[prev + k] + (main[last + k] - main[prev + k]) * Math.max(0f, Math.min(1f, f));
                }
            }
            float pulse = 0.75f + 0.25f * (float) Math.sin(time * 2.2f);
            double tx = part[last], ty = part[last + 1], tz = part[last + 2];
            float near = d.nearFade(tx, ty, tz, 1.0, first ? 5.0 : 2.5);
            d.polyline(part, shown, 2.0f * SIZE, 1.5f * SIZE, pal.gold, pal.gold, 0.18f * pulse, 0.25f * pulse * near);
            d.polyline(part, shown, 0.6f * SIZE, 0.55f * SIZE, pal.gold, 0xFFFFFF, 0.9f * pulse, pulse * near);
            d.flare(tx, ty, tz, 1.3f * SIZE * pulse, pal.light, 0.9f * near);
            Random sparks = new Random(seed * 17L + (long) time);
            for (int b = 0; b < 3; b++) {   // percikan bercabang dari ujung, mencari jalan ke bawah
                double ex = tx + (sparks.nextDouble() - 0.5) * 2.0 * SIZE, ey = ty - (0.8 + sparks.nextDouble() * 1.4) * SIZE,
                        ez = tz + (sparks.nextDouble() - 0.5) * 2.0 * SIZE;
                float[] br = Lightning.path(tx, ty, tz, ex, ey, ez, 3, 0.3, sparks);
                d.polyline(br, br.length / 3, 0.18f * SIZE, 0.04f * SIZE, pal.gold, 0xFFFFFF, 0.9f * pulse * near, 0f);
            }
        }
    }
}
