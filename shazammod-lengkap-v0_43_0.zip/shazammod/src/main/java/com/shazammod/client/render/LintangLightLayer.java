package com.shazammod.client.render;

import org.joml.Vector3f;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamMod;

import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.PlayerSkin;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * 0.42 Lintang tanpa kostum (kulit asli pemain yang terlihat): di kedua bahunya menyala "matahari bahu" - cakram cahaya
 * kecil dengan kipas sinar keemasan yang memancar ke atas & ke samping, berdenyut dan bergeser pelan. Sinarnya dua
 * bidang bersilang supaya tetap bervolume dari arah mana pun. Jubah cahayanya digambar ShazamCape, lambang matahari di
 * dada oleh ShazamEmblemLayer.
 */
public class LintangLightLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation WHITE = ShazamMod.id("textures/entity/shazam_white.png");
    private static final int RAYS = 9;

    public LintangLightLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    public static boolean active(AbstractClientPlayer player) {
        return !player.isInvisible() && ShazamClientState.isTransformed(player.getId()) && ShazamClientState.isLintang(player.getId());
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buffers, int light, AbstractClientPlayer player, float limbSwing,
                       float limbAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        try {
            if (!active(player)) {
                return;
            }
            PlayerModel<AbstractClientPlayer> m = getParentModel();
            boolean slim = player.getSkin().model() == PlayerSkin.Model.SLIM;
            VertexConsumer glow = buffers.getBuffer(RenderType.eyes(WHITE));
            shoulder(m.rightArm, ps, glow, ageInTicks, -1f, slim ? -0.5f : -1f, player.getId());
            shoulder(m.leftArm, ps, glow, ageInTicks, 1f, slim ? 0.5f : 1f, player.getId() + 7);
        } catch (Throwable ignored) {
            // lapisan cahaya nggak boleh bikin game crash
        }
    }

    /** side = -1 bahu kanan (sinar ke -x), +1 bahu kiri. cx = tengah atas lengan (piksel). */
    private static void shoulder(ModelPart arm, PoseStack ps, VertexConsumer vc, float t, float side, float cx, int seed) {
        if (!arm.visible) {
            return;
        }
        ps.pushPose();
        arm.translateAndRotate(ps);
        ps.scale(1f / 16f, 1f / 16f, 1f / 16f);
        PoseStack.Pose pose = ps.last();
        float ox = cx, oy = -2.3f, oz = 0f;
        float wob = 6f * Mth.sin(t * 0.05f + seed);
        for (int i = 0; i < RAYS; i++) {   // kipas di bidang depan: dari atas-dalam, ke atas, sampai menyamping ke bawah
            float phi = (-35f + 140f * i / (RAYS - 1) + wob) * Mth.DEG_TO_RAD;
            float dx = side * Mth.sin(phi), dy = -Mth.cos(phi);
            float pulse = 0.78f + 0.22f * Mth.sin(t * 0.25f + i * 1.3f + seed);
            float len = (i % 2 == 0 ? 4.2f : 2.8f) * pulse;
            ray(vc, pose, ox + dx * 1.4f, oy + dy * 1.4f, oz, dx, dy, 0f, len, 0.55f, i % 2 == 0 ? 0.9f : 0.7f);
        }
        for (int i = 0; i < 4; i++) {   // beberapa sinar ke depan & belakang bahu (volume)
            float psi = (-55f + 110f * i / 3f) * Mth.DEG_TO_RAD;
            float dy = -Mth.cos(psi), dz = Mth.sin(psi);
            float pulse = 0.75f + 0.25f * Mth.sin(t * 0.3f + i * 2.1f + seed);
            ray(vc, pose, ox, oy + dy * 1.2f, oz + dz * 1.2f, side * 0.25f, dy, dz, 2.6f * pulse, 0.45f, 0.6f);
        }
        float k = 0.8f + 0.2f * Mth.sin(t * 0.4f + seed);
        disc(vc, pose, ox, oy, oz, 1.35f * k, 0.95f);   // cakram matahari kecil di bahu
        disc(vc, pose, ox, oy, oz, 2.6f * k, 0.3f);
        ps.popPose();
    }

    /** Satu sinar: dua segi empat bersilang yang meruncing dari pangkal (putih-emas) ke ujung (jingga, padam). */
    private static void ray(VertexConsumer vc, PoseStack.Pose pose, float x, float y, float z, float dx, float dy, float dz,
                            float len, float width, float a) {
        float l = Mth.sqrt(dx * dx + dy * dy + dz * dz);
        if (l < 1.0E-4f) {
            return;
        }
        dx /= l;
        dy /= l;
        dz /= l;
        Vector3f d = new Vector3f(dx, dy, dz);
        Vector3f p1 = Math.abs(dz) < 0.9f ? new Vector3f(d).cross(0f, 0f, 1f) : new Vector3f(d).cross(1f, 0f, 0f);
        p1.normalize();
        Vector3f p2 = new Vector3f(d).cross(p1).normalize();
        float ex = x + dx * len, ey = y + dy * len, ez = z + dz * len;
        int ab = (int) (Mth.clamp(a, 0f, 1f) * 255f);
        for (Vector3f p : new Vector3f[] {p1, p2}) {
            float wx = p.x * width, wy = p.y * width, wz = p.z * width;
            quad(vc, pose, x - wx, y - wy, z - wz, x + wx, y + wy, z + wz, ex + wx * 0.12f, ey + wy * 0.12f, ez + wz * 0.12f,
                    ex - wx * 0.12f, ey - wy * 0.12f, ez - wz * 0.12f, 255, 236, 186, ab, 255, 150, 50, 0);
        }
    }

    /** Cakram cahaya kecil (dua bidang bersilang), terang di tengah. */
    private static void disc(VertexConsumer vc, PoseStack.Pose pose, float x, float y, float z, float r, float a) {
        int ab = (int) (Mth.clamp(a, 0f, 1f) * 255f);
        int seg = 10;
        for (int plane = 0; plane < 2; plane++) {
            for (int k = 0; k < seg; k++) {
                float a0 = (float) (Math.PI * 2.0) * k / seg, a1 = (float) (Math.PI * 2.0) * (k + 1) / seg;
                float c0 = Mth.cos(a0) * r, s0 = Mth.sin(a0) * r, c1 = Mth.cos(a1) * r, s1 = Mth.sin(a1) * r;
                float bx0 = plane == 0 ? c0 : 0f, bz0 = plane == 0 ? 0f : c0, bx1 = plane == 0 ? c1 : 0f, bz1 = plane == 0 ? 0f : c1;
                quad(vc, pose, x, y, z, x, y, z, x + bx1, y + s1, z + bz1, x + bx0, y + s0, z + bz0,
                        255, 248, 220, ab, 255, 170, 60, 0);
            }
        }
    }

    /** Segi empat aditif dua sisi (jenis render ini membuang sisi belakang): a,b memakai warna 1, c,d warna 2. */
    private static void quad(VertexConsumer vc, PoseStack.Pose pose, float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz,
                             int r1, int g1, int b1, int a1, int r2, int g2, int b2, int a2) {
        vertex(vc, pose, ax, ay, az, r1, g1, b1, a1);
        vertex(vc, pose, bx, by, bz, r1, g1, b1, a1);
        vertex(vc, pose, cx, cy, cz, r2, g2, b2, a2);
        vertex(vc, pose, dx, dy, dz, r2, g2, b2, a2);
        vertex(vc, pose, dx, dy, dz, r2, g2, b2, a2);
        vertex(vc, pose, cx, cy, cz, r2, g2, b2, a2);
        vertex(vc, pose, bx, by, bz, r1, g1, b1, a1);
        vertex(vc, pose, ax, ay, az, r1, g1, b1, a1);
    }

    /** Cahaya aditif: kekuatan dikalikan ke warnanya (jenis render "eyes" mengabaikan alpha). */
    private static void vertex(VertexConsumer vc, PoseStack.Pose pose, float x, float y, float z, int r, int g, int b, int a) {
        vc.addVertex(pose, x, y, z).setColor(r * a / 255, g * a / 255, b * a / 255, 255).setUv(0.5f, 0.5f)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(LightTexture.FULL_BRIGHT).setNormal(pose, 0f, 1f, 0f);
    }
}
