package com.shazammod.client.fx;

import com.shazammod.ShazamSounds;

import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Runes;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

/**
 * Efek & suara kedatangan dewa-dewa Mesir saat Black Adam berubah (gerak tubuhnya di GodShow, bentuknya di
 * EgyptFigures). Tiap dewa datang dengan caranya sendiri:
 *
 * Shu    : pusaran angin bercampur pasir berputar naik, lalu hembusan angin saat dia menyangga langit.
 * Heru   : bulu-bulu cahaya gugur dari jejak tukikannya, lalu mendarat menghantam tanah dengan kepakan sayap.
 * Amon   : asap bayangan pekat & percikan biru terhisap ke dalam sosoknya, lalu kilat biru lapis.
 * Zehuti : lingkaran hieroglif di tanah, huruf-huruf cahaya naik mengikuti garis tubuh yang sedang "ditulis".
 * Aton   : tanah retak membara keemasan, cahaya fajar memancar dari celahnya, lalu matahari terbit menyilaukan.
 * Mehen  : tanah merekah, pasir & batu menyembur, desis panjang, tudung kobra mengembang.
 */
final class EgyptSpirits {
    private EgyptSpirits() {}

    private static final int SAND = 0xD9C08A;
    private static final int SAND_DARK = 0xA88C5C;
    private static final Vec3 UP = new Vec3(0, 1, 0);

    static void entrance(ClientLevel level, AbstractClientPlayer caster, int god, int tau, int arrive, GodShow.State s,
                         Vec3 anchor, double fx, double fy, double fz, double[] focus, boolean seen) {
        RandomSource rnd = level.random;
        double sc = s.scale;
        double ax = anchor.x, ay = anchor.y, az = anchor.z;
        int aura = GodFigures.AURA[god];
        switch (god) {
            case GodFigures.SHU -> {
                if (tau == 0) {
                    play(level, ax, ay, az, ShazamSounds.WHOOSH.get(), 1.3f, ShazamSounds.tune(0.5f));
                    play(level, ax, ay, az, ShazamSounds.SAND_BURST.get(), 1.2f, ShazamSounds.tune(0.6f));
                }
                if (tau < arrive) {   // pusaran: pasir & garis angin berpilin naik, makin rapat
                    double tight = 1.0 - tau / (double) arrive;
                    for (int k = 0; k < 5; k++) {
                        double a = tau * 0.9 + k * Math.PI * 2 / 5 + rnd.nextDouble() * 0.4;
                        double rr = (0.45 + 0.8 * tight) * sc;
                        double y = ay + rnd.nextDouble() * 2.2 * sc;
                        double tx = -Math.sin(a), tz = Math.cos(a);
                        Vfx.dust(ax + Math.cos(a) * rr, y, az + Math.sin(a) * rr, tx * 0.22, 0.05, tz * 0.22, SAND,
                                0.35f + rnd.nextFloat() * 0.3f, 14 + rnd.nextInt(8));
                        if (k % 2 == 0) {
                            Vfx.spark(ax + Math.cos(a) * rr, y, az + Math.sin(a) * rr, tx * 0.3, 0.06, tz * 0.3, 0xEAF6FF,
                                    0.05f, 8, Double.NaN);
                        }
                    }
                    if (tau % 4 == 0) {
                        play(level, ax, ay, az, ShazamSounds.WHOOSH.get(), 0.6f, ShazamSounds.tune(0.6f + tau * 0.03f));
                    }
                }
                if (tau == arrive) {   // langit tersangga: hembusan angin ke segala arah
                    Ground.Map map = ShazamFx.ground(level, anchor, 3.0);
                    Vfx.add(new Fx.Wave(anchor.add(0, 0.05, 0), UP, 3.0 * sc, 0.4, aura, 14, 0.8f, 0.05f, map));
                    Vfx.add(new Fx.Wave(anchor.add(0, 0.1, 0), UP, 2.6 * sc, 0.9, SAND, 20, 0.45f, 0f, map, true));
                    ShazamFx.dustPuffs(level, anchor, SAND, 14, 1.0, 0.16);
                    play(level, ax, ay, az, ShazamSounds.WHOOSH_HEAVY.get(), 1.0f, ShazamSounds.tune(0.8f));
                }
            }
            case GodFigures.HERU -> {
                if (tau == 0) {
                    play(level, caster.getX(), caster.getY(), caster.getZ(), ShazamSounds.HERU_DIVE.get(), 1.3f, 1f);   // pekik elang + desing
                }
                if (tau < arrive) {   // bulu-bulu cahaya gugur dari tukikannya
                    for (int k = 0; k < 3; k++) {
                        Vfx.mote(fx + (rnd.nextDouble() - 0.5) * 1.4 * sc, fy + (0.8 + rnd.nextDouble() * 0.8) * sc,
                                fz + (rnd.nextDouble() - 0.5) * 1.4 * sc, (rnd.nextDouble() - 0.5) * 0.03, -0.02,
                                (rnd.nextDouble() - 0.5) * 0.03, k == 0 ? 0xFFF0C8 : aura, 0.13f, 22 + rnd.nextInt(10));
                    }
                    if (tau % 3 == 0) {
                        play(level, fx, fy, fz, ShazamSounds.WHOOSH_HEAVY.get(), 0.5f, ShazamSounds.tune(1.6f));
                    }
                }
                if (tau == arrive) {   // mendarat: hantaman, kepakan sayap menyibak debu, bulu berhamburan
                    ShazamFx.impact(level, caster, anchor, 1.3f, aura, 0xFFE0A0, true);
                    ShazamFx.shakeAround(anchor, 0.7f, 24.0);
                    Vec3 chest = anchor.add(0, 1.2 * sc, 0);
                    for (int k = 0; k < 26; k++) {
                        Vec3 v = ShazamFx.randomDir(rnd).scale(0.15 + rnd.nextDouble() * 0.2);
                        Vfx.mote(chest.x, chest.y, chest.z, v.x, Math.abs(v.y) * 0.6, v.z, k % 3 == 0 ? 0xFFFFFF : aura, 0.12f,
                                26 + rnd.nextInt(12));
                    }
                    play(level, ax, ay, az, ShazamSounds.IMPACT.get(), 1.2f, ShazamSounds.tune(0.8f));
                    play(level, ax, ay, az, ShazamSounds.WHOOSH_HEAVY.get(), 1.3f, ShazamSounds.tune(0.9f));
                }
            }
            case GodFigures.AMON -> {
                if (tau == 0) {   // bayangan pekat menggumpal
                    ShazamFx.smokeCloud(level, anchor, 0x0C0E1A, 10, 1.1 * sc);
                    play(level, ax, ay, az, ShazamSounds.CHARGE.get(), 1.2f, ShazamSounds.tune(0.5f));
                    play(level, ax, ay, az, ShazamSounds.HEARTBEAT.get(), 1.0f, ShazamSounds.tune(0.6f));
                }
                if (tau < arrive) {   // asap bayangan naik, percikan biru terhisap ke sosoknya
                    if (tau % 2 == 0) {
                        double a = rnd.nextDouble() * Math.PI * 2, rr = (0.3 + rnd.nextDouble() * 0.6) * sc;
                        Vfx.smoke(ax + Math.cos(a) * rr, ay + 0.2, az + Math.sin(a) * rr, 0, 0.04, 0, 0x10131F,
                                0.5f + rnd.nextFloat() * 0.3f, 30 + rnd.nextInt(10));
                    }
                    for (int k = 0; k < 3; k++) {
                        Vec3 off = ShazamFx.randomDir(rnd).scale((1.2 + rnd.nextDouble() * 0.6) * sc);
                        double cy = ay + 1.2 * sc;
                        Vfx.mote(ax + off.x, cy + off.y, az + off.z, -off.x * 0.09, -off.y * 0.09, -off.z * 0.09, aura, 0.09f, 9);
                    }
                }
                if (tau == arrive) {   // tersingkap penuh: kilat biru lapis
                    Vfx.add(new Fx.Flash(anchor.add(0, 1.6 * sc, 0), 2.6f, 0xBFD2FF, 10, 0.9f));
                    Vfx.add(new Fx.Wave(anchor.add(0, 0.05, 0), UP, 2.4 * sc, 0.35, aura, 14, 0.8f, 0.1f,
                            ShazamFx.ground(level, anchor, 2.5)));
                    ShazamFx.ringOfSparks(level, anchor.add(0, 1.4 * sc, 0), 18, aura, 0.3);
                    play(level, ax, ay, az, ShazamSounds.ENERGY_PULSE.get(), 1.0f, ShazamSounds.tune(0.55f));
                }
            }
            case GodFigures.ZEHUTI -> {
                if (tau == 0) {   // lingkaran hieroglif di tanah
                    int life = GodShow.STRIKE - GodShow.start(god) + 6;
                    Vfx.add(new Runes.Circle(Lightning.Anchor.fixed(anchor.add(0, 0.04, 0)), UP, 1.35 * sc, aura, life,
                            -0.03f, 0.9f, null));
                    play(level, ax, ay, az, ShazamSounds.SPELL.get(), 1.3f, ShazamSounds.tune(0.55f));
                    play(level, ax, ay, az, SoundEvents.BOOK_PAGE_TURN, 1.2f, 0.6f);
                }
                if (tau < arrive) {   // huruf-huruf cahaya naik di garis tubuh yang sedang ditulis
                    double y = fy + s.mask.scanY * sc;
                    for (int k = 0; k < 3; k++) {
                        double a = rnd.nextDouble() * Math.PI * 2, rr = (0.2 + rnd.nextDouble() * 0.35) * sc;
                        Vfx.glint(fx + Math.cos(a) * rr, y, fz + Math.sin(a) * rr, GodLook.lighten(aura, 0.5), 0.13f, 8);
                    }
                    if (tau % 3 == 0) {
                        play(level, ax, ay, az, SoundEvents.BOOK_PAGE_TURN, 0.6f, 1.2f + tau * 0.02f);
                    }
                }
                if (tau == arrive) {   // cakram bulan menyala
                    Vfx.add(new Fx.Flash(anchor.add(0, 2.35 * sc, 0), 1.8f, 0xEAFFF6, 10, 1f));
                    play(level, ax, ay, az, ShazamSounds.RESONANCE.get(), 1.3f, ShazamSounds.tune(1.3f));
                }
            }
            case GodFigures.ATON -> {
                Ground.Map map = tau == 0 || tau == arrive ? ShazamFx.ground(level, anchor, 3.0) : null;
                if (tau == 0) {   // tanah retak membara keemasan: fajar di balik bumi
                    if (map != null && map.found) {
                        Vfx.add(new Ground.Cracks(map.center(anchor), map, 10, 1.5f * (float) sc, GodShow.STRIKE + 30, 80,
                                0xFFE7A0, rnd.nextLong()));
                    }
                    Vfx.add(new Fx.Wave(anchor.add(0, 0.05, 0), UP, 2.0 * sc, 0.5, aura, 20, 0.7f, 0.3f, map));
                    play(level, ax, ay, az, ShazamSounds.POWER_UP.get(), 1.2f, ShazamSounds.tune(0.7f));
                }
                if (tau < arrive && tau % 2 == 0) {   // cahaya fajar memancar dari celah
                    for (int k = 0; k < 3; k++) {
                        double a = rnd.nextDouble() * Math.PI * 2, rr = rnd.nextDouble() * 1.2 * sc;
                        Vfx.spark(ax + Math.cos(a) * rr, ay + 0.05, az + Math.sin(a) * rr, 0, 0.18 + rnd.nextDouble() * 0.12, 0,
                                0xFFF0C0, 0.05f, 10, Double.NaN);
                    }
                    Vfx.add(new Fx.Flash(anchor.add(0, 0.3, 0), 1.2f + tau * 0.12f, aura, 4, 0.35f));
                }
                if (tau == arrive) {   // terbit penuh: menyilaukan
                    Vec3 sun = anchor.add(0, EgyptFigures.ATON_Y * sc, 0);
                    Vfx.add(new Fx.Flash(sun, 5.0f, 0xFFF6D8, 14, 1f));
                    Vfx.add(new Fx.Bubble(sun, 2.2 * sc, 0xFFE7A0, 10, 0.7f, 1.0, 2.0, true));
                    ShazamFx.ringOfSparks(level, sun, 34, aura, 0.4);
                    play(level, ax, ay, az, ShazamSounds.ENERGY_PULSE.get(), 1.2f, ShazamSounds.tune(1.2f));
                    play(level, ax, ay, az, ShazamSounds.RESONANCE.get(), 1.4f, ShazamSounds.tune(0.9f));
                    Minecraft mc = Minecraft.getInstance();
                    if (mc.player != null && mc.player.position().distanceTo(anchor) < 32.0) {
                        ScreenFlash.flash(0.3f, 0xFFF0C8);
                    }
                }
            }
            case GodFigures.MEHEN -> {
                Ground.Map map = tau == 0 || tau == 2 || tau == arrive ? ShazamFx.ground(level, anchor, 3.0) : null;
                if (tau == 0) {   // tanah merekah
                    if (map != null && map.found) {
                        Vfx.add(new Ground.Cracks(map.center(anchor), map, 9, 1.6f * (float) sc, GodShow.STRIKE + 40, 50, aura,
                                rnd.nextLong()));
                    }
                    play(level, ax, ay, az, ShazamSounds.IMPACT.get(), 1.0f, ShazamSounds.tune(0.5f));
                    play(level, ax, ay, az, ShazamSounds.DARK_HISS.get(), 1.4f, ShazamSounds.tune(0.4f));
                    ShazamFx.shakeAround(anchor, 0.35f, 20.0);
                }
                if (tau == 2 && map != null && map.found) {   // pasir & batu menyembur
                    Vfx.add(new Ground.Debris(map.center(anchor), map, 12, 0.16, 0.45, 0.9, 50));
                    ShazamFx.dustPuffs(level, map.center(anchor), SAND, 16, 1.2, 0.14);
                }
                if (tau < arrive + 2 && tau % 2 == 0) {   // pasir mengalir dari sisik yang menyeruak
                    for (int k = 0; k < 4; k++) {
                        double a = rnd.nextDouble() * Math.PI * 2, rr = (0.3 + rnd.nextDouble() * 0.9) * sc;
                        Vfx.dust(ax + Math.cos(a) * rr, ay + 0.1 + rnd.nextDouble() * 0.6 * sc, az + Math.sin(a) * rr,
                                Math.cos(a) * 0.04, 0.02, Math.sin(a) * 0.04, rnd.nextBoolean() ? SAND : SAND_DARK,
                                0.4f + rnd.nextFloat() * 0.3f, 18 + rnd.nextInt(10));
                    }
                }
                if (tau == arrive) {   // tudung mengembang: desis panjang
                    Vfx.add(new Fx.Wave(anchor.add(0, 0.05, 0), UP, 2.8 * sc, 0.4, aura, 16, 0.8f, 0.1f, map));
                    play(level, ax, ay, az, ShazamSounds.DARK_HISS.get(), 1.6f, ShazamSounds.tune(0.5f));
                    play(level, ax, ay, az, ShazamSounds.MEHEN_COIL.get(), 1.2f, 1f);
                    ShazamFx.shakeAround(anchor, 0.4f, 20.0);
                }
                if (tau > arrive + 4 && tau % 9 == 0 && seen) {   // lidahnya menjulur
                    play(level, focus[0], focus[1], focus[2], ShazamSounds.DARK_HISS.get(), 0.5f, ShazamSounds.tune(0.9f + rnd.nextFloat() * 0.3f));
                }
            }
            default -> { }
        }
    }

    private static void play(ClientLevel level, double x, double y, double z, SoundEvent sound, float volume, float pitch) {
        level.playLocalSound(x, y, z, sound, SoundSource.PLAYERS, volume, ShazamFx.slowPitch(level, pitch), false);
    }
}
