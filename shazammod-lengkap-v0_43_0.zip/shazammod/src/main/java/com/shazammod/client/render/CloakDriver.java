package com.shazammod.client.render;

/**
 * Penggerak waktu kain (murni Java): fisika dihitung dengan langkah kecil tetap (Cloak.SUBSTEPS per tick),
 * mengejar waktu render tiap frame, jadi gerakannya halus di FPS berapa pun dan nggak bergantung FPS.
 *
 * Pose model (kepala, lengan, kaki) cuma diketahui saat pemain digambar. Supaya gerak bagian tubuh yang dipakai
 * fisika halus (nggak loncat per frame), pose yang dipakai fisika adalah pose frame lalu yang dicampur mulus
 * ke pose terbaru selama satu frame. Kain tetap digambar menempel pose terbaru karena posisinya disimpan di
 * ruang bagian tubuh.
 */
public final class CloakDriver {
    /** Ketinggalan lebih dari ini (tick, misalnya lag berat): lompati, jangan dikejar. */
    public static final double MAX_LAG = 8.0;
    /** Paling banyak sekian langkah kecil per frame (4 tick). */
    public static final int MAX_STEPS = Cloak.SUBSTEPS * 4;

    /** Isi keadaan tubuh di satu langkah kecil. */
    public interface Sampler {
        /**
         * @param tickFraction posisi di antara tick lalu (0) dan tick sekarang (1)
         * @param tickTime     waktu langkah ini (tick, sama dengan simTime)
         */
        void sample(double tickFraction, double tickTime, Cloak.Input in);
    }

    public final Cloak cloak = new Cloak();
    public final Cloak.Input in = new Cloak.Input();
    /** Waktu fisika (tick); sedikit di depan waktu render. NaN = belum mulai. */
    public double simTime = Double.NaN;

    private final float[] posePrev = BodyRig.DEFAULT.clone();
    private final float[] poseLast = BodyRig.DEFAULT.clone();
    private boolean posed;
    private double frameStart;

    /** Simpan pose model dari render dunia terakhir (36 nilai, lihat BodyRig). */
    public void capture(float[] parts) {
        if (parts == null || parts.length < BodyRig.VALUES) {
            return;
        }
        System.arraycopy(parts, 0, poseLast, 0, BodyRig.VALUES);
        if (!posed) {
            System.arraycopy(parts, 0, posePrev, 0, BodyRig.VALUES);
            posed = true;
        }
    }

    /** Pose untuk fisika di waktu t (tick) di dalam frame ini. */
    public void poseAt(double t, double frameEnd, float[] out) {
        double span = frameEnd - frameStart;
        double u = span > 1.0E-6 ? (t - frameStart) / span : 1.0;
        BodyRig.lerp(posePrev, poseLast, Math.max(0.0, Math.min(1.0, u)), out);
    }

    /** Pose untuk pasang kain baru (sebelum fisika berjalan). */
    public void currentPose(float[] out) {
        System.arraycopy(poseLast, 0, out, 0, BodyRig.VALUES);
    }

    /**
     * Majukan fisika sampai waktu render.
     * @param now      waktu render (tick)
     * @param tickBase waktu tick lalu (tick); posisi di dalam tick = waktu - tickBase
     * @return true kalau fisika berjalan (false = baru mulai atau melompati lag)
     */
    public boolean frame(double now, double tickBase, Sampler sampler) {
        if (Double.isNaN(simTime) || now - simTime > MAX_LAG || simTime - now > 1.0) {
            simTime = now;
            frameStart = now;
            System.arraycopy(poseLast, 0, posePrev, 0, BodyRig.VALUES);
            cloak.resetMotion();
            return false;
        }
        frameStart = Math.min(simTime, now);
        int steps = 0;
        double dt = 1.0 / Cloak.SUBSTEPS;
        while (simTime < now && steps < MAX_STEPS) {
            simTime += dt;
            double p = Math.max(0.0, Math.min(1.0, simTime - tickBase));
            sampler.sample(p, simTime, in);
            poseAt(simTime, now, in.parts);
            in.time = simTime * Cloak.TICK;
            cloak.step(in);
            steps++;
        }
        if (simTime < now) {
            simTime = now;
        }
        // frame berikutnya mulai dari pose ini; kalau nggak ada render baru, pose ditahan
        System.arraycopy(poseLast, 0, posePrev, 0, BodyRig.VALUES);
        return steps > 0;
    }

    /** 0..1: posisi waktu render di antara dua langkah fisika terakhir. */
    public double alpha(double now) {
        if (Double.isNaN(simTime)) {
            return 1.0;
        }
        return Math.max(0.0, Math.min(1.0, 1.0 - (simTime - now) * Cloak.SUBSTEPS));
    }
}
