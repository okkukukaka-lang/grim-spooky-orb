package com.shazammod.client.fx;

import java.util.HashMap;
import java.util.Map;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

/**
 * 0.28.1 Black Adam: kekuatan dari matahari Aton (padanan petir Shazam, tapi tanpa petir sama sekali).
 *
 * Cakram Aton: cakram matahari emas melayang di atas kepala Black Adam selama dia berwujud juara, dengan mahkota sinar yang
 * berputar. Tiap 2 detik (animasi ADAM_SUN) sinar-sinarnya yang BERUJUNG TANGAN (lambang Aten Mesir kuno: matahari yang
 * memberkati dengan tangan-tangannya) terulur turun menyentuh bahu dan dadanya selama ShazamAnim.ROD_DESCENT tick, lalu
 * cakramnya menyembur: tiang cahaya matahari, kilatan hangat, gelombang panas & pasir di tanah, bara beterbangan, badannya
 * berpendar seperti emas yang dipanaskan, mata & lambang menyala, dan badannya tersentak (sama seperti Shazam tersambar).
 *
 * Tinju Aton (ADAM_SUNPUNCH): ledakan cahaya & api matahari di sasaran, tanpa petir.
 */
public final class AtonFx {
    private AtonFx() {}

    // ======= Angka yang gampang diutak-atik =======
    /** Cakram melayang segini di atas kepala (blok, dikali ukuran badan). */
    private static final double DISK_HEIGHT = 0.95;
    private static final float DISK_RADIUS = 0.36f;
    /** Jumlah sinar berujung tangan yang terulur ke badan tiap denyut. */
    private static final int HAND_RAYS = 7;
    /** Cakram tetap ada sekian tick sesudah denyut terakhir (denyutnya tiap 40 tick selama berwujud juara). */
    private static final int CROWN_LIFE = 70;
    /** Kilatan layar saat diri sendiri berdenyut: orang ketiga / orang pertama (0 = mati). */
    private static final float SELF_FLASH = 0.22f;
    private static final float SELF_FLASH_FIRST_PERSON = 0.08f;
    // =========================================================================

    private static final int SUN = AdamFx.SUN;
    private static final int GOLD_HOT = AdamFx.GOLD_HOT;
    private static final int AMBER = AdamFx.AMBER;
    private static final int WHITE_HOT = AdamFx.WHITE_HOT;
    private static final Vec3 UP = new Vec3(0, 1, 0);

    private static final Map<Integer, Crown> CROWNS = new HashMap<>();

    public static void clear() {
        CROWNS.clear();
    }

    public static void tick(ClientLevel level) {
        CROWNS.values().removeIf(c -> c.done);
    }

    private static boolean firstPerson(AbstractClientPlayer player) {
        Minecraft mc = Minecraft.getInstance();
        return player == mc.player && mc.options.getCameraType().isFirstPerson();
    }

    /** ADAM_SUN: Cakram Aton berdenyut (tiap 2 detik). */
    public static void pulse(AbstractClientPlayer caster, boolean self) {
        Crown crown = CROWNS.get(caster.getId());
        if (crown == null || crown.done) {
            crown = new Crown(caster);
            CROWNS.put(caster.getId(), crown);
            Vfx.add(crown);
        }
        crown.pulse();
        Crown c = crown;
        int reach = ShazamAnim.ROD_DESCENT;
        boolean first = firstPerson(caster);
        // 1) sinar bertangan terulur: hawa panas & bara kecil terhisap naik ke cakram
        ShazamFx.schedule(0, reach, (level, t) -> {
            Vec3 top = c.center(1f);
            RandomSource r = level.random;
            for (int i = 0, n = Vfx.count(first ? 1 : 4); i < n; i++) {
                Vec3 from = caster.position().add((r.nextDouble() - 0.5) * 1.4, 0.2 + r.nextDouble() * 1.6, (r.nextDouble() - 0.5) * 1.4);
                Vec3 v = top.subtract(from).scale(0.12);
                Vfx.ember(from.x, from.y, from.z, v.x, v.y, v.z, 0.05f, 8);
            }
        });
        // 2) menyembur: tepat di tick kekuatannya masuk di server (dan semburan di SFX aton_pulse)
        ShazamFx.schedule(reach, 1, (level, t) -> burst(level, caster, self, c));
    }

    private static void burst(ClientLevel level, AbstractClientPlayer caster, boolean self, Crown crown) {
        if (!caster.isAlive()) {
            return;
        }
        boolean first = firstPerson(caster);
        float k = first ? 0.35f : 1f;
        float scale = caster.getScale();
        Vec3 c = caster.position();
        Vec3 chest = c.add(0, 1.25 * scale, 0);
        Vec3 core = first ? c.add(0, 0.35, 0) : chest;
        RodStrikeFx.markHit(caster);     // mata & lambang menyala
        ShazamPoses.surge(caster);       // badan tersentak menerima panas matahari
        Vfx.add(new Fx.Pillar(c, 46.0, (first ? 0.5f : 1.3f) * scale, SUN, 11));   // tiang cahaya matahari
        Vfx.add(new Fx.Flash(core, 0.9f + 2.0f * k, WHITE_HOT, 8, 1f));
        Vfx.add(new Fx.Flash(core, 1.3f + 2.8f * k, SUN, 14, 0.85f));
        CineFx.flareAt(first ? Lightning.Anchor.fixed(core) : crown::center, 0xFFE8B0, 3f + 6f * k, 0.06f + 0.1f * k, k, 12);
        Vfx.add(new Fx.Bubble(chest, 2.0 * scale, GOLD_HOT, 9, 0.55f * k, 1.0, 2.6, true));   // selubung panas
        // dua cincin panas naik dari kaki ke kepala: energi, darah, dan armor pulih
        Vfx.add(new Fx.Ripple(c.add(0, 0.05, 0), UP, 2.1 * scale, 0.55, 0.85, 0.14, GOLD_HOT, 12, first ? 0.45f : 0.9f, false));
        Vfx.add(new Fx.Ripple(c.add(0, 0.05, 0), UP, 2.1 * scale, 0.8, 1.1, 0.08, SUN, 9, first ? 0.3f : 0.6f, false));
        // badan berpendar seperti emas yang dipanaskan, lalu meredup
        Vfx.add(new Fx.Aura(caster, AMBER, 26, () -> caster.isAlive() ? 0.6f : 0f));
        // di tanah: gelombang panas, pasir & debu tersibak, bekas terbakar matahari
        Ground.Map map = ShazamFx.ground(level, c, 3.0);
        if (map != null && map.found && c.y - map.centerY < 2.0) {
            Vec3 g = map.center(c);
            Vfx.add(new Fx.Wave(g, UP, 4.6, 0.22, WHITE_HOT, 8, 0.85f, 0f, map));
            Vfx.add(new Fx.Wave(g, UP, 4.0, 0.42, AMBER, 13, 0.85f, 0.12f, map));
            Vfx.add(new Fx.Wave(g, UP, 3.6, 1.0, AdamFx.SAND, 24, 0.55f, 0f, map, true));
            Vfx.add(new Fx.Scorch(g, 1.0, 90, 16, map));
            ShazamFx.dustPuffs(level, g, AdamFx.SAND, 10, 1.3, 0.12);
        }
        RandomSource r = level.random;
        for (int i = 0, n = Vfx.count(first ? 6 : 26); i < n; i++) {   // bara beterbangan dari badan
            Vec3 d = ShazamFx.randomDir(r);
            Vfx.ember(chest.x + d.x * 0.3, chest.y + d.y * 0.5, chest.z + d.z * 0.3, d.x * 0.12, 0.06 + r.nextDouble() * 0.1,
                    d.z * 0.12, 0.06f, 18 + r.nextInt(14));
        }
        ShazamFx.shakeAround(c, 0.3f, 20);
        if (self) {
            ScreenFlash.flash(first ? SELF_FLASH_FIRST_PERSON : SELF_FLASH, 0xFFE8C0);
            FovKick.punch(-0.03f);
        }
    }

    /** ADAM_SUNPUNCH: Tinju Aton, ledakan cahaya & api matahari di sasaran. */
    public static void punch(AbstractClientPlayer caster, Vec3 pos, boolean self) {
        ShazamFx.schedule(0, 1, (level, t) -> {
            Vec3 dir = pos.subtract(caster.getEyePosition());
            dir = dir.lengthSqr() < 1.0E-4 ? caster.getViewVector(1f) : dir.normalize();
            Vfx.add(new Fx.Flash(pos, 2.4f, WHITE_HOT, 9, 1f));
            Vfx.add(new Fx.Flash(pos, 3.6f, SUN, 14, 0.8f));
            Vfx.add(new Fx.Ripple(pos, dir, 4.5, 0.4, 3.4, 0.4, AMBER, 12, 0.9f, false));
            Vfx.add(new Fx.Cone(pos, dir, 5.0, 0.5, GOLD_HOT, 12, 0.55f, 2.0, true));
            Vfx.add(new Fx.Bubble(pos, 2.6, SUN, 10, 0.8f, 1.0, 2.0, true));
            Vfx.add(new Fx.Pillar(pos.subtract(0, 1.2, 0), 18.0, 1.0f, SUN, 9));   // sorot matahari singkat di sasaran
            CineFx.flare(pos, 0xFFE8B0, 6f, 0.16f, 1f, 12);
            RandomSource r = level.random;
            for (int i = 0, n = Vfx.count(40); i < n; i++) {   // api & bara menyembur ke segala arah
                Vec3 d = ShazamFx.randomDir(r).scale(0.15 + r.nextDouble() * 0.25);
                Vfx.ember(pos.x, pos.y, pos.z, d.x, d.y + 0.05, d.z, 0.07f + r.nextFloat() * 0.05f, 14 + r.nextInt(14));
            }
            for (int i = 0, n = Vfx.count(8); i < n; i++) {
                Vec3 d = ShazamFx.randomDir(r).scale(0.08);
                Vfx.smoke(pos.x, pos.y, pos.z, d.x, d.y + 0.04, d.z, AdamFx.SMOKE, 0.6f, 24);
            }
            ShazamFx.shakeAround(pos, 0.8f, 26);
            if (self) {
                ScreenFlash.flash(0.3f, 0xFFE8C0);
                FovKick.punch(-0.08f);
                CameraShake.add(0.25f);
            }
        });
    }

    private static int lerpColor(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return (r << 16) | (g << 8) | bl;
    }

    /**
     * 0.29 ADAM_SUN_SET: matahari terbenam (malam, atau masuk Nether/End). Cakram Aton turun ke balik punggung sambil mengecil
     * dan memerah seperti matahari di cakrawala, mahkota sinarnya menguncup, bara berjatuhan dari cakram, asap tipis, dan
     * cahaya senja jingga melebar pelan di tanah lalu padam.
     */
    public static void set(AbstractClientPlayer caster, boolean self) {
        Crown crown = CROWNS.get(caster.getId());
        if (crown == null || crown.done || crown.setting()) {
            crown = new Crown(caster);
            CROWNS.put(caster.getId(), crown);
            Vfx.add(crown);
        }
        crown.set();
        Crown c = crown;
        ShazamFx.schedule(0, ShazamAnim.SUN_SET_TICKS, (level, t) -> {
            if (t % 2 != 0) {
                return;
            }
            Vec3 p = c.center(1f);
            RandomSource r = level.random;
            Vfx.ember(p.x + (r.nextDouble() - 0.5) * 0.4, p.y, p.z + (r.nextDouble() - 0.5) * 0.4, (r.nextDouble() - 0.5) * 0.02,
                    -0.03 - r.nextDouble() * 0.03, (r.nextDouble() - 0.5) * 0.02, 0.05f, 16);
            if (t % 6 == 0) {
                Vfx.smoke(p.x, p.y, p.z, 0, 0.02, 0, AdamFx.SMOKE, 0.35f, 24);
            }
        });
        ShazamFx.schedule(4, 1, (level, t) -> {
            Ground.Map map = ShazamFx.ground(level, caster.position(), 3.0);
            if (map != null && map.found && caster.getY() - map.centerY < 2.0) {
                Vfx.add(new Fx.Wave(map.center(caster.position()), UP, 3.2, 0.7, AdamFx.EMBER_RED, 30, 0.4f, 0f, map, true));
            }
        });
        if (self) {
            ScreenFx.vignette(0.25f, 0x1A0A04, ShazamAnim.SUN_SET_TICKS);
        }
    }

    /**
     * 0.29 ADAM_SUN_RISE: matahari terbit. Cakram Aton naik dari balik punggung sambil membesar dan berubah dari merah ke emas,
     * mahkota sinarnya mekar, sinar dewa memancar, bara naik ke cakram, lalu (tick SUN_RISE_TICKS) mekar hangat.
     */
    public static void rise(AbstractClientPlayer caster, boolean self) {
        Crown crown = new Crown(caster);
        CROWNS.put(caster.getId(), crown);
        Vfx.add(crown);
        crown.rise();
        Crown c = crown;
        CineFx.godRays(c::center, SUN, 12.0, 1.0, 9, 0.5f, ShazamAnim.SUN_RISE_TICKS + 16);
        ShazamFx.schedule(0, ShazamAnim.SUN_RISE_TICKS, (level, t) -> {
            Vec3 top = c.center(1f);
            RandomSource r = level.random;
            Vec3 from = caster.position().add((r.nextDouble() - 0.5) * 1.4, 0.3 + r.nextDouble() * 1.4, (r.nextDouble() - 0.5) * 1.4);
            Vec3 v = top.subtract(from).scale(0.08);
            Vfx.ember(from.x, from.y, from.z, v.x, v.y, v.z, 0.05f, 12);
        });
        ShazamFx.schedule(ShazamAnim.SUN_RISE_TICKS, 1, (level, t) -> {
            Vec3 top = c.center(1f);
            boolean first = firstPerson(caster);
            Vfx.add(new Fx.Flash(top, first ? 0.6f : 1.8f, SUN, 12, 0.85f));
            CineFx.flare(top, 0xFFE8B0, first ? 2f : 5f, 0.08f, first ? 0.3f : 1f, 12);
            Ground.Map map = ShazamFx.ground(level, caster.position(), 3.0);
            if (map != null && map.found && caster.getY() - map.centerY < 2.0) {
                Vfx.add(new Fx.Wave(map.center(caster.position()), UP, 3.6, 0.3, SUN, 14, 0.7f, 0.1f, map));
            }
            if (self) {
                ScreenFlash.flash(first ? 0.06f : 0.14f, 0xFFE8C0);
            }
        });
    }

    /** Pelindung Kahndaq: sorot cahaya matahari tipis dari dada Black Adam ke penyerang makhluk tak berdosa. */
    public static void link(Lightning.Anchor from, Lightning.Anchor to, int life) {
        Vfx.add(new Beam(from, to, life));
    }

    static final class Beam extends Effect {
        private final Lightning.Anchor from;
        private final Lightning.Anchor to;

        Beam(Lightning.Anchor from, Lightning.Anchor to, int life) {
            super(life);
            this.from = from;
            this.to = to;
        }

        @Override
        public void renderGlow(Draw d) {
            float p = progress(d.partialTick);
            float a = p < 0.2f ? p / 0.2f : (float) Math.pow(1f - (p - 0.2f) / 0.8f, 1.3);
            if (a <= 0.01f) {
                return;
            }
            Vec3 s = from.at(d.partialTick);
            Vec3 e = to.at(d.partialTick);
            d.beam(s.x, s.y, s.z, e.x, e.y, e.z, 0.12f, SUN, 0xFFFFFF, a * 0.9f, a * 0.8f);
            d.glow(e.x, e.y, e.z, 0.5f, SUN, 0.6f * a);
        }
    }

    /**
     * Cakram Aton di atas kepala: cakram emas berkilau dengan cincin dan mahkota sinar yang berputar. Tiap denyut, sinar-sinar
     * berujung tangan (Aten) terulur turun menyentuh bahu & dada, lalu tertarik lagi.
     */
    static final class Crown extends Effect {
        private final AbstractClientPlayer owner;
        private int pulseAge = -1000;   // age saat denyut terakhir dimulai
        private int setAge = -1;        // 0.29: mulai terbenam
        private int riseAge = -1;       // 0.29: mulai terbit
        boolean done;

        Crown(AbstractClientPlayer owner) {
            super(CROWN_LIFE);
            this.owner = owner;
        }

        void pulse() {
            if (riseAge >= 0 && time(1f) - riseAge >= ShazamAnim.SUN_RISE_TICKS) {
                riseAge = -1;     // sudah terbit penuh
            }
            if (riseAge >= 0) {   // masih terbit: umurnya jangan diputar balik (cakramnya bisa turun lagi)
                pulseAge = age;
                return;
            }
            age = Math.min(age, 8);   // diperpanjang: tetap ada selama denyutnya terus datang (cuma fade-in yang dilewati)
            pulseAge = age;
        }

        /** 0.29: mulai terbenam (bertahan cukup lama untuk animasinya, lalu hilang). */
        void set() {
            age = Math.min(age, life - ShazamAnim.SUN_SET_TICKS - 2);
            setAge = age;
        }

        /** 0.29: mulai terbit dari balik punggung. */
        void rise() {
            riseAge = age;
        }

        boolean setting() {
            return setAge >= 0;
        }

        @Override
        public boolean tick(ClientLevel level) {
            boolean alive = owner.isAlive() && ShazamClientState.isTransformed(owner.getId())
                    && ShazamClientState.isAdam(owner.getId()) && super.tick(level)
                    && !(setAge >= 0 && age - setAge > ShazamAnim.SUN_SET_TICKS);
            done = !alive;
            return alive;
        }

        /** 0..1: seberapa jauh cakram terbenam (1 = di balik punggung, padam). */
        float sunk(float pt) {
            float time = time(pt);
            if (setAge >= 0) {
                float k = Math.min(1f, Math.max(0f, (time - setAge) / ShazamAnim.SUN_SET_TICKS));
                return k * k * (3f - 2f * k);
            }
            if (riseAge >= 0) {
                float k = Math.min(1f, Math.max(0f, (time - riseAge) / ShazamAnim.SUN_RISE_TICKS));
                k = 1f - (1f - k) * (1f - k) * (1f - k);
                return 1f - k;
            }
            return 0f;
        }

        Vec3 center(float pt) {
            Vec3 c = owner.getPosition(pt).add(0, owner.getBbHeight() + DISK_HEIGHT * owner.getScale(), 0);
            float s = sunk(pt);
            if (s <= 0f) {
                return c;
            }
            double yaw = Math.toRadians(owner.getViewYRot(pt));
            Vec3 back = new Vec3(Math.sin(yaw), 0, -Math.cos(yaw));   // ke balik punggung, lalu turun ke bawah bahu
            return c.add(back.scale(0.55 * s)).add(0, -1.35 * owner.getScale() * s, 0);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            float in = riseAge >= 0 ? 1f : Math.min(1f, time / 6f);
            float out = setAge >= 0 ? 1f : Math.min(1f, (life - time) / 10f);
            float sunk = sunk(d.partialTick);
            float k = Math.max(0f, in) * Math.max(0f, out) * (1f - (float) Math.pow(sunk, 1.6));   // terbenam: meredup
            if (k <= 0.01f || owner.isInvisible()) {
                return;
            }
            // terbenam / terbit: mengecil & memerah seperti matahari di cakrawala
            int sun = lerpColor(SUN, AdamFx.EMBER_RED, sunk);
            int rim = lerpColor(0xFFB838, AdamFx.EMBER_RED, sunk);
            Vec3 c = center(d.partialTick);
            double tx = d.camX - c.x, ty = d.camY - c.y, tz = d.camZ - c.z;
            double tl = Math.sqrt(tx * tx + ty * ty + tz * tz) + 1.0E-9;
            tx /= tl;
            ty /= tl;
            tz /= tl;
            float near = d.nearFade(c.x, c.y, c.z, 0.9, 2.6);   // orang pertama: cakram di atas kepala nggak menyilaukan
            if (near <= 0.01f) {
                return;
            }
            // denyut: 0 -> 1 selama sinar terulur (ROD_DESCENT), puncak saat menyembur, lalu tertarik lagi
            float sinceP = time - pulseAge;
            int reachT = ShazamAnim.ROD_DESCENT;
            float ext = sinceP < 0 ? 0f : sinceP < reachT ? sinceP / reachT : Math.max(0f, 1f - (sinceP - reachT) / 12f);
            float flare = sinceP >= reachT && sinceP < reachT + 8 ? 1f - (sinceP - reachT) / 8f : 0f;
            float r = DISK_RADIUS * owner.getScale() * (1f + 0.25f * flare) * (1f - 0.45f * sunk);
            float a = k * near;
            d.disc(c.x, c.y, c.z, tx, ty, tz, r, sun, 0.95f * a, 0.65f * a, null);
            d.ring(c.x, c.y, c.z, tx, ty, tz, r * 1.05, r * 0.14, rim, 0.95f * a, 0f, null);
            d.ring(c.x, c.y, c.z, tx, ty, tz, r * 1.5, r * 0.06, AMBER, 0.55f * a, 0f, null);
            d.flare(c.x, c.y, c.z, r * (1.8f + 1.4f * flare), lerpColor(GOLD_HOT, AMBER, sunk), (0.75f + 0.25f * flare) * a);
            d.glow(c.x, c.y, c.z, r * (5f + 4f * flare), sun, (0.25f + 0.25f * flare) * a);
            double[] e = new double[6];
            Draw.plane(tx, ty, tz, e);
            int rays = 20;   // mahkota sinar berputar pelan, panjangnya berdenyut
            for (int i = 0; i < rays; i++) {
                double ang = time * 0.04 + Math.PI * 2.0 * i / rays;
                double cs = Math.cos(ang), sn = Math.sin(ang);
                double dx = e[0] * cs + e[3] * sn, dy = e[1] * cs + e[4] * sn, dz = e[2] * cs + e[5] * sn;
                double pulse = (0.85 + 0.15 * Math.sin(time * 0.5 + i * 1.7) + 0.5 * flare) * (1.0 - 0.8 * sunk);   // sinar menguncup
                double r0 = r * 1.1, r1 = r * (i % 2 == 0 ? 2.2 : 1.6) * pulse;
                d.line(c.x + dx * r0, c.y + dy * r0, c.z + dz * r0, c.x + dx * r1, c.y + dy * r1, c.z + dz * r1,
                        0.07f, 0.01f, 0xFFE7A0, 0.75f * a, 0f);
            }
            if (ext <= 0.01f) {
                return;
            }
            // sinar-sinar berujung tangan (Aten) terulur ke bahu & dada
            Vec3 feet = owner.getPosition(d.partialTick);
            float yaw = (float) Math.toRadians(-owner.getViewYRot(d.partialTick));
            double h = owner.getBbHeight();
            for (int i = 0; i < HAND_RAYS; i++) {
                double f = HAND_RAYS == 1 ? 0.5 : i / (double) (HAND_RAYS - 1);
                double side = (f - 0.5) * 0.9 * owner.getScale();
                double fwd = 0.18 + 0.12 * Math.cos((f - 0.5) * Math.PI);
                double ly = h * (0.62 + 0.18 * Math.cos((f - 0.5) * Math.PI));
                double wx = Math.cos(yaw) * side + Math.sin(yaw) * fwd;
                double wz = -Math.sin(yaw) * side + Math.cos(yaw) * fwd;
                Vec3 target = feet.add(wx, ly, wz);
                Vec3 from = c.add((target.x - c.x) * 0.12, -r * 0.6, (target.z - c.z) * 0.12);
                Vec3 to = from.add(target.subtract(from).scale(ext));
                d.line(from.x, from.y, from.z, to.x, to.y, to.z, 0.06f, 0.035f, GOLD_HOT, 0.8f * a, (0.6f + 0.4f * flare) * a);
                // tangan terbuka kecil di ujung sinar: empat jari + ibu jari
                Vec3 dir = to.subtract(from);
                double len = dir.length();
                if (len < 0.2) {
                    continue;
                }
                dir = dir.scale(1.0 / len);
                Vec3 sideV = dir.cross(UP);
                sideV = sideV.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : sideV.normalize();
                Vec3 palm = to.subtract(dir.scale(0.06));
                for (int fgr = -2; fgr <= 2; fgr++) {
                    Vec3 base = palm.add(sideV.scale(fgr * 0.028));
                    Vec3 tip = base.add(dir.scale(fgr == -2 ? 0.06 : 0.11)).add(sideV.scale(fgr == -2 ? -0.05 : fgr * 0.008));
                    d.line(base.x, base.y, base.z, tip.x, tip.y, tip.z, 0.03f, 0.018f, 0xFFF4D0, 0.95f * a, 0.7f * a);
                }
                d.glow(palm.x, palm.y, palm.z, 0.16f, SUN, (0.45f + 0.4f * flare) * a);
            }
        }
    }
}
