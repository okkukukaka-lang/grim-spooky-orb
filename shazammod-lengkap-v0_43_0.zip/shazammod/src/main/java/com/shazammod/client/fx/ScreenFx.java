package com.shazammod.client.fx;

import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.Font;
import net.minecraft.client.Minecraft;
import java.util.Random;

import com.mojang.math.Axis;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

/**
 * Efek layar untuk pemain sendiri:
 * - garis kecepatan ala anime yang memusat ke tengah layar (terjangan, tepukan, sonic boom),
 * - vinyet berwarna di tepi layar (mengumpulkan tenaga, amarah, sihir).
 */
public final class ScreenFx {
    private ScreenFx() {}

    private static float lines, linesO;
    private static float vignette, vignetteO;
    private static float vignetteHold;
    private static int vignetteColor = 0x000000;
    private static int ticks;

    // ======= Sinema (0.24) =======
    /** Pita hitam atas-bawah (letterbox) di momen besar: ritual SHAZAM, Badai Para Dewa, Murka Kahndaq. false = mati. */
    public static final boolean CINEMA_BARS = true;
    /** Kartu judul di momen besar ("SHAZAM!", "BADAI PARA DEWA", "MURKA KAHNDAQ"). false = mati. */
    public static final boolean TITLE_CARDS = true;
    /** Tinggi tiap pita (bagian dari tinggi layar). */
    private static final float BAR_HEIGHT = 0.11f;
    private static float bars, barsO;
    private static int barsHold;
    private static Component title;
    private static int titleColor, titleAge, titleLife, titleDelay;

    /** Pita film masuk, bertahan hold tick, lalu keluar pelan. */
    public static void cinema(int hold) {
        barsHold = Math.max(barsHold, hold);
    }

    /** Kartu judul dari kunci bahasa: muncul delay tick lagi, menghentak masuk, bertahan, lalu memudar dalam life tick. */
    public static void titleKey(String key, int rgb, int life, int delay) {
        title = Component.translatable(key);
        titleColor = rgb & 0xFFFFFF;
        titleLife = Math.max(1, life);
        titleDelay = Math.max(0, delay);
        titleAge = 0;
    }

    /** Garis kecepatan, 0-1. */
    public static void speedLines(float strength) {
        lines = Math.max(lines, strength);
    }

    /** Vinyet berwarna, 0-1, bertahan hold tick sebelum memudar. */
    public static void vignette(float strength, int rgb, int hold) {
        if (strength >= vignette) {
            vignetteColor = rgb;
        }
        vignette = Math.max(vignette, strength);
        vignetteHold = Math.max(vignetteHold, hold);
    }

    public static void clear() {
        lines = linesO = 0f;
        vignette = vignetteO = 0f;
        vignetteHold = 0;
        bars = barsO = 0f;
        barsHold = 0;
        title = null;
    }

    public static void tick() {
        ticks++;
        barsO = bars;
        if (barsHold > 0) {
            barsHold--;
            bars = Math.min(1f, bars + 0.12f);
        } else {
            bars = Math.max(0f, bars - 0.07f);
        }
        if (title != null) {
            if (titleDelay > 0) {
                titleDelay--;
            } else if (++titleAge > titleLife) {
                title = null;
            }
        }
        linesO = lines;
        lines = Math.max(0f, lines - 0.07f);
        vignetteO = vignette;
        if (vignetteHold > 0) {
            vignetteHold--;
        } else {
            vignette = Math.max(0f, vignette - 0.05f);
        }
    }

    public static void render(GuiGraphics graphics, DeltaTracker deltaTracker) {
        float pt = deltaTracker.getGameTimeDeltaPartialTick(false);
        float v = Mth.lerp(pt, vignetteO, vignette);
        if (v > 0.01f) {
            drawVignette(graphics, v);
        }
        float s = Mth.lerp(pt, linesO, lines);
        if (s > 0.01f) {
            drawLines(graphics, s);
        }
        float b = Mth.lerp(pt, barsO, bars);
        if (CINEMA_BARS && b > 0.002f) {
            drawBars(graphics, b);
        }
        if (TITLE_CARDS && title != null && titleDelay <= 0) {
            drawTitle(graphics, pt);
        }
    }

    private static void drawBars(GuiGraphics g, float b) {
        int w = g.guiWidth(), h = g.guiHeight();
        float e = b * b * (3f - 2f * b);
        int bar = Math.round(h * BAR_HEIGHT * e);
        if (bar <= 0) {
            return;
        }
        g.fill(0, 0, w, bar, 0xFF000000);
        g.fill(0, h - bar, w, h, 0xFF000000);
        g.fillGradient(0, bar, w, bar + 3, 0x80000000, 0x00000000);   // tepi pita sedikit lembut
        g.fillGradient(0, h - bar - 3, w, h - bar, 0x00000000, 0x80000000);
    }

    private static void drawTitle(GuiGraphics g, float pt) {
        float u = (titleAge + pt) / titleLife;
        float in = Mth.clamp(u / 0.1f, 0f, 1f), out = Mth.clamp((1f - u) / 0.25f, 0f, 1f);
        float alpha = Math.min(in, out);
        if (alpha <= 0.02f) {
            return;
        }
        Font font = Minecraft.getInstance().font;
        int w = g.guiWidth(), h = g.guiHeight();
        float scale = 2.4f + 0.7f * (1f - in) * (1f - in);   // menghentak masuk dari sedikit lebih besar
        int tw = font.width(title);
        float y = h * 0.72f;
        int a8 = Math.max(4, (int) (alpha * 255f)) << 24;
        g.pose().pushPose();
        g.pose().translate(w / 2f, y, 0f);
        g.pose().scale(scale, scale, 1f);
        g.drawString(font, title, -tw / 2, -font.lineHeight / 2, a8 | titleColor, true);
        g.pose().popPose();
        int half = (int) (tw * scale / 2f) + 10;   // garis tipis di kiri-kanan judul, memanjang saat masuk
        int len = (int) ((30 + w * 0.12f) * in);
        int ly = (int) y;
        int line = (Math.max(4, (int) (alpha * 190f)) << 24) | titleColor;
        g.fill(w / 2 - half - len, ly, w / 2 - half, ly + 1, line);
        g.fill(w / 2 + half, ly, w / 2 + half + len, ly + 1, line);
    }

    private static void drawVignette(GuiGraphics g, float v) {
        int w = g.guiWidth(), h = g.guiHeight();
        int solid = ((int) (Mth.clamp(v, 0f, 1f) * 170f) << 24) | (vignetteColor & 0xFFFFFF);
        int clear = vignetteColor & 0xFFFFFF;
        int bandY = (int) (h * 0.28f), bandX = (int) (w * 0.22f);
        g.fillGradient(0, 0, w, bandY, solid, clear);           // atas
        g.fillGradient(0, h - bandY, w, h, clear, solid);       // bawah
        g.pose().pushPose();                                    // kiri (diputar supaya gradasinya mendatar)
        g.pose().translate(0f, h, 0f);
        g.pose().mulPose(Axis.ZP.rotationDegrees(-90f));
        g.fillGradient(0, 0, h, bandX, solid, clear);
        g.pose().popPose();
        g.pose().pushPose();                                    // kanan
        g.pose().translate(w, 0f, 0f);
        g.pose().mulPose(Axis.ZP.rotationDegrees(90f));
        g.fillGradient(0, 0, h, bandX, solid, clear);
        g.pose().popPose();
    }

    private static void drawLines(GuiGraphics g, float s) {
        int w = g.guiWidth(), h = g.guiHeight();
        float cx = w / 2f, cy = h / 2f;
        float outer = (float) Math.sqrt(cx * cx + cy * cy) + 4f;
        Random random = new Random(ticks / 2 * 1013L);   // pola berganti tiap 2 tick: garis berkedip
        int count = 54;
        for (int i = 0; i < count; i++) {
            float angle = random.nextFloat() * (float) (Math.PI * 2.0);
            float inner = outer * (0.38f + random.nextFloat() * 0.3f) * (1.15f - 0.25f * s);
            int thick = 1 + random.nextInt(3);
            int alpha = (int) (Mth.clamp(s, 0f, 1f) * (120 + random.nextInt(110)));
            g.pose().pushPose();
            g.pose().translate(cx, cy, 0f);
            g.pose().mulPose(Axis.ZP.rotation(angle));
            g.fillGradient(-thick, (int) inner, thick, (int) outer, 0x00FFFFFF, (alpha << 24) | 0xFFFFFF);
            g.pose().popPose();
        }
    }
}
