package com.shazammod.client.anim;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.shazammod.ShazamClientState;
import com.shazammod.client.fx.LintangCine;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;

/**
 * 0.33 Lapisan pose tambahan (dipanggil dari HumanoidModelMixin & PlayerRendererMixin sesudah ShazamPoses):
 * - Lintang melemah (Nether / Cryon): animasi roboh berlutut lalu sikap lemah terus-menerus (bungkuk, napas berat, goyah).
 * - Gerak sekunder Lintang & Sabbac supaya terasa hidup seperti di dunia nyata: badan condong saat mempercepat dan
 *   tertahan ke belakang saat mengerem (pegas teredam, ada sedikit pantulan), miring ke dalam belokan, menekuk saat
 *   mendarat, napas & geser berat badan saat diam, dan tersentak saat kena pukul.
 * (Eksperimen Evolusi Surya sekarang clip biasa di Clips: LINTANG_RITE.)
 * 0.34: pose akhirnya dihaluskan PoseFilter (pegas per frame) supaya semua animasi Lintang & Sabbac mulus.
 */
public final class LintangBody {
    private static Clip collapse;
    private static boolean failed;

    /** Keadaan pegas per pemain, dimajukan sekali per tick. */
    private static final class Motion {
        int lastTick = Integer.MIN_VALUE;
        double sfPrev;
        double ssPrev;
        double vyPrev;
        float yawPrev;
        boolean groundPrev = true;
        float tilt, tiltO, tiltV;
        float lean, leanO, leanV;
        float sink, sinkO, sinkV;
    }

    private static final Map<Integer, Motion> MOTION = new HashMap<>();

    private LintangBody() {
    }

    private static void build() {
        if (collapse != null || failed) return;
        try {
            collapse = Clip.builder(72.0f)
                    .key(0.0f, Ease.OUT_QUAD).head(-22.0f, 0.0f, 0.0f).rightArm(-18.0f, 0.0f, 34.0f).leftArm(-18.0f, 0.0f, -34.0f).tilt(-8.0f).drop(0.0f).shake(5.0f)
                    .key(6.0f, Ease.OUT_CUBIC).head(26.0f, 0.0f, 0.0f).rightArm(-78.0f, -46.0f, 6.0f).leftArm(-34.0f, 22.0f, -10.0f).tilt(18.0f).drop(0.12f).shake(2.5f)
                    .key(16.0f, Ease.IN_QUAD).head(34.0f, 0.0f, 0.0f).rightArm(-70.0f, -42.0f, 6.0f).leftArm(-58.0f, 0.0f, -18.0f)
                    .rightLeg(-80.0f, 0.0f, 8.0f).leftLeg(60.0f, 0.0f, -8.0f).tilt(30.0f).drop(0.58f).shake(2.0f)
                    .key(21.0f, Ease.OUT_BACK).tilt(35.0f).drop(0.62f).shake(3.2f)
                    .key(44.0f, Ease.IN_OUT_SINE).head(28.0f, 0.0f, 0.0f).tilt(28.0f).drop(0.57f).shake(1.2f)
                    .key(58.0f, Ease.IN_OUT_SINE).head(20.0f, 0.0f, 0.0f).rightLeg(-30.0f, 0.0f, 6.0f).leftLeg(20.0f, 0.0f, -6.0f)
                    .leftArm(-24.0f, 0.0f, -14.0f).tilt(20.0f).drop(0.24f).shake(1.6f)
                    .key(72.0f, Ease.IN_OUT_SINE).head(14.0f, 0.0f, 0.0f).rightArm(-32.0f, -30.0f, 4.0f).leftArm(6.0f, 0.0f, -6.0f)
                    .rightLeg(-4.0f, 0.0f, 4.0f).leftLeg(4.0f, 0.0f, -4.0f).tilt(12.0f).drop(0.05f).shake(0.4f)
                    .fade(2.0f, 12.0f).build();
        } catch (Throwable t) {
            failed = true;
        }
    }

    /** Pengganti panggilan ShazamPoses.apply dari HumanoidModelMixin. */
    public static void apply(HumanoidModel<?> model, AbstractClientPlayer p, float ageInTicks) {
        ShazamPoses.apply(model, p, ageInTicks);
        try {
            extra(model, p, ageInTicks);
        } catch (Throwable ignored) {
        }
        try {   // 0.34: penghalus gerak per frame (pegas teredam) untuk Lintang & Sabbac
            if (hero(p.getId())) {
                PoseFilter.apply(model, p, ageInTicks);
            } else if (ageInTicks > 0.0001f) {
                PoseFilter.forget(p.getId());
            }
        } catch (Throwable ignored) {
        }
    }

    /** Pengganti panggilan ShazamPoses.applyBodyTransform dari PlayerRendererMixin. */
    public static void applyBodyTransform(AbstractClientPlayer p, PoseStack ps, float pt, float scale) {
        ShazamPoses.applyBodyTransform(p, ps, pt, scale);
        try {
            extraBody(p, ps, pt);
        } catch (Throwable ignored) {
        }
    }

    private static boolean hero(int id) {
        return ShazamClientState.isTransformed(id) && (ShazamClientState.isLintang(id) || ShazamClientState.isSabbac(id)
                || ShazamClientState.isHelion(id));   // 0.43
    }

    private static Motion motion(AbstractClientPlayer p) {
        Motion m = MOTION.get(p.getId());
        if (m == null) {
            if (MOTION.size() > 64) MOTION.clear();
            m = new Motion();
            MOTION.put(p.getId(), m);
        }
        int tick = p.tickCount;
        if (m.lastTick == Integer.MIN_VALUE || tick < m.lastTick || tick - m.lastTick > 4) {
            m.lastTick = tick;
            m.yawPrev = p.yBodyRot;
            m.groundPrev = p.onGround();
            return m;
        }
        while (m.lastTick < tick) {
            step(m, p);
            m.lastTick++;
        }
        return m;
    }

    private static void step(Motion m, AbstractClientPlayer p) {
        double vx = p.getX() - p.xo, vy = p.getY() - p.yo, vz = p.getZ() - p.zo;
        float yaw = p.yBodyRot * Mth.DEG_TO_RAD;
        double fx = -Mth.sin(yaw), fz = Mth.cos(yaw);
        double sf = vx * fx + vz * fz;      // laju maju (blok/tick)
        double ss = vx * -fz + vz * fx;     // laju ke kanan
        double af = sf - m.sfPrev, as = ss - m.ssPrev;
        m.sfPrev = sf;
        m.ssPrev = ss;
        float yawRate = Mth.wrapDegrees(p.yBodyRot - m.yawPrev);
        m.yawPrev = p.yBodyRot;
        float tiltT = Mth.clamp((float) af * 90f, -9f, 9f) + Mth.clamp((float) sf * 14f, -2f, 5f);
        float leanT = Mth.clamp(yawRate * 0.22f, -7f, 7f) + Mth.clamp((float) -as * 70f, -6f, 6f);
        boolean ground = p.onGround();
        if (ground && !m.groundPrev && m.vyPrev < -0.25) {
            m.sinkV += (float) Math.min(0.2, -m.vyPrev * 0.22);
        }
        m.groundPrev = ground;
        m.vyPrev = vy;
        m.tiltO = m.tilt;
        m.leanO = m.lean;
        m.sinkO = m.sink;
        m.tiltV = (m.tiltV + (tiltT - m.tilt) * 0.32f) * 0.68f;
        m.tilt += m.tiltV;
        m.leanV = (m.leanV + (leanT - m.lean) * 0.3f) * 0.7f;
        m.lean += m.leanV;
        m.sinkV = (m.sinkV - m.sink * 0.35f) * 0.72f;
        m.sink += m.sinkV;
    }

    private static float still(Motion m) {
        return 1f - Mth.clamp((float) Math.abs(m.sfPrev) * 8f, 0f, 1f);
    }

    private static float hurt(AbstractClientPlayer p, float pt) {
        if (p.hurtTime <= 0) return 0f;
        float h = Mth.clamp((p.hurtTime - pt) / 10f, 0f, 1f);
        return h * h;
    }

    private static void extra(HumanoidModel<?> model, AbstractClientPlayer p, float age) {
        float pt = age - p.tickCount;
        if (pt < 0.0f || pt > 1.0f) pt = 0.0f;
        int id = p.getId();
        if (hero(id)) {
            Motion m = motion(p);
            float h = hurt(p, pt);
            float breathe = Mth.sin(age * 0.085f) * still(m);
            model.rightArm.zRot += 0.03f * breathe + 0.32f * h;
            model.leftArm.zRot -= 0.03f * breathe + 0.32f * h;
            model.head.xRot -= 0.35f * h;
        }
        float col = LintangCine.collapseAge(p, pt);
        float w = LintangCine.weakness(p, pt);
        if (col < 0.0f && w < 0.01f) return;
        build();
        if (failed) return;
        if (col >= 0.0f) collapse.apply(model, col, 0.0f, 0.0f, 1.0f);
        if (w > 0.01f) {
            float k = col >= 0.0f ? w * Mth.clamp((col - 54.0f) / 18.0f, 0.0f, 1.0f) : w;
            if (k <= 0.0f) return;
            float breathe = Mth.sin(age * 0.11f);
            model.head.xRot += (0.24f + 0.035f * breathe) * k;
            model.head.zRot += 0.05f * Mth.sin(age * 0.045f) * k;
            if (!p.swinging) {
                model.rightArm.xRot = Mth.lerp(0.5f * k, model.rightArm.xRot, -0.62f);
                model.rightArm.yRot = Mth.lerp(0.5f * k, model.rightArm.yRot, -0.5f);
                model.rightArm.zRot = Mth.lerp(0.5f * k, model.rightArm.zRot, 0.1f);
            }
            model.leftArm.xRot += (0.14f + 0.03f * breathe) * k;
            model.leftArm.zRot = Mth.lerp(0.45f * k, model.leftArm.zRot, -0.04f);
        }
    }

    private static void extraBody(AbstractClientPlayer p, PoseStack ps, float pt) {
        float tilt = 0.0f, drop = 0.0f, lean = 0.0f;
        int id = p.getId();
        float age = p.tickCount + pt;
        if (hero(id)) {
            Motion m = motion(p);
            float w = ShazamClientState.isFlying(id) ? 0.25f : 1.0f;
            float still = still(m);
            tilt += (Mth.lerp(pt, m.tiltO, m.tilt) + 1.1f * still * Mth.sin(age * 0.085f)) * w;
            lean += (Mth.lerp(pt, m.leanO, m.lean) + 0.6f * still * Mth.sin(age * 0.031f)) * w;
            drop += Mth.lerp(pt, m.sinkO, m.sink) * w;
            float h = hurt(p, pt);
            tilt -= 7.0f * h;
            lean += 3.0f * h * ((id & 1) == 0 ? 1f : -1f);
        }
        float col = LintangCine.collapseAge(p, pt);
        float wk = LintangCine.weakness(p, pt);
        if (col >= 0.0f || wk >= 0.01f) {
            build();
            if (!failed) {
                if (col >= 0.0f) {
                    float wt = collapse.weight(col);
                    float sh = collapse.shake(col);
                    tilt += (collapse.tilt(col) + sh * Clip.noise(col, 3.1f) * 0.5f) * wt;
                    drop += collapse.drop(col) * wt;
                    lean += (collapse.lean(col) + sh * Clip.noise(col, 4.7f) * 0.5f) * wt;
                }
                float k = col >= 0.0f ? wk * Mth.clamp((col - 54.0f) / 18.0f, 0.0f, 1.0f) : wk;
                if (k > 0.0f) {
                    tilt += (11.0f + 2.4f * Mth.sin(age * 0.11f)) * k;
                    drop += 0.045f * k;
                    lean += 2.6f * Mth.sin(age * 0.045f) * k;
                }
            }
        }
        if (Math.abs(tilt) < 0.01f && Math.abs(drop) < 0.0005f && Math.abs(lean) < 0.01f) return;
        ps.translate(0.0f, -drop, 0.0f);
        ps.translate(0.0f, 0.9f, 0.0f);
        ps.mulPose(Axis.ZP.rotationDegrees(-lean));
        ps.mulPose(Axis.XP.rotationDegrees(-tilt));
        ps.translate(0.0f, -0.9f, 0.0f);
    }
}
