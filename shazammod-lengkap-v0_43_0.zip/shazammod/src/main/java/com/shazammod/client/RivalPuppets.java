package com.shazammod.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamForm;
import com.shazammod.ShazamMod;
import com.shazammod.ShazamStatePayload;
import com.shazammod.rival.RivalChampion;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.client.resources.PlayerSkin;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;

/**
 * 0.30 Rival Juara digambar sebagai pemain boneka: tiap RivalChampion yang kelihatan di client punya satu RemotePlayer
 * palsu (id negatif, nggak bisa dipukul atau didorong, tanpa papan nama) yang mengikuti posisi, arah, ayunan tangan,
 * kilat merah saat terluka, dan ukurannya tiap tick. Statusnya (berubah wujud, terbang, amarah, juara) diisi ke
 * ShazamClientState seperti pemain sungguhan, dan animasi yang dikirim server untuk rival diputar di boneka ini.
 * Hasilnya: jubah, lambang, tanduk, pose, dewa/iblis yang datang, dan semua efek skill pemain langsung berlaku untuk rival.
 *
 * Yang dipukul pemain tetap entity rivalnya (kotak tabraknya sama besar, tapi rival sendiri nggak digambar).
 *
 * Skin: kalau ada assets/shazammod/textures/entity/rival/[shazam|black_adam|sabbac].png (64x64, format skin pemain),
 * itu yang dipakai; kalau nggak ada, rival memakai skin bawaan Minecraft (kostum juaranya dari lapisan mod).
 */
public final class RivalPuppets {
    private RivalPuppets() {}

    /** Id boneka = PUPPET_BASE - id rival (selalu negatif, nggak bentrok dengan entity dari server). */
    private static final int PUPPET_BASE = -1000;
    private static final String[] DEFAULT_SKINS = {"steve", "kai", "efe"};

    private static final Map<Integer, Puppet> PUPPETS = new HashMap<>();
    private static final Map<ShazamForm, Optional<ResourceLocation>> CUSTOM_SKINS = new HashMap<>();

    /** Boneka untuk entity ini: rival -> bonekanya (dibuat kalau belum ada), selain itu null. */
    public static Puppet puppetOf(Entity entity) {
        if (!(entity instanceof RivalChampion rival) || !(rival.level() instanceof ClientLevel level) || rival.isRemoved()) {
            return null;
        }
        Puppet puppet = PUPPETS.get(rival.getId());
        if (puppet == null || puppet.isRemoved()) {
            puppet = spawn(level, rival);
        }
        return puppet;
    }

    /** Dipanggil tiap tick client (sesudah semua entity bergerak, sebelum animasi baru diputar). */
    public static void tick(ClientLevel level) {
        Iterator<Map.Entry<Integer, Puppet>> it = PUPPETS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Puppet> e = it.next();
            Puppet puppet = e.getValue();
            Entity rival = level.getEntity(e.getKey());
            if (!(rival instanceof RivalChampion) || rival.isRemoved() || puppet.level() != level || puppet.isRemoved()) {
                despawn(puppet);
                it.remove();
            }
        }
        List<RivalChampion> rivals = new ArrayList<>();
        for (Entity entity : level.entitiesForRendering()) {
            if (entity instanceof RivalChampion rival && !rival.isRemoved()) {
                rivals.add(rival);
            }
        }
        for (RivalChampion rival : rivals) {
            Puppet puppet = PUPPETS.get(rival.getId());
            if (puppet == null) {
                puppet = spawn(level, rival);
            }
            puppet.follow(rival, false);
        }
    }

    public static void clear() {
        for (Puppet puppet : PUPPETS.values()) {
            despawn(puppet);
        }
        PUPPETS.clear();
        CUSTOM_SKINS.clear();
    }

    /** Skin khusus dari resource pack dimuat ulang (F3+T). */
    public static void resetSkins() {
        CUSTOM_SKINS.clear();
    }

    private static Puppet spawn(ClientLevel level, RivalChampion rival) {
        Puppet puppet = new Puppet(level, rival);
        puppet.follow(rival, true);
        level.addEntity(puppet);
        PUPPETS.put(rival.getId(), puppet);
        return puppet;
    }

    private static void despawn(Puppet puppet) {
        ShazamClientState.removeState(puppet.getId());
        if (puppet.level() instanceof ClientLevel level && level.getEntity(puppet.getId()) == puppet) {
            level.removeEntity(puppet.getId(), Entity.RemovalReason.DISCARDED);
        }
    }

    private static PlayerSkin skin(ShazamForm form) {
        Optional<ResourceLocation> custom = CUSTOM_SKINS.computeIfAbsent(form, f -> {
            ResourceLocation loc = ShazamMod.id("textures/entity/rival/" + f.id + ".png");
            Optional<Resource> res = Minecraft.getInstance().getResourceManager().getResource(loc);
            return res.isPresent() ? Optional.of(loc) : Optional.empty();
        });
        if (custom.isPresent()) {
            return new PlayerSkin(custom.get(), null, null, null, PlayerSkin.Model.WIDE, true);
        }
        String name = DEFAULT_SKINS[Math.floorMod(form.ordinal(), DEFAULT_SKINS.length)];
        return new PlayerSkin(ResourceLocation.withDefaultNamespace("textures/entity/player/wide/" + name + ".png"), null, null,
                null, PlayerSkin.Model.WIDE, true);
    }

    /** Pemain boneka yang mengikuti satu rival. Nggak berpikir & nggak bergerak sendiri. */
    public static final class Puppet extends RemotePlayer {
        private final int rivalId;
        private ShazamForm form = ShazamForm.SHAZAM;
        private ShazamStatePayload lastState;

        Puppet(ClientLevel level, RivalChampion rival) {
            super(level, new GameProfile(UUID.nameUUIDFromBytes(("shazammod:rival/" + rival.getUUID()).getBytes()), "Rival"));
            this.rivalId = rival.getId();
            this.setId(PUPPET_BASE - rival.getId());
            this.noCulling = true;
            this.entityData.set(DATA_PLAYER_MODE_CUSTOMISATION, (byte) 0x7F);   // semua lapisan skin terlihat
        }

        public int rivalId() {
            return rivalId;
        }

        /** Salin posisi, arah, ayunan, luka, dan ukuran dari rival; first = langsung di tempat (tanpa interpolasi). */
        void follow(RivalChampion r, boolean first) {
            if (first) {
                this.moveTo(r.getX(), r.getY(), r.getZ(), r.getYRot(), r.getXRot());
                this.setOldPosAndRot();
                this.yBodyRot = r.yBodyRot;
                this.yHeadRot = r.yHeadRot;
            }
            this.setOldPosAndRot();
            this.yBodyRotO = this.yBodyRot;
            this.yHeadRotO = this.yHeadRot;
            this.oAttackAnim = this.attackAnim;
            this.setPos(r.getX(), r.getY(), r.getZ());
            this.setYRot(r.getYRot());
            this.setXRot(r.getXRot());
            this.yBodyRot = r.yBodyRot;
            this.yHeadRot = r.yHeadRot;
            this.setOnGround(r.onGround());
            this.setDeltaMovement(this.getX() - this.xo, this.getY() - this.yo, this.getZ() - this.zo);
            this.calculateEntityAnimation(false);
            this.attackAnim = r.attackAnim;
            this.swinging = r.swinging;
            this.swingTime = r.swingTime;
            this.swingingArm = r.swingingArm;
            this.hurtTime = r.hurtTime;
            this.hurtDuration = r.hurtDuration;
            this.deathTime = r.deathTime;
            this.setInvisible(r.isInvisible());
            this.setPose(r.getPose());
            AttributeInstance scale = this.getAttribute(Attributes.SCALE);
            double want = r.getScale();
            if (scale != null && Math.abs(scale.getBaseValue() - want) > 1.0E-4) {
                scale.setBaseValue(want);
                this.refreshDimensions();
            }
            this.form = r.form();
            // status juara boneka (dibaca jubah, lambang, pose, efek) dari bendera rival
            boolean transformed = r.flag(RivalChampion.TRANSFORMED);
            ShazamStatePayload state = new ShazamStatePayload(this.getId(), transformed,
                    transformed && r.flag(RivalChampion.FLYING), r.flag(RivalChampion.HOOD), transformed && r.flag(RivalChampion.RAGE),
                    transformed && r.flag(RivalChampion.MERCURY), this.form.ordinal(), transformed && r.flag(RivalChampion.CHARGED));
            if (!state.equals(lastState)) {
                ShazamClientState.putState(state);
                lastState = state;
            }
        }

        @Override
        public void tick() {
            // digerakkan RivalPuppets.tick, bukan oleh dunia
        }

        @Override
        public void aiStep() {
        }

        @Override
        public boolean isPickable() {
            return false;
        }

        @Override
        public boolean isPushable() {
            return false;
        }

        @Override
        public boolean canBeCollidedWith() {
            return false;
        }

        @Override
        public boolean isInvisibleTo(Player player) {
            return true;   // papan nama disembunyikan (badannya tetap digambar)
        }

        @Override
        public boolean shouldShowName() {
            return false;
        }

        @Override
        public boolean isSpectator() {
            return false;
        }

        @Override
        public boolean isCreative() {
            return false;
        }

        @Override
        public PlayerSkin getSkin() {
            return RivalPuppets.skin(form);
        }
    }
}
