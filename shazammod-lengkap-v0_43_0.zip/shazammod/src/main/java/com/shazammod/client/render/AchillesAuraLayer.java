package com.shazammod.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.client.anim.ShazamPoses;

import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

import com.shazammod.ShazamMod;

/**
 * Kulit Achilles: perisai sisik heksagonal emas yang menyelubungi seluruh badan selama hampir kebal.
 * Polanya mengalir pelan, berdenyut, dan sesekali berkilat (tekstur textures/entity/fx/aegis.png).
 */
public class AchillesAuraLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation SWIRL = ShazamMod.id("textures/entity/fx/aegis.png");

    public AchillesAuraLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, AbstractClientPlayer player,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        float strength = ShazamPoses.auraStrength(player, partialTick);
        if (strength <= 0.01f) {
            return;
        }
        float scroll = ageInTicks * 0.006f;
        VertexConsumer consumer = buffer.getBuffer(RenderType.energySwirl(SWIRL, scroll % 1.0f, (scroll * 0.35f) % 1.0f));
        poseStack.pushPose();
        poseStack.translate(0.0f, 0.75f, 0.0f);
        poseStack.scale(1.09f, 1.06f, 1.09f);
        poseStack.translate(0.0f, -0.75f, 0.0f);
        float pulse = 0.75f + 0.25f * Mth.sin(ageInTicks * 0.35f) + ((int) ageInTicks % 23 == 0 ? 0.35f : 0f);
        float k = Mth.clamp(strength * pulse, 0f, 1f);
        int r = (int) (255 * k);
        int g = (int) (200 * k);
        int b = (int) (90 * k);
        this.getParentModel().renderToBuffer(poseStack, consumer, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY,
                0xFF000000 | (r << 16) | (g << 8) | b);
        poseStack.popPose();
    }
}
