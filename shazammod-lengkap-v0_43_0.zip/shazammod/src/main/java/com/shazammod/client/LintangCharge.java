package com.shazammod.client;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamActionPayload;
import com.shazammod.ShazamNetwork;
import com.shazammod.client.fx.LintangFx;

import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * 0.42 Tombol X Lintang ditahan = sinar mata di-charge, dilepas = ditembakkan. Mata langsung memanas di client sendiri
 * (nggak menunggu server), lalu server menghitung kuat sinarnya dari lama X ditahan. Shift + X tetap Angkat & Lempar.
 */
public final class LintangCharge {
    private LintangCharge() {}

    private static boolean charging;
    private static int startTick;

    /** X yang baru ditekan ini dipakai buat charge? (Lintang, sudah berubah, nggak sambil Shift) */
    public static boolean wants(Minecraft mc) {
        return mc.player != null && ShazamClientState.isLintang() && ShazamClientState.transformed && !mc.player.isShiftKeyDown();
    }

    public static void press(Minecraft mc) {
        if (charging || mc.player == null) {
            return;
        }
        charging = true;
        startTick = mc.player.tickCount;
        PacketDistributor.sendToServer(new ShazamActionPayload(ShazamNetwork.ACTION_IRIS_CHARGE));
        LintangFx.localCharge(mc.player);
    }

    /** Tiap tick client: X sudah dilepas -> tembak. Berhenti jadi Lintang di tengah charge -> batal. */
    public static void tick(Minecraft mc, boolean down) {
        if (!charging) {
            return;
        }
        if (mc.player == null || !ShazamClientState.isLintang() || !ShazamClientState.transformed) {
            charging = false;
            return;
        }
        if (!down) {
            charging = false;
            PacketDistributor.sendToServer(new ShazamActionPayload(ShazamNetwork.ACTION_IRIS_FIRE));
            LintangFx.localRelease(mc.player);
        }
    }

    public static boolean active() {
        return charging;
    }

    /** 0-1 seberapa penuh charge-nya sekarang (meteran HUD). */
    public static float level(float partialTick) {
        Minecraft mc = Minecraft.getInstance();
        if (!charging || mc.player == null) {
            return 0f;
        }
        return Mth.clamp((mc.player.tickCount - startTick + partialTick) / ShazamAnim.IRIS_CHARGE_TICKS, 0f, 1f);
    }
}
