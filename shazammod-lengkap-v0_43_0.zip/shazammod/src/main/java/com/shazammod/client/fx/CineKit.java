package com.shazammod.client.fx;

import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Vfx;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.registries.DeferredHolder;

/** Pustaka efek sinematik berlapis ("tebal") yang dipakai Lintang & Sabbac. */
final class CineKit {
    static final Vec3 UP = new Vec3(0.0, 1.0, 0.0);

    private CineKit() {
    }

    static boolean isLocal(AbstractClientPlayer p) {
        return p == Minecraft.getInstance().player;
    }

    static Vec3 chest(AbstractClientPlayer p) {
        return new Vec3(p.getX(), p.getY() + p.getBbHeight() * 0.68, p.getZ());
    }

    static Vec3 feet(AbstractClientPlayer p) {
        return new Vec3(p.getX(), p.getY() + 0.05, p.getZ());
    }

    static Vec3 eyes(AbstractClientPlayer p) {
        return p.getEyePosition(1.0f);
    }

    static Vec3 look(AbstractClientPlayer p) {
        return p.getViewVector(1.0f);
    }

    static Vec3 mouth(AbstractClientPlayer p) {
        Vec3 e = eyes(p);
        Vec3 l = look(p);
        return new Vec3(e.x + l.x * 0.28, e.y - 0.16 + l.y * 0.2, e.z + l.z * 0.28);
    }

    static Lightning.Anchor chestAnchor(AbstractClientPlayer p) {
        return Lightning.Anchor.on(p, 0.0, p.getBbHeight() * 0.68, 0.0);
    }

    static Lightning.Anchor headAnchor(AbstractClientPlayer p) {
        return Lightning.Anchor.on(p, 0.0, p.getBbHeight() * 0.9, 0.0);
    }

    static Vec3 norm(Vec3 v) {
        double l = Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
        return l < 1.0E-6 ? UP : new Vec3(v.x / l, v.y / l, v.z / l);
    }

    static Vec3 flat(Vec3 v) {
        return norm(new Vec3(v.x, 0.0, v.z));
    }

    static ClientLevel level(AbstractClientPlayer p) {
        return (ClientLevel) p.level();
    }

    @SuppressWarnings("rawtypes")
    static void sound(ClientLevel level, Vec3 at, DeferredHolder holder, float volume, float pitch) {
        level.playLocalSound(at.x, at.y, at.z, (SoundEvent) holder.get(), SoundSource.PLAYERS, volume, pitch, false);
    }

    static Ground.Map ground(ClientLevel level, Vec3 at, double radius) {
        return ShazamFx.ground(level, at, radius);
    }

    /** Gelombang kejut dua lapis: cincin lebar lembut + cincin tipis terang yang lebih cepat. */
    static void shock(ClientLevel level, Vec3 at, Vec3 normal, double radius, int rgb, int core, int life, float strength, boolean onGround) {
        shock(level, at, normal, radius, rgb, core, life, strength, onGround, false);
    }

    /** 0.35 soft = true: cincin udara/debu biasa (tembus pandang, kena cahaya dunia), bukan cincin cahaya. */
    static void shock(ClientLevel level, Vec3 at, Vec3 normal, double radius, int rgb, int core, int life, float strength, boolean onGround,
                      boolean soft) {
        Ground.Map g = onGround ? ground(level, at, radius) : null;
        Vec3 c = g != null ? g.center(at) : at;
        Vfx.add(new Fx.Wave(c, normal, radius, Math.max(0.12, radius * 0.045), rgb, life, strength, 0.08f, g, soft));
        Vfx.add(new Fx.Wave(c, normal, radius * 0.62, Math.max(0.06, radius * 0.02), core, Math.max(4, (int) (life * 0.6f)), strength, 0.03f, g, soft));
        Vfx.add(new Fx.Wave(c, normal, radius * 1.25, Math.max(0.2, radius * 0.08), rgb, life + 6, strength * 0.35f, 0.12f, g, soft));
        if (g != null) {
            // 0.33: dinding debu di garis depan gelombang, seperti gelombang kejut yang menyapu tanah di film
            final int dust = Draw.mix(0xBFAE96, rgb, 0.15);
            final int span = Math.max(4, life / 2);
            ShazamFx.schedule(0, Math.min(12, span), (lvl, t) -> {
                double k = 1.0 - Math.pow(1.0 - t / (double) span, 3.0);
                double front = radius * (0.15 + 0.85 * k);
                int n = Vfx.count(4 + radius * 0.8);
                for (int i = 0; i < n; i++) {
                    double ang = lvl.random.nextDouble() * Math.PI * 2.0;
                    double ca = Math.cos(ang), sa = Math.sin(ang);
                    Vfx.dust(c.x + ca * front, c.y + 0.06, c.z + sa * front, ca * 0.07, 0.025 + lvl.random.nextDouble() * 0.045, sa * 0.07,
                            dust, 0.32f + lvl.random.nextFloat() * 0.2f, 20 + lvl.random.nextInt(10));
                }
            });
        }
    }

    /** Ledakan cahaya berlapis: flash + bubble + flare anamorfik. */
    static void burst(Vec3 at, float size, int rgb, int core, int life, float strength) {
        Vfx.add(new Fx.Flash(at, size, core, Math.max(4, life / 2), Math.min(1.0f, strength * 1.1f)));
        Vfx.add(new Fx.Flash(at, size * 1.8f, rgb, life, strength * 0.6f));
        Vfx.add(new Fx.Bubble(at, size * 1.4, rgb, life, strength * 0.7f, 1.0, 2.2, true));
        CineFx.flare(at, core, size * 3.6f, 0.16f + size * 0.03f, Math.min(1.0f, strength), life + 4);
    }

    static void sparks(Vec3 at, int count, int rgb, double speed, float size, int life, double floorY) {
        RandomSource r = Vfx.random();
        int n = Vfx.count(count);
        for (int i = 0; i < n; i++) {
            Vec3 d = ShazamFx.randomDir(r);
            double s = speed * (0.45 + r.nextDouble() * 0.9);
            Vfx.spark(at.x, at.y, at.z, d.x * s, d.y * s + speed * 0.25, d.z * s, rgb, size * (0.7f + r.nextFloat() * 0.6f), life + r.nextInt(5), floorY);
        }
    }

    static void motesOut(Vec3 at, int count, int rgb, double speed, float size, int life) {
        RandomSource r = Vfx.random();
        int n = Vfx.count(count);
        for (int i = 0; i < n; i++) {
            Vec3 d = ShazamFx.randomDir(r);
            double s = speed * (0.4 + r.nextDouble());
            Vfx.mote(at.x + d.x * 0.2, at.y + d.y * 0.2, at.z + d.z * 0.2, d.x * s, d.y * s, d.z * s, rgb, size, life + r.nextInt(8));
        }
    }

    static void embers(Vec3 at, int count, double spread, double up, float size, int life) {
        RandomSource r = Vfx.random();
        int n = Vfx.count(count);
        for (int i = 0; i < n; i++) {
            double a = r.nextDouble() * Math.PI * 2.0;
            double rr = spread * Math.sqrt(r.nextDouble());
            Vfx.ember(at.x + Math.cos(a) * rr, at.y + r.nextDouble() * 0.4, at.z + Math.sin(a) * rr,
                    (r.nextDouble() - 0.5) * 0.05, up * (0.5 + r.nextDouble()), (r.nextDouble() - 0.5) * 0.05, size * (0.7f + r.nextFloat() * 0.6f), life + r.nextInt(10));
        }
    }

    /** Kawah: retakan panas + puing terlempar + debu + gelombang. */
    static void crater(ClientLevel level, Vec3 at, double radius, int heat, int dust, int life) {
        Ground.Map g = ground(level, at, radius + 1.0);
        Vec3 c = g.center(at);
        RandomSource r = Vfx.random();
        Vfx.add(new Ground.Cracks(c, g, 6 + (int) (radius * 1.6), (float) radius, 160 + life, 50 + life / 2, heat, r.nextLong()));
        Vfx.add(new Ground.Debris(c, g, 8 + (int) (radius * 2.2), 0.14 + radius * 0.025, 0.36 + radius * 0.02, 0.4 + radius * 0.12, 46));
        Vfx.add(new Fx.Scorch(c, radius * 0.55, 180, 40, g));
        ShazamFx.dustPuffs(level, c, dust, 10 + (int) (radius * 5.0), radius * 0.6, 0.12 + radius * 0.03);
        ShazamFx.smokeCloud(level, c, 0x5A5048, 3 + (int) radius, radius * 0.7);
    }

    static void camera(AbstractClientPlayer p, Vec3 at, float shake, double range) {
        if (isLocal(p)) CameraShake.add(shake);
        else ShazamFx.shakeAround(at, shake * 0.7f, range);
    }

    /** Aliran foton: sinar-sinar tipis yang meluncur dari arah sumber cahaya lalu terserap ke dada. */
    static final class PhotonStreams extends Effect {
        private final AbstractClientPlayer p;
        private final Vec3 dir;
        private final int rgb;
        private final int core;
        private final double[] seed;
        private final double[] off;

        PhotonStreams(AbstractClientPlayer p, Vec3 dir, int count, int life, int rgb, int core) {
            super(life);
            this.p = p;
            this.dir = norm(dir);
            this.rgb = rgb;
            this.core = core;
            RandomSource r = Vfx.random();
            int n = Math.max(4, Vfx.count(count));
            this.seed = new double[n];
            this.off = new double[n * 3];
            for (int i = 0; i < n; i++) {
                seed[i] = r.nextDouble();
                off[i * 3] = (r.nextDouble() - 0.5) * 7.0;
                off[i * 3 + 1] = (r.nextDouble() - 0.5) * 7.0;
                off[i * 3 + 2] = (r.nextDouble() - 0.5) * 7.0;
            }
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float t = time(pt);
            float fade = Mth.clamp(t / 10.0f, 0.0f, 1.0f) * Mth.clamp((life - t) / 12.0f, 0.0f, 1.0f);
            if (fade <= 0.01f || !p.isAlive()) return;
            Vec3 c = chestAnchor(p).at(pt);
            for (int i = 0; i < seed.length; i++) {
                double ox = c.x + dir.x * 26.0 + off[i * 3];
                double oy = c.y + dir.y * 26.0 + off[i * 3 + 1];
                double oz = c.z + dir.z * 26.0 + off[i * 3 + 2];
                double ph = (t * (0.035 + seed[i] * 0.03) + seed[i]) % 1.0;
                double h = ph * ph * (3.0 - 2.0 * ph);
                double tl = Math.max(0.0, h - 0.22);
                double hx = ox + (c.x - ox) * h, hy = oy + (c.y - oy) * h, hz = oz + (c.z - oz) * h;
                double tx = ox + (c.x - ox) * tl, ty = oy + (c.y - oy) * tl, tz = oz + (c.z - oz) * tl;
                float a = fade * (float) Math.sin(ph * Math.PI);
                d.line(tx, ty, tz, hx, hy, hz, 0.015f, 0.06f, rgb, 0.0f, 0.75f * a);
                d.glow(hx, hy, hz, 0.22f, core, 0.55f * a);
            }
            float k = Mth.clamp(t / (float) life, 0.0f, 1.0f);
            d.glow(c.x, c.y, c.z, 0.5f + 0.9f * k, rgb, 0.35f * fade);
            d.glow(c.x, c.y, c.z, 0.25f + 0.35f * k, core, 0.6f * fade);
        }
    }

    /** Heliks DNA dari cahaya yang berputar & naik di sekitar tubuh (tanda mutasi genetik). */
    static final class Helix extends Effect {
        private final AbstractClientPlayer p;
        private final int a;
        private final int b;

        Helix(AbstractClientPlayer p, int life, int a, int b) {
            super(life);
            this.p = p;
            this.a = a;
            this.b = b;
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float t = time(pt);
            float fade = Mth.clamp(t / 14.0f, 0.0f, 1.0f) * Mth.clamp((life - t) / 16.0f, 0.0f, 1.0f);
            if (fade <= 0.01f || !p.isAlive()) return;
            Vec3 base = Lightning.Anchor.on(p, 0.0, 0.0, 0.0).at(pt);
            int seg = 30;
            double height = 2.4;
            double radius = 0.78 + 0.1 * Math.sin(t * 0.09);
            double spin = t * 0.17;
            double px1 = 0, py1 = 0, pz1 = 0, px2 = 0, py2 = 0, pz2 = 0;
            for (int i = 0; i <= seg; i++) {
                double f = i / (double) seg;
                double ang = spin + f * Math.PI * 3.2;
                double y = base.y + 0.02 + f * height;
                double x1 = base.x + Math.cos(ang) * radius, z1 = base.z + Math.sin(ang) * radius;
                double x2 = base.x + Math.cos(ang + Math.PI) * radius, z2 = base.z + Math.sin(ang + Math.PI) * radius;
                float edge = (float) Math.sin(f * Math.PI);
                float al = fade * (0.35f + 0.65f * edge);
                d.glow(x1, y, z1, 0.09f, a, 0.65f * al);
                d.glow(x2, y, z2, 0.09f, b, 0.65f * al);
                if (i > 0) {
                    d.line(px1, py1, pz1, x1, y, z1, 0.03f, 0.03f, a, 0.55f * al, 0.55f * al);
                    d.line(px2, py2, pz2, x2, y, z2, 0.03f, 0.03f, b, 0.55f * al, 0.55f * al);
                }
                if (i % 3 == 1) {
                    d.line(x1, y, z1, x2, y, z2, 0.012f, 0.012f, 0xFFFFFF, 0.28f * al, 0.28f * al);
                }
                px1 = x1; py1 = y; pz1 = z1;
                px2 = x2; py2 = y; pz2 = z2;
            }
        }
    }

    /** Kilau panas: cincin-cincin tipis yang naik (riak udara panas/plasma). */
    static void heatRings(Vec3 at, int rgb, double radius, int life) {
        Vfx.add(new Fx.Ripple(at, UP, 2.2, radius * 0.6, radius, 0.12, rgb, life, 0.45f, true));
    }
}
