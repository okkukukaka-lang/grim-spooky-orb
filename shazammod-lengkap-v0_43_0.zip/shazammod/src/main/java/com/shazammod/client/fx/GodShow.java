package com.shazammod.client.fx;

import com.shazammod.ShazamAnim;

/**
 * Jadwal & gerak masuk enam dewa saat transformasi (murni Java). Dewa datang SATU PER SATU, tiap dewa dengan
 * cara masuknya sendiri, lalu berdiri melengkung di belakang pemain (dilihat dari kamera) dengan urutan
 * S-H-A-Z-A-M dari kiri ke kanan:
 *
 * S Solomon : lingkaran rune ungu, tubuhnya terbentuk dari bawah ke atas, kitab terbuka, segel menyala.
 * H Hercules: melompat dari kejauhan seperti bintang jatuh, mendarat bertumpu kepalan (tanah retak, gelombang).
 * A Atlas   : tanah retak membara, bangkit dari dalam bumi sambil memanggul bola langit.
 * Z Zeus    : badai berkumpul, petir menyambar, Zeus berdiri di tempat petir jatuh (silau putih, listrik).
 * A Achilles: pusaran api emas, tubuhnya terbakar muncul dari kaki ke kepala, perisai dihentakkan.
 * M Mercury : melesat secepat kilat mengitari semua dewa, berhenti mendadak, berjinjit di satu kaki.
 *
 * Setelah semua hadir (tick 83 semuanya bersinar), pemain mengangkat kepalan: tiap dewa mengarahkan pusakanya
 * ke kepalan dan mengalirkan sinar energinya, memudar selama petir turun, lalu lenyap saat petir menyambar.
 *
 * Black Adam memanggil dewa-dewa Mesir (id GodFigures.EGYPT + 0..5) dengan jadwal & tempat yang sama:
 * S Shu    : pusaran angin & pasir berputar, tubuhnya terbentuk dari kaki ke kepala sambil berputar melambat.
 * H Heru   : menukik dari langit seperti elang dengan sayap terbentang, mendarat merunduk, sayap terlipat setengah.
 * A Amon   : "Yang Tersembunyi": bayangan pekat, lalu tubuhnya tersingkap dari mahkota ke kaki.
 * Z Zehuti : hieroglif menyala menuliskan tubuhnya dari bawah ke atas, cakram bulan menyala terakhir.
 * A Aton   : cakram matahari terbit dari balik tanah, menyilaukan, lalu sinar-sinarnya memanjang berujung tangan.
 * M Mehen  : tanah retak, ular raksasa menyeruak dari pasir, melingkar, lalu menegakkan leher dan tudungnya.
 *
 * 0.30 Sabbac memanggil enam iblis (id GodFigures.DEMONS + 0..5) dengan jadwal & tempat yang sama:
 * S Setan     : tanah retak membara, raja iblis menyeruak dari bawah tanah dengan kedua lengan terangkat.
 * A Aym       : pusaran api neraka, tubuh obsidiannya terbakar muncul dari kaki ke kepala, obornya diangkat.
 * B Belial    : tersingkap dari kegelapan, dari tanduk ke kaki, rantai membara menyeruak di sekelilingnya.
 * B Beelzebub : kawanan lalat berpusar makin rapat lalu memadat jadi tubuhnya (dari kaki ke kepala, berputar melambat).
 * A Asmodeus  : tanah meledak dalam semburan api, Asmodeus mendarat di tengahnya sambil meraung.
 * C Crateis   : menukik dari langit dengan sayap api terbentang, mendarat, sayapnya mengepak pelan.
 *
 * Ruang ritual: asal = posisi kaki pemain saat mulai, sumbu dunia (blok).
 */
public final class GodShow {
    private GodShow() {}

    // ======= Jadwal (tick sejak mulai memanggil; ubah di sini) =======
    /** Saat tiap dewa selesai muncul (S, H, A, Z, A, M). Jarak 13 tick = 0,65 detik. */
    public static final int[] ARRIVE = {14, 27, 40, 53, 66, 79};
    /** Berapa tick sebelum "selesai muncul" gerak masuknya dimulai (per id dewa, dua jajaran). */
    private static final int[] LEAD = {12, 9, 12, 4, 12, 8,
            12, 10, 12, 12, 12, 12,
            12, 12, 12, 12, 8, 10};
    /** Semua dewa bersinar bersamaan. */
    public static final int CHORUS = 83;
    /** Kepalan mulai diangkat (klip TRANSFORM). */
    public static final int CONVERGE = ShazamAnim.SUMMON_TICKS;
    /** Petir mengenai kepalan: semua dewa lenyap. */
    public static final int STRIKE = ShazamAnim.SUMMON_TICKS + ShazamAnim.TRANSFORM_STRIKE;
    /** Jarak dewa dari pemain (blok) dan sudut masing-masing di busur (derajat, negatif = kiri penonton). */
    public static final double RADIUS = 4.0;
    private static final double[] ANGLE = {-78, -50, -22, 22, 50, 78};

    public static int start(int god) {
        return ARRIVE[GodFigures.slot(god)] - LEAD[god];
    }

    /** Tick saat dewa ini selesai muncul. */
    public static int arrive(int god) {
        return ARRIVE[GodFigures.slot(god)];
    }

    /** Tempat berdiri keenam dewa. */
    public static final class Layout {
        public final double[] x = new double[GodFigures.COUNT], y = new double[GodFigures.COUNT], z = new double[GodFigures.COUNT];
        /** Arah dari kamera ke pemain (datar), kanan penonton, ukuran pemain. */
        public double dirX = 0, dirZ = 1, rightX = -1, rightZ = 0, size = 1;

        /** Susun busur di seberang kamera: (dx, dz) = arah pandang penonton ke pemain. */
        public void arrange(double dx, double dz, double casterScale) {
            double l = Math.sqrt(dx * dx + dz * dz);
            if (l < 1.0E-6) {
                dx = 0; dz = 1; l = 1;
            }
            dirX = dx / l;
            dirZ = dz / l;
            rightX = -dirZ;
            rightZ = dirX;
            size = casterScale;
            double[] p = new double[2];
            for (int i = 0; i < GodFigures.COUNT; i++) {
                arc(ANGLE[i], RADIUS * size, p);
                x[i] = p[0];
                z[i] = p[1];
                y[i] = 0;
            }
        }

        /** Titik di busur: sudut (derajat dari arah pandang, negatif = kiri) dan jari-jari. */
        public void arc(double deg, double radius, double[] out) {
            double a = Math.toRadians(deg);
            out[0] = (rightX * Math.sin(a) + dirX * Math.cos(a)) * radius;
            out[1] = (rightZ * Math.sin(a) + dirZ * Math.cos(a)) * radius;
        }
    }

    /** Keadaan satu dewa pada satu saat. */
    public static final class State {
        public boolean visible;
        /** Posisi kaki (ruang ritual), arah hadap (radian: +Z lokal ke arah ini), ukuran (blok per satuan dasar). */
        public double x, y, z, yaw, scale = 1;
        /** 0..1: sudah tampil (buat pernik cahaya). */
        public float appear;
        public float halo, mist, beam, trail;
        public final GodFigures.Pose pose = new GodFigures.Pose();
        public final GodLook.Mask mask = new GodLook.Mask();

        public State set(State o) {
            visible = o.visible;
            x = o.x; y = o.y; z = o.z; yaw = o.yaw; scale = o.scale;
            appear = o.appear; halo = o.halo; mist = o.mist; beam = o.beam; trail = o.trail;
            pose.set(o.pose);
            mask.set(o.mask);
            return this;
        }
    }

    /**
     * Isi keadaan dewa god pada waktu t (tick, boleh pecahan).
     * (fx, fy, fz) = kepalan pemain di ruang ritual (buat arah pusaka saat menyatu).
     */
    public static void state(int god, double t, Layout l, double fx, double fy, double fz, State s) {
        int slot = GodFigures.slot(god);
        double tau = t - start(god);
        double since = t - ARRIVE[slot];
        GodLook.Mask k = s.mask.reset();
        k.divine = god < GodFigures.EGYPT ? 1f : 0f;   // 0.23: urat energi & gelombang cahaya dewa Shazam
        GodFigures.Pose p = s.pose;
        s.visible = tau >= 0 && t < STRIKE + 0.5;
        s.scale = GodFigures.SCALE[god] * l.size;
        s.x = l.x[slot];
        s.y = l.y[slot];
        s.z = l.z[slot];
        double spin = 0.0;
        s.trail = 0f;
        s.beam = 0f;
        s.appear = 1f;
        s.halo = (float) smooth(since / 6.0);
        s.mist = (float) smooth((since + 5.0) / 6.0);
        p.time = (float) t;
        p.tau = (float) tau;
        p.converge = 0f;
        double faceX = -s.x, faceZ = -s.z;   // menghadap pemain

        switch (god) {
            case GodFigures.SOLOMON -> {
                if (tau < 13.5) {
                    k.scanY = (float) (-0.12 + 2.5 * smooth(tau / 12.0));
                    k.scanBand = 0.16f;
                    k.edge = 0xEADCFF;
                }
                s.appear = (float) smooth(tau / 12.0);
            }
            case GodFigures.HERCULES -> {
                if (tau < 9.0) {
                    double u = Math.max(0.0, tau) / 9.0, e = Math.pow(u, 1.25);
                    double ol = Math.sqrt(s.x * s.x + s.z * s.z);
                    double ox = s.x / ol, oz = s.z / ol;
                    double sx = s.x + ox * 11.0 * l.size, sy = s.y + 9.0 * l.size, sz = s.z + oz * 11.0 * l.size;
                    s.x = lerp(e, sx, s.x);
                    s.y = lerp(e, sy, s.y) + 3.2 * l.size * 4.0 * e * (1.0 - e);
                    s.z = lerp(e, sz, s.z);
                    s.trail = 1f;
                    k.alpha = (float) smooth(tau / 2.5);
                    k.boost = (float) (1.0 + 2.0 * (1.0 - smooth(tau / 4.0)));
                    s.appear = k.alpha;
                }
            }
            case GodFigures.ATLAS -> {
                double rise = outCubic((tau - 1.5) / 10.5);
                double depth = 2.75 * (1.0 - rise);
                s.y -= depth * s.scale;
                if (tau > 12.0) {
                    double u = tau - 12.0;
                    s.y += 0.05 * s.scale * Math.sin(u * 1.1) * Math.exp(-u * 0.6);
                }
                k.groundY = (float) ((l.y[god] - s.y) / s.scale);
                k.edge = 0xFFC890;
                s.appear = (float) rise;
            }
            case GodFigures.ZEUS -> {
                double u = tau - 4.0;
                s.visible &= u >= 0.0;
                k.flash = (float) (1.0 - smooth(u / 5.0));
                k.boost = (float) (1.0 + 1.6 * (1.0 - smooth(u / 7.0)));
                s.y += 0.5 * s.scale * (1.0 - smooth(u / 2.5));
                s.appear = (float) smooth(u / 1.5);
            }
            case GodFigures.ACHILLES -> {
                if (tau < 13.0) {
                    k.burn = (float) smooth(tau / 12.0);
                    k.edge = 0xFF9A48;
                }
                s.appear = (float) smooth(tau / 12.0);
            }
            case GodFigures.SHU -> {
                // pusaran: tubuh terbentuk dari kaki ke kepala (tepi putih kebiruan) sambil berputar makin pelan
                if (tau < 12.5) {
                    k.scanY = (float) (-0.1 + 2.45 * smooth(tau / 11.0));
                    k.scanBand = 0.18f;
                    k.edge = 0xE6F6FF;
                    spin = Math.PI * 5.0 * Math.pow(1.0 - smooth(tau / 12.0), 1.6);
                }
                s.appear = (float) smooth(tau / 11.0);
                s.y += 0.12 * s.scale * (1.0 - smooth(tau / 12.0));
            }
            case GodFigures.HERU -> {
                // menukik dari langit seperti elang, lalu mendarat merunduk
                if (tau < 10.0) {
                    double u = Math.max(0.0, tau) / 10.0, e = Math.pow(u, 1.7);
                    double ol = Math.sqrt(s.x * s.x + s.z * s.z);
                    double ox = s.x / ol, oz = s.z / ol;
                    double sx = s.x + ox * 7.0 * l.size - l.rightX * 4.0 * l.size, sy = s.y + 15.0 * l.size;
                    double sz = s.z + oz * 7.0 * l.size - l.rightZ * 4.0 * l.size;
                    double px = lerp(e, sx, s.x), py = lerp(e, sy, s.y), pz = lerp(e, sz, s.z);
                    faceX = s.x - sx;
                    faceZ = s.z - sz;
                    s.x = px;
                    s.y = py;
                    s.z = pz;
                    s.trail = 1f;
                    k.alpha = (float) smooth(tau / 2.0);
                    k.boost = (float) (1.0 + 2.2 * (1.0 - smooth(tau / 5.0)));
                    s.appear = k.alpha;
                } else {
                    double u = tau - 10.0;
                    s.y -= 0.04 * s.scale * Math.sin(u * 0.9) * Math.exp(-u * 0.5);
                }
            }
            case GodFigures.AMON -> {
                // Yang Tersembunyi: tersingkap dari mahkota ke kaki, keluar dari bayangan
                if (tau < 12.5) {
                    k.scanTop = (float) (2.75 - 2.95 * smooth(tau / 11.0));
                    k.scanBand = 0.2f;
                    k.edge = 0xA8C4FF;
                    k.alpha = (float) smooth(tau / 3.0);
                    k.boost = (float) (1.0 + 1.2 * (1.0 - smooth(tau / 11.0)));
                }
                s.appear = (float) smooth(tau / 11.0);
            }
            case GodFigures.ZEHUTI -> {
                // dituliskan hieroglif: terbentuk dari bawah ke atas, tepi hijau bulan
                if (tau < 12.5) {
                    k.scanY = (float) (-0.12 + 2.75 * smooth(tau / 12.0));
                    k.scanBand = 0.1f;
                    k.edge = 0xC0FFE8;
                }
                s.appear = (float) smooth(tau / 12.0);
            }
            case GodFigures.ATON -> {
                // matahari terbit dari balik tanah, menyilaukan saat terbit penuh, lalu melayang pelan
                double rise = outCubic(tau / 11.0);
                s.y -= 2.45 * s.scale * (1.0 - rise);
                k.groundY = (float) ((l.y[slot] - s.y) / s.scale);
                k.edge = 0xFFF0B0;
                k.flash = (float) (Math.exp(-Math.pow((tau - 10.0) / 2.2, 2)) * 0.85);
                k.boost = (float) (1.0 + 1.4 * (1.0 - smooth((tau - 6.0) / 10.0)));
                s.appear = (float) rise;
                faceX = -l.dirX;   // cakram selalu menghadap penonton
                faceZ = -l.dirZ;
            }
            case GodFigures.MEHEN -> {
                // menyeruak dari pasir: muncul dari bawah tanah (gulungan & leher), lalu menegakkan tudung
                double rise = outCubic((tau - 1.0) / 10.0);
                s.y -= 1.9 * s.scale * (1.0 - rise);
                if (tau > 11.0) {
                    double u = tau - 11.0;
                    s.y += 0.04 * s.scale * Math.sin(u * 1.2) * Math.exp(-u * 0.6);
                }
                k.groundY = (float) ((l.y[slot] - s.y) / s.scale);
                k.edge = 0xFFB070;
                s.appear = (float) rise;
            }
            case GodFigures.SATAN -> {
                // menyeruak dari tanah yang retak membara (lebih dalam & lebih lambat dari Atlas)
                double rise = outCubic((tau - 1.0) / 11.0);
                s.y -= 2.9 * s.scale * (1.0 - rise);
                if (tau > 12.0) {
                    double u = tau - 12.0;
                    s.y += 0.05 * s.scale * Math.sin(u * 1.0) * Math.exp(-u * 0.55);
                }
                k.groundY = (float) ((l.y[slot] - s.y) / s.scale);
                k.edge = 0xFF6A30;
                k.boost = (float) (1.0 + 1.0 * (1.0 - smooth((tau - 8.0) / 8.0)));
                s.appear = (float) rise;
            }
            case GodFigures.AYM -> {
                // terbakar muncul dari kaki ke kepala
                if (tau < 13.0) {
                    k.burn = (float) smooth(tau / 12.0);
                    k.edge = 0xFF8A3A;
                }
                s.appear = (float) smooth(tau / 12.0);
            }
            case GodFigures.BELIAL -> {
                // tersingkap dari kegelapan, dari tanduk ke kaki
                if (tau < 12.5) {
                    k.scanTop = (float) (2.9 - 3.1 * smooth(tau / 11.0));
                    k.scanBand = 0.22f;
                    k.edge = 0xFFB060;
                    k.alpha = (float) smooth(tau / 3.0);
                }
                s.appear = (float) smooth(tau / 11.0);
            }
            case GodFigures.BEELZEBUB -> {
                // kawanan lalat memadat: terbentuk dari kaki ke kepala sambil berputar makin pelan
                if (tau < 12.5) {
                    k.scanY = (float) (-0.1 + 2.4 * smooth(tau / 11.0));
                    k.scanBand = 0.2f;
                    k.edge = 0xE0FF80;
                    spin = Math.PI * 4.0 * Math.pow(1.0 - smooth(tau / 12.0), 1.5);
                }
                s.appear = (float) smooth(tau / 11.0);
            }
            case GodFigures.ASMODEUS -> {
                // muncul di tengah ledakan api (tick 4), mendarat berat
                double u = tau - 4.0;
                s.visible &= u >= 0.0;
                k.flash = (float) (0.8 * (1.0 - smooth(u / 5.0)));
                k.boost = (float) (1.0 + 1.6 * (1.0 - smooth(u / 7.0)));
                s.y += 0.7 * s.scale * (1.0 - smooth(u / 2.0));
                s.appear = (float) smooth(u / 1.5);
            }
            case GodFigures.CRATEIS -> {
                // menukik dari langit dengan sayap api terbentang
                if (tau < 10.0) {
                    double u = Math.max(0.0, tau) / 10.0, e = Math.pow(u, 1.6);
                    double ol = Math.sqrt(s.x * s.x + s.z * s.z);
                    double ox = s.x / ol, oz = s.z / ol;
                    double sx = s.x + ox * 6.0 * l.size + l.rightX * 4.0 * l.size, sy = s.y + 14.0 * l.size;
                    double sz = s.z + oz * 6.0 * l.size + l.rightZ * 4.0 * l.size;
                    double px = lerp(e, sx, s.x), py = lerp(e, sy, s.y), pz = lerp(e, sz, s.z);
                    faceX = s.x - sx;
                    faceZ = s.z - sz;
                    s.x = px;
                    s.y = py;
                    s.z = pz;
                    s.trail = 1f;
                    k.alpha = (float) smooth(tau / 2.0);
                    k.boost = (float) (1.0 + 2.0 * (1.0 - smooth(tau / 5.0)));
                    s.appear = k.alpha;
                } else {
                    double u = tau - 10.0;
                    s.y += 0.06 * s.scale * Math.sin(u * 0.8) * Math.exp(-u * 0.4);
                }
            }
            default -> {   // MERCURY
                if (tau < 8.0) {
                    double[] a = new double[2], b = new double[2];
                    mercuryPath(l, tau, a);
                    mercuryPath(l, tau + 0.1, b);
                    s.x = a[0];
                    s.z = a[1];
                    faceX = b[0] - a[0];
                    faceZ = b[1] - a[1];
                    s.trail = 1f;
                    k.alpha = (float) smooth(tau / 1.5);
                } else if (tau < 10.5) {
                    double[] a = new double[2], b = new double[2];
                    mercuryPath(l, 7.9, a);
                    mercuryPath(l, 8.0, b);
                    double w = smooth((tau - 8.0) / 2.5);
                    double rl = Math.sqrt((b[0] - a[0]) * (b[0] - a[0]) + (b[1] - a[1]) * (b[1] - a[1])) + 1.0E-9;
                    double cl = Math.sqrt(faceX * faceX + faceZ * faceZ) + 1.0E-9;
                    faceX = lerp(w, (b[0] - a[0]) / rl, faceX / cl);
                    faceZ = lerp(w, (b[1] - a[1]) / rl, faceZ / cl);
                }
                s.appear = (float) smooth(tau / 1.5);
            }
        }
        if (Math.abs(faceX) + Math.abs(faceZ) > 1.0E-9) {
            s.yaw = Math.atan2(faceX, faceZ) + spin;
        }

        // semua bersinar bersamaan
        double chorus = Math.exp(-Math.pow((t - CHORUS) / 2.5, 2));
        k.boost *= (float) (1.0 + 0.9 * chorus);
        // menyatu ke kepalan
        double c = smooth((t - (CONVERGE + 1.0 + slot * 0.9)) / 7.0);
        p.converge = (float) c;
        double vanish = clamp01((STRIKE - t) / 1.2);
        s.beam = (float) (smooth((t - (CONVERGE + 4.0 + slot)) / 3.0) * vanish);
        k.alpha *= (float) ((1.0 - 0.5 * smooth((t - (CONVERGE + 9.0)) / 9.0)) * vanish);
        k.boost *= (float) (1.0 + 0.6 * c);
        // kepalan di ruang dewa
        double[] a = new double[3];
        GodLook.toLocal(s, 0, 0, 0, fx, fy, fz, a);
        p.aimX = (float) a[0];
        p.aimY = (float) a[1];
        p.aimZ = (float) a[2];
    }

    /** Lintasan Mercury: dari luar layar kiri, melesat di belakang dewa-dewa lain, berhenti di tempatnya. */
    static void mercuryPath(Layout l, double tau, double[] out) {
        double u = clamp01(tau / 8.0);
        double e = 1.0 - Math.pow(1.0 - u, 2.2);
        double ang = lerp(e, -100.0, ANGLE[GodFigures.MERCURY]);
        double rad = lerp(smooth((e - 0.55) / 0.45), 6.8, RADIUS) * l.size;
        l.arc(ang, rad, out);
    }

    /** Titik-titik jejak (dada dewa) dari t - span sampai t; hasil = jumlah titik. */
    public static int trailPoints(int god, double t, Layout l, double span, int n, double[] out, State tmp) {
        int count = 0;
        for (int i = 0; i < n; i++) {
            double ti = t - span * (1.0 - i / (double) (n - 1));
            if (ti < start(god)) {
                continue;
            }
            state(god, ti, l, 0, 0, 0, tmp);
            out[count * 3] = tmp.x;
            out[count * 3 + 1] = tmp.y + 1.25 * tmp.scale;
            out[count * 3 + 2] = tmp.z;
            count++;
        }
        return count;
    }

    static double smooth(double v) {
        v = clamp01(v);
        return v * v * (3 - 2 * v);
    }

    static double clamp01(double v) {
        return v < 0 ? 0 : (v > 1 ? 1 : v);
    }

    static double outCubic(double v) {
        v = clamp01(v);
        double u = 1 - v;
        return 1 - u * u * u;
    }

    static double lerp(double t, double a, double b) {
        return a + (b - a) * t;
    }
}
