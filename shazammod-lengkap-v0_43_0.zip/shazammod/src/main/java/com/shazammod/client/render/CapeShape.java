package com.shazammod.client.render;

/**
 * Bentuk jubah panjang (murni Java): kain trapesium yang dipaku di bahu, di bawah mantel.
 * Ruang leher (sama dengan mantel: titik nol di poros leher, +Y atas, depan = -Z, ikut condong badan atas,
 * satuan blok sebelum dikali ukuran badan), jadi jubah tetap menempel di bahu saat jongkok atau membungkuk.
 * Grid: kolom kiri -> kanan (dilihat dari belakang: kolom 0 di sisi kiri badan), baris bahu -> ujung bawah.
 */
public final class CapeShape {
    private CapeShape() {}

    public static final int COLS = 9;
    public static final int ROWS = 15;

    // ======= Ukuran (blok) =======
    public static final double TOP_WIDTH = 0.62;
    public static final double BOTTOM_WIDTH = 0.92;
    public static final double LENGTH = 1.20;
    public static final double SHOULDER_Y = -0.007;   // tepat di bawah poros leher (1,40 blok dari kaki saat berdiri)
    public static final double BACK_Z = MantleShape.CAPE_TOP_Z;
    private static final double FLARE_Z = 0.05;   // ujung bawah sedikit menjauh dari kaki

    // ======= Bahan =======
    public static final double DENSITY = 0.7;      // kg/m²: wol tebal + lapisan dalam
    private static final double STRETCH = 0.0;     // nggak bisa molor
    private static final double SHEAR = 2.0E-4;
    private static final double BEND = 0.02;       // gampang dilipat seperti kain wol
    private static final double COMPRESS = 0.004;  // tertekan = melipat, bukan menahan

    /**
     * Bagian atas jubah ada di bawah mantel, jadi ditahan dekat punggung: jarak maksimum dari bentuk diam tiap
     * baris (blok) dan seberapa jauh boleh masuk ke arah punggung. Makin ke bawah makin bebas.
     */
    private static final double[] MAX_DIST = {0.0, 0.015, 0.03, 0.05, 0.08, 0.12, 0.2};
    private static final double[] BACKSTOP = {0.0, 0.015, 0.025, 0.035, 0.05, 0.07};
    /** Baris terakhir yang tertutup mantel (mantel selalu di luar baris 0 sampai ini). */
    public static final int UNDER_MANTLE_ROWS = 5;

    public static final double[] REST_X = new double[COLS * ROWS];
    public static final double[] REST_Y = new double[COLS * ROWS];
    public static final double[] REST_Z = new double[COLS * ROWS];

    static {
        for (int r = 0; r < ROWS; r++) {
            double v = r / (ROWS - 1.0);
            double width = TOP_WIDTH + (BOTTOM_WIDTH - TOP_WIDTH) * v;
            for (int c = 0; c < COLS; c++) {
                int i = r * COLS + c;
                REST_X[i] = (c / (COLS - 1.0) - 0.5) * width;
                REST_Y[i] = SHOULDER_Y - v * LENGTH;
                REST_Z[i] = BACK_Z + v * FLARE_Z;
            }
        }
    }

    public static ClothSim create() {
        ClothSim sim = new ClothSim(COLS, ROWS, REST_X, REST_Y, REST_Z, DENSITY);
        for (int c = 0; c < COLS; c++) {
            sim.pin(c);
        }
        sim.addGridLinks(STRETCH, SHEAR, BEND);
        sim.compressCompliance = COMPRESS;
        sim.buildTethers(3, 1.0);
        for (int i = COLS; i < sim.count; i++) {
            int r = i / COLS;
            sim.maxDist[i] = r < MAX_DIST.length ? MAX_DIST[r] : -1.0;
            sim.backstop[i] = r < BACKSTOP.length ? BACKSTOP[r] : -1.0;
            // normal luar jubah = ke belakang (+Z)
            sim.outX[i] = 0.0; sim.outY[i] = 0.0; sim.outZ[i] = 1.0;
        }
        return sim;
    }

    /**
     * Posisi awal: menggantung diam, atau (saat berubah jadi Shazam) bagian bawahnya terbentang ke belakang
     * lalu jatuh. Bagian atas tetap di bentuknya (di bawah mantel).
     */
    public static void place(ClothSim sim, boolean unfurl) {
        double[] lx = new double[sim.count], ly = new double[sim.count], lz = new double[sim.count];
        int hinge = MAX_DIST.length - 1;
        double hingeY = REST_Y[hinge * COLS], hingeZ = REST_Z[hinge * COLS];
        double a = Math.toRadians(72.0);
        for (int i = 0; i < sim.count; i++) {
            int r = i / COLS;
            lx[i] = REST_X[i];
            if (unfurl && r > hinge) {
                double along = (r - hinge) / (ROWS - 1.0) * LENGTH;
                ly[i] = hingeY - along * Math.cos(a);
                lz[i] = hingeZ + along * Math.sin(a);
            } else {
                ly[i] = REST_Y[i];
                lz[i] = REST_Z[i];
            }
        }
        sim.reset(lx, ly, lz);
    }
}
