package com.shazammod.client.fx;

import net.neoforged.neoforge.client.event.ComputeFovModifierEvent;

/** Pandangan melebar sesaat saat Kilat Mercury, biar terasa ngebut. */
public final class FovKick {
    private FovKick() {}

    private static float kick;
    private static float punch;

    public static void kick(float amount) {
        kick = Math.max(kick, amount);
    }

    /** Sentakan sesaat (negatif = pandangan menyempit/zoom, misalnya saat tepukan menghantam). */
    public static void punch(float amount) {
        punch = Math.abs(amount) > Math.abs(punch) ? amount : punch;
    }

    public static void clear() {
        kick = 0f;
        punch = 0f;
    }

    public static void tick() {
        kick = Math.max(0f, kick - 0.03f);
        punch *= 0.6f;
        if (Math.abs(punch) < 0.002f) {
            punch = 0f;
        }
    }

    public static void apply(ComputeFovModifierEvent event) {
        if (kick > 0f || punch != 0f) {
            event.setNewFovModifier(event.getNewFovModifier() * (1f + kick + punch));
        }
    }
}
