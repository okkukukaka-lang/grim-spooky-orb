package com.shazammod.client.fx;

/**
 * Mesh roh dewa (murni Java, tanpa Minecraft, jadi bisa diuji dan digambar di luar game).
 * Isinya titik-titik (posisi, normal, warna, kepekatan, cahaya sendiri) dan segi empat, dibangun dari
 * bentuk dasar yang halus: elipsoid, tabung, tumpukan cincin (badan, jubah, janggut), pita (jubah luar),
 * kotak, kerucut, dan kipas bulu.
 *
 * Ruang dewa: satuan blok pada ukuran dasar (tinggi badan kira-kira 1,9), asal di tanah di antara kaki,
 * +Y ke atas, +Z ke depan (arah hadap), +X ke kiri si dewa. Semua sisi depan berlawanan arah jarum jam
 * (CCW) dilihat dari luar, sama seperti model Minecraft, jadi sisi belakang boleh dibuang (cull).
 */
public final class GodMesh {
    // ------------------------------------------------------------------ titik penting
    public static final int FOCUS = 0;    // pusaka: sumber sinar ke kepalan
    public static final int HEAD = 1;     // pusat kepala
    public static final int EYE_L = 2;
    public static final int EYE_R = 3;
    public static final int HAND_L = 4;
    public static final int HAND_R = 5;
    public static final int CHEST = 6;
    public static final int EXTRA = 7;    // titik khusus tiap dewa (segel Solomon, perisai Achilles, ...)
    public static final int EXTRA2 = 8;
    public static final int ANCHORS = 9;

    public float[] x = new float[1024], y = new float[1024], z = new float[1024];
    public float[] nx = new float[1024], ny = new float[1024], nz = new float[1024];
    public float[] opacity = new float[1024], glow = new float[1024];
    public int[] rgb = new int[1024];
    public int verts;
    public int[] quads = new int[4096];
    public int quadCount;
    /** Titik penting (x, y, z) dan arah (x, y, z) masing-masing. */
    public final float[] anchor = new float[ANCHORS * 3];
    public final float[] anchorDir = new float[ANCHORS * 3];
    /** Ukuran tambahan per dewa (misalnya jari-jari bola langit Atlas). */
    public float extraSize;

    private int curRgb = 0xFFFFFF;
    private float curOpacity = 1f;
    private float curGlow;

    // kisi sementara
    private double[] gx = new double[512], gy = new double[512], gz = new double[512];
    private double[] gnx = new double[512], gny = new double[512], gnz = new double[512];
    private boolean[] bad = new boolean[512];

    public void clear() {
        verts = 0;
        quadCount = 0;
        for (int i = 0; i < anchor.length; i++) {
            anchor[i] = 0f;
            anchorDir[i] = 0f;
        }
        extraSize = 0f;
    }

    /** Bahan untuk bentuk berikutnya: warna, kepekatan (0-1), cahaya sendiri (0-1). */
    public GodMesh mat(int color, float opacityValue, float glowValue) {
        curRgb = color;
        curOpacity = opacityValue;
        curGlow = glowValue;
        return this;
    }

    public void anchor(int k, double ax, double ay, double az) {
        anchor[k * 3] = (float) ax;
        anchor[k * 3 + 1] = (float) ay;
        anchor[k * 3 + 2] = (float) az;
    }

    public void anchorDir(int k, double dx, double dy, double dz) {
        double l = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (l < 1.0E-9) {
            return;
        }
        anchorDir[k * 3] = (float) (dx / l);
        anchorDir[k * 3 + 1] = (float) (dy / l);
        anchorDir[k * 3 + 2] = (float) (dz / l);
    }

    // ------------------------------------------------------------------ titik & segi empat

    private void growVerts(int need) {
        if (need <= x.length) {
            return;
        }
        int n = Math.max(need, x.length * 2);
        x = java.util.Arrays.copyOf(x, n);
        y = java.util.Arrays.copyOf(y, n);
        z = java.util.Arrays.copyOf(z, n);
        nx = java.util.Arrays.copyOf(nx, n);
        ny = java.util.Arrays.copyOf(ny, n);
        nz = java.util.Arrays.copyOf(nz, n);
        opacity = java.util.Arrays.copyOf(opacity, n);
        glow = java.util.Arrays.copyOf(glow, n);
        rgb = java.util.Arrays.copyOf(rgb, n);
    }

    int vertex(double px, double py, double pz, double qx, double qy, double qz) {
        growVerts(verts + 1);
        int i = verts++;
        x[i] = (float) px;
        y[i] = (float) py;
        z[i] = (float) pz;
        double l = Math.sqrt(qx * qx + qy * qy + qz * qz);
        if (l < 1.0E-12) {
            qx = 0; qy = 1; qz = 0; l = 1;
        }
        nx[i] = (float) (qx / l);
        ny[i] = (float) (qy / l);
        nz[i] = (float) (qz / l);
        rgb[i] = curRgb;
        opacity[i] = curOpacity;
        glow[i] = curGlow;
        return i;
    }

    void quad(int a, int b, int c, int d) {
        if (quadCount * 4 + 4 > quads.length) {
            quads = java.util.Arrays.copyOf(quads, quads.length * 2);
        }
        int o = quadCount * 4;
        quads[o] = a;
        quads[o + 1] = b;
        quads[o + 2] = c;
        quads[o + 3] = d;
        quadCount++;
    }

    private void growGrid(int n) {
        if (n <= gx.length) {
            return;
        }
        int m = Math.max(n, gx.length * 2);
        gx = new double[m]; gy = new double[m]; gz = new double[m];
        gnx = new double[m]; gny = new double[m]; gnz = new double[m];
        bad = new boolean[m];
    }

    private void put(int i, double px, double py, double pz) {
        gx[i] = px;
        gy[i] = py;
        gz[i] = pz;
    }

    /**
     * Permukaan dari kisi rows x cols di gx/gy/gz (baris = sepanjang sumbu bentuk, kolom = mengelilingi).
     * Normal = (arah kolom) x (arah baris): keluar untuk semua bentuk di sini (baris dari atas ke bawah atau
     * dari pangkal ke ujung, kolom memakai basis (cos, sin) yang tangan kanan).
     */
    private void grid(int rows, int cols, boolean wrapRows, boolean wrapCols, boolean twoSided) {
        int n = rows * cols;
        for (int r = 0; r < rows; r++) {
            int rp = r + 1 < rows ? r + 1 : (wrapRows ? 0 : r);
            int rm = r > 0 ? r - 1 : (wrapRows ? rows - 1 : r);
            for (int c = 0; c < cols; c++) {
                int cp = c + 1 < cols ? c + 1 : (wrapCols ? 0 : c);
                int cm = c > 0 ? c - 1 : (wrapCols ? cols - 1 : c);
                int i = r * cols + c;
                double ux = gx[rp * cols + c] - gx[rm * cols + c];
                double uy = gy[rp * cols + c] - gy[rm * cols + c];
                double uz = gz[rp * cols + c] - gz[rm * cols + c];
                double vx = gx[r * cols + cp] - gx[r * cols + cm];
                double vy = gy[r * cols + cp] - gy[r * cols + cm];
                double vz = gz[r * cols + cp] - gz[r * cols + cm];
                double qx = vy * uz - vz * uy, qy = vz * ux - vx * uz, qz = vx * uy - vy * ux;
                double l = qx * qx + qy * qy + qz * qz;
                bad[i] = l < 1.0E-16;
                gnx[i] = qx;
                gny[i] = qy;
                gnz[i] = qz;
            }
        }
        // baris yang menyempit jadi satu titik (kutub, ujung tabung): pakai rata-rata normal baris tetangga
        for (int r = 0; r < rows; r++) {
            boolean any = false;
            for (int c = 0; c < cols; c++) {
                any |= bad[r * cols + c];
            }
            if (!any) {
                continue;
            }
            int adj = r + 1 < rows ? r + 1 : r - 1;
            if (r > 0 && r + 1 < rows) {
                adj = r < rows / 2 ? r + 1 : r - 1;
            }
            double sx = 0, sy = 0, sz = 0;
            if (adj >= 0) {
                for (int c = 0; c < cols; c++) {
                    int j = adj * cols + c;
                    double l = Math.sqrt(gnx[j] * gnx[j] + gny[j] * gny[j] + gnz[j] * gnz[j]);
                    if (l > 1.0E-12) {
                        sx += gnx[j] / l;
                        sy += gny[j] / l;
                        sz += gnz[j] / l;
                    }
                }
            }
            for (int c = 0; c < cols; c++) {
                int i = r * cols + c;
                if (bad[i]) {
                    gnx[i] = sx;
                    gny[i] = sy;
                    gnz[i] = sz;
                }
            }
        }
        int base = verts;
        growVerts(verts + n * (twoSided ? 2 : 1));
        for (int i = 0; i < n; i++) {
            vertex(gx[i], gy[i], gz[i], gnx[i], gny[i], gnz[i]);
        }
        int rEnd = wrapRows ? rows : rows - 1;
        int cEnd = wrapCols ? cols : cols - 1;
        for (int r = 0; r < rEnd; r++) {
            int r1 = (r + 1) % rows;
            for (int c = 0; c < cEnd; c++) {
                int c1 = (c + 1) % cols;
                quad(base + r * cols + c, base + r * cols + c1, base + r1 * cols + c1, base + r1 * cols + c);
            }
        }
        if (twoSided) {
            int back = verts;
            for (int i = 0; i < n; i++) {
                vertex(gx[i], gy[i], gz[i], -gnx[i], -gny[i], -gnz[i]);
            }
            for (int r = 0; r < rEnd; r++) {
                int r1 = (r + 1) % rows;
                for (int c = 0; c < cEnd; c++) {
                    int c1 = (c + 1) % cols;
                    quad(back + r * cols + c, back + r1 * cols + c, back + r1 * cols + c1, back + r * cols + c1);
                }
            }
        }
    }

    // ------------------------------------------------------------------ bentuk dasar

    /** Elipsoid utuh di frame f (pusat & jari-jari di koordinat frame). */
    public void ellipsoid(Frame f, double cx, double cy, double cz, double rx, double ry, double rz, int lon, int lat) {
        ellipsoid(f, cx, cy, cz, rx, ry, rz, lon, lat, 0.0, Math.PI, 0.0);
    }

    /**
     * Elipsoid sebagian: lintang dari latFrom (0 = puncak +Y) sampai latTo (PI = dasar).
     * backExtra: tepi bawah turun sekian radian lebih jauh di belakang (-Z) daripada di depan (helm, rambut).
     */
    public void ellipsoid(Frame f, double cx, double cy, double cz, double rx, double ry, double rz, int lon, int lat,
                          double latFrom, double latTo, double backExtra) {
        int rows = lat + 1, cols = lon;
        growGrid(rows * cols);
        for (int r = 0; r < rows; r++) {
            double u = r / (double) lat;
            for (int c = 0; c < cols; c++) {
                double ph = Math.PI * 2.0 * c / cols;
                double cp = Math.cos(ph), sp = Math.sin(ph);
                double to = latTo + backExtra * (0.5 - 0.5 * sp);
                double th = latFrom + (Math.min(Math.PI, to) - latFrom) * u;
                double st = Math.sin(th), ct = Math.cos(th);
                double lx = cx + rx * st * cp, ly = cy + ry * ct, lz = cz + rz * st * sp;
                put(r * cols + c, f.px(lx, ly, lz), f.py(lx, ly, lz), f.pz(lx, ly, lz));
            }
        }
        grid(rows, cols, false, true, false);
    }

    /** Jari-jari tambahan per cincin & sudut (lipatan kain, gerigi mahkota). null = bulat polos. */
    public interface Fold {
        double at(int ring, double angle);
    }

    /**
     * Tumpukan cincin elips dengan sumbu Y frame f sebagai poros (badan, jubah, janggut, rambut).
     * Cincin k: pusat (cx[k], ys[k], cz[k]), jari-jari rx[k] (arah X) dan rz[k] (arah Z), urut dari atas ke bawah.
     * Sudut 0 = +X, PI/2 = +Z (depan). from/to = rentang sudut (to - from = 2PI: tertutup).
     */
    public void lathe(Frame f, double[] cx, double[] ys, double[] cz, double[] rx, double[] rz, int rings, int sides,
                      double from, double to, Fold fold, boolean twoSided) {
        boolean full = Math.abs(to - from - Math.PI * 2.0) < 1.0E-6;
        int cols = full ? sides : sides + 1;
        growGrid(rings * cols);
        for (int r = 0; r < rings; r++) {
            for (int c = 0; c < cols; c++) {
                double ph = from + (to - from) * c / sides;
                double m = fold == null ? 1.0 : fold.at(r, ph);
                double lx = (cx == null ? 0.0 : cx[r]) + rx[r] * m * Math.cos(ph);
                double lz = (cz == null ? 0.0 : cz[r]) + rz[r] * m * Math.sin(ph);
                double ly = ys[r];
                put(r * cols + c, f.px(lx, ly, lz), f.py(lx, ly, lz), f.pz(lx, ly, lz));
            }
        }
        grid(rings, cols, false, full, twoSided);
    }

    /**
     * Tumpukan cincin dengan frame sendiri tiap cincin (badan yang membungkuk mengikuti tulang belakang).
     * Cincin k: pusat (px,py,pz)[k], sumbu silang X = ax[k], Z = az[k] (satuan), jari-jari rx/rz. Urut atas ke bawah.
     */
    public void rings(double[] px, double[] py, double[] pz, double[] ax, double[] az, double[] rx, double[] rz,
                      int rings, int sides, Fold fold) {
        int cols = sides;
        growGrid(rings * cols);
        for (int r = 0; r < rings; r++) {
            for (int c = 0; c < cols; c++) {
                double ph = Math.PI * 2.0 * c / sides;
                double m = fold == null ? 1.0 : fold.at(r, ph);
                double a = rx[r] * m * Math.cos(ph), b = rz[r] * m * Math.sin(ph);
                put(r * cols + c, px[r] + ax[r * 3] * a + az[r * 3] * b, py[r] + ax[r * 3 + 1] * a + az[r * 3 + 1] * b,
                        pz[r] + ax[r * 3 + 2] * a + az[r * 3 + 2] * b);
            }
        }
        grid(rings, cols, false, true, false);
    }

    /**
     * Tabung sepanjang garis titik (ruang dewa) dengan jari-jari per titik. Jari-jari 0 di ujung = runcing.
     * caps = ujung yang jari-jarinya > 0 ditutup membulat. ref = arah acuan penampang (boleh asal, asal nggak
     * sejajar tabung). flat = penampang pipih (1 = bulat).
     */
    public void tube(double[] pts, double[] rad, int n, int sides, boolean caps, double refX, double refY, double refZ,
                     double flat) {
        tube(pts, rad, n, sides, caps, refX, refY, refZ, flat, false);
    }

    /** loop = garis tertutup (cincin, ikat pinggang, lingkar bola langit). */
    public void tube(double[] pts, double[] rad, int n, int sides, boolean caps, double refX, double refY, double refZ,
                     double flat, boolean loop) {
        if (n < 2) {
            return;
        }
        boolean capA = caps && !loop && rad[0] > 1.0E-6;
        boolean capB = caps && !loop && rad[n - 1] > 1.0E-6;
        int rows = n + (capA ? 2 : 0) + (capB ? 2 : 0);
        growGrid(rows * sides);
        int row = 0;
        double lnx = Double.NaN, lny = 0, lnz = 0;
        double[] tn = new double[3], nn = new double[3];
        for (int k = -(capA ? 2 : 0); k < n + (capB ? 2 : 0); k++) {
            int i = Math.max(0, Math.min(n - 1, k));
            // garis singgung
            int a = loop ? (i - 1 + n) % n : Math.max(0, i - 1);
            int b = loop ? (i + 1) % n : Math.min(n - 1, i + 1);
            tn[0] = pts[b * 3] - pts[a * 3];
            tn[1] = pts[b * 3 + 1] - pts[a * 3 + 1];
            tn[2] = pts[b * 3 + 2] - pts[a * 3 + 2];
            double tl = Math.sqrt(tn[0] * tn[0] + tn[1] * tn[1] + tn[2] * tn[2]);
            if (tl < 1.0E-12) {
                tn[0] = 0; tn[1] = 1; tn[2] = 0; tl = 1;
            }
            tn[0] /= tl; tn[1] /= tl; tn[2] /= tl;
            // penampang: acuan diproyeksikan tegak lurus garis singgung
            double d = refX * tn[0] + refY * tn[1] + refZ * tn[2];
            nn[0] = refX - tn[0] * d;
            nn[1] = refY - tn[1] * d;
            nn[2] = refZ - tn[2] * d;
            double nl = Math.sqrt(nn[0] * nn[0] + nn[1] * nn[1] + nn[2] * nn[2]);
            if (nl < 1.0E-4) {
                if (!Double.isNaN(lnx)) {
                    d = lnx * tn[0] + lny * tn[1] + lnz * tn[2];
                    nn[0] = lnx - tn[0] * d; nn[1] = lny - tn[1] * d; nn[2] = lnz - tn[2] * d;
                } else {
                    double ox = Math.abs(tn[0]) < 0.9 ? 1 : 0, oy = Math.abs(tn[0]) < 0.9 ? 0 : 1;
                    d = ox * tn[0] + oy * tn[1];
                    nn[0] = ox - tn[0] * d; nn[1] = oy - tn[1] * d; nn[2] = -tn[2] * d;
                }
                nl = Math.sqrt(nn[0] * nn[0] + nn[1] * nn[1] + nn[2] * nn[2]);
            }
            nn[0] /= nl; nn[1] /= nl; nn[2] /= nl;
            lnx = nn[0]; lny = nn[1]; lnz = nn[2];
            // binormal = T x N
            double bx = tn[1] * nn[2] - tn[2] * nn[1], by = tn[2] * nn[0] - tn[0] * nn[2], bz = tn[0] * nn[1] - tn[1] * nn[0];
            double cx = pts[i * 3], cy = pts[i * 3 + 1], cz = pts[i * 3 + 2];
            double r = rad[i];
            if (k < 0) {   // tutup pangkal: dua cincin membulat ke belakang
                double back = k == -2 ? 0.8 : 0.55;
                cx -= tn[0] * r * back; cy -= tn[1] * r * back; cz -= tn[2] * r * back;
                r = k == -2 ? 0.0 : r * 0.78;
            } else if (k >= n) {
                double fwd = k == n + 1 ? 0.8 : 0.55;
                cx += tn[0] * r * fwd; cy += tn[1] * r * fwd; cz += tn[2] * r * fwd;
                r = k == n + 1 ? 0.0 : r * 0.78;
            }
            for (int c = 0; c < sides; c++) {
                double ph = Math.PI * 2.0 * c / sides;
                double cp = Math.cos(ph) * r, sp = Math.sin(ph) * r * flat;
                put(row * sides + c, cx + nn[0] * cp + bx * sp, cy + nn[1] * cp + by * sp, cz + nn[2] * cp + bz * sp);
            }
            row++;
        }
        grid(rows, sides, loop, true, false);
    }

    /**
     * Pita dua sisi sepanjang garis titik (jubah, selempang, jambul helm). w = arah lebar (satuan) per titik,
     * width = lebar per titik, curl = lengkung melintang (positif = tepi melengkung ke arah normal pita).
     */
    public void ribbon(double[] pts, double[] w, double[] width, int n, int across, double curl) {
        if (n < 2 || across < 2) {
            return;
        }
        growGrid(n * across);
        for (int i = 0; i < n; i++) {
            int a = Math.max(0, i - 1), b = Math.min(n - 1, i + 1);
            double tx = pts[b * 3] - pts[a * 3], ty = pts[b * 3 + 1] - pts[a * 3 + 1], tz = pts[b * 3 + 2] - pts[a * 3 + 2];
            double wx = w[i * 3], wy = w[i * 3 + 1], wz = w[i * 3 + 2];
            // normal pita = lebar x garis singgung
            double qx = wy * tz - wz * ty, qy = wz * tx - wx * tz, qz = wx * ty - wy * tx;
            double ql = Math.sqrt(qx * qx + qy * qy + qz * qz);
            if (ql > 1.0E-12) {
                qx /= ql; qy /= ql; qz /= ql;
            }
            for (int c = 0; c < across; c++) {
                double s = -1.0 + 2.0 * c / (across - 1);
                double half = width[i] * 0.5;
                double bend = curl * half * s * s;
                put(i * across + c, pts[i * 3] + wx * s * half + qx * bend, pts[i * 3 + 1] + wy * s * half + qy * bend,
                        pts[i * 3 + 2] + wz * s * half + qz * bend);
            }
        }
        grid(n, across, false, false, true);
    }

    /** Kotak di frame f: pusat (cx,cy,cz), setengah ukuran (hx,hy,hz). Sisi datar. */
    public void box(Frame f, double cx, double cy, double cz, double hx, double hy, double hz) {
        for (int axis = 0; axis < 3; axis++) {
            for (int sgn = -1; sgn <= 1; sgn += 2) {
                // normal sisi di koordinat frame
                double qx = axis == 0 ? sgn : 0, qy = axis == 1 ? sgn : 0, qz = axis == 2 ? sgn : 0;
                // dua arah di bidang sisi (u x v = normal)
                double ux, uy, uz, vx, vy, vz;
                if (axis == 0) { ux = 0; uy = 1; uz = 0; vx = 0; vy = 0; vz = 1; }
                else if (axis == 1) { ux = 0; uy = 0; uz = 1; vx = 1; vy = 0; vz = 0; }
                else { ux = 1; uy = 0; uz = 0; vx = 0; vy = 1; vz = 0; }
                if (sgn < 0) {   // balik supaya tetap u x v = normal
                    double tx = ux, ty = uy, tz = uz;
                    ux = vx; uy = vy; uz = vz;
                    vx = tx; vy = ty; vz = tz;
                }
                double ox = cx + qx * hx, oy = cy + qy * hy, oz = cz + qz * hz;
                double ex = ux * hx, ey = uy * hy, ez = uz * hz;
                double fx = vx * hx, fy = vy * hy, fz = vz * hz;
                double wnx = f.dx(qx, qy, qz), wny = f.dy(qx, qy, qz), wnz = f.dz(qx, qy, qz);
                int a = cornerVertex(f, ox - ex - fx, oy - ey - fy, oz - ez - fz, wnx, wny, wnz);
                int b = cornerVertex(f, ox + ex - fx, oy + ey - fy, oz + ez - fz, wnx, wny, wnz);
                int c = cornerVertex(f, ox + ex + fx, oy + ey + fy, oz + ez + fz, wnx, wny, wnz);
                int d = cornerVertex(f, ox - ex + fx, oy - ey + fy, oz - ez + fz, wnx, wny, wnz);
                quad(a, b, c, d);
            }
        }
    }

    private int cornerVertex(Frame f, double lx, double ly, double lz, double qx, double qy, double qz) {
        return vertex(f.px(lx, ly, lz), f.py(lx, ly, lz), f.pz(lx, ly, lz), qx, qy, qz);
    }

    /** Kerucut/taring dari pangkal a (jari-jari r) ke ujung runcing b. */
    public void spike(double ax, double ay, double az, double bx, double by, double bz, double r, int sides) {
        double[] p = {ax, ay, az, (ax + bx) * 0.5, (ay + by) * 0.5, (az + bz) * 0.5, bx, by, bz};
        double[] rad = {r, r * 0.55, 0.0};
        double dx = bx - ax, dy = by - ay, dz = bz - az;
        boolean vertical = Math.abs(dy) > 0.8 * Math.sqrt(dx * dx + dy * dy + dz * dz);
        tube(p, rad, 3, sides, true, vertical ? 1 : 0, vertical ? 0 : 1, 0, 1.0);
    }

    /**
     * Kipas bulu (sayap kecil): count bulu dari titik pangkal f.origin, arah utama = sumbu Y frame, menyebar di
     * bidang XY frame sebesar spread (radian, total), panjang len (bulu tengah) mengecil ke tepi.
     */
    public void featherFan(Frame f, int count, double spread, double len, double width, double thick) {
        Frame q = new Frame();
        for (int k = 0; k < count; k++) {
            double u = count == 1 ? 0.0 : k / (double) (count - 1) - 0.5;
            double ang = u * spread;
            double l = len * (1.0 - 0.45 * Math.abs(u) * 2.0 * Math.abs(u));
            q.set(f).rotZ(Math.toDegrees(ang));
            ellipsoid(q, 0, l * 0.5, 0, width * (1.0 - 0.3 * Math.abs(u)), l * 0.5, thick, 5, 3);
        }
    }

    // ------------------------------------------------------------------ frame

    /** Frame kecil: titik asal + tiga sumbu satuan (ruang dewa). Putaran memakai sumbu frame sendiri. */
    public static final class Frame {
        public double ox, oy, oz;
        public double xx = 1, xy, xz, yx, yy = 1, yz, zx, zy, zz = 1;

        public Frame set(Frame o) {
            ox = o.ox; oy = o.oy; oz = o.oz;
            xx = o.xx; xy = o.xy; xz = o.xz;
            yx = o.yx; yy = o.yy; yz = o.yz;
            zx = o.zx; zy = o.zy; zz = o.zz;
            return this;
        }

        public Frame identity() {
            ox = oy = oz = 0;
            xx = 1; xy = 0; xz = 0;
            yx = 0; yy = 1; yz = 0;
            zx = 0; zy = 0; zz = 1;
            return this;
        }

        public Frame at(double x, double y, double z) {
            ox = x; oy = y; oz = z;
            return this;
        }

        /** Geser sepanjang sumbu frame sendiri. */
        public Frame move(double lx, double ly, double lz) {
            double px = px(lx, ly, lz), py = py(lx, ly, lz), pz = pz(lx, ly, lz);
            ox = px; oy = py; oz = pz;
            return this;
        }

        /** Putar di sumbu X frame (derajat, positif: +Y condong ke +Z). */
        public Frame rotX(double deg) {
            double a = Math.toRadians(deg), c = Math.cos(a), s = Math.sin(a);
            double nyx = yx * c + zx * s, nyy = yy * c + zy * s, nyz = yz * c + zz * s;
            double nzx = -yx * s + zx * c, nzy = -yy * s + zy * c, nzz = -yz * s + zz * c;
            yx = nyx; yy = nyy; yz = nyz;
            zx = nzx; zy = nzy; zz = nzz;
            return this;
        }

        /** Putar di sumbu Y frame (derajat, positif: +Z berputar ke +X). */
        public Frame rotY(double deg) {
            double a = Math.toRadians(deg), c = Math.cos(a), s = Math.sin(a);
            double nzx = zx * c + xx * s, nzy = zy * c + xy * s, nzz = zz * c + xz * s;
            double nxx = xx * c - zx * s, nxy = xy * c - zy * s, nxz = xz * c - zz * s;
            zx = nzx; zy = nzy; zz = nzz;
            xx = nxx; xy = nxy; xz = nxz;
            return this;
        }

        /** Putar di sumbu Z frame (derajat, positif: +X berputar ke +Y). */
        public Frame rotZ(double deg) {
            double a = Math.toRadians(deg), c = Math.cos(a), s = Math.sin(a);
            double nxx = xx * c + yx * s, nxy = xy * c + yy * s, nxz = xz * c + yz * s;
            double nyx = -xx * s + yx * c, nyy = -xy * s + yy * c, nyz = -xz * s + yz * c;
            xx = nxx; xy = nxy; xz = nxz;
            yx = nyx; yy = nyy; yz = nyz;
            return this;
        }

        /** Sumbu Y = arah d, sumbu Z sedekat mungkin ke arah h (keduanya ruang dewa). */
        public Frame aim(double dx, double dy, double dz, double hx, double hy, double hz) {
            double l = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (l < 1.0E-12) {
                return this;
            }
            yx = dx / l; yy = dy / l; yz = dz / l;
            double d = hx * yx + hy * yy + hz * yz;
            double qx = hx - yx * d, qy = hy - yy * d, qz = hz - yz * d;
            double ql = Math.sqrt(qx * qx + qy * qy + qz * qz);
            if (ql < 1.0E-6) {   // petunjuk sejajar: pakai sumbu lain
                double ax = Math.abs(yx) < 0.9 ? 1 : 0, ay = Math.abs(yx) < 0.9 ? 0 : 1;
                d = ax * yx + ay * yy;
                qx = ax - yx * d; qy = ay - yy * d; qz = -yz * d;
                ql = Math.sqrt(qx * qx + qy * qy + qz * qz);
            }
            zx = qx / ql; zy = qy / ql; zz = qz / ql;
            // X = Y x Z
            xx = yy * zz - yz * zy;
            xy = yz * zx - yx * zz;
            xz = yx * zy - yy * zx;
            return this;
        }

        public double px(double lx, double ly, double lz) {
            return ox + xx * lx + yx * ly + zx * lz;
        }

        public double py(double lx, double ly, double lz) {
            return oy + xy * lx + yy * ly + zy * lz;
        }

        public double pz(double lx, double ly, double lz) {
            return oz + xz * lx + yz * ly + zz * lz;
        }

        public double dx(double lx, double ly, double lz) {
            return xx * lx + yx * ly + zx * lz;
        }

        public double dy(double lx, double ly, double lz) {
            return xy * lx + yy * ly + zy * lz;
        }

        public double dz(double lx, double ly, double lz) {
            return xz * lx + yz * ly + zz * lz;
        }

        /** Titik lokal ke ruang dewa, ditulis ke out[o..o+2]. */
        public void point(double lx, double ly, double lz, double[] out, int o) {
            out[o] = px(lx, ly, lz);
            out[o + 1] = py(lx, ly, lz);
            out[o + 2] = pz(lx, ly, lz);
        }
    }
}
