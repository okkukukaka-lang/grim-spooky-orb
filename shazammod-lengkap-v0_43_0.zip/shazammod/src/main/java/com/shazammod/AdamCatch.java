package com.shazammod;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.AbstractHurtingProjectile;
import net.minecraft.world.entity.projectile.FireworkRocketEntity;
import net.minecraft.world.entity.projectile.FishingHook;
import net.minecraft.world.entity.projectile.LlamaSpit;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ShulkerBullet;
import net.minecraft.world.entity.projectile.ThrowableProjectile;
import net.minecraft.world.entity.projectile.ThrownEnderpearl;
import net.minecraft.world.entity.projectile.ThrownExperienceBottle;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.ProjectileImpactEvent;

/**
 * Tangan Kahndaq (0.27, khusus Black Adam): adegan paling terkenal di film Black Adam (2022), peluru dan rudal berhenti di
 * udara di depannya lalu dikembalikan ke penembaknya.
 *
 * Pasif selama berwujud Black Adam: panah, trisula, bola api (ghast, blaze, wither, naga), wind charge, ramuan penyihir, dan
 * ludah llama yang meluncur ke arahnya (dalam 7 blok dan lintasannya lewat dekat badan) BERHENTI di udara, lalu ditarik pelan
 * ke lingkaran 2,2 blok di sekeliling badan dan melayang di situ, terikat busur petir membara dari telapaknya (paling banyak 16).
 *
 * Tombol J (sama dengan Kekuatan Keluarga Shazam): Black Adam mengibaskan tangan dan SEMUA proyektil yang tertahan melesat
 * balik ke penembaknya (kalau penembaknya pemain, sekutu, atau sudah mati: ke monster terdekat) dengan jejak petir membara.
 * Panah jadi kritis dan 1,5x lebih sakit; tiap proyektil yang mengenai monster memanggil petir membara (+8 damage). Tanpa J,
 * proyektil dikembalikan otomatis 3 detik sesudah tertangkap. Proyektil yang lolos tetap memantul dari kulit seperti dulu.
 */
public final class AdamCatch {
    private AdamCatch() {}

    // ======= Angka yang gampang diutak-atik =======
    public static final double CATCH_RADIUS = 7.0;      // proyektil yang mengarah ke Black Adam ditangkap sejauh ini
    private static final double CATCH_LANE = 2.6;       // ... kalau lintasannya lewat sedekat ini dari badan
    public static final int MAX_HELD = 16;              // paling banyak segini yang melayang sekaligus
    public static final int HOLD_TICKS = 60;            // tanpa J: dikembalikan otomatis 3 detik sesudah tertangkap
    public static final double HOLD_DISTANCE = 2.2;     // proyektil ditarik ke lingkaran sejauh ini dari badan
    private static final int GLIDE_TICKS = 6;           // lama ditarik ke lingkaran itu
    private static final double RETURN_SPEED = 3.2;     // blok/tick saat dikembalikan
    private static final double TARGET_RANGE = 40.0;    // penembak / monster sejauh ini masih dikejar
    private static final float RETURN_BONUS = 8f;       // + petir membara saat proyektil yang dikembalikan mengenai monster
    private static final double ARROW_DAMAGE_MULTIPLIER = 1.5;
    private static final int STRAIGHT_TICKS = 30;       // proyektil yang dikembalikan terbang lurus (tanpa gravitasi) selama ini
    // =========================================================================

    private record Held(UUID projectile, UUID shooter, Vec3 caughtAt, Vec3 offset, long tick, double phase) {}

    private static final Map<UUID, List<Held>> HELD = new HashMap<>();      // Black Adam -> proyektil yang melayang
    private static final Map<UUID, UUID> RETURNED_BY = new HashMap<>();     // proyektil yang dikembalikan -> Black Adam
    private static final Map<UUID, Long> RETURNED_AT = new HashMap<>();
    private static final Map<UUID, Long> POSE_NEXT = new HashMap<>();

    /** Jumlah proyektil yang sedang tertahan (buat HUD). */
    public static int heldCount(ServerPlayer adam) {
        List<Held> held = HELD.get(adam.getUUID());
        return held == null ? 0 : held.size();
    }

    private static boolean isHeld(UUID projectile) {
        for (List<Held> list : HELD.values()) {
            for (Held h : list) {
                if (h.projectile().equals(projectile)) {
                    return true;
                }
            }
        }
        return false;
    }

    /** Proyektil yang bisa ditangkap (mutiara ender, kail, kembang api, peluru shulker, botol XP: nggak). */
    private static boolean catchable(Projectile p) {
        if (!p.isAlive() || p instanceof ThrownEnderpearl || p instanceof FishingHook || p instanceof FireworkRocketEntity
                || p instanceof ShulkerBullet || p instanceof ThrownExperienceBottle) {
            return false;
        }
        return p instanceof AbstractArrow || p instanceof AbstractHurtingProjectile || p instanceof ThrowableProjectile
                || p instanceof LlamaSpit;
    }

    /** Sedang meluncur ke arah badan (bukan tertancap, bukan menjauh, lintasannya lewat dekat badan). */
    private static boolean threat(Projectile p, Vec3 center) {
        Vec3 v = p.getDeltaMovement();
        double speed2 = v.lengthSqr();
        if (speed2 < 0.04 || p.position().distanceToSqr(p.xo, p.yo, p.zo) < 0.01) {
            return false;
        }
        Vec3 d = center.subtract(p.position());
        double along = d.dot(v) / Math.sqrt(speed2);
        if (along <= 0.0) {
            return false;
        }
        double lane2 = d.lengthSqr() - along * along;
        return lane2 <= CATCH_LANE * CATCH_LANE;
    }

    private static Vec3 center(ServerPlayer adam) {
        return adam.position().add(0, adam.getBbHeight() * 0.55, 0);
    }

    /** Dipanggil tiap tick selama berwujud Black Adam (dari AdamSkills.tick). */
    public static void tick(ServerPlayer adam) {
        ServerLevel level = adam.serverLevel();
        long now = level.getGameTime();
        UUID id = adam.getUUID();
        List<Held> held = HELD.computeIfAbsent(id, k -> new ArrayList<>());
        Vec3 center = center(adam);
        // 1) yang tertahan: ditarik ke lingkaran di sekeliling badan, melayang naik-turun pelan, ikut badan
        boolean expired = false;
        for (Iterator<Held> it = held.iterator(); it.hasNext(); ) {
            Held h = it.next();
            Entity e = level.getEntity(h.projectile());
            if (!(e instanceof Projectile p) || !p.isAlive()) {
                it.remove();
                continue;
            }
            double k = Math.min(1.0, (now - h.tick()) / (double) GLIDE_TICKS);
            k = k * k * (3.0 - 2.0 * k);
            Vec3 pos = h.caughtAt().lerp(center.add(h.offset()), k).add(0, Math.sin((now + h.phase()) * 0.22) * 0.06, 0);
            p.setDeltaMovement(Vec3.ZERO);
            p.setNoGravity(true);
            p.setPos(pos.x, pos.y, pos.z);
            p.hurtMarked = true;   // kirim ke client sekarang, bukan menunggu jadwal update proyektil
            if (now - h.tick() >= HOLD_TICKS) {
                expired = true;
            }
        }
        if (expired) {
            release(adam, false);
        }
        // 2) yang sudah dikembalikan: gravitasi kembali sesudah terbang lurus sebentar
        for (Iterator<Map.Entry<UUID, Long>> it = RETURNED_AT.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<UUID, Long> entry = it.next();
            if (!id.equals(RETURNED_BY.get(entry.getKey())) || now - entry.getValue() < STRAIGHT_TICKS) {
                continue;
            }
            if (level.getEntity(entry.getKey()) instanceof Projectile p) {
                p.setNoGravity(p instanceof AbstractHurtingProjectile);   // bola api memang tanpa gravitasi
            }
            RETURNED_BY.remove(entry.getKey());
            it.remove();
        }
        // 3) tangkap yang baru datang
        if (held.size() >= MAX_HELD) {
            return;
        }
        boolean caught = false;
        AABB box = adam.getBoundingBox().inflate(CATCH_RADIUS);
        for (Projectile p : level.getEntitiesOfClass(Projectile.class, box, AdamCatch::catchable)) {
            if (held.size() >= MAX_HELD) {
                break;
            }
            if (p.getOwner() == adam || RETURNED_BY.containsKey(p.getUUID()) || isHeld(p.getUUID()) || !threat(p, center)) {
                continue;
            }
            Vec3 dir = p.position().subtract(center);
            dir = dir.lengthSqr() < 1.0E-4 ? adam.getViewVector(1f) : dir.normalize();
            Entity owner = p.getOwner();
            held.add(new Held(p.getUUID(), owner != null ? owner.getUUID() : null, p.position(), dir.scale(HOLD_DISTANCE), now,
                    level.random.nextDouble() * 30.0));
            p.setDeltaMovement(Vec3.ZERO);
            p.setNoGravity(true);
            p.hurtMarked = true;
            ShazamNetwork.playAnim(adam, ShazamAnim.ADAM_CATCH, p.position());   // client: berhenti + busur petir dari telapak
            level.playSound(null, p.getX(), p.getY(), p.getZ(), ShazamSounds.ADAM_CATCH.get(), SoundSource.PLAYERS, 1.2f,
                    0.92f + level.random.nextFloat() * 0.16f);
            caught = true;
        }
        if (caught) {
            ShazamNetwork.sync(adam);
        }
        // telapak tetap terangkat selama masih ada yang tertahan (diulang tiap 15 tick, klipnya mulai dari pose terangkat)
        if (!held.isEmpty()) {
            Long next = POSE_NEXT.get(id);
            if (next == null || now >= next) {
                POSE_NEXT.put(id, now + 15);
                ShazamNetwork.playAnim(adam, ShazamAnim.ADAM_HOLD, adam.position());
            }
        }
    }

    /** Tombol J (atau otomatis sesudah HOLD_TICKS): semua proyektil yang tertahan melesat balik. */
    public static void release(ServerPlayer adam, boolean manual) {
        ServerLevel level = adam.serverLevel();
        UUID id = adam.getUUID();
        List<Held> held = HELD.get(id);
        if (held == null || held.isEmpty()) {
            if (manual) {
                adam.displayClientMessage(Component.translatable("message.shazammod.catch_empty"), true);
            }
            return;
        }
        long now = level.getGameTime();
        Vec3 center = center(adam);
        ShazamNetwork.playAnim(adam, ShazamAnim.ADAM_RELEASE, adam.position());
        level.playSound(null, adam, ShazamSounds.ADAM_RELEASE.get(), SoundSource.PLAYERS, 2.0f, 1f);
        for (Held h : held) {
            Entity e = level.getEntity(h.projectile());
            if (!(e instanceof Projectile p) || !p.isAlive()) {
                continue;
            }
            LivingEntity target = target(adam, h, p);
            Vec3 dir;
            if (target != null) {
                dir = target.position().add(0, target.getBbHeight() * 0.6, 0).subtract(p.position());
            } else {   // nggak ada sasaran: dilempar menjauh dari badan
                Vec3 out = p.position().subtract(center);
                dir = new Vec3(out.x, Math.max(out.y, 0.15), out.z);
            }
            dir = dir.lengthSqr() < 1.0E-4 ? adam.getViewVector(1f) : dir.normalize();
            p.setOwner(adam);
            p.setNoGravity(true);
            p.setDeltaMovement(dir.scale(RETURN_SPEED));
            p.hurtMarked = true;
            if (p instanceof AbstractArrow arrow) {
                arrow.setBaseDamage(arrow.getBaseDamage() * ARROW_DAMAGE_MULTIPLIER);
                arrow.setCritArrow(true);
            }
            RETURNED_BY.put(p.getUUID(), id);
            RETURNED_AT.put(p.getUUID(), now);
        }
        held.clear();
        POSE_NEXT.remove(id);
        ShazamNetwork.sync(adam);
    }

    /** Penembaknya kalau monster dan masih hidup; kalau bukan (pemain, sekutu, sudah mati): monster terdekat. */
    private static LivingEntity target(ServerPlayer adam, Held h, Projectile p) {
        ServerLevel level = adam.serverLevel();
        double range2 = TARGET_RANGE * TARGET_RANGE;
        if (h.shooter() != null && level.getEntity(h.shooter()) instanceof LivingEntity shooter && shooter.isAlive()
                && shooter instanceof Enemy && shooter.distanceToSqr(adam) <= range2) {
            return shooter;
        }
        LivingEntity best = null;
        double bestD = range2;
        for (LivingEntity m : level.getEntitiesOfClass(LivingEntity.class, adam.getBoundingBox().inflate(TARGET_RANGE),
                e -> e.isAlive() && e instanceof Enemy)) {
            double d = m.distanceToSqr(p);
            if (d < bestD) {
                bestD = d;
                best = m;
            }
        }
        return best;
    }

    /** Proyektil yang dikembalikan mengenai sesuatu: kalau monster, petir membara menyambarnya (+damage). */
    public static void onImpact(ProjectileImpactEvent event) {
        Projectile p = event.getProjectile();
        UUID adamId = RETURNED_BY.remove(p.getUUID());
        if (adamId == null) {
            return;
        }
        RETURNED_AT.remove(p.getUUID());
        if (!(p.level() instanceof ServerLevel level) || !(level.getPlayerByUUID(adamId) instanceof ServerPlayer adam)) {
            return;
        }
        if (event.getRayTraceResult() instanceof EntityHitResult hit && hit.getEntity() instanceof LivingEntity victim
                && victim instanceof Enemy) {
            ShazamPowers.spawnBolt(level, victim.position(), 1.0f, 1);
            level.playSound(null, victim.getX(), victim.getY(), victim.getZ(), ShazamSounds.LIGHTNING_STRIKE.get(),
                    SoundSource.PLAYERS, 1.2f, ShazamSounds.tune(1.2f));
            ShazamPowers.schedule(adam, 1, a -> {   // tick berikutnya: nggak tertahan jeda kebal sesudah kena proyektilnya
                if (victim.isAlive()) {
                    victim.hurt(ShazamPowers.lightningSource(a), RETURN_BONUS);
                }
            });
        }
    }

    /** Balik jadi manusia / respawn: proyektil yang tertahan jatuh begitu saja. */
    public static void reset(ServerPlayer adam) {
        List<Held> held = HELD.remove(adam.getUUID());
        if (held == null) {
            return;
        }
        for (Held h : held) {
            if (adam.serverLevel().getEntity(h.projectile()) instanceof Projectile p) {
                p.setNoGravity(p instanceof AbstractHurtingProjectile);
                p.setDeltaMovement(0, -0.1, 0);
                p.hurtMarked = true;
            }
        }
    }

    public static void forget(UUID id) {
        HELD.remove(id);
        POSE_NEXT.remove(id);
        RETURNED_BY.values().removeIf(id::equals);
        RETURNED_AT.keySet().removeIf(k -> !RETURNED_BY.containsKey(k));
    }
}
