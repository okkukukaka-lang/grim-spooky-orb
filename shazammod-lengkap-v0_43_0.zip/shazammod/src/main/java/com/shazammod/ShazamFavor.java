package com.shazammod;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;

/**
 * 0.31 Restu Para Dewa: scaling Shazam.
 *
 * Angka dasar Shazam (darah 300, damage diterima 40%, tinju 40) sengaja di bawah angka mentah Black Adam (350, 35%, 44):
 * Black Adam menang kekuatan mentah. Tapi selama Shazam bertarung, keenam dewa terus menuangkan kekuatannya ke juara yang
 * mereka pilih: tiap FAVOR_GAIN_TICKS (2 detik) bertarung, satu tumpukan restu. Tiap tumpukan menambah darah maksimal,
 * mengurangi damage yang diterima, dan memperkuat tinju. Tumpukan penuh melampaui Black Adam di ketiga angka itu, seperti
 * di komik dan film: ujung-ujungnya Shazam yang lebih kuat.
 *
 * - "Bertarung" = memukul musuh atau diserang musuh dalam FAVOR_COMBAT_TICKS terakhir (serangan yang dihindari Refleks
 *   Mercury juga dihitung). Musuh = monster, pemain lain, Rival Juara, atau makhluk apa pun yang sedang mengincar Shazam.
 *   Hewan, villager, dan prajurit iblis sekutu nggak dihitung.
 * - Nggak bergantung pada Penangkal Petir Hidup, jadi tetap naik di gurun, es & salju, dan Nether (tempat petirnya padam,
 *   dan gurun justru tempat Rival Black Adam datang).
 * - Petir alam / trisula Channeling yang diserap: +FAVOR_STORM_STACKS sekaligus (badai tetap wilayah Shazam).
 * - Nggak bertarung lagi: luruh satu tumpukan tiap FAVOR_DECAY_TICKS.
 * - Balik jadi manusia (termasuk terlempar balik karena serangan mematikan), mati, atau keluar world: restu hilang semua.
 * - Bentrokan Juara (damage Rival Juara) menembus tahan banting juara, tapi restu tetap ikut menahannya kalau
 *   FAVOR_VS_CHAMPIONS: damage-nya dikali (damage diterima sekarang / damage diterima dasar). Tanpa restu = 1, sama persis
 *   dengan sebelumnya.
 * - Kelemahan sihir (MAGIC_DAMAGE_MULTIPLIER) tetap: restu nggak mengurangi damage sihir.
 *
 * Angka-angkanya (FAVOR_*) dikumpulkan bersama angka Shazam lain di bagian atas ShazamPowers.
 */
public final class ShazamFavor {
    private ShazamFavor() {}

    /** Darah dasar pemain, sebelum darah tambahan juara. */
    private static final double PLAYER_BASE_HEALTH = 20.0;
    /** Batas bawah damage yang diterima, jaga-jaga kalau angka per tumpukan diubah terlalu besar. */
    private static final float MIN_DAMAGE_TAKEN = 0.05f;

    private static final ResourceLocation HEALTH_ID = ShazamMod.id("gods_favor_health");

    private static final Map<UUID, Integer> STACKS = new HashMap<>();
    private static final Map<UUID, Long> COMBAT_UNTIL = new HashMap<>();
    private static final Map<UUID, Long> NEXT_GAIN = new HashMap<>();
    private static final Map<UUID, Long> NEXT_DECAY = new HashMap<>();
    private static final Set<UUID> FADING = new HashSet<>();

    // ------------------------------------------------------------------ Angka (dipakai juga HUD di client)

    private static int clamp(int stacks) {
        return Math.max(0, Math.min(ShazamPowers.FAVOR_MAX_STACKS, stacks));
    }

    /** Darah maksimal Shazam dengan sekian tumpukan restu (tanpa efek lain seperti Health Boost). */
    public static double maxHealthAt(int stacks) {
        return PLAYER_BASE_HEALTH + ShazamPowers.BONUS_HEALTH + clamp(stacks) * ShazamPowers.FAVOR_HEALTH_PER_STACK;
    }

    /** Bagian damage yang masih diterima Shazam dengan sekian tumpukan restu (0,4 = 40%). */
    public static float damageTakenAt(int stacks) {
        return Math.max(MIN_DAMAGE_TAKEN,
                ShazamPowers.DAMAGE_TAKEN_MULTIPLIER - clamp(stacks) * ShazamPowers.FAVOR_DAMAGE_TAKEN_PER_STACK);
    }

    /** Tinju tangan kosong Shazam dengan sekian tumpukan restu. */
    public static float punchAt(int stacks) {
        return ShazamPowers.PUNCH_MULTIPLIER + clamp(stacks) * ShazamPowers.FAVOR_PUNCH_PER_STACK;
    }

    /** Ketiga angka Shazam (darah, damage diterima, tinju) sudah melampaui angka mentah Black Adam. */
    public static boolean surpassesAdam(int stacks) {
        return maxHealthAt(stacks) > PLAYER_BASE_HEALTH + ShazamPowers.ADAM_BONUS_HEALTH
                && damageTakenAt(stacks) < ShazamPowers.ADAM_DAMAGE_TAKEN_MULTIPLIER
                && punchAt(stacks) > ShazamPowers.ADAM_PUNCH_MULTIPLIER;
    }

    /** Tumpukan pertama yang melampaui Black Adam di ketiga angka (-1 = nggak pernah, dengan angka yang sekarang). */
    public static int adamThreshold() {
        for (int stacks = 0; stacks <= ShazamPowers.FAVOR_MAX_STACKS; stacks++) {
            if (surpassesAdam(stacks)) {
                return stacks;
            }
        }
        return -1;
    }

    /** 0,345 -> "34.5%", 0,3 -> "30%". */
    public static String percent(float fraction) {
        return number(fraction * 100f) + "%";
    }

    /** 45,5 -> "45.5", 46,0 -> "46". */
    public static String number(float value) {
        float rounded = Math.round(value * 10f) / 10f;
        if (rounded == (float) Math.round(rounded)) {
            return Integer.toString(Math.round(rounded));
        }
        return String.format(Locale.ROOT, "%.1f", rounded);
    }

    // ------------------------------------------------------------------ Status

    /** Jumlah tumpukan restu pemain ini (0 = belum ada, atau bukan Shazam). */
    public static int stacks(Player player) {
        return STACKS.getOrDefault(player.getUUID(), 0);
    }

    /** Sedang berwujud Shazam (bukan Black Adam atau Sabbac). */
    public static boolean isShazam(ServerPlayer player) {
        ShazamData data = ShazamPowers.data(player);
        return data.transformed() && data.isShazam();
    }

    public static boolean inCombat(ServerPlayer player) {
        Long until = COMBAT_UNTIL.get(player.getUUID());
        return until != null && until > player.level().getGameTime();
    }

    /** Damage yang diterima Shazam sekarang (pengganti DAMAGE_TAKEN_MULTIPLIER). */
    public static float damageTakenMultiplier(ServerPlayer player) {
        return damageTakenAt(stacks(player));
    }

    /** Pengali Bentrokan Juara (damage Rival Juara): 1 tanpa restu, makin kecil makin banyak restu. */
    public static float clashMultiplier(ServerPlayer player) {
        if (!ShazamPowers.FAVOR_VS_CHAMPIONS || ShazamPowers.DAMAGE_TAKEN_MULTIPLIER <= 0f) {
            return 1f;
        }
        return Math.min(1f, damageTakenMultiplier(player) / ShazamPowers.DAMAGE_TAKEN_MULTIPLIER);
    }

    /** Tinju tangan kosong Shazam sekarang (pengganti PUNCH_MULTIPLIER). */
    public static float punchMultiplier(ServerPlayer player) {
        return punchAt(stacks(player));
    }

    // ------------------------------------------------------------------ Bertarung

    /**
     * Dipanggil untuk tiap damage (awal ShazamPowers.onIncomingDamage), sebelum dibatalkan atau dikurangi apa pun: Shazam
     * memukul musuh, atau musuh menyerang Shazam (walau serangannya dihindari) = sedang bertarung.
     */
    public static void onDamage(LivingEntity victim, DamageSource source) {
        Entity attacker = source.getEntity();
        if (victim instanceof ServerPlayer hurt && isShazam(hurt) && isFoe(attacker, hurt)) {
            markCombat(hurt);
        }
        if (attacker instanceof ServerPlayer hitter && hitter != victim && isShazam(hitter) && isFoe(victim, hitter)) {
            markCombat(hitter);
        }
    }

    /** Lawan yang dihitung: monster, pemain lain, Rival Juara, atau makhluk apa pun yang sedang mengincar Shazam. */
    private static boolean isFoe(Entity entity, ServerPlayer shazam) {
        if (!(entity instanceof LivingEntity living) || living == shazam || DemonSoldier.isFriendly(living)) {
            return false;
        }
        if (living instanceof Player other) {
            return !other.isSpectator();
        }
        return living instanceof Enemy || (living instanceof Mob mob && mob.getTarget() == shazam);
    }

    private static void markCombat(ServerPlayer player) {
        UUID id = player.getUUID();
        long now = player.level().getGameTime();
        if (!inCombat(player)) {
            NEXT_GAIN.put(id, now + ShazamPowers.FAVOR_GAIN_TICKS);   // tumpukan pertama 2 detik sesudah pertarungan mulai
        }
        COMBAT_UNTIL.put(id, now + ShazamPowers.FAVOR_COMBAT_TICKS);
        NEXT_DECAY.remove(id);
        FADING.remove(id);
    }

    // ------------------------------------------------------------------ Tiap tick

    /** Tiap tick selama berwujud Shazam (dari ShazamSkills.tick): naik selama bertarung, luruh sesudahnya. */
    public static void tick(ServerPlayer player) {
        UUID id = player.getUUID();
        long now = player.level().getGameTime();
        int stacks = stacks(player);
        if (inCombat(player)) {
            Long next = NEXT_GAIN.get(id);
            if (next == null) {
                NEXT_GAIN.put(id, now + ShazamPowers.FAVOR_GAIN_TICKS);
            } else if (now >= next) {
                NEXT_GAIN.put(id, now + ShazamPowers.FAVOR_GAIN_TICKS);
                if (stacks < ShazamPowers.FAVOR_MAX_STACKS) {
                    set(player, stacks + 1);
                }
            }
            return;
        }
        NEXT_GAIN.remove(id);
        if (stacks <= 0) {
            NEXT_DECAY.remove(id);
            return;
        }
        Long decay = NEXT_DECAY.get(id);
        if (decay == null) {
            NEXT_DECAY.put(id, now + ShazamPowers.FAVOR_DECAY_TICKS);
        } else if (now >= decay) {
            NEXT_DECAY.put(id, now + ShazamPowers.FAVOR_DECAY_TICKS);
            if (FADING.add(id)) {   // kabar sekali saja tiap pertarungan reda
                player.displayClientMessage(Component.translatable("message.shazammod.favor_fade")
                        .withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC), true);
            }
            set(player, stacks - 1);
        }
    }

    /** Petir alam / trisula Channeling diserap Penangkal Petir Hidup: restu langsung naik FAVOR_STORM_STACKS. */
    public static void onStorm(ServerPlayer player) {
        if (ShazamPowers.FAVOR_STORM_STACKS > 0 && isShazam(player)) {
            set(player, stacks(player) + ShazamPowers.FAVOR_STORM_STACKS);
        }
    }

    // ------------------------------------------------------------------ Mengubah tumpukan

    /** Atur tumpukan: darah maksimal ikut berubah, HUD langsung dikabari, dan kabar saat melampaui Black Adam / penuh. */
    public static void set(ServerPlayer player, int value) {
        UUID id = player.getUUID();
        int old = stacks(player);
        int stacks = clamp(value);
        if (stacks == old) {
            return;
        }
        if (stacks > 0) {
            STACKS.put(id, stacks);
        } else {
            STACKS.remove(id);
        }
        applyHealth(player, stacks);
        if (stacks > old) {
            int threshold = adamThreshold();
            if (stacks >= ShazamPowers.FAVOR_MAX_STACKS) {
                milestone(player, Component.translatable("message.shazammod.favor_max",
                                Math.round(maxHealthAt(stacks)), percent(damageTakenAt(stacks)), number(punchAt(stacks)))
                        .withStyle(ChatFormatting.YELLOW, ChatFormatting.BOLD), true);
            } else if (threshold > 0 && old < threshold && stacks >= threshold) {
                milestone(player, Component.translatable("message.shazammod.favor_surpass")
                        .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), false);
            }
        }
        ShazamNetwork.sync(player);
    }

    /** Melampaui Black Adam / restu penuh: lonjakan petir di badan (efek petir alam diserap), paduan suara ilahi. */
    private static void milestone(ServerPlayer player, Component message, boolean full) {
        ServerLevel level = player.serverLevel();
        ShazamNetwork.playAnim(player, ShazamAnim.STORM_ABSORB, player.position());
        level.playSound(null, player.getX(), player.getY(), player.getZ(), ShazamSounds.DIVINE.get(), SoundSource.PLAYERS,
                full ? 1.0f : 0.8f, ShazamSounds.tune(full ? 1.2f : 1.4f));
        level.playSound(null, player.getX(), player.getY(), player.getZ(), ShazamSounds.POWER_UP.get(), SoundSource.PLAYERS,
                1.2f, ShazamSounds.tune(full ? 1.3f : 1.5f));
        player.displayClientMessage(message, true);
    }

    /** Darah maksimal ikut tumpukan. Naik: darah barunya ikut terisi. Turun: darah dipangkas ke batas yang baru. */
    private static void applyHealth(ServerPlayer player, int stacks) {
        AttributeInstance instance = player.getAttribute(Attributes.MAX_HEALTH);
        if (instance == null) {
            return;
        }
        double amount = stacks * ShazamPowers.FAVOR_HEALTH_PER_STACK;
        AttributeModifier existing = instance.getModifier(HEALTH_ID);
        double before = existing != null ? existing.amount() : 0.0;
        if (before == amount) {
            return;
        }
        instance.removeModifier(HEALTH_ID);
        if (amount > 0.0) {
            instance.addTransientModifier(new AttributeModifier(HEALTH_ID, amount, AttributeModifier.Operation.ADD_VALUE));
        }
        if (player.isDeadOrDying()) {
            return;
        }
        if (amount > before) {
            // 0.30 Luka Juara (dihantam juara lain) tetap berlaku: darah barunya terisi setengah
            player.heal((float) (amount - before) * ShazamPowers.healScale(player));
        } else if (player.getHealth() > player.getMaxHealth()) {
            player.setHealth(player.getMaxHealth());
        }
    }

    /** Balik jadi manusia / respawn (dari ShazamSkills.cancelActive): restu hilang semua. */
    public static void reset(ServerPlayer player) {
        UUID id = player.getUUID();
        STACKS.remove(id);
        COMBAT_UNTIL.remove(id);
        NEXT_GAIN.remove(id);
        NEXT_DECAY.remove(id);
        FADING.remove(id);
        AttributeInstance instance = player.getAttribute(Attributes.MAX_HEALTH);
        if (instance != null && instance.getModifier(HEALTH_ID) != null) {
            instance.removeModifier(HEALTH_ID);
            if (player.getHealth() > player.getMaxHealth()) {
                player.setHealth(player.getMaxHealth());
            }
        }
    }

    /** Keluar world. */
    public static void forget(UUID id) {
        STACKS.remove(id);
        COMBAT_UNTIL.remove(id);
        NEXT_GAIN.remove(id);
        NEXT_DECAY.remove(id);
        FADING.remove(id);
    }

    /** /shazam favor: atur tumpukan langsung. Dihitung sedang bertarung, jadi nggak langsung luruh. */
    public static void setForTest(ServerPlayer player, int stacks) {
        markCombat(player);
        set(player, stacks);
    }
}
