package com.shazammod;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;

import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.Difficulty;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * 0.30: enam skill Sabbac, satu untuk tiap iblis S-A-B-B-A-C, plus Gerbang Neraka. Tombolnya sama dengan skill Shazam &
 * Black Adam (Z X C V B N R); gerakan & efeknya diputar di client lewat ShazamAnim.SABBAC_* (lihat client.fx.SabbacFx).
 *
 * S - Tanduk Setan     : tanduk membara, lalu menyeruduk lurus seperti banteng neraka sampai 14 blok. Musuh di jalur
 *                        tersangkut di tanduk dan ikut terbawa, lalu dilempar tinggi ke udara di ujung serudukan.
 * A - Tubuh Aym        : kulit membatu jadi obsidian berurat magma selama 7 detik: damage tinggal 20%, penyerang dekat
 *                        terbakar, dan semua damage yang ditahan meledak keluar di akhir (Letusan Aym).
 * B - Rantai Belial    : rantai neraka menyeruak dari tanah di bawah sampai 8 musuh yang terlihat, membelit, lalu menyeret
 *                        mereka ke depan Sabbac. Yang terbelenggu menerima +25% damage dari Sabbac selama 8 detik.
 * B - Napas Beelzebub  : semburan api neraka berbentuk kerucut selama 2 detik, mengikuti arah pandangan.
 * A - Teror Asmodeus   : raungan teror: musuh dalam 14 blok terhempas, lemah, lambat, dan lari ketakutan selama 5 detik;
 *                        keberanian jahat Asmodeus: pukulan Sabbac +40% selama 8 detik.
 * C - Kepakan Crateis  : sayap api terbentang, satu kepakan dahsyat menghempas musuh & proyektil, lalu Sabbac terangkat
 *                        terbang.
 * R - Gerbang Neraka   : Sabbac membesar jadi raksasa, lingkaran api neraka, semburan api memburu musuh tiap detik, dan
 *                        tiap pukulan meledakkan tiang api neraka.
 * M - Panggil Petir Neraka (padanan Panggil Petir Kahndaq): petir merah-hitam menyembur NAIK dari bawah tanah ke badan
 *                        sendiri: energi & darah terisi, musuh di sekitar terhempas dan terbakar.
 * J - Pasukan Iblis    (padanan Kekuatan Keluarga): enam prajurit iblis bangkit dari retakan neraka, bertarung 30 detik.
 */
public final class SabbacSkills {
    private SabbacSkills() {}

    public enum Skill {
        SATAN(25f, 80),        // S - Tanduk Setan
        AYM(70f, 800),         // A - Tubuh Aym
        BELIAL(30f, 300),      // B - Rantai Belial
        BEELZEBUB(35f, 160),   // B - Napas Beelzebub
        ASMODEUS(40f, 600),    // A - Teror Asmodeus
        CRATEIS(30f, 120),     // C - Kepakan Crateis
        HELLGATE(150f, 1200);  // Gerbang Neraka

        public final float cost;
        public final int cooldownTicks;

        Skill(float cost, int cooldownTicks) {
            this.cost = cost;
            this.cooldownTicks = cooldownTicks;
        }
    }

    // ================= Angka-angka yang gampang diutak-atik =================
    // S - Tanduk Setan
    private static final double HORN_RANGE = 14.0;
    private static final float HORN_HIT_DAMAGE = 10f;       // saat tersangkut di tanduk
    private static final float HORN_TOSS_DAMAGE = 26f;      // saat dilempar di ujung serudukan
    private static final double HORN_TOSS_UP = 1.25;
    private static final double HORN_HIT_RADIUS = 1.8;
    private static final int HORN_MAX_CARRIED = 4;          // paling banyak segini yang ikut terbawa (lainnya tersibak)
    private static final float HORN_STOMP_DAMAGE = 10f;
    private static final double HORN_STOMP_RADIUS = 3.5;
    // A - Tubuh Aym
    public static final float AYM_DAMAGE_MULTIPLIER = 0.2f;
    private static final float AYM_RETALIATE_DAMAGE = 6f;
    private static final float AYM_RETALIATE_FIRE = 4f;
    private static final int AYM_RETALIATE_GAP = 10;
    private static final float AYM_BURST_MIN = 12f;         // Letusan Aym = 12 + damage tertahan x 2 (maks 80)
    private static final float AYM_BURST_GAIN = 2f;
    private static final float AYM_BURST_MAX = 80f;
    private static final double AYM_BURST_RADIUS = 7.0;
    // B - Rantai Belial
    private static final double CHAIN_RADIUS = 16.0;
    private static final int CHAIN_TARGETS = 8;
    private static final float CHAIN_DAMAGE = 6f;
    private static final int BOUND_TICKS = 160;             // terbelenggu 8 detik
    public static final float BOUND_MULTIPLIER = 1.25f;     // menerima +25% damage dari Sabbac
    private static final double CHAIN_YANK_SPEED = 1.35;    // ditarik ke depan Sabbac (blok/tick)
    // B - Napas Beelzebub
    private static final double BREATH_RANGE = 12.0;
    private static final double BREATH_CONE_COS = 0.82;     // ±35°
    private static final float BREATH_DAMAGE = 5f;          // tiap 4 tick selama 2 detik (10 kali)
    private static final float BREATH_FIRE_SECONDS = 5f;
    // A - Teror Asmodeus
    private static final double TERROR_RADIUS = 14.0;
    private static final float TERROR_DAMAGE = 8f;
    private static final int TERROR_TICKS = 100;            // lari ketakutan 5 detik
    private static final int COURAGE_TICKS = 160;
    public static final float COURAGE_MULTIPLIER = 1.4f;    // pukulan +40% selama 8 detik
    // C - Kepakan Crateis
    private static final double WINGS_RADIUS = 9.0;
    private static final float WINGS_DAMAGE = 16f;
    private static final double WINGS_KNOCKBACK = 2.5;
    private static final float WINGS_FIRE_SECONDS = 4f;
    private static final double WINGS_LIFT = 1.45;          // Sabbac terangkat ke udara
    // Gerbang Neraka (R)
    public static final float RAGE_PUNCH_MULTIPLIER = 1.6f;
    public static final float RAGE_DAMAGE_TAKEN = 0.8f;
    private static final double RAGE_GROWTH = 0.6;          // jadi raksasa (+60% ukuran)
    private static final double RAGE_SPEED_BONUS = 0.2;
    private static final double RAGE_BLAST_RADIUS = 3.0;
    private static final float RAGE_BLAST_DAMAGE = 8f;
    private static final double RAGE_STORM_RADIUS = 14.0;
    private static final int RAGE_STORM_TARGETS = 3;
    private static final float RAGE_STORM_DAMAGE = 10f;
    private static final float RAGE_BURST_DAMAGE = 14f;
    private static final double RAGE_BURST_RADIUS = 6.0;
    private static final ResourceLocation RAGE_SPEED = ShazamMod.id("hellgate_speed");
    private static final ResourceLocation RAGE_SIZE = ShazamMod.id("hellgate_size");
    // M - Panggil Petir Neraka (gratis)
    public static final int CALL_COOLDOWN_TICKS = 500;
    private static final float CALL_ENERGY = 220f;
    private static final float CALL_HEAL = 120f;
    private static final double CALL_RADIUS = 6.5;
    private static final float CALL_DAMAGE = 20f;
    private static final double CALL_KNOCKBACK = 1.6;
    // J - Pasukan Iblis
    public static final float LEGION_COST = 200f;
    public static final int LEGION_COOLDOWN_TICKS = 1200;
    private static final int LEGION_SIZE = 6;
    // =========================================================================

    private static final Map<UUID, long[]> READY_AT = new HashMap<>();
    private static final Map<UUID, Long> CALL_READY_AT = new HashMap<>();
    private static final Map<UUID, Long> LEGION_READY_AT = new HashMap<>();
    private static final Map<UUID, Charge> CHARGES = new HashMap<>();
    private static final Map<UUID, Long> AYM_UNTIL = new HashMap<>();
    private static final Map<UUID, Float> AYM_STORED = new HashMap<>();
    private static final Map<UUID, Long> AYM_NEXT_RETALIATE = new HashMap<>();
    private static final Map<UUID, Long> BOUND_UNTIL = new HashMap<>();
    private static final Map<UUID, Long> BREATH_UNTIL = new HashMap<>();
    private static final Map<UUID, Terror> TERRORS = new HashMap<>();
    private static final Map<UUID, Long> COURAGE_UNTIL = new HashMap<>();
    private static final Map<UUID, Long> RAGE_UNTIL = new HashMap<>();

    private static final List<Holder<MobEffect>> DEBUFFS = List.of(
            MobEffects.MOVEMENT_SLOWDOWN, MobEffects.WEAKNESS, MobEffects.BLINDNESS, MobEffects.DARKNESS,
            MobEffects.DIG_SLOWDOWN, MobEffects.CONFUSION, MobEffects.POISON, MobEffects.WITHER, MobEffects.HUNGER);

    /** Serudukan Tanduk Setan: dari start ke end mulai game time begin; yang tersangkut ikut terbawa. */
    private record Charge(Vec3 start, Vec3 end, long begin, Set<UUID> hit, List<LivingEntity> carried) {}

    /** Musuh yang lari ketakutan dari pusat ini sampai game time until. */
    private record Terror(Vec3 center, long until, List<Mob> mobs) {}

    // ----------------------------------------------------------- Pakai skill

    public static void use(ServerPlayer player, Skill skill) {
        if (!ShazamPowers.isTransformed(player)) {
            if (ShazamPowers.data(player).anyUnlocked()) {
                player.displayClientMessage(Component.translatable("message.shazammod.not_transformed_sabbac")
                        .withStyle(ChatFormatting.GRAY), true);
            }
            return;
        }
        if (cooldownTicks(player, skill) > 0) {
            return;
        }
        if (ShazamPowers.data(player).energy() < skill.cost) {
            player.displayClientMessage(Component.translatable("message.shazammod.skill_no_energy",
                    Math.round(skill.cost)).withStyle(ChatFormatting.RED), true);
            return;
        }
        boolean used = switch (skill) {
            case SATAN -> satan(player);
            case AYM -> aym(player);
            case BELIAL -> belial(player);
            case BEELZEBUB -> beelzebub(player);
            case ASMODEUS -> asmodeus(player);
            case CRATEIS -> crateis(player);
            case HELLGATE -> hellgate(player);
        };
        if (!used) {
            player.displayClientMessage(Component.translatable("message.shazammod.no_target")
                    .withStyle(ChatFormatting.GRAY), true);
            return;
        }
        ShazamData data = ShazamPowers.data(player);
        ShazamPowers.setData(player, data.withEnergy(data.energy() - skill.cost));
        READY_AT.computeIfAbsent(player.getUUID(), id -> new long[Skill.values().length])[skill.ordinal()] =
                player.level().getGameTime() + skill.cooldownTicks;
        ShazamNetwork.sync(player);
    }

    public static int cooldownTicks(ServerPlayer player, Skill skill) {
        long[] readyAt = READY_AT.get(player.getUUID());
        if (readyAt == null) {
            return 0;
        }
        long left = readyAt[skill.ordinal()] - player.level().getGameTime();
        return left > 0 ? (int) left : 0;
    }

    /** Efek dijalankan beberapa tick lagi, dan dibatalkan kalau pemain keburu balik jadi manusia. */
    private static void later(ServerPlayer player, int delay, Consumer<ServerPlayer> action) {
        ShazamPowers.schedule(player, delay, p -> {
            if (ShazamPowers.isSabbac(p)) {
                action.accept(p);
            }
        });
    }

    /** Dipanggil tiap tick selama pemain berwujud Sabbac. */
    public static void tick(ServerPlayer player) {
        UUID id = player.getUUID();
        long now = player.level().getGameTime();

        Charge charge = CHARGES.get(id);
        if (charge != null && now > charge.begin()) {
            int k = (int) (now - charge.begin());
            chargeStep(player, charge, k);
            if (k >= ShazamAnim.HORN_TICKS) {
                CHARGES.remove(id);
                chargeEnd(player, charge);
            }
        }

        Long aymUntil = AYM_UNTIL.get(id);
        if (aymUntil != null) {
            if (now >= aymUntil) {
                AYM_UNTIL.remove(id);
                AYM_NEXT_RETALIATE.remove(id);
                aymBurst(player);
            } else {
                for (Holder<MobEffect> debuff : DEBUFFS) {   // tubuh Aym tak tertembus apa pun
                    if (player.hasEffect(debuff)) {
                        player.removeEffect(debuff);
                    }
                }
            }
        }

        Long breathUntil = BREATH_UNTIL.get(id);
        if (breathUntil != null) {
            if (now >= breathUntil) {
                BREATH_UNTIL.remove(id);
            } else if ((breathUntil - now) % 4 == 0) {
                breathStep(player);
            }
        }

        Terror terror = TERRORS.get(id);
        if (terror != null) {
            if (now >= terror.until()) {
                TERRORS.remove(id);
            } else if ((terror.until() - now) % 5 == 0) {
                terrorStep(player, terror);
            }
        }

        Long rageUntil = RAGE_UNTIL.get(id);
        if (rageUntil != null) {
            if (now >= rageUntil) {
                endRage(player);
                ShazamNetwork.broadcastState(player);
            } else if ((rageUntil - now) % 20 == 0) {
                rageStorm(player);
            }
        }

        if (player.tickCount % 200 == 0) {
            BOUND_UNTIL.values().removeIf(until -> until < now);
        }
        ShazamPassives.tick(player);   // Api Neraka tiap 2 detik, Muatan Neraka, Kulit Bara, Amarah Iblis
    }

    /** Hentikan skill yang sedang berjalan (balik jadi manusia, respawn). Cooldown tetap jalan. */
    public static void cancelActive(ServerPlayer player) {
        UUID id = player.getUUID();
        CHARGES.remove(id);
        AYM_UNTIL.remove(id);
        AYM_STORED.remove(id);
        AYM_NEXT_RETALIATE.remove(id);
        BREATH_UNTIL.remove(id);
        TERRORS.remove(id);
        COURAGE_UNTIL.remove(id);
        endRage(player);
    }

    public static void forget(UUID id) {
        READY_AT.remove(id);
        CALL_READY_AT.remove(id);
        LEGION_READY_AT.remove(id);
        CHARGES.remove(id);
        AYM_UNTIL.remove(id);
        AYM_STORED.remove(id);
        AYM_NEXT_RETALIATE.remove(id);
        BREATH_UNTIL.remove(id);
        TERRORS.remove(id);
        COURAGE_UNTIL.remove(id);
        RAGE_UNTIL.remove(id);
    }

    public static boolean isRageActive(ServerPlayer player) {
        Long until = RAGE_UNTIL.get(player.getUUID());
        return until != null && until > player.level().getGameTime();
    }

    public static boolean isAymActive(ServerPlayer player) {
        Long until = AYM_UNTIL.get(player.getUUID());
        return until != null && until > player.level().getGameTime();
    }

    /** Musuh yang sedang terbelenggu Rantai Belial. */
    public static boolean isBound(LivingEntity entity) {
        Long until = BOUND_UNTIL.get(entity.getUUID());
        return until != null && until > entity.level().getGameTime();
    }

    /** Pengali pukulan dari Teror Asmodeus (keberanian jahat). */
    public static float courageMultiplier(ServerPlayer player) {
        Long until = COURAGE_UNTIL.get(player.getUUID());
        return until != null && until > player.level().getGameTime() ? COURAGE_MULTIPLIER : 1f;
    }

    private static List<LivingEntity> enemies(ServerPlayer player, Vec3 center, double radius) {
        return player.serverLevel().getEntitiesOfClass(LivingEntity.class, new AABB(center, center).inflate(radius),
                m -> m.isAlive() && m instanceof Enemy && !DemonSoldier.isFriendly(m)
                        && m.distanceToSqr(center) <= radius * radius);
    }

    private static void sound(ServerPlayer player, Vec3 at, SoundEvent sound, float volume, float pitch) {
        player.serverLevel().playSound(null, at.x, at.y, at.z, sound, SoundSource.PLAYERS, volume, pitch);
    }

    private static Vec3 flatLook(ServerPlayer player) {
        Vec3 look = player.getViewVector(1f);
        Vec3 flat = new Vec3(look.x, 0, look.z);
        if (flat.lengthSqr() < 1.0E-4) {
            float yaw = player.getYRot() * Mth.DEG_TO_RAD;
            flat = new Vec3(-Mth.sin(yaw), 0, Mth.cos(yaw));
        }
        return flat.normalize();
    }

    private static Vec3 away(Vec3 center, LivingEntity entity) {
        Vec3 away = new Vec3(entity.getX() - center.x, 0, entity.getZ() - center.z);
        return away.lengthSqr() < 1.0E-4 ? Vec3.ZERO : away.normalize();
    }

    // ---------------------------------------------------- S - Tanduk Setan

    private static boolean satan(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        Vec3 dir = player.onGround() ? flatLook(player) : player.getViewVector(1f);
        if (player.onGround() && dir.y < 0.0) {
            dir = new Vec3(dir.x, 0.0, dir.z);
        }
        if (dir.lengthSqr() < 1.0E-4) {
            return false;
        }
        dir = dir.normalize();
        Vec3 start = player.position();
        Vec3 from = start.add(0, 1.0, 0);
        BlockHitResult hit = level.clip(new ClipContext(from, from.add(dir.scale(HORN_RANGE)), ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, player));
        double distance = hit.getType() == HitResult.Type.MISS ? HORN_RANGE : hit.getLocation().distanceTo(from) - 0.9;
        Vec3 end = start.add(dir.scale(distance));
        while (distance >= 2.0 && !level.noCollision(player, player.getBoundingBox().move(end.subtract(start)))) {
            distance -= 0.5;
            end = start.add(dir.scale(distance));
        }
        if (distance < 2.0) {
            return false;   // tembok tepat di depan
        }
        CHARGES.put(player.getUUID(), new Charge(start, end, level.getGameTime() + ShazamAnim.HORN_WINDUP, new HashSet<>(),
                new ArrayList<>()));
        ShazamNetwork.playAnim(player, ShazamAnim.SABBAC_HORNS, end);   // client pemain sendiri yang menggerakkan badan
        sound(player, start, ShazamSounds.HORNS_WINDUP.get(), 1.6f, 1f);   // menggaruk tanah 6 tick
        later(player, ShazamAnim.HORN_WINDUP, p -> sound(p, p.position(), ShazamSounds.HORNS_CHARGE.get(), 2.0f, 1f));
        return true;
    }

    /** Potongan lintasan tick ke-k: musuh di dekatnya tersangkut tanduk (atau tersibak kalau tanduknya penuh). */
    private static void chargeStep(ServerPlayer player, Charge charge, int k) {
        double t0 = Mth.clamp((k - 1) / (double) ShazamAnim.HORN_TICKS, 0.0, 1.0);
        double t1 = Mth.clamp(k / (double) ShazamAnim.HORN_TICKS, 0.0, 1.0);
        Vec3 a = charge.start().lerp(charge.end(), t0).add(0, 1.0, 0);
        Vec3 b = charge.start().lerp(charge.end(), t1).add(0, 1.0, 0);
        Vec3 dir = charge.end().subtract(charge.start()).normalize();
        DamageSource source = ShazamPowers.forceSource(player);
        AABB box = new AABB(a, b).inflate(HORN_HIT_RADIUS + 1.0);
        for (LivingEntity target : player.serverLevel().getEntitiesOfClass(LivingEntity.class, box,
                m -> m.isAlive() && m instanceof Enemy && !DemonSoldier.isFriendly(m))) {
            Vec3 body = target.position().add(0, target.getBbHeight() * 0.5, 0);
            if (AdamSkills.distanceToSegment(body, a, b) > HORN_HIT_RADIUS + target.getBbWidth() * 0.5
                    || !charge.hit().add(target.getUUID())) {
                continue;
            }
            target.hurt(source, HORN_HIT_DAMAGE);
            target.igniteForSeconds(3f);
            ShazamNetwork.playAnim(player, ShazamAnim.SABBAC_GORE, body);
            sound(player, body, ShazamSounds.PUNCH_CRIT.get(), 1.2f, ShazamSounds.tune(0.6f));
            if (charge.carried().size() < HORN_MAX_CARRIED && target.getMaxHealth() <= 300f) {
                charge.carried().add(target);   // tersangkut di tanduk, ikut terbawa
            } else {
                Vec3 side = body.subtract(a);
                side = side.subtract(dir.scale(side.dot(dir)));
                Vec3 push = side.lengthSqr() < 1.0E-4 ? new Vec3(-dir.z, 0, dir.x) : side.normalize();
                target.push(push.x * 1.2 + dir.x * 0.4, 0.5, push.z * 1.2 + dir.z * 0.4);
                target.hurtMarked = true;
            }
        }
        // yang tersangkut menempel di depan tanduk
        Vec3 front = player.position().add(dir.scale(1.5)).add(0, 0.7, 0);
        for (LivingEntity carried : charge.carried()) {
            if (carried.isAlive()) {
                carried.moveTo(front.x, front.y, front.z);
                carried.setDeltaMovement(dir.scale(0.4));
                carried.fallDistance = 0f;
                carried.hurtMarked = true;
            }
        }
    }

    /** Ujung serudukan: yang tersangkut dilempar tinggi, tanah dihentak. */
    private static void chargeEnd(ServerPlayer player, Charge charge) {
        Vec3 c = player.position();
        Vec3 dir = charge.end().subtract(charge.start()).normalize();
        DamageSource source = ShazamPowers.forceSource(player);
        for (LivingEntity carried : charge.carried()) {
            if (!carried.isAlive()) {
                continue;
            }
            carried.hurt(source, HORN_TOSS_DAMAGE);
            carried.setDeltaMovement(dir.x * 0.6, HORN_TOSS_UP, dir.z * 0.6);
            carried.hurtMarked = true;
            ShazamNetwork.playAnim(player, ShazamAnim.SABBAC_GORE, carried.position().add(0, carried.getBbHeight() * 0.5, 0));
        }
        for (LivingEntity target : enemies(player, c, HORN_STOMP_RADIUS)) {
            if (charge.hit().contains(target.getUUID())) {
                continue;
            }
            target.hurt(source, HORN_STOMP_DAMAGE);
            Vec3 push = away(c, target).scale(1.0);
            target.push(push.x, 0.4, push.z);
            target.hurtMarked = true;
        }
        sound(player, c, ShazamSounds.IMPACT.get(), 1.6f, ShazamSounds.tune(0.6f));
    }

    // ----------------------------------------------------- A - Tubuh Aym

    private static boolean aym(ServerPlayer player) {
        ShazamNetwork.playAnim(player, ShazamAnim.SABBAC_AYM);
        sound(player, player.position(), ShazamSounds.AYM_SHELL.get(), 1.6f, 1f);
        later(player, ShazamAnim.AYM_WINDUP, p -> {
            long now = p.level().getGameTime();
            AYM_UNTIL.put(p.getUUID(), now + ShazamAnim.AYM_TICKS);
            AYM_STORED.put(p.getUUID(), 0f);
            AYM_NEXT_RETALIATE.put(p.getUUID(), now);
            ShazamNetwork.broadcastState(p);
        });
        return true;
    }

    /** Damage yang ditahan kulit obsidian (dipanggil ShazamPowers saat damage masuk). */
    public static void storeAym(ServerPlayer player, float blocked) {
        if (blocked > 0f && AYM_STORED.containsKey(player.getUUID())) {
            AYM_STORED.merge(player.getUUID(), blocked, Float::sum);
        }
    }

    /** Yang memukul kulit Aym dari dekat ikut terbakar magma. */
    public static void aymRetaliate(ServerPlayer victim, DamageSource source) {
        if (!(source.getEntity() instanceof LivingEntity attacker) || attacker == victim || !attacker.isAlive()
                || attacker.distanceToSqr(victim) > 6.0 * 6.0) {
            return;
        }
        long now = victim.level().getGameTime();
        Long next = AYM_NEXT_RETALIATE.get(victim.getUUID());
        if (next != null && now < next) {
            return;
        }
        AYM_NEXT_RETALIATE.put(victim.getUUID(), now + AYM_RETALIATE_GAP);
        ShazamPowers.schedule(victim, 1, p -> {
            if (isAymActive(p) && attacker.isAlive()) {
                attacker.hurt(ShazamPowers.forceSource(p), AYM_RETALIATE_DAMAGE);
                attacker.igniteForSeconds(AYM_RETALIATE_FIRE);
                ShazamNetwork.playAnim(p, ShazamAnim.SABBAC_ENGULF, attacker.position().add(0, attacker.getBbHeight() * 0.6, 0));
            }
        });
    }

    /** Kulit obsidian pecah: semua damage yang ditahannya meledak keluar sebagai magma. */
    private static void aymBurst(ServerPlayer player) {
        Float stored = AYM_STORED.remove(player.getUUID());
        float damage = Mth.clamp(AYM_BURST_MIN + (stored == null ? 0f : stored) * AYM_BURST_GAIN, AYM_BURST_MIN, AYM_BURST_MAX);
        ShazamNetwork.playAnim(player, ShazamAnim.SABBAC_AYM_BURST);
        ShazamNetwork.broadcastState(player);
        later(player, ShazamAnim.NOVA_WINDUP, p -> {
            Vec3 c = p.position();
            DamageSource source = ShazamPowers.forceSource(p);
            for (LivingEntity target : enemies(p, c, AYM_BURST_RADIUS)) {
                target.hurt(source, damage);
                target.igniteForSeconds(5f);
                Vec3 push = away(c, target);
                target.push(push.x * 1.6, 0.5, push.z * 1.6);
                target.hurtMarked = true;
            }
            sound(p, c, ShazamSounds.AYM_BURST.get(), 2.2f, 1f);
        });
    }

    // ----------------------------------------------------- B - Rantai Belial

    private static boolean belial(ServerPlayer player) {
        List<LivingEntity> targets = enemies(player, player.position(), CHAIN_RADIUS);
        targets.removeIf(m -> !player.hasLineOfSight(m));
        if (targets.isEmpty()) {
            return false;
        }
        targets.sort(Comparator.comparingDouble(m -> m.distanceToSqr(player)));
        List<LivingEntity> chosen = new ArrayList<>(targets.subList(0, Math.min(CHAIN_TARGETS, targets.size())));
        ShazamNetwork.playAnim(player, ShazamAnim.SABBAC_CHAINS);
        sound(player, player.position(), ShazamSounds.EARTH_CRACK.get(), 1.4f, ShazamSounds.tune(0.5f));
        later(player, ShazamAnim.CHAIN_WINDUP, p -> {
            long until = p.level().getGameTime() + BOUND_TICKS;
            DamageSource source = ShazamPowers.forceSource(p);
            for (LivingEntity target : chosen) {
                if (!target.isAlive()) {
                    continue;
                }
                target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, ShazamAnim.CHAIN_PULL + 6, 5), p);
                target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, BOUND_TICKS, 1), p);
                target.addEffect(new MobEffectInstance(MobEffects.GLOWING, BOUND_TICKS, 0, false, false), p);
                BOUND_UNTIL.put(target.getUUID(), until);
                target.hurt(source, CHAIN_DAMAGE);
                ShazamNetwork.playAnim(p, ShazamAnim.SABBAC_CHAIN_BIND, target.position());
            }
            sound(p, p.position(), ShazamSounds.BELIAL_CHAINS.get(), 2.0f, 1f);
        });
        // satu detik kemudian: rantai menyeret semuanya ke depan Sabbac
        later(player, ShazamAnim.CHAIN_WINDUP + ShazamAnim.CHAIN_PULL, p -> {
            Vec3 front = p.position().add(flatLook(p).scale(2.5));
            for (LivingEntity target : chosen) {
                if (!target.isAlive()) {
                    continue;
                }
                Vec3 to = front.subtract(target.position());
                double d = to.length();
                if (d < 0.8) {
                    continue;
                }
                Vec3 v = to.normalize().scale(Math.min(CHAIN_YANK_SPEED, d * 0.32));
                target.setDeltaMovement(v.x, 0.32 + Math.max(0.0, v.y), v.z);
                target.fallDistance = 0f;
                target.hurtMarked = true;
            }
            sound(p, p.position(), ShazamSounds.WHOOSH_HEAVY.get(), 1.4f, ShazamSounds.tune(0.6f));
        });
        return true;
    }

    // ------------------------------------------------- B - Napas Beelzebub

    private static boolean beelzebub(ServerPlayer player) {
        ShazamNetwork.playAnim(player, ShazamAnim.SABBAC_BREATH);
        sound(player, player.position(), ShazamSounds.BEELZEBUB_BREATH.get(), 2.0f, 1f);   // tarik napas 8 tick + semburan 40
        later(player, ShazamAnim.BREATH_WINDUP, p -> BREATH_UNTIL.put(p.getUUID(), p.level().getGameTime() + ShazamAnim.BREATH_TICKS));
        return true;
    }

    /** Satu denyut semburan: semua musuh di kerucut pandangan terbakar api neraka. */
    private static void breathStep(ServerPlayer player) {
        Vec3 mouth = player.getEyePosition().add(0, -0.15, 0);
        Vec3 look = player.getViewVector(1f);
        DamageSource source = ShazamPowers.forceSource(player);
        for (LivingEntity target : enemies(player, mouth, BREATH_RANGE)) {
            Vec3 to = target.position().add(0, target.getBbHeight() * 0.5, 0).subtract(mouth);
            double d = to.length();
            if (d < 0.01 || to.normalize().dot(look) < BREATH_CONE_COS || !player.hasLineOfSight(target)) {
                continue;
            }
            target.hurt(source, BREATH_DAMAGE);
            target.igniteForSeconds(BREATH_FIRE_SECONDS);
            Vec3 push = look.scale(0.12);
            target.push(push.x, 0.02, push.z);
            target.hurtMarked = true;
        }
    }

    // ------------------------------------------------- A - Teror Asmodeus

    private static boolean asmodeus(ServerPlayer player) {
        ShazamNetwork.playAnim(player, ShazamAnim.SABBAC_ROAR);
        sound(player, player.position(), ShazamSounds.HELLGATE_WINDUP.get(), 1.0f, ShazamSounds.tune(1.3f));
        later(player, ShazamAnim.TERROR_WINDUP, SabbacSkills::roar);
        return true;
    }

    private static void roar(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        long now = level.getGameTime();
        Vec3 c = player.position();
        DamageSource source = ShazamPowers.forceSource(player);
        List<Mob> fleeing = new ArrayList<>();
        for (LivingEntity target : enemies(player, c, TERROR_RADIUS)) {
            target.hurt(source, TERROR_DAMAGE);
            target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, TERROR_TICKS, 1), player);
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, TERROR_TICKS, 1), player);
            target.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, TERROR_TICKS, 1), player);
            Vec3 push = away(c, target);
            target.push(push.x * 1.2, 0.35, push.z * 1.2);
            target.hurtMarked = true;
            if (target instanceof Mob mob) {
                mob.setTarget(null);
                fleeing.add(mob);
            }
        }
        TERRORS.put(player.getUUID(), new Terror(c, now + TERROR_TICKS, fleeing));
        COURAGE_UNTIL.put(player.getUUID(), now + COURAGE_TICKS);
        for (Holder<MobEffect> debuff : DEBUFFS) {   // keberanian jahat Asmodeus: nggak bisa dilemahkan
            if (player.hasEffect(debuff)) {
                player.removeEffect(debuff);
            }
        }
        sound(player, c, ShazamSounds.ASMODEUS_ROAR.get(), 2.5f, 1f);
    }

    /** Yang ketakutan nggak berani menyerang Sabbac dan lari menjauh. */
    private static void terrorStep(ServerPlayer player, Terror terror) {
        for (Mob mob : terror.mobs()) {
            if (!mob.isAlive()) {
                continue;
            }
            if (mob.getTarget() == player) {
                mob.setTarget(null);
            }
            if (mob instanceof PathfinderMob runner) {
                Vec3 away = new Vec3(mob.getX() - player.getX(), 0, mob.getZ() - player.getZ());
                if (away.lengthSqr() > 1.0E-4) {
                    Vec3 to = mob.position().add(away.normalize().scale(8.0));
                    runner.getNavigation().moveTo(to.x, to.y, to.z, 1.4);
                }
            }
        }
    }

    // ------------------------------------------------- C - Kepakan Crateis

    private static boolean crateis(ServerPlayer player) {
        ShazamNetwork.playAnim(player, ShazamAnim.SABBAC_WINGS);
        sound(player, player.position(), ShazamSounds.WHOOSH_HEAVY.get(), 1.4f, ShazamSounds.tune(0.5f));
        later(player, ShazamAnim.WINGS_WINDUP, SabbacSkills::wingBeat);
        return true;
    }

    private static void wingBeat(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        Vec3 c = player.position();
        DamageSource source = ShazamPowers.forceSource(player);
        for (LivingEntity target : enemies(player, c, WINGS_RADIUS)) {
            double d = Math.sqrt(target.distanceToSqr(c));
            float falloff = (float) (1.0 - d / WINGS_RADIUS * 0.5);
            target.hurt(source, WINGS_DAMAGE * falloff);
            target.igniteForSeconds(WINGS_FIRE_SECONDS);
            Vec3 push = away(c, target).scale(WINGS_KNOCKBACK * falloff);
            target.push(push.x, 0.7, push.z);
            target.hurtMarked = true;
        }
        // badai sayap: proyektil di sekitar terhempas menjauh
        for (Projectile projectile : level.getEntitiesOfClass(Projectile.class, player.getBoundingBox().inflate(WINGS_RADIUS + 2.0),
                p -> p.isAlive() && p.getOwner() != player)) {
            Vec3 away = projectile.position().subtract(c);
            Vec3 v = away.lengthSqr() < 1.0E-4 ? new Vec3(0, 1, 0) : away.normalize().scale(1.6);
            projectile.setDeltaMovement(v);
            projectile.hurtMarked = true;
        }
        // Sabbac terangkat dengan sayap apinya, langsung terbang
        Vec3 v = player.getDeltaMovement();
        player.setDeltaMovement(v.x * 0.4, WINGS_LIFT, v.z * 0.4);
        player.hurtMarked = true;
        player.fallDistance = 0f;
        if (!player.isCreative() && !player.isSpectator()) {
            player.getAbilities().mayfly = true;
        }
        player.getAbilities().flying = true;
        player.onUpdateAbilities();
        ShazamNetwork.broadcastState(player);
        sound(player, c, ShazamSounds.CRATEIS_WINGS.get(), 2.2f, 1f);
    }

    // ---------------------------------------------------- Gerbang Neraka (R)

    private static boolean hellgate(ServerPlayer player) {
        ShazamNetwork.playAnim(player, ShazamAnim.SABBAC_HELLGATE);
        sound(player, player.position(), ShazamSounds.HELLGATE_WINDUP.get(), 1.8f, 1f);   // tanah bergemuruh 12 tick
        later(player, ShazamAnim.HELLGATE_WINDUP, SabbacSkills::ignite);
        return true;
    }

    private static void ignite(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        RAGE_UNTIL.put(player.getUUID(), level.getGameTime() + ShazamAnim.RAGE_TICKS);
        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null && !speed.hasModifier(RAGE_SPEED)) {
            speed.addTransientModifier(new AttributeModifier(RAGE_SPEED, RAGE_SPEED_BONUS,
                    AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        }
        AttributeInstance size = player.getAttribute(Attributes.SCALE);
        if (size != null && !size.hasModifier(RAGE_SIZE)) {
            size.addTransientModifier(new AttributeModifier(RAGE_SIZE, RAGE_GROWTH, AttributeModifier.Operation.ADD_VALUE));
        }
        Vec3 center = player.position();
        DamageSource source = ShazamPowers.forceSource(player);
        for (LivingEntity target : enemies(player, center, RAGE_BURST_RADIUS)) {
            target.hurt(source, RAGE_BURST_DAMAGE);
            target.igniteForSeconds(4f);
            Vec3 push = away(center, target).scale(1.6);
            target.push(push.x, 0.5, push.z);
            target.hurtMarked = true;
        }
        for (int i = 0; i < 6; i++) {   // enam semburan api neraka di enam penjuru: enam iblis menjawab
            double angle = Math.PI * 2.0 * i / 6.0 + level.random.nextDouble() * 0.4;
            ShazamPowers.spawnBolt(level, center.add(Math.cos(angle) * 4.0, 0, Math.sin(angle) * 4.0), 0.9f,
                    ShazamForm.SABBAC.boltVariant());
        }
        sound(player, center, ShazamSounds.HELLGATE_OPEN.get(), 2.6f, 1f);
        ShazamNetwork.broadcastState(player);
    }

    private static void endRage(ServerPlayer player) {
        RAGE_UNTIL.remove(player.getUUID());
        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null) {
            speed.removeModifier(RAGE_SPEED);
        }
        AttributeInstance size = player.getAttribute(Attributes.SCALE);
        if (size != null) {
            size.removeModifier(RAGE_SIZE);
        }
    }

    /** Tiap detik api neraka menyembur dari tanah di bawah musuh terdekat. */
    private static void rageStorm(ServerPlayer player) {
        List<LivingEntity> targets = enemies(player, player.position(), RAGE_STORM_RADIUS);
        targets.sort(Comparator.comparingDouble(m -> m.distanceToSqr(player)));
        DamageSource source = ShazamPowers.forceSource(player);
        for (int i = 0; i < Math.min(RAGE_STORM_TARGETS, targets.size()); i++) {
            LivingEntity target = targets.get(i);
            ShazamNetwork.playAnim(player, ShazamAnim.SABBAC_GEYSER, target.position());
            target.hurt(source, RAGE_STORM_DAMAGE);
            target.igniteForSeconds(3f);
            target.push(0, 0.55, 0);
            target.hurtMarked = true;
            sound(player, target.position(), ShazamSounds.FIRE_BLAST.get(), 1.2f, ShazamSounds.tune(0.7f));
        }
    }

    /** Tinju raksasa: tiang api neraka meledak dari tanah di bawah sasaran, musuh di dekatnya ikut terhempas. */
    public static void ragePunch(ServerPlayer player, LivingEntity target) {
        Vec3 c = target.position();
        ShazamNetwork.playAnim(player, ShazamAnim.SABBAC_GEYSER, c);
        sound(player, c, ShazamSounds.FIRE_BLAST.get(), 1.6f, ShazamSounds.tune(0.6f));
        target.igniteForSeconds(4f);
        DamageSource force = ShazamPowers.forceSource(player);
        for (LivingEntity other : enemies(player, c, RAGE_BLAST_RADIUS)) {
            if (other == target) {
                continue;
            }
            other.hurt(force, RAGE_BLAST_DAMAGE);
            other.igniteForSeconds(2f);
            Vec3 push = away(c, other).scale(0.9);
            other.push(push.x, 0.4, push.z);
            other.hurtMarked = true;
        }
    }

    // ------------------------------------------- M - Panggil Petir Neraka

    public static int callCooldownTicks(ServerPlayer player) {
        Long ready = CALL_READY_AT.get(player.getUUID());
        if (ready == null) {
            return 0;
        }
        long left = ready - player.level().getGameTime();
        return left > 0 ? (int) left : 0;
    }

    /** Petir neraka menyembur naik dari bawah tanah menembus badan sendiri (seperti saat berubah di komik). */
    public static void callLightning(ServerPlayer player) {
        if (!ShazamPowers.isSabbac(player) || callCooldownTicks(player) > 0) {
            return;
        }
        CALL_READY_AT.put(player.getUUID(), player.level().getGameTime() + CALL_COOLDOWN_TICKS);
        ShazamNetwork.playAnim(player, ShazamAnim.SABBAC_CALL);
        sound(player, player.position(), ShazamSounds.DEMON_CALL_WINDUP.get(), 2.0f, 1f);   // tanah bergemuruh 12 tick
        later(player, ShazamAnim.SABBAC_CALL_WINDUP, p -> {
            ServerLevel level = p.serverLevel();
            Vec3 c = p.position();
            ShazamPowers.spawnBolt(level, c, 2.3f, ShazamForm.SABBAC.boltVariant());
            level.playSound(null, c.x, c.y, c.z, ShazamSounds.DEMON_CALL.get(), SoundSource.WEATHER, 3.0f, 1f);
            level.playSound(null, c.x, c.y, c.z, ShazamSounds.THUNDER.get(), SoundSource.WEATHER, 3.0f, ShazamSounds.tune(0.55f));
            ShazamData data = ShazamPowers.data(p);
            ShazamPowers.setData(p, data.withEnergy(data.energy() + CALL_ENERGY));
            p.heal(CALL_HEAL * ShazamPowers.healScale(p));
            p.clearFire();
            for (Holder<MobEffect> debuff : DEBUFFS) {
                if (p.hasEffect(debuff)) {
                    p.removeEffect(debuff);
                }
            }
            DamageSource source = ShazamPowers.lightningSource(p);
            for (LivingEntity target : enemies(p, c, CALL_RADIUS)) {
                target.hurt(source, CALL_DAMAGE);
                target.igniteForSeconds(3f);
                Vec3 push = away(c, target).scale(CALL_KNOCKBACK);
                target.push(push.x, 0.55, push.z);
                target.hurtMarked = true;
            }
            ShazamNetwork.sync(p);
        });
        ShazamNetwork.sync(player);
    }

    // --------------------------------------------------- J - Pasukan Iblis

    public static int legionCooldownTicks(ServerPlayer player) {
        Long ready = LEGION_READY_AT.get(player.getUUID());
        if (ready == null) {
            return 0;
        }
        long left = ready - player.level().getGameTime();
        return left > 0 ? (int) left : 0;
    }

    /** Jumlah prajurit iblis pemain ini yang masih bertarung (HUD). */
    public static int legionCount(ServerPlayer player) {
        return player.serverLevel().getEntitiesOfClass(DemonSoldier.class, player.getBoundingBox().inflate(64.0),
                s -> s.isAlive() && DemonSoldier.servesPlayer(s, player)).size();
    }

    public static void legion(ServerPlayer player) {
        if (!ShazamPowers.isSabbac(player)) {
            if (ShazamPowers.data(player).isSabbac()) {
                player.displayClientMessage(Component.translatable("message.shazammod.not_transformed_sabbac")
                        .withStyle(ChatFormatting.GRAY), true);
            }
            return;
        }
        int left = legionCooldownTicks(player);
        if (left > 0) {
            player.displayClientMessage(Component.translatable("message.shazammod.legion_cooldown", (left + 19) / 20)
                    .withStyle(ChatFormatting.GRAY), true);
            return;
        }
        ServerLevel level = player.serverLevel();
        if (level.getDifficulty() == Difficulty.PEACEFUL) {
            player.displayClientMessage(Component.translatable("message.shazammod.legion_peaceful")
                    .withStyle(ChatFormatting.GRAY), true);
            return;
        }
        ShazamData data = ShazamPowers.data(player);
        if (data.energy() < LEGION_COST) {
            player.displayClientMessage(Component.translatable("message.shazammod.legion_energy", Math.round(LEGION_COST))
                    .withStyle(ChatFormatting.RED), true);
            return;
        }
        ShazamPowers.setData(player, data.withEnergy(data.energy() - LEGION_COST));
        LEGION_READY_AT.put(player.getUUID(), level.getGameTime() + LEGION_COOLDOWN_TICKS);
        ShazamNetwork.playAnim(player, ShazamAnim.SABBAC_LEGION);
        sound(player, player.position(), ShazamSounds.DEMON_CALL_WINDUP.get(), 1.4f, ShazamSounds.tune(0.8f));
        later(player, ShazamAnim.LEGION_WINDUP, p -> {
            int count = summonLegion(p.serverLevel(), p, p.position(), LEGION_SIZE, true);
            p.displayClientMessage(Component.translatable("message.shazammod.legion_rise", count)
                    .withStyle(ChatFormatting.RED), true);
            sound(p, p.position(), ShazamSounds.LEGION_RISE.get(), 2.0f, 1f);
        });
        ShazamNetwork.sync(player);
    }

    /**
     * Bangkitkan prajurit iblis di cincin sekitar center. Dipakai Sabbac (sekutu) dan Rival Sabbac (musuh).
     * Hasil = jumlah yang bangkit.
     */
    public static int summonLegion(ServerLevel level, net.minecraft.world.entity.Entity master, Vec3 center, int count,
                                   boolean ally) {
        int made = 0;
        for (int i = 0; i < count; i++) {
            DemonSoldier soldier = ShazamEntities.DEMON_SOLDIER.get().create(level);
            if (soldier == null) {
                continue;
            }
            double angle = Math.PI * 2.0 * (i + level.random.nextDouble() * 0.4) / count;
            double distance = 2.5 + level.random.nextDouble() * 1.5;
            Vec3 at = center.add(Math.cos(angle) * distance, 0, Math.sin(angle) * distance);
            BlockHitResult ground = level.clip(new ClipContext(at.add(0, 3.0, 0), at.add(0, -4.0, 0),
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, soldier));
            if (ground.getType() != HitResult.Type.MISS) {
                at = ground.getLocation();
            }
            soldier.moveTo(at.x, at.y, at.z, (float) Math.toDegrees(angle) + 90f, 0f);
            soldier.bind(master, ally);
            if (level.addFreshEntity(soldier)) {
                made++;
                if (master instanceof ServerPlayer player) {
                    ShazamNetwork.playAnim(player, ShazamAnim.SABBAC_RISE, at);
                } else if (master instanceof com.shazammod.rival.RivalChampion rival) {
                    rival.anim(ShazamAnim.SABBAC_RISE, at);
                }
            }
        }
        return made;
    }
}
