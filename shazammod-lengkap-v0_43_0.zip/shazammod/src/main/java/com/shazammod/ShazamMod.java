package com.shazammod;

import java.util.function.Supplier;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

@Mod(ShazamMod.MODID)
public class ShazamMod {
    public static final String MODID = "shazammod";

    private static final DeferredRegister<AttachmentType<?>> ATTACHMENT_TYPES =
            DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, MODID);

    // Data Shazam milik tiap pemain: ikut tersimpan di save world dan tetap ada setelah mati
    public static final Supplier<AttachmentType<ShazamData>> SHAZAM_DATA = ATTACHMENT_TYPES.register(
            "shazam_data",
            () -> AttachmentType.builder(() -> ShazamData.DEFAULT)
                    .serialize(ShazamData.CODEC)
                    .copyOnDeath()
                    .build());

    // Jenis damage khusus petir Shazam (JSON-nya di data/shazammod/damage_type/)
    public static final ResourceKey<DamageType> SHAZAM_LIGHTNING =
            ResourceKey.create(Registries.DAMAGE_TYPE, id("shazam_lightning"));

    // Jenis damage untuk skill fisik (tepukan, hantaman, terjangan)
    public static final ResourceKey<DamageType> SHAZAM_FORCE =
            ResourceKey.create(Registries.DAMAGE_TYPE, id("shazam_force"));

    // 0.30 Kekuatan juara lain (Rival Juara): menembus armor & tahan banting juara, karena kekuatannya setara
    public static final ResourceKey<DamageType> CHAMPION_CLASH =
            ResourceKey.create(Registries.DAMAGE_TYPE, id("champion_clash"));

    public ShazamMod(IEventBus modEventBus, ModContainer modContainer) {
        ATTACHMENT_TYPES.register(modEventBus);
        ShazamEntities.ENTITY_TYPES.register(modEventBus);
        ShazamArmor.ARMOR_MATERIALS.register(modEventBus);
        ShazamItems.ITEMS.register(modEventBus);
        AdamItems.ITEMS.register(modEventBus);
        SabbacItems.BLOCKS.register(modEventBus);   // 0.30 Bijih Eternium
        SabbacItems.ITEMS.register(modEventBus);    // 0.30 Eternium & Mahkota Sabbac
        LintangItems.BLOCKS.register(modEventBus);  // 0.32 Bijih Kelam
        LintangItems.ITEMS.register(modEventBus);   // 0.32 Pecahan Kelam & Kristal Bintang
        HelionItems.ITEMS.register(modEventBus);    // 0.43 Serum Helion-6
        ShazamSounds.SOUNDS.register(modEventBus);   // SFX sinematik (assets/shazammod/sounds)
    }

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MODID, path);
    }
}
