package com.shazammod;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Client -> server: pemain menekan tombol transformasi (0) atau skill (1-4). */
public record ShazamActionPayload(int action) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<ShazamActionPayload> TYPE =
            new CustomPacketPayload.Type<>(ShazamMod.id("action"));

    public static final StreamCodec<ByteBuf, ShazamActionPayload> STREAM_CODEC =
            ByteBufCodecs.VAR_INT.map(ShazamActionPayload::new, ShazamActionPayload::action);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
