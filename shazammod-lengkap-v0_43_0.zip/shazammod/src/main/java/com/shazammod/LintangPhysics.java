package com.shazammod;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.WeakHashMap;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.common.Tags;

/**
 * 0.40 Hukum fisika untuk semua skill Lintang (1 blok = 1 meter, 1 tick = 1/20 detik).
 *
 * - Massa: dari volume kotak tabrakan x kepadatan efektif (pemain/zombie ~80 kg, golem besi ~640 kg, ayam ~13 kg).
 *   Impuls J -> perubahan kecepatan dv = J / m, jadi makhluk ringan terlempar jauh & yang berat cuma bergeser.
 * - Benda terlempar dilacak: menabrak dinding/tanah/makhluk lain -> damage dari energi kinetik 1/2 m v^2, momentum
 *   berpindah ke makhluk yang ditabrak (bisa beruntun seperti bola boling), kaca pecah kalau energinya cukup.
 * - Gelombang tekanan (tepukan, ledakan, hantaman tanah) merambat dengan kecepatan tetap: makin jauh makin telat
 *   sampai, tekanannya turun ~1/r, kaca pecah & api padam kalau tekanannya cukup, makhluk didorong sebanding tekanan x
 *   luas badan / massa.
 * - Panas (sinar mata): suhu blok yang disorot naik terus (dan mendingin pelan, hukum pendinginan Newton), lalu
 *   bahannya berubah: es/salju mencair, air mendidih jadi uap, pasir jadi kaca, batu & tanah jadi magma lalu lahar
 *   (0.42, sementara: membeku lagi jadi magma lalu basal), benda mudah terbakar menyala, TNT tersulut. Makhluk:
 *   langsung terbakar kena sinar (0.42), panas menumpuk -> damage naik; di air panasnya terserap.
 * - Dingin (napas beku): air jadi es, lava jadi obsidian/batu, api padam, magma mendingin, embun beku jadi salju.
 * - Energi matahari: sebanding sinus ketinggian matahari (hukum cosinus Lambert), berkurang saat hujan/badai, nol di
 *   Nether/End atau tanpa langit.
 */
public final class LintangPhysics {
    private LintangPhysics() {}

    // ------------------------------------------------------------------ tetapan (bisa diatur)

    /** Boleh mengubah blok (meleleh, membeku, kaca pecah, terbakar). false = efek fisika ke makhluk saja. */
    public static boolean BLOCK_CHANGES = true;
    /**
     * Batu yang sudah jadi magma boleh meleleh terus jadi lahar. 0.42: lahar ini sementara: begitu nggak disorot lagi
     * LAVA_HOLD_TICKS, permukaannya membeku jadi magma, lalu CRUST_TICKS kemudian jadi basal (false = berhenti di magma).
     */
    public static boolean MELT_TO_LAVA = true;
    public static final float LAVA_TEMP = 1350f;          // magma meleleh jadi lahar
    public static final int LAVA_HOLD_TICKS = 160;        // lahar tetap cair segini lama sesudah terakhir disorot
    public static final int CRUST_TICKS = 400;            // kerak magma mendingin jadi basal
    public static final double G = 0.08;                  // gravitasi makhluk vanila (blok/tick^2)
    public static final double DENSITY = 120.0;           // kg per blok^3 kotak tabrakan
    public static final double LINTANG_MASS = 600.0;      // badan Lintang yang super padat (tumbukan lesatan)
    public static final double MAX_SPEED = 3.6;           // blok/tick (72 m/s)
    public static final double WAVE_SPEED = 3.4;          // blok/tick: kecepatan suara 343 m/s diperlambat 5x supaya terlihat
    public static final double SEISMIC_SPEED = 2.2;       // blok/tick: gelombang di permukaan tanah, lebih lambat dari udara
    public static final double JOULE_PER_DAMAGE = 2500.0; // energi kinetik tumbukan per 1 damage
    public static final double IMPACT_MIN_SPEED = 0.45;   // perubahan kecepatan minimum yang dianggap tumbukan (blok/tick)
    public static final double GLASS_BREAK_JOULE = 3000.0;
    public static final float AMBIENT = 20f;              // suhu sekitar (°C)
    public static final float COOLING = 0.025f;           // laju pendinginan Newton per tick
    public static final float IGNITE_TEMP = 300f;         // makhluk mulai terbakar

    // ------------------------------------------------------------------ massa & impuls

    /** Massa kira-kira (kg) dari volume kotak tabrakan. */
    public static double mass(Entity e) {
        AABB b = e.getBoundingBox();
        double v = Math.max(0.02, b.getXsize() * b.getYsize() * b.getZsize());
        return Mth.clamp(v * DENSITY, 4.0, 5000.0);
    }

    /** Luas penampang kira-kira (m^2) yang ditabrak gelombang tekanan. */
    public static double area(Entity e) {
        return Math.max(0.05, e.getBbWidth() * e.getBbHeight());
    }

    private static double grip(LivingEntity e) {
        return Mth.clamp(e.getAttributeValue(Attributes.KNOCKBACK_RESISTANCE), 0.0, 1.0);
    }

    /** Impuls J (kg·blok/tick): dv = J/m (tahanan dorong mengurangi sampai 75%). Benda yang melaju kencang dilacak. */
    public static Vec3 impulse(ServerPlayer owner, LivingEntity target, Vec3 j) {
        Vec3 dv = j.scale((1.0 - 0.75 * grip(target)) / mass(target));
        setVelocity(owner, target, target.getDeltaMovement().add(dv));
        return dv;
    }

    /** Kecepatan langsung (dibatasi MAX_SPEED), dilacak kalau cukup kencang. */
    public static void setVelocity(ServerPlayer owner, LivingEntity target, Vec3 v) {
        double s = v.length();
        if (s > MAX_SPEED) {
            v = v.scale(MAX_SPEED / s);
        }
        target.setDeltaMovement(v);
        target.hurtMarked = true;
        if (v.length() > IMPACT_MIN_SPEED) {
            track(owner, target);
        }
    }

    /** Energi kinetik (joule) dari kecepatan blok/tick. */
    public static double kinetic(double mass, double speed) {
        double ms = speed * 20.0;
        return 0.5 * mass * ms * ms;
    }

    /**
     * Tumbukan lenting dengan sasaran yang diam: kecepatan sasaran sesudahnya = v x 2m1/(m1+m2). Sasaran ringan
     * terpental hampir 2x kecepatan penabrak, yang berat nyaris nggak bergerak. Mengembalikan energi tumbukan (J).
     */
    public static double collide(ServerPlayer owner, LivingEntity target, double m1, Vec3 v1) {
        double m2 = mass(target);
        Vec3 v2 = v1.scale(2.0 * m1 / (m1 + m2) * (1.0 - 0.6 * grip(target)));
        setVelocity(owner, target, target.getDeltaMovement().add(v2).add(0, 0.12, 0));
        double mu = m1 * m2 / (m1 + m2);   // massa tereduksi: energi yang benar-benar dipakai merusak
        return kinetic(mu, v1.length());
    }

    /** Damage dari energi (dibatasi supaya bos nggak mati sekali sentuh), jeda kebal dilewati. */
    public static void hurtByEnergy(ServerPlayer owner, LivingEntity target, double joule, float cap) {
        float dmg = (float) Math.min(cap, joule / JOULE_PER_DAMAGE);
        if (dmg < 0.5f) {
            return;
        }
        target.invulnerableTime = 0;
        target.hurt(ShazamPowers.forceSource(owner), dmg);
    }

    private static boolean foe(ServerPlayer owner, LivingEntity e) {
        return e != owner && e.isAlive() && e instanceof Enemy && !DemonSoldier.isFriendly(e);
    }

    // ------------------------------------------------------------------ benda terlempar (energi kinetik)

    private static final class Body {
        final UUID owner;
        final long until;
        Vec3 last;
        final Set<Integer> struck = new HashSet<>();

        Body(UUID owner, long until, Vec3 v) {
            this.owner = owner;
            this.until = until;
            this.last = v;
        }
    }

    private static final Map<LivingEntity, Body> BODIES = new WeakHashMap<>();

    public static void track(ServerPlayer owner, LivingEntity e) {
        Body old = BODIES.get(e);
        Body b = new Body(owner.getUUID(), owner.level().getGameTime() + 80, e.getDeltaMovement());
        if (old != null) {
            b.struck.addAll(old.struck);
        }
        BODIES.put(e, b);
    }

    public static boolean flying(LivingEntity e) {
        return BODIES.containsKey(e);
    }

    private static void tickBodies(ServerPlayer owner, long now) {
        if (BODIES.isEmpty()) {
            return;
        }
        List<LivingEntity> list = new ArrayList<>(BODIES.keySet());
        for (LivingEntity e : list) {
            Body b = BODIES.get(e);
            if (b == null || !b.owner.equals(owner.getUUID())) {
                continue;
            }
            if (!e.isAlive() || e.isRemoved() || now > b.until || e.level() != owner.level()) {
                BODIES.remove(e);
                continue;
            }
            Vec3 prev = b.last;
            Vec3 cur = e.getDeltaMovement();
            double m = mass(e);
            // menabrak dinding: kecepatan mendatar hilang mendadak
            double lostH = Math.sqrt(prev.x * prev.x + prev.z * prev.z) - Math.sqrt(cur.x * cur.x + cur.z * cur.z);
            if (e.horizontalCollision && lostH > IMPACT_MIN_SPEED) {
                impact(owner, e, m, lostH, new Vec3(prev.x, 0, prev.z).normalize());
            }
            // jatuh menghantam tanah
            if (e.onGround() && prev.y < -IMPACT_MIN_SPEED) {
                impact(owner, e, m, -prev.y, new Vec3(0, -1, 0));
            }
            // menabrak makhluk lain di jalurnya: momentum berpindah (beruntun)
            if (prev.length() > IMPACT_MIN_SPEED) {
                AABB sweep = e.getBoundingBox().expandTowards(prev).inflate(0.2);
                for (LivingEntity other : e.level().getEntitiesOfClass(LivingEntity.class, sweep,
                        o -> o != e && foe(owner, o) && !b.struck.contains(o.getId()))) {
                    b.struck.add(other.getId());
                    double joule = collide(owner, other, m, prev);
                    hurtByEnergy(owner, other, joule, 40f);
                    hurtByEnergy(owner, e, joule * 0.5, 40f);
                    BODIES.computeIfPresent(other, (k, ob) -> {
                        ob.struck.add(e.getId());
                        return ob;
                    });
                    ShazamNetwork.playAnim(owner, ShazamAnim.LINTANG_HIT, other.position().add(0, other.getBbHeight() * 0.6, 0));
                    e.setDeltaMovement(prev.scale(0.35));   // penabrak kehilangan sebagian besar momentumnya
                }
            }
            b.last = e.getDeltaMovement();
            if (e.onGround() && b.last.horizontalDistanceSqr() < 0.004 && now > b.until - 74) {
                BODIES.remove(e);
            }
        }
    }

    /** Tumbukan dengan dunia: damage 1/2 m v^2, debu/kawah sesuai energi, kaca di titik tabrak pecah. */
    private static void impact(ServerPlayer owner, LivingEntity e, double m, double speed, Vec3 dir) {
        double joule = kinetic(m, speed);
        hurtByEnergy(owner, e, joule, 60f);
        Vec3 at = e.position().add(0, e.getBbHeight() * 0.4, 0);
        ShazamNetwork.playAnim(owner, joule > 40000 ? ShazamAnim.HERCULES_IMPACT : ShazamAnim.LINTANG_HIT, at);
        float vol = (float) Mth.clamp(joule / 30000.0, 0.4, 2.0);
        e.level().playSound(null, at.x, at.y, at.z, ShazamSounds.PUNCH.get(), SoundSource.PLAYERS, vol, ShazamSounds.tune(0.8f));
        if (joule > GLASS_BREAK_JOULE && owner.level() instanceof ServerLevel level) {
            BlockPos front = BlockPos.containing(at.add(dir.scale(e.getBbWidth() * 0.5 + 0.4)));
            for (BlockPos p : BlockPos.betweenClosed(front.offset(-1, -1, -1), front.offset(1, 1, 1))) {
                if (isGlass(level.getBlockState(p)) && canChange(owner, level, p)) {
                    shatter(owner, level, p.immutable());
                }
            }
        }
    }

    // ------------------------------------------------------------------ gelombang tekanan

    /** Gelombang tekanan yang merambat dari center (axis + coneCos untuk kerucut; axis null = bola). */
    private static final class Wave {
        final UUID owner;
        final Vec3 center;
        final Vec3 axis;
        final double coneCos, maxR, speed, damage1, impulse1, glassR, core;
        final boolean ground;
        final long start;
        final Set<Integer> hit = new HashSet<>();
        int shards;

        Wave(UUID owner, Vec3 center, Vec3 axis, double coneCos, double maxR, double speed, double damage1, double impulse1,
             double glassR, boolean ground, long start, double core) {
            this.core = Math.max(1.0, core);
            this.owner = owner;
            this.center = center;
            this.axis = axis;
            this.coneCos = coneCos;
            this.maxR = maxR;
            this.speed = speed;
            this.damage1 = damage1;
            this.impulse1 = impulse1;
            this.glassR = glassR;
            this.ground = ground;
            this.start = start;
        }
    }

    private static final List<Wave> WAVES = new ArrayList<>();

    /**
     * Gelombang tekanan udara. damage1/impulse1 = damage & impuls (kg·blok/tick per m^2) pada jarak 1 blok; di jarak r
     * tinggal 1/r-nya. glassR = jarak terjauh kaca masih pecah.
     */
    public static void blast(ServerPlayer owner, Vec3 center, Vec3 axis, double coneCos, double maxR, double damage1,
                             double impulse1, double glassR) {
        blast(owner, center, axis, coneCos, maxR, damage1, impulse1, glassR, 1.0);
    }

    /**
     * 0.41 sama, tapi dengan radius sumber (core): sumber gelombang sebesar ini (kawah, bola api, tepukan raksasa), jadi
     * di dalamnya tekanan puncak rata dan baru di luarnya turun 1/r (tekanan di jarak r = puncak x core / r).
     */
    public static void blast(ServerPlayer owner, Vec3 center, Vec3 axis, double coneCos, double maxR, double damagePeak,
                             double impulsePeak, double glassR, double core) {
        WAVES.add(new Wave(owner.getUUID(), center, axis == null ? null : axis.normalize(), coneCos, maxR, WAVE_SPEED, damagePeak,
                impulsePeak, glassR, false, owner.level().getGameTime(), core));
    }

    /** Gelombang seismik di permukaan tanah: cuma melontarkan yang sedang berpijak di tanah (yang di udara selamat). */
    public static void quake(ServerPlayer owner, Vec3 center, double maxR, double damage1, double impulse1) {
        quake(owner, center, maxR, damage1, impulse1, 1.0);
    }

    /** 0.41 gelombang seismik dengan radius sumber (lihat blast): di dalam kawah guncangannya rata, di luarnya ~1/r. */
    public static void quake(ServerPlayer owner, Vec3 center, double maxR, double damagePeak, double impulsePeak, double core) {
        WAVES.add(new Wave(owner.getUUID(), center, null, -1.0, maxR, SEISMIC_SPEED, damagePeak, impulsePeak, 0.0, true,
                owner.level().getGameTime(), core));
    }

    private static void tickWaves(ServerPlayer owner, long now) {
        if (WAVES.isEmpty()) {
            return;
        }
        ServerLevel level = owner.serverLevel();
        for (Iterator<Wave> it = WAVES.iterator(); it.hasNext();) {
            Wave w = it.next();
            if (!w.owner.equals(owner.getUUID())) {
                continue;
            }
            double age = now - w.start + 1;
            double r1 = Math.min(w.maxR, w.speed * age), r0 = w.speed * (age - 1);
            if (r0 > w.maxR) {
                it.remove();
                continue;
            }
            AABB box = new AABB(w.center, w.center).inflate(r1);
            for (Entity ent : level.getEntities(owner, box, Entity::isAlive)) {
                Vec3 at = ent.position().add(0, ent.getBbHeight() * 0.5, 0);
                Vec3 to = at.subtract(w.center);
                double d = w.ground ? Math.sqrt(to.x * to.x + to.z * to.z) : to.length();
                if (d > r1 || d <= r0 - 0.001 || w.hit.contains(ent.getId())) {
                    continue;
                }
                if (w.axis != null && d > 0.3 && to.normalize().dot(w.axis) < w.coneCos) {
                    continue;
                }
                w.hit.add(ent.getId());
                double p = 1.0 / Math.max(1.0, d / w.core);   // rata di dalam sumber, lalu tekanan turun ~1/r
                Vec3 dir = d < 1.0E-3 ? new Vec3(0, 1, 0) : new Vec3(to.x, w.ground ? 0 : to.y, to.z).normalize();
                if (ent instanceof Projectile proj) {   // proyektil dibelokkan menjauh
                    proj.setDeltaMovement(dir.scale(0.6 + 1.6 * p));
                    proj.hurtMarked = true;
                } else if (ent instanceof ItemEntity item) {
                    item.setDeltaMovement(item.getDeltaMovement().add(dir.scale(0.8 * p)).add(0, 0.25 * p, 0));
                    item.hurtMarked = true;
                } else if (ent instanceof LivingEntity le && foe(owner, le)) {
                    if (w.ground && !le.onGround()) {
                        continue;   // gelombang tanah nggak menyentuh yang melayang/terbang
                    }
                    le.invulnerableTime = 0;
                    le.hurt(ShazamPowers.forceSource(owner), (float) (w.damage1 * p));
                    Vec3 j = w.ground ? new Vec3(dir.x * 0.5, 1.0, dir.z * 0.5).scale(w.impulse1 * p * area(le))
                            : dir.add(0, 0.25, 0).scale(w.impulse1 * p * area(le));
                    impulse(owner, le, j);
                }
            }
            if (w.glassR > 0 && r0 < w.glassR) {   // kaca pecah & api padam di cangkang gelombang
                shell(owner, level, w, r0, Math.min(r1, w.glassR));
            }
        }
    }

    private static void shell(ServerPlayer owner, ServerLevel level, Wave w, double r0, double r1) {
        if (!BLOCK_CHANGES) {
            return;
        }
        BlockPos c = BlockPos.containing(w.center);
        int r = (int) Math.ceil(r1);
        for (BlockPos p : BlockPos.betweenClosed(c.offset(-r, -r, -r), c.offset(r, r, r))) {
            Vec3 to = Vec3.atCenterOf(p).subtract(w.center);
            double d = to.length();
            if (d > r1 || d < r0) {
                continue;
            }
            if (w.axis != null && d > 0.5 && to.normalize().dot(w.axis) < w.coneCos) {
                continue;
            }
            BlockState s = level.getBlockState(p);
            if (isGlass(s) && canChange(owner, level, p)) {
                shatter(owner, level, p.immutable(), w);
            } else if (s.getBlock() instanceof BaseFireBlock) {
                level.removeBlock(p, false);
            }
        }
    }

    // ------------------------------------------------------------------ panas (sinar mata)

    private static final Map<Level, Map<BlockPos, float[]>> HEAT = new WeakHashMap<>();   // {suhu, tick terakhir}
    private static final Map<LivingEntity, float[]> BODY_HEAT = new WeakHashMap<>();

    private static float cooled(float[] h, long now) {
        float dt = Math.max(0f, now - h[1]);
        h[0] = AMBIENT + (h[0] - AMBIENT) * (float) Math.exp(-COOLING * dt);   // hukum pendinginan Newton
        h[1] = now;
        return h[0];
    }

    /** Suhu blok sekarang (buat efek). */
    public static float temperature(Level level, BlockPos pos) {
        Map<BlockPos, float[]> m = HEAT.get(level);
        float[] h = m == null ? null : m.get(pos);
        return h == null ? AMBIENT : cooled(h, level.getGameTime());
    }

    /**
     * Panas q (°C) dari sinar ke blok ini. Suhu menumpuk kalau terus disorot, lalu bahannya berubah sesuai titik
     * lelehnya. Mengembalikan suhu baru.
     */
    public static float heatBlock(ServerPlayer owner, BlockPos pos, Direction face, float q) {
        ServerLevel level = owner.serverLevel();
        long now = level.getGameTime();
        Map<BlockPos, float[]> m = HEAT.computeIfAbsent(level, k -> new HashMap<>());
        if (m.size() > 512) {   // buang blok yang sudah dingin
            m.entrySet().removeIf(en -> cooled(en.getValue(), now) < AMBIENT + 15f);
        }
        float[] h = m.computeIfAbsent(pos.immutable(), k -> new float[] {AMBIENT, now});
        float t = Math.min(1700f, cooled(h, now) + q);
        h[0] = t;
        if (BLOCK_CHANGES && canChange(owner, level, pos)) {
            react(owner, level, pos, face, t, m);
        }
        return t;
    }

    private static void react(ServerPlayer owner, ServerLevel level, BlockPos pos, Direction face, float t,
                              Map<BlockPos, float[]> m) {
        BlockState s = level.getBlockState(pos);
        boolean nether = level.dimensionType().ultraWarm();
        if (s.is(BlockTags.ICE) && t >= 60f) {                          // es mencair (di Nether langsung menguap)
            level.setBlockAndUpdate(pos, nether ? Blocks.AIR.defaultBlockState() : Blocks.WATER.defaultBlockState());
            steam(owner, level, pos);
        } else if ((s.is(Blocks.SNOW) || s.is(Blocks.SNOW_BLOCK) || s.is(Blocks.POWDER_SNOW)) && t >= 35f) {
            level.removeBlock(pos, false);
            steam(owner, level, pos);
        } else if (s.is(Blocks.WATER) && level.getFluidState(pos).isSource() && t >= 420f) {   // mendidih habis jadi uap
            level.setBlockAndUpdate(pos, Blocks.AIR.defaultBlockState());
            m.remove(pos);
            steam(owner, level, pos);
        } else if (s.is(Blocks.SAND) && t >= 900f) {                    // pasir meleleh jadi kaca
            level.setBlockAndUpdate(pos, Blocks.GLASS.defaultBlockState());
            melt(owner, pos);
        } else if (s.is(Blocks.RED_SAND) && t >= 900f) {
            level.setBlockAndUpdate(pos, Blocks.ORANGE_STAINED_GLASS.defaultBlockState());
            melt(owner, pos);
        } else if (s.is(Blocks.MAGMA_BLOCK) && MELT_TO_LAVA && t >= LAVA_TEMP) {   // 0.42 meleleh jadi lahar (sementara)
            level.setBlockAndUpdate(pos, Blocks.LAVA.defaultBlockState());
            molten(level, pos);
            melt(owner, pos);
        } else if (s.is(Blocks.LAVA) && level.getFluidState(pos).isSource()) {   // lahar yang masih disorot tetap cair
            Map<BlockPos, long[]> mm = MOLTEN.get(level);
            if (mm != null && mm.containsKey(pos)) {
                molten(level, pos);
            }
        } else if ((s.is(Blocks.GRASS_BLOCK) || s.is(Blocks.PODZOL) || s.is(Blocks.MYCELIUM)) && t >= 300f && t < 1100f) {
            level.setBlockAndUpdate(pos, Blocks.DIRT.defaultBlockState());   // 0.42 rumput hangus
        } else if (stoneLike(s) && t >= 1100f) {                        // batu memerah lalu jadi magma
            level.setBlockAndUpdate(pos, Blocks.MAGMA_BLOCK.defaultBlockState());
            melt(owner, pos);
        } else if (s.is(Blocks.TNT) && t >= 200f) {                     // TNT tersulut panas
            s.onCaughtFire(level, pos, face, owner);
            level.removeBlock(pos, false);
        } else if (t >= 300f && s.isFlammable(level, pos, face)) {      // benda mudah terbakar menyala
            BlockPos firePos = pos.relative(face);
            if (level.getBlockState(firePos).isAir()) {
                level.setBlockAndUpdate(firePos, BaseFireBlock.getState(level, firePos));
            }
            if (s.is(BlockTags.LEAVES) || s.is(BlockTags.WOOL_CARPETS) || s.is(BlockTags.FLOWERS) || s.canBeReplaced()) {
                level.removeBlock(pos, false);
            }
        }
    }

    private static boolean stoneLike(BlockState s) {
        return s.is(BlockTags.BASE_STONE_OVERWORLD) || s.is(Blocks.COBBLESTONE) || s.is(Blocks.NETHERRACK)
                || s.is(Blocks.BLACKSTONE) || s.is(Blocks.BASALT) || s.is(Blocks.SMOOTH_BASALT) || s.is(Blocks.MOSSY_COBBLESTONE)
                || s.is(BlockTags.DIRT) || s.is(Blocks.GRAVEL) || s.is(Blocks.CLAY) || s.is(BlockTags.TERRACOTTA)
                || s.is(Blocks.SANDSTONE) || s.is(Blocks.RED_SANDSTONE);   // 0.42: tanah & batu lain ikut meleleh
    }

    // ------------------------------------------------------------------ 0.42 lahar sementara

    /** Blok lahar dari sinar mata: {kapan berubah, tahap (0 = lahar, 1 = kerak magma)}. */
    private static final Map<Level, Map<BlockPos, long[]>> MOLTEN = new WeakHashMap<>();

    private static void molten(ServerLevel level, BlockPos pos) {
        MOLTEN.computeIfAbsent(level, k -> new HashMap<>()).put(pos.immutable(),
                new long[] {level.getGameTime() + LAVA_HOLD_TICKS, 0});
    }

    /**
     * Tiap tick server (ShazamEvents): lahar yang sudah nggak disorot membeku jadi kerak magma (berdesis & berasap), lalu
     * jadi basal. Jalan untuk semua dunia, jadi tetap membeku walau Lintang-nya sudah keluar.
     */
    public static void serverTick(MinecraftServer server) {
        if (MOLTEN.isEmpty()) {
            return;
        }
        for (ServerLevel level : server.getAllLevels()) {
            Map<BlockPos, long[]> m = MOLTEN.get(level);
            if (m == null || m.isEmpty()) {
                continue;
            }
            long now = level.getGameTime();
            m.entrySet().removeIf(en -> {
                long[] v = en.getValue();
                if (now < v[0]) {
                    return false;
                }
                BlockPos p = en.getKey();
                BlockState st = level.getBlockState(p);
                if (v[1] == 0) {
                    if (!st.is(Blocks.LAVA)) {
                        return true;   // sudah didinginkan napas beku / diambil ember
                    }
                    level.setBlockAndUpdate(p, Blocks.MAGMA_BLOCK.defaultBlockState());
                    level.levelEvent(1501, p, 0);   // desis lahar membeku + asap (efek vanila)
                    v[0] = now + CRUST_TICKS;
                    v[1] = 1;
                    return false;
                }
                if (st.is(Blocks.MAGMA_BLOCK)) {
                    level.setBlockAndUpdate(p, Blocks.BASALT.defaultBlockState());
                }
                return true;
            });
        }
    }

    /**
     * Panas q ke makhluk: menumpuk (dan mendingin), damage naik sesuai suhunya, mulai terbakar di IGNITE_TEMP.
     * Tahan api: menyerap 40%. Di air/hujan: air menyerap panasnya (uap).
     */
    public static void heatEntity(ServerPlayer owner, LivingEntity e, float q, float baseDamage) {
        heatEntity(owner, e, q, baseDamage, 0f);
    }

    /**
     * 0.42 igniteSeconds > 0: langsung terbakar begitu kena (sinar ribuan derajat), nggak menunggu panas tubuhnya menumpuk.
     * Yang basah tetap nggak menyala (panasnya jadi uap).
     */
    public static void heatEntity(ServerPlayer owner, LivingEntity e, float q, float baseDamage, float igniteSeconds) {
        long now = e.level().getGameTime();
        float[] h = BODY_HEAT.computeIfAbsent(e, k -> new float[] {AMBIENT, now});
        boolean wet = e.isInWaterRainOrBubble();
        float absorb = (e.hasEffect(MobEffects.FIRE_RESISTANCE) ? 0.4f : 1f) * (wet ? 0.35f : 1f);
        float t = Math.min(1500f, cooled(h, now) + q * absorb);
        h[0] = t;
        float k = Mth.clamp((t - AMBIENT) / (IGNITE_TEMP - AMBIENT), 0f, 1.6f);
        e.invulnerableTime = 0;
        e.hurt(ShazamPowers.forceSource(owner), baseDamage * (0.35f + 0.65f * k));
        if (!wet && (igniteSeconds > 0f || t >= IGNITE_TEMP)) {
            e.igniteForSeconds(Math.max(igniteSeconds, Math.min(8f, 2f + Math.max(0f, t - IGNITE_TEMP) / 100f)));
        }
        if (wet) {
            ShazamNetwork.playAnim(owner, ShazamAnim.LINTANG_STEAM, e.position().add(0, e.getBbHeight() * 0.6, 0));
        }
    }

    // ------------------------------------------------------------------ dingin (napas beku)

    /** Menyedot panas dari blok ini (napas beku): air membeku, lava memadat, api padam, magma mendingin, embun jadi salju. */
    public static void chill(ServerPlayer owner, ServerLevel level, BlockPos pos) {
        Map<BlockPos, float[]> m = HEAT.get(level);
        if (m != null) {
            m.remove(pos);
        }
        if (!BLOCK_CHANGES || !canChange(owner, level, pos)) {
            return;
        }
        BlockState s = level.getBlockState(pos);
        if (s.is(Blocks.WATER) && level.getFluidState(pos).isSource() && level.getBlockState(pos.above()).isAir()) {
            level.setBlockAndUpdate(pos, Blocks.FROSTED_ICE.defaultBlockState());
        } else if (s.is(Blocks.LAVA)) {                                // lava didinginkan mendadak
            level.setBlockAndUpdate(pos, level.getFluidState(pos).isSource() ? Blocks.OBSIDIAN.defaultBlockState()
                    : Blocks.COBBLESTONE.defaultBlockState());
            steam(owner, level, pos);
        } else if (s.getBlock() instanceof BaseFireBlock) {
            level.removeBlock(pos, false);
        } else if (s.is(Blocks.MAGMA_BLOCK)) {
            level.setBlockAndUpdate(pos, Blocks.NETHERRACK.defaultBlockState());
            steam(owner, level, pos);
        } else if (!level.dimensionType().ultraWarm() && s.isFaceSturdy(level, pos, Direction.UP)
                && level.getBlockState(pos.above()).isAir() && Blocks.SNOW.defaultBlockState().canSurvive(level, pos.above())) {
            level.setBlockAndUpdate(pos.above(), Blocks.SNOW.defaultBlockState());   // uap air di udara mengendap jadi salju
        }
    }

    // ------------------------------------------------------------------ energi matahari

    /**
     * 0..1: sinar matahari yang sampai ke Lintang = sinus ketinggian matahari (tengah hari 1, fajar/senja 0) x cuaca,
     * nol di Nether/End, malam, atau tanpa langit terbuka.
     */
    public static float solarIrradiance(ServerPlayer p) {
        Level level = p.level();
        if (level.dimensionType().hasFixedTime() || !level.canSeeSky(p.blockPosition().above())) {
            return 0f;
        }
        float elevation = Mth.cos(level.getTimeOfDay(1f) * (float) (Math.PI * 2.0));
        if (elevation <= 0f) {
            return 0f;
        }
        float weather = level.isThundering() ? 0.3f : level.isRaining() ? 0.55f : 1f;
        return elevation * weather;
    }

    // ------------------------------------------------------------------ bantu

    public static boolean isGlass(BlockState s) {
        return s.is(Tags.Blocks.GLASS_BLOCKS) || s.is(Tags.Blocks.GLASS_PANES);
    }

    public static boolean canChange(ServerPlayer owner, ServerLevel level, BlockPos pos) {
        BlockState s = level.getBlockState(pos);
        return owner.mayBuild() && level.mayInteract(owner, pos) && !s.hasBlockEntity() && s.getDestroySpeed(level, pos) >= 0f
                && !s.is(Blocks.OBSIDIAN) && !s.is(Blocks.CRYING_OBSIDIAN);
    }

    private static void shatter(ServerPlayer owner, ServerLevel level, BlockPos p) {
        shatter(owner, level, p, null);
    }

    private static void shatter(ServerPlayer owner, ServerLevel level, BlockPos p, Wave w) {
        level.destroyBlock(p, false, owner);
        if (w == null || w.shards++ < 6) {   // efek pecahan dibatasi supaya paketnya nggak banjir
            ShazamNetwork.playAnim(owner, ShazamAnim.LINTANG_SHATTER, Vec3.atCenterOf(p));
            level.playSound(null, p, SoundEvents.GLASS_BREAK, SoundSource.BLOCKS, 1.0f, 0.8f + level.random.nextFloat() * 0.4f);
        }
    }

    private static void steam(ServerPlayer owner, ServerLevel level, BlockPos p) {
        ShazamNetwork.playAnim(owner, ShazamAnim.LINTANG_STEAM, Vec3.atCenterOf(p));
        level.playSound(null, p, SoundEvents.FIRE_EXTINGUISH, SoundSource.BLOCKS, 0.7f, 1.2f + level.random.nextFloat() * 0.3f);
    }

    private static void melt(ServerPlayer owner, BlockPos p) {
        ShazamNetwork.playAnim(owner, ShazamAnim.LINTANG_MELT, Vec3.atCenterOf(p));
    }

    /** Sinar mata menembus kaca (bening) & berhenti di air (diserap). Mengembalikan titik kena (atau MISS). */
    public static net.minecraft.world.phys.BlockHitResult beamClip(ServerPlayer owner, Vec3 from, Vec3 dir, double range,
                                                                   float[] power) {
        Level level = owner.level();
        Vec3 end = from.add(dir.scale(range));
        Vec3 start = from;
        net.minecraft.world.phys.BlockHitResult hit = null;
        for (int layer = 0; layer < 5; layer++) {
            hit = level.clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.SOURCE_ONLY, owner));
            if (hit.getType() == HitResult.Type.MISS || !isGlass(level.getBlockState(hit.getBlockPos()))) {
                return hit;
            }
            power[0] *= 0.82f;   // tiap lapis kaca menyerap sedikit
            BlockPos glass = hit.getBlockPos();
            Vec3 q = hit.getLocation();
            for (int i = 0; i < 8 && BlockPos.containing(q).equals(glass); i++) {
                q = q.add(dir.scale(0.2));
            }
            start = q;
        }
        return hit;
    }

    // ------------------------------------------------------------------ tiap tick

    public static void tick(ServerPlayer owner) {
        long now = owner.level().getGameTime();
        tickBodies(owner, now);
        tickWaves(owner, now);
    }

    public static void forget(UUID id) {
        WAVES.removeIf(w -> w.owner.equals(id));
        BODIES.values().removeIf(b -> b.owner.equals(id));
    }
}
