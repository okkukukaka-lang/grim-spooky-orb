package com.shazammod;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/**
 * Kelemahan Lintang di Nether: nggak ada radiasi matahari, jadi sel surya "kelaparan".
 * (Kelemahan karena Batu Cryon sendiri sudah ditangani LintangSkills: daya x0.5, lambat, nggak bisa terbang.)
 */
@EventBusSubscriber(modid = "shazammod")
public final class LintangScience {
    public static final float NETHER_PUNCH = 0.7f;
    public static final float NETHER_TAKEN = 1.35f;
    public static final float NETHER_DRAIN = 4.0f;
    private static final ResourceLocation NETHER_SLOW = ShazamMod.id("lintang_nether_slow");
    private static final Set<UUID> WEAK = new HashSet<>();

    private LintangScience() {
    }

    public static boolean netherWeak(Player p) {
        return PassiveConditions.inferno(p.level()) && ShazamPowers.isTransformed(p) && ShazamPowers.isLintang(p);
    }

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        try {
            if (!(event.getEntity() instanceof ServerPlayer p)) return;
            UUID id = p.getUUID();
            AttributeInstance speed = p.getAttribute(Attributes.MOVEMENT_SPEED);
            if (netherWeak(p)) {
                if (WEAK.add(id)) {
                    p.displayClientMessage(Component.translatable("message.shazammod.lintang_nether").withStyle(ChatFormatting.RED), true);
                }
                if (speed != null && !speed.hasModifier(NETHER_SLOW)) {
                    speed.addTransientModifier(new AttributeModifier(NETHER_SLOW, -0.15, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
                }
                if (p.tickCount % 20 == 0) {
                    ShazamData d = ShazamPowers.data(p);
                    if (d.energy() > 0f) ShazamPowers.setData(p, d.withEnergy(Math.max(0f, d.energy() - NETHER_DRAIN)));
                }
            } else if (WEAK.remove(id)) {
                if (speed != null) speed.removeModifier(NETHER_SLOW);
            }
        } catch (Throwable ignored) {
        }
    }

    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        try {
            Entity src = event.getSource().getEntity();
            if (src instanceof ServerPlayer a && a != event.getEntity() && netherWeak(a)) {
                event.setAmount(event.getAmount() * NETHER_PUNCH);
            }
            if (event.getEntity() instanceof ServerPlayer v && netherWeak(v)) {
                event.setAmount(event.getAmount() * NETHER_TAKEN);
            }
        } catch (Throwable ignored) {
        }
    }
}
