package com.shazammod;

import net.minecraft.ChatFormatting;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * 0.43 Barang Projek Helion-6:
 * - Serum Helion-6 (helion6_serum): serum Cryon. Resep: 6 Pecahan Cryon, mata laba-laba terfermentasi (mutagen), Nether
 *   Star, dan botol kaca (data/shazammod/recipe/helion6_serum.json). Klik kanan dalam wujud manusia di tempat gelap (jauh
 *   dari matahari) untuk Eksperimen Proyek Helion-6 (lihat HelionRite).
 * Pecahan Cryon untuk Hirup Cryon (tombol M) memakai barang Lintang yang sudah ada (LintangItems.KELAM_SHARD).
 */
@EventBusSubscriber(modid = ShazamMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public final class HelionItems {
    private HelionItems() {}

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(ShazamMod.MODID);

    public static final DeferredItem<SerumItem> SERUM = ITEMS.register("helion6_serum",
            () -> new SerumItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));

    @SubscribeEvent
    public static void addToCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            event.accept(SERUM.get());
        }
    }

    /** Serum Helion-6: klik kanan dalam wujud manusia, jauh dari sinar matahari, untuk Eksperimen Proyek Helion-6. */
    public static class SerumItem extends LintangItems.LoreItem {
        public SerumItem(Item.Properties properties) {
            super(properties, "item.shazammod.helion6_serum", ChatFormatting.GREEN, true);
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            if (player instanceof ServerPlayer serverPlayer) {
                HelionRite.tryBegin(serverPlayer);
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
        }
    }
}
