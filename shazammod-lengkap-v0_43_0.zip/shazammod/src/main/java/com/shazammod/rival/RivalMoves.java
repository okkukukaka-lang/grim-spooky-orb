package com.shazammod.rival;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import com.shazammod.AdamSkills;
import com.shazammod.DemonSoldier;
import com.shazammod.SabbacSkills;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamForm;
import com.shazammod.ShazamSkills;
import com.shazammod.ShazamSounds;

import net.minecraft.core.Holder;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * 0.30 Skill Rival Juara: skill yang SAMA dengan milik pemain (gerakan, efek, suara, waktu ancang-ancang, dan mekaniknya),
 * dipakai AI sesuai jarak & keadaan. Bedanya cuma sasaran (juara & sekutunya, bukan monster) dan angka damage-nya yang
 * dikali {@link #SKILL_DAMAGE} supaya duel juara lawan juara seimbang. Damage-nya kekuatan juara (menembus tahan banting
 * juara, lihat RivalChampion.clash).
 *
 * Shazam     : Kebijaksanaan Solomon, Tepukan Guntur Hercules, Beban Langit Atlas, Petir Berantai Zeus, Perisai Achilles,
 *              rentetan Mode Kilat Mercury, Badai Para Dewa; pasif Penangkal Petir Hidup, Refleks Mercury, Pukulan Guntur.
 * Black Adam : Pusaran Shu, Sambaran Heru, Tinju Amon, Segel Zehuti, Sinar Aton, Lilitan Mehen, Murka Kahndaq, Panggil
 *              Petir Kahndaq; pasif Cakram Aton, Tangkisan Kahndaq, kulit yang memantulkan proyektil, Tinju Aton.
 * Sabbac     : Tanduk Setan, Tubuh Aym, Rantai Belial, Napas Beelzebub, Teror Asmodeus, Kepakan Crateis, Gerbang Neraka,
 *              Panggil Petir Neraka, Pasukan Iblis; pasif Api Neraka, Kulit Bara, Tinju Neraka.
 */
final class RivalMoves {
    // ======= Angka yang gampang diutak-atik =======
    /** Damage skill rival = angka skill pemain x ini (kekuatan juara menembus tahan banting, jadi jauh lebih terasa). */
    static final float SKILL_DAMAGE = 0.6f;
    /** Jeda minimal antar-skill (tick), plus acak sampai SKILL_GAP_RANDOM. */
    private static final int SKILL_GAP = 46;
    private static final int SKILL_GAP_RANDOM = 30;
    /** Cooldown skill rival paling cepat segini (beberapa skill pemain cuma 3-4 detik). */
    private static final int MIN_COOLDOWN = 110;
    private static final float CHARGED_PUNCH = 1.75f;
    private static final float CHAIN_DAMAGE = 14f;
    // =========================================================================

    private static final List<Holder<MobEffect>> DEBUFFS = List.of(
            MobEffects.MOVEMENT_SLOWDOWN, MobEffects.WEAKNESS, MobEffects.BLINDNESS, MobEffects.DARKNESS,
            MobEffects.DIG_SLOWDOWN, MobEffects.CONFUSION, MobEffects.POISON, MobEffects.WITHER);

    private final RivalChampion r;
    private final long[] readyAt = new long[9];
    private long nextSkill;
    private long busyUntil;
    private long rageUntil;
    private int rageStep;
    private long shieldUntil;        // Perisai Achilles / Lilitan Mehen / Tubuh Aym
    private float shieldStored;
    private long courageUntil;       // Teror Asmodeus
    private UUID marked;             // Solomon (terbaca) / Zehuti (tersegel) / Belial (terbelenggu)
    private long markedUntil;
    private long retaliateReady;

    RivalMoves(RivalChampion rival) {
        this.r = rival;
    }

    private long now() {
        return r.level().getGameTime();
    }

    private ShazamForm form() {
        return r.form();
    }

    void reset() {
        rageUntil = 0;
        shieldUntil = 0;
        courageUntil = 0;
        busyUntil = 0;
        r.setFlag(RivalChampion.RAGE, false);
        r.setFlag(RivalChampion.MERCURY, false);
        AttributeInstance size = r.getAttribute(Attributes.SCALE);
        if (size != null) {
            size.removeModifier(HELLGATE_SIZE);
        }
    }

    void startFight() {
        nextSkill = now() + 40;
    }

    boolean busy() {
        return now() < busyUntil;
    }

    private void busyFor(int ticks) {
        busyUntil = Math.max(busyUntil, now() + ticks);
    }

    // ------------------------------------------------------------------ pengali

    /** Damage dari rival ke sasaran yang terbaca / tersegel / terbelenggu: +25%. Juga Teror Asmodeus & amarah. */
    float damageBonus(LivingEntity target) {
        float k = 1f;
        if (marked != null && target.getUUID().equals(marked) && markedUntil > now()) {
            k *= 1.25f;
        }
        return k;
    }

    /**
     * Damage yang diterima rival (Perisai Achilles / Lilitan Mehen / Tubuh Aym / Gerbang Neraka / musuh terbaca). Yang
     * ditahan Perisai Achilles & Tubuh Aym disimpan untuk ledakan di akhirnya, sama seperti milik pemain.
     */
    float damageTakenMultiplier(DamageSource source, float amount) {
        float k = 1f;
        long now = now();
        if (shieldUntil > now && !source.is(DamageTypeTags.BYPASSES_RESISTANCE)) {
            float shield = switch (form()) {
                case BLACK_ADAM -> AdamSkills.MEHEN_DAMAGE_MULTIPLIER;
                case SABBAC -> SabbacSkills.AYM_DAMAGE_MULTIPLIER;
                default -> ShazamSkills.ACHILLES_DAMAGE_MULTIPLIER;
            };
            k *= shield;
            shieldStored += amount * (1f - shield);
            retaliate(source);
        }
        if (rageUntil > now && form() == ShazamForm.SABBAC) {
            k *= SabbacSkills.RAGE_DAMAGE_TAKEN;
        }
        if (form() == ShazamForm.SHAZAM && marked != null && markedUntil > now && source.getEntity() != null
                && source.getEntity().getUUID().equals(marked)) {
            k *= ShazamSkills.SOLOMON_FORESIGHT;   // gerakan musuh yang terbaca Solomon bisa diantisipasi
        }
        return k;
    }

    /** Pasif bertahan tiap 1,8 detik: Shazam menghindar, Black Adam menahan, Sabbac menelan. true = dibatalkan. */
    boolean defend(DamageSource source, boolean ready) {
        Entity attacker = source.getEntity();
        Entity direct = source.getDirectEntity();
        if (form() == ShazamForm.BLACK_ADAM && source.is(DamageTypeTags.IS_PROJECTILE)) {
            Vec3 at = direct != null ? direct.position() : r.getEyePosition();
            r.anim(ShazamAnim.ADAM_DEFLECT, at);
            r.sound(at, ShazamSounds.DEFLECT.get(), 1.0f, ShazamSounds.tune(1.5f));
            return true;   // kulit Kahndaq: proyektil memantul
        }
        if (!ready || (attacker == null && direct == null) || source.is(DamageTypeTags.IS_EXPLOSION)
                || shieldUntil > now()) {
            return false;
        }
        Entity from = direct != null ? direct : attacker;
        Vec3 chest = r.position().add(0, r.getBbHeight() * 0.6, 0);
        Vec3 toward = from.position().add(0, from.getBbHeight() * 0.6, 0).subtract(chest);
        Vec3 hit = toward.lengthSqr() < 1.0E-4 ? chest : chest.add(toward.normalize().scale(0.55));
        switch (form()) {
            case SHAZAM -> {   // Refleks Mercury: melesat ke samping secepat kilat
                Vec3 away = new Vec3(r.getX() - from.getX(), 0, r.getZ() - from.getZ());
                away = away.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : away.normalize();
                Vec3 side = new Vec3(-away.z, 0, away.x).scale(r.getRandom().nextBoolean() ? 1.0 : -1.0);
                r.anim(ShazamAnim.MERCURY_DODGE, r.position());
                Vec3 v = side.scale(1.15).add(away.scale(0.35));
                r.setDeltaMovement(v.x, 0.12, v.z);
                r.hurtMarked = true;
                r.sound(r.position(), ShazamSounds.MERCURY_BLINK.get(), 1.2f, 1f);
            }
            case BLACK_ADAM -> {   // Tangkisan Kahndaq: ditahan kulit, panas matahari menyembur balik
                r.anim(ShazamAnim.ADAM_BLOCK, hit);
                r.sound(hit, ShazamSounds.ADAM_BLOCK.get(), 1.4f, 1f);
                if (attacker instanceof LivingEntity foe) {
                    r.later(1, () -> {
                        if (foe.isAlive() && r.hit(foe, 10f * SKILL_DAMAGE)) {
                            foe.igniteForSeconds(3f);
                            push(foe, r.position(), 1.2, 0.3);
                        }
                    });
                }
            }
            default -> {   // Kulit Bara: ditelan bara, penyerangnya terseret mendekat & terbakar
                r.anim(ShazamAnim.SABBAC_ENGULF, hit);
                r.sound(hit, ShazamSounds.SABBAC_ENGULF.get(), 1.4f, 1f);
                if (attacker instanceof LivingEntity foe) {
                    r.later(1, () -> {
                        if (foe.isAlive() && r.hit(foe, 10f * SKILL_DAMAGE)) {
                            foe.igniteForSeconds(3f);
                            Vec3 pull = r.position().subtract(foe.position());
                            if (pull.lengthSqr() > 6.0) {
                                pull = pull.normalize();
                                foe.push(pull.x, 0.3, pull.z);
                                foe.hurtMarked = true;
                            }
                        }
                    });
                }
            }
        }
        return true;
    }

    /** Lilitan Mehen / Tubuh Aym: yang memukul dari dekat dipatuk / terbakar. */
    private void retaliate(DamageSource source) {
        if (form() == ShazamForm.SHAZAM || !(source.getEntity() instanceof LivingEntity foe) || now() < retaliateReady
                || foe.distanceToSqr(r) > 8.0 * 8.0) {
            return;
        }
        retaliateReady = now() + 10;
        r.later(1, () -> {
            if (!foe.isAlive()) {
                return;
            }
            if (form() == ShazamForm.BLACK_ADAM) {
                mehenBite(foe);
            } else if (r.hit(foe, 6f * SKILL_DAMAGE)) {
                foe.igniteForSeconds(4f);
                r.anim(ShazamAnim.SABBAC_ENGULF, foe.position().add(0, foe.getBbHeight() * 0.6, 0));
            }
        });
    }

    // ------------------------------------------------------------------ tinju & pasif

    /** Tinju rival: kekuatan juara, plus pukulan penuh muatan (Pukulan Guntur / Tinju Aton / Tinju Neraka). */
    void punch(LivingEntity target) {
        float damage = RivalChampion.PUNCH_DAMAGE;
        boolean rage = rageUntil > now();
        if (rage) {
            damage *= form() == ShazamForm.SHAZAM ? ShazamSkills.RAGE_PUNCH_MULTIPLIER
                    : form() == ShazamForm.BLACK_ADAM ? AdamSkills.RAGE_PUNCH_MULTIPLIER : SabbacSkills.RAGE_PUNCH_MULTIPLIER;
        }
        if (courageUntil > now()) {
            damage *= SabbacSkills.COURAGE_MULTIPLIER;
        }
        boolean charged = r.flag(RivalChampion.CHARGED);
        if (charged) {
            damage *= CHARGED_PUNCH;
            r.setFlag(RivalChampion.CHARGED, false);
        }
        Vec3 at = target.position().add(0, target.getBbHeight() * 0.6, 0);
        if (!r.hit(target, damage)) {
            return;
        }
        r.sound(at, ShazamSounds.PUNCH.get(), 1.2f, ShazamSounds.tune(0.8f));
        push(target, r.position(), charged ? 1.8 : 1.0, charged ? 0.55 : 0.3);
        switch (form()) {
            case BLACK_ADAM -> r.anim(ShazamAnim.ADAM_PUNCH, at);
            case SABBAC -> {
                r.anim(ShazamAnim.SABBAC_PUNCH, at);
                target.igniteForSeconds(2f);
            }
            default -> { }
        }
        if (charged) {
            chargedPunch(target, at);
        }
        if (rage) {
            ragePunch(target);
        }
    }

    private void chargedPunch(LivingEntity target, Vec3 at) {
        switch (form()) {
            case SHAZAM -> {
                r.anim(ShazamAnim.THUNDER_PUNCH, at);
                r.bolt(target.position(), 1.4f);
                r.sound(at, ShazamSounds.THUNDER_PUNCH.get(), 2.0f, 1f);
            }
            case BLACK_ADAM -> {
                r.anim(ShazamAnim.ADAM_SUNPUNCH, at);
                r.sound(at, ShazamSounds.ATON_PUNCH.get(), 2.0f, 1f);
                target.igniteForSeconds(4f);
            }
            default -> {
                r.anim(ShazamAnim.SABBAC_HELLPUNCH, at);
                r.sound(at, ShazamSounds.HELLFIRE_PUNCH.get(), 2.0f, 1f);
                target.igniteForSeconds(4f);
            }
        }
        List<LivingEntity> near = r.foes(target.position(), 7.0);
        near.remove(target);
        near.sort(Comparator.comparingDouble(m -> m.distanceToSqr(target)));
        for (int i = 0; i < Math.min(3, near.size()); i++) {
            LivingEntity m = near.get(i);
            if (form() == ShazamForm.SHAZAM) {
                strike(m.position(), CHAIN_DAMAGE * SKILL_DAMAGE, 0.9, 0.7f);
            } else if (r.hit(m, CHAIN_DAMAGE * SKILL_DAMAGE)) {
                m.igniteForSeconds(2f);
                if (form() == ShazamForm.SABBAC) {
                    r.anim(ShazamAnim.SABBAC_CHAIN_BIND, m.position());
                }
            }
        }
    }

    /** Pasif tiap 2 detik: Penangkal Petir Hidup / Cakram Aton / Api Neraka (energinya masuk tepat di ROD_DESCENT). */
    void pulse() {
        ShazamAnim anim = switch (form()) {
            case BLACK_ADAM -> ShazamAnim.ADAM_SUN;
            case SABBAC -> ShazamAnim.SABBAC_PULSE;
            default -> ShazamAnim.ROD_STRIKE;
        };
        var sound = switch (form()) {
            case BLACK_ADAM -> ShazamSounds.ATON_PULSE;
            case SABBAC -> ShazamSounds.HELLFIRE_PULSE;
            default -> ShazamSounds.ROD_STRIKE;
        };
        r.anim(anim, r.position());
        r.level().playSound(null, r, sound.get(), net.minecraft.sounds.SoundSource.HOSTILE, 1.5f, 1f);
        r.later(ShazamAnim.ROD_DESCENT, r::empower);
    }

    void passiveChanged(boolean on) {
        switch (form()) {
            case BLACK_ADAM -> {
                r.anim(on ? ShazamAnim.ADAM_SUN_RISE : ShazamAnim.ADAM_SUN_SET, r.position());
                r.level().playSound(null, r, (on ? ShazamSounds.ATON_RISE : ShazamSounds.ATON_SET).get(),
                        net.minecraft.sounds.SoundSource.HOSTILE, 1.3f, 1f);
            }
            case SABBAC -> {
                r.anim(on ? ShazamAnim.SABBAC_FIRE_IN : ShazamAnim.SABBAC_FIRE_OUT, r.position());
                r.level().playSound(null, r, (on ? ShazamSounds.HELLFIRE_IN : ShazamSounds.HELLFIRE_OUT).get(),
                        net.minecraft.sounds.SoundSource.HOSTILE, 1.3f, 1f);
            }
            default -> {
                if (!on) {
                    r.anim(ShazamAnim.ROD_FADE, r.position());
                    r.level().playSound(null, r, ShazamSounds.ROD_FADE.get(), net.minecraft.sounds.SoundSource.HOSTILE,
                            1.2f, 1f);
                }
            }
        }
    }

    // ------------------------------------------------------------------ memilih skill

    void tick(LivingEntity target) {
        long now = now();
        if (rageUntil > 0) {
            if (now >= rageUntil) {
                endRage();
            } else if ((rageUntil - now) % 20 == 0) {
                rageStorm();
            }
        }
        if (shieldUntil > 0 && now >= shieldUntil) {
            shieldUntil = 0;
            shieldEnd();
        }
        if (busy() || now < nextSkill || target == null) {
            return;
        }
        int slot = choose(target);
        if (slot < 0) {
            nextSkill = now + 10;
            return;
        }
        if (use(slot, target)) {
            int cooldown = switch (form()) {
                case BLACK_ADAM -> slot < 7 ? AdamSkills.Skill.values()[slot].cooldownTicks : AdamSkills.CALL_COOLDOWN_TICKS;
                case SABBAC -> slot < 7 ? SabbacSkills.Skill.values()[slot].cooldownTicks
                        : slot == 7 ? SabbacSkills.CALL_COOLDOWN_TICKS : SabbacSkills.LEGION_COOLDOWN_TICKS;
                default -> slot < 7 ? Math.max(ShazamSkills.Skill.values()[slot].cooldownTicks, 300) : 600;
            };
            readyAt[slot] = now + Math.max(MIN_COOLDOWN, cooldown);
            nextSkill = now + SKILL_GAP + r.getRandom().nextInt(SKILL_GAP_RANDOM);
        } else {
            readyAt[slot] = now + 40;
            nextSkill = now + 10;
        }
    }

    /** Pilih skill yang siap dan cocok dengan keadaan (acak berbobot). -1 = nggak ada. */
    private int choose(LivingEntity target) {
        double d = Math.sqrt(r.distanceToSqr(target));
        boolean sight = r.hasLineOfSight(target);
        float hp = r.getHealth() / r.getMaxHealth();
        long now = now();
        int[] weight = new int[9];
        switch (form()) {
            case SHAZAM -> {
                weight[0] = sight && d < 32 && markedUntil < now ? 3 : 0;          // Solomon
                weight[1] = d < 7 ? 5 : 0;                                         // Tepukan Guntur
                weight[2] = d < 9 && r.onGround() ? 4 : 0;                         // Beban Langit
                weight[3] = sight && d < 30 ? 5 : 0;                               // Petir Berantai
                weight[4] = hp < 0.7f && shieldUntil < now ? 4 : 0;                // Perisai Achilles
                weight[5] = d < 18 && sight ? 3 : 0;                               // Mode Kilat
                weight[6] = hp < 0.85f && rageUntil < now ? 6 : 0;                 // Badai Para Dewa
            }
            case BLACK_ADAM -> {
                weight[0] = d < 8 ? 4 : 0;                                         // Pusaran Shu
                weight[1] = d > 4 && d < 18 && sight ? 5 : 0;                      // Sambaran Heru
                weight[2] = d < 14 && r.onGround() ? 4 : 0;                        // Tinju Amon
                weight[3] = sight && d < 16 && markedUntil < now ? 3 : 0;          // Segel Zehuti
                weight[4] = sight && d < 22 ? 5 : 0;                               // Sinar Aton
                weight[5] = (hp < 0.75f || d < 5) && shieldUntil < now ? 3 : 0;    // Lilitan Mehen
                weight[6] = hp < 0.85f && rageUntil < now ? 6 : 0;                 // Murka Kahndaq
                weight[7] = hp < 0.5f ? 6 : 0;                                     // Panggil Petir Kahndaq
            }
            default -> {
                weight[0] = d > 3 && d < 14 && sight ? 5 : 0;                      // Tanduk Setan
                weight[1] = hp < 0.75f && shieldUntil < now ? 4 : 0;               // Tubuh Aym
                weight[2] = sight && d < 16 && markedUntil < now ? 4 : 0;          // Rantai Belial
                weight[3] = sight && d < 10 ? 5 : 0;                               // Napas Beelzebub
                weight[4] = d < 12 && courageUntil < now ? 3 : 0;                  // Teror Asmodeus
                weight[5] = d < 6 ? 3 : 0;                                         // Kepakan Crateis
                weight[6] = hp < 0.85f && rageUntil < now ? 6 : 0;                 // Gerbang Neraka
                weight[7] = hp < 0.5f ? 6 : 0;                                     // Panggil Petir Neraka
                weight[8] = d < 24 && legionGone() ? 3 : 0;                        // Pasukan Iblis
            }
        }
        int total = 0;
        for (int i = 0; i < weight.length; i++) {
            if (readyAt[i] > now) {
                weight[i] = 0;
            }
            total += weight[i];
        }
        if (total <= 0) {
            return -1;
        }
        int roll = r.getRandom().nextInt(total);
        for (int i = 0; i < weight.length; i++) {
            roll -= weight[i];
            if (roll < 0) {
                return i;
            }
        }
        return -1;
    }

    private boolean legionGone() {
        return r.level().getEntitiesOfClass(DemonSoldier.class, r.getBoundingBox().inflate(48.0),
                s -> s.isAlive() && !s.isAlly() && r.getUUID().equals(s.owner())).isEmpty();
    }

    private boolean use(int slot, LivingEntity target) {
        return switch (form()) {
            case SHAZAM -> switch (slot) {
                case 0 -> solomon(target);
                case 1 -> hercules();
                case 2 -> atlas();
                case 3 -> zeus(target);
                case 4 -> achilles();
                case 5 -> mercury(target);
                case 6 -> stormOfGods();
                default -> false;
            };
            case BLACK_ADAM -> switch (slot) {
                case 0 -> shu();
                case 1 -> heru(target);
                case 2 -> amon(target);
                case 3 -> zehuti(target);
                case 4 -> aton(target);
                case 5 -> mehen();
                case 6 -> wrath();
                case 7 -> adamCall();
                default -> false;
            };
            default -> switch (slot) {
                case 0 -> horns(target);
                case 1 -> aym();
                case 2 -> belial(target);
                case 3 -> breath(target);
                case 4 -> terror();
                case 5 -> wings();
                case 6 -> hellgate();
                case 7 -> sabbacCall();
                case 8 -> legion();
                default -> false;
            };
        };
    }

    // ------------------------------------------------------------------ alat bantu

    private static Vec3 chest(LivingEntity e) {
        return e.position().add(0, e.getBbHeight() * 0.6, 0);
    }

    private static void push(LivingEntity target, Vec3 from, double strength, double up) {
        Vec3 away = new Vec3(target.getX() - from.x, 0, target.getZ() - from.z);
        away = away.lengthSqr() < 1.0E-4 ? Vec3.ZERO : away.normalize();
        target.push(away.x * strength, up, away.z * strength);
        target.hurtMarked = true;
    }

    private Vec3 flatLook() {
        Vec3 look = r.getViewVector(1f);
        Vec3 flat = new Vec3(look.x, 0, look.z);
        if (flat.lengthSqr() < 1.0E-4) {
            float yaw = r.getYRot() * Mth.DEG_TO_RAD;
            flat = new Vec3(-Mth.sin(yaw), 0, Mth.cos(yaw));
        }
        return flat.normalize();
    }

    private Vec3 flatTo(LivingEntity target) {
        Vec3 to = new Vec3(target.getX() - r.getX(), 0, target.getZ() - r.getZ());
        return to.lengthSqr() < 1.0E-4 ? flatLook() : to.normalize();
    }

    /** Petir sihir juara di titik ini: guntur + damage ke lawan dalam radius. */
    private void strike(Vec3 pos, float damage, double radius, float size) {
        r.bolt(pos, size);
        r.sound(pos, ShazamSounds.THUNDER.get(), 2.0f + size, ShazamSounds.tune(0.8f));
        r.sound(pos, ShazamSounds.LIGHTNING_STRIKE.get(), 1.6f, ShazamSounds.tune(0.6f));
        for (LivingEntity foe : r.foes(pos, radius)) {
            if (r.hit(foe, damage) && form() == ShazamForm.SABBAC) {
                foe.igniteForSeconds(3f);
            }
        }
    }

    private void mark(LivingEntity target, int ticks) {
        marked = target.getUUID();
        markedUntil = now() + ticks;
        target.addEffect(new MobEffectInstance(MobEffects.GLOWING, ticks, 0, false, false));
    }

    /** Lintasan terjangan: dari posisi rival ke arah dir sejauh range, berhenti sebelum tembok. */
    private Vec3 dashEnd(Vec3 dir, double range) {
        Vec3 start = r.position();
        Vec3 from = start.add(0, 1.0, 0);
        BlockHitResult hit = r.level().clip(new ClipContext(from, from.add(dir.scale(range)), ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, r));
        double distance = hit.getType() == HitResult.Type.MISS ? range : hit.getLocation().distanceTo(from) - 0.9;
        Vec3 end = start.add(dir.scale(distance));
        while (distance >= 2.0 && !r.level().noCollision(r, r.getBoundingBox().move(end.subtract(start)))) {
            distance -= 0.5;
            end = start.add(dir.scale(distance));
        }
        return distance < 2.0 ? null : end;
    }

    /** Gerakkan rival lurus dari start ke end selama ticks tick (cepat di awal, mengerem di ujung); onStep tiap tick. */
    private void dash(Vec3 start, Vec3 end, int ticks, RivalChampion.Step onStep, Runnable onEnd) {
        r.getNavigation().stop();
        r.setNoGravity(true);
        r.channel(ticks, k -> {
            double u = (k + 1) / (double) ticks;
            double e = 1.0 - Math.pow(1.0 - Math.min(1.0, u), 2.2);
            Vec3 want = start.lerp(end, e);
            r.setDeltaMovement(want.subtract(r.position()));
            r.hurtMarked = true;
            onStep.run(k);
        }, () -> {
            r.setNoGravity(r.flag(RivalChampion.FLYING));
            r.setDeltaMovement(end.subtract(start).normalize().scale(0.2));
            if (onEnd != null) {
                onEnd.run();
            }
        });
    }

    // ================================================================== SHAZAM

    private boolean solomon(LivingEntity target) {
        r.anim(ShazamAnim.SOLOMON_SIGHT);
        r.sound(r.position(), ShazamSounds.SOLOMON_CAST.get(), 1.4f, 1f);
        busyFor(ShazamAnim.CAST_WINDUP + 4);
        r.later(ShazamAnim.CAST_WINDUP, () -> {
            for (LivingEntity foe : r.foes(r.position(), 48.0)) {
                List<Holder<MobEffect>> remove = new ArrayList<>();
                for (MobEffectInstance effect : foe.getActiveEffects()) {
                    if (effect.getEffect().value().isBeneficial()) {
                        remove.add(effect.getEffect());
                    }
                }
                for (Holder<MobEffect> effect : remove) {
                    foe.removeEffect(effect);
                }
            }
            mark(target, ShazamAnim.SOLOMON_TICKS);
            r.sound(r.position(), ShazamSounds.SOLOMON_SIGHT.get(), 2f, 1f);
        });
        return true;
    }

    private boolean hercules() {
        r.anim(ShazamAnim.HERCULES_CLAP);
        r.sound(r.position(), ShazamSounds.HERCULES_WINDUP.get(), 1.2f, 1f);
        busyFor(ShazamAnim.CAST_WINDUP + 6);
        r.later(ShazamAnim.CAST_WINDUP, () -> {
            Vec3 eye = r.getEyePosition();
            Vec3 look = r.getViewVector(1f);
            for (LivingEntity foe : r.foes(r.position(), 9.0)) {
                Vec3 to = foe.position().add(0, foe.getBbHeight() * 0.5, 0).subtract(eye);
                double d = to.length();
                if (d < 0.01 || to.normalize().dot(look) < 0.5) {
                    continue;
                }
                float falloff = (float) (1.0 - d / 9.0 * 0.5);
                if (r.hit(foe, 20f * SKILL_DAMAGE * falloff)) {
                    Vec3 push = new Vec3(to.x, 0, to.z).normalize().scale(2.4 * falloff);
                    foe.push(push.x, 0.35, push.z);
                    foe.hurtMarked = true;
                    foe.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 50, 2));
                    foe.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 50, 0));
                }
            }
            for (Projectile p : r.level().getEntitiesOfClass(Projectile.class, r.getBoundingBox().inflate(11.0),
                    p -> p.isAlive() && p.getOwner() != r)) {
                Vec3 to = p.position().subtract(eye);
                if (to.lengthSqr() > 0.01 && to.normalize().dot(look) >= 0.5) {
                    p.discard();
                }
            }
            r.sound(r.position(), ShazamSounds.HERCULES_CLAP.get(), 2.0f, 1f);
        });
        return true;
    }

    private boolean atlas() {
        Vec3 c = r.position();
        r.anim(ShazamAnim.ATLAS_GROUND, c);
        r.anim(ShazamAnim.ATLAS_GLOBE, c);
        r.sound(c, ShazamSounds.ATLAS_WINDUP.get(), 2.0f, 1f);
        busyFor(ShazamAnim.ATLAS_HOLD + 6);
        r.getNavigation().stop();
        r.channel(ShazamAnim.ATLAS_HOLD, k -> {
            for (LivingEntity foe : r.foes(c, 10.0)) {
                double dx = c.x - foe.getX(), dz = c.z - foe.getZ();
                double d = Math.sqrt(dx * dx + dz * dz);
                double down = Math.min(foe.getDeltaMovement().y, 0.0) - 0.04;
                double speed = Math.min(0.32, d * 0.2);
                foe.setDeltaMovement(d < 1.2 ? 0 : dx / d * speed, down, d < 1.2 ? 0 : dz / d * speed);
                foe.hurtMarked = true;
            }
        }, () -> {
            r.anim(ShazamAnim.ATLAS_IMPACT);
            for (LivingEntity foe : r.foes(c, 10.0)) {
                if (foe.distanceToSqr(c) <= 6.5 * 6.5) {
                    if (r.hit(foe, 30f * SKILL_DAMAGE)) {
                        foe.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 3));
                        foe.setDeltaMovement(0, -0.8, 0);
                        foe.hurtMarked = true;
                    }
                } else if (r.hit(foe, 10f * SKILL_DAMAGE)) {
                    push(foe, c, 1.4, 0.45);
                }
            }
            r.sound(c, ShazamSounds.ATLAS_SLAM.get(), 2.5f, 1f);
        });
        return true;
    }

    private boolean zeus(LivingEntity target) {
        List<LivingEntity> chain = new ArrayList<>();
        chain.add(target);
        LivingEntity last = target;
        for (int i = 0; i < 5; i++) {
            LivingEntity next = null;
            double best = 7.0 * 7.0;
            for (LivingEntity m : r.foes(last.position(), 7.0)) {
                double d = m.distanceToSqr(last);
                if (!chain.contains(m) && d < best) {
                    best = d;
                    next = m;
                }
            }
            if (next == null) {
                break;
            }
            chain.add(next);
            last = next;
        }
        r.anim(ShazamAnim.ZEUS_CALL, chest(target));
        r.sound(r.position(), ShazamSounds.ZEUS_WINDUP.get(), 1.4f, 1f);
        busyFor(ShazamAnim.CAST_WINDUP + 6);
        for (int i = 0; i < chain.size(); i++) {
            LivingEntity foe = chain.get(i);
            int index = i;
            float damage = (20f * Math.max(0.25f, 1f - 0.15f * i) + (i == 0 ? 14f : 6f)) * SKILL_DAMAGE;
            r.later(ShazamAnim.CAST_WINDUP + i * ShazamAnim.ZEUS_HOP, () -> {
                if (!foe.isAlive()) {
                    return;
                }
                Vec3 at = chest(foe);
                r.anim(index == 0 ? ShazamAnim.ZEUS_CHAIN_START : ShazamAnim.ZEUS_CHAIN, at);
                r.bolt(foe.position(), index == 0 ? 1.6f : 1.05f);
                r.sound(at, index == 0 ? ShazamSounds.ZEUS_SPEAR.get() : ShazamSounds.LIGHTNING_STRIKE.get(), 2.0f, 1f);
                r.hit(foe, damage * (foe.isInWaterOrRain() ? 2f : 1f));
            });
        }
        return true;
    }

    private boolean achilles() {
        r.anim(ShazamAnim.ACHILLES_ROAR);
        r.sound(r.position(), ShazamSounds.ACHILLES_WINDUP.get(), 1.2f, 1f);
        busyFor(ShazamAnim.ROAR_WINDUP + 6);
        r.later(ShazamAnim.ROAR_WINDUP, () -> {
            shieldUntil = now() + ShazamAnim.ACHILLES_TICKS;
            shieldStored = 0f;
            for (LivingEntity foe : r.foes(r.position(), 6.0)) {
                push(foe, r.position(), 1.4, 0.3);
                foe.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 120, 1));
            }
            r.sound(r.position(), ShazamSounds.ACHILLES_WARCRY.get(), 2.0f, 1f);
        });
        return true;
    }

    /** Rentetan Mode Kilat Mercury: melesat mengitari sasaran dan memukul bertubi-tubi secepat kilat. */
    private boolean mercury(LivingEntity target) {
        r.anim(ShazamAnim.MERCURY_ON);
        r.setFlag(RivalChampion.MERCURY, true);
        int strikes = 6;
        int gap = 6;
        busyFor(6 + strikes * gap + 6);
        ShazamAnim[] moves = {ShazamAnim.MERCURY_JAB, ShazamAnim.MERCURY_CROSS, ShazamAnim.MERCURY_HOOK, ShazamAnim.MERCURY_KICK};
        for (int i = 0; i < strikes; i++) {
            int index = i;
            r.later(6 + i * gap, () -> {
                if (!target.isAlive() || r.distanceToSqr(target) > 30 * 30) {
                    return;
                }
                double angle = r.getRandom().nextDouble() * Math.PI * 2.0;
                Vec3 spot = target.position().add(Math.cos(angle) * 1.6, 0, Math.sin(angle) * 1.6);
                if (r.level().noCollision(r, r.getBoundingBox().move(spot.subtract(r.position())))) {
                    r.teleportTo(spot.x, spot.y, spot.z);
                }
                r.face(target);
                Vec3 at = chest(target);
                r.anim(moves[index % moves.length], at);
                r.hit(target, 9f * SKILL_DAMAGE);
                r.sound(at, ShazamSounds.PUNCH.get(), 1.0f, ShazamSounds.tune(1.2f));
            });
        }
        r.later(6 + strikes * gap + 2, () -> {
            r.setFlag(RivalChampion.MERCURY, false);
            r.anim(ShazamAnim.MERCURY_OFF);
        });
        return true;
    }

    private boolean stormOfGods() {
        r.anim(ShazamAnim.ZEUS_RAGE);
        r.sound(r.position(), ShazamSounds.STORM_WINDUP.get(), 1.6f, 1f);
        busyFor(ShazamAnim.RAGE_WINDUP + 4);
        r.later(ShazamAnim.RAGE_WINDUP, () -> {
            rageUntil = now() + ShazamAnim.RAGE_TICKS;
            rageStep = 0;
            r.setFlag(RivalChampion.RAGE, true);
            Vec3 c = r.position();
            strike(c, 12f * SKILL_DAMAGE, 5.0, 1.6f);
            for (int i = 0; i < 6; i++) {
                double angle = Math.PI * 2.0 * i / 6.0;
                r.bolt(c.add(Math.cos(angle) * 3.8, 0, Math.sin(angle) * 3.8), 0.8f);
            }
            r.sound(c, ShazamSounds.STORM_GODS.get(), 2.5f, 1f);
        });
        return true;
    }

    private void godStrike(int god, LivingEntity foe) {
        r.anim(ShazamAnim.godStrike(god), chest(foe));
        float[] damage = {8f, 16f, 14f, 14f, 18f, 9f};
        if (god == 3) {
            strike(foe.position(), damage[3] * SKILL_DAMAGE, 1.4, 1.0f);
            return;
        }
        if (!r.hit(foe, damage[god] * SKILL_DAMAGE)) {
            return;
        }
        switch (god) {
            case 0 -> mark(foe, 200);
            case 1 -> push(foe, r.position(), 1.8, 0.55);
            case 2 -> foe.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 3));
            case 4 -> foe.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 80, 1));
            default -> r.later(11, () -> r.hit(foe, damage[5] * SKILL_DAMAGE));
        }
        r.sound(foe.position(), ShazamSounds.PUNCH_CRIT.get(), 1.0f, ShazamSounds.tune(0.9f));
    }

    // ================================================================== BLACK ADAM

    private boolean shu() {
        r.anim(ShazamAnim.ADAM_SHU);
        r.sound(r.position(), ShazamSounds.WHOOSH.get(), 1.4f, ShazamSounds.tune(0.5f));
        busyFor(ShazamAnim.CAST_WINDUP + ShazamAnim.SHU_TICKS + 4);
        r.getNavigation().stop();
        r.later(ShazamAnim.CAST_WINDUP, () -> {
            r.healRival(30f);
            r.sound(r.position(), ShazamSounds.SHU_VORTEX.get(), 1.8f, 1f);
            r.channel(ShazamAnim.SHU_TICKS, k -> {
                Vec3 c = r.position();
                for (LivingEntity foe : r.foes(c, 9.0)) {
                    double dx = foe.getX() - c.x, dz = foe.getZ() - c.z;
                    double d = Math.max(1.0E-3, Math.sqrt(dx * dx + dz * dz));
                    double rx = dx / d, rz = dz / d;
                    double pull = Mth.clamp((3.2 - d) * 0.12, -0.5, 0.3);
                    double height = foe.getY() - c.y;
                    double vy = height < 2.6 ? 0.16 : (height > 3.4 ? -0.05 : 0.03);
                    foe.setDeltaMovement(-rz * 0.42 + rx * pull, vy, rx * 0.42 + rz * pull);
                    foe.hurtMarked = true;
                    foe.fallDistance = 0f;
                    if (k % 10 == 0) {
                        r.hit(foe, 3f * SKILL_DAMAGE);
                    }
                }
            }, () -> {
                Vec3 c = r.position();
                for (LivingEntity foe : r.foes(c, 10.0)) {
                    if (r.hit(foe, 16f * SKILL_DAMAGE)) {
                        push(foe, c, 2.1, 0.6);
                    }
                }
                r.sound(c, ShazamSounds.SHU_BURST.get(), 2.0f, 1f);
            });
        });
        return true;
    }

    private boolean heru(LivingEntity target) {
        Vec3 dir = chest(target).subtract(r.position().add(0, 1.0, 0));
        if (dir.lengthSqr() < 1.0E-4) {
            return false;
        }
        dir = dir.normalize();
        double range = Math.min(18.0, Math.sqrt(r.distanceToSqr(target)) + 3.0);
        Vec3 end = dashEnd(dir, range);
        if (end == null) {
            return false;
        }
        Vec3 start = r.position();
        r.anim(ShazamAnim.ADAM_HERU, end);
        r.sound(start, ShazamSounds.HERU_DIVE.get(), 1.8f, 1f);
        busyFor(ShazamAnim.HERU_WINDUP + ShazamAnim.HERU_TICKS + 4);
        r.getNavigation().stop();
        Set<UUID> hit = new HashSet<>();
        r.later(ShazamAnim.HERU_WINDUP, () -> dash(start, end, ShazamAnim.HERU_TICKS, k -> {
            for (LivingEntity foe : r.foes(r.position(), 2.6)) {
                if (hit.add(foe.getUUID()) && r.hit(foe, 24f * SKILL_DAMAGE)) {
                    push(foe, r.position(), 1.1, 0.45);
                    r.sound(foe.position(), ShazamSounds.PUNCH.get(), 1.0f, ShazamSounds.tune(0.7f));
                }
            }
        }, () -> {
            for (LivingEntity foe : r.foes(r.position(), 3.5)) {
                if (!hit.contains(foe.getUUID()) && r.hit(foe, 10f * SKILL_DAMAGE)) {
                    push(foe, r.position(), 0.9, 0.35);
                }
            }
            r.sound(r.position(), ShazamSounds.HERU_LAND.get(), 1.6f, 1f);
        }));
        return true;
    }

    private boolean amon(LivingEntity target) {
        if (!r.onGround()) {
            return false;
        }
        Vec3 dir = flatTo(target);
        Vec3 origin = r.position();
        r.anim(ShazamAnim.ADAM_AMON, origin.add(dir.scale(15.0)));
        r.sound(origin, ShazamSounds.AMON_WINDUP.get(), 1.6f, 1f);
        busyFor(ShazamAnim.AMON_WINDUP + ShazamAnim.AMON_SPREAD + 4);
        r.getNavigation().stop();
        Set<UUID> hit = new HashSet<>();
        r.later(ShazamAnim.AMON_WINDUP, () -> {
            r.sound(origin, ShazamSounds.AMON_QUAKE.get(), 2.4f, 1f);
            for (LivingEntity foe : r.foes(origin, 3.0)) {
                if (hit.add(foe.getUUID()) && r.hit(foe, 14f * SKILL_DAMAGE)) {
                    foe.push(0, 0.6, 0);
                    foe.hurtMarked = true;
                }
            }
            r.channel(ShazamAnim.AMON_SPREAD, k -> {
                double near = 15.0 * k / ShazamAnim.AMON_SPREAD, far = 15.0 * (k + 1) / ShazamAnim.AMON_SPREAD;
                for (LivingEntity foe : r.foes(origin.add(dir.scale((near + far) * 0.5)), 4.5)) {
                    Vec3 rel = foe.position().subtract(origin);
                    double along = rel.x * dir.x + rel.z * dir.z;
                    double side = Math.abs(rel.x * dir.z - rel.z * dir.x);
                    if (along < near - 0.5 || along > far + 0.5 || side > 2.2 + foe.getBbWidth() * 0.5
                            || Math.abs(rel.y) > 3.0 || !hit.add(foe.getUUID())) {
                        continue;
                    }
                    if (r.hit(foe, 30f * SKILL_DAMAGE)) {
                        foe.push(dir.x * 0.35, 0.95, dir.z * 0.35);
                        foe.hurtMarked = true;
                    }
                }
                r.sound(origin.add(dir.scale(far)), ShazamSounds.EARTH_CRACK.get(), 1.5f, ShazamSounds.tune(0.55f));
            }, null);
        });
        return true;
    }

    private boolean zehuti(LivingEntity target) {
        r.anim(ShazamAnim.ADAM_ZEHUTI);
        r.sound(r.position(), ShazamSounds.ZEHUTI_CAST.get(), 1.4f, 1f);
        busyFor(ShazamAnim.CAST_WINDUP + 4);
        r.later(ShazamAnim.CAST_WINDUP, () -> {
            if (!target.isAlive()) {
                return;
            }
            mark(target, 160);
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 2));
            target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 160, 0));
            r.hit(target, 6f * SKILL_DAMAGE);
            r.anim(ShazamAnim.ADAM_ZEHUTI_MARK, target.position());
            r.sound(r.position(), ShazamSounds.ZEHUTI_SEAL.get(), 2.0f, 1f);
        });
        return true;
    }

    private boolean aton(LivingEntity target) {
        List<LivingEntity> rays = new ArrayList<>();
        rays.add(target);
        for (LivingEntity foe : r.foes(r.position(), 22.0)) {
            if (foe != target && rays.size() < 6 && r.hasLineOfSight(foe)) {
                rays.add(foe);
            }
        }
        r.anim(ShazamAnim.ADAM_ATON);
        r.sound(r.position(), ShazamSounds.ATON_WINDUP.get(), 1.6f, 1f);
        busyFor(ShazamAnim.ATON_WINDUP + ShazamAnim.ATON_GAP * rays.size() + 4);
        for (int i = 0; i < rays.size(); i++) {
            LivingEntity foe = rays.get(i);
            r.later(ShazamAnim.ATON_WINDUP + i * ShazamAnim.ATON_GAP, () -> {
                if (!foe.isAlive()) {
                    return;
                }
                Vec3 at = foe.position().add(0, foe.getBbHeight() * 0.55, 0);
                r.anim(ShazamAnim.ADAM_ATON_RAY, at);
                if (r.hit(foe, 20f * SKILL_DAMAGE)) {
                    foe.igniteForSeconds(4f);
                }
                r.sound(at, ShazamSounds.ATON_RAY.get(), 1.6f, 1f);
            });
        }
        return true;
    }

    private boolean mehen() {
        r.anim(ShazamAnim.ADAM_MEHEN);
        r.sound(r.position(), ShazamSounds.MEHEN_RISE.get(), 1.6f, 1f);
        busyFor(ShazamAnim.MEHEN_WINDUP + 4);
        r.later(ShazamAnim.MEHEN_WINDUP, () -> {
            shieldUntil = now() + ShazamAnim.MEHEN_TICKS;
            r.sound(r.position(), ShazamSounds.MEHEN_COIL.get(), 2.0f, 1f);
            r.channel(ShazamAnim.MEHEN_TICKS, k -> {
                if (k % 20 == 19) {
                    List<LivingEntity> near = r.foes(r.position(), 7.0);
                    near.sort(Comparator.comparingDouble(m -> m.distanceToSqr(r)));
                    for (int i = 0; i < Math.min(2, near.size()); i++) {
                        mehenBite(near.get(i));
                    }
                }
                for (Holder<MobEffect> debuff : DEBUFFS) {
                    if (r.hasEffect(debuff)) {
                        r.removeEffect(debuff);
                    }
                }
            }, null);
        });
        return true;
    }

    private void mehenBite(LivingEntity foe) {
        Vec3 at = chest(foe);
        r.anim(ShazamAnim.ADAM_MEHEN_BITE, at);
        if (r.hit(foe, 14f * SKILL_DAMAGE)) {
            foe.addEffect(new MobEffectInstance(MobEffects.POISON, 60, 1));
            push(foe, r.position(), 0.6, 0.25);
        }
        r.sound(at, ShazamSounds.MEHEN_BITE.get(), 1.4f, 1f);
    }

    private boolean wrath() {
        r.anim(ShazamAnim.ADAM_RAGE);
        r.sound(r.position(), ShazamSounds.KAHNDAQ_WINDUP.get(), 1.8f, 1f);
        busyFor(ShazamAnim.ADAM_RAGE_WINDUP + 4);
        r.later(ShazamAnim.ADAM_RAGE_WINDUP, () -> {
            rageUntil = now() + ShazamAnim.RAGE_TICKS;
            r.setFlag(RivalChampion.RAGE, true);
            Vec3 c = r.position();
            strike(c, 14f * SKILL_DAMAGE, 6.0, 1.8f);
            for (LivingEntity foe : r.foes(c, 6.0)) {
                push(foe, c, 1.6, 0.5);
            }
            for (int i = 0; i < 5; i++) {
                double angle = Math.PI * 2.0 * i / 5.0;
                r.bolt(c.add(Math.cos(angle) * 3.5, 0, Math.sin(angle) * 3.5), 0.9f);
            }
            r.sound(c, ShazamSounds.KAHNDAQ_WRATH.get(), 2.5f, 1f);
        });
        return true;
    }

    private boolean adamCall() {
        r.anim(ShazamAnim.ADAM_CALL);
        r.sound(r.position(), ShazamSounds.CALL_WINDUP.get(), 2.0f, 1f);
        busyFor(ShazamAnim.ADAM_CALL_WINDUP + 6);
        r.later(ShazamAnim.ADAM_CALL_WINDUP, () -> {
            Vec3 c = r.position();
            r.bolt(c, 2.3f);
            r.sound(c, ShazamSounds.THUNDER.get(), 4.0f, ShazamSounds.tune(0.65f));
            r.healRival(120f);
            for (LivingEntity foe : r.foes(c, 6.5)) {
                if (r.hit(foe, 20f * SKILL_DAMAGE)) {
                    push(foe, c, 1.6, 0.55);
                }
            }
        });
        return true;
    }

    // ================================================================== SABBAC

    private boolean horns(LivingEntity target) {
        Vec3 dir = flatTo(target);
        double range = Math.min(14.0, Math.sqrt(r.distanceToSqr(target)) + 3.0);
        Vec3 end = dashEnd(dir, range);
        if (end == null) {
            return false;
        }
        Vec3 start = r.position();
        r.anim(ShazamAnim.SABBAC_HORNS, end);
        r.sound(start, ShazamSounds.HORNS_WINDUP.get(), 1.6f, 1f);
        busyFor(ShazamAnim.HORN_WINDUP + ShazamAnim.HORN_TICKS + 4);
        r.getNavigation().stop();
        Set<UUID> hit = new HashSet<>();
        r.later(ShazamAnim.HORN_WINDUP, () -> {
            r.sound(r.position(), ShazamSounds.HORNS_CHARGE.get(), 2.0f, 1f);
            dash(start, end, ShazamAnim.HORN_TICKS, k -> {
                for (LivingEntity foe : r.foes(r.position(), 2.4)) {
                    if (hit.add(foe.getUUID()) && r.hit(foe, 30f * SKILL_DAMAGE)) {
                        foe.igniteForSeconds(3f);
                        foe.setDeltaMovement(dir.x * 0.6, 1.2, dir.z * 0.6);   // dilempar tinggi oleh tanduk
                        foe.hurtMarked = true;
                        r.anim(ShazamAnim.SABBAC_GORE, chest(foe));
                    }
                }
            }, () -> {
                for (LivingEntity foe : r.foes(r.position(), 3.5)) {
                    if (!hit.contains(foe.getUUID()) && r.hit(foe, 10f * SKILL_DAMAGE)) {
                        push(foe, r.position(), 1.0, 0.4);
                    }
                }
                r.sound(r.position(), ShazamSounds.IMPACT.get(), 1.6f, ShazamSounds.tune(0.6f));
            });
        });
        return true;
    }

    private boolean aym() {
        r.anim(ShazamAnim.SABBAC_AYM);
        r.sound(r.position(), ShazamSounds.AYM_SHELL.get(), 1.6f, 1f);
        busyFor(ShazamAnim.AYM_WINDUP + 4);
        r.later(ShazamAnim.AYM_WINDUP, () -> {
            shieldUntil = now() + ShazamAnim.AYM_TICKS;
            shieldStored = 0f;
        });
        return true;
    }

    /** Perisai habis: Perisai Achilles -> Ledakan Keberanian, Tubuh Aym -> Letusan Aym (Lilitan Mehen cuma lepas). */
    private void shieldEnd() {
        if (form() == ShazamForm.BLACK_ADAM) {
            return;
        }
        float stored = shieldStored;
        shieldStored = 0f;
        boolean sabbac = form() == ShazamForm.SABBAC;
        float damage = Mth.clamp(12f + stored * (sabbac ? 2f : 2.5f), 12f, sabbac ? 80f : 90f) * SKILL_DAMAGE;
        r.anim(sabbac ? ShazamAnim.SABBAC_AYM_BURST : ShazamAnim.ACHILLES_NOVA);
        r.later(ShazamAnim.NOVA_WINDUP, () -> {
            Vec3 c = r.position();
            for (LivingEntity foe : r.foes(c, sabbac ? 7.0 : 7.5)) {
                if (r.hit(foe, damage)) {
                    push(foe, c, 1.7, 0.5);
                    if (sabbac) {
                        foe.igniteForSeconds(5f);
                    }
                }
            }
            r.sound(c, (sabbac ? ShazamSounds.AYM_BURST : ShazamSounds.COURAGE_NOVA).get(), 2.2f, 1f);
        });
    }

    private boolean belial(LivingEntity target) {
        r.anim(ShazamAnim.SABBAC_CHAINS);
        r.sound(r.position(), ShazamSounds.EARTH_CRACK.get(), 1.4f, ShazamSounds.tune(0.5f));
        busyFor(ShazamAnim.CHAIN_WINDUP + 6);
        List<LivingEntity> bound = new ArrayList<>();
        r.later(ShazamAnim.CHAIN_WINDUP, () -> {
            bound.add(target);
            for (LivingEntity foe : r.foes(r.position(), 16.0)) {
                if (foe != target && bound.size() < 4 && r.hasLineOfSight(foe)) {
                    bound.add(foe);
                }
            }
            for (LivingEntity foe : bound) {
                if (!foe.isAlive()) {
                    continue;
                }
                foe.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, ShazamAnim.CHAIN_PULL + 6, 4));
                r.hit(foe, 6f * SKILL_DAMAGE);
                r.anim(ShazamAnim.SABBAC_CHAIN_BIND, foe.position());
            }
            mark(target, 160);
            r.sound(r.position(), ShazamSounds.BELIAL_CHAINS.get(), 2.0f, 1f);
        });
        r.later(ShazamAnim.CHAIN_WINDUP + ShazamAnim.CHAIN_PULL, () -> {
            Vec3 front = r.position().add(flatLook().scale(2.5));
            for (LivingEntity foe : bound) {
                if (!foe.isAlive()) {
                    continue;
                }
                Vec3 to = front.subtract(foe.position());
                double d = to.length();
                if (d < 0.8) {
                    continue;
                }
                Vec3 v = to.normalize().scale(Math.min(1.35, d * 0.32));
                foe.setDeltaMovement(v.x, 0.32 + Math.max(0.0, v.y), v.z);
                foe.hurtMarked = true;
            }
            r.sound(r.position(), ShazamSounds.WHOOSH_HEAVY.get(), 1.4f, ShazamSounds.tune(0.6f));
        });
        return true;
    }

    private boolean breath(LivingEntity target) {
        r.anim(ShazamAnim.SABBAC_BREATH);
        r.sound(r.position(), ShazamSounds.BEELZEBUB_BREATH.get(), 2.0f, 1f);
        busyFor(ShazamAnim.BREATH_WINDUP + ShazamAnim.BREATH_TICKS + 4);
        r.getNavigation().stop();
        r.later(ShazamAnim.BREATH_WINDUP, () -> r.channel(ShazamAnim.BREATH_TICKS, k -> {
            if (target.isAlive()) {
                r.face(target);
            }
            if (k % 4 != 0) {
                return;
            }
            Vec3 mouth = r.getEyePosition().add(0, -0.15, 0);
            Vec3 look = target.isAlive() ? chest(target).subtract(mouth).normalize() : r.getViewVector(1f);
            for (LivingEntity foe : r.foes(mouth, 12.0)) {
                Vec3 to = chest(foe).subtract(mouth);
                if (to.lengthSqr() < 1.0E-4 || to.normalize().dot(look) < 0.82 || !r.hasLineOfSight(foe)) {
                    continue;
                }
                if (r.hit(foe, 5f * SKILL_DAMAGE)) {
                    foe.igniteForSeconds(5f);
                }
            }
        }, null));
        return true;
    }

    private boolean terror() {
        r.anim(ShazamAnim.SABBAC_ROAR);
        r.sound(r.position(), ShazamSounds.HELLGATE_WINDUP.get(), 1.0f, ShazamSounds.tune(1.3f));
        busyFor(ShazamAnim.TERROR_WINDUP + 6);
        r.later(ShazamAnim.TERROR_WINDUP, () -> {
            Vec3 c = r.position();
            for (LivingEntity foe : r.foes(c, 14.0)) {
                if (r.hit(foe, 8f * SKILL_DAMAGE)) {
                    foe.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 1));
                    foe.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 1));
                    push(foe, c, 1.2, 0.35);
                }
            }
            courageUntil = now() + 160;
            for (Holder<MobEffect> debuff : DEBUFFS) {
                if (r.hasEffect(debuff)) {
                    r.removeEffect(debuff);
                }
            }
            r.sound(c, ShazamSounds.ASMODEUS_ROAR.get(), 2.5f, 1f);
        });
        return true;
    }

    private boolean wings() {
        r.anim(ShazamAnim.SABBAC_WINGS);
        r.sound(r.position(), ShazamSounds.WHOOSH_HEAVY.get(), 1.4f, ShazamSounds.tune(0.5f));
        busyFor(ShazamAnim.WINGS_WINDUP + 8);
        r.later(ShazamAnim.WINGS_WINDUP, () -> {
            Vec3 c = r.position();
            for (LivingEntity foe : r.foes(c, 9.0)) {
                double d = Math.sqrt(foe.distanceToSqr(c));
                float falloff = (float) (1.0 - d / 9.0 * 0.5);
                if (r.hit(foe, 16f * SKILL_DAMAGE * falloff)) {
                    foe.igniteForSeconds(4f);
                    push(foe, c, 2.5 * falloff, 0.7);
                }
            }
            for (Projectile p : r.level().getEntitiesOfClass(Projectile.class, r.getBoundingBox().inflate(11.0),
                    p -> p.isAlive() && p.getOwner() != r)) {
                Vec3 away = p.position().subtract(c);
                p.setDeltaMovement(away.lengthSqr() < 1.0E-4 ? new Vec3(0, 1, 0) : away.normalize().scale(1.6));
                p.hurtMarked = true;
            }
            r.startFlying();
            r.setDeltaMovement(r.getDeltaMovement().x * 0.4, 1.2, r.getDeltaMovement().z * 0.4);
            r.hurtMarked = true;
            r.sound(c, ShazamSounds.CRATEIS_WINGS.get(), 2.2f, 1f);
        });
        return true;
    }

    private static final net.minecraft.resources.ResourceLocation HELLGATE_SIZE =
            com.shazammod.ShazamMod.id("rival_hellgate_size");

    private boolean hellgate() {
        r.anim(ShazamAnim.SABBAC_HELLGATE);
        r.sound(r.position(), ShazamSounds.HELLGATE_WINDUP.get(), 1.8f, 1f);
        busyFor(ShazamAnim.HELLGATE_WINDUP + 4);
        r.later(ShazamAnim.HELLGATE_WINDUP, () -> {
            rageUntil = now() + ShazamAnim.RAGE_TICKS;
            r.setFlag(RivalChampion.RAGE, true);
            AttributeInstance size = r.getAttribute(Attributes.SCALE);
            if (size != null && !size.hasModifier(HELLGATE_SIZE)) {
                size.addTransientModifier(new AttributeModifier(HELLGATE_SIZE, 0.6, AttributeModifier.Operation.ADD_VALUE));
            }
            Vec3 c = r.position();
            for (LivingEntity foe : r.foes(c, 6.0)) {
                if (r.hit(foe, 14f * SKILL_DAMAGE)) {
                    foe.igniteForSeconds(4f);
                    push(foe, c, 1.6, 0.5);
                }
            }
            for (int i = 0; i < 6; i++) {
                double angle = Math.PI * 2.0 * i / 6.0;
                r.bolt(c.add(Math.cos(angle) * 4.0, 0, Math.sin(angle) * 4.0), 0.9f);
            }
            r.sound(c, ShazamSounds.HELLGATE_OPEN.get(), 2.6f, 1f);
        });
        return true;
    }

    private boolean sabbacCall() {
        r.anim(ShazamAnim.SABBAC_CALL);
        r.sound(r.position(), ShazamSounds.DEMON_CALL_WINDUP.get(), 2.0f, 1f);
        busyFor(ShazamAnim.SABBAC_CALL_WINDUP + 6);
        r.later(ShazamAnim.SABBAC_CALL_WINDUP, () -> {
            Vec3 c = r.position();
            r.bolt(c, 2.3f);
            r.sound(c, ShazamSounds.DEMON_CALL.get(), 3.0f, 1f);
            r.healRival(120f);
            for (LivingEntity foe : r.foes(c, 6.5)) {
                if (r.hit(foe, 20f * SKILL_DAMAGE)) {
                    foe.igniteForSeconds(3f);
                    push(foe, c, 1.6, 0.55);
                }
            }
        });
        return true;
    }

    private boolean legion() {
        if (r.level().getDifficulty() == net.minecraft.world.Difficulty.PEACEFUL) {
            return false;
        }
        r.anim(ShazamAnim.SABBAC_LEGION);
        r.sound(r.position(), ShazamSounds.DEMON_CALL_WINDUP.get(), 1.4f, ShazamSounds.tune(0.8f));
        busyFor(ShazamAnim.LEGION_WINDUP + 6);
        r.later(ShazamAnim.LEGION_WINDUP, () -> {
            SabbacSkills.summonLegion(r.serverLevel(), r, r.position(), 3, false);
            r.sound(r.position(), ShazamSounds.LEGION_RISE.get(), 2.0f, 1f);
        });
        return true;
    }

    // ------------------------------------------------------------------ amarah (R) ketiga juara

    private void rageStorm() {
        List<LivingEntity> near = r.foes(r.position(), 14.0);
        if (near.isEmpty()) {
            return;
        }
        near.sort(Comparator.comparingDouble(m -> m.distanceToSqr(r)));
        switch (form()) {
            case SHAZAM -> {
                int step = rageStep++;
                for (int i = 0; i < Math.min(2, near.size()); i++) {
                    godStrike((step * 2 + i) % 6, near.get(i));
                }
            }
            case BLACK_ADAM -> {
                for (int i = 0; i < Math.min(3, near.size()); i++) {
                    strike(near.get(i).position(), 10f * SKILL_DAMAGE, 1.2, 0.9f);
                }
            }
            default -> {
                for (int i = 0; i < Math.min(3, near.size()); i++) {
                    LivingEntity foe = near.get(i);
                    r.anim(ShazamAnim.SABBAC_GEYSER, foe.position());
                    if (r.hit(foe, 10f * SKILL_DAMAGE)) {
                        foe.igniteForSeconds(3f);
                        foe.push(0, 0.55, 0);
                        foe.hurtMarked = true;
                    }
                    r.sound(foe.position(), ShazamSounds.FIRE_BLAST.get(), 1.2f, ShazamSounds.tune(0.7f));
                }
            }
        }
    }

    private void ragePunch(LivingEntity target) {
        Vec3 c = target.position();
        switch (form()) {
            case SHAZAM -> {
                r.bolt(c, 0.6f);
                List<LivingEntity> near = r.foes(c, 5.0);
                near.remove(target);
                for (int i = 0; i < Math.min(2, near.size()); i++) {
                    strike(near.get(i).position(), 8f * SKILL_DAMAGE, 0.8, 0.6f);
                }
            }
            case BLACK_ADAM -> {
                r.bolt(c, 0.7f);
                for (LivingEntity other : r.foes(c, 3.0)) {
                    if (other != target && r.hit(other, 8f * SKILL_DAMAGE)) {
                        push(other, c, 0.9, 0.3);
                    }
                }
            }
            default -> {
                r.anim(ShazamAnim.SABBAC_GEYSER, c);
                target.igniteForSeconds(4f);
                for (LivingEntity other : r.foes(c, 3.0)) {
                    if (other != target && r.hit(other, 8f * SKILL_DAMAGE)) {
                        other.igniteForSeconds(2f);
                        push(other, c, 0.9, 0.4);
                    }
                }
            }
        }
    }

    private void endRage() {
        rageUntil = 0;
        r.setFlag(RivalChampion.RAGE, false);
        AttributeInstance size = r.getAttribute(Attributes.SCALE);
        if (size != null) {
            size.removeModifier(HELLGATE_SIZE);
        }
    }
}
