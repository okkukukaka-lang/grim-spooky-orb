package com.shazammod;

import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * 0.30 Jalan Sabbac: Bijih Eternium (mineral mistis dari film Black Adam) yang tersembunyi di batu Nether, dilebur jadi
 * Batangan Eternium, lalu ditempa bersama tengkorak Wither Skeleton jadi Mahkota Sabbac. Mahkotanya dipakai (klik kanan,
 * wujud manusia, di kegelapan: malam hari atau di Nether) untuk Perjanjian Enam Iblis (lihat SabbacPact).
 *
 * Resep di data/shazammod/recipe/, sebaran bijih di data/shazammod/worldgen/ & neoforge/biome_modifier/.
 */
@EventBusSubscriber(modid = ShazamMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public final class SabbacItems {
    private SabbacItems() {}

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(ShazamMod.MODID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(ShazamMod.MODID);

    /** Bijih Eternium: sekeras puing purba, berpendar merah samar dari dalam batu Nether. */
    public static final DeferredBlock<Block> ETERNIUM_ORE = BLOCKS.register("eternium_ore",
            () -> new DropExperienceBlock(UniformInt.of(4, 9), BlockBehaviour.Properties.of()
                    .mapColor(MapColor.NETHER)
                    .requiresCorrectToolForDrops()
                    .strength(20f, 1200f)
                    .sound(SoundType.ANCIENT_DEBRIS)
                    .lightLevel(state -> 6)));

    public static final DeferredItem<BlockItem> ETERNIUM_ORE_ITEM = ITEMS.register("eternium_ore",
            () -> new BlockItem(ETERNIUM_ORE.get(), new Item.Properties().fireResistant().rarity(Rarity.UNCOMMON)));

    public static final DeferredItem<Item> RAW_ETERNIUM = ITEMS.registerSimpleItem("raw_eternium",
            new Item.Properties().fireResistant().rarity(Rarity.UNCOMMON));

    public static final DeferredItem<Item> ETERNIUM_INGOT = ITEMS.registerSimpleItem("eternium_ingot",
            new Item.Properties().fireResistant().rarity(Rarity.RARE));

    public static final DeferredItem<SabbacCrownItem> CROWN = ITEMS.register("crown_of_sabbac",
            () -> new SabbacCrownItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant()));

    @SubscribeEvent
    public static void addToCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
            event.accept(ETERNIUM_ORE_ITEM.get());
        }
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            event.accept(RAW_ETERNIUM.get());
            event.accept(ETERNIUM_INGOT.get());
            event.accept(CROWN.get());
        }
    }
}
