package com.shazammod;

/**
 * Jadwal slow motion transformasi (murni Java, gampang diuji). Tiap tick mengembalikan tick rate yang
 * harus dipasang, atau NaN kalau nggak berubah:
 * petir turun (sangat lambat) -> kostum terbentuk (lambat) -> kembali normal pelan-pelan.
 * Kalau petir batal menyambar atau pemainnya pergi, dunia langsung kembali normal.
 */
public final class SlowMoTimeline {
    public enum Phase { OFF, DESCENT, TRANSFORM, RAMP }

    private final float descentRate;
    private final float transformRate;
    private final float[] ramp;
    private final int rampHold;
    private Phase phase = Phase.OFF;
    private int ticksLeft;
    private int rampStep;
    private float normalRate = 20f;

    /**
     * @param descentRate   tick rate saat petir turun (20 = normal)
     * @param transformRate tick rate saat kostum terbentuk
     * @param ramp          tick rate bertahap saat kembali normal
     * @param rampHold      berapa tick tiap tahap kembali normal
     */
    public SlowMoTimeline(float descentRate, float transformRate, float[] ramp, int rampHold) {
        this.descentRate = descentRate;
        this.transformRate = transformRate;
        this.ramp = ramp;
        this.rampHold = rampHold;
    }

    public Phase phase() {
        return phase;
    }

    public boolean active() {
        return phase != Phase.OFF;
    }

    /** Petir mulai turun. currentRate = tick rate sebelum slow motion (dikembalikan di akhir). */
    public float begin(float currentRate, int descentTicks, int safetyTicks) {
        if (phase == Phase.OFF) {
            normalRate = currentRate;
        }
        phase = Phase.DESCENT;
        ticksLeft = descentTicks + safetyTicks;   // pengaman kalau sambaran nggak pernah datang
        return Math.min(descentRate, normalRate);
    }

    /** Petir mengenai: lanjut lambat selama kostum terbentuk. */
    public float strike(int transformTicks) {
        if (phase == Phase.OFF) {
            return Float.NaN;
        }
        phase = Phase.TRANSFORM;
        ticksLeft = transformTicks;
        return Math.min(transformRate, normalRate);
    }

    /** Dipanggil tiap tick server. */
    public float tick(boolean ownerPresent) {
        if (phase == Phase.OFF) {
            return Float.NaN;
        }
        if (!ownerPresent) {
            return end();
        }
        if (--ticksLeft > 0) {
            return Float.NaN;
        }
        switch (phase) {
            case DESCENT:
                return end();   // petir nggak jadi menyambar
            case TRANSFORM:
                phase = Phase.RAMP;
                rampStep = 0;
                // jatuh ke RAMP di bawah
            default:
                while (rampStep < ramp.length && ramp[rampStep] >= normalRate) {
                    rampStep++;   // tahap yang sudah lebih cepat dari normal dilewati
                }
                if (rampStep < ramp.length) {
                    ticksLeft = rampHold;
                    return ramp[rampStep++];
                }
                return end();
        }
    }

    /** Matikan slow motion sekarang; mengembalikan tick rate normal. */
    public float end() {
        if (phase == Phase.OFF) {
            return Float.NaN;
        }
        phase = Phase.OFF;
        return normalRate;
    }
}
