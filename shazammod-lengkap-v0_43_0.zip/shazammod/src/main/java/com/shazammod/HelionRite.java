package com.shazammod;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

/**
 * 0.43 Eksperimen Proyek Helion-6: Serum Helion-6 (serum Cryon) disuntikkan di leher, JAUH dari matahari (malam, di bawah
 * tanah, di dalam ruangan, atau di Nether). Radiasi Cryon menjalar lewat pembuluh darah (urat hijau menyala dari leher ke
 * seluruh tubuh), sel bermutasi jadi Sel Cryon (kejang, berlutut), lalu radiasinya meledak keluar dari tubuh. Kena sinar
 * matahari di tengah eksperimen = gagal (serum belum terpakai).
 */
public final class HelionRite {
    public static final int INJECT = 14;
    public static final int SPREAD = 40;
    public static final int MUTATE = 80;
    public static final int EVOLVE = ShazamAnim.HELION_RITE_STRIKE;
    public static final int LENGTH = ShazamAnim.HELION_RITE_TICKS;

    private static final Map<UUID, Long> RITES = new HashMap<>();
    private static final Set<UUID> FORCED = new HashSet<>();

    private HelionRite() {}

    public static boolean isAwakening(ServerPlayer p) {
        Long t = RITES.get(p.getUUID());
        return t != null && p.level().getGameTime() - t <= LENGTH + 4;
    }

    public static void tryBegin(ServerPlayer p) {
        ShazamData d = ShazamPowers.data(p);
        String err = null;
        if (isAwakening(p) || LintangRite.isAwakening(p)) {
            err = "message.shazammod.helion_rite.already";
        } else if (d.helionUnlocked()) {
            err = "message.shazammod.helion_rite.already_yours";
        } else if (d.transformed()) {
            err = "message.shazammod.helion_rite.human_only";
        } else if (KahndaqTrial.isRunning(p) || ShazamTotems.isAwakening(p) || SabbacPact.isAwakening(p)) {
            err = "message.shazammod.helion_rite.busy";
        } else if (PassiveConditions.underSun(p.level(), p.blockPosition())) {
            err = "message.shazammod.helion_rite.need_dark";
        }
        if (err != null) {
            p.displayClientMessage(Component.translatable(err).withStyle(ChatFormatting.GREEN, ChatFormatting.ITALIC), true);
            return;
        }
        begin(p, false);
    }

    public static void begin(ServerPlayer p, boolean forced) {
        if (isAwakening(p)) {
            return;
        }
        UUID id = p.getUUID();
        if (forced) {
            FORCED.add(id);
        } else {
            FORCED.remove(id);
        }
        if (ShazamPowers.isTransformed(p)) {
            ShazamPowers.revert(p, false);
        }
        final long start = p.serverLevel().getGameTime();
        RITES.put(id, start);
        ShazamNetwork.playAnim(p, ShazamAnim.HELION_RITE);
        sound(p, ShazamSounds.HELION_RITE.get(), 1.6f, 1f);
        log(p, "message.shazammod.helion_lab.start", ChatFormatting.GREEN);
        for (int t = 6; t < EVOLVE; t += 6) {
            final int tick = t;
            ShazamPowers.schedule(p, t, sp -> progress(sp, start, tick));
        }
        ShazamPowers.schedule(p, SPREAD, sp -> {
            if (active(sp, start)) {
                log(sp, "message.shazammod.helion_lab.spread", ChatFormatting.DARK_GREEN);
            }
        });
        ShazamPowers.schedule(p, MUTATE, sp -> {
            if (active(sp, start)) {
                log(sp, "message.shazammod.helion_lab.mutate", ChatFormatting.RED);
            }
        });
        ShazamPowers.schedule(p, EVOLVE, sp -> finish(sp, start));
    }

    private static boolean active(ServerPlayer p, long start) {
        Long t = RITES.get(p.getUUID());
        return t != null && t.longValue() == start;
    }

    private static void progress(ServerPlayer p, long start, int tick) {
        if (!active(p, start)) {
            return;
        }
        if (!FORCED.contains(p.getUUID()) && PassiveConditions.underSun(p.level(), p.blockPosition())) {
            abort(p);
            return;
        }
        String stage;
        float frac;
        if (tick < SPREAD) {
            stage = "message.shazammod.helion_lab.stage.inject";
            frac = tick / (float) SPREAD;
        } else if (tick < MUTATE) {
            stage = "message.shazammod.helion_lab.stage.spread";
            frac = (tick - SPREAD) / (float) (MUTATE - SPREAD);
        } else {
            stage = "message.shazammod.helion_lab.stage.mutate";
            frac = (tick - MUTATE) / (float) (EVOLVE - MUTATE);
        }
        int pct = Math.max(1, Math.min(100, Math.round(frac * 100f)));
        int full = Math.min(10, pct / 10);
        StringBuilder bar = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            bar.append(i < full ? '\u25AE' : '\u25AF');
        }
        ChatFormatting c = tick < SPREAD ? ChatFormatting.GREEN : tick < MUTATE ? ChatFormatting.DARK_GREEN : ChatFormatting.RED;
        p.displayClientMessage(Component.translatable("message.shazammod.helion_lab.bar",
                Component.translatable(stage), bar.toString(), String.valueOf(pct)).withStyle(c), true);
    }

    private static void abort(ServerPlayer p) {
        UUID id = p.getUUID();
        RITES.remove(id);
        FORCED.remove(id);
        log(p, "message.shazammod.helion_lab.abort", ChatFormatting.RED);
        sound(p, ShazamSounds.HELION_POWER_DOWN.get(), 1.2f, 1f);
        ShazamNetwork.playAnim(p, ShazamAnim.HELION_SUN_BURN, p.position());
    }

    private static void finish(ServerPlayer p, long start) {
        if (!active(p, start)) {
            return;
        }
        UUID id = p.getUUID();
        RITES.remove(id);
        boolean forced = FORCED.remove(id);
        if (ShazamPowers.data(p).helionUnlocked()) {
            return;
        }
        if (!forced && !consumeSerum(p)) {
            p.displayClientMessage(Component.translatable("message.shazammod.helion_rite.no_serum").withStyle(ChatFormatting.GRAY), true);
            return;
        }
        log(p, "message.shazammod.helion_lab.done", ChatFormatting.GREEN);
        ShazamPowers.unlockHelion(p);
    }

    private static boolean consumeSerum(ServerPlayer p) {
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (!s.isEmpty() && s.is(HelionItems.SERUM.get())) {
                s.shrink(1);
                return true;
            }
        }
        return false;
    }

    private static void log(ServerPlayer p, String key, ChatFormatting color) {
        p.sendSystemMessage(Component.translatable("message.shazammod.helion_lab.prefix").withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD)
                .append(Component.literal(" "))
                .append(Component.translatable(key).withStyle(color)));
    }

    private static void sound(ServerPlayer p, SoundEvent sound, float volume, float pitch) {
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), sound, SoundSource.PLAYERS, volume, pitch);
    }

    public static void forget(UUID id) {
        RITES.remove(id);
        FORCED.remove(id);
    }
}
