package com.shazammod;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.animal.SnowGolem;
import net.minecraft.world.entity.animal.horse.AbstractHorse;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/**
 * Kekuatan Keluarga (0.26, tombol J), diambil dari klimaks film Shazam!: Billy membagi kekuatannya ke keluarganya dan
 * petir menyambar mereka semua bersamaan.
 *
 * Shazam mengangkat kepalan ke langit sementara tautan petir emas menyambung ke tiap anggota keluarga dalam 16 blok
 * (pemain lain, hewan peliharaan, kuda jinak, villager, golem besi & salju). Tepat di tick FAMILY_WINDUP petir sihir
 * menyambar SEMUANYA bersamaan, juga kepalan Shazam. Selama 30 detik mereka jadi juara kecil:
 * Kekuatan II, Cepat II, Tahan II, Pulih II, kebal api, darah langsung pulih separuh, badan berpendar emas dengan listrik
 * merayap (client.fx.FamilyFx), dan tiap pukulan mereka ke monster +50% dengan petir kecil dari langit (paling sering
 * tiap 1 detik per anggota, +6 damage). Panah dan serangan lain dari anggota keluarga ikut dihitung.
 */
public final class ShazamFamily {
    private ShazamFamily() {}

    // ======= Angka yang gampang diutak-atik =======
    public static final double RADIUS = 16.0;              // jangkauan: anggota keluarga sejauh ini ikut disambar
    public static final float COST = 200f;                 // Energi Petir yang dipakai
    public static final int COOLDOWN_TICKS = 1200;         // 60 detik
    public static final int DURATION_TICKS = 600;          // kekuatan bertahan 30 detik
    private static final int EFFECT_LEVEL = 1;             // 0 = level I, 1 = level II
    private static final float HEAL_FRACTION = 0.5f;       // darah anggota keluarga langsung pulih segini dari penuh
    private static final float HIT_MULTIPLIER = 1.5f;      // pukulan anggota keluarga ke monster
    private static final float HIT_BOLT_DAMAGE = 6f;       // + petir kecil dari langit
    private static final int HIT_BOLT_GAP = 20;            // petir kecil paling sering tiap 1 detik per anggota
    public static final int MAX_FAMILY = 12;               // paling banyak segini yang disambar sekaligus (terdekat dulu)
    // =========================================================================

    private static final Map<UUID, Long> READY_AT = new HashMap<>();
    private static final Map<UUID, Long> EMPOWERED = new HashMap<>();
    private static final Map<UUID, Long> BOLT_NEXT = new HashMap<>();

    /** Anggota keluarga Shazam (sama dengan yang dicari FamilyFx di client). */
    public static boolean isFamily(LivingEntity entity, Player shazam) {
        if (entity == shazam || !entity.isAlive()) {
            return false;
        }
        if (entity instanceof Player player) {
            return !player.isSpectator();
        }
        if (entity instanceof TamableAnimal pet) {
            return pet.isTame();
        }
        if (entity instanceof AbstractHorse horse) {
            return horse.isTamed();
        }
        if (entity instanceof IronGolem && !(entity instanceof Enemy)) {   // penjaga Atlas di mod ini musuh, bukan keluarga
            return true;
        }
        return entity instanceof AbstractVillager || entity instanceof SnowGolem;
    }

    static List<LivingEntity> family(ServerPlayer player) {
        List<LivingEntity> list = player.serverLevel().getEntitiesOfClass(LivingEntity.class,
                player.getBoundingBox().inflate(RADIUS), e -> isFamily(e, player) && e.distanceToSqr(player) <= RADIUS * RADIUS);
        list.sort(Comparator.comparingDouble(e -> e.distanceToSqr(player)));
        return list.size() > MAX_FAMILY ? list.subList(0, MAX_FAMILY) : list;
    }

    /** Sisa cooldown (tick) buat HUD. */
    public static int cooldownTicks(ServerPlayer player) {
        Long ready = READY_AT.get(player.getUUID());
        if (ready == null) {
            return 0;
        }
        long left = ready - player.level().getGameTime();
        return left > 0 ? (int) left : 0;
    }

    /** Tombol J. */
    public static void use(ServerPlayer player) {
        if (!ShazamPassives.isShazam(player)) {
            player.displayClientMessage(Component.translatable("message.shazammod.family_only"), true);
            return;
        }
        int cooldown = cooldownTicks(player);
        if (cooldown > 0) {
            player.displayClientMessage(Component.translatable("message.shazammod.family_cooldown", (cooldown + 19) / 20), true);
            return;
        }
        ShazamData data = ShazamPowers.data(player);
        if (data.energy() < COST) {
            player.displayClientMessage(Component.translatable("message.shazammod.family_energy", Math.round(COST)), true);
            return;
        }
        if (family(player).isEmpty()) {
            player.displayClientMessage(Component.translatable("message.shazammod.family_none", (int) RADIUS), true);
            return;
        }
        ShazamPowers.setData(player, data.withEnergy(data.energy() - COST));
        READY_AT.put(player.getUUID(), player.level().getGameTime() + COOLDOWN_TICKS);
        ShazamNetwork.playAnim(player, ShazamAnim.FAMILY_CALL, player.position());
        // ancang-ancang: panjangnya sama dengan FAMILY_WINDUP, diputar di nada asli supaya puncaknya jatuh di tick sambaran
        player.serverLevel().playSound(null, player, ShazamSounds.FAMILY_WINDUP.get(), SoundSource.PLAYERS, 1.6f, 1f);
        ShazamPowers.schedule(player, ShazamAnim.FAMILY_WINDUP, ShazamFamily::strike);
        ShazamNetwork.sync(player);
    }

    /** Petir menyambar seluruh keluarga dan kepalan Shazam bersamaan. */
    private static void strike(ServerPlayer player) {
        if (!ShazamPassives.isShazam(player)) {
            return;   // keburu balik jadi manusia
        }
        ServerLevel level = player.serverLevel();
        List<LivingEntity> family = family(player);
        long until = level.getGameTime() + DURATION_TICKS;
        for (LivingEntity ally : family) {
            ShazamPowers.spawnBolt(level, ally.position(), 1.4f, 0);
            empower(ally, until);
        }
        ShazamPowers.spawnBolt(level, player.position().add(0, ShazamPowers.FIST_HEIGHT * player.getScale(), 0), 1.8f, 0);
        level.playSound(null, player.getX(), player.getY(), player.getZ(), ShazamSounds.FAMILY_STRIKE.get(), SoundSource.PLAYERS,
                3.0f, 1f);
        player.displayClientMessage(Component.translatable("message.shazammod.family_power", family.size())
                .withStyle(ChatFormatting.GOLD), true);
        for (LivingEntity ally : family) {
            if (ally instanceof ServerPlayer friend) {
                friend.displayClientMessage(Component.translatable("message.shazammod.family_given", player.getDisplayName())
                        .withStyle(ChatFormatting.GOLD), true);
            }
        }
    }

    private static void empower(LivingEntity ally, long until) {
        int t = DURATION_TICKS;
        ally.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, t, EFFECT_LEVEL, true, false, true));
        ally.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, t, EFFECT_LEVEL, true, false, true));
        ally.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, t, EFFECT_LEVEL, true, false, true));
        ally.addEffect(new MobEffectInstance(MobEffects.REGENERATION, t, EFFECT_LEVEL, true, false, true));
        ally.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, t, 0, true, false, true));
        ally.heal(ally.getMaxHealth() * HEAL_FRACTION);
        ally.clearFire();
        EMPOWERED.put(ally.getUUID(), until);
    }

    /** Masih diberkati Kekuatan Keluarga? (yang sudah habis dibuang di sini) */
    public static boolean isEmpowered(Entity entity) {
        if (entity == null) {
            return false;
        }
        Long until = EMPOWERED.get(entity.getUUID());
        if (until == null) {
            return false;
        }
        if (until <= entity.level().getGameTime()) {
            EMPOWERED.remove(entity.getUUID());
            BOLT_NEXT.remove(entity.getUUID());
            return false;
        }
        return true;
    }

    /** Anggota keluarga yang diberkati memukul monster: +50% dan (paling sering tiap 1 detik) petir kecil dari langit. */
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        LivingEntity victim = event.getEntity();
        Entity attacker = event.getSource().getEntity();
        if (!(victim instanceof Enemy) || !(victim.level() instanceof ServerLevel level) || !isEmpowered(attacker)) {
            return;
        }
        float amount = event.getAmount() * HIT_MULTIPLIER;
        long now = level.getGameTime();
        Long next = BOLT_NEXT.get(attacker.getUUID());
        if (next == null || now >= next) {
            BOLT_NEXT.put(attacker.getUUID(), now + HIT_BOLT_GAP);
            amount += HIT_BOLT_DAMAGE;
            ShazamPowers.spawnBolt(level, victim.position(), 0.8f, 0);
            level.playSound(null, victim.getX(), victim.getY(), victim.getZ(), ShazamSounds.LIGHTNING_STRIKE.get(),
                    SoundSource.PLAYERS, 0.9f, ShazamSounds.tune(1.3f));
        }
        event.setAmount(amount);
    }
}
