package com.shazammod;

import java.util.Locale;

import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.ServerChatEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.ProjectileImpactEvent;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.living.LivingDropsEvent;
import net.neoforged.neoforge.event.entity.living.LivingExperienceDropEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/** Menyambungkan event game ke logika di ShazamPowers. */
@EventBusSubscriber(modid = ShazamMod.MODID)
public final class ShazamEvents {
    private ShazamEvents() {}

    @SubscribeEvent
    public static void onChat(ServerChatEvent event) {
        // "shazam", "Shazam!", "SHAZAM!!!" semuanya dihitung; 0.30: "SABBAC" untuk juara enam iblis
        String word = event.getRawText().toLowerCase(Locale.ROOT).replaceAll("[^a-z]", "");
        if (word.equals("shazam") || word.equals("sabbac")) {   // 0.33: Lintang hero sains, nggak pakai kata ajaib (Mode Surya lewat tombol Transformasi)
            ServerPlayer player = event.getPlayer();
            player.server.execute(() -> ShazamPowers.onSayWord(player, word));
        }
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        ShazamSlowMo.tick(event.getServer());
        KahndaqTrial.tick(event.getServer());
        com.shazammod.rival.RivalSpawner.tick(event.getServer());   // 0.30 Rival Juara datang menantang
        LintangPhysics.serverTick(event.getServer());               // 0.42 lahar dari sinar mata membeku lagi
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        ShazamSlowMo.end(event.getServer());
        KahndaqTrial.clear();
        SabbacPact.clear();
        LintangRite.clear();
        com.shazammod.rival.RivalSpawner.clear();
    }

    /** Sisa makhluk Ujian Kahndaq yang terputus (server mati di tengah ujian) dibuang saat dimuat lagi. */
    @SubscribeEvent
    public static void onEntityJoin(EntityJoinLevelEvent event) {
        KahndaqTrial.onEntityJoin(event);
    }

    /** Husk di gurun kadang menjatuhkan Skarabe Teth-Adam. */
    @SubscribeEvent
    public static void onDrops(LivingDropsEvent event) {
        KahndaqTrial.onDrops(event);
    }

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            ShazamPowers.tick(player);
        }
    }

    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        ShazamPowers.onIncomingDamage(event);
    }

    /** 0.27 Tangan Kahndaq: proyektil yang dikembalikan Black Adam mengenai sasaran. */
    @SubscribeEvent
    public static void onProjectileImpact(ProjectileImpactEvent event) {
        if (!event.getProjectile().level().isClientSide) {
            AdamCatch.onImpact(event);
        }
    }

    /** Paling akhir, supaya damage yang dicek sudah final (sesudah semua mod lain mengubahnya). */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onDamagePre(LivingDamageEvent.Pre event) {
        ShazamPowers.onDamagePre(event);
    }

    /** Lebih dulu dari mod lain yang mengurus kematian (misalnya kuburan), supaya Shazam nggak dianggap mati. */
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onDeath(LivingDeathEvent event) {
        ShazamPowers.onDeath(event);
    }

    @SubscribeEvent
    public static void onExperienceDrop(LivingExperienceDropEvent event) {
        ShazamPowers.onExperienceDrop(event);
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            ShazamPowers.onLogin(player);
        }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            ShazamPowers.onRespawn(player);
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            ShazamPowers.onLogout(player);
        }
    }

    /** Pemain lain baru kelihatan: kabari dia kalau pemain ini sedang jadi Shazam / Black Adam (atau memilih Black Adam). */
    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking event) {
        if (event.getTarget() instanceof ServerPlayer target && event.getEntity() instanceof ServerPlayer viewer
                && (ShazamPowers.isTransformed(target) || ShazamPowers.data(target).hoodUp()
                || !ShazamPowers.data(target).isShazam())) {
            ShazamNetwork.sendStateTo(target, viewer);
        }
    }

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        ShazamCommands.register(event.getDispatcher());
    }
}
