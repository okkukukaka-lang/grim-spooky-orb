package com.shazammod.guardian;

import com.shazammod.ShazamItems;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.breeze.Breeze;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Penjaga Zeus: titik sambaran petirnya ditandai percikan 1 detik sebelumnya. */
public class StormStalker extends Breeze implements ShazamGuardian {
    private final GuardianCore core = new GuardianCore(this, BossEvent.BossBarColor.BLUE,
            ShazamItems.TOTEM_ZEUS, "hint.shazammod.zeus");
    private int boltCooldown = 60;
    private int markTicks;
    private Vec3 markedPos = Vec3.ZERO;

    public StormStalker(EntityType<? extends StormStalker> type, Level level) {
        super(type, level);
        this.xpReward = 50;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Breeze.createAttributes()
                .add(Attributes.MAX_HEALTH, 120.0)
                .add(Attributes.FOLLOW_RANGE, 32.0)
                .add(Attributes.SCALE, 1.6);
    }

    @Override
    public GuardianCore core() {
        return core;
    }

    @Override
    public void aiStep() {
        if (!this.level().isClientSide) {
            core.tick();
            if (!core.isDormant() && this.isAlive()) {
                tickLightning((ServerLevel) this.level());
            }
        }
        super.aiStep();
    }

    private void tickLightning(ServerLevel level) {
        if (markTicks > 0) {
            markTicks--;
            for (int i = 0; i < 8; i++) {
                double angle = i * Math.PI / 4.0;
                level.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                        markedPos.x + Math.cos(angle) * 1.5, markedPos.y + 0.1, markedPos.z + Math.sin(angle) * 1.5,
                        1, 0, 0, 0, 0);
            }
            if (markTicks == 0) {
                strikeMarked(level);
            }
            return;
        }
        if (--boltCooldown <= 0) {
            Player target = level.getNearestPlayer(this.getX(), this.getY(), this.getZ(), 24.0,
                    EntitySelector.NO_CREATIVE_OR_SPECTATOR);
            if (target != null) {
                markedPos = target.position();
                markTicks = 20;
                boltCooldown = 50;
                this.playSound(SoundEvents.EVOKER_PREPARE_ATTACK, 1.2f, 1.5f);
            } else {
                boltCooldown = 20;
            }
        }
    }

    private void strikeMarked(ServerLevel level) {
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt != null) {
            bolt.moveTo(markedPos.x, markedPos.y, markedPos.z);
            bolt.setVisualOnly(true); // cuma efek; damage dihitung di bawah
            level.addFreshEntity(bolt);
        }
        AABB area = new AABB(markedPos, markedPos).inflate(1.5, 3.0, 1.5);
        for (Player player : level.getEntitiesOfClass(Player.class, area,
                p -> p.isAlive() && !p.isCreative() && !p.isSpectator())) {
            player.hurt(this.damageSources().lightningBolt(), 8f);
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!this.level().isClientSide && core.isDormant()) {
            core.wake();
        }
        return super.hurt(source, amount);
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        core.onDeath();
    }

    @Override
    protected boolean isImmobile() {
        return super.isImmobile() || core.isDormant();
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        core.startSeen(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        core.stopSeen(player);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        core.save(tag);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        core.load(tag);
    }
}
