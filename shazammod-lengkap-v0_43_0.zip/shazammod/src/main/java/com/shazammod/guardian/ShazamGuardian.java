package com.shazammod.guardian;

/** Semua penjaga kuil punya GuardianCore: boss bar, tidur/bangun, dan drop totem. */
public interface ShazamGuardian {
    GuardianCore core();
}
