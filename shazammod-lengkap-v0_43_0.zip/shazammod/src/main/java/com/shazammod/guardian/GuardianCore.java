package com.shazammod.guardian;

import java.util.function.Supplier;

import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/**
 * Bagian yang sama untuk semua penjaga: tidur sampai ada pemain mendekat,
 * boss bar, petunjuk cara melawan, dan totem yang jatuh saat kalah.
 */
public final class GuardianCore {
    private static final double WAKE_RANGE = 10.0;

    private final Mob mob;
    private final ServerBossEvent bossEvent;
    private final Supplier<? extends Item> totem; // null kalau totemnya jatuh dengan cara lain
    private final String hintKey;
    private boolean dormant = true;

    public GuardianCore(Mob mob, BossEvent.BossBarColor color, Supplier<? extends Item> totem, String hintKey) {
        this.mob = mob;
        this.totem = totem;
        this.hintKey = hintKey;
        this.bossEvent = new ServerBossEvent(mob.getType().getDescription(), color, BossEvent.BossBarOverlay.NOTCHED_10);
        this.bossEvent.setVisible(false);
    }

    public boolean isDormant() {
        return dormant;
    }

    /** Dipanggil tiap tick di server dari aiStep() penjaga. */
    public void tick() {
        if (dormant) {
            if (mob.tickCount % 10 == 0 && mob.level().getNearestPlayer(mob.getX(), mob.getY(), mob.getZ(),
                    WAKE_RANGE, EntitySelector.NO_SPECTATORS) != null) {
                wake();
            }
        } else {
            bossEvent.setProgress(mob.getHealth() / mob.getMaxHealth());
        }
    }

    public void wake() {
        if (!dormant) {
            return;
        }
        dormant = false;
        bossEvent.setVisible(true);
        mob.playSound(SoundEvents.ENDER_DRAGON_GROWL, 1.5f, 1.3f);
        Component title = Component.translatable("message.shazammod.guardian_awakens", mob.getDisplayName())
                .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD);
        Component hint = Component.translatable(hintKey).withStyle(ChatFormatting.YELLOW);
        for (Player player : mob.level().players()) {
            if (player.distanceToSqr(mob) < 48 * 48) {
                player.sendSystemMessage(title);
                player.displayClientMessage(hint, true);
            }
        }
    }

    public void startSeen(ServerPlayer player) {
        bossEvent.addPlayer(player);
    }

    public void stopSeen(ServerPlayer player) {
        bossEvent.removePlayer(player);
    }

    public void save(CompoundTag tag) {
        tag.putBoolean("ShazamDormant", dormant);
    }

    public void load(CompoundTag tag) {
        dormant = tag.getBoolean("ShazamDormant");
        bossEvent.setVisible(!dormant);
    }

    /** Dipanggil saat penjaga kalah: totemnya jatuh. */
    public void onDeath() {
        bossEvent.setProgress(0f);
        if (totem != null && !mob.level().isClientSide) {
            mob.spawnAtLocation(new ItemStack(totem.get()));
        }
    }
}
