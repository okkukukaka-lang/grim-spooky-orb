package com.shazammod;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

/**
 * 0.30 Perjanjian Enam Iblis: jalan menjadi SABBAC, beda dari Shazam (enam totem penjaga) dan Black Adam (Ujian Kahndaq).
 *
 * 1. Tambang Bijih Eternium di batu Nether (beliung berlian), lebur jadi Batangan Eternium.
 * 2. Tempa Mahkota Sabbac: 5 Batangan Eternium + 1 tengkorak Wither Skeleton (lihat resepnya).
 * 3. Klik kanan mahkotanya dalam wujud MANUSIA, jauh dari matahari: malam hari, di gua / di dalam ruangan, saat hujan,
 *    atau di Nether / End. Iblis nggak menjawab di bawah matahari (siang, langit terbuka, nggak hujan).
 * 4. Mahkota terangkat ke atas kepala, enam bara iblis (Satan, Aym, Belial, Beelzebub, Asmodeus, Crateis) mengorbit,
 *    lingkaran api neraka merekah di tanah, lalu petir neraka merah-hitam menyembur NAIK dari bawah tanah menembus badan.
 *    Mahkotanya menyatu, dan kekuatan Sabbac jadi milikmu (langsung terpilih sebagai juara). Ucapkan SABBAC untuk berubah.
 *
 * Selama upacara badan dilindungi api neraka (nggak bisa dilukai), sama seperti ritual berubah.
 */
public final class SabbacPact {
    private SabbacPact() {}

    /** Pemain yang sedang menjalani perjanjian: game time mulai. */
    private static final Map<UUID, Long> PACTS = new HashMap<>();
    /** Perjanjian dari perintah /shazam pact: boleh tanpa mahkota (buat dites). */
    private static final Set<UUID> FORCED = new HashSet<>();

    public static boolean isAwakening(ServerPlayer player) {
        Long start = PACTS.get(player.getUUID());
        return start != null && player.level().getGameTime() - start <= ShazamAnim.PACT_TICKS + 5;
    }

    /** Klik kanan Mahkota Sabbac. */
    public static void tryBegin(ServerPlayer player) {
        ShazamData data = ShazamPowers.data(player);
        String refusal = null;
        if (isAwakening(player)) {
            refusal = "message.shazammod.pact.already";
        } else if (data.sabbacUnlocked()) {
            refusal = "message.shazammod.pact.already_yours";
        } else if (data.transformed()) {
            refusal = "message.shazammod.pact.human_only";
        } else if (KahndaqTrial.isRunning(player) || ShazamTotems.isAwakening(player)) {
            refusal = "message.shazammod.pact.busy";
        } else if (PassiveConditions.underSun(player.level(), player.blockPosition())) {
            refusal = "message.shazammod.pact.need_dark";
        }
        if (refusal != null) {
            player.displayClientMessage(Component.translatable(refusal).withStyle(ChatFormatting.DARK_RED, ChatFormatting.ITALIC),
                    true);
            return;
        }
        begin(player, false);
    }

    /** Mulai upacara di sini. forced = dari perintah /shazam pact: syarat matahari & mahkota dilewati, buat dites. */
    public static void begin(ServerPlayer player, boolean forced) {
        if (isAwakening(player)) {
            return;
        }
        if (forced) {
            FORCED.add(player.getUUID());
        } else {
            FORCED.remove(player.getUUID());
        }
        if (ShazamPowers.isTransformed(player)) {
            ShazamPowers.revert(player, false);
        }
        ServerLevel level = player.serverLevel();
        PACTS.put(player.getUUID(), level.getGameTime());
        ShazamNetwork.playAnim(player, ShazamAnim.SABBAC_PACT);
        // bisikan enam iblis yang makin rapat, memuncak tepat saat petir neraka menyembur (PACT_STRIKE)
        level.playSound(null, player.getX(), player.getY(), player.getZ(), ShazamSounds.SABBAC_PACT.get(), SoundSource.PLAYERS,
                1.6f, 1f);
        level.playSound(null, player.getX(), player.getY(), player.getZ(), ShazamSounds.DREAD.get(), SoundSource.PLAYERS,
                1.0f, ShazamSounds.tune(0.45f));
        speak(player, "message.shazammod.pact.start");
        ShazamPowers.schedule(player, ShazamAnim.PACT_STRIKE / 2, p -> {
            if (PACTS.containsKey(p.getUUID())) {
                speak(p, "message.shazammod.pact.names");
            }
        });
        ShazamPowers.schedule(player, ShazamAnim.PACT_STRIKE, SabbacPact::strike);
    }

    private static void speak(ServerPlayer player, String key) {
        player.sendSystemMessage(Component.translatable("speaker.shazammod.six_demons").withStyle(ChatFormatting.DARK_RED,
                ChatFormatting.BOLD).append(Component.literal(" ")).append(Component.translatable(key)
                .withStyle(ChatFormatting.RED, ChatFormatting.ITALIC)));
    }

    /**
     * Petir neraka menyembur naik: mahkota menyatu, Sabbac terbuka. Mahkota baru dipakai di sini (dibuang di tengah: batal).
     * Perjanjian dari perintah tes nggak memakai mahkota.
     */
    private static void strike(ServerPlayer player) {
        PACTS.remove(player.getUUID());
        boolean forced = FORCED.remove(player.getUUID());
        if (ShazamPowers.data(player).sabbacUnlocked()) {
            return;
        }
        Inventory inventory = player.getInventory();
        boolean consumed = forced;
        for (int i = 0; i < inventory.getContainerSize() && !consumed; i++) {
            ItemStack stack = inventory.getItem(i);
            if (!stack.isEmpty() && stack.is(SabbacItems.CROWN.get())) {
                stack.shrink(1);
                consumed = true;
            }
        }
        if (!consumed) {
            player.displayClientMessage(Component.translatable("message.shazammod.pact.no_crown").withStyle(ChatFormatting.GRAY),
                    true);
            return;
        }
        ServerLevel level = player.serverLevel();
        Vec3 pos = player.position();
        ShazamPowers.spawnBolt(level, pos, 2.8f, ShazamForm.SABBAC.boltVariant());
        level.playSound(null, pos.x, pos.y, pos.z, ShazamSounds.DEMON_CALL.get(), SoundSource.PLAYERS, 3.0f, 1f);
        level.playSound(null, pos.x, pos.y, pos.z, ShazamSounds.THUNDER.get(), SoundSource.WEATHER, 4.0f, ShazamSounds.tune(0.5f));
        speak(player, "message.shazammod.pact.sealed");
        ShazamPowers.unlockSabbac(player);
    }

    public static void forget(UUID id) {
        PACTS.remove(id);
        FORCED.remove(id);
    }

    public static void clear() {
        PACTS.clear();
        FORCED.clear();
    }
}
