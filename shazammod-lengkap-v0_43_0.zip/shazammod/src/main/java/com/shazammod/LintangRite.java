package com.shazammod;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.registries.DeferredHolder;

/**
 * Eksperimen Evolusi Surya (pengganti ritual magis "Penyatuan Bintang").
 * Serum Helion-7 disuntikkan di bawah sinar matahari langsung; sel tubuh menyerap foton,
 * DNA bermutasi, mitokondria berevolusi jadi Sel Surya. Tanpa suara gaib, tanpa petir.
 * API publik sama dengan versi lama supaya kelas lain (perintah, rival, powers) tetap jalan.
 */
public final class LintangRite {
    public static final int ABSORB = 24;
    public static final int MUTATE = 74;
    public static final int EVOLVE = 104;
    public static final int LENGTH = 136;

    private static final Map<UUID, Long> RITES = new HashMap<>();
    private static final Set<UUID> FORCED = new HashSet<>();

    private LintangRite() {
    }

    public static boolean isAwakening(ServerPlayer p) {
        Long t = RITES.get(p.getUUID());
        return t != null && p.level().getGameTime() - t <= LENGTH + 4;
    }

    public static void tryBegin(ServerPlayer p) {
        ShazamData d = ShazamPowers.data(p);
        String err = null;
        if (isAwakening(p)) err = "message.shazammod.rite.already";
        else if (d.lintangUnlocked()) err = "message.shazammod.rite.already_yours";
        else if (d.transformed()) err = "message.shazammod.rite.human_only";
        else if (KahndaqTrial.isRunning(p) || ShazamTotems.isAwakening(p) || SabbacPact.isAwakening(p)) err = "message.shazammod.rite.busy";
        else if (!PassiveConditions.underSun(p.level(), p.blockPosition())) err = "message.shazammod.rite.need_sun";
        if (err != null) {
            p.displayClientMessage(Component.translatable(err).withStyle(ChatFormatting.GOLD, ChatFormatting.ITALIC), true);
            return;
        }
        begin(p, false);
    }

    public static void begin(ServerPlayer p, boolean forced) {
        if (isAwakening(p)) return;
        UUID id = p.getUUID();
        if (forced) FORCED.add(id); else FORCED.remove(id);
        if (ShazamPowers.isTransformed(p)) ShazamPowers.revert(p, false);
        final long start = p.serverLevel().getGameTime();
        RITES.put(id, start);
        ShazamNetwork.playAnim(p, ShazamAnim.LINTANG_RITE);
        sound(p, ShazamSounds.LINTANG_RITE, 1.3f, 1.15f);
        log(p, "message.shazammod.lab.start", ChatFormatting.AQUA);
        for (int t = 8; t < EVOLVE; t += 6) {
            final int tick = t;
            ShazamPowers.schedule(p, t, sp -> progress(sp, start, tick));
        }
        ShazamPowers.schedule(p, ABSORB, sp -> {
            if (!active(sp, start)) return;
            log(sp, "message.shazammod.lab.absorb", ChatFormatting.GOLD);
            sound(sp, ShazamSounds.RISER, 1.2f, 1.1f);
        });
        ShazamPowers.schedule(p, MUTATE, sp -> {
            if (!active(sp, start)) return;
            log(sp, "message.shazammod.lab.mutate", ChatFormatting.RED);
            sound(sp, ShazamSounds.HEARTBEAT, 1.4f, 1.25f);
            sound(sp, ShazamSounds.POWER_DOWN, 1.0f, 0.7f);
        });
        ShazamPowers.schedule(p, EVOLVE, sp -> finish(sp, start));
    }

    private static boolean active(ServerPlayer p, long start) {
        Long t = RITES.get(p.getUUID());
        return t != null && t.longValue() == start;
    }

    private static void progress(ServerPlayer p, long start, int tick) {
        if (!active(p, start)) return;
        if (!FORCED.contains(p.getUUID()) && tick >= ABSORB && !PassiveConditions.underSun(p.level(), p.blockPosition())) {
            abort(p);
            return;
        }
        String stage;
        float frac;
        if (tick < ABSORB) {
            stage = "message.shazammod.lab.stage.inject";
            frac = tick / (float) ABSORB;
        } else if (tick < MUTATE) {
            stage = "message.shazammod.lab.stage.absorb";
            frac = (tick - ABSORB) / (float) (MUTATE - ABSORB);
        } else {
            stage = "message.shazammod.lab.stage.mutate";
            frac = (tick - MUTATE) / (float) (EVOLVE - MUTATE);
        }
        int pct = Math.max(1, Math.min(100, Math.round(frac * 100f)));
        int full = Math.min(10, pct / 10);
        StringBuilder bar = new StringBuilder();
        for (int i = 0; i < 10; i++) bar.append(i < full ? '\u25AE' : '\u25AF');
        ChatFormatting c = tick < ABSORB ? ChatFormatting.AQUA : tick < MUTATE ? ChatFormatting.GOLD : ChatFormatting.RED;
        p.displayClientMessage(Component.translatable("message.shazammod.lab.bar",
                Component.translatable(stage), bar.toString(), String.valueOf(pct)).withStyle(c), true);
    }

    private static void abort(ServerPlayer p) {
        UUID id = p.getUUID();
        RITES.remove(id);
        FORCED.remove(id);
        log(p, "message.shazammod.lab.abort", ChatFormatting.RED);
        sound(p, ShazamSounds.POWER_DOWN, 1.0f, 0.8f);
        ShazamNetwork.playAnim(p, ShazamAnim.LINTANG_FADE);
    }

    private static void finish(ServerPlayer p, long start) {
        if (!active(p, start)) return;
        UUID id = p.getUUID();
        RITES.remove(id);
        boolean forced = FORCED.remove(id);
        if (ShazamPowers.data(p).lintangUnlocked()) return;
        if (!forced && !consumeSerum(p)) {
            p.displayClientMessage(Component.translatable("message.shazammod.rite.no_crystal").withStyle(ChatFormatting.GRAY), true);
            ShazamNetwork.playAnim(p, ShazamAnim.LINTANG_FADE);
            return;
        }
        sound(p, ShazamSounds.SHOCKWAVE, 2.2f, 0.9f);   // 0.35: dentuman tekanan dari tubuh, bukan lonceng
        sound(p, ShazamSounds.POWER_UP, 1.6f, 0.85f);
        log(p, "message.shazammod.lab.done", ChatFormatting.GOLD);
        ShazamPowers.unlockLintang(p);
    }

    private static boolean consumeSerum(ServerPlayer p) {
        Item serum = (Item) LintangItems.STAR_CRYSTAL.get();
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (!s.isEmpty() && s.is(serum)) {
                s.shrink(1);
                return true;
            }
        }
        return false;
    }

    private static void log(ServerPlayer p, String key, ChatFormatting color) {
        p.sendSystemMessage(Component.translatable("message.shazammod.lab.prefix").withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD)
                .append(Component.literal(" "))
                .append(Component.translatable(key).withStyle(color)));
    }

    @SuppressWarnings("rawtypes")
    private static void sound(ServerPlayer p, DeferredHolder holder, float volume, float pitch) {
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), (SoundEvent) holder.get(), SoundSource.PLAYERS, volume, pitch);
    }

    public static void forget(UUID id) {
        RITES.remove(id);
        FORCED.remove(id);
    }

    public static void clear() {
        RITES.clear();
        FORCED.clear();
    }
}
