package com.shazammod;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Client -> server: Mode Kilat Mercury memukul sasaran ini (target = id entity, move = jenis pukulan 0-3). */
public record ShazamMercuryPayload(int target, int move) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<ShazamMercuryPayload> TYPE =
            new CustomPacketPayload.Type<>(ShazamMod.id("mercury"));

    public static final StreamCodec<ByteBuf, ShazamMercuryPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, ShazamMercuryPayload::target,
            ByteBufCodecs.VAR_INT, ShazamMercuryPayload::move,
            ShazamMercuryPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
