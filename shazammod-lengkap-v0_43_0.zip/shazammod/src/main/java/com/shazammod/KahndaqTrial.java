package com.shazammod;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BiomeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Husk;
import net.minecraft.world.entity.monster.Silverfish;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.living.LivingDropsEvent;

/**
 * Ujian Kahndaq: jalan menjadi BLACK ADAM, beda total dari Shazam (yang mengalahkan enam penjaga kuil dan menyatukan
 * totemnya).
 *
 * 1. Temukan Skarabe Teth-Adam: di peti Piramida Gurun (Desert Temple), atau sesekali dijatuhkan Husk di gurun.
 * 2. Bawa ke tanah Kahndaq (gurun atau badlands), di bawah langit terbuka, dalam wujud MANUSIA, lalu klik kanan.
 * 3. Badai pasir bangkit dan bayangan Teth-Adam bersuara. Tiga gelombang makhluk makam bangkit dari pasir:
 *    prajurit makam, lalu prajurit + kumbang skarabe, lalu Penjaga Makam Teth-Adam yang raksasa.
 * 4. Lulus: skarabe bangkit, petir Kahndaq menyambar, dan kekuatan Black Adam jadi milikmu.
 *    Gagal (mati, keluar, pergi terlalu jauh, berubah wujud, atau waktunya habis): makhluk makam runtuh jadi pasir dan
 *    skarabe tertidur lagi (skarabenya tetap di tasmu, bisa dicoba lagi).
 */
public final class KahndaqTrial {
    private KahndaqTrial() {}

    // ================= Angka-angka yang gampang diutak-atik =================
    public static final int INTRO_TICKS = 70;                  // badai pasir bangkit, suara Teth-Adam
    public static final int WAVE_GAP_TICKS = 50;               // jeda antar-gelombang
    public static final int TIME_LIMIT_TICKS = 20 * 60 * 5;    // 5 menit
    public static final double ARENA_RADIUS = 40.0;            // pergi lebih jauh dari titik mulai = gagal
    public static final int WARRIORS_WAVE_1 = 5;
    public static final int WARRIORS_WAVE_2 = 3;
    public static final int SCARABS_WAVE_2 = 6;
    public static final int WARRIORS_WAVE_3 = 2;
    public static final double WARRIOR_HEALTH = 26.0;
    public static final double SCARAB_HEALTH = 12.0;
    public static final double GUARDIAN_HEALTH = 220.0;
    public static final double GUARDIAN_SCALE = 2.3;           // Penjaga Makam setinggi ±4,5 blok
    public static final double GUARDIAN_DAMAGE = 9.0;
    public static final double GUARDIAN_SPEED = 0.21;
    public static final double GUARDIAN_ARMOR = 10.0;
    public static final float HUSK_SCARAB_CHANCE = 0.02f;      // Husk yang dikalahkan pemain di gurun: 2% menjatuhkan skarabe
    /** Penanda makhluk ujian (sisa ujian yang terputus karena server mati langsung dibuang saat dimuat lagi). */
    public static final String TAG = "shazammod_trial";
    // =========================================================================

    private enum Phase { INTRO, WAVE, GAP, AWAKEN }

    private static final class Trial {
        final UUID player;
        final ResourceKey<Level> dimension;
        final Vec3 center;
        final long started;
        final ServerBossEvent bar;
        final Set<UUID> mobs = new HashSet<>();
        Phase phase = Phase.INTRO;
        int phaseTicks;
        int wave;
        int waveTotal;
        UUID guardian;

        Trial(ServerPlayer player) {
            this.player = player.getUUID();
            this.dimension = player.level().dimension();
            this.center = player.position();
            this.started = player.level().getGameTime();
            this.bar = new ServerBossEvent(Component.translatable("bossbar.shazammod.trial_intro"),
                    BossEvent.BossBarColor.YELLOW, BossEvent.BossBarOverlay.NOTCHED_10);
            this.bar.setProgress(1f);
        }
    }

    private static final Map<UUID, Trial> TRIALS = new HashMap<>();

    // ------------------------------------------------------------------ mulai

    /** Tanah Kahndaq: gurun atau badlands. */
    public static boolean isKahndaq(ServerLevel level, BlockPos pos) {
        Holder<Biome> biome = level.getBiome(pos);
        return biome.is(Biomes.DESERT) || biome.is(BiomeTags.IS_BADLANDS);
    }

    /** Klik kanan Skarabe Teth-Adam. */
    public static void tryBegin(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        ShazamData data = ShazamPowers.data(player);
        String refusal = null;
        if (TRIALS.containsKey(player.getUUID())) {
            refusal = "message.shazammod.trial.already";
        } else if (data.adamUnlocked()) {
            refusal = "message.shazammod.trial.already_yours";
        } else if (data.transformed()) {
            refusal = "message.shazammod.trial.human_only";
        } else if (level.getDifficulty() == Difficulty.PEACEFUL) {
            refusal = "message.shazammod.trial.peaceful";
        } else if (!isKahndaq(level, player.blockPosition())) {
            refusal = "message.shazammod.trial.need_desert";
        } else if (!level.canSeeSky(player.blockPosition().above())) {
            refusal = "message.shazammod.trial.need_sky";
        }
        if (refusal != null) {
            player.displayClientMessage(Component.translatable(refusal).withStyle(ChatFormatting.GOLD, ChatFormatting.ITALIC),
                    true);
            return;
        }
        begin(player);
    }

    /** Mulai ujian di sini (perintah /shazam trial melewati syarat gurun & langit, buat dites). */
    public static void begin(ServerPlayer player) {
        if (TRIALS.containsKey(player.getUUID())) {
            return;
        }
        if (ShazamPowers.isTransformed(player)) {
            ShazamPowers.revert(player, false);
        }
        Trial trial = new Trial(player);
        TRIALS.put(player.getUUID(), trial);
        trial.bar.addPlayer(player);
        ServerLevel level = player.serverLevel();
        ShazamNetwork.playAnim(player, ShazamAnim.KAHNDAQ_TRIAL);
        level.playSound(null, player.getX(), player.getY(), player.getZ(), ShazamSounds.DREAD.get(), SoundSource.HOSTILE,
                1.0f, ShazamSounds.tune(0.5f));
        level.playSound(null, player.getX(), player.getY(), player.getZ(), ShazamSounds.HEARTBEAT.get(), SoundSource.HOSTILE,
                2.0f, ShazamSounds.tune(0.6f));
        speak(player, "message.shazammod.trial.start");
    }

    private static void speak(ServerPlayer player, String key) {
        player.sendSystemMessage(Component.translatable("speaker.shazammod.teth_adam").withStyle(ChatFormatting.GOLD,
                ChatFormatting.BOLD).append(Component.literal(" ")).append(Component.translatable(key)
                .withStyle(ChatFormatting.YELLOW, ChatFormatting.ITALIC)));
    }

    public static boolean isRunning(ServerPlayer player) {
        return TRIALS.containsKey(player.getUUID());
    }

    /** Upacara skarabe bangkit sedang berjalan (pemainnya dilindungi petir, seperti ritual berubah). */
    public static boolean isAwakening(ServerPlayer player) {
        Trial trial = TRIALS.get(player.getUUID());
        return trial != null && trial.phase == Phase.AWAKEN;
    }

    // ------------------------------------------------------------------ tiap tick

    public static void tick(MinecraftServer server) {
        if (TRIALS.isEmpty()) {
            return;
        }
        for (Trial trial : new ArrayList<>(TRIALS.values())) {
            ServerPlayer player = server.getPlayerList().getPlayer(trial.player);
            if (player == null) {
                fail(server, trial, null, "message.shazammod.trial.fail_left");
                continue;
            }
            if (!player.isAlive()) {
                fail(server, trial, player, "message.shazammod.trial.fail_died");
                continue;
            }
            if (player.level().dimension() != trial.dimension
                    || player.position().distanceToSqr(trial.center) > ARENA_RADIUS * ARENA_RADIUS) {
                fail(server, trial, player, "message.shazammod.trial.fail_left");
                continue;
            }
            if (trial.phase != Phase.AWAKEN && ShazamPowers.isTransformed(player)) {
                fail(server, trial, player, "message.shazammod.trial.fail_transformed");
                continue;
            }
            if (trial.phase != Phase.AWAKEN && player.level().getGameTime() - trial.started > TIME_LIMIT_TICKS) {
                fail(server, trial, player, "message.shazammod.trial.fail_time");
                continue;
            }
            tickTrial(player, trial);
        }
    }

    private static void tickTrial(ServerPlayer player, Trial trial) {
        ServerLevel level = player.serverLevel();
        trial.phaseTicks++;
        switch (trial.phase) {
            case INTRO -> {
                if (trial.phaseTicks % 20 == 10) {
                    level.playSound(null, player.getX(), player.getY(), player.getZ(), ShazamSounds.SAND_BURST.get(),
                            SoundSource.AMBIENT, 1.2f, ShazamSounds.tune(0.5f + level.random.nextFloat() * 0.2f));
                }
                trial.bar.setProgress(Mth.clamp(1f - trial.phaseTicks / (float) INTRO_TICKS, 0f, 1f));
                if (trial.phaseTicks >= INTRO_TICKS) {
                    startWave(player, trial, 1);
                }
            }
            case WAVE -> {
                trial.mobs.removeIf(id -> {
                    Entity e = level.getEntity(id);
                    return e == null || !e.isAlive();
                });
                if (trial.phaseTicks % 20 == 0) {   // makhluk makam selalu memburu orang yang membangunkan skarabe
                    for (UUID id : trial.mobs) {
                        if (level.getEntity(id) instanceof Mob mob && mob.getTarget() != player) {
                            mob.setTarget(player);
                        }
                    }
                }
                Entity guardian = trial.guardian == null ? null : level.getEntity(trial.guardian);
                if (guardian instanceof LivingEntity boss && boss.isAlive()) {
                    trial.bar.setProgress(Mth.clamp(boss.getHealth() / Math.max(1f, boss.getMaxHealth()), 0f, 1f));
                } else {
                    trial.bar.setProgress(trial.waveTotal <= 0 ? 0f : Mth.clamp(trial.mobs.size() / (float) trial.waveTotal, 0f, 1f));
                }
                if (trial.mobs.isEmpty()) {
                    if (trial.wave >= 3) {
                        startAwaken(player, trial);
                    } else {
                        trial.phase = Phase.GAP;
                        trial.phaseTicks = 0;
                        trial.bar.setName(Component.translatable("bossbar.shazammod.trial_cleared", trial.wave));
                        trial.bar.setProgress(0f);
                        level.playSound(null, player.getX(), player.getY(), player.getZ(), ShazamSounds.ENERGY_PULSE.get(),
                                SoundSource.PLAYERS, 1.0f, ShazamSounds.tune(0.6f));
                    }
                }
            }
            case GAP -> {
                trial.bar.setProgress(Mth.clamp(trial.phaseTicks / (float) WAVE_GAP_TICKS, 0f, 1f));
                if (trial.phaseTicks >= WAVE_GAP_TICKS) {
                    startWave(player, trial, trial.wave + 1);
                }
            }
            case AWAKEN -> {
                if (trial.phaseTicks >= ShazamAnim.KAHNDAQ_AWAKEN_STRIKE) {
                    succeed(player, trial);
                }
            }
        }
    }

    // ------------------------------------------------------------------ gelombang

    private static void startWave(ServerPlayer player, Trial trial, int wave) {
        ServerLevel level = player.serverLevel();
        trial.wave = wave;
        trial.phase = Phase.WAVE;
        trial.phaseTicks = 0;
        trial.mobs.clear();
        trial.guardian = null;
        speak(player, "message.shazammod.trial.wave" + wave);
        level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.WITHER_SKELETON_AMBIENT,
                SoundSource.HOSTILE, 1.6f, 0.5f);
        switch (wave) {
            case 1 -> {
                for (int i = 0; i < WARRIORS_WAVE_1; i++) {
                    spawnWarrior(player, trial, i, WARRIORS_WAVE_1, false);
                }
            }
            case 2 -> {
                for (int i = 0; i < WARRIORS_WAVE_2; i++) {
                    spawnWarrior(player, trial, i, WARRIORS_WAVE_2, true);
                }
                for (int i = 0; i < SCARABS_WAVE_2; i++) {
                    spawnScarab(player, trial, i);
                }
            }
            default -> {
                spawnGuardian(player, trial);
                for (int i = 0; i < WARRIORS_WAVE_3; i++) {
                    spawnWarrior(player, trial, i, WARRIORS_WAVE_3, true);
                }
                level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.RAVAGER_ROAR, SoundSource.HOSTILE,
                        2.0f, 0.5f);
            }
        }
        trial.waveTotal = trial.mobs.size();
        trial.bar.setName(Component.translatable(wave >= 3 ? "bossbar.shazammod.trial_guardian" : "bossbar.shazammod.trial_wave",
                wave));
        trial.bar.setColor(wave >= 3 ? BossEvent.BossBarColor.RED : BossEvent.BossBarColor.YELLOW);
        trial.bar.setProgress(1f);
    }

    /** Titik muncul di tanah, di cincin sekitar pemain (dari pasir). */
    private static Vec3 spawnPoint(ServerPlayer player, double angle, double distance) {
        ServerLevel level = player.serverLevel();
        double x = player.getX() + Math.cos(angle) * distance, z = player.getZ() + Math.sin(angle) * distance;
        BlockPos top = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, BlockPos.containing(x, player.getY(), z));
        double y = top.getY();
        if (Math.abs(y - player.getY()) > 6.0) {   // tebing / lubang: muncul setinggi pemain saja
            y = player.getY();
        }
        return new Vec3(x, y, z);
    }

    private static void prepare(Mob mob, ServerPlayer player, Trial trial, Vec3 at, String nameKey) {
        mob.moveTo(at.x, at.y, at.z, player.getRandom().nextFloat() * 360f, 0f);
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            mob.setDropChance(slot, 0f);
        }
        mob.setCustomName(Component.translatable(nameKey));
        mob.setPersistenceRequired();
        mob.addTag(TAG);
        mob.setTarget(player);
        trial.mobs.add(mob.getUUID());   // dicatat dulu, supaya nggak dibuang penjaga sisa ujian (onEntityJoin)
        rise(player, at);
    }

    private static void setBase(LivingEntity entity, Holder<Attribute> attribute, double value) {
        AttributeInstance instance = entity.getAttribute(attribute);
        if (instance != null) {
            instance.setBaseValue(value);
        }
    }

    private static void spawnWarrior(ServerPlayer player, Trial trial, int index, int count, boolean armed) {
        ServerLevel level = player.serverLevel();
        Husk husk = EntityType.HUSK.create(level);
        if (husk == null) {
            return;
        }
        double angle = Math.PI * 2.0 * (index + level.random.nextDouble() * 0.5) / count + trial.wave * 0.7;
        Vec3 at = spawnPoint(player, angle, 6.0 + level.random.nextDouble() * 4.0);
        husk.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.GOLDEN_HELMET));
        if (armed) {
            husk.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.GOLDEN_SWORD));
        }
        setBase(husk, Attributes.MAX_HEALTH, WARRIOR_HEALTH);
        husk.setHealth((float) WARRIOR_HEALTH);
        prepare(husk, player, trial, at, "entity.shazammod.tomb_warrior");
        level.addFreshEntity(husk);
    }

    private static void spawnScarab(ServerPlayer player, Trial trial, int index) {
        ServerLevel level = player.serverLevel();
        Silverfish beetle = EntityType.SILVERFISH.create(level);
        if (beetle == null) {
            return;
        }
        double angle = Math.PI * 2.0 * (index + level.random.nextDouble() * 0.6) / SCARABS_WAVE_2;
        Vec3 at = spawnPoint(player, angle, 4.0 + level.random.nextDouble() * 3.0);
        setBase(beetle, Attributes.MAX_HEALTH, SCARAB_HEALTH);
        beetle.setHealth((float) SCARAB_HEALTH);
        prepare(beetle, player, trial, at, "entity.shazammod.tomb_scarab");
        level.addFreshEntity(beetle);
    }

    private static void spawnGuardian(ServerPlayer player, Trial trial) {
        ServerLevel level = player.serverLevel();
        Husk guardian = EntityType.HUSK.create(level);
        if (guardian == null) {
            return;
        }
        Vec3 look = player.getLookAngle();
        double angle = Math.atan2(look.z, look.x);
        Vec3 at = spawnPoint(player, angle, 9.0);
        guardian.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.GOLDEN_HELMET));
        guardian.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.GOLDEN_CHESTPLATE));
        guardian.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.GOLDEN_SWORD));
        setBase(guardian, Attributes.SCALE, GUARDIAN_SCALE);
        setBase(guardian, Attributes.MAX_HEALTH, GUARDIAN_HEALTH);
        setBase(guardian, Attributes.ATTACK_DAMAGE, GUARDIAN_DAMAGE);
        setBase(guardian, Attributes.MOVEMENT_SPEED, GUARDIAN_SPEED);
        setBase(guardian, Attributes.ARMOR, GUARDIAN_ARMOR);
        setBase(guardian, Attributes.KNOCKBACK_RESISTANCE, 0.9);
        guardian.setHealth((float) GUARDIAN_HEALTH);
        prepare(guardian, player, trial, at, "entity.shazammod.tomb_guardian");
        guardian.setCustomNameVisible(true);
        trial.guardian = guardian.getUUID();
        level.addFreshEntity(guardian);
    }

    // ------------------------------------------------------------------ akhir

    private static void startAwaken(ServerPlayer player, Trial trial) {
        ServerLevel level = player.serverLevel();
        trial.phase = Phase.AWAKEN;
        trial.phaseTicks = 0;
        trial.bar.setVisible(false);
        speak(player, "message.shazammod.trial.worthy");
        ShazamNetwork.playAnim(player, ShazamAnim.KAHNDAQ_AWAKEN);
        level.playSound(null, player.getX(), player.getY(), player.getZ(), ShazamSounds.POWER_UP.get(), SoundSource.PLAYERS,
                1.5f, ShazamSounds.tune(0.5f));
        level.playSound(null, player.getX(), player.getY(), player.getZ(), ShazamSounds.AURA_SWELL.get(), SoundSource.PLAYERS,
                1.5f, ShazamSounds.tune(0.45f));
    }

    private static void succeed(ServerPlayer player, Trial trial) {
        ServerLevel level = player.serverLevel();
        // skarabe menyatu ke dada pemilik barunya
        Inventory inventory = player.getInventory();
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack stack = inventory.getItem(i);
            if (!stack.isEmpty() && stack.is(AdamItems.SCARAB.get())) {
                stack.shrink(1);
                break;
            }
        }
        Vec3 pos = player.position();
        ShazamPowers.spawnBolt(level, pos, 2.8f, ShazamForm.BLACK_ADAM.boltVariant());
        level.playSound(null, pos.x, pos.y, pos.z, ShazamSounds.THUNDER.get(), SoundSource.WEATHER, 5.0f, ShazamSounds.tune(0.6f));
        level.playSound(null, pos.x, pos.y, pos.z, ShazamSounds.LIGHTNING_STRIKE.get(), SoundSource.WEATHER, 2.0f, ShazamSounds.tune(0.5f));
        end(level.getServer(), trial, player);
        ShazamPowers.unlockAdam(player);
    }

    private static void fail(MinecraftServer server, Trial trial, ServerPlayer player, String key) {
        if (player != null) {
            player.sendSystemMessage(Component.translatable(key).withStyle(ChatFormatting.RED, ChatFormatting.ITALIC));
        }
        end(server, trial, player);
    }

    /** Bersihkan: makhluk makam yang tersisa runtuh jadi pasir, bar hilang, badai pasir reda. */
    private static void end(MinecraftServer server, Trial trial, ServerPlayer player) {
        TRIALS.remove(trial.player);
        trial.bar.removeAllPlayers();
        ServerLevel level = server.getLevel(trial.dimension);
        if (level != null) {
            for (UUID id : trial.mobs) {
                Entity e = level.getEntity(id);
                if (e != null) {
                    if (player != null) {
                        rise(player, e.position());
                    }
                    e.discard();
                }
            }
        }
        trial.mobs.clear();
        if (player != null) {
            ShazamNetwork.playAnim(player, ShazamAnim.KAHNDAQ_END);
        }
    }

    public static void clear() {
        for (Trial trial : TRIALS.values()) {
            trial.bar.removeAllPlayers();
        }
        TRIALS.clear();
    }

    // ------------------------------------------------------------------ event

    /** Makhluk ujian yang tertinggal (server mati di tengah ujian) dibuang saat dimuat lagi. */
    public static void onEntityJoin(EntityJoinLevelEvent event) {
        Entity entity = event.getEntity();
        if (event.getLevel().isClientSide() || !event.loadedFromDisk() || !entity.getTags().contains(TAG)) {
            return;
        }
        for (Trial trial : TRIALS.values()) {
            if (trial.mobs.contains(entity.getUUID())) {
                return;
            }
        }
        event.setCanceled(true);
    }

    /** Husk yang dikalahkan pemain di gurun kadang menjatuhkan Skarabe Teth-Adam (selain di peti Piramida Gurun). */
    public static void onDrops(LivingDropsEvent event) {
        LivingEntity entity = event.getEntity();
        if (!(entity instanceof Husk) || entity.getTags().contains(TAG) || !(entity.level() instanceof ServerLevel level)
                || !(event.getSource().getEntity() instanceof ServerPlayer)) {
            return;
        }
        if (level.random.nextFloat() < HUSK_SCARAB_CHANCE && isKahndaq(level, entity.blockPosition())) {
            event.getDrops().add(new ItemEntity(level, entity.getX(), entity.getY() + 0.5, entity.getZ(),
                    new ItemStack(AdamItems.SCARAB.get())));
        }
    }

    /** Kabari pemain di sekitar: makhluk bangkit dari / runtuh jadi pasir di titik ini. */
    private static void rise(ServerPlayer player, Vec3 at) {
        ShazamNetwork.playAnim(player, ShazamAnim.KAHNDAQ_RISE, at);
        player.serverLevel().playSound(null, at.x, at.y, at.z, ShazamSounds.SAND_BURST.get(), SoundSource.HOSTILE, 1.2f,
                ShazamSounds.tune(0.6f + player.getRandom().nextFloat() * 0.2f));
    }
}
