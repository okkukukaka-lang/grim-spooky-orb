package com.shazammod;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/**
 * Server -> client: status juara seorang pemain (jubah, hood, pose terbang, mata menyala saat amarah, Mode Kilat
 * Mercury, Muatan Petir penuh) dan juara yang dipilihnya (ShazamForm: tampilan jubah, lambang, dewa-dewa, dan efek ikut
 * juaranya).
 */
public record ShazamStatePayload(int entityId, boolean transformed, boolean flying, boolean hood, boolean rage,
                                 boolean mercury, int form, boolean charged) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<ShazamStatePayload> TYPE =
            new CustomPacketPayload.Type<>(ShazamMod.id("state"));

    private static final int TRANSFORMED = 1, FLYING = 2, HOOD = 4, RAGE = 8, MERCURY = 16, CHARGED = 32;

    // Semua status ya/tidak dipadatkan jadi satu angka (lebih hemat, dan nggak terbatas jumlah kolom composite)
    public static final StreamCodec<ByteBuf, ShazamStatePayload> STREAM_CODEC = StreamCodec.of(
            (buf, p) -> {
                ByteBufCodecs.VAR_INT.encode(buf, p.entityId());
                int flags = (p.transformed() ? TRANSFORMED : 0) | (p.flying() ? FLYING : 0) | (p.hood() ? HOOD : 0)
                        | (p.rage() ? RAGE : 0) | (p.mercury() ? MERCURY : 0) | (p.charged() ? CHARGED : 0);
                ByteBufCodecs.VAR_INT.encode(buf, flags);
                ByteBufCodecs.VAR_INT.encode(buf, p.form());
            },
            buf -> {
                int entityId = ByteBufCodecs.VAR_INT.decode(buf);
                int flags = ByteBufCodecs.VAR_INT.decode(buf);
                int form = ByteBufCodecs.VAR_INT.decode(buf);
                return new ShazamStatePayload(entityId, (flags & TRANSFORMED) != 0, (flags & FLYING) != 0,
                        (flags & HOOD) != 0, (flags & RAGE) != 0, (flags & MERCURY) != 0, form, (flags & CHARGED) != 0);
            });

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
