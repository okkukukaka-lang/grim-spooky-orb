package com.shazammod;

import java.util.Comparator;
import java.util.List;
import java.util.UUID;

import com.shazammod.rival.RivalChampion;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * 0.30 Prajurit Iblis (Pasukan Iblis, tombol J Sabbac): iblis berkulit hangus berurat bara yang bangkit dari retakan api
 * neraka, bertarung 30 detik, lalu runtuh jadi bara.
 *
 * Prajurit milik pemain (sekutu) memburu monster di sekitar tuannya dan nggak pernah menyerang pemain. Prajurit milik
 * Rival Sabbac (musuh) memburu juara (pemain yang sedang berubah wujud). Damage-nya dari api neraka: sasaran ikut terbakar.
 */
public class DemonSoldier extends Monster {
    // ======= Angka yang gampang diutak-atik =======
    public static final int LIFE_TICKS = 600;           // 30 detik
    public static final double HEALTH = 40.0;
    public static final double DAMAGE = 8.0;
    private static final float FIRE_SECONDS = 3f;
    private static final float HOSTILE_CLASH_DAMAGE = 6f;   // prajurit rival ke juara (menembus tahan banting juara)
    private static final double HUNT_RADIUS = 18.0;
    // =========================================================================

    private static final EntityDataAccessor<Boolean> DATA_ALLY =
            SynchedEntityData.defineId(DemonSoldier.class, EntityDataSerializers.BOOLEAN);

    private UUID owner;
    private int life = LIFE_TICKS;

    public DemonSoldier(EntityType<? extends DemonSoldier> type, Level level) {
        super(type, level);
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, HEALTH)
                .add(Attributes.ATTACK_DAMAGE, DAMAGE)
                .add(Attributes.MOVEMENT_SPEED, 0.32)
                .add(Attributes.ARMOR, 6.0)
                .add(Attributes.FOLLOW_RANGE, 24.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.4);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_ALLY, true);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.25, true));
        this.goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 0.8));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
    }

    /** Siapkan prajurit: tuannya (pemain = sekutu, rival = musuh). */
    public void bind(Entity master, boolean ally) {
        this.owner = master.getUUID();
        this.entityData.set(DATA_ALLY, ally);
        this.life = LIFE_TICKS;
        this.setPersistenceRequired();
    }

    public boolean isAlly() {
        return this.entityData.get(DATA_ALLY);
    }

    public UUID owner() {
        return owner;
    }

    public int lifeLeft() {
        return life;
    }

    /** Prajurit iblis sekutu pemain mana pun: nggak dihitung musuh oleh skill dan pasif juara. */
    public static boolean isFriendly(Entity entity) {
        return entity instanceof DemonSoldier soldier && soldier.isAlly();
    }

    /** Prajurit sekutu milik pemain ini. */
    public static boolean servesPlayer(Entity entity, Entity player) {
        return entity instanceof DemonSoldier soldier && soldier.isAlly() && player != null
                && player.getUUID().equals(soldier.owner);
    }

    private Entity master() {
        if (owner == null || !(this.level() instanceof ServerLevel level)) {
            return null;
        }
        if (isAlly()) {
            return level.getServer().getPlayerList().getPlayer(owner);
        }
        return level.getEntity(owner);
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        Entity master = master();
        if (--life <= 0 || master == null || !master.isAlive() || master.level() != this.level()) {
            crumble();
            return;
        }
        if (this.tickCount % 10 == 0) {
            LivingEntity target = isAlly() ? huntForPlayer(master) : huntForRival(master);
            if (target != null && target != this.getTarget()) {
                this.setTarget(target);
            } else if (target == null && this.getTarget() != null && !this.getTarget().isAlive()) {
                this.setTarget(null);
            }
            if (this.getTarget() == null) {
                double d = this.distanceToSqr(master);
                if (d > 32.0 * 32.0) {   // tertinggal jauh: menyeruak lagi di dekat tuannya
                    this.teleportTo(master.getX() + (this.random.nextDouble() - 0.5) * 4.0, master.getY(),
                            master.getZ() + (this.random.nextDouble() - 0.5) * 4.0);
                } else if (d > 6.0 * 6.0) {
                    this.getNavigation().moveTo(master, 1.2);
                }
            }
        }
    }

    /** Sekutu pemain: monster yang menyerang tuannya, yang sedang dihajar tuannya, atau yang terdekat. */
    private LivingEntity huntForPlayer(Entity master) {
        if (master instanceof LivingEntity lord && lord.getLastHurtMob() instanceof Enemy
                && lord.getLastHurtMob().isAlive() && !isFriendly(lord.getLastHurtMob())
                && lord.getLastHurtMob().distanceToSqr(this) < HUNT_RADIUS * HUNT_RADIUS * 2) {
            return lord.getLastHurtMob();
        }
        List<LivingEntity> foes = this.level().getEntitiesOfClass(LivingEntity.class,
                this.getBoundingBox().inflate(HUNT_RADIUS),
                m -> m.isAlive() && m instanceof Enemy && !isFriendly(m) && m != this);
        if (foes.isEmpty()) {
            return null;
        }
        for (LivingEntity foe : foes) {
            if (foe instanceof net.minecraft.world.entity.Mob mob && mob.getTarget() == master) {
                return foe;
            }
        }
        foes.sort(Comparator.comparingDouble(m -> m.distanceToSqr(this)));
        return foes.get(0);
    }

    /** Prajurit Rival Sabbac: sasaran rivalnya, atau juara / hewan peliharaan terdekat. */
    private LivingEntity huntForRival(Entity master) {
        if (master instanceof RivalChampion rival && rival.getTarget() != null && rival.getTarget().isAlive()) {
            return rival.getTarget();
        }
        List<LivingEntity> foes = this.level().getEntitiesOfClass(LivingEntity.class,
                this.getBoundingBox().inflate(HUNT_RADIUS), m -> m.isAlive() && isChampionSide(m));
        if (foes.isEmpty()) {
            return null;
        }
        foes.sort(Comparator.comparingDouble(m -> m.distanceToSqr(this)));
        return foes.get(0);
    }

    private static boolean isChampionSide(LivingEntity m) {
        return (m instanceof ServerPlayer p && ShazamPowers.isTransformed(p) && !p.isCreative() && !p.isSpectator())
                || (m instanceof TamableAnimal pet && pet.isTame()) || m instanceof IronGolem || isFriendly(m);
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hit;
        if (!isAlly() && target instanceof ServerPlayer player && ShazamPowers.isTransformed(player)) {
            hit = target.hurt(RivalChampion.clash(this.level(), this), HOSTILE_CLASH_DAMAGE);
            if (hit) {
                ShazamPowers.wound(player);
            }
        } else {
            hit = super.doHurtTarget(target);
        }
        if (hit) {
            target.igniteForSeconds(FIRE_SECONDS);
        }
        return hit;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        Entity attacker = source.getEntity();
        if (isAlly() && attacker != null && (attacker.getUUID().equals(owner) || isFriendly(attacker))) {
            return false;   // tuannya sendiri (atau prajurit lain) nggak melukai
        }
        if (!isAlly() && (attacker instanceof RivalChampion || attacker instanceof DemonSoldier)) {
            return false;
        }
        return super.hurt(source, amount);
    }

    @Override
    public boolean canAttack(LivingEntity target) {
        if (isAlly() && (target instanceof net.minecraft.world.entity.player.Player || isFriendly(target))) {
            return false;
        }
        return super.canAttack(target);
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        announce();
    }

    /** Waktunya habis (atau tuannya pergi): runtuh jadi bara. */
    public void crumble() {
        if (!this.isRemoved()) {
            announce();
            this.discard();
        }
    }

    private void announce() {
        Entity master = master();
        Vec3 at = this.position();
        if (master instanceof ServerPlayer player) {
            ShazamNetwork.playAnim(player, ShazamAnim.SABBAC_RISE, at);
        } else if (master instanceof RivalChampion rival) {
            rival.anim(ShazamAnim.SABBAC_RISE, at);
        }
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.WITHER_SKELETON_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.WITHER_SKELETON_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.WITHER_SKELETON_DEATH;
    }

    @Override
    public float getVoicePitch() {
        return 0.55f + this.random.nextFloat() * 0.1f;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Life", life);
        tag.putBoolean("Ally", isAlly());
        if (owner != null) {
            tag.putUUID("Owner", owner);
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        life = tag.contains("Life") ? tag.getInt("Life") : LIFE_TICKS;
        this.entityData.set(DATA_ALLY, !tag.contains("Ally") || tag.getBoolean("Ally"));
        owner = tag.hasUUID("Owner") ? tag.getUUID("Owner") : null;
    }
}
