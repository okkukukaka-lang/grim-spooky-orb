package com.shazammod;

import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/**
 * 0.30 Mahkota Sabbac: ditempa dari Eternium seperti mahkota raja Ahk-Ton di film Black Adam. Klik kanan dalam wujud
 * manusia, jauh dari matahari (malam hari, di gua / di dalam ruangan, atau di Nether / End), untuk Perjanjian Enam Iblis
 * (lihat SabbacPact).
 */
public class SabbacCrownItem extends Item {
    public SabbacCrownItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player instanceof ServerPlayer serverPlayer) {
            SabbacPact.tryBegin(serverPlayer);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.shazammod.crown_of_sabbac.lore").withStyle(ChatFormatting.DARK_RED,
                ChatFormatting.ITALIC));
        tooltip.add(Component.translatable("item.shazammod.crown_of_sabbac.hint").withStyle(ChatFormatting.GRAY));
    }
}
