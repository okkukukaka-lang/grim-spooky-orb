package com.shazammod;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

/**
 * Jalan menjadi SHAZAM: kalahkan enam penjaga kuil (Solomon, Hercules, Atlas, Zeus, Achilles, Mercury), kumpulkan
 * keenam totemnya, lalu ucapkan SHAZAM (atau tombol G) sambil membawa semuanya. Keenam totem terangkat, berputar
 * mengelilingimu, menyatu jadi satu cahaya, dan petir emas Penyihir menyambar: kekuatan Shazam terbuka.
 *
 * Black Adam punya jalan yang beda total: Skarabe Teth-Adam dan Ujian Kahndaq di gurun (lihat KahndaqTrial).
 */
public final class ShazamTotems {
    private ShazamTotems() {}

    private static final List<Supplier<? extends Item>> TOTEMS = List.of(
            ShazamItems.TOTEM_SOLOMON, ShazamItems.TOTEM_HERCULES, ShazamItems.TOTEM_ATLAS,
            ShazamItems.TOTEM_ZEUS, ShazamItems.TOTEM_ACHILLES, ShazamItems.TOTEM_MERCURY);

    /** Pemain yang sedang menjalani upacara totem: game time mulai. */
    private static final Map<UUID, Long> AWAKENING = new HashMap<>();

    /** Keenam totem ada di inventory. */
    public static boolean hasAll(ServerPlayer player) {
        for (Supplier<? extends Item> totem : TOTEMS) {
            if (find(player.getInventory(), totem.get()) < 0) {
                return false;
            }
        }
        return true;
    }

    private static int find(Inventory inventory, Item item) {
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack stack = inventory.getItem(i);
            if (!stack.isEmpty() && stack.is(item)) {
                return i;
            }
        }
        return -1;
    }

    public static boolean isAwakening(ServerPlayer player) {
        Long start = AWAKENING.get(player.getUUID());
        return start != null && player.level().getGameTime() - start <= ShazamAnim.SHAZAM_CHOSEN_TICKS + 5;
    }

    /** Upacara enam totem. Totemnya baru dipakai saat petir menyambar (keluar di tengah upacara: nggak hilang). */
    public static void awaken(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        AWAKENING.put(player.getUUID(), level.getGameTime());
        ShazamNetwork.playAnim(player, ShazamAnim.SHAZAM_CHOSEN);
        level.playSound(null, player.getX(), player.getY(), player.getZ(), ShazamSounds.AURA_SWELL.get(), SoundSource.PLAYERS,
                1.6f, ShazamSounds.tune(0.7f));
        level.playSound(null, player.getX(), player.getY(), player.getZ(), ShazamSounds.POWER_UP.get(), SoundSource.PLAYERS,
                1.2f, ShazamSounds.tune(0.8f));
        player.sendSystemMessage(Component.translatable("message.shazammod.totems_rise")
                .withStyle(ChatFormatting.YELLOW, ChatFormatting.ITALIC));
        ShazamPowers.schedule(player, ShazamAnim.SHAZAM_CHOSEN_STRIKE, p -> {
            AWAKENING.remove(p.getUUID());
            if (!hasAll(p) || ShazamPowers.data(p).unlocked()) {
                return;   // totemnya dibuang/dipindah di tengah upacara
            }
            for (Supplier<? extends Item> totem : TOTEMS) {
                int slot = find(p.getInventory(), totem.get());
                if (slot >= 0) {
                    p.getInventory().getItem(slot).shrink(1);
                }
            }
            ServerLevel l = p.serverLevel();
            Vec3 pos = p.position();
            ShazamPowers.spawnBolt(l, pos, 2.4f, ShazamForm.SHAZAM.boltVariant());
            l.playSound(null, pos.x, pos.y, pos.z, ShazamSounds.THUNDER.get(), SoundSource.WEATHER, 4.0f, ShazamSounds.tune(0.75f));
            l.playSound(null, pos.x, pos.y, pos.z, ShazamSounds.DIVINE.get(), SoundSource.PLAYERS, 1.2f, ShazamSounds.tune(0.9f));
            ShazamPowers.unlock(p);
        });
    }

    public static void forget(UUID id) {
        AWAKENING.remove(id);
    }
}
