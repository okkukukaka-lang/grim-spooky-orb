package com.shazammod;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * 0.43 PROJEK HELION-6, juara kelima (orisinal). Eksperimen Helion sebelum Lintang: serumnya disuntikkan di bawah radiasi
 * Batu Cryon, bukan matahari, jadi sel tubuhnya jadi Sel Cryon yang HIDUP dari radiasi Cryon. Kebalikan Lintang:
 * - Sumber tenaga: dekat bijih/pecahan Cryon terisi deras, membawa Cryon terisi pelan, Nether (penuh Cryon) & tempat gelap
 *   terisi sedikit. Tombol M (Hirup Cryon) meremukkan sebutir Pecahan Cryon lalu menghirup radiasinya: energi & darah
 *   melonjak, lalu Lonjakan Cryon 12 detik (tinju & ketahanan naik, aura radiasi melukai musuh di dekatnya).
 * - Kelemahan: MATAHARI. Siang di bawah langit terbuka (nggak hujan) radiasinya terbakar habis: energi terkuras (makin terik
 *   makin cepat), daya tinggal 60%, lari melambat, darah nggak pulih, Kulit Cryon nggak jalan, dan kalau radiasinya tinggal
 *   sedikit nggak bisa terbang. Habis = terlempar balik jadi manusia. Batu Cryon di dekatnya menetralkan kelemahan ini.
 * - Musuh bebuyutan Lintang: tinju Helion-6 membawa radiasi Cryon (menembus Kulit Baja Lintang & menghisap cahayanya), dan
 *   Helion-6 yang sedang berubah wujud membuat Lintang di dekatnya melemah. Sebaliknya tinju Lintang membakar sel Cryon.
 *
 * Skill (huruf H-E-L-I-O-N-6 di HUD, tombol sama dengan juara lain):
 * Z  H - Hempasan Lesat  : melesat lurus sejauh 22 blok, menghantam & melempar semua musuh di jalurnya, gelombang di ujung.
 * X  E - Emisi Cryon     : mata mengumpulkan radiasi, lalu dua sinar Cryon 2,5 detik mengikuti arah pandang: menembus 5
 *                          musuh, membakar & melemahkan (radiasi), menyulut permukaan yang disorot.
 * V  I - Injakan Cryon   : melompat kecil lalu berlutut menghantam tanah: gelombang radiasi 13 blok melambungkan musuh,
 *                          tanah retak bercahaya, gempa susulan 19 blok.
 * R  6 - Supernova-6     : 3 detik meringkuk menyerap radiasi (musuh tersedot, badan hampir kebal), lalu SEMUA radiasi
 *                          di atas 60 diledakkan: makin penuh makin luas & sakit; sisa zona radiasi beberapa detik.
 * C/B/N L, O, N           : menyusul di ronde berikutnya.
 * M  Hirup Cryon         : (butuh Pecahan Cryon) lihat di atas.
 * Pasif: Denyut Cryon tiap 2 detik (padam di bawah matahari), Tinju Cryon (muatan penuh), Kulit Cryon (serangan lemah
 * memantul), dan radiasi yang melemahkan musuh yang kena (Lemah & Lambat).
 */
public final class HelionSkills {
    private HelionSkills() {}

    public enum Skill {
        HEMPAS(18f, 50, true),      // H - Hempasan Lesat (Z)
        EMISI(25f, 120, true),      // E - Emisi Cryon: sinar mata (X)
        LIDAH(0f, 0, false),        // L - (menyusul) (C)
        INJAK(30f, 160, true),      // I - Injakan Cryon (V)
        OMBAK(0f, 0, false),        // O - (menyusul) (B)
        NADIR(0f, 0, false),        // N - (menyusul) (N)
        SUPERNOVA(0f, 900, true);   // 6 - Supernova-6 (R): butuh NOVA_MIN_ENERGY, membakar hampir semua radiasi

        public final float cost;
        public final int cooldownTicks;
        public final boolean ready;

        Skill(float cost, int cooldownTicks, boolean ready) {
            this.cost = cost;
            this.cooldownTicks = cooldownTicks;
            this.ready = ready;
        }
    }

    // ================= Angka-angka yang gampang diutak-atik =================
    // Daya Cryon (kekuatan ikut radiasi tersimpan)
    public static final float FULL_POWER_ENERGY = 400f;   // radiasi segini ke atas: kekuatan penuh
    public static final float MIN_POWER = 0.8f;           // radiasi habis: masih 80%
    public static final float SUN_POWER = 0.6f;           // di bawah matahari: daya tinggal 60%
    public static final float WEAK_TAKEN_BONUS = 0.3f;    // damage diterima naik (1 - daya) x ini
    public static final float SURGE_POWER = 1.3f;         // Lonjakan Cryon: daya x1,3
    public static final float SURGE_TAKEN = 0.8f;         // ... dan damage diterima x0,8
    // Radiasi (energi) per detik
    public static final float CRYON_CHARGE = 25f;         // dekat bijih / pecahan Cryon di dunia
    public static final float CARRY_CHARGE = 6f;          // membawa Cryon di inventori
    public static final float NETHER_CHARGE = 4f;         // Nether penuh Cryon
    public static final float DARK_CHARGE = 1.5f;         // malam / di bawah tanah / di dalam ruangan
    public static final float SHADE_DRAIN = 0.5f;         // siang tapi teduh atau hujan
    public static final float SUN_DRAIN_MIN = 6f;         // di bawah matahari: 6 + 16 x terik matahari (tengah hari ±22/detik)
    public static final float SUN_DRAIN = 16f;
    public static final float HUMAN_RECHARGE = 6f;        // wujud manusia (bukan di bawah matahari)
    public static final float REGEN_PER_SECOND = 4f;      // x2,5 dekat Cryon, x1,5 di kegelapan, 0 di bawah matahari
    // Kelemahan matahari
    private static final double SUN_SLOW = -0.25;
    public static final float SUN_GROUND_ENERGY = 150f;   // di bawah matahari & radiasi di bawah segini: nggak bisa terbang
    private static final int SCAN_TICKS = 10;
    private static final int CRYON_BLOCK_RADIUS = 4;
    private static final double CRYON_ENTITY_RADIUS = 6.0;
    // Kulit Cryon (serangan di bawah segini memantul; 0 = mati)
    public static final float TOUGH_SKIN = 10f;
    // H - Hempasan Lesat
    private static final double DASH_RANGE = 22.0;
    private static final double DASH_WIDTH = 2.2;
    private static final float DASH_DAMAGE = 34f;
    private static final double DASH_IMPULSE = 1.9;
    private static final double DASH_END_RADIUS = 4.5;
    private static final float DASH_END_DAMAGE = 14f;
    // E - Emisi Cryon
    public static final double BEAM_RANGE = 56.0;
    private static final float BEAM_DAMAGE = 8f;           // tiap 2 tick, dikali daya
    private static final int BEAM_PIERCE = 5;
    private static final float BEAM_FIRE_SECONDS = 3f;
    private static final boolean BEAM_BURNS_BLOCKS = true; // false = sinar nggak pernah menyulut blok
    // I - Injakan Cryon
    private static final double QUAKE_RADIUS = 13.0;
    private static final double QUAKE_CORE = 3.5;          // di dalam sini damage penuh, di luarnya turun ~1/jarak
    private static final float QUAKE_DAMAGE = 48f;
    private static final double QUAKE_LIFT = 0.95;
    private static final double QUAKE_PUSH = 1.6;
    private static final int AFTERSHOCK_DELAY = 8;
    private static final double AFTERSHOCK_RADIUS = 19.0;
    private static final float AFTERSHOCK_DAMAGE = 12f;
    // 6 - Supernova-6
    public static final float NOVA_MIN_ENERGY = 300f;
    private static final float NOVA_KEEP_ENERGY = 60f;
    private static final double NOVA_RADIUS_MIN = 14.0;
    private static final double NOVA_RADIUS_PER_ENERGY = 0.019;   // radiasi 1000 -> ±32 blok
    private static final double NOVA_CORE = 6.0;
    private static final float NOVA_MIN_DAMAGE = 80f;
    private static final float NOVA_DAMAGE_PER_ENERGY = 0.14f;   // radiasi 1000 -> ±210
    private static final double NOVA_PULL_RADIUS = 16.0;
    private static final float NOVA_CHARGE_TAKEN = 0.3f;         // selama menyerap radiasi: damage diterima x0,3
    private static final int NOVA_ZONE_PULSES = 5;
    private static final float NOVA_ZONE_DAMAGE = 6f;
    // M - Hirup Cryon
    public static final int INHALE_COOLDOWN_TICKS = 400;
    private static final float INHALE_ENERGY = 450f;
    private static final float INHALE_HEAL = 150f;
    public static final int SURGE_TICKS = 240;
    private static final double SURGE_SPEED = 0.15;
    private static final double SURGE_AURA_RADIUS = 5.0;
    private static final float SURGE_AURA_DAMAGE = 4f;
    // Denyut Cryon (tiap 2 detik) & Tinju Cryon (muatan penuh)
    private static final double PULSE_SPLASH_RADIUS = 3.5;
    private static final float PULSE_SPLASH_DAMAGE = 5f;
    private static final float CRYON_PUNCH_CHAIN_DAMAGE = 16f;
    private static final double CRYON_PUNCH_RADIUS = 7.0;
    private static final int CRYON_PUNCH_TARGETS = 3;
    private static final double CRYON_PUNCH_KNOCKBACK = 2.2;
    private static final int SICK_TICKS = 80;                     // radiasi: musuh Lemah & Lambat
    // =========================================================================

    private static final ResourceLocation SUN_SLOW_ID = ShazamMod.id("helion_sun_slow");
    private static final ResourceLocation SURGE_SPEED_ID = ShazamMod.id("helion_surge_speed");

    private static final Map<UUID, long[]> READY_AT = new HashMap<>();
    private static final Map<UUID, Long> INHALE_READY_AT = new HashMap<>();
    private static final Map<UUID, Long> BEAM_START = new HashMap<>();
    private static final Map<UUID, Long> BEAM_UNTIL = new HashMap<>();
    private static final Map<UUID, Long> NOVA_AT = new HashMap<>();      // tick Supernova meledak (selama menyerap)
    private static final Map<UUID, Long> SURGE_UNTIL = new HashMap<>();
    private static final Map<UUID, Long> CRYON_UNTIL = new HashMap<>();  // bijih/pecahan Cryon di dunia sekitar
    private static final Map<UUID, Long> CARRY_UNTIL = new HashMap<>();  // membawa Cryon di inventori
    private static final Set<UUID> SUN_ON = new HashSet<>();             // sedang terbakar matahari
    private static final Map<UUID, Long> QUIET_UNTIL = new HashMap<>();

    // ----------------------------------------------------------- Pakai skill

    public static void use(ServerPlayer player, Skill skill) {
        if (!ShazamPowers.isHelion(player)) {
            if (ShazamPowers.data(player).anyUnlocked()) {
                player.displayClientMessage(Component.translatable("message.shazammod.not_transformed_helion")
                        .withStyle(ChatFormatting.GRAY), true);
            }
            return;
        }
        if (!skill.ready) {
            player.displayClientMessage(Component.translatable("message.shazammod.helion_soon",
                    Component.translatable("skill.shazammod.helion." + skill.name().toLowerCase(Locale.ROOT)))
                    .withStyle(ChatFormatting.DARK_GREEN), true);
            return;
        }
        if (isNovaCharging(player) || cooldownTicks(player, skill) > 0) {
            return;
        }
        float cost = skill == Skill.SUPERNOVA ? NOVA_MIN_ENERGY : skill.cost;
        if (ShazamPowers.data(player).energy() < cost) {
            player.displayClientMessage(Component.translatable("message.shazammod.skill_no_energy", Math.round(cost))
                    .withStyle(ChatFormatting.RED), true);
            return;
        }
        boolean used = switch (skill) {
            case HEMPAS -> hempas(player);
            case EMISI -> emisi(player);
            case INJAK -> injak(player);
            case SUPERNOVA -> supernova(player);
            default -> false;
        };
        if (!used) {
            player.displayClientMessage(Component.translatable("message.shazammod.no_target").withStyle(ChatFormatting.GRAY), true);
            return;
        }
        if (skill != Skill.SUPERNOVA) {   // Supernova membakar radiasinya saat meledak
            ShazamData data = ShazamPowers.data(player);
            ShazamPowers.setData(player, data.withEnergy(data.energy() - skill.cost));
        }
        READY_AT.computeIfAbsent(player.getUUID(), id -> new long[Skill.values().length])[skill.ordinal()] =
                player.level().getGameTime() + skill.cooldownTicks;
        ShazamNetwork.sync(player);
    }

    public static int cooldownTicks(ServerPlayer player, Skill skill) {
        long[] readyAt = READY_AT.get(player.getUUID());
        if (readyAt == null) {
            return 0;
        }
        long left = readyAt[skill.ordinal()] - player.level().getGameTime();
        return left > 0 ? (int) left : 0;
    }

    public static int inhaleCooldownTicks(ServerPlayer player) {
        Long ready = INHALE_READY_AT.get(player.getUUID());
        if (ready == null) {
            return 0;
        }
        long left = ready - player.level().getGameTime();
        return left > 0 ? (int) left : 0;
    }

    /** Efek dijalankan beberapa tick lagi, dan dibatalkan kalau pemain keburu balik jadi manusia. */
    private static void later(ServerPlayer player, int delay, Consumer<ServerPlayer> action) {
        ShazamPowers.schedule(player, delay, p -> {
            if (ShazamPowers.isHelion(p)) {
                action.accept(p);
            }
        });
    }

    // ----------------------------------------------------------- Daya Cryon

    /** 0..1,3: kekuatan Helion-6 dari radiasi tersimpan, dikali SUN_POWER di bawah matahari dan SURGE_POWER saat Lonjakan. */
    public static float powerAt(float energy, boolean sun, boolean surge) {
        float k = energy >= FULL_POWER_ENERGY ? 1f : MIN_POWER + (1f - MIN_POWER) * Math.max(0f, energy) / FULL_POWER_ENERGY;
        if (sun) {
            k *= SUN_POWER;
        }
        if (surge) {
            k *= SURGE_POWER;
        }
        return k;
    }

    public static float power(ServerPlayer player) {
        return powerAt(ShazamPowers.data(player).energy(), weakened(player), isSurging(player));
    }

    /** Persen Daya Cryon buat HUD. */
    public static int powerPercent(ServerPlayer player) {
        return Math.round(power(player) * 100f);
    }

    /** Damage yang diterima pada daya ini (tanpa Lonjakan & Supernova). */
    public static float takenAt(float power) {
        return ShazamPowers.HELION_DAMAGE_TAKEN_MULTIPLIER + Math.max(0f, 1f - power) * WEAK_TAKEN_BONUS;
    }

    /** Tinju tangan kosong pada daya ini. */
    public static float punchAt(float power) {
        return ShazamPowers.HELION_PUNCH_MULTIPLIER * power;
    }

    public static float damageTakenMultiplier(ServerPlayer player) {
        float taken = takenAt(Math.min(1f, power(player)));
        if (isSurging(player)) {
            taken *= SURGE_TAKEN;
        }
        if (isNovaCharging(player)) {
            taken *= NOVA_CHARGE_TAKEN;
        }
        return taken;
    }

    public static float punchMultiplier(ServerPlayer player) {
        return punchAt(power(player));
    }

    /** Siang di bawah langit terbuka (nggak hujan). */
    public static boolean sunExposed(ServerPlayer player) {
        return ShazamPowers.isInSun(player);
    }

    /** Sel Cryon sedang terbakar matahari (di bawah matahari tanpa Batu Cryon di dekatnya). */
    public static boolean weakened(ServerPlayer player) {
        return SUN_ON.contains(player.getUUID());
    }

    /** Bijih / pecahan Cryon di dunia sekitar (sumber tenaga yang deras). */
    public static boolean cryonWorld(ServerPlayer player) {
        Long until = CRYON_UNTIL.get(player.getUUID());
        return until != null && until > player.level().getGameTime();
    }

    public static boolean carrying(ServerPlayer player) {
        Long until = CARRY_UNTIL.get(player.getUUID());
        return until != null && until > player.level().getGameTime();
    }

    /** Ada Cryon di dekatnya (dunia atau inventori): buat HUD. */
    public static boolean cryonNear(ServerPlayer player) {
        return cryonWorld(player) || carrying(player);
    }

    /** Di bawah matahari dengan radiasi tinggal sedikit: nggak bisa terbang. */
    public static boolean grounded(ServerPlayer player) {
        return weakened(player) && ShazamPowers.data(player).energy() < SUN_GROUND_ENERGY;
    }

    public static boolean isSurging(ServerPlayer player) {
        Long until = SURGE_UNTIL.get(player.getUUID());
        return until != null && until > player.level().getGameTime();
    }

    public static boolean isNovaCharging(ServerPlayer player) {
        return NOVA_AT.containsKey(player.getUUID());
    }

    /** Energi per detik (ShazamPowers.tick): Cryon mengisi, matahari membakar. */
    public static float energyPerSecond(ServerPlayer player, boolean transformed) {
        if (player.tickCount % SCAN_TICKS == 0) {
            scanCryon(player);
        }
        boolean world = cryonWorld(player);
        boolean carry = carrying(player);
        boolean sun = ShazamPowers.isInSun(player);
        Level level = player.level();
        if (transformed) {
            if (world) {
                return CRYON_CHARGE;
            }
            if (sun) {   // makin terik makin cepat terbakar (sinus ketinggian matahari, cuaca)
                return -(SUN_DRAIN_MIN + SUN_DRAIN * LintangPhysics.solarIrradiance(player)) + (carry ? CARRY_CHARGE : 0f);
            }
            float base = PassiveConditions.inferno(level) ? NETHER_CHARGE
                    : PassiveConditions.darkness(level) || !level.canSeeSky(player.blockPosition().above()) ? DARK_CHARGE
                    : -SHADE_DRAIN;
            return base + (carry ? CARRY_CHARGE : 0f);
        }
        if (world) {
            return CRYON_CHARGE * 1.2f;
        }
        if (sun) {
            return carry ? CARRY_CHARGE * 0.5f : 0f;
        }
        return HUMAN_RECHARGE * (PassiveConditions.inferno(level) ? 1.5f : 1f) + (carry ? CARRY_CHARGE : 0f);
    }

    /** Darah pulih per detik: 0 di bawah matahari, lebih cepat dekat Cryon & di kegelapan, x2 saat Lonjakan. */
    public static float regenPerSecond(ServerPlayer player) {
        if (weakened(player)) {
            return 0f;
        }
        float r = REGEN_PER_SECOND;
        if (cryonWorld(player)) {
            r *= 2.5f;
        } else if (PassiveConditions.darkness(player.level())) {
            r *= 1.5f;
        }
        return isSurging(player) ? r * 2f : r;
    }

    // ----------------------------------------------------------- Tiap tick

    public static void tick(ServerPlayer player) {
        UUID id = player.getUUID();
        long now = player.level().getGameTime();
        if (player.tickCount % SCAN_TICKS == 0) {
            sunScan(player, now);
        }
        Long beamEnd = BEAM_UNTIL.get(id);
        if (beamEnd != null) {
            Long beamStart = BEAM_START.get(id);
            if (now >= beamEnd) {
                BEAM_UNTIL.remove(id);
                BEAM_START.remove(id);
            } else if (beamStart != null && now >= beamStart && (now - beamStart) % 2 == 0) {
                beamStep(player);
            }
        }
        Long nova = NOVA_AT.get(id);
        if (nova != null && now < nova && (nova - now) % 5 == 0) {
            novaPull(player);
        }
        Long surge = SURGE_UNTIL.get(id);
        if (surge != null) {
            if (now >= surge) {
                endSurge(player);
                player.displayClientMessage(Component.translatable("message.shazammod.helion_surge_end")
                        .withStyle(ChatFormatting.DARK_GREEN), true);
            } else if ((surge - now) % 20 == 0) {
                surgeAura(player);
            }
        }
        ShazamPassives.tick(player);   // Denyut Cryon tiap 2 detik, Muatan Cryon, Hati Pahlawan
    }

    /** Hentikan skill yang sedang berjalan (balik jadi manusia, respawn). Cooldown tetap jalan. */
    public static void cancelActive(ServerPlayer player) {
        UUID id = player.getUUID();
        BEAM_START.remove(id);
        BEAM_UNTIL.remove(id);
        NOVA_AT.remove(id);
        endSurge(player);
        SUN_ON.remove(id);
        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null) {
            speed.removeModifier(SUN_SLOW_ID);
        }
    }

    public static void forget(UUID id) {
        READY_AT.remove(id);
        INHALE_READY_AT.remove(id);
        BEAM_START.remove(id);
        BEAM_UNTIL.remove(id);
        NOVA_AT.remove(id);
        SURGE_UNTIL.remove(id);
        CRYON_UNTIL.remove(id);
        CARRY_UNTIL.remove(id);
        SUN_ON.remove(id);
        QUIET_UNTIL.remove(id);
    }

    private static void endSurge(ServerPlayer player) {
        SURGE_UNTIL.remove(player.getUUID());
        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null) {
            speed.removeModifier(SURGE_SPEED_ID);
        }
    }

    // ----------------------------------------------------------- bantu

    private static List<LivingEntity> enemies(ServerPlayer player, Vec3 center, double radius) {
        return player.serverLevel().getEntitiesOfClass(LivingEntity.class, new AABB(center, center).inflate(radius),
                m -> m.isAlive() && m instanceof Enemy && !DemonSoldier.isFriendly(m)
                        && m.distanceToSqr(center) <= radius * radius);
    }

    private static void sound(ServerPlayer player, Vec3 at, SoundEvent sound, float volume, float pitch) {
        player.serverLevel().playSound(null, at.x, at.y, at.z, sound, SoundSource.PLAYERS, volume, pitch);
    }

    private static Vec3 flat(Vec3 v) {
        Vec3 f = new Vec3(v.x, 0, v.z);
        return f.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : f.normalize();
    }

    private static Vec3 away(Vec3 center, LivingEntity entity) {
        Vec3 a = new Vec3(entity.getX() - center.x, 0, entity.getZ() - center.z);
        return a.lengthSqr() < 1.0E-4 ? Vec3.ZERO : a.normalize();
    }

    private static Vec3 chest(LivingEntity entity) {
        return entity.position().add(0, entity.getBbHeight() * 0.55, 0);
    }

    /** Jarak titik p ke ruas garis a-b. */
    private static double segmentDistance(Vec3 p, Vec3 a, Vec3 b) {
        Vec3 ab = b.subtract(a);
        double len2 = ab.lengthSqr();
        double t = len2 < 1.0E-8 ? 0.0 : Mth.clamp(p.subtract(a).dot(ab) / len2, 0.0, 1.0);
        return p.distanceTo(a.add(ab.scale(t)));
    }

    /** Radiasi Cryon: musuh yang kena melemah & melambat. */
    static void sicken(LivingEntity target, int ticks) {
        target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, ticks, 1));
        target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, Math.max(20, ticks / 2), 1));
    }

    private static boolean quiet(ServerPlayer player, int ticks) {
        long now = player.level().getGameTime();
        Long until = QUIET_UNTIL.get(player.getUUID());
        if (until != null && now < until) {
            return false;
        }
        QUIET_UNTIL.put(player.getUUID(), now + ticks);
        return true;
    }

    /**
     * Pemain ini sedang berwujud Helion-6 (memancarkan radiasi Cryon)? Dipakai server & client (kelemahan Lintang di dekatnya),
     * jadi di client dibaca dari status juara yang dikirim server.
     */
    public static boolean radiates(Player player) {
        if (player.level().isClientSide()) {
            return ShazamClientState.isTransformed(player.getId()) && ShazamClientState.isHelion(player.getId());
        }
        return ShazamPowers.isHelion(player);
    }

    // ----------------------------------------------------------- Cryon & matahari

    private static boolean carries(Player player) {
        Inventory inventory = player.getInventory();
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            if (LintangSkills.isKelam(inventory.getItem(i))) {
                return true;
            }
        }
        return false;
    }

    private static boolean cryonAround(Level level, Player player) {
        AABB area = player.getBoundingBox().inflate(CRYON_ENTITY_RADIUS);
        if (!level.getEntitiesOfClass(ItemEntity.class, area, item -> LintangSkills.isKelam(item.getItem())).isEmpty()
                || !level.getEntitiesOfClass(LivingEntity.class, area, e -> e != player && e.isAlive()
                && LintangSkills.holdsKelam(e)).isEmpty()) {
            return true;
        }
        BlockPos c = player.blockPosition();
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        int r = CRYON_BLOCK_RADIUS;
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r + 1; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    p.set(c.getX() + dx, c.getY() + dy, c.getZ() + dz);
                    if (level.getBlockState(p).is(LintangItems.KELAM_ORE.get())) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private static void scanCryon(ServerPlayer player) {
        long now = player.level().getGameTime();
        UUID id = player.getUUID();
        if (cryonAround(player.serverLevel(), player)) {
            CRYON_UNTIL.put(id, now + SCAN_TICKS + 2);
        }
        if (carries(player)) {
            CARRY_UNTIL.put(id, now + SCAN_TICKS + 2);
        }
    }

    /** Tiap SCAN_TICKS saat berwujud Helion-6: matahari membakar sel Cryon (lambat, nggak bisa terbang kalau radiasi tipis). */
    private static void sunScan(ServerPlayer player, long now) {
        UUID id = player.getUUID();
        boolean burning = ShazamPowers.isInSun(player) && !cryonWorld(player);
        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (burning) {
            if (SUN_ON.add(id) && speed != null && !speed.hasModifier(SUN_SLOW_ID)) {
                speed.addTransientModifier(new AttributeModifier(SUN_SLOW_ID, SUN_SLOW, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
            }
            if (ShazamPowers.data(player).energy() < SUN_GROUND_ENERGY && !player.isCreative() && !player.isSpectator()
                    && (player.getAbilities().mayfly || player.getAbilities().flying)) {
                player.getAbilities().flying = false;
                player.getAbilities().mayfly = false;
                player.onUpdateAbilities();
                player.displayClientMessage(Component.translatable("message.shazammod.helion_grounded")
                        .withStyle(ChatFormatting.GOLD), true);
            }
            if ((now / SCAN_TICKS) % 4 == 0) {   // kulit mendesis & berasap (asapnya digambar client)
                sound(player, player.position().add(0, 1.0, 0), ShazamSounds.HELION_SUN_BURN.get(), 0.45f,
                        0.9f + player.getRandom().nextFloat() * 0.2f);
            }
        } else if (SUN_ON.remove(id) && speed != null) {
            speed.removeModifier(SUN_SLOW_ID);
        }
    }

    public static boolean hasCryon(ServerPlayer player) {
        return carries(player);
    }

    /** Ambil sebutir Pecahan Cryon (atau bijihnya kalau nggak ada pecahan) dari inventori. */
    private static boolean consumeCryon(ServerPlayer player) {
        Inventory inventory = player.getInventory();
        int ore = -1;
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack stack = inventory.getItem(i);
            if (stack.isEmpty()) {
                continue;
            }
            if (stack.is(LintangItems.KELAM_SHARD.get())) {
                stack.shrink(1);
                return true;
            }
            if (ore < 0 && LintangSkills.isKelam(stack)) {
                ore = i;
            }
        }
        if (ore >= 0) {
            inventory.getItem(ore).shrink(1);
            return true;
        }
        return false;
    }

    // ----------------------------------------------------------- Kulit Cryon

    /** Serangan lemah dari makhluk memantul (bukan sihir, bukan saat terbakar matahari). */
    public static boolean bounces(ServerPlayer victim, DamageSource source, float amount) {
        if (TOUGH_SKIN <= 0f || amount >= TOUGH_SKIN || weakened(victim)) {
            return false;
        }
        if (source.getEntity() == null && source.getDirectEntity() == null) {
            return false;
        }
        return !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY) && !source.is(DamageTypes.MAGIC)
                && !source.is(DamageTypes.INDIRECT_MAGIC);
    }

    public static void bounce(ServerPlayer victim, DamageSource source) {
        if (!quiet(victim, 6)) {
            return;
        }
        Entity from = source.getDirectEntity() != null ? source.getDirectEntity() : source.getEntity();
        Vec3 chest = chest(victim);
        Vec3 hit = chest;
        if (from != null) {
            Vec3 toward = from.position().add(0, from.getBbHeight() * 0.6, 0).subtract(chest);
            hit = toward.lengthSqr() < 1.0E-4 ? chest : chest.add(toward.normalize().scale(0.55));
        }
        ShazamNetwork.playAnim(victim, ShazamAnim.HELION_DEFLECT, hit);
        sound(victim, hit, ShazamSounds.DEFLECT.get(), 0.9f, ShazamSounds.tune(1.3f + victim.getRandom().nextFloat() * 0.3f));
    }

    // ----------------------------------------------------------- Tinju

    /** Tinju biasa Helion-6 mengenai: kilat radiasi di titik kena, kadang musuhnya terpapar radiasi. */
    public static void onPunch(ServerPlayer attacker, LivingEntity hit) {
        Vec3 at = hit.position().add(0, hit.getBbHeight() * 0.6, 0);
        ShazamNetwork.playAnim(attacker, ShazamAnim.HELION_PUNCH, at);
        sound(attacker, at, ShazamSounds.HELION_PUNCH.get(), 1.0f, 0.95f + attacker.getRandom().nextFloat() * 0.1f);
        if (attacker.getRandom().nextInt(3) == 0) {
            sicken(hit, 40);
        }
    }

    /**
     * Tinju Cryon (Muatan Cryon penuh, padanan Pukulan Guntur; damage-nya sudah dikali di event yang sama): radiasi meledak
     * di sasaran, sasaran terlempar jauh, lalu sampai 3 musuh lain disambar radiasi.
     */
    public static void cryonPunch(ServerPlayer player, LivingEntity target) {
        Vec3 at = target.position().add(0, target.getBbHeight() * 0.6, 0);
        ShazamNetwork.playAnim(player, ShazamAnim.HELION_CRYON_PUNCH, at);
        sound(player, at, ShazamSounds.HELION_CRYON_PUNCH.get(), 2.0f, 1f);
        sicken(target, SICK_TICKS * 2);
        ShazamPowers.schedule(player, 1, p -> {
            if (target.isAlive()) {
                Vec3 dir = new Vec3(target.getX() - p.getX(), 0, target.getZ() - p.getZ());
                dir = dir.lengthSqr() < 1.0E-4 ? Vec3.ZERO : dir.normalize();
                target.push(dir.x * CRYON_PUNCH_KNOCKBACK, 0.6, dir.z * CRYON_PUNCH_KNOCKBACK);
                target.hurtMarked = true;
            }
            List<LivingEntity> near = enemies(p, target.position(), CRYON_PUNCH_RADIUS);
            near.remove(target);
            near.sort(Comparator.comparingDouble(m -> m.distanceToSqr(target)));
            DamageSource force = ShazamPowers.forceSource(p);
            for (int i = 0; i < Math.min(CRYON_PUNCH_TARGETS, near.size()); i++) {
                LivingEntity m = near.get(i);
                m.invulnerableTime = 0;
                m.hurt(force, CRYON_PUNCH_CHAIN_DAMAGE);
                sicken(m, SICK_TICKS);
                ShazamNetwork.playAnim(p, ShazamAnim.HELION_DASH_HIT, chest(m));
            }
        });
    }

    // ----------------------------------------------------------- Pasif

    /** Pengali Denyut Cryon tiap 2 detik: x2 dekat Cryon, x1,5 di Nether. */
    public static float pulseScale(ServerPlayer player) {
        return cryonWorld(player) ? 2f : PassiveConditions.inferno(player.level()) ? 1.5f : 1f;
    }

    /** Denyut Cryon ikut membakar musuh yang terlalu dekat. */
    public static void pulseSplash(ServerPlayer player) {
        DamageSource force = ShazamPowers.forceSource(player);
        for (LivingEntity m : enemies(player, player.position(), PULSE_SPLASH_RADIUS)) {
            m.hurt(force, PULSE_SPLASH_DAMAGE);
            sicken(m, 40);
        }
    }

    /** Berubah wujud: radiasi meledak dari tubuh (pengganti petir), musuh di sekitar terlempar & terpapar. */
    public static void transformBlast(ServerPlayer caster, Vec3 pos, float damage, double radius) {
        ServerLevel level = caster.serverLevel();
        level.playSound(null, pos.x, pos.y, pos.z, ShazamSounds.HELION_BURST.get(), SoundSource.PLAYERS, 3.0f, 1f);
        if (damage <= 0f) {
            return;
        }
        DamageSource source = ShazamPowers.forceSource(caster);
        for (LivingEntity target : enemies(caster, pos, radius)) {
            target.hurt(source, damage);
            Vec3 a = away(pos, target);
            target.push(a.x * 1.6, 0.5, a.z * 1.6);
            target.hurtMarked = true;
            sicken(target, 100);
        }
    }

    /** Radiasi habis di bawah matahari: jatuh berlutut (ShazamPowers lalu mengembalikannya jadi manusia). */
    public static void burnout(ServerPlayer player) {
        ShazamNetwork.playAnim(player, ShazamAnim.HELION_COLLAPSE, player.position());
    }

    // ----------------------------------------------------------- H - Hempasan Lesat

    private static boolean hempas(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        Vec3 look = player.getViewVector(1f);
        Vec3 dir = player.onGround() && Math.abs(look.y) < 0.55 ? flat(look) : look.normalize();
        Vec3 start = player.position();
        Vec3 from = start.add(0, 0.9, 0);
        BlockHitResult hit = level.clip(new ClipContext(from, from.add(dir.scale(DASH_RANGE)), ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, player));
        double dist = hit.getType() == HitResult.Type.MISS ? DASH_RANGE : Math.max(0.0, hit.getLocation().distanceTo(from) - 0.9);
        if (dist < 2.0) {
            return false;   // terhalang dinding
        }
        Vec3 end = start.add(dir.scale(dist));
        ShazamNetwork.playAnim(player, ShazamAnim.HELION_DASH, end);
        sound(player, start, ShazamSounds.HELION_DASH.get(), 1.6f, 1f);
        later(player, ShazamAnim.HELION_DASH_WINDUP + ShazamAnim.HELION_DASH_TICKS, p -> dashImpact(p, start, end, dir));
        return true;
    }

    private static void dashImpact(ServerPlayer player, Vec3 a, Vec3 b, Vec3 dir) {
        float power = power(player);
        DamageSource source = ShazamPowers.forceSource(player);
        Vec3 a1 = a.add(0, 0.9, 0), b1 = b.add(0, 0.9, 0);
        AABB box = new AABB(a1, b1).inflate(DASH_WIDTH + 1.0);
        for (LivingEntity m : player.serverLevel().getEntitiesOfClass(LivingEntity.class, box,
                e -> e.isAlive() && e instanceof Enemy && !DemonSoldier.isFriendly(e))) {
            Vec3 c = chest(m);
            if (segmentDistance(c, a1, b1) > DASH_WIDTH + m.getBbWidth() * 0.5) {
                continue;
            }
            m.invulnerableTime = 0;
            m.hurt(source, DASH_DAMAGE * power);
            Vec3 side = new Vec3(c.x - a.x, 0, c.z - a.z);
            Vec3 across = side.subtract(dir.scale(side.dot(dir)));
            Vec3 push = (across.lengthSqr() < 1.0E-4 ? Vec3.ZERO : across.normalize().scale(0.8)).add(dir.scale(DASH_IMPULSE));
            m.push(push.x, 0.55, push.z);
            m.hurtMarked = true;
            sicken(m, SICK_TICKS);
            ShazamNetwork.playAnim(player, ShazamAnim.HELION_DASH_HIT, c);
        }
        for (LivingEntity m : enemies(player, b, DASH_END_RADIUS)) {   // radiasi yang terbawa menghempas di ujung lesatan
            m.hurt(source, DASH_END_DAMAGE * power);
            Vec3 aw = away(b, m);
            m.push(aw.x * 0.9, 0.35, aw.z * 0.9);
            m.hurtMarked = true;
        }
        sound(player, b, ShazamSounds.SHOCKWAVE.get(), 1.2f, ShazamSounds.tune(1.2f));
    }

    // ----------------------------------------------------------- E - Emisi Cryon

    private static boolean emisi(ServerPlayer player) {
        UUID id = player.getUUID();
        long now = player.level().getGameTime();
        BEAM_START.put(id, now + ShazamAnim.HELION_EYES_WINDUP);
        BEAM_UNTIL.put(id, now + ShazamAnim.HELION_EYES_WINDUP + ShazamAnim.HELION_EYES_TICKS);
        ShazamNetwork.playAnim(player, ShazamAnim.HELION_EYES);
        sound(player, player.getEyePosition(), ShazamSounds.HELION_BEAM_CHARGE.get(), 1.2f, 1f);
        later(player, ShazamAnim.HELION_EYES_WINDUP, p -> sound(p, p.getEyePosition(), ShazamSounds.HELION_BEAM_FIRE.get(), 1.8f, 1f));
        return true;
    }

    /** Satu denyut sinar (tiap 2 tick): dari mata lurus ke arah pandang, menembus musuh, berhenti di blok. */
    private static void beamStep(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getViewVector(1f);
        Vec3 far = eye.add(look.scale(BEAM_RANGE));
        BlockHitResult hit = level.clip(new ClipContext(eye, far, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        Vec3 end = hit.getType() == HitResult.Type.MISS ? far : hit.getLocation();
        float power = power(player);
        DamageSource source = ShazamPowers.forceSource(player);
        List<LivingEntity> hits = new ArrayList<>();
        for (LivingEntity m : level.getEntitiesOfClass(LivingEntity.class, new AABB(eye, end).inflate(1.5),
                e -> e.isAlive() && e instanceof Enemy && !DemonSoldier.isFriendly(e))) {
            double reach = Math.max(0.6, m.getBbWidth() * 0.6) + m.getBbHeight() * 0.25;
            if (segmentDistance(m.position().add(0, m.getBbHeight() * 0.5, 0), eye, end) <= reach) {
                hits.add(m);
            }
        }
        hits.sort(Comparator.comparingDouble(m -> m.distanceToSqr(eye)));
        for (int i = 0; i < Math.min(BEAM_PIERCE, hits.size()); i++) {
            LivingEntity m = hits.get(i);
            m.invulnerableTime = 0;
            m.hurt(source, BEAM_DAMAGE * power);
            m.igniteForSeconds(BEAM_FIRE_SECONDS);
            sicken(m, 40);
        }
        if (BEAM_BURNS_BLOCKS && hit.getType() == HitResult.Type.BLOCK && level.random.nextInt(6) == 0) {
            BlockPos firePos = hit.getBlockPos().relative(hit.getDirection());
            if (level.getBlockState(firePos).isAir() && LintangPhysics.canChange(player, level, firePos)) {
                level.setBlockAndUpdate(firePos, BaseFireBlock.getState(level, firePos));
            }
        }
    }

    // ----------------------------------------------------------- I - Injakan Cryon

    private static boolean injak(ServerPlayer player) {
        ShazamNetwork.playAnim(player, ShazamAnim.HELION_QUAKE, player.position());
        sound(player, player.position(), ShazamSounds.HELION_QUAKE.get(), 2.6f, 1f);
        later(player, ShazamAnim.HELION_QUAKE_WINDUP, HelionSkills::quakeImpact);
        return true;
    }

    private static void quakeImpact(ServerPlayer player) {
        Vec3 c = player.position();
        float power = power(player);
        DamageSource source = ShazamPowers.forceSource(player);
        for (LivingEntity m : enemies(player, c, QUAKE_RADIUS)) {
            double d = Math.sqrt(m.distanceToSqr(c));
            float fall = d <= QUAKE_CORE ? 1f : (float) (QUAKE_CORE / d);
            m.invulnerableTime = 0;
            m.hurt(source, QUAKE_DAMAGE * power * fall);
            Vec3 a = away(c, m);
            double k = 0.35 + 0.65 * fall;
            m.push(a.x * QUAKE_PUSH * k, QUAKE_LIFT * k, a.z * QUAKE_PUSH * k);
            m.hurtMarked = true;
            sicken(m, SICK_TICKS);
        }
        for (Projectile shot : player.serverLevel().getEntitiesOfClass(Projectile.class, new AABB(c, c).inflate(QUAKE_RADIUS * 0.6),
                e -> e.getOwner() != player)) {   // proyektil di dekatnya terlempar ke atas
            shot.setDeltaMovement(shot.getDeltaMovement().scale(0.2).add(0, 0.8, 0));
            shot.hurtMarked = true;
        }
        later(player, AFTERSHOCK_DELAY, p -> {   // gempa susulan: cuma yang berpijak di tanah
            DamageSource force = ShazamPowers.forceSource(p);
            for (LivingEntity m : enemies(p, c, AFTERSHOCK_RADIUS)) {
                if (!m.onGround()) {
                    continue;
                }
                m.invulnerableTime = 0;
                m.hurt(force, AFTERSHOCK_DAMAGE * power(p));
                Vec3 a = away(c, m);
                m.push(a.x * 0.5, 0.45, a.z * 0.5);
                m.hurtMarked = true;
            }
        });
    }

    // ----------------------------------------------------------- 6 - Supernova-6

    private static boolean supernova(ServerPlayer player) {
        long now = player.level().getGameTime();
        NOVA_AT.put(player.getUUID(), now + ShazamAnim.HELION_NOVA_WINDUP);
        ShazamNetwork.playAnim(player, ShazamAnim.HELION_NOVA);
        sound(player, player.position(), ShazamSounds.HELION_NOVA.get(), 3.5f, 1f);
        later(player, ShazamAnim.HELION_NOVA_WINDUP, HelionSkills::novaBlast);
        return true;
    }

    /** Selama menyerap radiasi: musuh di sekitar tersedot pelan ke arahnya & terpapar. */
    private static void novaPull(ServerPlayer player) {
        Vec3 c = player.position();
        for (LivingEntity m : enemies(player, c, NOVA_PULL_RADIUS)) {
            Vec3 pull = c.subtract(m.position());
            if (pull.lengthSqr() > 4.0) {
                pull = pull.normalize().scale(0.35);
                m.push(pull.x, 0.04, pull.z);
                m.hurtMarked = true;
            }
            if (m.distanceToSqr(c) < 36.0) {
                sicken(m, 30);
            }
        }
    }

    private static void novaBlast(ServerPlayer player) {
        UUID id = player.getUUID();
        NOVA_AT.remove(id);
        float k = (weakened(player) ? SUN_POWER : 1f) * (isSurging(player) ? SURGE_POWER : 1f);
        ShazamData data = ShazamPowers.data(player);
        float burned = Math.max(0f, data.energy() - NOVA_KEEP_ENERGY);
        ShazamPowers.setData(player, data.withEnergy(Math.min(data.energy(), NOVA_KEEP_ENERGY)));
        double radius = NOVA_RADIUS_MIN + burned * NOVA_RADIUS_PER_ENERGY;
        float damage = (NOVA_MIN_DAMAGE + burned * NOVA_DAMAGE_PER_ENERGY) * k;
        Vec3 c = player.position().add(0, 1.0, 0);
        DamageSource source = ShazamPowers.forceSource(player);
        for (LivingEntity m : enemies(player, c, radius)) {
            double d = Math.sqrt(m.distanceToSqr(c));
            float fall = d <= NOVA_CORE ? 1f : (float) Math.max(0.25, NOVA_CORE / d);
            m.invulnerableTime = 0;
            m.hurt(source, damage * fall);
            m.igniteForSeconds(6f);
            sicken(m, 200);
            Vec3 a = away(c, m);
            m.push(a.x * 2.4 * fall, 0.2 + 0.8 * fall, a.z * 2.4 * fall);
            m.hurtMarked = true;
        }
        for (Projectile shot : player.serverLevel().getEntitiesOfClass(Projectile.class, new AABB(c, c).inflate(radius),
                e -> e.getOwner() != player)) {
            shot.discard();
        }
        // x = jari-jari ledakan, y = kekuatan 0-1 (efek di client mengikuti radiasi yang dibakar)
        ShazamNetwork.playAnim(player, ShazamAnim.HELION_NOVA_BLAST,
                new Vec3(radius, Mth.clamp(burned / (ShazamPowers.MAX_ENERGY - NOVA_KEEP_ENERGY), 0.2f, 1f), 0));
        double zone = radius * 0.4;
        for (int i = 1; i <= NOVA_ZONE_PULSES; i++) {   // sisa zona radiasi
            ShazamPowers.schedule(player, i * 20, p -> {
                DamageSource force = ShazamPowers.forceSource(p);
                for (LivingEntity m : p.serverLevel().getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(zone),
                        e -> e.isAlive() && e instanceof Enemy && !DemonSoldier.isFriendly(e) && e.distanceToSqr(c) <= zone * zone)) {
                    m.invulnerableTime = 0;
                    m.hurt(force, NOVA_ZONE_DAMAGE);
                    sicken(m, 40);
                }
            });
        }
        player.displayClientMessage(Component.translatable("message.shazammod.helion_nova", Math.round(burned))
                .withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD), true);
        ShazamNetwork.sync(player);
    }

    // ----------------------------------------------------------- M - Hirup Cryon

    public static void inhale(ServerPlayer player) {
        if (!ShazamPowers.isHelion(player)) {
            player.displayClientMessage(Component.translatable("message.shazammod.not_transformed_helion")
                    .withStyle(ChatFormatting.GRAY), true);
            return;
        }
        if (inhaleCooldownTicks(player) > 0 || isNovaCharging(player)) {
            return;
        }
        if (!player.isCreative() && !hasCryon(player)) {
            player.displayClientMessage(Component.translatable("message.shazammod.helion_need_cryon")
                    .withStyle(ChatFormatting.GRAY), true);
            return;
        }
        INHALE_READY_AT.put(player.getUUID(), player.level().getGameTime() + INHALE_COOLDOWN_TICKS);
        ShazamNetwork.playAnim(player, ShazamAnim.HELION_INHALE);
        sound(player, player.getEyePosition(), ShazamSounds.HELION_INHALE.get(), 1.6f, 1f);
        later(player, ShazamAnim.HELION_INHALE_WINDUP, p -> {
            if (!p.isCreative() && !consumeCryon(p)) {
                return;
            }
            ShazamData d = ShazamPowers.data(p);
            ShazamPowers.setData(p, d.withEnergy(d.energy() + INHALE_ENERGY));
            p.heal(INHALE_HEAL * ShazamPowers.healScale(p));
            SURGE_UNTIL.put(p.getUUID(), p.level().getGameTime() + SURGE_TICKS);
            AttributeInstance speed = p.getAttribute(Attributes.MOVEMENT_SPEED);
            if (speed != null && !speed.hasModifier(SURGE_SPEED_ID)) {
                speed.addTransientModifier(new AttributeModifier(SURGE_SPEED_ID, SURGE_SPEED, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
            }
            DamageSource force = ShazamPowers.forceSource(p);
            for (LivingEntity m : enemies(p, p.position(), 6.0)) {   // radiasinya meledak keluar sekali
                m.hurt(force, 10f);
                Vec3 a = away(p.position(), m);
                m.push(a.x * 1.1, 0.35, a.z * 1.1);
                m.hurtMarked = true;
                sicken(m, SICK_TICKS);
            }
            p.displayClientMessage(Component.translatable("message.shazammod.helion_surge")
                    .withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD), true);
            ShazamNetwork.sync(p);
        });
        ShazamNetwork.sync(player);
    }

    /** Lonjakan Cryon: tiap detik radiasi dari tubuh melukai musuh yang terlalu dekat. */
    private static void surgeAura(ServerPlayer player) {
        DamageSource force = ShazamPowers.forceSource(player);
        for (LivingEntity m : enemies(player, player.position(), SURGE_AURA_RADIUS)) {
            m.hurt(force, SURGE_AURA_DAMAGE);
            sicken(m, 40);
        }
    }
}
