package com.shazammod;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Salinan data Shazam di sisi client. Sengaja nggak memakai class khusus client,
 * supaya aman dimuat juga di server dedicated.
 */
public final class ShazamClientState {
    private ShazamClientState() {}

    // HUD pemain sendiri
    public static boolean unlocked;        // punya paling nggak satu juara
    public static boolean transformed;
    public static boolean storm;
    /** Berkah Aton: Black Adam di bawah matahari (darah pulih lebih cepat, energi malah terisi). */
    public static boolean sun;
    /** 0.30 Sabbac di kegelapan neraka (malam, Nether, End): Muatan Neraka 2x, energi terisi, pulih lebih cepat. */
    public static boolean dark;
    /** Juara yang sudah didapat: Shazam (enam totem), Black Adam (Skarabe Teth-Adam), dan 0.30 Sabbac (Mahkota Sabbac). */
    public static boolean hasShazam, hasAdam, hasSabbac, hasLintang, hasHelion;
    /** 0.32 Lintang: dekat Batu Kelam (cahaya terhisap), dan di bawah langit malam (cahaya bintang). */
    public static boolean kelam, starlight;
    public static float energy = ShazamPowers.MAX_ENERGY;
    /** Juara yang dipilih pemain sendiri (lihat ShazamForm). */
    public static int form;
    private static List<Integer> cooldowns = List.of();

    // Status semua pemain yang kelihatan, dan antrean animasi yang baru datang
    private static final Map<Integer, ShazamStatePayload> STATES = new HashMap<>();
    private static final ArrayDeque<ShazamAnimPayload> ANIMS = new ArrayDeque<>();

    public static void update(ShazamSyncPayload payload) {
        unlocked = payload.has(ShazamSyncPayload.UNLOCKED);
        transformed = payload.has(ShazamSyncPayload.TRANSFORMED);
        storm = payload.has(ShazamSyncPayload.STORM);
        sun = payload.has(ShazamSyncPayload.SUN);
        hasShazam = payload.has(ShazamSyncPayload.HAS_SHAZAM);
        hasAdam = payload.has(ShazamSyncPayload.HAS_ADAM);
        dark = payload.has(ShazamSyncPayload.DARK);
        hasSabbac = payload.has(ShazamSyncPayload.HAS_SABBAC);
        hasLintang = payload.has(ShazamSyncPayload.HAS_LINTANG);
        hasHelion = payload.has(ShazamSyncPayload.HAS_HELION);
        kelam = payload.has(ShazamSyncPayload.KELAM);
        starlight = payload.has(ShazamSyncPayload.STARLIGHT);
        energy = payload.energy();
        cooldowns = payload.cooldowns();
        form = payload.form();
    }

    /** Pemain sendiri memilih Black Adam. */
    public static boolean isAdam() {
        return form == ShazamForm.BLACK_ADAM.ordinal();
    }

    /** 0.30: pemain sendiri memilih Sabbac. */
    public static boolean isSabbac() {
        return form == ShazamForm.SABBAC.ordinal();
    }

    /** 0.32: pemain sendiri memilih Lintang. */
    public static boolean isLintang() {
        return form == ShazamForm.LINTANG.ordinal();
    }

    /** 0.43: pemain sendiri memilih Helion-6. */
    public static boolean isHelion() {
        return form == ShazamForm.HELION.ordinal();
    }

    /** Sisa cooldown skill ke-index, dalam tick. */
    public static int cooldown(int index) {
        return index < cooldowns.size() ? cooldowns.get(index) : 0;
    }

    /** Sisa waktu pulih (tick) sesudah terlempar balik jadi manusia; dikirim sesudah cooldown semua skill. */
    public static int recovery() {
        return cooldown(ShazamNetwork.SKILL_SLOTS);
    }

    /** Black Adam: sisa cooldown Panggil Petir Kahndaq (tombol M), dikirim paling belakang. */
    public static int callCooldown() {
        return cooldown(ShazamNetwork.SKILL_SLOTS + 1);
    }

    public static void onState(ShazamStatePayload payload) {
        STATES.put(payload.entityId(), payload);
    }

    /** 0.30: status pemain boneka Rival Juara (diisi client sendiri tiap tick, lihat client.RivalPuppets). */
    public static void putState(ShazamStatePayload payload) {
        STATES.put(payload.entityId(), payload);
    }

    public static ShazamStatePayload state(int entityId) {
        return STATES.get(entityId);
    }

    public static void removeState(int entityId) {
        STATES.remove(entityId);
    }

    public static boolean isTransformed(int entityId) {
        ShazamStatePayload state = STATES.get(entityId);
        return state != null && state.transformed();
    }

    public static boolean isRaging(int entityId) {
        ShazamStatePayload state = STATES.get(entityId);
        return state != null && state.rage();
    }

    public static boolean isHoodUp(int entityId) {
        ShazamStatePayload state = STATES.get(entityId);
        return state != null && state.hood();
    }

    /** Mode Kilat Mercury sedang menyala. */
    public static boolean isMercury(int entityId) {
        ShazamStatePayload state = STATES.get(entityId);
        return state != null && state.mercury();
    }

    /** Juara pemain ini (tampilan jubah, lambang, dewa, warna efek). Belum ada kabar = Shazam. */
    public static ShazamForm form(int entityId) {
        ShazamStatePayload state = STATES.get(entityId);
        return state == null ? ShazamForm.SHAZAM : ShazamForm.byId(state.form());
    }

    public static boolean isAdam(int entityId) {
        return form(entityId) == ShazamForm.BLACK_ADAM;
    }

    /** 0.30: pemain ini (atau pemain boneka rival) memakai juara Sabbac. */
    public static boolean isSabbac(int entityId) {
        return form(entityId) == ShazamForm.SABBAC;
    }

    /** 0.32: pemain ini memakai juara Lintang. */
    public static boolean isLintang(int entityId) {
        return form(entityId) == ShazamForm.LINTANG;
    }

    /** 0.43: pemain ini memakai juara Helion-6. */
    public static boolean isHelion(int entityId) {
        return form(entityId) == ShazamForm.HELION;
    }

    /** Juara yang berat & tak berakrobat (Black Adam, Sabbac): terbang lugas, nggak berguling. */
    public static boolean isHeavy(int entityId) {
        ShazamForm f = form(entityId);
        return f == ShazamForm.BLACK_ADAM || f == ShazamForm.SABBAC;
    }

    public static boolean isFlying(int entityId) {
        ShazamStatePayload state = STATES.get(entityId);
        return state != null && state.flying();
    }

    /** Muatan Petir Shazam penuh: kepalan menyala, Pukulan Guntur siap. */
    public static boolean isCharged(int entityId) {
        ShazamStatePayload state = STATES.get(entityId);
        return state != null && state.charged();
    }

    /** Muatan Petir pemain sendiri (0-100), dikirim sesudah cooldown Panggil Petir. */
    public static int charge() {
        return cooldown(ShazamNetwork.SKILL_SLOTS + 2);
    }

    /** Sisa jeda Refleks Mercury pemain sendiri (tick, 0 = siap). */
    public static int dodgeCooldown() {
        return cooldown(ShazamNetwork.SKILL_SLOTS + 3);
    }

    /** 0.26: sisa cooldown Kekuatan Keluarga (tombol J) pemain sendiri (tick, 0 = siap). */
    public static int familyCooldown() {
        return cooldown(ShazamNetwork.SKILL_SLOTS + 4);
    }

    /** 0.27 Black Adam: jumlah proyektil yang sedang tertahan Tangan Kahndaq. */
    public static int heldCount() {
        return cooldown(ShazamNetwork.SKILL_SLOTS + 5);
    }

    /** 0.30 Sabbac: jumlah prajurit iblis yang masih bertarung (dikirim di tempat heldCount). */
    public static int legionCount() {
        return cooldown(ShazamNetwork.SKILL_SLOTS + 5);
    }

    /** 0.30 Sabbac: sisa cooldown Pasukan Iblis (tombol J), dikirim di tempat cooldown Kekuatan Keluarga. */
    public static int legionCooldown() {
        return cooldown(ShazamNetwork.SKILL_SLOTS + 4);
    }

    /** 0.31 Restu Para Dewa: tumpukan scaling Shazam pemain sendiri (0 sampai FAVOR_MAX_STACKS). */
    public static int favor() {
        return cooldown(ShazamNetwork.SKILL_SLOTS + 6);
    }

    /** 0.32 Lintang: Daya Surya pemain sendiri (persen, 0-100). */
    public static int lintangPower() {
        return cooldown(ShazamNetwork.SKILL_SLOTS + 7);
    }

    /** 0.43 Helion-6: Daya Cryon pemain sendiri (persen, dikirim di tempat Daya Surya). */
    public static int helionPower() {
        return cooldown(ShazamNetwork.SKILL_SLOTS + 7);
    }

    public static void onAnim(ShazamAnimPayload payload) {
        if (ANIMS.size() < 256) {
            ANIMS.add(payload);
        }
    }

    public static ShazamAnimPayload pollAnim() {
        return ANIMS.poll();
    }

    public static void reset() {
        unlocked = false;
        transformed = false;
        storm = false;
        sun = false;
        hasShazam = false;
        hasAdam = false;
        hasSabbac = false;
        hasLintang = false;
        hasHelion = false;
        kelam = false;
        starlight = false;
        dark = false;
        energy = ShazamPowers.MAX_ENERGY;
        form = 0;
        cooldowns = List.of();
        STATES.clear();
        ANIMS.clear();
    }
}
