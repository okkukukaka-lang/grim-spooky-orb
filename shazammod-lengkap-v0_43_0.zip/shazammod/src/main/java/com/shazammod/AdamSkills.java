package com.shazammod;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;

import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Enam skill Black Adam, satu untuk tiap dewa Mesir S-H-A-Z-A-M, plus Murka Kahndaq. Tombolnya sama dengan
 * skill Shazam (Z X C V B N R); gerakan & efeknya diputar di client lewat ShazamAnim.ADAM_*.
 *
 * S - Pusaran Shu   : badai pasir (napas dewa udara) berputar mengangkat musuh, lalu meledak ke luar. Stamina Shu:
 *                     darah pulih dan dapat hati emas.
 * H - Sambaran Heru : menerjang lurus secepat elang Heru sampai 18 blok, menghantam semua musuh di lintasan.
 * A - Tinju Amon    : kedua kepalan menghantam tanah; tanah terbelah lurus ke depan, musuh di atasnya terlempar.
 * Z - Segel Zehuti  : hieroglif kebijaksanaan Zehuti mengikat semua musuh yang terlihat (nyaris nggak bisa bergerak,
 *                     lemah, dan menerima damage lebih besar).
 * A - Sinar Aton    : cakram matahari Aton menembakkan sinar membara ke enam musuh berturut-turut.
 * M - Lilitan Mehen : ular raksasa Mehen membelit badan: damage yang diterima tinggal 30%, dan ularnya mematuk musuh
 *                     di sekitar (juga yang berani menyerang).
 * R - Murka Kahndaq : mata emas menyala, petir membara menyambar sekeliling, tinju meledak dan merambat.
 * M - Panggil Petir Kahndaq (khusus Black Adam, Shazam punya Mode Kilat di tombol ini): kepalan ke langit, petir sihir
 *                     menyambar badan sendiri seperti saat berubah. Energi & darah terisi di tengah pertarungan, dan
 *                     petirnya menghempas musuh di sekitar.
 */
public final class AdamSkills {
    private AdamSkills() {}

    public enum Skill {
        SHU(40f, 300),       // S - Pusaran Shu
        HERU(25f, 80),       // H - Sambaran Heru
        AMON(40f, 160),      // A - Tinju Amon
        ZEHUTI(30f, 300),    // Z - Segel Zehuti
        ATON(35f, 120),      // A - Sinar Aton
        MEHEN(70f, 800),     // M - Lilitan Mehen
        KAHNDAQ(150f, 1200); // Murka Kahndaq

        public final float cost;
        public final int cooldownTicks;

        Skill(float cost, int cooldownTicks) {
            this.cost = cost;
            this.cooldownTicks = cooldownTicks;
        }
    }

    // ================= Angka-angka yang gampang diutak-atik =================
    private static final double SHU_RADIUS = 9.0;          // musuh sejauh ini ikut tersedot pusaran
    private static final double SHU_RING = 3.2;            // musuh berputar di jarak segini
    private static final double SHU_SPIN = 0.42;           // kecepatan putar (blok/tick)
    private static final double SHU_LIFT = 2.6;            // musuh terangkat setinggi ini
    private static final float SHU_TICK_DAMAGE = 3f;       // tiap 0,5 detik di dalam pusaran
    private static final float SHU_BURST_DAMAGE = 16f;     // ledakan di akhir
    private static final double SHU_BURST_KNOCKBACK = 2.1;
    private static final float SHU_HEAL = 30f;             // stamina Shu: darah langsung pulih segini
    private static final int SHU_ABSORPTION_LEVEL = 3;     // + hati emas 16 darah (Absorption IV) selama 30 detik
    private static final int SHU_ABSORPTION_TICKS = 600;

    private static final double HERU_RANGE = 18.0;
    private static final float HERU_DAMAGE = 24f;
    private static final double HERU_HIT_RADIUS = 1.8;     // musuh sedekat ini ke lintasan ikut tertabrak
    private static final float HERU_END_DAMAGE = 10f;      // hempasan di titik akhir
    private static final double HERU_END_RADIUS = 3.5;

    private static final double AMON_RANGE = 15.0;         // panjang tanah terbelah
    private static final double AMON_WIDTH = 2.2;          // lebar (tiap sisi)
    private static final float AMON_DAMAGE = 30f;
    private static final double AMON_LAUNCH = 0.95;        // musuh terlempar ke atas
    private static final double AMON_SLAM_RADIUS = 3.0;    // hantaman di titik kepalan
    private static final float AMON_SLAM_DAMAGE = 14f;

    private static final double ZEHUTI_RADIUS = 16.0;
    private static final int ZEHUTI_TARGETS = 12;
    private static final float ZEHUTI_DAMAGE = 6f;
    private static final int ZEHUTI_TICKS = 160;           // lama tersegel (8 detik)
    public static final float SEAL_MULTIPLIER = 1.25f;     // musuh tersegel menerima damage +25% dari Black Adam

    private static final double ATON_RANGE = 22.0;
    private static final int ATON_TARGETS = 6;
    private static final float ATON_DAMAGE = 20f;
    private static final float ATON_FIRE_SECONDS = 4f;
    private static final double ATON_SPLASH = 2.0;         // tanpa musuh: sinar ke titik yang dibidik, kena di sekitarnya

    public static final float MEHEN_DAMAGE_MULTIPLIER = 0.3f;
    private static final double MEHEN_RADIUS = 7.0;
    private static final int MEHEN_BITE_EVERY = 20;        // tiap detik ular mematuk
    private static final int MEHEN_BITES = 2;              // sampai dua musuh sekaligus
    private static final float MEHEN_BITE_DAMAGE = 14f;
    private static final int MEHEN_RETALIATE_GAP = 10;     // yang menyerang langsung dipatuk balik (paling cepat tiap 0,5 detik)

    public static final float RAGE_PUNCH_MULTIPLIER = 1.6f;   // pukulan +60%
    private static final double RAGE_BLAST_RADIUS = 3.0;      // tinju meledak: musuh lain di dekat sasaran ikut terhempas
    private static final float RAGE_BLAST_DAMAGE = 8f;
    private static final double RAGE_CHAIN_RADIUS = 6.0;      // lalu petir merambat
    private static final int RAGE_CHAIN_TARGETS = 2;
    private static final float RAGE_CHAIN_DAMAGE = 10f;
    private static final double RAGE_STORM_RADIUS = 14.0;     // tiap detik petir membara memburu musuh
    private static final int RAGE_STORM_TARGETS = 3;
    private static final float RAGE_STORM_DAMAGE = 10f;
    private static final float RAGE_BURST_DAMAGE = 14f;       // ledakan saat amarah menyala
    private static final double RAGE_BURST_RADIUS = 6.0;
    private static final double RAGE_SPEED_BONUS = 0.25;
    private static final ResourceLocation RAGE_SPEED = ShazamMod.id("kahndaq_rage_speed");
    // Panggil Petir Kahndaq (tombol M)
    public static final int CALL_COOLDOWN_TICKS = 500;        // 25 detik, tanpa biaya energi
    private static final float CALL_ENERGY = 220f;            // energi yang terisi
    private static final float CALL_HEAL = 120f;              // darah yang pulih
    private static final double CALL_RADIUS = 6.5;
    private static final float CALL_DAMAGE = 20f;
    private static final double CALL_KNOCKBACK = 1.6;
    // =========================================================================

    private static final Map<UUID, long[]> READY_AT = new HashMap<>();
    private static final Map<UUID, Long> CALL_READY_AT = new HashMap<>();
    private static final Map<UUID, Long> SHU_UNTIL = new HashMap<>();
    private static final Map<UUID, Dash> DASHES = new HashMap<>();
    private static final Map<UUID, Fissure> FISSURES = new HashMap<>();
    private static final Map<UUID, Long> SEALED_UNTIL = new HashMap<>();
    private static final Map<UUID, Long> MEHEN_UNTIL = new HashMap<>();
    private static final Map<UUID, Long> MEHEN_NEXT_RETALIATE = new HashMap<>();
    private static final Map<UUID, Long> RAGE_UNTIL = new HashMap<>();

    // Efek penghambat yang dibuang lilitan Mehen (keberanian)
    private static final List<Holder<MobEffect>> DEBUFFS = List.of(
            MobEffects.MOVEMENT_SLOWDOWN, MobEffects.WEAKNESS, MobEffects.BLINDNESS, MobEffects.DARKNESS,
            MobEffects.DIG_SLOWDOWN, MobEffects.CONFUSION, MobEffects.POISON, MobEffects.WITHER, MobEffects.HUNGER);

    /** Terjangan Heru: dari start ke end mulai game time begin, musuh yang sudah tertabrak nggak kena dua kali. */
    private record Dash(Vec3 start, Vec3 end, long begin, Set<UUID> hit) {}

    /** Tanah terbelah Amon: dari origin ke arah dir (datar, satuan) mulai game time begin. */
    private record Fissure(Vec3 origin, Vec3 dir, long begin, Set<UUID> hit) {}

    // ----------------------------------------------------------- Pakai skill

    public static void use(ServerPlayer player, Skill skill) {
        if (!ShazamPowers.isTransformed(player)) {
            if (ShazamPowers.data(player).anyUnlocked()) {
                player.displayClientMessage(Component.translatable("message.shazammod.not_transformed_adam")
                        .withStyle(ChatFormatting.GRAY), true);
            }
            return;
        }
        if (cooldownTicks(player, skill) > 0) {
            return;
        }
        if (ShazamPowers.data(player).energy() < skill.cost) {
            player.displayClientMessage(Component.translatable("message.shazammod.skill_no_energy",
                    Math.round(skill.cost)).withStyle(ChatFormatting.RED), true);
            return;
        }

        boolean used = switch (skill) {
            case SHU -> shu(player);
            case HERU -> heru(player);
            case AMON -> amon(player);
            case ZEHUTI -> zehuti(player);
            case ATON -> aton(player);
            case MEHEN -> mehen(player);
            case KAHNDAQ -> kahndaq(player);
        };
        if (!used) {
            // Meleset: energi dan cooldown nggak terpakai
            player.displayClientMessage(Component.translatable("message.shazammod.no_target")
                    .withStyle(ChatFormatting.GRAY), true);
            return;
        }

        ShazamData data = ShazamPowers.data(player);
        ShazamPowers.setData(player, data.withEnergy(data.energy() - skill.cost));
        READY_AT.computeIfAbsent(player.getUUID(), id -> new long[Skill.values().length])[skill.ordinal()] =
                player.level().getGameTime() + skill.cooldownTicks;
        ShazamNetwork.sync(player);
    }

    public static int cooldownTicks(ServerPlayer player, Skill skill) {
        long[] readyAt = READY_AT.get(player.getUUID());
        if (readyAt == null) {
            return 0;
        }
        long left = readyAt[skill.ordinal()] - player.level().getGameTime();
        return left > 0 ? (int) left : 0;
    }

    /** Efek dijalankan beberapa tick lagi, dan dibatalkan kalau pemain keburu balik jadi manusia. */
    private static void later(ServerPlayer player, int delay, Consumer<ServerPlayer> action) {
        ShazamPowers.schedule(player, delay, p -> {
            if (ShazamPowers.isAdam(p)) {
                action.accept(p);
            }
        });
    }

    /** Dipanggil tiap tick selama pemain berwujud Black Adam. */
    public static void tick(ServerPlayer player) {
        UUID id = player.getUUID();
        long now = player.level().getGameTime();

        Long shuUntil = SHU_UNTIL.get(id);
        if (shuUntil != null) {
            if (now >= shuUntil) {
                SHU_UNTIL.remove(id);
                shuBurst(player);
            } else {
                shuPull(player, shuUntil - now);
            }
        }

        Dash dash = DASHES.get(id);
        if (dash != null && now > dash.begin()) {
            int k = (int) (now - dash.begin());
            heruStep(player, dash, k);
            if (k >= ShazamAnim.HERU_TICKS) {
                DASHES.remove(id);
                heruArrive(player, dash);
            }
        }

        Fissure fissure = FISSURES.get(id);
        if (fissure != null && now >= fissure.begin()) {
            int k = (int) (now - fissure.begin());
            amonStep(player, fissure, k);
            if (k >= ShazamAnim.AMON_SPREAD) {
                FISSURES.remove(id);
            }
        }

        Long mehenUntil = MEHEN_UNTIL.get(id);
        if (mehenUntil != null) {
            if (now >= mehenUntil) {
                MEHEN_UNTIL.remove(id);
                MEHEN_NEXT_RETALIATE.remove(id);
                player.serverLevel().playSound(null, player.getX(), player.getY(), player.getZ(), ShazamSounds.DARK_HISS.get(),
                        SoundSource.PLAYERS, 0.6f, ShazamSounds.tune(0.5f));
            } else {
                if ((mehenUntil - now) % MEHEN_BITE_EVERY == 0) {
                    mehenStrike(player);
                }
                for (Holder<MobEffect> debuff : DEBUFFS) {   // keberanian Mehen: nggak bisa dilemahkan
                    if (player.hasEffect(debuff)) {
                        player.removeEffect(debuff);
                    }
                }
            }
        }

        Long rageUntil = RAGE_UNTIL.get(id);
        if (rageUntil != null) {
            if (now >= rageUntil) {
                endRage(player);
                ShazamNetwork.broadcastState(player);   // mata kembali normal
            } else if ((rageUntil - now) % 20 == 0) {
                rageStorm(player);
            }
        }

        if (player.tickCount % 200 == 0) {
            SEALED_UNTIL.values().removeIf(until -> until < now);
        }
        AdamCatch.tick(player);   // 0.27 Tangan Kahndaq: proyektil berhenti di udara
        ShazamPassives.tick(player);   // 0.28: petir tiap 2 detik, Muatan Petir, Pelindung Kahndaq, sama dengan Shazam
    }

    /** Hentikan skill yang sedang berjalan (balik jadi manusia, respawn). Cooldown tetap jalan. */
    public static void cancelActive(ServerPlayer player) {
        UUID id = player.getUUID();
        SHU_UNTIL.remove(id);
        DASHES.remove(id);
        FISSURES.remove(id);
        MEHEN_UNTIL.remove(id);
        MEHEN_NEXT_RETALIATE.remove(id);
        endRage(player);
        AdamCatch.reset(player);
    }

    public static void forget(UUID id) {
        AdamCatch.forget(id);
        READY_AT.remove(id);
        CALL_READY_AT.remove(id);
        SHU_UNTIL.remove(id);
        DASHES.remove(id);
        FISSURES.remove(id);
        MEHEN_UNTIL.remove(id);
        MEHEN_NEXT_RETALIATE.remove(id);
        RAGE_UNTIL.remove(id);
    }

    public static boolean isRageActive(ServerPlayer player) {
        Long until = RAGE_UNTIL.get(player.getUUID());
        return until != null && until > player.level().getGameTime();
    }

    public static boolean isMehenActive(ServerPlayer player) {
        Long until = MEHEN_UNTIL.get(player.getUUID());
        return until != null && until > player.level().getGameTime();
    }

    public static boolean isSealed(LivingEntity entity) {
        Long until = SEALED_UNTIL.get(entity.getUUID());
        return until != null && until > entity.level().getGameTime();
    }

    private static List<LivingEntity> enemies(ServerPlayer player, Vec3 center, double radius) {
        return player.serverLevel().getEntitiesOfClass(LivingEntity.class, new AABB(center, center).inflate(radius),
                m -> m.isAlive() && m instanceof Enemy && m.distanceToSqr(center) <= radius * radius);
    }

    private static void sound(ServerPlayer player, Vec3 at, net.minecraft.sounds.SoundEvent sound, float volume, float pitch) {
        player.serverLevel().playSound(null, at.x, at.y, at.z, sound, SoundSource.PLAYERS, volume, pitch);
    }

    // ---------------------------------------------------- S - Pusaran Shu

    private static boolean shu(ServerPlayer player) {
        ShazamNetwork.playAnim(player, ShazamAnim.ADAM_SHU);
        sound(player, player.position(), ShazamSounds.WHOOSH.get(), 1.4f, ShazamSounds.tune(0.5f));
        later(player, ShazamAnim.CAST_WINDUP, p -> {
            SHU_UNTIL.put(p.getUUID(), p.level().getGameTime() + ShazamAnim.SHU_TICKS);
            // stamina Shu: napas dewa udara memulihkan badan
            p.heal(SHU_HEAL);
            p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, SHU_ABSORPTION_TICKS, SHU_ABSORPTION_LEVEL, false, true));
            sound(p, p.position(), ShazamSounds.SHU_VORTEX.get(), 1.8f, 1f);   // pusaran 50 tick
        });
        return true;
    }

    /** Musuh tersedot ke cincin pusaran, berputar, dan terangkat. */
    private static void shuPull(ServerPlayer player, long left) {
        Vec3 c = player.position();
        DamageSource source = ShazamPowers.forceSource(player);
        for (LivingEntity target : enemies(player, c, SHU_RADIUS)) {
            double dx = target.getX() - c.x, dz = target.getZ() - c.z;
            double d = Math.sqrt(dx * dx + dz * dz);
            if (d < 1.0E-3) {
                dx = 1;
                dz = 0;
                d = 1;
            }
            double rx = dx / d, rz = dz / d;      // keluar dari pusat
            double tx = -rz, tz = rx;             // searah putaran
            double pull = Mth.clamp((SHU_RING - d) * 0.12, -0.5, 0.3);
            double height = target.getY() - c.y;
            double vy = height < SHU_LIFT ? 0.16 : (height > SHU_LIFT + 0.8 ? -0.05 : 0.03);
            target.setDeltaMovement(tx * SHU_SPIN + rx * pull, vy, tz * SHU_SPIN + rz * pull);
            target.hurtMarked = true;
            target.fallDistance = 0f;
            if (left % 10 == 0) {
                target.hurt(source, SHU_TICK_DAMAGE);
            }
        }
        if (left % 12 == 0) {
            sound(player, c, ShazamSounds.SAND_BURST.get(), 0.55f, ShazamSounds.tune(0.5f + player.getRandom().nextFloat() * 0.2f));
        }
    }

    /** Pusaran meledak: semua musuh terhempas keluar. */
    private static void shuBurst(ServerPlayer player) {
        Vec3 c = player.position();
        DamageSource source = ShazamPowers.forceSource(player);
        for (LivingEntity target : enemies(player, c, SHU_RADIUS + 1.0)) {
            target.hurt(source, SHU_BURST_DAMAGE);
            Vec3 away = new Vec3(target.getX() - c.x, 0, target.getZ() - c.z);
            Vec3 push = away.lengthSqr() < 1.0E-4 ? Vec3.ZERO : away.normalize().scale(SHU_BURST_KNOCKBACK);
            target.push(push.x, 0.6, push.z);
            target.hurtMarked = true;
        }
        sound(player, c, ShazamSounds.SHU_BURST.get(), 2.0f, 1f);
    }

    // ------------------------------------------------- H - Sambaran Heru

    private static boolean heru(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        Vec3 look = player.getViewVector(1f);
        Vec3 dir = look;
        if (player.onGround() && dir.y < 0.0) {
            dir = new Vec3(dir.x, 0.0, dir.z);   // di tanah: menerjang mendatar, nggak menembus tanah
        }
        if (dir.lengthSqr() < 1.0E-4) {
            return false;
        }
        dir = dir.normalize();
        Vec3 start = player.position();
        Vec3 from = start.add(0, 1.0, 0);
        BlockHitResult hit = level.clip(new ClipContext(from, from.add(dir.scale(HERU_RANGE)), ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, player));
        double distance = hit.getType() == HitResult.Type.MISS ? HERU_RANGE : hit.getLocation().distanceTo(from) - 0.9;
        // titik akhir harus muat untuk badan: mundur sedikit-sedikit sampai bebas dari blok
        Vec3 end = start.add(dir.scale(distance));
        while (distance >= 2.0 && !level.noCollision(player, player.getBoundingBox().move(end.subtract(start)))) {
            distance -= 0.5;
            end = start.add(dir.scale(distance));
        }
        if (distance < 2.0) {
            return false;   // tembok tepat di depan
        }
        DASHES.put(player.getUUID(), new Dash(start, end, level.getGameTime() + ShazamAnim.HERU_WINDUP, new HashSet<>()));
        ShazamNetwork.playAnim(player, ShazamAnim.ADAM_HERU, end);   // client pemain sendiri yang menggerakkan badan
        // merunduk 3 tick (tarikan napas), lalu pekik elang + desing terjangan: semuanya sudah diatur di dalam suaranya
        sound(player, start, ShazamSounds.HERU_DIVE.get(), 1.8f, 1f);
        return true;
    }

    /** Potongan lintasan tick ke-k: musuh di dekatnya tertabrak. */
    private static void heruStep(ServerPlayer player, Dash dash, int k) {
        double t0 = Mth.clamp((k - 1) / (double) ShazamAnim.HERU_TICKS, 0.0, 1.0);
        double t1 = Mth.clamp(k / (double) ShazamAnim.HERU_TICKS, 0.0, 1.0);
        Vec3 a = dash.start().lerp(dash.end(), t0).add(0, 1.0, 0);
        Vec3 b = dash.start().lerp(dash.end(), t1).add(0, 1.0, 0);
        DamageSource source = ShazamPowers.forceSource(player);
        Vec3 dir = dash.end().subtract(dash.start()).normalize();
        AABB box = new AABB(a, b).inflate(HERU_HIT_RADIUS + 1.0);
        for (LivingEntity target : player.serverLevel().getEntitiesOfClass(LivingEntity.class, box,
                m -> m.isAlive() && m instanceof Enemy)) {
            Vec3 body = target.position().add(0, target.getBbHeight() * 0.5, 0);
            if (distanceToSegment(body, a, b) > HERU_HIT_RADIUS + target.getBbWidth() * 0.5 || !dash.hit().add(target.getUUID())) {
                continue;
            }
            target.hurt(source, HERU_DAMAGE);
            // tersibak ke samping lintasan dan sedikit terangkat, seperti ditabrak elang
            Vec3 side = body.subtract(a);
            side = side.subtract(dir.scale(side.dot(dir)));
            Vec3 push = side.lengthSqr() < 1.0E-4 ? new Vec3(-dir.z, 0, dir.x) : side.normalize();
            target.push(push.x * 1.1 + dir.x * 0.5, 0.45, push.z * 1.1 + dir.z * 0.5);
            target.hurtMarked = true;
            sound(player, body, ShazamSounds.PUNCH.get(), 1.0f, ShazamSounds.tune(0.7f));
        }
    }

    private static void heruArrive(ServerPlayer player, Dash dash) {
        Vec3 c = dash.end();
        DamageSource source = ShazamPowers.forceSource(player);
        for (LivingEntity target : enemies(player, c, HERU_END_RADIUS)) {
            if (dash.hit().contains(target.getUUID())) {
                continue;
            }
            target.hurt(source, HERU_END_DAMAGE);
            Vec3 away = new Vec3(target.getX() - c.x, 0, target.getZ() - c.z);
            Vec3 push = away.lengthSqr() < 1.0E-4 ? Vec3.ZERO : away.normalize().scale(0.9);
            target.push(push.x, 0.35, push.z);
            target.hurtMarked = true;
        }
        sound(player, c, ShazamSounds.HERU_LAND.get(), 1.6f, 1f);
    }

    static double distanceToSegment(Vec3 p, Vec3 a, Vec3 b) {
        Vec3 ab = b.subtract(a);
        double len = ab.lengthSqr();
        double t = len < 1.0E-9 ? 0.0 : Mth.clamp(p.subtract(a).dot(ab) / len, 0.0, 1.0);
        return p.distanceTo(a.add(ab.scale(t)));
    }

    // --------------------------------------------------- A - Tinju Amon

    private static boolean amon(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        Vec3 pos = player.position();
        BlockHitResult ground = level.clip(new ClipContext(pos.add(0, 0.5, 0), pos.add(0, -6.0, 0), ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, player));
        if (ground.getType() == HitResult.Type.MISS) {
            return false;   // terlalu tinggi di udara: nggak ada tanah untuk dibelah
        }
        Vec3 look = player.getViewVector(1f);
        Vec3 flat = new Vec3(look.x, 0, look.z);
        if (flat.lengthSqr() < 1.0E-4) {
            float yaw = player.getYRot() * Mth.DEG_TO_RAD;
            flat = new Vec3(-Mth.sin(yaw), 0, Mth.cos(yaw));
        }
        flat = flat.normalize();
        Vec3 origin = new Vec3(pos.x, ground.getLocation().y, pos.z);
        FISSURES.put(player.getUUID(), new Fissure(origin, flat, level.getGameTime() + ShazamAnim.AMON_WINDUP, new HashSet<>()));
        ShazamNetwork.playAnim(player, ShazamAnim.ADAM_AMON, origin.add(flat.scale(AMON_RANGE)));
        sound(player, pos, ShazamSounds.AMON_WINDUP.get(), 1.6f, 1f);   // melompat 7 tick, memuncak saat kepalan menghantam
        later(player, ShazamAnim.AMON_WINDUP, p -> {
            sound(p, origin, ShazamSounds.AMON_QUAKE.get(), 2.4f, 1f);
        });
        return true;
    }

    /** Tanah terbelah merambat: tick ke-k membelah sampai jarak k/AMON_SPREAD x AMON_RANGE. */
    private static void amonStep(ServerPlayer player, Fissure f, int k) {
        DamageSource source = ShazamPowers.forceSource(player);
        if (k == 0) {   // kepalan menghantam tanah
            for (LivingEntity target : enemies(player, f.origin(), AMON_SLAM_RADIUS)) {
                f.hit().add(target.getUUID());
                target.hurt(source, AMON_SLAM_DAMAGE);
                target.push(0, 0.6, 0);
                target.hurtMarked = true;
            }
            return;
        }
        double near = AMON_RANGE * (k - 1) / ShazamAnim.AMON_SPREAD;
        double far = AMON_RANGE * k / ShazamAnim.AMON_SPREAD;
        Vec3 dir = f.dir();
        Vec3 a = f.origin().add(dir.scale(near)), b = f.origin().add(dir.scale(far));
        AABB box = new AABB(a, b).inflate(AMON_WIDTH + 1.0, 3.0, AMON_WIDTH + 1.0);
        for (LivingEntity target : player.serverLevel().getEntitiesOfClass(LivingEntity.class, box,
                m -> m.isAlive() && m instanceof Enemy)) {
            Vec3 rel = target.position().subtract(f.origin());
            double along = rel.x * dir.x + rel.z * dir.z;
            double side = Math.abs(rel.x * dir.z - rel.z * dir.x);
            if (along < near - 0.5 || along > far + 0.5 || side > AMON_WIDTH + target.getBbWidth() * 0.5
                    || Math.abs(rel.y) > 3.0 || !f.hit().add(target.getUUID())) {
                continue;
            }
            target.hurt(source, AMON_DAMAGE);
            target.push(dir.x * 0.35, AMON_LAUNCH, dir.z * 0.35);   // tanah meledak ke atas di bawah kakinya
            target.hurtMarked = true;
        }
        Vec3 front = f.origin().add(dir.scale(far));
        if (k % 2 == 0) {
            sound(player, front, ShazamSounds.EARTH_CRACK.get(), 1.6f, ShazamSounds.tune(0.5f));
        } else {
            sound(player, front, ShazamSounds.EARTH_CRACK.get(), 1.4f, ShazamSounds.tune(0.6f));
        }
    }

    // ----------------------------------------------------- Z - Segel Zehuti

    private static boolean zehuti(ServerPlayer player) {
        List<LivingEntity> targets = enemies(player, player.position(), ZEHUTI_RADIUS);
        targets.removeIf(m -> !player.hasLineOfSight(m));
        if (targets.isEmpty()) {
            return false;
        }
        targets.sort(Comparator.comparingDouble(m -> m.distanceToSqr(player)));
        List<LivingEntity> chosen = new ArrayList<>(targets.subList(0, Math.min(ZEHUTI_TARGETS, targets.size())));
        ShazamNetwork.playAnim(player, ShazamAnim.ADAM_ZEHUTI);
        sound(player, player.position(), ShazamSounds.ZEHUTI_CAST.get(), 1.4f, 1f);
        later(player, ShazamAnim.CAST_WINDUP, p -> {
            long until = p.level().getGameTime() + ZEHUTI_TICKS;
            DamageSource source = ShazamPowers.forceSource(p);
            for (LivingEntity target : chosen) {
                if (!target.isAlive()) {
                    continue;
                }
                target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, ZEHUTI_TICKS, 4), p);
                target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, ZEHUTI_TICKS, 1), p);
                target.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, ZEHUTI_TICKS, 2), p);
                target.addEffect(new MobEffectInstance(MobEffects.GLOWING, ZEHUTI_TICKS, 0, false, false), p);
                SEALED_UNTIL.put(target.getUUID(), until);
                target.hurt(source, ZEHUTI_DAMAGE);
                ShazamNetwork.playAnim(p, ShazamAnim.ADAM_ZEHUTI_MARK, target.position());
            }
            sound(p, p.position(), ShazamSounds.ZEHUTI_SEAL.get(), 2.0f, 1f);
        });
        return true;
    }

    // ------------------------------------------------------- A - Sinar Aton

    private static boolean aton(ServerPlayer player) {
        List<LivingEntity> targets = enemies(player, player.position(), ATON_RANGE);
        targets.removeIf(m -> !player.hasLineOfSight(m));
        targets.sort(Comparator.comparingDouble(m -> m.distanceToSqr(player)));
        List<LivingEntity> chosen = new ArrayList<>(targets.subList(0, Math.min(ATON_TARGETS, targets.size())));
        Vec3 aimed = null;
        if (chosen.isEmpty()) {
            LivingEntity entity = ShazamSkills.aimedEntity(player, 32.0);
            if (entity != null) {
                chosen.add(entity);
            } else {
                BlockHitResult block = ShazamSkills.clipBlocks(player, 32.0);
                if (block.getType() == HitResult.Type.MISS) {
                    return false;
                }
                aimed = block.getLocation();
            }
        }
        ShazamNetwork.playAnim(player, ShazamAnim.ADAM_ATON);
        sound(player, player.position(), ShazamSounds.ATON_WINDUP.get(), 1.6f, 1f);   // cakram matahari terbentuk 8 tick
        if (aimed != null) {
            Vec3 point = aimed;
            later(player, ShazamAnim.ATON_WINDUP, p -> {
                ShazamNetwork.playAnim(p, ShazamAnim.ADAM_ATON_RAY, point);
                DamageSource source = ShazamPowers.lightningSource(p);
                for (LivingEntity target : enemies(p, point, ATON_SPLASH)) {
                    target.hurt(source, ATON_DAMAGE);
                    target.igniteForSeconds(ATON_FIRE_SECONDS);
                }
                sound(p, point, ShazamSounds.ATON_RAY.get(), 1.8f, 1f);
            });
            return true;
        }
        for (int i = 0; i < chosen.size(); i++) {
            LivingEntity target = chosen.get(i);
            later(player, ShazamAnim.ATON_WINDUP + i * ShazamAnim.ATON_GAP, p -> {
                if (!target.isAlive() || target.distanceToSqr(p) > (ATON_RANGE + 8.0) * (ATON_RANGE + 8.0)) {
                    return;
                }
                Vec3 at = target.position().add(0, target.getBbHeight() * 0.55, 0);
                ShazamNetwork.playAnim(p, ShazamAnim.ADAM_ATON_RAY, at);
                target.hurt(ShazamPowers.lightningSource(p), ATON_DAMAGE);
                target.igniteForSeconds(ATON_FIRE_SECONDS);
                sound(p, at, ShazamSounds.ATON_RAY.get(), 1.6f, 0.95f + p.getRandom().nextFloat() * 0.1f);
            });
        }
        return true;
    }

    // ----------------------------------------------------- M - Lilitan Mehen

    private static boolean mehen(ServerPlayer player) {
        ShazamNetwork.playAnim(player, ShazamAnim.ADAM_MEHEN);
        sound(player, player.position(), ShazamSounds.MEHEN_RISE.get(), 1.6f, 1f);   // ular muncul dari bayangan 6 tick
        later(player, ShazamAnim.MEHEN_WINDUP, p -> {
            long now = p.level().getGameTime();
            MEHEN_UNTIL.put(p.getUUID(), now + ShazamAnim.MEHEN_TICKS);
            MEHEN_NEXT_RETALIATE.put(p.getUUID(), now);
            sound(p, p.position(), ShazamSounds.MEHEN_COIL.get(), 2.0f, 1f);
        });
        return true;
    }

    /** Tiap detik ular mematuk musuh terdekat. */
    private static void mehenStrike(ServerPlayer player) {
        List<LivingEntity> targets = enemies(player, player.position(), MEHEN_RADIUS);
        targets.sort(Comparator.comparingDouble(m -> m.distanceToSqr(player)));
        for (int i = 0; i < Math.min(MEHEN_BITES, targets.size()); i++) {
            bite(player, targets.get(i));
        }
    }

    private static void bite(ServerPlayer player, LivingEntity target) {
        Vec3 at = target.position().add(0, target.getBbHeight() * 0.6, 0);
        ShazamNetwork.playAnim(player, ShazamAnim.ADAM_MEHEN_BITE, at);
        target.hurt(ShazamPowers.forceSource(player), MEHEN_BITE_DAMAGE);
        target.addEffect(new MobEffectInstance(MobEffects.POISON, 60, 1), player);   // bisa ular
        Vec3 away = new Vec3(target.getX() - player.getX(), 0, target.getZ() - player.getZ());
        if (away.lengthSqr() > 1.0E-4) {
            away = away.normalize();
            target.push(away.x * 0.6, 0.25, away.z * 0.6);
            target.hurtMarked = true;
        }
        sound(player, at, ShazamSounds.MEHEN_BITE.get(), 1.4f, 0.95f + player.getRandom().nextFloat() * 0.1f);
    }

    /** Yang menyerang Black Adam selagi dililit Mehen langsung dipatuk balik. */
    public static void mehenRetaliate(ServerPlayer victim, DamageSource source) {
        if (!(source.getEntity() instanceof LivingEntity attacker) || attacker == victim || !attacker.isAlive()
                || attacker.distanceToSqr(victim) > 8.0 * 8.0) {
            return;
        }
        long now = victim.level().getGameTime();
        Long next = MEHEN_NEXT_RETALIATE.get(victim.getUUID());
        if (next != null && now < next) {
            return;
        }
        MEHEN_NEXT_RETALIATE.put(victim.getUUID(), now + MEHEN_RETALIATE_GAP);
        // sesudah event damage ini selesai, jangan di tengahnya
        ShazamPowers.schedule(victim, 1, p -> {
            if (isMehenActive(p) && attacker.isAlive()) {
                bite(p, attacker);
            }
        });
    }

    // ---------------------------------------------------- Murka Kahndaq

    private static boolean kahndaq(ServerPlayer player) {
        ShazamNetwork.playAnim(player, ShazamAnim.ADAM_RAGE);
        sound(player, player.position(), ShazamSounds.KAHNDAQ_WINDUP.get(), 1.8f, 1f);   // amarah tertahan 10 tick
        later(player, ShazamAnim.ADAM_RAGE_WINDUP, AdamSkills::ignite);
        return true;
    }

    /** Amarah menyala: mata emas, petir membara di sekeliling, musuh dekat terhempas. */
    private static void ignite(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        RAGE_UNTIL.put(player.getUUID(), level.getGameTime() + ShazamAnim.RAGE_TICKS);
        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null && !speed.hasModifier(RAGE_SPEED)) {
            speed.addTransientModifier(new AttributeModifier(RAGE_SPEED, RAGE_SPEED_BONUS,
                    AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        }
        Vec3 center = player.position();
        ShazamPowers.strikeLightning(player, center, RAGE_BURST_DAMAGE, RAGE_BURST_RADIUS, 1.8f);
        for (LivingEntity target : enemies(player, center, RAGE_BURST_RADIUS)) {
            Vec3 away = new Vec3(target.getX() - center.x, 0, target.getZ() - center.z);
            Vec3 push = away.lengthSqr() < 1.0E-4 ? Vec3.ZERO : away.normalize().scale(1.6);
            target.push(push.x, 0.5, push.z);
            target.hurtMarked = true;
        }
        for (int i = 0; i < 5; i++) {
            double angle = Math.PI * 2.0 * i / 5.0 + level.random.nextDouble() * 0.5;
            ShazamPowers.spawnBolt(level, center.add(Math.cos(angle) * 3.5, 0, Math.sin(angle) * 3.5), 0.9f,
                    ShazamForm.BLACK_ADAM.boltVariant());
        }
        // raungan + braam gelap ala trailer + retakan petir + sub, ekornya dengung mencekam
        sound(player, center, ShazamSounds.KAHNDAQ_WRATH.get(), 2.5f, 1f);
        ShazamNetwork.broadcastState(player);
    }

    private static void endRage(ServerPlayer player) {
        RAGE_UNTIL.remove(player.getUUID());
        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null) {
            speed.removeModifier(RAGE_SPEED);
        }
    }

    /** Tiap detik petir membara memburu musuh terdekat. */
    private static void rageStorm(ServerPlayer player) {
        List<LivingEntity> targets = enemies(player, player.position(), RAGE_STORM_RADIUS);
        targets.sort(Comparator.comparingDouble(m -> m.distanceToSqr(player)));
        for (int i = 0; i < Math.min(RAGE_STORM_TARGETS, targets.size()); i++) {
            ShazamPowers.strikeLightning(player, targets.get(i).position(), RAGE_STORM_DAMAGE, 1.2, 0.9f);
        }
    }

    /** Tinju membara: sasaran disambar, musuh di dekatnya terhempas, lalu petir merambat ke dua musuh lain. */
    public static void ragePunch(ServerPlayer player, LivingEntity target) {
        ServerLevel level = player.serverLevel();
        ShazamPowers.spawnBolt(level, target.position(), 0.7f, ShazamForm.BLACK_ADAM.boltVariant());
        sound(player, target.position(), ShazamSounds.THUNDER_PUNCH.get(), 1.6f, 0.88f);   // versi Black Adam: lebih berat
        DamageSource force = ShazamPowers.forceSource(player);
        Vec3 c = target.position();
        for (LivingEntity other : enemies(player, c, RAGE_BLAST_RADIUS)) {
            if (other == target) {
                continue;
            }
            other.hurt(force, RAGE_BLAST_DAMAGE);
            Vec3 away = new Vec3(other.getX() - c.x, 0, other.getZ() - c.z);
            Vec3 push = away.lengthSqr() < 1.0E-4 ? Vec3.ZERO : away.normalize().scale(0.9);
            other.push(push.x, 0.3, push.z);
            other.hurtMarked = true;
        }
        List<LivingEntity> nearby = enemies(player, c, RAGE_CHAIN_RADIUS);
        nearby.remove(target);
        nearby.sort(Comparator.comparingDouble(m -> m.distanceToSqr(target)));
        for (int i = 0; i < Math.min(RAGE_CHAIN_TARGETS, nearby.size()); i++) {
            ShazamPowers.strikeLightning(player, nearby.get(i).position(), RAGE_CHAIN_DAMAGE, 0.8, 0.6f);
        }
    }

    // ------------------------------------------- M - Panggil Petir Kahndaq

    public static int callCooldownTicks(ServerPlayer player) {
        Long ready = CALL_READY_AT.get(player.getUUID());
        if (ready == null) {
            return 0;
        }
        long left = ready - player.level().getGameTime();
        return left > 0 ? (int) left : 0;
    }

    /**
     * Kepalan diangkat ke langit dan petir sihir menyambar badan sendiri (seperti di film: kekuatannya diisi ulang petir
     * di tengah pertarungan). Energi & darah terisi, efek penghambat lenyap, dan petirnya menghempas musuh di sekitar.
     */
    public static void callLightning(ServerPlayer player) {
        if (!ShazamPowers.isAdam(player) || callCooldownTicks(player) > 0) {
            return;
        }
        CALL_READY_AT.put(player.getUUID(), player.level().getGameTime() + CALL_COOLDOWN_TICKS);
        ShazamNetwork.playAnim(player, ShazamAnim.ADAM_CALL);
        sound(player, player.position(), ShazamSounds.CALL_WINDUP.get(), 2.0f, 1f);   // langit bergemuruh 12 tick
        later(player, ShazamAnim.ADAM_CALL_WINDUP, p -> {
            ServerLevel level = p.serverLevel();
            Vec3 c = p.position();
            ShazamPowers.spawnBolt(level, c, 2.3f, ShazamForm.BLACK_ADAM.boltVariant());
            level.playSound(null, c.x, c.y, c.z, ShazamSounds.THUNDER.get(), SoundSource.WEATHER, 4.0f, ShazamSounds.tune(0.65f));
            level.playSound(null, c.x, c.y, c.z, ShazamSounds.LIGHTNING_STRIKE.get(), SoundSource.WEATHER, 2.0f, ShazamSounds.tune(0.55f));
            ShazamData data = ShazamPowers.data(p);
            ShazamPowers.setData(p, data.withEnergy(data.energy() + CALL_ENERGY));
            p.heal(CALL_HEAL);
            p.clearFire();
            for (Holder<MobEffect> debuff : DEBUFFS) {
                if (p.hasEffect(debuff)) {
                    p.removeEffect(debuff);
                }
            }
            DamageSource source = ShazamPowers.lightningSource(p);
            for (LivingEntity target : enemies(p, c, CALL_RADIUS)) {
                target.hurt(source, CALL_DAMAGE);
                Vec3 away = new Vec3(target.getX() - c.x, 0, target.getZ() - c.z);
                Vec3 push = away.lengthSqr() < 1.0E-4 ? Vec3.ZERO : away.normalize().scale(CALL_KNOCKBACK);
                target.push(push.x, 0.55, push.z);
                target.hurtMarked = true;
            }
            ShazamNetwork.sync(p);
        });
        ShazamNetwork.sync(player);
    }
}
