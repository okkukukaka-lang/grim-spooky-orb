package com.shazammod.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.shazammod.client.anim.LintangBody;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.entity.LivingEntity;

/** Setelah pose bawaan dihitung, timpa dengan pose Shazam (terbang, berdiri, skill). */
@Mixin(HumanoidModel.class)
public abstract class HumanoidModelMixin {
    @Inject(method = "setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V", at = @At("TAIL"))
    private void shazammod$applyPoses(LivingEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                                      float netHeadYaw, float headPitch, CallbackInfo ci) {
        if (entity instanceof AbstractClientPlayer player) {
            // 0.33: LintangBody memanggil ShazamPoses.apply dulu, lalu menambah pose eksperimen & melemah Lintang
            LintangBody.apply((HumanoidModel<?>) (Object) this, player, ageInTicks);
        }
    }
}
