package com.shazammod;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Barang jalan Black Adam: Skarabe Teth-Adam. Ditemukan di peti Piramida Gurun (Desert Temple), atau sesekali dijatuhkan
 * Husk yang dikalahkan di gurun. Dipakai di gurun/badlands untuk memulai Ujian Kahndaq (lihat KahndaqTrial).
 */
@EventBusSubscriber(modid = ShazamMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public final class AdamItems {
    private AdamItems() {}

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(ShazamMod.MODID);

    public static final DeferredItem<ScarabItem> SCARAB = ITEMS.register("scarab_of_teth_adam",
            () -> new ScarabItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant()));

    @SubscribeEvent
    public static void addToCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            event.accept(SCARAB.get());
        }
    }
}
