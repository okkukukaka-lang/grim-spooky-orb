package com.shazammod;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.phys.Vec3;

/**
 * 0.36 Anjing Super (terinspirasi anjing super di DLC Superman, rancangannya orisinal): serigala jinak milik Lintang yang
 * sedang dalam Mode Surya ikut kuat. Mereka lari lebih cepat, gigitannya jauh lebih keras, tahan banting, kebal api &
 * jatuh, pulih di bawah matahari, dan IKUT TERBANG di samping Lintang saat dia terbang. Di client mereka memakai jubah merah
 * kecil (SuperDogCapeLayer) dan meninggalkan jejak uap saat melesat (LintangFx).
 *
 * Tanpa data yang disimpan di serigalanya: cuma efek pendek yang terus diperbarui dan kecepatan yang diatur tiap tick,
 * jadi begitu Lintang berhenti (balik jadi manusia, keluar, terlalu jauh) serigalanya otomatis kembali biasa.
 */
public final class LintangDog {
    private LintangDog() {}

    // ======= Angka yang gampang diutak-atik =======
    public static final double RANGE = 48.0;           // serigala sejauh ini dari Lintang ikut jadi anjing super
    private static final int SCAN_TICKS = 20;          // daftar serigala diperbarui tiap 1 detik
    private static final int BUFF_TICKS = 50;          // lama efek (diperbarui tiap SCAN_TICKS)
    private static final int SPEED_LEVEL = 1;          // Kecepatan II
    private static final int STRENGTH_LEVEL = 2;       // Kekuatan III (gigitan 4 -> 13)
    private static final int RESIST_LEVEL = 2;         // Ketahanan III (damage diterima -60%)
    private static final double FLY_SPEED = 2.6;       // batas kecepatan terbang (blok/tick)
    private static final double FLY_FOLLOW = 0.3;      // seberapa cepat mengejar titiknya di samping Lintang
    private static final double FLY_TELEPORT = 40.0;   // tertinggal sejauh ini di udara: langsung menyusul

    private static final Map<UUID, List<Wolf>> DOGS = new HashMap<>();
    private static final Map<UUID, Vec3> LAST_POS = new HashMap<>();

    /** Dipanggil tiap tick dari LintangSkills.tick (Lintang sedang dalam Mode Surya). */
    public static void tick(ServerPlayer player) {
        UUID id = player.getUUID();
        Vec3 pos = player.position();
        Vec3 last = LAST_POS.put(id, pos);
        Vec3 velocity = last == null ? Vec3.ZERO : pos.subtract(last);   // kecepatan pemain di server dihitung sendiri
        if (velocity.lengthSqr() > 16.0) {
            velocity = Vec3.ZERO;   // teleport, bukan terbang
        }
        List<Wolf> dogs = DOGS.get(id);
        boolean scan = dogs == null || player.tickCount % SCAN_TICKS == 0;
        if (scan) {
            dogs = new ArrayList<>(player.serverLevel().getEntitiesOfClass(Wolf.class, player.getBoundingBox().inflate(RANGE),
                    w -> w.isAlive() && w.isTame() && w.isOwnedBy(player)));
            DOGS.put(id, dogs);
        }
        boolean flying = player.getAbilities().flying && !player.onGround();
        boolean sun = ShazamPowers.isInSun(player);
        int index = 0;
        for (Wolf dog : dogs) {
            if (!dog.isAlive() || dog.isRemoved() || dog.level() != player.level()) {
                continue;
            }
            dog.fallDistance = 0f;   // kebal jatuh (juga sesudah terbang)
            if (scan) {
                buff(dog, sun);
            }
            if (flying && !dog.isOrderedToSit() && !dog.isLeashed() && !dog.isPassenger()) {
                fly(player, dog, velocity, index++);
            }
        }
    }

    private static void buff(Wolf dog, boolean sun) {
        // ambient & tanpa butiran: kekuatannya nggak terlihat sebagai pusaran efek (nggak ada kesan sihir)
        dog.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, BUFF_TICKS, SPEED_LEVEL, true, false));
        dog.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, BUFF_TICKS, STRENGTH_LEVEL, true, false));
        dog.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, BUFF_TICKS, RESIST_LEVEL, true, false));
        dog.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, BUFF_TICKS, 0, true, false));
        if (sun) {   // sel suryanya ikut menyerap matahari
            dog.addEffect(new MobEffectInstance(MobEffects.REGENERATION, BUFF_TICKS, 1, true, false));
        }
    }

    /** Terbang di samping-belakang Lintang (kiri & kanan bergantian kalau serigalanya banyak). */
    private static void fly(ServerPlayer player, Wolf dog, Vec3 velocity, int index) {
        Vec3 look = player.getViewVector(1f);
        Vec3 flat = new Vec3(look.x, 0, look.z);
        if (flat.lengthSqr() < 1.0E-4) {
            float yaw = player.getYRot() * Mth.DEG_TO_RAD;
            flat = new Vec3(-Mth.sin(yaw), 0, Mth.cos(yaw));
        }
        flat = flat.normalize();
        Vec3 side = new Vec3(-flat.z, 0, flat.x);
        double sign = index % 2 == 0 ? 1.0 : -1.0;
        double row = 1.6 + (index / 2) * 1.4;
        Vec3 spot = player.position().add(flat.scale(-row)).add(side.scale(1.3 * sign)).add(0, 0.2, 0);
        Vec3 to = spot.subtract(dog.position());
        if (to.lengthSqr() > FLY_TELEPORT * FLY_TELEPORT) {
            dog.moveTo(spot.x, spot.y, spot.z, player.getYRot(), 0f);
            dog.setDeltaMovement(velocity);
        } else {
            Vec3 v = to.scale(FLY_FOLLOW).add(velocity.scale(0.85));
            if (v.length() > FLY_SPEED) {
                v = v.normalize().scale(FLY_SPEED);
            }
            dog.setDeltaMovement(v);
            Vec3 face = new Vec3(v.x, 0, v.z).lengthSqr() > 0.01 ? v : flat;
            float yaw = (float) (Mth.atan2(face.z, face.x) * Mth.RAD_TO_DEG) - 90f;
            dog.setYRot(yaw);
            dog.yBodyRot = yaw;
            dog.setYHeadRot(yaw);
        }
        dog.getNavigation().stop();
        dog.hurtMarked = true;
    }

    /** Lintang berhenti (balik jadi manusia / mati): serigalanya dilepas (efek pendeknya habis sendiri). */
    public static void release(ServerPlayer player) {
        DOGS.remove(player.getUUID());
        LAST_POS.remove(player.getUUID());
    }

    public static void forget(UUID id) {
        DOGS.remove(id);
        LAST_POS.remove(id);
    }
}
